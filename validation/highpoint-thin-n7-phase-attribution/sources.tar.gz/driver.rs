//! Constructor-only diagnostic: no kinematics, workspace, masters, or result arrays.
use iregi_rust::{Algorithm, ReductionSettings, thin_n7::ThinSevenReductionPlan};
use serde_json::{Value, json};
use std::{path::Path, time::Instant};

fn write(path: &Path, value: &Value) -> Result<(), Box<dyn std::error::Error>> {
    let temporary = path.with_extension("tmp");
    std::fs::write(&temporary, serde_json::to_vec_pretty(value)?)?;
    std::fs::rename(temporary, path)?;
    Ok(())
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args_os().collect();
    if args.len() != 2 { return Err("expected one result-ledger path".into()); }
    let output = Path::new(&args[1]);
    let mut settings = ReductionSettings::new(7, 0);
    settings.algorithm = Algorithm::PassarinoVeltman;
    let mut record = json!({
        "schema_version": 1,
        "status": "preparing_plan",
        "scope": "Generic private ThinSevenReductionPlan::new only; no numerical kinematics, workspace, masters, arrays, oracle, reference or performance acceptance",
        "settings": &settings,
        "constructor_completed": false,
        "workspace_created": false,
        "numerical_arrays": false,
    });
    write(output, &record)?;
    let started = Instant::now();
    match ThinSevenReductionPlan::new(settings) {
        Ok(plan) => {
            record["status"] = json!("constructor_complete");
            record["constructor_completed"] = json!(true);
            record["elapsed_seconds"] = json!(started.elapsed().as_secs_f64());
            record["alias_count"] = json!(plan.alias_count());
            record["basis_count"] = json!(plan.basis().len());
            write(output, &record)?;
        }
        Err(error) => {
            record["status"] = json!("constructor_failed");
            record["elapsed_seconds"] = json!(started.elapsed().as_secs_f64());
            record["error"] = json!(error.to_string());
            write(output, &record)?;
            return Err(error.into());
        }
    }
    Ok(())
}
