//! Geometry for the private thin seven-point dispatcher.
//!
//! These are exact preserved-coordinate identities. No tensor child is prepared
//! or evaluated here. Symbolica owns determinants, inverses, matrix products and
//! coefficient arithmetic; the integer maps only select ordered propagators.

use super::{Atom, AtomCore, Matrix, PreparationTimer, PvCompiler, coordinate_rows, dot, field};

/// One candidate for the complete seven-point parent expression.
#[derive(Clone, Debug)]
pub(crate) struct ThinSevenChart {
    /// Omitted column among the six non-origin parent lines. The absent line is
    /// `active[omitted + 1]`, and its weight is structurally zero in every column.
    pub omitted: usize,
    /// Exact coordinate polynomial without internally generated PV aliases.
    /// This is a chart predicate, not a numerical nonzero certificate.
    pub determinant: Atom,
    /// Constant-one column followed by the four Cartesian numerator columns.
    /// Each vector uses the complete seven-line parent order.
    pub weights: [Vec<Atom>; 5],
}

/// A six-line coefficient system, including a structurally unavailable system.
#[derive(Clone, Debug)]
pub(crate) struct ThinSixGeometry {
    /// Ordered original propagator indices; the first is this child's origin.
    pub active: Vec<usize>,
    pub determinant: Atom,
    /// `None` means exact structural singularity, never a successful zero.
    /// A demanded unavailable child must reject its parent representation.
    pub weights: Option<[Vec<Atom>; 5]>,
}

#[derive(Clone, Debug)]
pub(crate) struct ThinSevenGeometry {
    pub active: Vec<usize>,
    /// Highest-priority chart first, matching the existing PV selection order:
    /// omitted columns 5,4,3,2,1,0, with exact singular charts absent.
    /// Select complete assembled chart expressions lazily; do not select the
    /// five columns independently or evaluate inactive child inverses eagerly.
    pub charts: Vec<ThinSevenChart>,
    /// Entry `i` omits `active[i]`, preserving every other line's order.
    pub six: Vec<ThinSixGeometry>,
}

impl PvCompiler {
    /// Construct geometry only. The caller enforces the private preserved-shift,
    /// unit-power native Cartesian domain before using these coefficients.
    pub(crate) fn thin_seven_geometry(
        &mut self,
        active: &[usize],
    ) -> Result<ThinSevenGeometry, String> {
        validate_active(self, active, 7)?;
        let mut six = Vec::with_capacity(7);
        for omitted in 0..7 {
            let subset: Vec<_> = active
                .iter()
                .enumerate()
                .filter_map(|(position, &line)| (position != omitted).then_some(line))
                .collect();
            six.push(self.thin_six_geometry(&subset)?);
        }
        let mut charts = Vec::with_capacity(6);
        for omitted in (0..6).rev() {
            // The chart omits one non-origin parent line, so its matrix and
            // every RHS equal this already prepared six-line system. Reuse
            // those aliases rather than repeat six exact inversions.
            let removed = omitted + 1;
            let child = &six[removed];
            let Some(child_weights) = &child.weights else {
                continue;
            };
            let weights = std::array::from_fn(|column| {
                let mut weights = vec![Atom::new(); 7];
                for (local, parent_position) in
                    (0..7).filter(|&position| position != removed).enumerate()
                {
                    weights[parent_position] = child_weights[column][local].clone();
                }
                weights
            });
            charts.push(ThinSevenChart {
                omitted,
                determinant: child.determinant.clone(),
                weights,
            });
        }
        if charts.is_empty() {
            return Err(
                "thin seven-point coordinate system has no structurally regular chart".into(),
            );
        }
        Ok(ThinSevenGeometry {
            active: active.to_vec(),
            charts,
            six,
        })
    }

    /// The five RHS columns for an ordered six-line subset. In particular,
    /// omitting the original origin changes the last Cartesian RHS entries.
    pub(crate) fn thin_six_geometry(
        &mut self,
        active: &[usize],
    ) -> Result<ThinSixGeometry, String> {
        validate_active(self, active, 6)?;
        let columns = [0, 1, 2, 3, 4];
        let (determinant, weights) = solve_chart(self, active, &columns)?;
        Ok(ThinSixGeometry {
            active: active.to_vec(),
            determinant,
            weights,
        })
    }
}

fn validate_active(compiler: &PvCompiler, active: &[usize], expected: usize) -> Result<(), String> {
    if active.len() != expected
        || active.iter().enumerate().any(|(position, &line)| {
            line >= compiler.shifts.len() || active[..position].contains(&line)
        })
    {
        return Err(format!(
            "thin geometry requires {expected} distinct in-range ordered propagators"
        ));
    }
    if !compiler.moments.is_empty() {
        return Err("thin geometry requires a compiler with no prepared tensor moments".into());
    }
    Ok(())
}

/// Solve a five-column relative-coordinate chart against the constant and four
/// Cartesian RHS columns. The raw matrix deliberately uses coordinate distances,
/// not supplied/snapped invariants or coefficient aliases.
fn solve_chart(
    compiler: &mut PvCompiler,
    active: &[usize],
    columns: &[usize],
) -> Result<(Atom, Option<[Vec<Atom>; 5]>), String> {
    let _chart = PreparationTimer::new(compiler.profile_preparation, format_args!("thin N7 six-line chart {active:?}"));
    let _matrix = PreparationTimer::new(compiler.profile_preparation, format_args!("thin N7 matrix assembly {active:?}"));
    let origin = active[0];
    let mut rows = coordinate_rows(&compiler.shifts, active);
    rows.push(
        active[1..]
            .iter()
            .map(|&line| {
                let delta = std::array::from_fn(|mu| {
                    &compiler.shifts[line][mu] - &compiler.shifts[origin][mu]
                });
                dot(&delta, &delta) - &compiler.mass_squared[line] + &compiler.mass_squared[origin]
            })
            .collect(),
    );
    let matrix = Matrix::from_nested_vec(
        rows.iter()
            .map(|row| columns.iter().map(|&column| row[column].clone()).collect())
            .collect(),
        field(),
    )
    .map_err(|error| format!("thin coordinate chart matrix: {error}"))?;
    drop(_matrix);
    let _determinant = PreparationTimer::new(compiler.profile_preparation, format_args!("thin N7 determinant {active:?}"));
    let determinant = matrix
        .det()
        .map_err(|error| format!("thin coordinate chart determinant: {error:?}"))?;
    drop(_determinant);
    if determinant.is_zero() {
        return Ok((determinant, None));
    }
    let _rhs = PreparationTimer::new(compiler.profile_preparation, format_args!("thin N7 RHS assembly {active:?}"));
    let rhs = Matrix::from_nested_vec(
        (0..5)
            .map(|row| {
                (0..5)
                    .map(|column| {
                        if column == 0 {
                            Atom::num(i64::from(row == 4))
                        } else if row == 4 {
                            -&compiler.shifts[origin][column - 1]
                        } else if row == column - 1 {
                            Atom::num(if row == 0 { 1 } else { -1 }) / Atom::num(2)
                        } else {
                            Atom::new()
                        }
                    })
                    .collect()
            })
            .collect(),
        field(),
    )
    .map_err(|error| format!("thin coordinate chart RHS: {error}"))?;
    drop(_rhs);
    let _inverse = PreparationTimer::new(compiler.profile_preparation, format_args!("thin N7 inverse {active:?}"));
    let inverse = matrix
        .inv()
        .map_err(|error| format!("thin coordinate chart inverse: {error:?}"))?;
    drop(_inverse);
    let _product = PreparationTimer::new(compiler.profile_preparation, format_args!("thin N7 inverse times RHS {active:?}"));
    let solutions = &inverse * &rhs;
    drop(_product);
    let _aliases = PreparationTimer::new(compiler.profile_preparation, format_args!("thin N7 weight aliases {active:?}"));
    let weights = std::array::from_fn(|column| {
        let mut weights = vec![Atom::new(); active.len()];
        for (row, &selected) in columns.iter().enumerate() {
            weights[selected + 1] = solutions[(row as u32, column as u32)].clone();
        }
        weights[0] = -Atom::add_many(&weights[1..]);
        weights
            .into_iter()
            .map(|weight| compiler.bind_alias(weight))
            .collect()
    });
    drop(_aliases);
    Ok((determinant, Some(weights)))
}

#[cfg(test)]
mod tests {
    use super::*;

    // Masses make f_i=t_i^5 at the unshifted origin. This is an algebraic
    // geometry fixture, not an asserted physical integration domain.
    fn moment_curve() -> (Vec<[Atom; 4]>, Vec<Atom>) {
        let shifts: Vec<_> = (0_i64..7)
            .map(|t| std::array::from_fn(|mu| Atom::num(t.pow(mu as u32 + 1))))
            .collect();
        let masses = shifts
            .iter()
            .enumerate()
            .map(|(i, p)| dot(p, p) - Atom::num((i as i64).pow(5)))
            .collect();
        (shifts, masses)
    }

    fn assert_integrand_columns(
        shifts: &[[Atom; 4]],
        masses: &[Atom],
        active: &[usize],
        weights: &[Vec<Atom>; 5],
    ) {
        let q: [Atom; 4] = std::array::from_fn(|mu| {
            Atom::var(symbolica::symbol!(format!(
                "thin_seven_geometry_test::q{mu}"
            )))
        });
        let perpendicular = Atom::var(symbolica::symbol!(
            "thin_seven_geometry_test::q_perp_squared"
        ));
        let denominators: Vec<_> = active
            .iter()
            .map(|&line| {
                let shifted = std::array::from_fn(|mu| &q[mu] + &shifts[line][mu]);
                dot(&shifted, &shifted) + &perpendicular - &masses[line]
            })
            .collect();
        for column in 0..5 {
            assert_eq!(weights[column].len(), active.len());
            let actual = Atom::add_many(
                &weights[column]
                    .iter()
                    .zip(&denominators)
                    .map(|(weight, denominator)| weight * denominator)
                    .collect::<Vec<_>>(),
            );
            let expected = if column == 0 {
                Atom::num(1)
            } else {
                q[column - 1].clone()
            };
            assert!(
                (actual - expected).expand().together().is_zero(),
                "column {column}"
            );
        }
    }

    #[test]
    fn thin_seven_geometry_six_chart_order_and_all_five_rhs_identities() {
        let (mut shifts, masses) = moment_curve();
        for point in &mut shifts {
            for (mu, coordinate) in point.iter_mut().enumerate() {
                *coordinate = &*coordinate + Atom::num((mu + 1) as i64) / Atom::num(3);
            }
        }
        let active: Vec<_> = (0..7).rev().collect();
        let mut compiler = PvCompiler::new(shifts.clone(), masses.clone()).unwrap();
        let geometry = compiler.thin_seven_geometry(&active).unwrap();
        assert_eq!(geometry.active, active);
        assert_eq!(
            geometry
                .charts
                .iter()
                .map(|chart| chart.omitted)
                .collect::<Vec<_>>(),
            vec![5, 4, 3, 2, 1, 0]
        );
        for chart in &geometry.charts {
            assert!(!chart.determinant.is_zero());
            assert!(
                chart
                    .weights
                    .iter()
                    .all(|column| column[chart.omitted + 1].is_zero())
            );
            let child = &geometry.six[chart.omitted + 1];
            assert_eq!(chart.determinant, child.determinant);
            for column in 0..5 {
                let embedded: Vec<_> = chart.weights[column]
                    .iter()
                    .enumerate()
                    .filter_map(|(position, weight)| {
                        (position != chart.omitted + 1).then_some(weight.clone())
                    })
                    .collect();
                assert_eq!(embedded, child.weights.as_ref().unwrap()[column]);
            }
            assert_integrand_columns(&shifts, &masses, &active, &chart.weights);
        }
        assert_eq!(geometry.six.len(), 7);
        for (omitted, child) in geometry.six.iter().enumerate() {
            let expected: Vec<_> = active
                .iter()
                .enumerate()
                .filter_map(|(position, &line)| (position != omitted).then_some(line))
                .collect();
            assert_eq!(child.active, expected);
            assert!(!child.determinant.is_zero());
            assert_integrand_columns(
                &shifts,
                &masses,
                &child.active,
                child.weights.as_ref().unwrap(),
            );
        }
    }

    #[test]
    fn thin_seven_geometry_retains_unavailable_six_children() {
        let (mut shifts, mut masses) = moment_curve();
        shifts[6] = shifts[0].clone();
        masses[6] = masses[0].clone();
        let mut compiler = PvCompiler::new(shifts, masses).unwrap();
        let geometry = compiler
            .thin_seven_geometry(&(0..7).collect::<Vec<_>>())
            .unwrap();
        assert_eq!(geometry.charts.len(), 1);
        assert_eq!(geometry.charts[0].omitted, 5);
        for (omitted, child) in geometry.six.iter().enumerate() {
            let regular = omitted == 0 || omitted == 6;
            assert_eq!(child.weights.is_some(), regular);
            assert_eq!(child.determinant.is_zero(), !regular);
        }
    }

    #[test]
    fn thin_seven_geometry_keeps_primal_zero_mixed_direction_weight() {
        let (shifts, masses) = moment_curve();
        let active = [0, 1, 2, 3, 4, 5];
        let mut original = PvCompiler::new(shifts.clone(), masses.clone()).unwrap();
        let original = original
            .thin_six_geometry(&active)
            .unwrap()
            .weights
            .unwrap();
        let c = original[0][0].clone();
        assert!(!c.is_zero());
        let x_symbol = symbolica::symbol!("thin_seven_geometry_test::x");
        let y_symbol = symbolica::symbol!("thin_seven_geometry_test::y");
        let x = Atom::var(x_symbol);
        let y = Atom::var(y_symbol);
        let translation = &original[1][0] / &c + &x * &y;
        let translated: Vec<_> = shifts
            .iter()
            .map(|point| {
                let mut point = point.clone();
                point[0] = &point[0] + &translation;
                point
            })
            .collect();
        let mut compiler = PvCompiler::new(translated, masses).unwrap();
        let weights = compiler
            .thin_six_geometry(&active)
            .unwrap()
            .weights
            .unwrap();
        let weight = &weights[1][0];
        assert!(!weight.is_zero());
        assert!((weight + &x * &y * &c).expand().together().is_zero());
        assert!(
            weight
                .replace(x.clone())
                .with(Atom::new())
                .replace(y.clone())
                .with(Atom::new())
                .is_zero()
        );
        assert!(
            (weight.derivative(x_symbol).derivative(y_symbol) + c)
                .expand()
                .together()
                .is_zero()
        );
    }

    #[test]
    fn thin_seven_geometry_rejects_invalid_or_all_singular_parent() {
        let (shifts, masses) = moment_curve();
        let mut compiler = PvCompiler::new(shifts, masses).unwrap();
        for active in [
            vec![0, 1, 2, 3, 4, 5],
            vec![0, 1, 2, 3, 4, 5, 5],
            vec![0, 1, 2, 3, 4, 5, 7],
        ] {
            assert!(compiler.thin_seven_geometry(&active).is_err());
        }
        let shifts = vec![std::array::from_fn(|_| Atom::new()); 7];
        let mut compiler = PvCompiler::new(shifts, vec![Atom::num(1); 7]).unwrap();
        assert!(
            compiler
                .thin_seven_geometry(&(0..7).collect::<Vec<_>>())
                .is_err()
        );
    }
}
