// Included inside execution::tests. These are private dispatch/accounting
// controls, not additional mathematical integral-validation fixtures.

fn accounting_a0_batch(masses: &[f64]) -> KinematicsBatch<f64> {
    KinematicsBatch {
        rows: masses.len(),
        components: 1,
        values: masses
            .iter()
            .flat_map(|&mass| [0., 0., 0., 0., mass, 1.].map(c))
            .collect(),
    }
}

fn accounting_a0_workspace(reject_primary: bool, allow_profiles: bool) -> Workspace<f64> {
    let mut configuration = plan(1, 0);
    configuration.special_kinematics = !allow_profiles;
    if reject_primary {
        // Preserve the actual A0 dependency but inject a singular output term.
        // All fixture rows have p0_time=0, so the existing numerical guard
        // rejects this primary only after its argument/master work has run.
        configuration.moments[0][3] =
            &configuration.moments[0][3] + Atom::num(1) / &configuration.parameters[0];
    }
    Workspace::new(&configuration, 0.).unwrap()
}

fn accounting_assert_same_lanes(actual: &BatchResult<f64>, expected: &BatchResult<f64>) {
    assert_eq!(actual.metadata(), expected.metadata());
    assert_eq!(actual.basis, expected.basis);
    assert_eq!(actual.components, expected.components);
    assert_eq!(actual.rows(), expected.rows());
    for lane in 0..actual.rows() {
        assert_eq!(actual.statuses[lane], LaneStatus::Success);
        for (&left, &right) in actual
            .lane(lane)
            .unwrap()
            .iter()
            .zip(expected.lane(lane).unwrap())
        {
            close(left, right);
        }
    }
}

#[test]
fn accounting_profile_child_retry_survives_later_parent_retry() {
    let batch = accounting_a0_batch(&[0., 4.]);
    let expected = accounting_a0_workspace(false, false)
        .reduce_batch(&batch)
        .unwrap();

    let mut profile_child = accounting_a0_workspace(true, false);
    profile_child.fallback = Some(Box::new(accounting_a0_workspace(false, false)));
    let mut parent = accounting_a0_workspace(true, true);
    parent.zero_profiles.insert(
        ZeroInvariantProfile {
            masses: vec![true],
            distances: Vec::new(),
        },
        Ok(Box::new(profile_child)),
    );
    parent.fallback = Some(Box::new(accounting_a0_workspace(false, false)));
    parent.set_profiling(true);

    let actual = parent.reduce_batch(&batch).unwrap();
    accounting_assert_same_lanes(&actual, &expected);
    assert_eq!(actual.fallback_used, [true, true]);
    assert_eq!(actual.analytic_used, [true, false]);
    let work = parent.last_execution();
    assert_eq!(work.input_rows, 2);
    // One retry happens inside the zero-mass analytic child, before the
    // nonzero-mass ordinary lane reaches the parent's retry stage.
    assert_eq!(work.fallback_rows, 2);
    assert_eq!(work.fallback_successes, 2);
    assert_eq!(work.analytic_rows, 1);
    assert_eq!(work.argument_rows, 5);
    assert_eq!(work.reduction_rows, 4);
    assert_eq!(work.master_family_batches, 4);
    assert_eq!(work.master_rows, 4);
    let profile = parent.last_profile().unwrap();
    assert!(profile.arguments + profile.scalar_masters + profile.reduction <= profile.total);
}

#[test]
fn accounting_profile_scatter_preserves_prior_fallback_flags_and_work() {
    let batch = accounting_a0_batch(&[2., 4., 9.]);
    let mut initial = accounting_a0_workspace(true, false);
    initial.fallback = Some(Box::new(accounting_a0_workspace(false, false)));
    initial.set_profiling(true);
    let mut result = initial.reduce_batch(&batch).unwrap();
    let before = result.clone();
    assert_eq!(result.fallback_used, [true; 3]);
    let mut work = initial.last_execution();
    let mut profile = initial.last_profile().unwrap();
    let before_total = profile.total;
    let mut diagnostics = initial.last_diagnostics().to_vec();
    let mut child = accounting_a0_workspace(false, false);
    child.set_profiling(true);

    dispatch_profile(
        &mut child,
        &[2, 0],
        &batch,
        &mut result,
        &mut work,
        &mut profile,
        &mut diagnostics,
        None,
        &mut DistanceProofWork::default(),
    )
    .unwrap();

    accounting_assert_same_lanes(&result, &before);
    assert_eq!(result.fallback_used, [true; 3]);
    assert_eq!(result.analytic_used, [true, false, true]);
    assert_eq!(work.input_rows, 3);
    assert_eq!(work.fallback_rows, 3);
    assert_eq!(work.fallback_successes, 3);
    assert_eq!(work.analytic_rows, 2);
    assert_eq!(work.argument_rows, 8);
    assert_eq!(work.reduction_rows, 8);
    assert_eq!(work.master_rows, 8);
    assert_eq!(child.last_execution().input_rows, 2);
    // dispatch_profile adds only child stages. The owning outer call closes
    // its own timer; adding the child's total here would count elapsed time twice.
    assert_eq!(profile.total, before_total);
}

#[test]
fn accounting_profile_error_keeps_completed_master_work_and_attempt_flags() {
    let batch = accounting_a0_batch(&[2., 4., 9.]);
    let mut initial = accounting_a0_workspace(false, false);
    initial.set_profiling(true);
    let mut result = initial.reduce_batch(&batch).unwrap();
    let before = result.clone();
    let mut work = initial.last_execution();
    let mut profile = initial.last_profile().unwrap();
    let before_profile = profile;
    let mut diagnostics = initial.last_diagnostics().to_vec();
    let mut child = accounting_a0_workspace(false, false);
    child.set_profiling(true);
    // A real A0 batch executes first. Symbolica then rejects the deliberately
    // wrong output buffer length at the recurrence evaluator boundary.
    child.reduction_outputs = 0;
    let failure = dispatch_profile(
        &mut child,
        &[2, 0],
        &batch,
        &mut result,
        &mut work,
        &mut profile,
        &mut diagnostics,
        None,
        &mut DistanceProofWork::default(),
    );

    assert!(matches!(failure, Err(ReductionError::Evaluation(_))));
    assert_eq!(result.values, before.values);
    assert_eq!(result.statuses, before.statuses);
    assert_eq!(result.metadata(), before.metadata());
    assert_eq!(result.fallback_used, [false; 3]);
    assert_eq!(result.analytic_used, [true, false, true]);
    assert_eq!(work.input_rows, 3);
    assert_eq!(work.argument_rows, 5);
    assert_eq!(work.master_family_batches, 2);
    assert_eq!(work.master_rows, 5);
    assert_eq!(work.reduction_rows, 5);
    assert_eq!(work.analytic_rows, 2);
    assert_eq!(work.fallback_rows, 0);
    assert_eq!(work.fallback_successes, 0);
    let child_work = child.last_execution();
    assert_eq!(child_work.master_rows, 2);
    assert_eq!(child_work.reduction_rows, 2);
    let child_profile = child.last_profile().unwrap();
    assert_eq!(
        profile.arguments,
        before_profile.arguments + child_profile.arguments
    );
    assert_eq!(
        profile.scalar_masters,
        before_profile.scalar_masters + child_profile.scalar_masters
    );
    assert_eq!(
        profile.reduction,
        before_profile.reduction + child_profile.reduction
    );
    assert_eq!(profile.total, before_profile.total);
    assert!(
        child_profile.arguments + child_profile.scalar_masters + child_profile.reduction
            <= child_profile.total
    );
}

#[test]
fn accounting_parent_retry_error_keeps_child_master_work_and_outer_timing() {
    let batch = accounting_a0_batch(&[2.]);
    let mut child = accounting_a0_workspace(false, false);
    child.reduction_outputs = 0;
    let mut parent = accounting_a0_workspace(true, false);
    parent.fallback = Some(Box::new(child));
    parent.set_profiling(true);

    let failure = parent.reduce_batch(&batch);
    assert!(matches!(failure, Err(ReductionError::Evaluation(_))));
    let work = parent.last_execution();
    assert_eq!(work.input_rows, 1);
    assert_eq!(work.argument_rows, 2);
    assert_eq!(work.master_family_batches, 2);
    assert_eq!(work.master_rows, 2);
    assert_eq!(work.reduction_rows, 2);
    assert_eq!(work.fallback_rows, 1);
    assert_eq!(work.fallback_successes, 0);
    assert_eq!(work.analytic_rows, 0);
    let child = parent.fallback.as_ref().unwrap();
    assert_eq!(child.last_execution().master_rows, 1);
    assert_eq!(child.last_execution().reduction_rows, 1);
    let profile = parent.last_profile().unwrap();
    let child_profile = child.last_profile().unwrap();
    assert!(profile.arguments >= child_profile.arguments);
    assert!(profile.scalar_masters >= child_profile.scalar_masters);
    assert!(profile.reduction >= child_profile.reduction);
    assert!(profile.arguments + profile.scalar_masters + profile.reduction <= profile.total);
}

#[test]
fn accounting_parent_retry_includes_child_analytic_work_and_flags_once() {
    let mut settings = ReductionSettings::new(2, 0);
    settings.convention = Convention::OneLoop;
    settings.algorithm = Algorithm::Hybrid;
    let mut configuration = ReductionPlan::new(settings).unwrap();
    let clean_fallback = configuration.fallback.as_ref().unwrap().clone();
    // This dimensionless fault affects only the fresh primary graph. The
    // original IBP fallback is left intact and still sees a lightlike bubble.
    configuration.moments[0][3] =
        &configuration.moments[0][3] + &configuration.parameters[0] / &configuration.parameters[1];
    let batch = KinematicsBatch {
        rows: 1,
        components: 1,
        values: [0., 0., 0., 0., 1., 1., 0., 0., 4., 9., 1.].map(c).to_vec(),
    };
    let expected = Workspace::new(&clean_fallback, 0.)
        .unwrap()
        .reduce_batch(&batch)
        .unwrap();
    assert_eq!(expected.analytic_used, [true]);
    let mut parent = Workspace::new(&configuration, 0.).unwrap();
    // Keep classification enabled in the child only, so this control reaches
    // the actual parent retry before the exact lightlike analytic dispatch.
    parent.classification_offset = None;
    parent.zero_profile_offset = None;
    parent.zero_profile_plan = None;
    parent.set_profiling(true);
    let actual = parent.reduce_batch(&batch).unwrap();

    accounting_assert_same_lanes(&actual, &expected);
    assert_eq!(actual.fallback_used, [true]);
    assert_eq!(actual.analytic_used, [true]);
    let work = parent.last_execution();
    let child_work = parent.fallback.as_ref().unwrap().last_execution();
    assert_eq!(work.input_rows, 1);
    assert_eq!(work.fallback_rows, 1);
    assert_eq!(work.fallback_successes, 1);
    assert_eq!(work.analytic_rows, 1);
    assert_eq!(child_work.analytic_rows, 1);
    assert_eq!(child_work.argument_rows, 2);
    assert_eq!(work.argument_rows, 3);
    assert_eq!(work.reduction_rows, 2);
    let profile = parent.last_profile().unwrap();
    assert!(profile.arguments + profile.scalar_masters + profile.reduction <= profile.total);
}

#[test]
fn accounting_failed_profile_retry_remains_visible_after_ordinary_rejoin() {
    let batch = accounting_a0_batch(&[4., 0., 9.]);
    let expected = accounting_a0_workspace(false, false)
        .reduce_batch(&batch)
        .unwrap();
    let mut profile_child = accounting_a0_workspace(true, false);
    profile_child.fallback = Some(Box::new(accounting_a0_workspace(true, false)));
    let mut parent = accounting_a0_workspace(false, true);
    parent.zero_profiles.insert(
        ZeroInvariantProfile {
            masses: vec![true],
            distances: Vec::new(),
        },
        Ok(Box::new(profile_child)),
    );
    parent.set_profiling(true);

    let actual = parent.reduce_batch(&batch).unwrap();
    accounting_assert_same_lanes(&actual, &expected);
    // The optional profile and its retry both fail, after which the ordinary
    // graph succeeds. The retry remains an actual attempt in this lane.
    assert_eq!(actual.fallback_used, [false, true, false]);
    // This flag also controls routing: rejoining clears it so that an ordinary
    // failure would remain eligible for the owning workspace's later retry.
    assert_eq!(actual.analytic_used, [false; 3]);
    assert!(parent.last_diagnostics()[1].iter().any(|note| {
        note.contains("exact-zero profile evaluation failed")
            && note.contains("ordinary reduction retained")
    }));
    let work = parent.last_execution();
    assert_eq!(work.input_rows, 3);
    assert_eq!(work.fallback_rows, 1);
    assert_eq!(work.fallback_successes, 0);
    assert_eq!(work.analytic_rows, 1);
    assert_eq!(work.argument_rows, 5);
    assert_eq!(work.reduction_rows, 5);
    assert_eq!(work.master_family_batches, 3);
    assert_eq!(work.master_rows, 5);
    let profile = parent.last_profile().unwrap();
    assert!(profile.arguments + profile.scalar_masters + profile.reduction <= profile.total);
}
