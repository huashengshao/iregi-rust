// Include in execution::proof_receipt_tests after the ten frozen receipt tests.
// These test error accounting, not additional integral accuracy claims.

#[test]
fn receipt_profile_error_harvests_covered_proof_work_before_returning_error() {
    let p = plan();
    let batch = lightlike_batch();
    let mut parent = Workspace::new(&p, 0.).unwrap();
    let expected = parent.reduce_batch(&batch).unwrap();
    let (_, receipt, _) = check(&mut parent, &batch, None);
    let child_plan = ReductionPlan::lightlike_bubble(p.settings.clone(), 0, true).unwrap();
    let mut child = Workspace::new(&child_plan, 0.).unwrap();
    // The argument/proof/master stages genuinely execute before Symbolica
    // rejects this intentionally malformed final result-buffer length.
    child.reduction_outputs = 0;
    let mut result = expected.clone();
    let mut stats = ExecutionStats::default();
    let mut profile = ExecutionProfile::default();
    let mut diagnostics = vec![Vec::new()];
    let mut work = DistanceProofWork::default();
    let failure = dispatch_profile(
        &mut child,
        &[0],
        &batch,
        &mut result,
        &mut stats,
        &mut profile,
        &mut diagnostics,
        Some(&receipt),
        &mut work,
    );
    assert!(matches!(failure, Err(ReductionError::Evaluation(_))));
    assert_eq!(result.values, expected.values);
    assert_eq!(result.statuses, expected.statuses);
    assert_eq!(result.analytic_used, [true]);
    assert_eq!(work, child.proof_work);
    assert_eq!(work.reused_pairs, 1);
    assert_eq!(work.covered_rows, 1);
    assert_eq!(work.certificate_rows, 0);
    assert_eq!(stats.analytic_rows, 1);
    assert!(stats.master_rows > 0);
}

#[test]
fn receipt_fallback_error_harvests_fresh_child_proof_before_returning_error() {
    let mut child_plan = plan();
    // Keep the test on the generic fallback seam rather than profile dispatch.
    child_plan.special_kinematics = true;
    let mut child = Workspace::new(&child_plan, 0.).unwrap();
    child.reduction_outputs = 0;
    let mut parent_plan = child_plan.clone();
    // Genuine parent proof/master work precedes this injected numerical failure.
    parent_plan.moments[0][3] =
        &parent_plan.moments[0][3] + Atom::num(1) / &parent_plan.parameters[0];
    let mut parent = Workspace::new(&parent_plan, 0.).unwrap();
    parent.fallback = Some(Box::new(child));
    let failure = parent.reduce_batch(&lightlike_batch());
    assert!(matches!(failure, Err(ReductionError::Evaluation(_))));
    let child = parent.fallback.as_ref().unwrap();
    assert_eq!(child.proof_work.certificate_rows, 1);
    assert_eq!(child.proof_work.reused_pairs, 0);
    assert_eq!(parent.proof_work.certificate_rows, 2);
    assert_eq!(parent.proof_work.certificate_passes, 2);
    assert_eq!(parent.proof_work.reused_pairs, 0);
    assert_eq!(parent.last_execution().fallback_rows, 1);
    assert_eq!(parent.last_execution().fallback_successes, 0);
    assert!(parent.last_execution().master_rows >= 2);
}
