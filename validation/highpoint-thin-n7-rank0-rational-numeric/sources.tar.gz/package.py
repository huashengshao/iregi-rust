#!/usr/bin/env python3
"""Package saved N7 evidence; standard library only, no candidate execution."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path('/shared/external/iregi/iregi-rust')
SOURCE = ROOT / 'target/public-highpoint/thin-n7-rank0-rational-numeric'
DEST = ROOT / 'validation/highpoint-thin-n7-rank0-rational-numeric'
PARENT = ROOT / 'validation/highpoint-thin-n7-rational-domain'
HISTORY = ROOT / 'validation/highpoint-thin-n7-rank0-attempt'
assert Path.cwd().resolve() == ROOT


def digest(data):
    return hashlib.sha256(data).hexdigest()


def info(path):
    data = path.read_bytes()
    return {'sha256': digest(data), 'bytes': len(data)}


def load(path):
    return json.loads(path.read_text())


def json_bytes(data):
    return (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()


def binding(path):
    return {'path': str(path.relative_to(ROOT)), **info(path)}


assert not DEST.exists(), 'Never overwrite an evidence capsule.'
review_path = SOURCE / 'independent-numerical-review.json'
review = load(review_path)
assert review['status'].lower() in ('pass', 'passed')
protocol = load(SOURCE / 'protocol/protocol.json')
for name, expected in protocol['inputs'].items():
    assert info(ROOT / name)['sha256'] == expected, name
closed = {name: sha for name, sha in protocol['inputs'].items()
          if str(Path(name).parent) in protocol['closed_search_directories']}
assert len(closed) == 118
for directory in protocol['closed_search_directories']:
    actual = {str(p.relative_to(ROOT)) for p in (ROOT / directory).iterdir() if p.is_file()}
    assert actual == {name for name in closed if str(Path(name).parent) == directory}

stages = []
for name in ['build_driver', 'capture128', 'capture256', 'compare']:
    path = SOURCE / f'runs/{name}-001/run.json'
    record = load(path)
    assert record['status'] == 'passed' and record['inputs_unchanged']
    assert not record.get('total_bound_exceeded', False) and not record['missing_outputs']
    assert record['elapsed_seconds_including_postguards'] <= record['bound_seconds']
    assert all(s['passed'] and s['exit_code'] == 0 and not s['timeout']
               and not s['cleanup_errors'] and s['within_bound'] for s in record['stages'])
    for output, expected in record['outputs'].items():
        assert info(ROOT / output)['sha256'] == expected, output
    stages.append({'stage': name, 'receipt': binding(path), 'status': record['status'],
                   'seconds_before_postguards': record['elapsed_seconds'],
                   'seconds_including_postguards': record['elapsed_seconds_including_postguards'],
                   'bound_seconds': record['bound_seconds'],
                   'inputs_unchanged': record['inputs_unchanged'],
                   'subprocesses': [{k: s[k] for k in ['name', 'pid', 'exit_code', 'timeout',
                        'cleanup_errors', 'elapsed_seconds', 'within_bound']} for s in record['stages']]})

comparison = load(SOURCE / 'runs/compare-001/comparison.json')
assert comparison['status'] == 'passed_stable_original_and_precision_only'
assert comparison['stable_original_modes_all_slots_agree']
assert comparison['precision_convergence']['passed']
assert not comparison['independent_scalar_oracle_qualified']
captures = {bits: load(SOURCE / f'runs/capture{bits}-001/result.json') for bits in [128, 256]}
scope = ('One private ordinary N7 rank-zero lane, Float128 and Float256/request53, '
         'all four native complex Laurent slots, unchanged fixed dyadic fixture. '
         'Agreement with stable original IBP/Hybrid at1e-10 and precision convergence '
         'at2^-80 only; no independent scalar-oracle, higher-rank, Dual, batching, '
         'general-domain, performance or production qualification.')
parents = {}
for name in ['highpoint-thin-n7-exact', 'highpoint-thin-n7-rank0-attempt',
             'highpoint-thin-n7-phase-attribution', 'highpoint-thin-n7-rational-domain']:
    path = ROOT / 'validation' / name / 'manifest.json'
    parents[str(path.relative_to(ROOT))] = info(path)

qualification = {
    'schema_version': 1, 'status': 'private_rank0_stable_original_and_precision_pass',
    'scope': scope, 'production_adopted': False,
    'protocol': binding(SOURCE / 'protocol/protocol.json'),
    'source_review': binding(SOURCE / 'protocol/independent-review.json'),
    'independent_saved_data_review': binding(review_path),
    'comparison': binding(SOURCE / 'runs/compare-001/comparison.json'),
    'parent_source_qualification': binding(PARENT / 'qualification.json'),
    'stages': stages, 'fixture': binding(SOURCE / 'fixture.json'),
    'settings': captures[128]['settings'], 'requested_accuracy_bits': 53,
    'working_precisions': [128, 256], 'components': 1, 'lanes_per_capture': 1,
    'native_slots': ['uv1', 'ir1', 'ir2', 'finite'],
    'stable_reference_slot_comparisons': 16,
    'unstable_original_pv_diagnostic_slot_comparisons': 8,
    'precision_slot_comparisons': 4,
    'reference_tolerance': comparison['reference_tolerance'],
    'natural_scale': comparison['natural_scale'],
    'reference_comparisons': comparison['reference_comparisons'],
    'precision_convergence': comparison['precision_convergence'],
    'exact_zero_poles_each_capture': 3,
    'results': {str(bits): {
        'result': binding(SOURCE / f'runs/capture{bits}-001/result.json'),
        'metadata': captures[bits]['metadata'], 'lane_statuses': captures[bits]['lane_statuses'],
        'basis': captures[bits]['basis'], 'native_lanes': captures[bits]['lanes'],
        'execution': captures[bits]['execution'],
        'diagnostic_seconds': {k: captures[bits][k] for k in ['diagnostic_plan_seconds',
                'diagnostic_workspace_seconds', 'diagnostic_reduction_seconds', 'elapsed_seconds']}
    } for bits in [128, 256]},
    'domain': {'all_seven_six_systems_regular': True,
               'all_twenty_one_children_mandatory_supported': True,
               'positive_F_lower_bound': '15/16', 'normalization_q_squared': '4',
               'full_symbolic_preparation_each_precision': True,
               'numerical_specialization_or_pruning': False,
               'guard_policy_changed': False},
    'retained_limitations': {
        'original_pv': 'Unstable all-zero reference; retained diagnostically, never counted as agreement.',
        'independent_scalar_oracle': 'Prior fixed six-rule oracle remains inconclusive; not rerun or promoted.',
        'prior_failures': 'Original300s capture and marker-only constructor timeout remain immutable.',
        'precision': 'Working precision is not an achieved-bit guarantee; unchanged requested53 and full-complex-slot convergence gate apply. The tiny finite real residual reports relative precision2 at both working precisions; no component-wise achieved-bit claim is made.',
        'performance': 'All elapsed values are diagnostic, not a full-call benchmark or optimized speedup.'},
    'dependency_profile': 'Frozen historical numerical dependencies opt2/debug2 native objects; private core and driver opt0/debug0.',
    'parent_manifests': parents,
}

# Archive core bytes from the already qualified durable parent, not live sources.
parent_manifest = load(PARENT / 'manifest.json')
assert info(PARENT / 'sources.tar.gz')['sha256'] == parent_manifest['archive']['sha256']
members = {}
member_origins = {}
with tarfile.open(PARENT / 'sources.tar.gz', 'r:gz') as archive:
    for entry in archive.getmembers():
        if entry.name.startswith('core/'):
            assert entry.isfile()
            data = archive.extractfile(entry).read()
            assert digest(data) == parent_manifest['archive_members'][entry.name]['sha256']
            members[entry.name] = data
            member_origins[entry.name] = {'origin_archive': str((PARENT / 'sources.tar.gz').relative_to(ROOT)),
                                          'origin_member': entry.name}
assert len(members) == 40
source_files = [SOURCE / name for name in ['driver.rs', 'domain.rs', 'fixture.json',
                'driver.patch', 'source.json', 'README.md', 'compare.py', 'package.py',
                'independent-reconstruct.py']]
source_files += sorted(p for p in (SOURCE / 'protocol').rglob('*') if p.is_file())
for path in source_files:
    assert path.suffix in ['.rs', '.json', '.py', '.patch', '.md']
    name = str(path.relative_to(SOURCE))
    assert name not in members
    members[name] = path.read_bytes()
    member_origins[name] = {'origin': str(path.relative_to(ROOT))}


def archive_bytes():
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as tar:
        for name, data in sorted(members.items()):
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            entry.uid = entry.gid = entry.mtime = 0
            entry.uname = entry.gname = ''
            tar.addfile(entry, io.BytesIO(data))
    result = io.BytesIO()
    with gzip.GzipFile(fileobj=result, mode='wb', filename='', mtime=0, compresslevel=9) as stream:
        stream.write(raw.getvalue())
    return result.getvalue()


archive = archive_bytes()
assert archive == archive_bytes()
payloads = {}
origins = {'payloads': {}, 'archive_members': member_origins}


def add(relative, path):
    assert relative not in payloads
    payloads[relative] = path.read_bytes()
    origins['payloads'][relative] = {'origin': str(path.relative_to(ROOT)), **info(path)}


for name in ['independent-numerical-review.json', 'build-completion.json',
             'root-128-preflight.json', 'root-numerical-release.json']:
    add(name, SOURCE / name)
for path in sorted((SOURCE / 'protocol').rglob('*')):
    if path.is_file():
        add(str(path.relative_to(SOURCE)), path)
for stage in ['build_driver', 'capture128', 'capture256', 'compare']:
    for path in sorted((SOURCE / f'runs/{stage}-001').iterdir()):
        if path.suffix in ['.json', '.log']:
            add(f'{stage}-001/{path.name}', path)
for path in sorted((HISTORY / 'api2/reference-002').iterdir()):
    if path.suffix in ['.json', '.log']:
        add(f'original-reference/{path.name}', path)
for mode in range(3):
    add(f'original-reference/request-mode{mode}.txt', ROOT /
        f'target/public-highpoint/thin-n7-rank0-api2/protocol/reference-mode{mode}.txt')
for name in ['highpoint-thin-n7-exact', 'highpoint-thin-n7-rank0-attempt',
             'highpoint-thin-n7-phase-attribution', 'highpoint-thin-n7-rational-domain']:
    add(f'history/{name}-qualification.json', ROOT / 'validation' / name / 'qualification.json')
payloads['qualification.json'] = json_bytes(qualification)
payloads['sources.tar.gz'] = archive
payloads['payload-origins.json'] = json_bytes(origins)
payloads['protocol-input-bindings.json'] = json_bytes({
    'protocol': binding(SOURCE / 'protocol/protocol.json'),
    'input_count': len(protocol['inputs']), 'inputs': protocol['inputs'],
    'closed_artifact_count': len(closed), 'closed_artifacts': closed,
    'closed_search_directories': protocol['closed_search_directories'],
    'dependency_profile': qualification['dependency_profile'],
    'omitted_payloads': 'No binaries, rlibs, dependency objects, caches or credentials; hashes retained.'})
payloads['artifact-bindings.json'] = json_bytes({
    'scope': 'Hash-only build artifacts, not included in capsule.',
    'accepted_core': binding(ROOT / load(SOURCE / 'source.json')['accepted_core']),
    'numerical_driver': binding(SOURCE / 'runs/build_driver-001/driver'),
    'closure_count': len(closed), 'closure': closed})
payloads['README.md'] = b'''# Private N7 rank-zero numerical qualification

**One fixed ordinary N7 rank-zero lane passed stable-original agreement and two-precision convergence. This is a private qualification, not production adoption or general N7 acceptance.** Both Float128 and Float256 captures requested53 accuracy and returned all four complex native Laurent slots. Each independently prepared the generic symbolic plan and used the same retained dyadic fixture; no numerical substitution, discarded child, imported reference scalar or relaxed guard was introduced.

All16 slot comparisons against the untouched stable original IREGI IBP and Hybrid results passed the unchanged normalized1e-10 gate. The maximum error is approximately4.782044e-12. The three pole coefficients are exactly zero in each capture. All four128/256 comparisons passed2^-80; the maximum normalized difference is approximately9.102e-34. Original PV returned an unstable all-zero result and remains a diagnostic failure, not an agreement. The earlier fixed six-rule scalar oracle remains inconclusive at its original uncertainty gate; it is neither rerun nor promoted by this result.

Scope is unit powers, dimension shift zero, preserved shifts, FromShifts invariants, PV routing, IregiNative convention and component weights. All seven six-line systems and all21 coalesced mandatory N5 children pass the retained necessary geometric checks; F>=15/16 and Q^2=4. Every numerical guard remains active. One child batch evaluates21 rows/105 master rows at each precision. This does not qualify higher ranks, Dual inputs, multiple parent lanes, other kinematic domains or performance. Working precision is not a claim of achieved bits.

Complete capture stages including postguards took153.623358646s and164.176475480s, both within the fixed300s cap. Earlier elapsed fields151.802825308s and162.437978211s end before postguards. All timings are diagnostic only; numerical dependencies retain their historical opt2/debug2 native-object profile and the private core/driver use opt0/debug0.

The independent saved-data audit reconstructs the complex differences from raw rational outputs and original decimal logs using only the Python standard library, without importing the producer comparator. The capsule retains both raw captures, complete native arrays, all stage and terminal receipts, immutable ROOT grants, ROOT first-capture preflight/release, original three-mode logs and exact requests, source review, protocol and closure hashes. The deterministic source archive contains40 accepted core files plus the numerical driver, unchanged domain/fixture, one-line precision-admission patch, original protocol/runners/grants, independent audit script and packager. Binaries, rlibs, dependencies, credentials and caches are excluded; their hashes are retained.

The original300s capture failure, marker-only constructor timeout and old inconclusive oracle are linked through immutable parent manifests and copied historical qualifications. The parent rational-polynomial22-test/constructor capsule remains separate; its ignored constructor-variant test remains UNRUN. Original source/protocol snapshots may say awaiting execution: they are intentionally unchanged, while qualification.json and the actual receipts record the completed outcome.

Manifest hashes bind all payloads and archive members, excluding the manifest itself. The source archive uses sorted regular USTAR entries, fixed mode/ownership/time and deterministic gzip metadata. Reproduction of numerical execution requires the matched closure or a separately qualified rebuild; package creation runs no candidate or numerical workload.
'''
DEST.mkdir()
for name, data in sorted(payloads.items()):
    path = DEST / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
manifest = {'schema_version': 1, 'status': qualification['status'], 'scope': scope,
    'files': {name: {'sha256': digest(data), 'bytes': len(data)} for name, data in sorted(payloads.items())},
    'archive': {'path': 'sources.tar.gz', 'sha256': digest(archive), 'bytes': len(archive),
                'members': len(members), 'core_source_files': 40,
                'format': 'Sorted USTAR regular files; mode0644; uid=gid=mtime0; empty names; gzip level9 mtime0 empty filename',
                'repeated_serialization_byte_identical': True},
    'archive_members': {name: {'sha256': digest(data), 'bytes': len(data)} for name, data in sorted(members.items())},
    'parent_manifests': parents}
(DEST / 'manifest.json').write_bytes(json_bytes(manifest))
print(json.dumps({'path': str(DEST.relative_to(ROOT)), 'payload_count': len(payloads),
    'archive_members': len(members), 'manifest': info(DEST / 'manifest.json'),
    'qualification': info(DEST / 'qualification.json'), 'archive': info(DEST / 'sources.tar.gz')}, indent=2))
