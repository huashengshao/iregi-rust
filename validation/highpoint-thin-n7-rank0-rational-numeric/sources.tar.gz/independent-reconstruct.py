#!/usr/bin/env python3
"""Read saved evidence only; exact rational gates, no producer imports/processes.

Run from the project root with Python 3's standard library. This script neither
loads Symbolica nor evaluates an integral. It writes one new review receipt.
"""
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import json
from pathlib import Path

ROOT = Path('/shared/external/iregi/iregi-rust')
HERE = Path(__file__).absolute().parent
EXPECTED_PROTOCOL = 'f5ea7bc86befd8cb43ac145093d8535ddd9c732b7984d028957bc4883ccb5d1e'
EXPECTED_REVIEW = 'f779fa28afc1757f8379e56852428382499e4348d72021ce4ab91767fa3a69fb'
EXPECTED_RECEIPTS = {
    'build_driver': 'b2383779a1232d210eaa4b96c97691dd340bb5870daeda5084e160c100435018',
    'capture128': '4fad91c9f3684ea15fb756a47641149dbf06c83255955683c403b2771b4dd076',
    'capture256': '6cf18d98ff560918c2df5109aa94a635f03ca176398ea1062a6e16feefe1f954',
    'compare': '4fc26775a9c334814bd67cfa79136e4b2162d3ee3804b2c9a42fb06b3f269f74',
}
CHECKED = {}


def digest(path):
    path = ROOT / path
    if str(path) not in CHECKED:
        with path.open('rb') as stream:
            CHECKED[str(path)] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return CHECKED[str(path)]


def bound(path, expected):
    actual = digest(path)
    assert actual == expected, (str(path), expected, actual)
    return actual


def read(path):
    path = ROOT / path
    digest(path)
    return json.loads(path.read_text())


def hash_map(mapping):
    for path, expected in mapping.items():
        bound(path, expected)


def now():
    return datetime.now(timezone.utc).isoformat()


def date(text):
    return datetime.fromisoformat(text)


def successful_step(step):
    assert step['passed'] is True and step['exit_code'] == 0
    assert step['timeout'] is False and step['cleanup_errors'] == []
    assert step.get('interrupted', False) is False and 'error' not in step
    assert step['within_bound'] is True
    assert 0 <= step['elapsed_seconds'] <= step['bound_seconds']
    assert date(step['started_utc']) <= date(step['finished_utc'])


def successful_receipt(receipt):
    assert receipt['status'] == 'passed' and receipt['inputs_unchanged'] is True
    assert receipt['missing_outputs'] == []
    assert receipt.get('total_bound_exceeded', False) is False
    assert 0 <= receipt['elapsed_seconds'] <= receipt['elapsed_seconds_including_postguards'] <= receipt['bound_seconds']
    assert not any(key.endswith('_error') for key in receipt)
    for step in receipt['stages']:
        successful_step(step)


def norm_squared(pair):
    return sum(part * part for part in pair)


def relative_error_squared(actual, expected):
    return norm_squared(tuple(a - b for a, b in zip(actual, expected))) / max(Fraction(1, 1024**2), norm_squared(expected))


def decimal_sqrt(value):
    with localcontext() as context:
        context.prec = 150
        return (Decimal(value.numerator) / Decimal(value.denominator)).sqrt()


def agrees_with_printed(value, printed):
    # Exact gate decisions do not use this presentation-only tolerance. The
    # producer converted operands at 100 decimal digits before subtracting.
    with localcontext() as context:
        context.prec = 150
        expected = decimal_sqrt(value)
        actual = Decimal(printed)
        assert actual.is_finite()
        assert abs(actual - expected) <= max(Decimal('1e-120'), abs(expected) * Decimal('1e-60'))


def main():
    assert Path.cwd() == ROOT
    output = HERE / 'independent-numerical-review.json'
    assert not output.exists(), 'Preserve an existing review; do not overwrite it.'
    protocol_path = HERE / 'protocol/protocol.json'
    review_path = HERE / 'protocol/independent-review.json'
    bound(protocol_path, EXPECTED_PROTOCOL)
    bound(review_path, EXPECTED_REVIEW)
    protocol = read(protocol_path)
    review = read(review_path)
    assert review['status'] == 'source_review_passed' and review['protocol_sha256'] == EXPECTED_PROTOCOL
    assert len(protocol['inputs']) == 315
    hash_map(protocol['inputs'])
    closure = {}
    for directory in protocol['closed_search_directories']:
        actual = {str(p.relative_to(ROOT)) for p in (ROOT / directory).iterdir() if p.is_file()}
        expected = {p for p in protocol['inputs'] if str(Path(p).parent) == directory}
        assert actual == expected
        closure[directory] = len(actual)
    assert sum(closure.values()) == 118
    assert sum('/thin-n7-rational-domain/core/' in p for p in protocol['inputs']) == 40

    receipts, grants, stage_summary = {}, {}, {}
    for stage in protocol['stages']:
        spec = protocol['stage_specs'][stage]
        grant_path = HERE / f'protocol/grants/{stage}.json'
        receipt_path = HERE / f'runs/{stage}-001/run.json'
        grant, receipt = read(grant_path), read(receipt_path)
        bound(receipt_path, EXPECTED_RECEIPTS[stage])
        assert grant['status'] == 'root_execution_granted'
        assert grant['protocol_sha256'] == EXPECTED_PROTOCOL and grant['review_sha256'] == EXPECTED_REVIEW
        assert grant['stages'] == [stage] and grant['cpu'] == '6'
        assert grant['bound_seconds'] == spec['bound_seconds']
        assert grant['postguard_reserve_seconds'] == spec['postguard_reserve_seconds']
        assert grant['child_bound_seconds'] == spec['commands'][0]['bound_seconds']
        assert date(grant['created_utc']) <= date(receipt['started_utc'])
        expected_inputs = {str(ROOT / key): value for key, value in protocol['inputs'].items()}
        expected_inputs.update({str(protocol_path): digest(protocol_path), str(review_path): digest(review_path), str(grant_path): digest(grant_path)})
        assert set(grant['required_receipts']) == set(spec['requires'])
        for parent in spec['requires']:
            previous = receipts[parent]
            parent_path = HERE / f'runs/{parent}-001/run.json'
            bound(parent_path, grant['required_receipts'][parent])
            additions = dict(previous['inputs'])
            additions.update({str(ROOT / key): value for key, value in previous['outputs'].items()})
            additions[str(parent_path)] = digest(parent_path)
            for key, value in additions.items():
                assert key not in expected_inputs or expected_inputs[key] == value
                expected_inputs[key] = value
        assert receipt['inputs'] == expected_inputs
        assert receipt['stage'] == stage and receipt['bound_seconds'] == spec['bound_seconds']
        successful_receipt(receipt)
        hash_map(receipt['inputs'])
        hash_map(receipt['outputs'])
        assert set(receipt['outputs']) == set(spec['outputs'])
        assert len(receipt['stages']) == len(spec['commands']) == 1
        step, command = receipt['stages'][0], spec['commands'][0]
        assert step['name'] == command['name'] and step['command'] == command['command']
        assert 2 < step['bound_seconds'] <= command['bound_seconds']
        terminal_path = HERE / f'runs/{stage}-001' / Path(command['log']).with_suffix('.terminal.json')
        terminal = read(terminal_path)
        for key, value in terminal.items():
            assert step[key] == value, (stage, key)
        assert terminal['exit_code'] == 0 and terminal['timeout'] is False and terminal['cleanup_errors'] == []
        assert date(step['started_utc']) <= date(step['observed_terminal_utc']) <= date(step['finished_utc']) <= date(receipt['finished_utc'])
        assert receipt['retained_log_hashes'] == {command['log']: digest(HERE / f'runs/{stage}-001' / command['log'])}
        receipts[stage], grants[stage] = receipt, grant
        stage_summary[stage] = {'receipt_sha256': digest(receipt_path), 'grant_sha256': digest(grant_path), 'input_count': len(expected_inputs), 'pid': step['pid'], 'process_seconds': step['elapsed_seconds'], 'total_seconds': receipt['elapsed_seconds_including_postguards'], 'cap_seconds': spec['bound_seconds'], 'terminal_and_cleanup_passed': True}

    build_completion = read(HERE / 'build-completion.json')
    assert build_completion['status'] == 'compile_only_passed'
    assert build_completion['receipt_sha256'] == EXPECTED_RECEIPTS['build_driver']
    assert build_completion['outputs'] == receipts['build_driver']['outputs']
    preflight = read(HERE / 'root-128-preflight.json')
    bound(HERE / 'root-128-preflight.json', grants['capture256']['root_preflight_sha256'])
    assert preflight['status'] == 'PASS' and preflight['owned_group_gone'] is True
    assert preflight['capture_receipt_sha256'] == grants['capture256']['prior_capture_receipt_sha256'] == EXPECTED_RECEIPTS['capture128']
    bound(HERE / 'runs/capture128-001/result.json', preflight['result_sha256'])
    release = read(HERE / 'root-numerical-release.json')
    bound(HERE / 'root-numerical-release.json', grants['compare']['root_lease_release_sha256'])
    assert release['all_absent'] is True
    assert release['receipts'] == {key: EXPECTED_RECEIPTS[key] for key in ['build_driver', 'capture128', 'capture256']}
    assert release['owned_groups'] == [receipts[key]['stages'][0]['pid'] for key in ['build_driver', 'capture128', 'capture256']]
    lease = grants['capture128']['numerical_release']
    bound(lease['path'], lease['sha256'])

    fixture = read(HERE / 'fixture.json')
    sample = fixture['samples'][0]
    historical = ROOT / 'target/public-highpoint/thin-n7-rank0-api2'
    old_capsule = ROOT / 'validation/highpoint-thin-n7-rank0-attempt'
    reference_dir = old_capsule / 'api2/reference-002'
    reference = read(reference_dir / 'run.json')
    successful_receipt(reference)
    assert len(reference['stages']) == 3
    assert reference['inputs'][str(historical / 'fixture.json')] == digest(HERE / 'fixture.json')
    historical_protocol = read(historical / 'protocol/protocol.json')
    assert reference['inputs'][str(historical / 'protocol/protocol.json')] == digest(historical / 'protocol/protocol.json')
    originals, original_values = [], {}
    for mode in range(3):
        request_path = historical / f'protocol/reference-mode{mode}.txt'
        bound(request_path, reference['inputs'][str(request_path)])
        lines = request_path.read_text().splitlines()
        assert len(lines) == 9 and lines[-1] == 'QUIT'
        header = lines[0].split()
        assert header[:7] == ['EVAL', f'n7_rank0_mode{mode}', 'tensor', str(mode), '7', '0', '0']
        assert len(header) == 10 and Fraction(header[7]) == Fraction(sample['mu']) and header[8:] == ['0', '1e-6']
        for line, prop in zip(lines[1:8], sample['propagators']):
            parts = line.split()
            assert len(parts) == 7 and Fraction(parts[6]) == prop['power'] == 1
            assert list(map(Fraction, parts[:4])) == list(map(Fraction, prop['shift']))
            assert list(map(Fraction, parts[4:6])) == list(map(Fraction, prop['mass_squared']))
        step = reference['stages'][mode]
        assert step['name'] == f'original_mode{mode}'
        assert step['command'] == historical_protocol['stage_specs']['reference']['commands'][mode]['command']
        log_path = reference_dir / f'mode{mode}.log'
        bound(log_path, reference['outputs'][str((historical / f'runs/reference-002/mode{mode}.log').relative_to(ROOT))])
        bound(log_path, reference['retained_log_hashes'][f'mode{mode}.log'])
        entries = [json.loads(line[7:], parse_float=str) for line in log_path.read_text().splitlines() if line.startswith('RESULT ')]
        assert len(entries) == 1
        entry = entries[0]
        assert entry['id'] == f'n7_rank0_mode{mode}' and entry['stable'] is (mode != 1)
        assert entry['poles'] == ['uv1', 'ir1', 'ir2', 'finite']
        assert len(entry['moments']) == 1 and len(entry['moments'][0]) == 4
        assert all(len(pair) == 2 for pair in entry['moments'][0])
        original_values[mode] = [tuple(map(Fraction, pair)) for pair in entry['moments'][0]]
        originals.append(entry)

    expected_input = [[str(Fraction(v)), '0'] for prop in sample['propagators'] for v in prop['shift']]
    expected_input += [[str(Fraction(v)) for v in prop['mass_squared']] for prop in sample['propagators']]
    expected_input += [[str(Fraction(sample['mu'])), '0']]
    old_domain_path = old_capsule / 'api2/domain-002/domain.json'
    old_manifest = read(old_capsule / 'manifest.json')
    bound(old_capsule / 'manifest.json', '2a50ce92d032aec631be983b754a828b28015a0715c22da8b68f217a15ccdb24')
    bound(old_domain_path, old_manifest['files']['api2/domain-002/domain.json']['sha256'])
    old_domain = read(old_domain_path)['audit']
    values, captures, capture_summary = {}, {}, {}
    for bits in [128, 256]:
        value = read(HERE / f'runs/capture{bits}-001/result.json')
        assert value['status'] == 'all_lanes_success' and value['lane_statuses'] == ['Success']
        assert value['working_bits'] == bits and value['requested_bits'] == 53
        assert value['rows'] == value['components'] == 1 and value['basis'] == [[0, 0, 0, 0]]
        assert value['settings'] == {'propagators': 7, 'rank': 0, 'powers': [1] * 7, 'dimension_shift': 0, 'algorithm': 'PassarinoVeltman', 'convention': 'IregiNative', 'tensor_weights': 'Components', 'invariants': 'FromShifts', 'input_policy': 'Preserve'}
        assert value['metadata'] == {'convention': 'IregiNative', 'tensor_weights': 'Components', 'dual_shape': None}
        assert value['input_exact_rational'] == [expected_input]
        assert value['domain_audit'] == old_domain
        assert value['domain_audit']['domain_accepted'] is True
        assert value['fallback_used'] == value['analytic_used'] == [False] and value['diagnostics'] == [[]]
        assert value['alias_count'] == 259
        assert len(value['lanes']) == 1 and value['lanes'][0]['row'] == 0 and value['lanes'][0]['status'] == 'Success'
        assert len(value['lanes'][0]['moments']) == 1 and len(value['lanes'][0]['moments'][0]) == 4
        values[bits] = [(Fraction(slot['real']), Fraction(slot['imaginary'])) for slot in value['lanes'][0]['moments'][0]]
        assert all(pair == (0, 0) for pair in values[bits][:3])
        stats = value['execution']
        assert {key: stats[key] for key in ['child_batch_calls', 'packed_child_rows', 'parent_batch_calls', 'packed_parent_rows', 'parent_input_rows']} == {'child_batch_calls': 1, 'packed_child_rows': 21, 'parent_batch_calls': 1, 'packed_parent_rows': 1, 'parent_input_rows': 1}
        assert 'master_rows: 105' in stats['child_execution'] and 'master_rows: 0' in stats['parent_execution']
        log = (HERE / f'runs/capture{bits}-001/capture.log').read_text()
        assert log.count('reducing 1 lanes') == 1 and 'public high point complete' in log and log.rstrip().endswith('[Success]')
        assert log.count('PV prepare begin ') == log.count('PV prepare end ') == 62
        captures[bits] = value
        capture_summary[bits] = {'finite_exact': list(map(str, values[bits][3])), 'slot_precisions': [[slot['real_precision'], slot['imaginary_precision']] for slot in value['lanes'][0]['moments'][0]], 'all_three_poles_exact_zero': True, 'domain_matches_prior_saved_audit': True, 'diagnostic_plan_seconds': value['diagnostic_plan_seconds'], 'diagnostic_workspace_seconds': value['diagnostic_workspace_seconds'], 'diagnostic_reduction_seconds': value['diagnostic_reduction_seconds'], 'execution': stats, 'complete_phase_markers': 62}

    comparison = read(HERE / 'runs/compare-001/comparison.json')
    bound(HERE / 'runs/compare-001/comparison.json', '9821c3ca6c6bca639edd5ae6bc84487042b72f4263077f457c0545433a165d35')
    hash_map(comparison['inputs'])
    assert comparison['status'] == 'passed_stable_original_and_precision_only'
    assert comparison['original_modes'] == originals
    assert comparison['independent_scalar_oracle_qualified'] is False
    assert 'inconclusive' in comparison['previous_fixed_scalar_oracle']
    assert Fraction(comparison['natural_scale']) == Fraction(1, 1024)
    assert Fraction(comparison['reference_tolerance']) == Fraction(1, 10**10)
    assert len(comparison['reference_comparisons']) == 6
    reconstructed = []
    reference_squared = {}
    for bits in [128, 256]:
        for mode in range(3):
            squares = [relative_error_squared(a, r) for a, r in zip(values[bits], original_values[mode])]
            reference_squared[bits, mode] = squares
            expected_pass = mode in [0, 2] and all(square <= Fraction(1, 10**20) for square in squares)
            assert expected_pass is (mode != 1)
            stored = next(item for item in comparison['reference_comparisons'] if item['working_bits'] == bits and item['mode'] == mode)
            assert stored['stable'] is (mode != 1) and stored['qualified_agreement'] is expected_pass
            assert len(stored['normalized_errors']) == 4
            for square, printed in zip(squares, stored['normalized_errors']):
                agrees_with_printed(square, printed)
            assert all(Fraction(v) == 0 for v in stored['native_pole_residues'] + stored['original_pole_residues'])
            reconstructed.append({'working_bits': bits, 'mode': mode, 'stable': mode != 1, 'normalized_errors': [str(decimal_sqrt(square)) for square in squares], 'exact_squared_threshold_passed': expected_pass})
    assert len(preflight['checks']) == 8
    for item in preflight['checks']:
        assert item['mode'] in [0, 2] and item['slot'] in range(4) and item['passed'] is True
        agrees_with_printed(reference_squared[128, item['mode']][item['slot']], item['normalized_error'])
    assert {(c['mode'], c['slot']) for c in preflight['checks']} == {(m, s) for m in [0, 2] for s in range(4)}
    convergence = [relative_error_squared(low, high) for low, high in zip(values[128], values[256])]
    assert all(square <= Fraction(1, 2**160) for square in convergence)
    assert comparison['precision_convergence']['passed'] is True
    assert Fraction(comparison['precision_convergence']['tolerance']) == Fraction(1, 2**80)
    for square, printed in zip(convergence, comparison['precision_convergence']['normalized_errors']):
        agrees_with_printed(square, printed)
    assert comparison['stable_original_modes_all_slots_agree'] is True

    oracle_path = old_capsule / 'api2/oracle-002/oracle.json'
    bound(oracle_path, old_manifest['files']['api2/oracle-002/oracle.json']['sha256'])
    oracle = read(oracle_path)
    assert oracle['status'] == 'insufficient_convergence' and len(oracle['runs']) == 6
    assert {(r['order'], r['mapping']) for r in oracle['runs']} == {(o, m) for o in [8, 12, 16] for m in [0, 1]}
    assert all(r['status'] == 'completed' for r in oracle['runs'])

    # Read /proc only. Do not send even signal 0 to any process.
    owned = {receipts[key]['stages'][0]['pid'] for key in receipts}
    historical_groups = {step['pid'] for step in reference['stages']}
    additional = set(lease['independently_absent_groups'])
    checked_groups = owned | historical_groups | additional
    members = {group: [] for group in sorted(checked_groups)}
    unreadable = []
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit():
            continue
        try:
            text = (directory / 'stat').read_text()
            rest = text[text.rfind(')') + 2:].split()
            pgid = int(rest[2])
            if pgid in members:
                members[pgid].append(int(directory.name))
        except FileNotFoundError:
            continue
        except PermissionError:
            unreadable.append(int(directory.name))
    assert not unreadable, unreadable
    assert all(not group_members for group_members in members.values()), members
    for pid in checked_groups:
        assert not (Path('/proc') / str(pid)).exists(), ('reused or remaining leader PID', pid)

    source = read(HERE / 'source.json')
    for entry in source['files'].values():
        bound(entry['origin'], entry['origin_sha256'])
        bound(entry['candidate'], entry['candidate_sha256'])
    source_driver = ROOT / source['files']['driver.rs']['origin']
    assert (HERE / 'driver.rs').read_text() == source_driver.read_text().replace('|| working_bits != 128', '|| !matches!(working_bits, 128 | 256)')
    for name in ['domain.rs', 'fixture.json']:
        assert (HERE / name).read_bytes() == (ROOT / source['files'][name]['origin']).read_bytes()
    digest(Path(__file__).absolute())
    report = {
        'schema_version': 1,
        'status': 'passed',
        'review_kind': 'independent_saved_numerical_and_provenance_review',
        'reviewer': '/root/numeric_batch_audit/masters_review',
        'recorded_utc': now(),
        'scope': 'Saved-data-only independent reconstruction for one fixed private N7 rank0 ordinary lane, all four native complex Laurent slots, Float128/Float256 and requested53. No producer imports, numerical kernels, builds, tests, new integral evaluations or source mutations.',
        'protocol_sha256': EXPECTED_PROTOCOL,
        'source_review_sha256': EXPECTED_REVIEW,
        'script': str(Path(__file__).absolute().relative_to(ROOT)),
        'script_sha256': digest(Path(__file__).absolute()),
        'findings': [],
        'provenance': {'protocol_inputs': 315, 'accepted_core_source_files': 40, 'closed_artifacts': closure, 'unique_current_files_hashed': len(CHECKED), 'all_hashes_match': True, 'all_receipt_input_sets_reconstructed_exactly': True, 'current_hashes': dict(sorted(CHECKED.items()))},
        'stages': stage_summary,
        'root_preflight_and_release': {'preflight_sha256': digest(HERE / 'root-128-preflight.json'), 'release_sha256': digest(HERE / 'root-numerical-release.json'), 'all_eight_preflight_comparisons_reconstructed': True, 'stage_grant_and_prior_receipt_hashes_verified': True},
        'captures': capture_summary,
        'independent_reference_comparisons': reconstructed,
        'independent_precision_convergence': {'normalized_errors': [str(decimal_sqrt(v)) for v in convergence], 'exact_squared_gate': 'each error_squared <= 1/2^160', 'passed': True},
        'reconstruction_method': 'Fraction parses exact saved rational outputs and exact decimal reference strings. Complex squared errors and squared thresholds are compared as exact rationals, without rounding. Decimal precision150 is used only to print square roots. Saved comparator presentation agrees to relative1e-60 (absolute floor1e-120); this presentation check does not loosen the exact acceptance gates.',
        'historical_statuses': {'original_modes': {'0': 'stable; all four slots agree', '1': 'unstable; retained, excluded from qualification', '2': 'stable; all four slots agree'}, 'prior_scalar_oracle': 'six fixed rules retained as insufficient_convergence; not rerun or promoted', 'oracle_sha256': digest(oracle_path)},
        'process_absence': {'method': 'Read every accessible /proc/<pid>/stat and inspect process-group IDs, plus leader path absence; no signals or subprocesses.', 'observed_utc': now(), 'current_four_stage_groups': sorted(owned), 'additional_historical_reference_and_release_groups': sorted((historical_groups | additional) - owned), 'members_by_group': members, 'unreadable_processes': unreadable, 'all_absent': True},
        'limits': ['One fixed private rank-zero fixture only; no rank7, Dual, batch or general-domain qualification.', 'No production adoption, throughput or speedup claim. Stage timings are diagnostic.', 'No independent scalar-oracle qualification. Original unstable PV and historical inconclusive oracle remain visible.', 'Working precision is not a claim that each separate real/imaginary component retains that many significant bits; the near-zero finite real residual records precision2 at both working precisions and is assessed through the complete complex slot.'],
    }
    with output.open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'status': report['status'], 'review': str(output.relative_to(ROOT)), 'review_sha256': digest(output), 'script_sha256': report['script_sha256'], 'verified_files': len(CHECKED) - 1, 'max_reference_normalized_error': max(item['normalized_errors'][-1] for item in reconstructed if item['stable']), 'precision_normalized_error': report['independent_precision_convergence']['normalized_errors'][-1]}))


if __name__ == '__main__':
    main()
