#!/usr/bin/env python3
"""Fixed saved-data four-slot comparisons; never launch a numerical process."""
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/shared/external/iregi/iregi-rust')
HERE = Path(__file__).resolve().parent
REFERENCE = ROOT / 'validation/highpoint-thin-n7-rank0-attempt/api2/reference-002'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def decimal(value):
    fraction = Fraction(value)
    return Decimal(fraction.numerator) / Decimal(fraction.denominator)


def norm(pair):
    return sum(value * value for value in pair).sqrt()


def main():
    assert Path.cwd().resolve() == ROOT
    target = HERE / 'runs/compare-001/comparison.json'
    assert not target.exists()
    record = {'status': 'started', 'inputs': {}, 'reference_comparisons': [],
              'scope': 'One fixed private N7 rank0 lane, Float128 and Float256/request53; all four native complex slots. No independent scalar oracle, higher rank, Dual, batching, general-domain, performance or production qualification.'}
    def save():
        temporary = target.with_suffix('.tmp')
        temporary.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
        temporary.replace(target)
    def load(path):
        record['inputs'][str(path)] = sha(path)
        return json.loads(path.read_text())
    save()
    try:
        protocol = load(HERE / 'protocol/protocol.json')
        def pinned(path):
            assert protocol['inputs'][str(path.relative_to(ROOT))] == sha(path), f'unbound changed input: {path}'
        pinned(HERE / 'fixture.json')
        pinned(REFERENCE / 'run.json')
        fixture = load(HERE / 'fixture.json')
        reference_terminal = load(REFERENCE / 'run.json')
        historical = ROOT / 'target/public-highpoint/thin-n7-rank0-api2'
        assert reference_terminal['inputs'][str(historical / 'fixture.json')] == sha(HERE / 'fixture.json')
        sample = fixture['samples'][0]
        assert len(fixture['samples']) == 1 and len(sample['propagators']) == 7
        for mode in range(3):
            request = historical / 'protocol' / f'reference-mode{mode}.txt'
            pinned(request)
            assert reference_terminal['inputs'][str(request)] == sha(request)
            record['inputs'][str(request)] = sha(request)
            lines = request.read_text().splitlines()
            assert len(lines) == 9 and lines[-1] == 'QUIT'
            header = lines[0].split()
            assert header[:7] == ['EVAL', f'n7_rank0_mode{mode}', 'tensor', str(mode), '7', '0', '0']
            assert len(header) == 10 and Fraction(header[7]) == Fraction(sample['mu'])
            assert header[8:] == ['0', '1e-6']
            for line, prop in zip(lines[1:8], sample['propagators']):
                fields = line.split()
                assert len(fields) == 7 and Fraction(fields[6]) == prop['power'] == 1
                assert [Fraction(v) for v in fields[:4]] == [Fraction(v) for v in prop['shift']]
                assert [Fraction(v) for v in fields[4:6]] == [Fraction(v) for v in prop['mass_squared']]
        assert reference_terminal['status'] == 'passed' and reference_terminal['inputs_unchanged'] is True
        assert not reference_terminal.get('total_bound_exceeded', False)
        assert len(reference_terminal['stages']) == 3
        for mode, step in enumerate(reference_terminal['stages']):
            assert step['name'] == f'original_mode{mode}'
            assert step['passed'] is True and step['exit_code'] == 0 and step['within_bound'] is True
            assert step['timeout'] is False and step['cleanup_errors'] == [] and 'error' not in step
            assert step.get('interrupted', False) is False
        refs = []
        for mode in range(3):
            path = REFERENCE / f'mode{mode}.log'
            pinned(path)
            historical_log = str((historical / f'runs/reference-002/mode{mode}.log').relative_to(ROOT))
            assert reference_terminal['outputs'][historical_log] == sha(path)
            record['inputs'][str(path)] = sha(path)
            parsed = [json.loads(line[7:], parse_float=str) for line in path.read_text().splitlines() if line.startswith('RESULT ')]
            assert len(parsed) == 1
            response = parsed[0]
            assert response['id'] == f'n7_rank0_mode{mode}' and type(response['stable']) is bool
            assert response['poles'] == ['uv1', 'ir1', 'ir2', 'finite']
            assert response['stable'] is (mode != 1), 'Retained original status changed'
            assert len(response['moments']) == 1 and len(response['moments'][0]) == 4
            assert all(len(slot) == 2 for slot in response['moments'][0])
            refs.append(response)
        record['original_modes'] = refs
        sample = fixture['samples'][0]
        expected_input = [[str(Fraction(value)), '0'] for prop in sample['propagators'] for value in prop['shift']]
        expected_input += [[str(Fraction(value)) for value in prop['mass_squared']] for prop in sample['propagators']]
        expected_input += [[str(Fraction(sample['mu'])), '0']]
        results = {}
        for bits in [128, 256]:
            stage = f'capture{bits}'
            terminal = load(HERE / f'runs/{stage}-001/run.json')
            assert terminal['status'] == 'passed' and terminal['inputs_unchanged'] is True
            assert not terminal.get('total_bound_exceeded', False)
            assert len(terminal['stages']) == 1
            step = terminal['stages'][0]
            assert step['command'] == protocol['stage_specs'][stage]['commands'][0]['command']
            assert step['passed'] is True and step['exit_code'] == 0 and step['within_bound'] is True
            assert step['timeout'] is False and step['cleanup_errors'] == [] and 'error' not in step
            assert step.get('interrupted', False) is False
            result_path = HERE / f'runs/{stage}-001/result.json'
            assert terminal['outputs'][str(result_path.relative_to(ROOT))] == sha(result_path)
            assert terminal['inputs'][str(HERE / 'fixture.json')] == sha(HERE / 'fixture.json')
            assert terminal['inputs'][str(HERE / 'protocol/protocol.json')] == sha(HERE / 'protocol/protocol.json')
            result = load(result_path)
            assert result['status'] == 'all_lanes_success' and result['lane_statuses'] == ['Success']
            assert result['basis'] == [[0, 0, 0, 0]] and result['rows'] == 1 and result['components'] == 1
            assert result['working_bits'] == bits and result['requested_bits'] == 53
            assert result['metadata'] == {'convention': 'IregiNative', 'tensor_weights': 'Components', 'dual_shape': None}
            assert result['settings'] == {'propagators': 7, 'rank': 0, 'powers': [1] * 7, 'dimension_shift': 0,
                'algorithm': 'PassarinoVeltman', 'convention': 'IregiNative', 'tensor_weights': 'Components',
                'invariants': 'FromShifts', 'input_policy': 'Preserve'}
            assert result['input_exact_rational'] == [expected_input]
            audit = result['domain_audit']
            assert audit['domain_accepted'] is True
            assert Fraction(audit['positive_F_lower_bound']) == Fraction(15, 16)
            assert Fraction(audit['normalization_q_squared']) == 4
            assert len(audit['six_systems']) == 7 and len(audit['five_subsets']) == 21
            execution = result['execution']
            assert execution['child_batch_calls'] == 1 and execution['packed_child_rows'] == 21
            assert execution['parent_batch_calls'] == 1 and execution['packed_parent_rows'] == 1
            assert execution['parent_input_rows'] == 1
            lane = result['lanes'][0]
            assert len(result['lanes']) == 1 and lane['status'] == 'Success' and lane['row'] == 0
            assert len(lane['moments']) == 1 and len(lane['moments'][0]) == 4
            results[bits] = result
        with localcontext() as context:
            context.prec = 100
            natural = Decimal(1) / 1024
            reference_tolerance = Decimal('1e-10')
            precision_tolerance = Decimal(2) ** -80
            values = {bits: [(decimal(slot['real']), decimal(slot['imaginary'])) for slot in result['lanes'][0]['moments'][0]] for bits, result in results.items()}
            assert all(part.is_finite() for slots in values.values() for pair in slots for part in pair)
            agreements = []
            for bits in [128, 256]:
                for mode, response in enumerate(refs):
                    expected = [tuple(Decimal(str(part)) for part in slot) for slot in response['moments'][0]]
                    assert all(part.is_finite() for slot in expected for part in slot)
                    errors = [norm(tuple(a - b for a, b in zip(actual, ref))) / max(natural, norm(ref)) for actual, ref in zip(values[bits], expected)]
                    poles = [norm(slot) / natural for slot in values[bits][:3]]
                    ref_poles = [norm(slot) / natural for slot in expected[:3]]
                    passed = response['stable'] and max(errors + poles + ref_poles) <= reference_tolerance
                    record['reference_comparisons'].append({'working_bits': bits, 'mode': mode,
                        'stable': response['stable'], 'normalized_errors': list(map(str, errors)),
                        'native_pole_residues': list(map(str, poles)), 'original_pole_residues': list(map(str, ref_poles)),
                        'qualified_agreement': passed, 'status': 'compared' if response['stable'] else 'retained_original_unstable'})
                    if mode in [0, 2]:
                        agreements.append(passed)
            convergence = [norm(tuple(a - b for a, b in zip(low, high))) / max(natural, norm(high)) for low, high in zip(values[128], values[256])]
            record['precision_convergence'] = {'normalized_errors': list(map(str, convergence)),
                'tolerance': str(precision_tolerance), 'passed': max(convergence) <= precision_tolerance}
            record['natural_scale'] = str(natural)
            record['reference_tolerance'] = str(reference_tolerance)
            record['stable_original_modes_all_slots_agree'] = all(agreements)
            record['previous_fixed_scalar_oracle'] = 'inconclusive; unchanged and not included in this qualification'
            record['independent_scalar_oracle_qualified'] = False
            record['status'] = 'passed_stable_original_and_precision_only' if all(agreements) and max(convergence) <= precision_tolerance else 'failed_or_requires_adjudication'
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        save()
    print({'status': record['status'], 'path': str(target)})
    return 0 if record['status'] == 'passed_stable_original_and_precision_only' else 1


if __name__ == '__main__':
    sys.exit(main())
