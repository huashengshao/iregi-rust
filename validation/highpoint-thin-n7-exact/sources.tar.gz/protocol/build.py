#!/usr/bin/env python3
"""Compile only the frozen private core and unit binary after ROOT grants it."""
import os
import sys
import time
from common import ROOT, BUNDLE, bindings, execute, finish, install_signal_handlers, load_protocol, save, sha, utc, verify


def main():
    install_signal_handlers()
    protocol = load_protocol()
    output = BUNDLE / 'qualification/build-001'
    output.mkdir(parents=True, exist_ok=False)
    record = {'status': 'building', 'started_utc': utc(), 'bound_seconds': 180,
              'scope': protocol['scope'], 'stages': [], 'outputs': {}}
    path = output / 'build.json'
    save(path, record)
    files = {}
    start = time.monotonic()
    try:
        files = bindings(protocol)
        verify(files, protocol)
        record['inputs'] = {str(p): digest for p, digest in files.items()}
        env = os.environ.copy()
        env.update(CARGO_CRATE_NAME='iregi_rust',
                   CARGO_MANIFEST_DIR=str(BUNDLE / 'core/crates/iregi-rust'),
                   RAYON_NUM_THREADS='1', RUST_TEST_THREADS='1')
        # The frozen command explicitly names rustc, linker, search directories,
        # and every direct extern. No Cargo or mutable shared target is used.
        for stage in protocol['build_stages']:
            verify(files, protocol)
            remaining = 180 - (time.monotonic() - start)
            step = execute(stage['command'], output / stage['log'], remaining, env)
            step['name'] = stage['name']
            record['stages'].append(step)
            save(path, record)
            assert step['passed'], f"{stage['name']} did not pass"
            verify(files, protocol)
        record['status'] = 'passed'
        save(path, record)
        record['outputs'] = {name: sha(output / name) for name in
                             ['libiregi_rust.rlib', 'tests', 'core.log', 'tests.log']}
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        finish(record, path, files, protocol, start)
    print({'status': record['status'], 'receipt': str(path)})
    return 0 if record['status'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main())

