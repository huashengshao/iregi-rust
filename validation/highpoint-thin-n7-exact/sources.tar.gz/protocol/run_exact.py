#!/usr/bin/env python3
"""Run exactly17 nonignored private tests; no N7 numerical kernel/constructor."""
import json
import os
import re
import sys
import time
from common import ROOT, BUNDLE, bindings, execute, finish, install_signal_handlers, load_protocol, save, sha, utc, verify


def main():
    install_signal_handlers()
    protocol = load_protocol()
    output = BUNDLE / 'qualification/exact-001'
    output.mkdir(parents=True, exist_ok=False)
    record = {'status': 'running', 'started_utc': utc(), 'bound_seconds': 180,
              'scope': protocol['scope'], 'tests': [dict(test) for test in protocol['tests']],
              'stages': [], 'tests_passed': 0, 'tests_failed': 0, 'outputs': {}}
    path = output / 'run.json'
    save(path, record)
    files = {}
    start = time.monotonic()
    try:
        files = bindings(protocol)
        build_path = BUNDLE / 'qualification/build-001/build.json'
        build = json.loads(build_path.read_text())
        assert build['status'] == 'passed' and build['inputs_unchanged'] is True
        assert build['elapsed_seconds_including_postguards'] <= 180
        assert build['inputs'] == {str(p): d for p, d in files.items()}
        files[build_path] = sha(build_path)
        for name, digest in build['outputs'].items():
            files[build_path.parent / name] = digest
        verify(files, protocol)
        record['inputs'] = {str(p): d for p, d in files.items()}
        env = os.environ.copy()
        env.update(RAYON_NUM_THREADS='1', RUST_TEST_THREADS='1')
        binary = str(build_path.parent / 'tests')
        taskset = protocol['tool_paths']['taskset']
        command = [taskset, '-c', protocol['runtime_cpu'], binary, '--list', '--format', 'terse']
        listed = execute(command, output / 'inventory.log', 10, env)
        record['stages'].append(dict(listed, name='inventory'))
        save(path, record)
        assert listed['passed'], 'test inventory listing failed'
        names = re.findall(r'^([^\n]+): test$', (output / 'inventory.log').read_text(), re.M)
        assert len(names) == len(set(names)), 'duplicate binary test names'
        for test in record['tests']:
            assert names.count(test['name']) == 1, f"missing exact test: {test['name']}"
        for index, test in enumerate(record['tests']):
            if not test['selected']:
                assert test['status'] == 'unrun_explicitly_ignored'
                continue
            verify(files, protocol)
            remaining = 180 - (time.monotonic() - start)
            assert remaining > 2, 'runtime total bound exhausted'
            logfile = output / f'test-{index:02d}.log'
            command = [taskset, '-c', protocol['runtime_cpu'], binary, test['name'],
                       '--exact', '--nocapture', '--test-threads=1']
            step = execute(command, logfile, min(45, remaining), env)
            step['name'] = test['name']
            record['stages'].append(step)
            test.update(status='passed' if step['passed'] else 'failed', log=logfile.name)
            # Save terminal subprocess information before log parsing/hashes.
            save(path, record)
            assert not step['cleanup_errors'], 'child group cleanup failed; remaining tests stay unrun'
            assert not step.get('interrupted', False), 'runtime interrupted; remaining tests stay unrun'
            text = logfile.read_text()
            success_line = f"test {test['name']} ... ok"
            exact_summary = re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;', text)
            if not (step['passed'] and success_line in text and exact_summary):
                test['status'] = 'failed'
                test['result_gate_error'] = 'nonzero/timeout or exact one-test success record missing'
                record['tests_failed'] += 1
            else:
                record['tests_passed'] += 1
            save(path, record)
            verify(files, protocol)
        record['status'] = 'passed' if record['tests_passed'] == 17 and record['tests_failed'] == 0 else 'failed'
        save(path, record)
        record['outputs'] = {p.name: sha(p) for p in sorted(output.glob('*.log'))}
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        finish(record, path, files, protocol, start)
    print({'status': record['status'], 'passed': record['tests_passed'], 'failed': record['tests_failed'],
           'ignored_constructor': 'UNRUN', 'receipt': str(path)})
    return 0 if record['status'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main())
