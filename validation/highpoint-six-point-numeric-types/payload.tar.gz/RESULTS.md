# Bounded typed six-point pilot: numerical attempts terminal

This is private validation evidence, not a production change or a performance
measurement. It uses the preserved qualified V2 six-point source, adds only the
already reviewed capture/helper module, and links the explicitly frozen native
object closure. It is not a fresh current-Cargo qualification.
`README.md` remains the immutable pre-execution protocol snapshot; this document
records the subsequent actual outcomes without changing any bound input.

The final approved protocol is SHA-256
`9d84e08c824f5b155a75a770ea0a4f4d453b96d8f178e93d6aebb262ad66b566`.
Its 219 source/tool/archive/review bindings include the independently reviewed
216-binding draft, the draft itself and both independent source reviews. The
build adds its exact protocol/grant bindings. Root authorized this fixed build
and all four independent numeric stages after the preceding constructor cohort
released its lease; no attempt was repeated or extended.

| Stage | Aggregate seconds | Captured positive lanes | Complete complex slots | Outcome |
|---|---:|---:|---:|---|
| Core and driver build | 35.644090749 / 90 | — | — | Both compilation steps pass |
| f64 | 68.567705068 / 180 | 0 / 10 | 0 / 40 | Complete schedule; every positive lane rejects its cancellation guard |
| DoubleFloat | 43.912880827 / 180 | 10 / 10 | 40 / 40 | Complete saved numerical gate passes |
| Float128 dynamic Dual | 164.436043399 / 180 | 1 / 10 | 24 / 240 | Work alarm during `mixed`, after one successful affine singleton; incomplete domain fails |
| Float256 dynamic Dual | 164.159542519 / 180 | 0 / 10 | 0 / 240 | Work alarm during first affine singleton; incomplete domain fails |

The runtime runner's `passed` status means that the bounded process completed
and its provenance checks passed. It is distinct from numerical qualification:
the f64 process finishes all five calls but its saved numerical gate fails.
All f64 failure values remain null. The positive rejection identifies N5 subset
zero and its configured 53-bit cancellation guard; no tolerance was loosened.

DoubleFloat has ten complete successes, two exact invalid-mu controls, one empty
reset, identical repeated/reordered represented values, and forty complete
Laurent slots. All original-IREGI, retained high-precision scalar, repeat, exact
pole-zero, input-preservation, metadata and packing gates pass. The largest
dimensionally normalized discrepancy is approximately `8.1748079e-14` against
the untouched original scalar and `6.4199782e-30` against the retained Float256
scalar. The three positive ordinary profiles have the same primal kinematics;
this is one physical point, not ten independent physical samples.

The completed Float128 affine singleton contains eighteen exact pole zeros and
six finite Taylor coefficients in ordered shape `[00,10,01,20,11,02]`. Every
available original-primal and analytic scaling comparison passes; its largest
normalized discrepancy against the retained Float256 scalar times independently
differentiated exact multipliers is approximately `1.0127480e-34`. This available
prefix is retained as diagnostic evidence. It does not satisfy the complete
240-slot domain gate. No Float256 array is available, so there can be no paired
precision-convergence qualification.

Exact inputs and targets use Symbolica Dualizer and ordinary symbolic
differentiation respectively. Independently reviewed fixed numerical equalities
in the saved comparator verify their beyond-binary64 input information, including
`2^-60` and `2^-120`, without implementing a polynomial or Taylor manipulator.
The two formal variables describe one physical dilation, not independent mass
or invariant derivatives. Only the affine profile produced a Dual result before
the fixed budget exhausted; the nonlinear product-profile numerical check
remains incomplete.

All six owned process groups (two compiler steps and four numeric captures) are
actually absent. The immutable release record is `numerical-release.json`, SHA
`544bd26f6e3cca5749bc1575d86dedfe41f2c227af78c6cc03fabb09b9a92702`.
The numerical lease has passed to the next root-coordinated owner. Float256 and
paired saved-data gates were collected after the following owner's numerical
attempt; both fail, with valid domain provenance and no Float256 or paired
arrays available. `saved-gates-terminal.json`, SHA
`b493dc3e79c13439733fcb95fd2218ba6e6733db73ec306915fe0db01419453b`,
binds all terminal artifacts and all five comparison reports. An independent
final saved-data audit independently recomputed all 64 available output slots
and all 1,736 input slots without importing the producer. It confirmed the
DoubleFloat complete pass and the visible failures/incomplete Dual coverage.
The separate provenance audit rehashed all 219 protocol inputs and each domain's
231 bindings, checked the two build and four runtime commands, and confirmed
all six owned process groups are absent. These checks execute no integral.

The independent numeric and provenance audit hashes are respectively
`c08655b8565c848f2749763d5f65639e798c43da1382da3634246192bc8fe0c2` and
`438446e353fd66d26225c78e47ce1f65082d970078c8d1e032e9e673819e234c`.
The immutable `qualification.json` hash is
`c3982195d7d133f6a13b7137f83f21208db4b1d9c113a6a4ac478359586bfc37`;
its status is `private_typed_scalar_n6_pilot_completed_with_failures`.

Child sensitivity/error imports are primal-only. Even the successful partial
affine derivative identity cannot certify requested-53 derivative uncertainty
transport. Public `new_dual`, an achieved-error enclosure, static Dual, arbitrary
independent directions, generalized N6 powers, rank seven and performance remain
unqualified. No production source was edited or default enabled. These timings
include preparation and immutable-input checks in an unoptimized qualification
build and must not be used as kernel benchmark ratios.
