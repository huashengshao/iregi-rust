"""One independent, separately granted type capture; 180s with 20s reserve."""
import datetime
import os
import sys
import time
import common as h
from lifecycle import Budget, execute, freeze_binary


def main(domain):
    h.require(domain in h.DOMAINS, 'unknown domain')
    folder = h.HERE / h.RUNS[domain]
    folder.mkdir(exist_ok=False)
    budget = Budget(180)
    budget.work_deadline = budget.deadline - 20
    record = {'status': 'preflight', 'operation': domain, 'bound_seconds': 180,
              'postwork_reserve_seconds': 20, 'steps': [], 'cleanup_errors': [],
              'environment_additions': h.ENVIRONMENT,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    h.save(folder / 'run.json', record)
    work_passed = False
    try:
        budget.arm()
        build = h.validate_build()
        inputs = h.run_inputs(domain, build)
        record.update(status='running', inputs=inputs)
        executable_sha = build['run']['outputs']['typed_n6']
        freeze_binary(h.BUILD / 'typed_n6', executable_sha,
                      folder / h.FROZEN_EXECUTABLE, budget)
        record['executed_binary_sha256'] = executable_sha
        environment = os.environ.copy()
        environment.update(h.ENVIRONMENT)
        command = h.run_command(domain, build['protocol'])
        budget.remaining()
        step = {'command': command}
        record['steps'].append(step)

        def persist(result):
            step.update(result)
            h.save(folder / 'run.json', record)

        result = execute(command, folder / 'step-0.log', budget, 180,
                         record['cleanup_errors'], persist, environment)
        h.require(result['status'] == 'exited' and result.get('owned_group_gone') is True,
                  'capture failed or retained an owned process')
        work_passed = True
        record['status'] = 'completed_awaiting_guards'
    except Exception as error:
        record.update(status='failed', error=repr(error))
    finally:
        budget.disarm()
        record['elapsed_seconds'] = budget.elapsed()
        if budget.cancelled:
            record['cancellation'] = budget.cancelled
        h.save(folder / 'run.json', record)
    post = Budget(max(0, budget.deadline - time.monotonic()))
    try:
        post.arm()
        post.remaining()
        h.require('inputs' in record, 'preflight did not establish input bindings')
        h.final_verify(record['inputs'])
        record['inputs_unchanged'] = True
        record['outputs'] = {}
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.name != 'run.json':
                post.remaining()
                record['outputs'][path.name] = h.sha(path)
    except Exception as error:
        record.update(postguard_error=repr(error), inputs_unchanged=False)
    finally:
        post.disarm()
    record.update(elapsed_seconds=budget.elapsed(),
                  finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if post.cancelled:
        record['postguard_cancellation'] = post.cancelled
    record['status'] = 'passed' if (
        work_passed and record.get('inputs_unchanged') is True and not record['cleanup_errors']
        and not budget.cancelled and not post.cancelled and record['elapsed_seconds'] <= 180
        and all(step.get('status') == 'exited' and step.get('owned_group_gone') is True for step in record['steps'])
    ) else 'failed'
    h.save(folder / 'run.json', record)
    print({'operation': domain, 'status': record['status'], 'seconds': record['elapsed_seconds']})
    return 0 if record['status'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main(sys.argv[1]))
