# Typed scalar N6 pilot — source-only candidate

The qualified V2 six-point mathematics is unchanged. `source.json` binds 61
private files and proves restoration of all 59 originals after removing the
single capture-module declaration. Only the capture module, exact Symbolica jet
helper, and standalone driver are added. No build or numerical run has occurred.

The four predeclared stages are `f64`, `DoubleFloat`, `Float128Dual`, and
`Float256Dual`. Every stage has the same scalar fixture and five-call schedule.
The first two stages capture only primal values. The latter use the ordered
six-component shape `[00,10,01,20,11,02]`; they test two formal parameterizations
of one physical dilation, including nonlinear mixed inputs.

Each type is independent: a qualified build and that type's own root grant are
the only execution prerequisites. A guard rejection in f64 or DoubleFloat is
reported as an unsuccessful numerical gate, with its statuses and partial
outputs retained. It does not remove the separately predeclared high-precision
stages. This replaces only the suggested serial-admission wording of the
preserved source proposal. It does not authorize parallel execution or retry.

`compare_saved.py <domain>` checks all intended successful lanes and returns a
failed gate if any positive lane lacks its complete result. `paired` additionally
requires both Dual gates and compares all 240 matching complex Taylor/Laurent
slots at `2^-80`. Individual original/reference and scaling-identity comparisons
retain `1e-10`. All three pole slots and every constant-profile non-primal slot
must be exactly zero. Full errors, precision/sign/value differences, invalid
neighbors, repeated/reordered profiles, empty resets, and counters remain visible.

The saved comparator checks every prepared input component and response
multiplier against the independently reviewed fixed exact-number formulas,
including the information at `2^-60` and `2^-120`. It uses full complex norms;
matching missing/rejected positive lanes never qualify a domain or convergence.

The response identity is native scalar N6 scaling by `lambda^-8`, with shifts and
mu multiplied by lambda and masses squared by lambda squared. Symbolica's
Dualizer generates inputs over rationals; ordinary Symbolica differentiation
generates the expected multipliers independently. The helper and mathematical
review are pinned. No hand-written polynomial or Taylor arithmetic is added.

Build and runtime require source approval of the final protocol and a separate
`grant-<operation>.json` bound to its exact hash. The build has 90 seconds total,
including a 25-second reserve. Each capture has 180 seconds total, including a
20-second reserve. The exact reviewed `lifecycle.py` owns and cleans the whole
process group even after leader exit. Terminal events are saved before output
hashes. The frozen source, compiler, explicitly selected linker, explicit
Rust/native closure, Python, taskset, and resulting binaries are checked before
and after work. Each capture executes an owned immutable copy of the qualified
executable whose digest is checked again afterward. These locally retained ELF
copies are execution artifacts and must be excluded from any committed evidence
archive. No claim is made for all linker-wrapper subtools or the
operating-system/sysroot closure. No live dependency fallback or new dependency
build is allowed.

After the final source review, and **only with the corresponding execution
grant**, commands run from `/shared/external/iregi/iregi-rust` are:

```sh
source scripts/env.sh
source .local/symbolica-license.env
python3 target/public-highpoint/numeric-types-dual/build.py
python3 target/public-highpoint/numeric-types-dual/run.py Float128Dual
python3 target/public-highpoint/numeric-types-dual/compare_saved.py Float128Dual
```

The example command does not imply a current grant or prescribe skipping the
other declared types. It never prints or stores the license. Every stage uses a
fresh fixed output directory and refuses overwrite. No automatic retries, bound
extensions, new references, or altered thresholds are implemented.

Primal-only child sensitivity remains a material limitation. Passing these
identities does not demonstrate requested-53 derivative-error propagation,
arbitrary independent mass/invariant directions, or static Dual support. Public
`new_dual`, a general achieved-error enclosure, rank-seven admission, generalized
N6 powers, and performance qualification remain deferred. The public Float-only
rank-at-most-three scope is unchanged.
