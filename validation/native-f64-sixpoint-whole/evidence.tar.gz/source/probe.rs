//! Untimed qualification of two public policies in one source-matched binary.
#[cfg(not(iregi_qualification_capture))]
compile_error!("qualification harness requires the observation-only capture cfg");

use serde::Deserialize;
use serde_json::json;
use std::{collections::HashMap, io::{self, BufRead, Write}};

#[derive(Deserialize)]
pub struct Sample { shifts: Vec<[f64; 4]>, masses: Vec<[f64; 2]>, mu: f64 }
#[derive(Deserialize)]
pub struct Request {
    id: String, n: usize, rank: u16, algorithm: String, samples: Vec<Sample>,
    #[serde(default)] engine: Option<String>,
    #[serde(default)] warmup: usize,
    #[serde(default)] repeats: usize,
    #[serde(default)] iterations: usize,
}

mod baseline {
    use iregi_rust_baseline as core_impl;
    const POLICY: iregi_masters::MasterExecutionPolicy = iregi_masters::MasterExecutionPolicy::Symbolica;
    include!("core_probe.rs");
    fn assert_workspace_policy<T: NativeFloat>(_: &Workspace<T>, policy: MasterExecutionPolicy)
    where Complex<T>: EvaluationDomain { assert_eq!(policy, MasterExecutionPolicy::Symbolica); }
    fn ordinary_workspace<T: NativeFloat>(plan: &ReductionPlan, prototype: T, policy: MasterExecutionPolicy)
        -> Result<Workspace<T>, core_impl::ReductionError> where Complex<T>: EvaluationDomain {
        assert_eq!(policy, MasterExecutionPolicy::Symbolica);
        Workspace::new(plan, prototype)
    }
    fn dual_workspace<T: NativeFloat>(plan: &ReductionPlan, prototype: T, shape: HyperDual<f64>, policy: MasterExecutionPolicy)
        -> Result<Workspace<T>, core_impl::ReductionError> where Complex<T>: EvaluationDomain {
        assert_eq!(policy, MasterExecutionPolicy::Symbolica);
        Workspace::new_dual(plan, prototype, shape)
    }
}
mod candidate {
    use iregi_rust_candidate as core_impl;
    const POLICY: core_impl::MasterExecutionPolicy = core_impl::MasterExecutionPolicy::NativeF64Abc;
    include!("core_probe.rs");
    include!("cache_interleaving.rs");
    fn assert_workspace_policy<T: NativeFloat>(workspace: &Workspace<T>, policy: MasterExecutionPolicy)
    where Complex<T>: EvaluationDomain { assert_eq!(workspace.master_execution_policy(), policy); }
    fn ordinary_workspace<T: NativeFloat>(plan: &ReductionPlan, prototype: T, policy: MasterExecutionPolicy)
        -> Result<Workspace<T>, core_impl::ReductionError> where Complex<T>: EvaluationDomain {
        Workspace::new_with_master_policy(plan, prototype, policy)
    }
    fn dual_workspace<T: NativeFloat>(plan: &ReductionPlan, prototype: T, shape: HyperDual<f64>, policy: MasterExecutionPolicy)
        -> Result<Workspace<T>, core_impl::ReductionError> where Complex<T>: EvaluationDomain {
        Workspace::new_dual_with_master_policy(plan, prototype, shape, policy)
    }
}
mod master_controls;
mod actual_base_master_controls;

fn main() {
    assert!(iregi_rust_baseline::QUALIFICATION_CAPTURE_ENABLED);
    assert!(iregi_rust_candidate::QUALIFICATION_CAPTURE_ENABLED);
    iregi_masters::MasterExecutionPolicy::NativeF64Abc.validate_available().unwrap();
    assert_eq!(iregi_masters::default_master_backend(), iregi_masters::MasterBackend::SymbolicaBatch,
        "qualification must enable only native-f64-abc, not broad native-batch");
    let mut base = None;
    let mut selected = None;
    let mut baseline_plans = HashMap::new();
    let mut candidate_plans = HashMap::new();
    let stdin = io::stdin();
    let mut out = io::stdout().lock();
    for line in stdin.lock().lines() {
        let line = line.unwrap();
        if line.trim() == "QUIT" { break; }
        if line.trim().is_empty() { continue; }
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            if line.trim() == "CONTROLS" {
                let a = baseline::unchanged_controls();
                let b = candidate::unchanged_controls();
                assert_eq!(a, b, "unchanged complete core records differ across policies");
                let extended_a = baseline::extended_unchanged_controls();
                let extended_b = candidate::extended_unchanged_controls();
                assert_eq!(extended_a, extended_b, "extended complete core records differ across policies");
                let masters = master_controls::run();
                let actual_base_masters = actual_base_master_controls::run();
                for field in ["unchanged_paths", "extended_unchanged_paths", "extended_inventory"] {
                    assert_eq!(actual_base_masters[field], masters[field], "actual-base unchanged master records differ: {field}");
                }
                json!({"id":"controls","status":"passed","controls":{
                    "baseline":a,"candidate":b,"masters":masters},
                    "actual_base_master_controls":actual_base_masters,
                    "extended_unchanged_controls":{"status":"passed","baseline":extended_a,"candidate":extended_b,
                        "inventory":[
                            {"label":"DoubleFloat N2r1 beyond53","numeric_type":"DoubleFloat","precision":106,"rows":1,"components":1,"tensor_complex_values":20},
                            {"label":"Float256 N2r1 beyond53","numeric_type":"Float","precision":256,"rows":1,"components":1,"tensor_complex_values":20}
                        ]},
                    "cache_interleaving":candidate::cache_interleaving(),
                    "requested_master_policies":{"baseline":"Symbolica","candidate":"NativeF64Abc"}})
            } else {
                match serde_json::from_str::<Request>(&line) {
                    Ok(request) if request.engine.is_none() && request.warmup == 0 && request.repeats == 0 && request.iterations == 0 => {
                        json!({"id":request.id,
                            "baseline":baseline::run(&request, &mut base, &mut baseline_plans).unwrap_or_else(|e|json!({"error":e})),
                            "candidate":candidate::run(&request, &mut selected, &mut candidate_plans).unwrap_or_else(|e|json!({"error":e}))})
                    }
                    Ok(_) => json!({"status":"invalid_request","error":"qualification is untimed; engine and timing counts are forbidden"}),
                    Err(error) => json!({"status":"invalid_request","error":error.to_string()}),
                }
            }
        }));
        let result = result.unwrap_or_else(|_| {
            iregi_rust_baseline::set_master_capture(false);
            iregi_rust_candidate::set_master_capture(false);
            let _ = iregi_rust_baseline::take_master_captures();
            let _ = iregi_rust_candidate::take_master_captures();
            json!({"status":"failed","error":"qualification assertion failed; see stderr"})
        });
        writeln!(out, "RESULT {result}").unwrap();
        out.flush().unwrap();
    }
}
