pub fn cache_interleaving() -> Value {
    let plan=control_plan();
    let policies=[MasterExecutionPolicy::Symbolica,MasterExecutionPolicy::NativeF64Abc];
    let mut expected=Vec::new();
    for policy in policies {
        for dual in [false,true] {
            let batch=control_batch(&0f64,dual,false);
            let mut workspace=control_workspace(&plan,0f64,dual,policy);
            let record=observe(&mut workspace,&batch,plan.basis().len(),policy,dual).unwrap();
            assert!(record["stable"].as_bool().unwrap());
            expected.push(record);
        }
    }
    let mut steps=Vec::new();
    for index in [2usize,1,0,3,2,0,3,1] {
        let policy=policies[index/2];let dual=index%2==1;
        let batch=control_batch(&0f64,dual,false);
        let mut workspace=control_workspace(&plan,0f64,dual,policy);
        let record=observe(&mut workspace,&batch,plan.basis().len(),policy,dual).unwrap();
        assert_eq!(record,expected[index],"policy/shape cache interleaving changed complete record");
        steps.push(json!({"requested_master_policy":format!("{policy:?}"),"dual":dual,"result":record}));
    }
    json!({"status":"passed","same_immutable_plan":true,"expected_current_process_records":expected,"steps":steps})
}
