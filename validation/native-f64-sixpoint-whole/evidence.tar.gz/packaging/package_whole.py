"""Seal compact whole38 evidence after independent saved-record audits; no kernels."""
from pathlib import Path
import argparse,datetime,gzip,hashlib,io,json,os,tarfile
ROOT=Path.cwd();PORT=ROOT/'target/native-f64-sixpoint-port';HERE=PORT/'whole'
DEST=ROOT/'validation/native-f64-sixpoint-whole'
PARENT=ROOT/'validation/winddown/native-f64-sixpoint-composition.tar.gz'
EXPECTED_PARENT='25bdb8eaef1ca55875e8ab73b0b59b6c8a6e85c90c2fe166317fef01881a7329'

def sha(path):
    with Path(path).open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def blobsha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save(path,value):
    with Path(path).open('x')as stream:stream.write(json.dumps(value,indent=2)+'\n')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('closure_audit');parser.add_argument('numerical_audit');args=parser.parse_args()
    closure=ROOT/args.closure_audit;numerical=ROOT/args.numerical_audit
    for path in [closure,numerical]:
        doc=read(path);assert 'passed'in doc['status'].lower() or doc['status'].lower()=='pass',str(path)
        assert not doc.get('findings'),str(path)
    prep=read(HERE/'preparation.json');build=read(HERE/'observation-build-001/build.json')
    runtime=read(HERE/'whole-qualification-001/results.json');gate=read(HERE/'whole-qualification-001/independent-admission.json')
    assert build['status']=='passed'and runtime['status']=='passed-awaiting-independent-raw-validation'and gate['status']=='passed'
    assert len(build['input_sha256'])==776 and len(runtime['input_sha256'])==782 and runtime['request_count']==38
    assert build['inputs_unchanged']and runtime['inputs_unchanged']and not build['cleanup_errors']and not runtime['cleanup_errors']
    assert not build['deadline_exceeded']and not runtime['deadline_exceeded']and build['elapsed_seconds']<180 and runtime['elapsed_seconds']<120
    assert sha(PARENT)==EXPECTED_PARENT
    # Every original source is inherited exactly from the already committed parent; avoid duplicating165files.
    inherited={}
    with tarfile.open(PARENT,'r:gz')as archive:
        for variant,prefix in [('baseline','base'),('candidate','proposed')]:
            for relative,expected in prep['original_source_mapping'][variant].items():
                member=f'{prefix}/{relative}';data=archive.extractfile(member).read();assert blobsha(data)==expected,member
                inherited[f'source/{variant}/{relative}']={'parent_member':member,'sha256':expected,'bytes':len(data)}
    payload={}; omitted=[]
    # Capture-only source overrides plus every fresh script/metadata/raw/log record, excluding ELFs and rustc products.
    for path in sorted(HERE.rglob('*')):
        if not path.is_file()or '__pycache__'in path.parts:continue
        relative=str(path.relative_to(HERE))
        if relative.startswith('source/baseline/')or relative.startswith('source/candidate/'):
            variant=relative.split('/')[1];local='/'.join(relative.split('/')[2:])
            changes=prep['overlay_changes'][variant]
            if local not in changes['changed']+changes['added']:
                assert sha(path)==inherited[relative]['sha256'],relative
                continue
        if path.suffix in ['.rlib','.rmeta','.o','.a','.so','.pyc']or path.name in ['probe','TIRust-frozen','IREGI-frozen']:
            omitted.append({'origin':str(path.relative_to(ROOT)),'sha256':sha(path),'bytes':path.stat().st_size,'reason':'compiled product/executable kept private; hash and command provenance retained'})
            continue
        assert not path.is_symlink()
        payload[relative]=path
    reviews={
      'reviews/external-source-command-review.json':ROOT/'target/resume-20261025-review/whole-independent-source-command-review-v2.json',
      'reviews/external-probe-source-review.json':ROOT/'target/resume-20261025-review/whole-probe-child-review.json',
      'reviews/external-build-saved-audit.json':ROOT/'target/resume-20261025-review/whole-build-independent-saved-audit.json',
      'reviews/external-runtime-closure-audit.json':closure,
      'reviews/external-runtime-numerical-audit.json':numerical,
      'reviews/audit_whole_runtime_independent.py':ROOT/'target/resume-20261025-review/audit_whole_runtime_independent.py',
      'predecessor/Dual-numerical-release.json':ROOT/'target/public-highpoint/numeric-types-dual/numerical-release.json',
      'packaging/package_whole.py':Path(__file__).resolve(),
    }
    assert len(set(payload)&set(reviews))==0;payload.update(reviews)
    license_value=os.environ.get('SYMBOLICA_LICENSE','').encode();assert license_value,'private license loaded silently solely for content exclusion check'
    member_map={}; contents={}
    for relative,path in sorted(payload.items()):
        data=path.read_bytes();assert not data.startswith((b'\x7fELF',b'!<arch>\n')),relative
        assert license_value not in data,'private credential unexpectedly present in '+relative
        contents[relative]=data
        member_map[relative]={'kind':'exact-copy','origin':str(path.relative_to(ROOT)),'sha256':blobsha(data),'bytes':len(data)}
    DEST.mkdir(exist_ok=False)
    archive_path=DEST/'evidence.tar.gz'
    with archive_path.open('xb')as output,gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=9)as compressed,tarfile.open(fileobj=compressed,mode='w|')as archive:
        for relative,data in sorted(contents.items()):
            info=tarfile.TarInfo(relative);info.size=len(data);info.mode=0o644;info.uid=info.gid=0;info.mtime=0;info.uname=info.gname=''
            archive.addfile(info,io.BytesIO(data))
    parent={'source_commit':'2c1f3342e189a20fef3bbf7dd9e0baa372e2b4a2','path':str(PARENT.relative_to(ROOT)),'sha256':EXPECTED_PARENT,'inherited_source_files':inherited}
    save(DEST/'parent.json',parent)
    summary={
      'status':'private-actual-base-combined-candidate-whole38-qualified','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer':'/root/native_whole_port',
      'source_context':'2c1f3342e189a20fef3bbf7dd9e0baa372e2b4a2','combined_patch_sha256':'70b5f94487f79d25c9bc831c0895fe2970ba8e222297ba0baf9f683d67101f9a',
      'source':{'actual_baseline_files':80,'candidate_files':85,'observation_changes_per_variant':3,'observation_added_modules_per_variant':1,'reused_candidate_captured_master_files':30,'fresh_rustc_products':4,'source_and_command_review_sha256':sha(reviews['reviews/external-source-command-review.json']),'build_saved_audit_sha256':sha(reviews['reviews/external-build-saved-audit.json'])},
      'build':{'status':'passed','receipt_member':'observation-build-001/build.json','receipt_sha256':sha(HERE/'observation-build-001/build.json'),'elapsed_seconds':build['elapsed_seconds'],'aggregate_cap_seconds':180,'cleanup_reserve_seconds':8,'compile_cpus':[6,7],'protected_inputs':776,'owned_groups':4,'all_groups_gone':True,'diagnostic_duration_not_performance':True,'outputs':build['outputs']},
      'runtime':{'status':'passed','receipt_member':'whole-qualification-001/results.json','receipt_sha256':sha(HERE/'whole-qualification-001/results.json'),'saved_admission_member':'whole-qualification-001/independent-admission.json','saved_admission_sha256':sha(HERE/'whole-qualification-001/independent-admission.json'),'raw_member':'whole-qualification-001/responses.jsonl','raw_sha256':runtime['raw_sha256'],'elapsed_seconds':runtime['elapsed_seconds'],'aggregate_cap_seconds':120,'cleanup_reserve_seconds':8,'cpu':22,'protected_inputs':782,'requests':38,'TIRust_requests':30,'IREGI_requests':8,'raw_events':76,'families':8,'tensor_complex_slots_per_variant':1584,'master_complex_slots_per_variant':1782,'direct_selected_master_cases':34,'candidate_unchanged_master_cases':21,'actual_base_unchanged_master_cases':21,'precision_master_cases_per_source':12,'whole_f64_Dual_controls':1,'whole_DoubleFloat_Float_controls':2,'cache_interleaving_steps':8,'invalid_timing_request_controls':4,'all_own_and_retained_full_records_exact':True,'owned_groups':2,'all_groups_gone':True,'kernel_timing':False,'diagnostic_duration_not_performance':True},
      'comparisons':{'gate':1e-10,'tensor_normalization':'abs(a-b)/(E^(4+rank-2*n)+abs(b)); E=max(1,mu,abs(shifts),sqrt(abs(mass_squared)))','maximum_cross_source_tensor_error':max(row['whole_cross_backend']['max_error']for row in gate['whole_cases']),'maximum_original_reference_tensor_error':max(item['max_error']for row in gate['whole_cases']for item in row['reference_comparisons'].values()),'maximum_captured_master_error':max(row['masters']['max_normalized_error']for row in gate['whole_cases']),'unchanged_numeric_paths':'all complete six-output/tensor records exact by represented rational, precision, sign, inputs/errors and metadata'},
      'independent_audits':{'runtime_closure':{'member':'reviews/external-runtime-closure-audit.json','sha256':sha(closure)},'runtime_numerical':{'member':'reviews/external-runtime-numerical-audit.json','sha256':sha(numerical)}},
      'not_qualified_by_this_capsule':{'retained_six_point_reference_convergence_lifecycle':True,'current_Cargo_feature_forwarding':True,'production_application_or_default_adoption':True,'performance_or_parity':True,'broad_native_runtime':True,'public_SixPoint_Dual_f64_DoubleFloat_or_generalized_envelope':True,'rank_seven_or_N7':True},
      'production_mutations':False,'compiler_execution':True,'Cargo_execution':False,'numerical_execution':True,'benchmark_execution':False,'automatic_retries':False,'compiled_artifacts_committed':False,
    }
    save(DEST/'qualification.json',summary)
    for name in ['README.md','check.py']:
        (DEST/name).write_bytes((PORT/'whole-capsule-template'/name).read_bytes())
    metadata={name:{'sha256':sha(DEST/name),'bytes':(DEST/name).stat().st_size}for name in ['README.md','check.py','parent.json','qualification.json']}
    save(DEST/'manifest.json',{'metadata_files':metadata,'status':'sealed-compact-source-and-text-evidence-capsule','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':{'path':'evidence.tar.gz','sha256':sha(archive_path),'bytes':archive_path.stat().st_size,'members':member_map},'inherited_parent_sources':165,'omitted_compiled_products':omitted,'content_audit':{'source_or_text_members':len(member_map),'ELF_or_ar_payloads':0,'provided_license_occurrences':0,'no_private_license_value_stored':True}})
    print(json.dumps({'status':summary['status'],'qualification_sha256':sha(DEST/'qualification.json'),'manifest_sha256':sha(DEST/'manifest.json'),'archive_sha256':sha(archive_path),'archive_bytes':archive_path.stat().st_size,'payload_members':len(member_map),'inherited_parent_sources':len(inherited)}))
if __name__=='__main__':main()
