"""Four bounded direct-rustc observation products; importing executes nothing."""
from pathlib import Path
import datetime, hashlib, json, os, sys
from lifecycle import Budget, execute
ROOT=Path.cwd(); HERE=ROOT/'target/native-f64-sixpoint-port/whole'; CAP=180

def sha(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path): return json.loads(Path(path).read_text())
def save(path,value): Path(path).write_text(json.dumps(value,indent=2)+'\n')

def recipe(attempt,manifest):
    tools=manifest['tools']; external={name:ROOT/path for name,path in manifest['externs'].items()}
    master=Path(manifest['reused_candidate_masters']['path'])
    common=[tools['taskset']['path'],'-c','6,7',tools['rustc']['path'],'--edition=2024',
        '-C','opt-level=0','-C','debuginfo=0','-C','strip=debuginfo','-C','debug-assertions=yes',
        '-C','overflow-checks=yes','-C',f'linker={tools["cc"]["path"]}']
    for kind,directory in [('dependency',manifest['dependency_directory']),('dependency',manifest['supplemental_directory']),('native',manifest['native_directory'])]:
        common+=['-L',f'{kind}={ROOT/directory}']
    for directory in [master.parent,attempt/'baseline',attempt/'candidate']:
        common+=['-L',f'dependency={directory}']
    base=HERE/'source/baseline/crates'; candidate=HERE/'source/candidate/crates'
    outputs={'baseline-masters':attempt/'baseline/libiregi_masters.rlib',
             'baseline-core':attempt/'baseline/libiregi_rust_baseline.rlib',
             'candidate-core':attempt/'candidate/libiregi_rust_candidate.rlib',
             'selective-probe':attempt/'probe'}
    steps=[]
    def add(label,crate,source,externs,flags,manifest_directory,library=True):
        command=common+['--crate-name',crate,'-C','metadata=native_sixpoint_whole_'+label.replace('-','_')]
        if library: command+=['--crate-type','rlib']
        command+=['--cfg','iregi_qualification_capture']+flags+[str(source),'-o',str(outputs[label])]
        for name,path in externs.items(): command+=['--extern',f'{name}={path}']
        steps.append({'label':label,'command':command,'output':str(outputs[label]),'timeout_seconds':90,
          'environment':{'CARGO_CRATE_NAME':crate,'CARGO_MANIFEST_DIR':str(manifest_directory)}})
    add('baseline-masters','iregi_masters',base/'iregi-masters/src/lib.rs',
        {key:external[key] for key in ['symbolica','oneloop']},['--cfg','feature="default"'],base/'iregi-masters')
    add('baseline-core','iregi_rust_baseline',base/'iregi-rust/src/lib.rs',
        {**{key:external[key] for key in ['symbolica','serde','thiserror']},'iregi_masters':outputs['baseline-masters']},
        ['--cfg','feature="default"'],base/'iregi-rust')
    add('candidate-core','iregi_rust_candidate',candidate/'iregi-rust/src/lib.rs',
        {**{key:external[key] for key in ['symbolica','serde','thiserror']},'iregi_masters':master},
        ['--cfg','feature="default"','--cfg','feature="native-f64-abc"'],candidate/'iregi-rust')
    add('selective-probe','native_sixpoint_whole_qualification',HERE/'source/probe.rs',
        {**{key:external[key] for key in ['symbolica','oneloop','serde','serde_json']},
         'iregi_masters':master,'iregi_masters_baseline':outputs['baseline-masters'],'iregi_rust_baseline':outputs['baseline-core'],'iregi_rust_candidate':outputs['candidate-core']},
        [],HERE/'source',library=False)
    assert len(steps)==4
    return steps

def main():
    assert len(sys.argv)==2 and sys.argv[1]=='001','one separately granted attempt: 001'
    attempt=HERE/'observation-build-001'; attempt.mkdir(exist_ok=False)
    budget=Budget(CAP); bindings={}; setup=False
    record={'status':'preparing','stage':'observation','scope':'private actual-base/combined-candidate opt0 observation build; no Cargo/numerical execution/performance claim',
      'runtime_cap_seconds':CAP,'cleanup_reserve_seconds':8,'compile_cpus':[6,7],
      'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':{},'steps':[],'outputs':{},'cleanup_errors':[]}
    save(attempt/'build.json',record)
    def verify():
        assert setup,'input binding setup did not complete'
        for path,value in bindings.items(): budget.remaining(); assert sha(path)==value,str(path)
        for item in record['outputs'].values(): budget.remaining(); assert sha(item['path'])==item['sha256'],item['path']
    budget.arm()
    try:
        prep_path=HERE/'preparation.json';plan_path=HERE/'command-plan.json';grant_path=HERE/'build-execution-grant-001.json'
        prep=read(prep_path); grant=read(grant_path)
        assert grant['preparation_sha256']==sha(prep_path) and grant['command_plan_sha256']==sha(plan_path)
        assert grant['runner_sha256']==sha(__file__) and grant['lifecycle_sha256']==sha(HERE/'lifecycle.py')
        assert grant['aggregate_seconds']==CAP and grant['compile_cpus']==[6,7]
        bindings={Path(path):value for path,value in prep['input_sha256'].items()}
        bindings.update({prep_path:sha(prep_path),plan_path:sha(plan_path),grant_path:sha(grant_path)})
        assert bindings[Path(__file__).resolve()]==sha(__file__)
        steps=recipe(attempt,prep);assert steps==read(plan_path)['steps'];record['steps']=steps
        for step in steps:step['status']='unrun'
        record['input_sha256']={str(path):value for path,value in bindings.items()};setup=True
        save(attempt/'build.json',record);verify()
        for step in steps:
            budget.remaining();Path(step['output']).parent.mkdir(exist_ok=True)
            env=os.environ.copy();env.update(step['environment'])
            def persist(result):step.update(result);save(attempt/'build.json',record)
            result=execute(step['command'],attempt/(step['label']+'.log'),budget,step['timeout_seconds'],record['cleanup_errors'],persist,env)
            step['status']='compiled' if result['status']=='exited' else 'failed';save(attempt/'build.json',record)
            assert step['status']=='compiled',step['label']+' failed; no retry authorized'
            verify();output=Path(step['output']);step['output_sha256']=sha(output);step['status']='passed'
            record['outputs'][step['label']]={'path':str(output),'sha256':step['output_sha256'],'bytes':output.stat().st_size}
            save(attempt/'build.json',record)
        record['status']='completed-awaiting-guards'
    except Exception as error:record.update(status='failed',error=repr(error))
    record['elapsed_seconds']=budget.elapsed();record['deadline_exceeded']=record['elapsed_seconds']>CAP;save(attempt/'build.json',record)
    try:
        verify();record['inputs_unchanged']=True
        record['compiler_logs_sha256']={str(path):sha(path) for path in sorted(attempt.glob('*.log'))}
    except Exception as error:record.update(inputs_unchanged=False,guard_error=repr(error))
    record['elapsed_seconds']=budget.elapsed();record['deadline_exceeded']|=record['elapsed_seconds']>CAP
    record['status']='passed' if len(record['steps'])==4 and all(item['status']=='passed' for item in record['steps']) and record.get('inputs_unchanged')is True and not record['cleanup_errors'] and not record['deadline_exceeded'] and 'error'not in record else 'failed'
    record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(attempt/'build.json',record);budget.disarm()
    print(json.dumps({'status':record['status'],'elapsed_seconds':record['elapsed_seconds'],'steps':[{key:step.get(key)for key in ['label','status','returncode','elapsed_seconds']}for step in record['steps']]}))
    return 0 if record['status']=='passed' else 1
if __name__=='__main__':sys.exit(main())
