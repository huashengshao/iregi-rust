"""Audit saved native-policy whole-call data using only the Python standard library.

This deliberately does not import or execute any producer/admission/validator code,
compiled program, numerical library, or integral evaluator. Run from the project root.
"""
from pathlib import Path
from fractions import Fraction
import datetime
import hashlib
import json
import math
import re
import struct

ROOT = Path.cwd()
HERE = ROOT / "target/native-f64-sixpoint-port/whole"
RUN = HERE / "whole-qualification-001"
OUT = ROOT / "target/resume-20261025-review/whole-runtime-independent-numeric-audit.json"
CHECKS = 0
ORDER = ["finite", "total_single", "ir_double", "uv_single", "ir_single", "derivative_discriminant"]
ARITY = {"A0": 2, "B0": 4, "C0": 7, "dB0": 4, "D0": 11}
POLICIES = {"baseline": "Symbolica", "candidate": "NativeF64Abc"}
CAPTURE_KEYS = {"family", "backend", "components", "rows", "requests", "valid_lanes", "input", "output_order", "output", "errors", "whole_batch_error"}
NORMALIZATION = "abs(a-b)/(E^(4+rank-2*n)+abs(b)); E=max(1,mu,abs(shifts),sqrt(abs(mass_squared)))"


def require(predicate, context="check"):
    global CHECKS
    CHECKS += 1
    if not predicate:
        raise AssertionError(context)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def decode(text):
    def invalid_constant(value):
        raise ValueError("nonstandard JSON constant: " + value)
    return json.loads(text, object_pairs_hook=unique_object, parse_constant=invalid_constant)


def read(path):
    return decode(Path(path).read_text())


def exact(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def array(value, count):
    require(type(value) is list and len(value) == count, ("array length", count))
    return value


def natural(value, expected=None):
    require(type(value) is int and value >= 0, ("natural", value))
    if expected is not None:
        require(value == expected, ("natural value", value, expected))
    return value


def real_metadata(value, domain="f64", finite_field=True, allow_nonfinite=False):
    required = {"rational", "precision", "negative_sign"} | ({"finite"} if finite_field else set())
    require(type(value) is dict and set(value) == required, "number metadata schema")
    precision = natural(value["precision"])
    require(0 < precision <= 2**32 - 1 and type(value["negative_sign"]) is bool)
    if domain in ("f64", "DoubleFloat"):
        require(precision == {"f64": 53, "DoubleFloat": 106}[domain])
    else:
        require(domain == "Float")
    if finite_field:
        require(type(value["finite"]) is bool)
        if not value["finite"]:
            require(allow_nonfinite and value["rational"] is None)
            return None
    require(type(value["rational"]) is str and re.fullmatch(r"-?\d+(?:/[1-9]\d*)?", value["rational"]) is not None)
    rational = Fraction(value["rational"])
    require(rational.denominator & (rational.denominator - 1) == 0)
    if rational:
        require((rational < 0) == value["negative_sign"])
        if domain != "DoubleFloat":
            numerator = abs(rational.numerator)
            odd = numerator >> ((numerator & -numerator).bit_length() - 1)
            require(odd.bit_length() <= precision)
    if domain == "f64":
        native = float(rational)
        require(math.isfinite(native) and Fraction.from_float(native) == rational)
    return rational


def represented(z, domain="f64", finite_field=True, allow_nonfinite=False):
    return tuple(real_metadata(v, domain, finite_field, allow_nonfinite) for v in array(z, 2))


def f64_represented(z, finite_field=True):
    parts = represented(z, "f64", finite_field)
    return tuple(float(q) if q else math.copysign(0., -1. if v["negative_sign"] else 1.) for q, v in zip(parts, z))


def f64_complex(z):
    array(z, 2)
    require(all(type(v) in (int, float) and math.isfinite(v) for v in z), "finite native complex")
    return tuple(z)


def norm(z):
    return math.hypot(*z)


def difference(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def close_report(actual, reported):
    require(type(reported) in (float, int) and math.isfinite(reported))
    require(math.isclose(actual, reported, rel_tol=1e-12, abs_tol=1e-30), ("recomputed maximum", actual, reported))


def expected_execution(batch, groups, rows):
    return {"input_rows": batch, "argument_rows": batch, "master_family_batches": groups,
            "master_rows": rows, "pentagon_box_rows": 0, "reduction_rows": batch,
            "fallback_rows": 0, "fallback_successes": 0, "analytic_rows": 0}


def tensor_compare(actual, reference, case, samples):
    require(actual["stable"] is True and reference["stable"] is True)
    degrees = [0] if case["rank"] == 0 else [0, 1, 1, 1, 1]
    maximum = 0.
    for left, right, sample in zip(array(actual["lanes"], len(samples)), array(reference["lanes"], len(samples)), samples):
        require(left["status"] == right["status"] == "success")
        energy = max(1., sample["mu"], *(abs(x) for p in sample["shifts"] for x in p),
                     *(math.sqrt(math.hypot(*m)) for m in sample["masses"]))
        for a, b, degree in zip(array(left["moments"], len(degrees)), array(right["moments"], len(degrees)), degrees):
            unit = energy ** (4 + degree - 2 * case["n"])
            for av, bv in zip(array(a, 4), array(b, 4)):
                av = f64_complex(av); bv = f64_complex(bv)
                error = difference(av, bv) / (unit + norm(bv))
                require(math.isfinite(error) and error <= 1e-10, ("tensor normalized error", error))
                maximum = max(maximum, error)
    return maximum


def six_compare(a, b, input_values, family):
    scale = max(1., *(norm(z) for z in input_values))
    unit = {"A0": scale, "B0": 1., "C0": 1. / scale}[family]
    maximum = 0.
    for index, (x, y) in enumerate(zip(array(a, 6), array(b, 6))):
        error = difference(x, y) / ((1. if index == 5 else unit) + norm(x))
        require(math.isfinite(error) and error <= 1e-10, ("master normalized error", error))
        if index == 5:
            require(x == y == (0., 0.), "derivative discriminant must be zero")
        maximum = max(maximum, error)
    return maximum


def groups_for(n, rank, batch):
    return {(2, 0): [("B0", [0])], (2, 1): [("B0", [0]), ("A0", [1, 2])],
            (3, 0): [("C0", [0])], (3, 1): [("C0", [0]), ("B0", [1, 2, 3])]}[(n, rank)]


def master_captures(record, n, rank, batch, backend):
    expected = groups_for(n, rank, batch)
    for group, (family, leaves) in zip(array(record["master_captures"], len(expected)), expected):
        require(type(group) is dict and set(group) == CAPTURE_KEYS)
        rows = len(leaves) * batch
        require(group["family"] == family and group["backend"] == backend)
        natural(group["rows"], rows); natural(group["components"], 1)
        require(group["whole_batch_error"] is None and exact(group["errors"], [None] * rows))
        require(exact(group["requests"], [[leaf, lane] for leaf in leaves for lane in range(batch)]))
        require(exact(group["valid_lanes"], list(range(batch))) and group["output_order"] == ORDER)
        for z in array(group["input"], ARITY[family] * rows):
            f64_represented(z)
        for row in array(group["output"], rows):
            for z in array(row, 6):
                f64_represented(z)
    return expected


def validate_whole_response(response, case, samples):
    require(set(response) == {"id", "baseline", "candidate"} and response["id"] == case["id"])
    n = case["n"]; rank = case["rank"]; batch = len(samples)
    degrees = [0] if rank == 0 else [0, 1, 1, 1, 1]
    groups = groups_for(n, rank, batch)
    execution = expected_execution(batch, len(groups), batch * sum(len(leaves) for _, leaves in groups))
    for side, backend in [("baseline", "SymbolicaBatch"), ("candidate", "RustBatch")]:
        value = response[side]
        require(value["id"] == case["id"] and value["stable"] is True)
        require(value["requested_master_policy"] == POLICIES[side])
        require(value["capture_enabled"] is True and value["profiling_enabled"] is False)
        require(value["input_unchanged"] is True and value["own_repeated_outputs_exact"] is True)
        require(type(value["plan_reused"]) is bool)
        for key, expected in [("n", n), ("rank", rank), ("batch", batch), ("iterations", 0)]:
            natural(value[key], expected)
        require(value["total_ns"] == value["elapsed_ns"] == [] and not {"engine", "warmup", "repeats", "private_selected_native"}.intersection(value))
        require(value["scope"] == "untimed public-policy whole-reduction qualification")
        require(exact(value["degrees"], degrees) and exact(value["execution"], execution))
        for count in value["execution"].values():
            natural(count)
        require(exact(value["diagnostics"], [[] for _ in samples]))
        for lane in array(value["lanes"], batch):
            require(lane["status"] == "success" and lane["fallback_used"] is False and lane["analytic_used"] is False)
            moments = [z for moment in array(lane["moments"], len(degrees)) for z in array(moment, 4)]
            for meta, native in zip(array(lane["represented"], 4 * len(degrees)), moments):
                decoded = f64_represented(meta)
                require(all(struct.pack(">d", x) == struct.pack(">d", y) for x, y in zip(decoded, f64_complex(native))), "represented/native mismatch")
        master_captures(value, n, rank, batch, backend)
    master_max = 0.; differences = 0
    for base, cand in zip(response["baseline"]["master_captures"], response["candidate"]["master_captures"]):
        for key in CAPTURE_KEYS - {"backend", "output"}:
            require(exact(base[key], cand[key]), ("cross-backend master metadata", key))
        points = [f64_represented(z) for z in base["input"]]
        for index, (a, b) in enumerate(zip(base["output"], cand["output"])):
            point = points[index * ARITY[base["family"]]:(index + 1) * ARITY[base["family"]]]
            master_max = max(master_max, six_compare([f64_represented(z) for z in a], [f64_represented(z) for z in b], point, base["family"]))
            differences += sum(not exact(x, y) for az, bz in zip(a, b) for x, y in zip(az, bz))
    return {"candidate_vs_baseline": tensor_compare(response["candidate"], response["baseline"], case, samples),
            "masters": {"max_normalized_error": master_max, "represented_component_differences": differences,
                        "master_groups": len(groups), "master_rows": execution["master_rows"], "complex_outputs": execution["master_rows"] * 6}}


def snapshot(value, rows, components, errors, domain):
    require(set(value) == {"rows", "components", "lanes"})
    natural(value["rows"], rows); natural(value["components"], components)
    successes = failures = complex_values = 0
    for lane, error in zip(array(value["lanes"], rows), array(errors, rows)):
        require(set(lane) == {"error", "six_outputs"} and lane["error"] == error)
        if error is not None:
            require(type(error) is str and lane["six_outputs"] is None, "failed lane must be null")
            failures += 1
        else:
            for z in array(lane["six_outputs"], 6 * components):
                represented(z, domain, False)
            successes += 1; complex_values += 6 * components
    return {"successful_lanes": successes, "failed_lanes": failures, "complex_outputs_per_backend": complex_values}


def aggregate(stats, item):
    for key, value in item.items():
        stats[key] = stats.get(key, 0) + value


def selected_controls(groups, prior):
    stats = {"cases": 0, "max_normalized_error": 0., "scaleless_lanes_analytic_values_recomputed": 0}
    details = []
    for group, old, family in zip(array(groups, 3), array(prior, 3), ["A0", "B0", "C0"]):
        require(group["status"] == "passed" and group["family"] == old["family"] == family)
        for key in ["layout_and_overflow_errors_checked", "ordinary_dual_adapter_rejected", "warm_clone_checked"]:
            require(group[key] is True)
        for case, previous in zip(array(group["cases"], len(old["cases"])), old["cases"]):
            for key in ["label", "family", "baseline_backend", "candidate_backend", "input_metadata"]:
                require(exact(case[key], previous[key]))
            require(case["status"] == "passed" and case["baseline_backend"] == "SymbolicaBatch" and case["candidate_backend"] == "RustBatch")
            require(case["input_unchanged"] is True and case["own_repeated_outputs_exact"] is True)
            rows = previous["baseline"]["rows"]
            errors = [v["error"] for v in previous["baseline"]["lanes"]]
            points = array(case["input_metadata"], rows * ARITY[family])
            for z in points:
                represented(z, "f64", True, True)
            a = case["baseline"]; b = case["candidate"]
            item = snapshot(a, rows, 1, errors, "f64")
            require(snapshot(b, rows, 1, errors, "f64") == item)
            aggregate(stats, item)
            maximum = 0.; differences = zeros = 0
            for lane, (left, right) in enumerate(zip(a["lanes"], b["lanes"])):
                if errors[lane] is not None:
                    continue
                av = [f64_represented(z, False) for z in left["six_outputs"]]
                bv = [f64_represented(z, False) for z in right["six_outputs"]]
                inputs = [f64_represented(z) for z in points[lane * ARITY[family]:(lane + 1) * ARITY[family]]]
                maximum = max(maximum, six_compare(av, bv, inputs, family))
                for za, zb in zip(left["six_outputs"], right["six_outputs"]):
                    for x, y in zip(za, zb):
                        differences += not exact(x, y)
                        zeros += Fraction(x["rational"]) == Fraction(y["rational"]) == 0 and x["negative_sign"] != y["negative_sign"]
                if case["label"] == "scaleless":
                    expected = [(0., 0.)] * 6
                    if family == "B0":
                        expected[3] = (1., 0.); expected[4] = (-1., 0.)
                    require(av == bv == expected, "independent scaleless pole cancellation identity")
                    stats["scaleless_lanes_analytic_values_recomputed"] += 1
            close_report(maximum, case["maximum_normalized_error"])
            natural(case["represented_component_differences"], differences); natural(case["signed_zero_differences"], zeros)
            stats["cases"] += 1; stats["max_normalized_error"] = max(stats["max_normalized_error"], maximum)
            details.append({"family": family, "label": case["label"], "successful_rows": item["successful_lanes"],
                            "maximum_normalized_error": maximum, "represented_component_differences": differences, "signed_zero_differences": zeros})
    require(stats["cases"] == 34 and stats["successful_lanes"] == 57 and stats["failed_lanes"] == 21)
    return stats, details


def unchanged_controls(groups, prior, domain="f64"):
    stats = {"groups": 0, "cases": 0}
    for group, old in zip(array(groups, len(prior)), prior):
        for key in ["label", "family", "components", "shape"]:
            require(exact(group[key], old[key]))
        require(group["status"] == "passed" and group["backend"] == "SymbolicaBatch")
        for case, previous in zip(array(group["cases"], len(old["cases"])), old["cases"]):
            require(case["label"] == previous["label"] and exact(case["input_metadata"], previous["input_metadata"]))
            for z in case["input_metadata"]:
                represented(z, domain, True, True)
            require(case["status"] == "passed" and case["input_unchanged"] is True and case["own_repeated_outputs_exact"] is True and case["candidate_exactly_matches_baseline"] is True)
            expected = previous["represented_outputs"]
            masks = [lane["error"] for lane in expected["lanes"]]
            item = snapshot(case["baseline"], expected["rows"], expected["components"], masks, domain)
            snapshot(case["candidate"], expected["rows"], expected["components"], masks, domain)
            snapshot(case["represented_outputs"], expected["rows"], expected["components"], masks, domain)
            require(exact(case["baseline"], case["candidate"]) and exact(case["baseline"], case["represented_outputs"]))
            aggregate(stats, item); stats["cases"] += 1
        stats["groups"] += 1
    return stats


def exact_real(q, bits, imaginary_bits=None):
    def number(value, precision):
        return {"finite": True, "rational": str(Fraction(value)), "precision": precision, "negative_sign": value < 0}
    return [number(q, bits), number(0, bits if imaginary_bits is None else imaginary_bits)]


def precision_controls(groups):
    definitions = [
        ("DoubleFloat_beyond53", "DoubleFloat", [("three_lanes", [106] * 3), ("empty_reuse", []), ("singleton_recovery", [106])]),
        ("Float53_is_not_f64", "Float", [("singleton", [53])]),
    ]
    for bits in [128, 256]:
        definitions.append((f"Float_mixed_prototype{bits}", "Float", [(f"lane_precisions_{precisions}", precisions) for precisions in [[128, 256, 64], [256], [], [64, 128, 256]]]))
    totals = {"groups": 0, "cases": 0}
    for group, (label, domain, cases) in zip(array(groups, 4), definitions):
        require(group["label"] == label and group["family"] == "A0" and group["components"] == 1 and group["shape"] is None)
        require(group["backend"] == "SymbolicaBatch" and group["status"] == "passed")
        for case, (case_label, precisions) in zip(array(group["cases"], len(cases)), cases):
            require(case["label"] == case_label)
            inputs = []
            for precision in precisions:
                if domain == "DoubleFloat":
                    inputs.extend([exact_real(1 + Fraction(1, 2**80), 106), exact_real(1, 106)])
                elif label == "Float53_is_not_f64":
                    inputs.extend([exact_real(2, 53), exact_real(1, 53)])
                else:
                    inputs.extend([exact_real(1 + Fraction(1, 2**(precision - 10)), precision, 128), exact_real(1, 128, 64)])
            require(exact(case["input_metadata"], inputs))
            for z in inputs:
                represented(z, domain)
            require(case["status"] == "passed" and case["input_unchanged"] is True and case["own_repeated_outputs_exact"] is True and case["candidate_exactly_matches_baseline"] is True)
            item = snapshot(case["baseline"], len(precisions), 1, [None] * len(precisions), domain)
            snapshot(case["candidate"], len(precisions), 1, [None] * len(precisions), domain)
            require(exact(case["baseline"], case["candidate"]) and exact(case["baseline"], case["represented_outputs"]))
            for index, lane in enumerate(case["baseline"]["lanes"]):
                expected_uv = [{k: v for k, v in part.items() if k != "finite"} for part in inputs[2 * index]]
                require(exact(lane["six_outputs"][3], expected_uv), "exact A0 UV mass identity")
            aggregate(totals, item); totals["cases"] += 1
        totals["groups"] += 1
    require(totals["cases"] == 12 and totals["successful_lanes"] == 19 and totals["complex_outputs_per_backend"] == 114)
    return totals


def fixed_core_captures(captures, domain, components, backend, mass):
    for group, family, requests, values, derivative_index in zip(array(captures, 2), ["B0", "A0"],
            [[[0, 0]], [[1, 0], [2, 0]]], [[-1, mass, 3, 1], [3, 1, mass, 1]], [1, 2]):
        require(set(group) == CAPTURE_KEYS)
        require(group["family"] == family and group["backend"] == backend and group["components"] == components)
        natural(group["rows"], len(requests)); require(exact(group["requests"], requests) and group["valid_lanes"] == [0])
        require(group["output_order"] == ORDER and group["whole_batch_error"] is None and exact(group["errors"], [None] * len(requests)))
        expected = [Fraction(v) for v in values]
        if components == 2:
            expected = [part for index, q in enumerate(expected) for part in [q, Fraction(index == derivative_index)]]
        for z, q in zip(array(group["input"], 4 * components), expected):
            require(represented(z, domain) == (q, Fraction(0)), "fixed core master input")
        for row in array(group["output"], len(requests)):
            for z in array(row, 6 * components):
                represented(z, domain)


def whole_unchanged(record, label, domain, bits, dual=False, beyond53=False):
    components = 2 if dual else 1
    mass = Fraction(18014398509481985, 9007199254740992) if beyond53 else Fraction(2)
    values = [0, 0, 0, 0, 0, 1, 0, 0, mass, 3, 1]
    if dual:
        values = [part for index, q in enumerate(values) for part in [q, int(index == 8)]]
    require(record["label"] == label and record["components"] == components)
    require(record["own_repeated_outputs_exact"] is True and record["input_unchanged"] is True)
    require(exact(record["input"], [exact_real(v, bits) for v in values]))
    for z in record["input"]:
        represented(z, domain)
    result = record["result"]
    require(result["statuses"] == "[Success]" and exact(result["diagnostics"], [[]]))
    require(exact(result["fallback_used"], [False]) and exact(result["analytic_used"], [False]))
    require(exact(result["execution"], expected_execution(1, 2, 3)))
    for z in array(result["values"], 20 * components):
        represented(z, domain)
    fixed_core_captures(result["master_captures"], domain, components, "SymbolicaBatch", mass)


def cache_controls(record):
    require(record["status"] == "passed" and record["same_immutable_plan"] is True)
    values = array(record["expected_current_process_records"], 4)
    for index, value in enumerate(values):
        components = 2 if index % 2 else 1
        require(value["stable"] is True and exact(value["diagnostics"], [[]]) and exact(value["execution"], expected_execution(1, 2, 3)))
        lane = array(value["lanes"], 1)[0]
        require(lane["status"] == "success" and lane["fallback_used"] is False and lane["analytic_used"] is False)
        for z in array(lane["represented"], 20 * components):
            represented(z)
        if components == 1:
            moments = [z for row in array(lane["moments"], 5) for z in array(row, 4)]
            for meta, native in zip(lane["represented"], moments):
                require(all(struct.pack(">d", x) == struct.pack(">d", y) for x, y in zip(f64_represented(meta), f64_complex(native))))
        else:
            require("moments" not in lane)
        fixed_core_captures(value["master_captures"], "f64", components, "RustBatch" if index == 2 else "SymbolicaBatch", Fraction(2))
    require(exact(values[1], values[3]), "Dual policies complete exact parity")
    for step, index in zip(array(record["steps"], 8), [2, 1, 0, 3, 2, 0, 3, 1]):
        require(step["requested_master_policy"] == ("Symbolica" if index < 2 else "NativeF64Abc"))
        require(step["dual"] is bool(index % 2) and exact(step["result"], values[index]))
    sample = {"shifts": [[0., 0., 0., 0.], [0., 1., 0., 0.]], "masses": [[2., 0.], [3., 0.]], "mu": 1.}
    tensor_error = tensor_compare(values[2], values[0], {"n": 2, "rank": 1}, [sample])
    master_error = 0.
    for a, b in zip(values[0]["master_captures"], values[2]["master_captures"]):
        for key in CAPTURE_KEYS - {"backend", "output"}:
            require(exact(a[key], b[key]))
        points = [f64_represented(z) for z in a["input"]]
        for index, (x, y) in enumerate(zip(a["output"], b["output"])):
            arity = ARITY[a["family"]]
            master_error = max(master_error, six_compare([f64_represented(z) for z in x], [f64_represented(z) for z in y], points[index * arity:(index + 1) * arity], a["family"]))
    return {"expected_records": 4, "interleaved_records_exact": 8, "tensor_max_normalized_error": tensor_error, "master_max_normalized_error": master_error}


def controls(response, inventory):
    require(response["id"] == "controls" and response["status"] == "passed" and exact(response["requested_master_policies"], POLICIES))
    core = response["controls"]
    require(exact(array(core["baseline"], 1), array(core["candidate"], 1)))
    for side in POLICIES:
        whole_unchanged(core[side][0], "f64 Dual N2r1", "f64", 53, dual=True)
        old = inventory["controls"]["baseline"][0]
        for key in ["label", "components", "input"]:
            require(exact(core[side][0][key], old[key]))
        for key in ["statuses", "diagnostics", "fallback_used", "analytic_used", "execution"]:
            require(exact(core[side][0]["result"][key], old["result"][key]))
    masters = core["masters"]; oldmasters = inventory["controls"]["masters"]
    require(masters["status"] == "passed")
    selected, details = selected_controls(masters["selected_families"], oldmasters["selected_families"])
    unchanged = unchanged_controls(array(masters["unchanged_paths"], 6), oldmasters["unchanged_paths"])
    require(unchanged["cases"] == 21 and unchanged["successful_lanes"] == 30 and unchanged["failed_lanes"] == 6 and unchanged["complex_outputs_per_backend"] == 318)
    extended = precision_controls(masters["extended_unchanged_paths"])
    whole_extended = response["extended_unchanged_controls"]
    require(whole_extended["status"] == "passed" and exact(whole_extended["baseline"], whole_extended["candidate"]))
    expected_inventory = [
        {"label": "DoubleFloat N2r1 beyond53", "numeric_type": "DoubleFloat", "precision": 106, "rows": 1, "components": 1, "tensor_complex_values": 20},
        {"label": "Float256 N2r1 beyond53", "numeric_type": "Float", "precision": 256, "rows": 1, "components": 1, "tensor_complex_values": 20},
    ]
    require(exact(whole_extended["inventory"], expected_inventory))
    for side in POLICIES:
        for record, label, domain, bits in zip(array(whole_extended[side], 2), ["DoubleFloat N2r1 beyond53", "Float256 N2r1 beyond53"], ["DoubleFloat", "Float"], [106, 256]):
            whole_unchanged(record, label, domain, bits, beyond53=True)
    actual = response["actual_base_master_controls"]
    require(actual["status"] == "passed" and actual["scope"] == "actual-base Symbolica unchanged master controls; no native policy API or performance claim")
    for key in ["unchanged_paths", "extended_unchanged_paths", "extended_inventory"]:
        require(exact(actual[key], masters[key]), ("actual-base complete masters snapshot", key))
    require(exact(masters["extended_inventory"], [
        {"label": "DoubleFloat_beyond53", "numeric_type": "DoubleFloat", "prototype_precision": 106, "family": "A0", "components": 1, "shape": None, "case_rows": [3, 0, 1]},
        {"label": "Float53_is_not_f64", "numeric_type": "Float", "prototype_precision": 53, "family": "A0", "components": 1, "shape": None, "case_rows": [1]},
    ] + [{"label": f"Float_mixed_prototype{bits}", "numeric_type": "Float", "prototype_precision": bits, "family": "A0", "components": 1, "shape": None, "case_real_mass_precisions": [[128, 256, 64], [256], [], [64, 128, 256]], "case_rows": [3, 1, 0, 3]} for bits in [128, 256]]))
    return {"selected_masters": selected, "selected_case_details": details, "unchanged_f64_paths": unchanged,
            "extended_precision_masters": extended, "actual_base_unchanged_exact_cases": 21, "actual_base_precision_exact_cases": 12,
            "whole_unchanged": {"dual_cases": 1, "dual_complex_values_per_policy": 40, "extended_precision_cases": 2, "extended_complex_values_per_policy": 40},
            "cache": cache_controls(response["cache_interleaving"])}


def rust_payload(case, samples):
    return json.dumps({"id": case["id"], "n": case["n"], "rank": case["rank"], "algorithm": "Hybrid", "samples": samples}) + "\n"


def original_payload(case, samples):
    mu = samples[0]["mu"]
    require(all(sample["mu"] == mu for sample in samples))
    lines = [f'BENCH {case["id"]} 2 {case["n"]} {case["rank"]} {mu:.17g} {len(samples)} 0 1 1']
    for sample in samples:
        for shift, mass in zip(sample["shifts"], sample["masses"]):
            lines.append(" ".join(f"{v:.17g}" for v in shift) + f" ({mass[0]:.17g},{mass[1]:.17g})")
    return "\n".join(lines) + "\n"


def canonical(response):
    result = decode(json.dumps(response, allow_nan=False))
    for side in POLICIES:
        result[side].pop("plan_reused")
    return result


def main():
    result = read(RUN / "results.json")
    require(result["status"] == "passed-awaiting-independent-raw-validation")
    require(result["runtime_cap_seconds"] == 120 and result["request_count"] == 38)
    require(result["inputs_unchanged"] is True and result["deadline_exceeded"] is False and result["cleanup_errors"] == [])
    require(not {"error", "guard_error"}.intersection(result))
    require(type(result["elapsed_seconds"]) in (int, float) and math.isfinite(result["elapsed_seconds"]) and 0 <= result["elapsed_seconds"] <= 120)
    for process, terminal, label, count in zip(array(result["processes"], 2), array(result["process_terminals"], 2), ["TIRust", "IREGI"], [30, 8]):
        require(process["label"] == terminal["label"] == label and process["status"] == "running")
        require(type(process["owned_process_group"]) is int and process["owned_process_group"] > 0)
        require(terminal["owned_process_group"] == process["owned_process_group"] and terminal["returncode"] == 0 and type(terminal["returncode"]) is int)
        require(terminal["owned_group_gone"] is True and terminal["received_responses"] == count)
        require(process["command"][-3:] == ["-c", "22", result["executed_executables"][label]["path"]])
    require(result["processes"][0]["owned_process_group"] != result["processes"][1]["owned_process_group"])
    prep = read(HERE / "preparation.json")
    cases = read(ROOT / prep["whole_inputs"])
    require([(c["id"], c["n"], c["rank"], len(c["samples"])) for c in cases] == [("n2-r0-massive", 2, 0, 32), ("n2-r1-massive", 2, 1, 32), ("n3-r0-massive", 3, 0, 32), ("n3-r1-massive", 3, 1, 32)])
    inventory = read(HERE / "control-inventory.json")["controls"]
    schedule = []
    for case in cases:
        for batch in [1, 32]:
            key = [case["id"], batch]; samples = case["samples"][:batch]
            schedule.extend([("TIRust", "initial", key, rust_payload(case, samples)), ("TIRust", "own-repeat", key, rust_payload(case, samples)), ("IREGI", "reference", key, original_payload(case, samples))])
    schedule.extend([("TIRust", "controls", ["controls", 0], "CONTROLS\n"), ("TIRust", "controls-repeat", ["controls", 1], "CONTROLS\n")])
    for case in cases:
        for batch in [1, 32]:
            schedule.append(("TIRust", "retained", [case["id"], batch], rust_payload(case, case["samples"][:batch])))
    invalid = [("engine", "baseline"), ("warmup", 1), ("repeats", 1), ("iterations", 1)]
    first = decode(rust_payload(cases[0], cases[0]["samples"][:1]))
    for field, value in invalid:
        schedule.append(("TIRust", "invalid-request", [field, value], json.dumps({**first, field: value}) + "\n"))
    require(len(schedule) == 38)
    events = [decode(line) for line in (RUN / "responses.jsonl").read_text().splitlines()]
    require(len(events) == 76)
    pairs = {}; whole = []; control_data = None; admitted_controls = None
    case_map = {c["id"]: c for c in cases}
    emitted = {"TIRust": [], "IREGI": []}
    for serial, (engine, stage, key, payload) in enumerate(schedule, 1):
        request, response = events[2 * (serial - 1):2 * serial]
        for event, kind in [(request, "request"), (response, "response")]:
            require(set(event) == {"serial", "stage", "key", "engine", "payload", "event"} | ({"response"} if kind == "response" else set()))
            require(type(event["serial"]) is int and event["serial"] == serial)
            require(event["event"] == kind and event["engine"] == engine and event["stage"] == stage and exact(event["key"], key) and event["payload"] == payload)
        data = response["response"]; emitted[engine].append(data)
        if stage in ("initial", "own-repeat", "retained"):
            case = case_map[key[0]]; samples = case["samples"][:key[1]]
            stats = validate_whole_response(data, case, samples)
            if stage == "initial":
                pairs[tuple(key)] = data
                whole.append({"id": key[0], "batch": key[1], "tensor_complex_values_per_backend": key[1] * 4 * (1 if case["rank"] == 0 else 5),
                              "master_rows_per_backend": stats["masters"]["master_rows"], "master_complex_values_per_backend": stats["masters"]["complex_outputs"],
                              "maxima": {"candidate_vs_baseline": stats["candidate_vs_baseline"]}, "masters": stats["masters"]})
            else:
                require(exact(canonical(data), canonical(pairs[tuple(key)])), "complete own/retained raw equality")
        elif stage == "reference":
            case = case_map[key[0]]; samples = case["samples"][:key[1]]
            require(data["id"] == key[0] and data["stable"] is True)
            require(type(data["clock_ticks_per_second"]) is int and data["clock_ticks_per_second"] > 0)
            require(len(data["total_ns"]) == 1 and type(data["total_ns"][0]) in (int, float) and math.isfinite(data["total_ns"][0]) and data["total_ns"][0] > 0)
            for side in POLICIES:
                whole[-1]["maxima"][side + "_vs_IREGI"] = tensor_compare(pairs[tuple(key)][side], data, case, samples)
        elif stage in ("controls", "controls-repeat"):
            checked = controls(data, inventory)
            if stage == "controls":
                control_data = data; admitted_controls = checked
            else:
                require(exact(data, control_data) and exact(checked, admitted_controls), "complete controls repeat")
        else:
            require(exact(data, {"status": "invalid_request", "error": "qualification is untimed; engine and timing counts are forbidden"}))
    require(len(whole) == 8 and len(pairs) == 8)
    for label in ["TIRust", "IREGI"]:
        path = RUN / (label + ".stdout.log")
        raw = path.read_bytes(); require(raw.endswith(b"\n"))
        actual = [decode(line[7:]) for line in raw.splitlines() if line.startswith(b"RESULT ")]
        require(exact(actual, emitted[label]), "all stdout RESULT sequences exactly match saved raw")
        require(digest(path) == result["stdout_sha256"][label])
        require(digest(RUN / (label + ".stderr.log")) == result["stderr_sha256"][label])
        require((RUN / (label + ".stderr.log")).read_bytes() == b"", "stderr must remain empty")
    require(digest(RUN / "responses.jsonl") == result["raw_sha256"])
    for field in ["rows", "retained_rows"]:
        require([(v["id"], v["batch"]) for v in array(result[field], 8)] == [(v["id"], v["batch"]) for v in whole])
        require(all(v["status"] == "passed" for v in result[field]))
    for receipt, derived in zip(result["rows"], whole):
        for key, expected in [("status", "passed"), ("errors", []), ("tolerance", 1e-10), ("normalization", NORMALIZATION)]:
            require(exact(receipt["comparison"]["whole_cross_backend"][key], expected))
        close_report(derived["maxima"]["candidate_vs_baseline"], receipt["comparison"]["whole_cross_backend"]["max_error"])
        require(receipt["comparison"]["masters"]["status"] == "passed")
        for key, value in derived["masters"].items():
            if key == "max_normalized_error":
                close_report(value, receipt["comparison"]["masters"][key])
            else:
                natural(receipt["comparison"]["masters"][key], value)
        for side in POLICIES:
            reference = receipt["reference_comparisons"][side]
            require(reference["status"] == "passed" and reference["errors"] == [] and reference["tolerance"] == 1e-10 and reference["normalization"] == NORMALIZATION)
            close_report(derived["maxima"][side + "_vs_IREGI"], reference["max_error"])
    c = result["controls"]
    require(c["status"] == "passed" and c["selected_cases"] == 34 and c["unchanged_cases"] == 21 and c["whole_dual_cases"] == 1 and c["extended_whole_cases"] == 2)
    require(c["actual_base_unchanged_master_cases"] == 21 and c["actual_base_extended_master_cases"] == 12)
    for reported, actual in zip(array(c["selected_recomputed"], 34), admitted_controls["selected_case_details"]):
        for key in actual:
            if key == "maximum_normalized_error":
                close_report(actual[key], reported[key])
            else:
                require(exact(actual[key], reported[key]))
    require(exact(result["invalid_request_controls"], {"status": "passed", "cases": [{"field": field, "value": value, "status": "passed"} for field, value in invalid]}))
    totals = {"families": 8, "tensor_complex_values_per_backend": sum(v["tensor_complex_values_per_backend"] for v in whole),
              "master_rows_per_backend": sum(v["master_rows_per_backend"] for v in whole), "master_complex_values_per_backend": sum(v["master_complex_values_per_backend"] for v in whole)}
    require(totals == {"families": 8, "tensor_complex_values_per_backend": 1584, "master_rows_per_backend": 297, "master_complex_values_per_backend": 1782})
    bound = [Path(__file__), RUN / "results.json", RUN / "responses.jsonl", RUN / "TIRust.stdout.log", RUN / "IREGI.stdout.log", RUN / "TIRust.stderr.log", RUN / "IREGI.stderr.log", HERE / "control-inventory.json", ROOT / prep["whole_inputs"], ROOT / "target/resume-20261025-review/whole-probe-child-review.json"]
    output = {"status": "independent-saved-numerical-raw-audit-passed", "reviewer": "/root/resume_auditor/whole_probe_review",
              "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "scope": "Independent Python standard-library reconstruction from saved raw data. No producer admission.py, validate_whole.py, benchmark helper, compiled binary or evaluator was imported or executed.",
              "source_and_data_sha256": {str(p.relative_to(ROOT)): digest(p) for p in bound},
              "protocol": {"requests": 38, "events": 76, "TIRust_responses": 30, "IREGI_responses": 8, "full_schedule_pairing_exact": True,
                           "stdout_RESULT_sequences_exact": True, "own_and_retained_complete_records_exact": True, "controls_complete_repeat_exact": True,
                           "invalid_timing_requests_rejected": 4, "recorded_process_groups_terminal_and_gone": True, "recorded_elapsed_seconds": result["elapsed_seconds"]},
              "whole": whole, "whole_totals": totals, "controls": admitted_controls,
              "worst_whole_errors": {key: max(v["maxima"][key] for v in whole) for key in whole[0]["maxima"]},
              "tolerance": 1e-10, "checks": CHECKS, "blocking_findings": [],
              "limitations": ["This validates saved numerical correctness for eight retained massive low-point families, not speed, current Cargo feature identity, public N6/N7 coverage or policy promotion.",
                              "Large dependency/compiler/executable closure hashing is independently handled by the parent reviewer; this audit binds only source and saved data relevant to arithmetic and protocol reconstruction.",
                              "Internal direct-master repeats/layout/shape exceptions are asserted in the separately reviewed executed Rust; only first snapshots are exported. Complete CONTROLS repeats, whole-call own/retained records and cache interleaving are independently compared here.",
                              "DoubleFloat equality means exact represented rational, precision and sign, not internal limb-byte equality.",
                              "No high-precision input or output is converted to f64 in admission; f64 conversion is restricted to ordinary f64 observations and their original IREGI comparisons.",
                              "Process termination is audited from sealed saved records, not by launching or probing kernels."]}
    with OUT.open("x") as stream:
        json.dump(output, stream, indent=2, allow_nan=False); stream.write("\n")
    print(json.dumps({"status": output["status"], "path": str(OUT.relative_to(ROOT)), "sha256": digest(OUT), "checks": CHECKS,
                      "whole_totals": totals, "worst_whole_errors": output["worst_whole_errors"]}, sort_keys=True))


if __name__ == "__main__":
    main()
