"""Freeze exact source/artifact reuse and four commands; no compiler or kernel."""
from pathlib import Path
import ast, datetime, hashlib, importlib.util, json
ROOT=Path.cwd(); HERE=ROOT/'target/native-f64-sixpoint-port/whole'; PORT=HERE.parent
PRIOR=ROOT/'target/native-f64-opt-in/qualification'

def sha(path):
    with Path(path).open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save_new(path,value):
    with Path(path).open('x')as stream:stream.write(json.dumps(value,indent=2)+'\n')
def functions(path):
    return {node.name:ast.dump(node,include_attributes=False)for node in ast.parse(Path(path).read_text()).body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))}

def main():
    assert not(HERE/'preparation.json').exists()and not(HERE/'command-plan.json').exists()
    source=read(PORT/'source-inventory.json'); old_prep=read(PRIOR/'observation-preparation.json');old_build=read(PRIOR/'observation-build-001/build.json')
    assert old_build['status']=='passed' and old_build['stage']=='observation' and old_build['inputs_unchanged']is True
    assert old_build['cleanup_errors']==[]and old_build['deadline_exceeded']is False
    assert sha(PORT/'combined.patch')==source['combined_patch_sha256']=='70b5f94487f79d25c9bc831c0895fe2970ba8e222297ba0baf9f683d67101f9a'
    assert sha(HERE/'lifecycle.py')==sha(PRIOR/'lifecycle.py')=='c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824'
    assert sha(HERE/'interactive.py')==sha(PRIOR/'interactive.py')
    assert sha(HERE/'control-inventory.json')==sha(PRIOR/'control-inventory.json')
    assert sha(HERE/'source/master_controls.rs')==sha(PRIOR/'source/master_controls.rs')
    # The runtime schedule/numerical validator is inherited intact; new source metadata checks only surround it.
    before=functions(PRIOR/'validate_whole.py');after=functions(HERE/'validate_whole.py')
    for name in ['payload','exact','schedule','qualify']:assert before[name]==after[name],name
    before=functions(PRIOR/'admission.py');after=functions(HERE/'admission.py')
    assert before.keys()==after.keys()
    for name in before:
        if name!='validate_controls':assert before[name]==after[name],name
    # Never replace old successful six-output/whole-array gates or weaken unchanged precision/sign/error checks.
    assert (HERE/'admission.py').read_text().count('1e-10')==(PRIOR/'admission.py').read_text().count('1e-10')
    bindings={Path(path):value for path,value in old_build['input_sha256'].items()}
    old_expected={**old_prep['input_sha256'],str(PRIOR/'observation-preparation.json'):sha(PRIOR/'observation-preparation.json')}
    assert old_build['input_sha256']==old_expected
    original_variants={};overlay_variants={};overlay_changes={}
    for variant,original,key in [('baseline',PORT/'base','base'),('candidate',PORT/'proposed','proposed')]:
        overlay=HERE/'source'/variant;original_variants[variant]={};overlay_variants[variant]={};changes=[]
        for relative,value in source[key].items():
            original_path=original/relative;assert sha(original_path)==value,str(original_path)
            bindings[original_path]=value;original_variants[variant][relative]=value
            if variant=='baseline':
                assert sha(ROOT/relative)==value,'live baseline drift: '+relative
                bindings[ROOT/relative]=value
            path=overlay/relative;digest=sha(path);bindings[path]=digest;overlay_variants[variant][relative]=digest
            if digest!=value:changes.append(relative)
        added=[str(path.relative_to(overlay))for path in overlay.rglob('*')if path.is_file()and str(path.relative_to(overlay))not in source[key]]
        assert sorted(changes)==['crates/iregi-masters/src/lib.rs','crates/iregi-rust/src/execution.rs','crates/iregi-rust/src/lib.rs']
        assert added==['crates/iregi-rust/src/master_capture.rs']
        path=overlay/added[0];digest=sha(path);bindings[path]=digest;overlay_variants[variant][added[0]]=digest
        assert digest=='616cf5840097d28d691b35b874fdcbe8b01600461b3a0637345a6715db1bb95b'
        overlay_changes[variant]={'changed':sorted(changes),'added':added}
    master_mapping={relative:value for relative,value in overlay_variants['candidate'].items()if relative.startswith('crates/iregi-masters/')}
    assert len(master_mapping)==30
    for relative,value in master_mapping.items():
        path=PRIOR/'source/observation-overlay'/relative
        assert sha(path)==value and old_build['input_sha256'][str(path)]==value,relative
    master_step=next(step for step in old_build['steps']if step['label']=='selective-masters')
    assert master_step['status']=='passed'and master_step['returncode']==0 and master_step['owned_group_gone']is True
    command=master_step['command']; cfg=[command[index+1]for index,token in enumerate(command)if token=='--cfg']
    assert cfg==['feature="default"','feature="native-f64-abc"','iregi_qualification_capture']
    assert 'opt-level=0'in command and '--emit'not in command
    assert str(PRIOR/'source/observation-overlay/crates/iregi-masters/src/lib.rs')in command
    master=old_build['outputs']['selective-masters'];assert sha(master['path'])==master['sha256']=='73e4889ed0a4bfb3785f63041052f1da5031dc567774ddb20be59134d84fd5fe'
    bindings[Path(master['path'])]=master['sha256']
    for relative in ['source-inventory.json','combined.patch','doc-refresh.json','mechanical-checks.json','reviews/independent-source-review.json','qualification/codegen-preparation.json','qualification/codegen-build-001/build.json','qualification/reviews/codegen-build-001-independent-evidence-review.json','qualification/ordinary-tests-001/results.json','qualification/reviews/ordinary20-independent-log-lifecycle-audit.json']:
        path=PORT/relative;bindings[path]=sha(path)
    for relative in ['observation-preparation.json','observation-command-plan.json','observation-build-001/build.json','reviews/observation-admission-source-review.json','whole-qualification-001/independent-evidence-review.json','whole-qualification-001/independent-numerical-audit.json']:
        path=PRIOR/relative;bindings[path]=sha(path)
    # The fresh private tree is small; do not duplicate the large historical whole-call raw corpus.
    for path in HERE.rglob('*'):
        if path.is_file()and '__pycache__'not in path.parts and 'reviews'not in path.relative_to(HERE).parts:
            assert path.suffix not in ['.rlib','.rmeta','.so']
            bindings[path]=sha(path)
            if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    for path,value in bindings.items():assert sha(path)==value,str(path)
    manifest={key:old_prep[key]for key in ['tools','dependency_directory','supplemental_directory','native_directory','externs','whole_inputs','reference']}
    manifest.update(status='actual-base-combined-candidate-whole-source-frozen-no-compilation',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope={'fresh_rustc_products':4,'compile_cpus':[6,7],'build_cap_seconds':180,'per_invocation_seconds':90,'cleanup_reserve_seconds':8,'requests':38,'probe_requests':30,'original_iregi_requests':8,'runtime_cpu':22,'runtime_cap_seconds':120,'timing':False,'cargo':False,'production_mutation':False,'current_cargo_feature_graph_claim':False},
        original_source_mapping=original_variants,overlay_source_mapping=overlay_variants,overlay_changes=overlay_changes,
        reused_candidate_masters={**master,'original_step':master_step,'old_build_receipt':str(PRIOR/'observation-build-001/build.json'),'old_build_receipt_sha256':sha(PRIOR/'observation-build-001/build.json'),'exact_captured_source_files':30},
        direct_master_control_roles={'retained_candidate_policy_comparison':'all old34selected,21unchanged,12precision cases unchanged','new_actual_base_unchanged_snapshot':'same21unchanged+12precision fixtures, complete six-output records exact againstcandidate','selected_abc_actual_base':'wholearrays and capturedmasters coveractualbase/candidate+originalIREGI'},
        input_sha256={str(path):value for path,value in sorted(bindings.items())})
    spec=importlib.util.spec_from_file_location('native_whole_build',HERE/'build.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    steps=module.recipe(HERE/'observation-build-001',manifest);assert len(steps)==4
    save_new(HERE/'preparation.json',manifest)
    save_new(HERE/'command-plan.json',{'status':'four-commands-only-not-executed','preparation_sha256':sha(HERE/'preparation.json'),'steps':steps})
    print(json.dumps({'status':manifest['status'],'bindings':len(bindings),'preparation_sha256':sha(HERE/'preparation.json'),'command_plan_sha256':sha(HERE/'command-plan.json'),'fresh_rustc_products':len(steps)}))
if __name__=='__main__':main()
