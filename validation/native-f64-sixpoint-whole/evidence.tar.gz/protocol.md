# Combined native policy / actual-base whole-call regression

This is a private source and command proposal, not numerical evidence. It uses
current production base and the frozen combined candidate from
`../source-inventory.json` / `../combined.patch`. Nothing in this directory
modifies production, introduces new algebra, changes scalar formulae or enables
the optional policy by default. Root coordinates CPU/build/numerical ownership;
the user's instruction to continue already authorizes routine reversible work.
The named execution-grant files are machine-readable source/budget freezes, not
requests for further user permission.

## Actual source chains and observation overlay

The old 38-request harness compared two public policies inside one candidate
core. This adaptation links two distinct core crates into one untimed harness:

- `iregi_rust_baseline`: every file in the current `../base` snapshot, with its
  actual default Symbolica masters and original `Workspace::new/new_dual` APIs.
- `iregi_rust_candidate`: every file in `../proposed`, selecting
  `NativeF64Abc` explicitly through its public constructors. Native selection is
  restricted to ordinary f64 A0/B0/C0; unchanged paths remain Symbolica.

Each source tree receives precisely the same historical observation-only patch:
three cfg-gated hooks (`iregi-masters/src/lib.rs`, core `src/lib.rs` and
`src/execution.rs`) and the byte-identical `src/master_capture.rs` module. The
master hook exposes its six stored outputs by borrow. Core capture records the
already evaluated batch, without another evaluation or arithmetic operation.
Capture state is separate for the two core crates. All generated scalar formulae,
recurrence instructions, diagnostics and numeric handling remain untouched.
`baseline-observation.patch`, `candidate-observation.patch` and
`overlay-checks.json` enumerate every permitted difference.

The shared `core_probe.rs` retains the historical numerical and schema checks.
Adapters only bridge the actual base's original workspace constructors to the
candidate's explicit policy constructors. Each variant owns a separate structural
plan cache and workspace. The candidate alone runs the existing policy/shape
cache-interleaving control because the actual base has no policy API. These roles
are explicit; the old one-core baseline is not relabeled as current production.

`master_controls.rs` is byte-identical to the reviewed old harness and retains
all selected-ABC and same-candidate policy controls. In addition,
`actual_base_master_controls.rs` selects the *identical existing unchanged
fixtures* through the actual base's `ExactMasterPlan::instantiate`. All six
stored outputs, exact represented rationals, component precision, signs,
inputs/error masks, repeat behavior, lane counts and shapes are emitted. The
new admission requires complete equality against the candidate's 21 unchanged
f64/Dual cases and 12 precision cases. No selected native ABC response from this
additional module is claimed; those are independently checked by the retained
candidate policy controls and whole-array reference comparisons.

## Finite build recipe

`preparation.json` and `command-plan.json` freeze all source, recipes, tools,
inputs, reused artifact bytes and prior provenance before compilation. Use the
same non-Python native-ELF debug dependency closure as the prior qualified native
stage; this is not a claim of current Cargo feature-graph identity. In particular,
Symbolica, OneLoop, serde, thiserror, GMP/MPFR/MPC objects and their recorded
profiles are reused without rebuild or mutation.

The candidate captured masters archive is exactly the old observation selective
archive `73e4889ed0a4bfb3785f63041052f1da5031dc567774ddb20be59134d84fd5fe`.
Every one of its 30 source files, capture cfg, selective cfg, toolchain,
command/environment and full old input closure are bound and checked. Default
and selective ordinary masters/core archives lack the capture API and cannot be
substituted. The old captured core predates the current SixPoint composition and
cannot represent either fresh core tree.

Only four products are freshly compiled, all direct rustc:

1. Actual-base captured default masters.
2. Actual-base captured core, linked only to product 1.
3. Combined candidate captured core, linked to the exact reused candidate masters.
4. One probe linking both distinct core crates and both masters where needed.

Use opt-level 0, debug assertions and overflow checks, Rust 2024 and the frozen
compiler/linker/native closure; compile on CPUs 6,7. The aggregate build cap is
**180 seconds**, including the exact c193 lifecycle's **eight-second reserve**,
all input/output guards and terminal hashing. Each invocation is capped at
90 seconds. Every later step is left unrun after the first failure. There are no
Cargo commands, broad-native runtime, dependency rebuilds or automatic retries.
A frozen source/command review and root-owned stage record precede execution;
there is no need for another user permission round trip.

## Exact retained 38-request protocol

Preserve four identical-input massive N2/N3 rank0/rank1 families, each at batch1
and batch32. The input corpus and original IREGI benchmark/reference-build bytes
are the exact old bound artifacts. The runtime remains **120 seconds aggregate**
including cleanup, final guards and hashing, on CPU22 with one owned probe and
one original IREGI process. No timing mode is allowed.

For each of eight coordinates, send initial and own-repeat requests to TIRust,
then one fixed original IREGI Hybrid reference request: 24 total. Send the same
complete CONTROLS request twice: 2 total. Revisit all eight coordinates with
retained structural caches: 8 total. Reject the same four requests carrying an
engine/warmup/repeats/iterations timing field: 4 total. Thus **30 TIRust + 8 IREGI
requests**, exactly 76 request/response events in fixed order. No fixture, rank,
branch or sample count is silently added or omitted.

Every whole tensor component and native Laurent slot is admitted before any
contraction. The exact previous dimensionally normalized mixed absolute/relative
`1e-10` comparison is retained for both actual base and candidate against
original IREGI and for selected backend differences. All six captured master
outputs are compared at the original gate, and all unchanged numerical paths
require exact represented value, precision, sign (including signed zero),
components, inputs, expected errors and complete metadata. No high-precision
output is routed through f64 admission. Recurrence/master row counts,
fallback/analytic flags, failure outputs, diagnostics and own repeats remain
explicit. Successful outputs must be finite; failed lanes stay null.

`validate_whole.py` retains the exact historical `schedule` and `qualify`
implementations and independently reconstructs every saved pair, RESULT line,
source/binary binding, row, own/retained equality and numerical gate. The
admission's sole mathematical addition is strict equality of the new actual-base
unchanged master snapshots to the already validated candidate snapshots. Full
stdout/stderr/raw/terminal records are saved. The record must show both owned
process groups gone before final hashes; any deadline, cleanup, guard or parser
failure disqualifies the attempt. Never infer child termination from leader exit.

## Boundary after this stage

Even a successful 38-request observation run is an eight-family low-point
correctness regression, not a performance measurement or complete policy
promotion. Retained N6 ordinary paired admission, rank-three Float128/256
reference/convergence and rank-two lifecycle/contraction preservation remain
separate required next stages using the already qualified drivers. Public N6
binary64/DD/Dual, rank seven, generalized and N7 qualification are not inferred.
Only root may integrate the combined patch after all required preservation gates,
then qualify current Cargo forwarding and make fresh matched performance runs.
Preserve every historical failure and inconclusive timing without rewriting it.
