"""Read-only source and saved-ledger review; does not import or run audit.py."""
import ast
from collections import Counter
from decimal import Decimal
from fractions import Fraction
import gzip
import hashlib
import itertools
import json
from pathlib import Path

BASE = Path('/shared/external/iregi/iregi-rust/target/n2-rank7-independent-saved-audit')
checks = []
bindings = {}


def check(label, condition):
    checks.append({'check': label, 'passed': bool(condition)})


def read(name):
    raw = (BASE/name).read_bytes()
    bindings[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    return raw


source = read('audit.py')
receipt_raw = read('receipt.json')
compressed = read('gates.jsonl.gz')
old_source = read('audit-before-exact-control-denominator.py')
old_log = read('audit-attempt-001.log')
receipt = json.loads(receipt_raw)
raw = gzip.decompress(compressed)
records = [json.loads(line) for line in raw.splitlines()]
tree = ast.parse(source)
imports = []
for node in ast.walk(tree):
    if isinstance(node, ast.Import):
        imports.extend(alias.name for alias in node.names)
    elif isinstance(node, ast.ImportFrom):
        imports.append(node.module)
check('stdlib_only_imports', sorted(imports) == sorted([
    'collections', 'decimal', 'fractions', 'itertools', 'gzip', 'hashlib', 'json', 'pathlib', 're']))
check('reviewed_source_matches_receipt', bindings['audit.py']['sha256'] == receipt['review_source_sha256'])
check('only_failed_attempt_source_correction_is_Fraction_denominator',
      old_source.replace(b'return norm2(difference) / max(unit2, norm2(right))',
                         b'return norm2(difference) / Fraction(max(unit2, norm2(right)))') == source)
check('failed_attempt_self_control_preserved', b'ValueError: complex relative denominator' in old_log)
check('compressed_ledger_binding', bindings['gates.jsonl.gz']['sha256'] == receipt['full_gate_ledger']['sha256']
      and len(compressed) == receipt['full_gate_ledger']['bytes'])
check('uncompressed_ledger_binding', hashlib.sha256(raw).hexdigest() == receipt['full_gate_ledger']['uncompressed_sha256']
      and len(raw) == receipt['full_gate_ledger']['uncompressed_bytes'])
check('total_gate_count', len(records) == receipt['full_gate_ledger']['records'] ==
      receipt['independently_reconstructed_gate_records'] == 18480)
expected_counts = {'reference': 7920, 'precision': 3960, 'scaling': 2640, 'analytic_IR_zero': 3960}
counts = Counter(r['kind'] for r in records)
check('gate_counts_by_kind', counts == expected_counts)
basis = sorted((list(t) for t in itertools.product(range(8), repeat=4) if sum(t) <= 7),
               key=lambda t: (sum(t), tuple(-e for e in t)))
check('independent_basis_count', len(basis) == 330)
seen = {kind: set() for kind in expected_counts}
maxima = {}
rows_valid = True
for row in records:
    kind = row['kind']
    rows_valid &= kind in expected_counts and row['monomial'] == basis[row['moment']]
    rows_valid &= 0 <= row['slot'] < 4
    if kind in ('reference', 'analytic_IR_zero'):
        rows_valid &= row['case'] in ('n2-rank7-IBP-Float128-postfix-001', 'n2-rank7-IBP-Float256-postfix-001')
        rows_valid &= row['row'] in (0, 1, 2)
        key = (row['case'], row['row'], row['moment'], row['slot'])
        if kind == 'analytic_IR_zero':
            rows_valid &= row['slot'] in (1,2)
    elif kind == 'precision':
        rows_valid &= row['n'] == 2 and row['row'] in (0,1,2)
        key = (row['row'], row['moment'], row['slot'])
    else:
        rows_valid &= row['n'] == 2 and row['bits'] in (128,256)
        key = (row['bits'], row['moment'], row['slot'])
    rows_valid &= key not in seen[kind]
    seen[kind].add(key)
    squared = Fraction(row['normalized_error_squared_exact'])
    threshold = Fraction(1, 10**20) if kind in ('reference','analytic_IR_zero') else Fraction(1, 2**160)
    displayed = Decimal(row['normalized_complex_error'])
    rows_valid &= Fraction(row['squared_threshold_exact']) == threshold
    rows_valid &= squared >= 0 and row['passed'] is True and squared <= threshold
    rows_valid &= displayed.is_finite() and displayed >= 0
    if kind not in maxima or squared > maxima[kind][0]:
        maxima[kind] = (squared, row)
check('every_saved_gate_coordinate_shape_threshold_and_pass', rows_valid)
check('all_gate_coordinates_complete_and_unique', {k: len(v) for k,v in seen.items()} == expected_counts)
check('receipt_maxima_match_saved_gate_first_maxima', receipt['maxima'] == {k:r for k,(_,r) in maxima.items()})
check('receipt_zero_failures', receipt['findings'] == [] and all(
    receipt['counters'][k+'_failures'] == 0 and receipt['counters'][k+'_slots'] == n
    for k,n in expected_counts.items()))
controls = receipt['parser_and_exact_threshold_controls']
check('33_unique_saved_parser_and_threshold_controls', len(controls) == len(set(controls)) == 33)
check('control_class_counts', Counter(c.split(':',1)[0] for c in controls) == {
    'parse':13, 'reject':12, 'reference':3, 'convergence':3,
    'complex-relative-norm':1, 'dimensional-floor':1})
check('threshold_boundary_controls_present', all(k+':'+side in controls
      for k in ('reference','convergence') for side in ('below','equal','above')))
findings = [c for c in checks if not c['passed']]
review = {
    'status': 'passed_independent_saved_math_source_and_ledger_review' if not findings else 'failed_independent_saved_math_source_and_ledger_review',
    'reviewer': '/root/dual_pilot_finish/n2_saved_math_audit/metadata',
    'review_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'bindings': bindings, 'check_count': len(checks), 'checks': checks, 'findings': findings,
    'source_review_conclusions': [
        'Exact parser produces Fraction values for integer/rational/decimal scientific forms, including D exponents; rejects non-string, nonfinite, malformed and invalid denominator controls.',
        'Acceptance uses exact squared complex residual |left-right|^2/max(unit^2,|reference|^2), with inclusive rational thresholds10^-20 and2^-160. Decimal100 is only used to display errors and reproduce producer summaries.',
        'For N2 in4D with two unit-power propagators, rankr moments have mass dimensionr: unit^2=(chosen mass-unit-squared)^r and uniform scale2 multiplies moments by2^r. Fixed fixture unit-squared values2,8,2 and scale mu3,6,3 are consistent.',
        'Weak compositions are independently enumerated and sorted by total rank then descending Cartesian exponents, giving1+4+10+20+35+56+84+120=330 moments.',
        'Audit reconstructs complete per-case records and requires exact equality with producer cases and counters; all arrays and native Laurent slots are kept, with no projection or UV/IR merging.',
        'Gate counts are7920reference+3960precision+2640scaling+3960IR=18480. Saved gate coordinates are unique and complete; all exact thresholds pass.',
        'First self-control failure is preserved. The only old/current source difference wraps the denominator in Fraction; this fixes integer-control division without changing Fraction-valued production-array arithmetic.',
        'Counter labels do not independently establish instruction-major execution; only the saved counters and bounded source semantics are reviewed.',
    ],
    'limits': [
        'Source inspected and saved gzip verified; audit_saved, controls and main were not imported or executed in this review.',
        'No second mathematical replay is claimed; separate metadata review already bound exact inputs, full arrays, counters and five archived source files.',
        'No native/compiler jobs, PID queries, binary hashes, recursive dependency closure, or Git actions.',
    ],
}
out = BASE/'code-review.json'
if out.exists():
    raise SystemExit('refusing to overwrite code-review.json')
out.write_text(json.dumps(review, indent=2, sort_keys=True)+'\n')
print(json.dumps({'status':review['status'], 'checks':len(checks), 'findings':findings,
                  'receipt_sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
raise SystemExit(bool(findings))
