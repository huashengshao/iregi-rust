#!/usr/bin/env python3
"""Independent bounded saved-file metadata review; no producer imports or native jobs."""
import collections
import decimal
import hashlib
import itertools
import json
import math
from fractions import Fraction
from pathlib import Path

ROOT = Path('/shared/external/iregi/iregi-rust')
BASE = ROOT / 'target/ibp-workspace-preparation-research/n2-rank7-postfix'
OUT = ROOT / 'target/n2-rank7-independent-saved-audit/metadata-review.json'
SNAPSHOT = ROOT / 'target/cli-facade-integration/build-002/source-snapshot'
checks = []
findings = []
bindings = {}


def check(name, condition, detail=None):
    entry = {'check': name, 'passed': bool(condition)}
    if detail is not None:
        entry['detail'] = detail
    checks.append(entry)
    if not condition:
        findings.append(entry)


def read(path):
    data = path.read_bytes()
    bindings[str(path.relative_to(ROOT))] = {
        'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)
    }
    return data


def load(path):
    return json.loads(read(path))


def digest(path):
    return bindings[str(path.relative_to(ROOT))]['sha256']


catalog = load(BASE / 'catalog.json')
comparison = load(BASE / 'comparison.json')
anchors = load(BASE / 'anchors-n2.json')
fixture_path = ROOT / 'validation/public-highpoint/fixture-conditioned_masses.json'
fixture = load(fixture_path)
expected_poles = ['uv1', 'ir1', 'ir2', 'finite']
expected_basis = sorted(
    (list(x) for x in itertools.product(range(8), repeat=4) if sum(x) <= 7),
    key=lambda x: (sum(x), -x[0], -x[1], -x[2], -x[3]),
)
expected_inputs = [
    [['0','0'], ['0','0'], ['0','0'], ['0','0'],
     ['0','0'], ['1','0'], ['0','0'], ['0','0'],
     ['1','0'], ['2','0'], ['3','0']],
    [['0','0'], ['0','0'], ['0','0'], ['0','0'],
     ['0','0'], ['2','0'], ['0','0'], ['0','0'],
     ['4','0'], ['8','0'], ['6','0']],
    [['0','0'], ['0','0'], ['0','0'], ['0','0'],
     ['0','0'], ['1','0'], ['0','0'], ['0','0'],
     ['2','0'], ['2','0'], ['3','0']],
]
expected_settings = {
    'algorithm': 'Ibp', 'convention': 'IregiNative', 'dimension_shift': 0,
    'input_policy': 'Preserve', 'invariants': 'FromShifts', 'powers': [1, 1],
    'propagators': 2, 'rank': 7, 'tensor_weights': 'Components',
}
expected_execution = {
    'analytic_rows': 0, 'argument_rows': 3, 'fallback_rows': 0,
    'fallback_successes': 0, 'input_rows': 3, 'master_family_batches': 2,
    'master_rows': 9, 'pentagon_box_rows': 0, 'reduction_rows': 3,
}

check('basis_count_independent_enumeration', len(expected_basis) == 330)
check('catalog_fixture_path', catalog['fixture'] == str(fixture_path))
check('catalog_fixture_hash', catalog['fixture_sha256'] == digest(fixture_path))
check('catalog_oracle_hash', catalog['oracle_subset_sha256'] == digest(BASE/'anchors-n2.json'))
check('anchor_fixture_hash', anchors['fixture_sha256'] == digest(fixture_path))
check('comparison_protocol_hash', comparison['protocol_sha256'] == digest(BASE/'catalog.json'))
check('fixture_three_sample_ids', [s['id'] for s in fixture['samples']] ==
      ['base', 'scaled_by_two', 'first_mass_squared_plus_one'])
fixture_input = []
for sample in fixture['samples']:
    props = sample['propagators'][:2]
    fixture_input.append(
        [[v, '0'] for prop in props for v in prop['shift']]
        + [prop['mass_squared'] for prop in props] + [[sample['mu'], '0']]
    )
check('fixed_fixture_first_two_propagators_exact', fixture_input == expected_inputs)
check('fixture_unit_powers', all(p['power'] == 1 for s in fixture['samples'] for p in s['propagators'][:2]))
check('catalog_native_pole_order', catalog['expected_scope']['native_Laurent_slots'] == expected_poles)
check('catalog_restricted_scope', catalog['expected_scope']['input_policy'] == 'Preserve'
      and catalog['expected_scope']['actual_algorithm_required'] == 'Ibp'
      and catalog['expected_scope']['full_mode_domain_qualified'] is False
      and catalog['expected_scope']['performance_qualified'] is False)
check('catalog_exact_two_cases', [(c['n'], c['rank'], c['algorithm'], c['working_bits'],
      c['requested_bits'], c['rows']) for c in catalog['cases']] ==
      [(2, 7, 'ibp', 128, 53, 3), (2, 7, 'ibp', 256, 53, 3)])
check('comparison_case_counts', comparison['complete_cases'] == comparison['expected_cases'] == 2)
check('comparison_status_scoped', comparison['status'] == 'passed_restricted_fresh_Cargo_N2_IBP_rank7_postfix')
check('comparison_exclusions', all(comparison[k] is False for k in (
    'original_PV_failures_accepted_as_anchors', 'working_precision_is_achieved_accuracy',
    'full_rank7_domain_qualified', 'Dual_or_dotted_or_dimension_shift_qualified',
    'performance_qualified')))
check('comparison_no_reported_failures', comparison['failures'] == [])
check('comparison_counters_dimensions', comparison['counters'] == {
    'reference_slots': 2*3*330*4, 'precision_slots': 3*330*4,
    'scaling_slots': 2*330*4, 'reference_failures': 0, 'precision_failures': 0,
    'scaling_failures': 0, 'analytic_IR_zero_slots': 2*3*330*2,
    'analytic_IR_zero_failures': 0, 'analytic_convergent_UV_slots': 0,
    'analytic_convergent_UV_failures': 0,
})
check('anchor_three_rows', len(anchors['anchors']) == 3)
anchor_shapes = []
for row, (sample, anchor) in enumerate(zip(fixture['samples'], anchors['anchors'])):
    name = f'anchor_row_{row}'
    check(name+'_identity', anchor['sample'] == sample['id'] and anchor['mode'] == 0
          and anchor['id'] == f'n2_{sample["id"]}_mode0')
    check(name+'_inputs', anchor['exact_propagators'] == sample['propagators'][:2]
          and anchor['exact_scale'] == sample['mu'])
    check(name+'_native_stable', anchor['native_stable'] is True
          and anchor['response']['stable'] is True
          and anchor['response']['id'] == anchor['id'])
    check(name+'_saved_identity_tags', anchor['applicable_identities_pass'] is True
          and anchor['IBP_scaling_pass'] is (True if row < 2 else None))
    moments = anchor['response']['moments']
    check(name+'_pole_order', anchor['response']['poles'] == expected_poles)
    check(name+'_dimensions', len(moments) == 330 and all(len(m)==4 for m in moments)
          and all(len(z)==2 for m in moments for z in m))
    check(name+'_finite_decimal_encodings', all(
        isinstance(v, str) and decimal.Decimal(v).is_finite()
        for m in moments for z in m for v in z))
    anchor_shapes.append([len(moments), 4, 2])

case_summaries = []
for spec, reported in zip(catalog['cases'], comparison['cases']):
    case = spec['id']
    prefix = case + ':'
    result_path = BASE / 'captures' / case / 'result.json'
    receipt_path = BASE / 'captures' / case / 'receipt.json'
    result = load(result_path)
    receipt = load(receipt_path)
    check(prefix+'report_case', reported['case'] == case)
    check(prefix+'report_result_hash', reported['result_sha256'] == digest(result_path))
    check(prefix+'report_receipt_hash', reported['receipt_sha256'] == digest(receipt_path))
    check(prefix+'receipt_catalog_hash', receipt['protocol_sha256'] == digest(BASE/'catalog.json'))
    check(prefix+'receipt_fixture_hash', receipt['inputs'][str(fixture_path)] == digest(fixture_path))
    check(prefix+'receipt_anchor_hash', receipt['inputs'][str(BASE/'anchors-n2.json')] == digest(BASE/'anchors-n2.json'))
    check(prefix+'receipt_spec', receipt['case'] == spec)
    check(prefix+'receipt_terminal_success', receipt['status'] == 'terminal_capture'
          and receipt['driver_status'] == 'all_lanes_success'
          and receipt['driver_ledger_sha256'] == digest(result_path)
          and receipt['inputs_unchanged'] is True and receipt['cleanup_errors'] == []
          and receipt['cancellation'] is None and receipt['performance_evidence'] is False)
    check(prefix+'one_saved_step', len(receipt['steps']) == 1)
    step = receipt['steps'][0]
    argv = step['command']
    check(prefix+'recorded_argv', argv == [catalog['taskset'], '-c', str(spec['cpu']),
          str(BASE/'captures'/case/'highpoint_public-owned'), str(fixture_path),
          '2', '7', 'ibp', str(spec['working_bits']), '53', '3', str(result_path)])
    check(prefix+'recorded_exit_cleanup', step['status'] == 'exited' and step['returncode'] == 0
          and step['owned_group_gone'] is True and step['group_existed_at_cleanup'] is False)
    check(prefix+'recorded_bounded_elapsed', step['timeout_seconds'] == spec['child_cap_seconds'] == 240
          and math.isfinite(step['elapsed_seconds']) and 0 < step['elapsed_seconds'] < 240)
    check(prefix+'result_metadata', result['schema_version'] == 1
          and result['working_bits'] == spec['working_bits'] and result['requested_bits'] == 53
          and result['rows'] == 3 and result['components'] == 1
          and result['fixture'] == str(fixture_path) and result['settings'] == expected_settings
          and result['interface'] == 'ReductionPlan::new; Workspace<Float>::new; Workspace::reduce_batch')
    check(prefix+'exact_serialized_inputs', result['input_exact_rational'] == expected_inputs)
    check(prefix+'success_all_lanes', result['status'] == 'all_lanes_success'
          and result['lane_statuses'] == ['Success']*3
          and result['diagnostics'] == [[], [], []])
    check(prefix+'no_analytic_fallback', result['algorithm_used'] == 'Ibp'
          and result['analytic_used'] == [False]*3 and result['fallback_used'] == [False]*3
          and result['preparation_notes'] == [])
    check(prefix+'execution_counters', result['execution'] == expected_execution
          and reported['execution'] == expected_execution)
    check(prefix+'structural_counters', result['master_count'] == reported['master_count'] == 3
          and result['alias_count'] == reported['alias_count'] == 618)
    check(prefix+'basis_exact_order', result['basis'] == expected_basis)
    check(prefix+'three_lanes', len(result['lanes']) == 3)
    precision = collections.Counter()
    nonzero = collections.Counter()
    complex_slots = 0
    for row, lane in enumerate(result['lanes']):
        check(prefix+f'lane_{row}_metadata', lane['row'] == row and lane['status'] == 'Success')
        moments = lane['moments']
        check(prefix+f'lane_{row}_shape', len(moments) == 330 and all(len(m) == 4 for m in moments))
        scalar_metadata_ok = True
        rational_metadata_ok = True
        ir_zero = True
        for moment in moments:
            for slot, z in enumerate(moment):
                complex_slots += 1
                scalar_metadata_ok &= set(z) == {'real', 'imaginary', 'real_precision', 'imaginary_precision'}
                rational_metadata_ok &= isinstance(z['real'], str) and isinstance(z['imaginary'], str)
                re, im = Fraction(z['real']), Fraction(z['imaginary'])
                if re or im:
                    nonzero[expected_poles[slot]] += 1
                if slot in (1,2):
                    ir_zero &= not re and not im
                for key in ('real_precision', 'imaginary_precision'):
                    value = z[key]
                    scalar_metadata_ok &= type(value) is int and 0 < value <= spec['working_bits']
                    precision[value] += 1
        check(prefix+f'lane_{row}_scalar_metadata', scalar_metadata_ok)
        check(prefix+f'lane_{row}_exact_rational_encodings', rational_metadata_ok)
        check(prefix+f'lane_{row}_saved_IR_slots_exact_zero', ir_zero)
    check(prefix+'complete_complex_slots', complex_slots == reported['slots_compared'] == 3960)
    check(prefix+'precision_bounds_report', min(precision) == reported['stored_component_precision_min']
          and max(precision) == reported['stored_component_precision_max'])
    check(prefix+'precision_metadata_count', sum(precision.values()) == 7920)
    check(prefix+'nonzero_native_UV_retained', nonzero['uv1'] > 0)
    check(prefix+'limitations_explicit', 'Working precision is not a claim' in result['limitations']
          and 'Timings are diagnostic, not performance gates' in result['limitations'])
    case_summaries.append({
        'case': case, 'rows_moments_slots': [3,330,4], 'complex_slots': complex_slots,
        'working_bits': spec['working_bits'], 'requested_bits': 53,
        'stored_component_precision_histogram': dict(sorted(precision.items())),
        'represented_nonzero_native_slots': {p: nonzero[p] for p in expected_poles},
        'execution': result['execution'],
        'recorded_cleanup_only_no_live_PID_query': True,
    })

source_paths = {
    'driver': SNAPSHOT / 'crates/iregi-rust/examples/highpoint_public.rs',
    'types': SNAPSHOT / 'crates/iregi-rust/src/types.rs',
    'convention': SNAPSHOT / 'crates/iregi-rust/src/convention.rs',
    'basis': SNAPSHOT / 'crates/iregi-rust/src/basis.rs',
    'execution': SNAPSHOT / 'crates/iregi-rust/src/execution.rs',
}
sources = {name: read(path).decode() for name, path in source_paths.items()}
for name, path in source_paths.items():
    for spec in catalog['cases']:
        receipt = json.loads((BASE/'captures'/spec['id']/'receipt.json').read_text())
        check('source_binding_'+name+'_'+str(spec['working_bits']),
              receipt['inputs'][str(path)] == digest(path))
check('source_input_scale_mu_not_squared', 'then the renormalization scale mu (not mu²)' in sources['types'])
check('source_exact_input_roundtrip', 'fixture inputs must be represented exactly at working precision' in sources['driver']
      and 'exact_rational().as_ref() != Some(re)' in sources['driver'])
check('source_driver_preserves_four_slot_chunks', 'values.chunks_exact(4)' in sources['driver'])
check('source_native_pole_order', 'Input and output retain `[UV1, IR1, IR2, finite]` ordering.' in sources['convention']
      and '[value.uv, value.ir, value.ir2, value.finite]' in sources['execution'])
check('source_Component_weight_meaning', 'Actual Cartesian tensor components (IREGI ML5_CONVENTION=true).' in sources['types'])
check('source_counter_semantics', 'Each scalar family is called once for all its leaves and active samples.' in sources['execution']
      and 'let rows = group.requests.len();' in sources['execution']
      and 'evaluator.evaluate_batch(&group.input, rows)' in sources['execution'])
check('source_default_Preserve', 'input_policy: InputPolicy::Preserve' in sources['types'])

receipt = {
    'status': 'passed_independent_bounded_saved_N2_rank7_postfix_metadata_review' if not findings else 'failed_independent_saved_metadata_review',
    'reviewer': '/root/dual_pilot_finish/n2_saved_math_audit/metadata',
    'method': 'Own stdlib-only JSON, shape, exact-input, precision-label, counter and bounded archived-source review; no producer code imported or executed.',
    'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'check_count': len(checks), 'findings': findings, 'bindings': bindings,
    'cases': case_summaries, 'anchor_shapes': anchor_shapes,
    'native_pole_order': expected_poles,
    'scope_caveats': [
        'Saved metadata and encodings reviewed; independent numeric agreement belongs to the separate mathematical audit.',
        'Execution counters support two scalar-family batches over nine active leaf/sample requests and three argument/reduction rows; they alone are not an instruction trace.',
        'Stored component precision labels are not achieved accuracy; inputs are exactly representable integers and do not qualify beyond-53-bit input preservation.',
        'Native UV1/IR1/IR2/finite slots remain distinct; these positive-mass fixture IR entries are exactly zero in saved outputs.',
        'Recorded exit/cleanup fields reviewed without live PID queries; no independent absolute chronology or overlap proof is supplied here.',
        'No binaries or compiler products were read or hashed; source binding is to five named archived source files, not a recursive source/dependency closure.',
        'Individual-product fresh-Cargo attribution and successful exit are saved claims; this review does not independently establish compiler or whole-parent-catalog success.',
        'Restricted N2 rank7 ordinary Float128/256, requested53, three fixed rows, Ibp, Preserve, unit powers, dimension shift0, Components, IregiNative.',
        'No full IBP/rank7 domain, Dual, dotted propagators, dimension shift, physical graph, exceptional kinematics, or performance qualification.',
        'Earlier failed/timeout attempts are not upgraded by this review; their history files were not part of this bounded read set.',
    ],
    'prohibited_actions_performed': {
        'native_jobs': False, 'PID_queries': False, 'binary_hashes': False,
        'recursive_closure': False, 'producer_imports_or_execution': False, 'Git': False,
    },
    'checks': checks,
}
if OUT.exists():
    raise SystemExit('refusing to overwrite metadata review')
OUT.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': receipt['status'], 'checks': len(checks), 'findings': findings,
                  'receipt_sha256': hashlib.sha256(OUT.read_bytes()).hexdigest(),
                  'receipt': str(OUT)}, indent=2))
raise SystemExit(bool(findings))
