"""Independent, saved-only N2/rank-seven exact-numeric audit.

This source does not import a producer/controller/comparator, Symbolica, a
reducer, or native tooling.  ``audit_saved`` consumes a small explicit mapping
of saved JSON byte strings and is also suitable for a portable capsule replay.
The only arithmetic is exact accounting of the supplied numbers and published
tolerances; it implements no tensor reduction or symbolic manipulation.
"""

from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction
from itertools import product
import gzip
import hashlib
import json
from pathlib import Path
import re


INPUT = Path("target/ibp-workspace-preparation-research/n2-rank7-postfix")
OUTPUT = Path("target/n2-rank7-independent-saved-audit")
EXPECTED = {
    "catalog.json": "711678656dede22829fd20c52341b8c0f82a0b15931810421f355cd7dc3deaf3",
    "comparison.json": "93b75316059e5cca76410f93dafedcf912c1905601e937fe7e1afe73f5fa37bd",
    "anchors-n2.json": "9f116e99bb2a36d640ed4d24e43c438b338caf4696b69ff3517f59fca15a2308",
    "fixture.json": "ec27f2c5774a18d3d84d2d733e634dae93e9bd4c74523d6f77e8784d13421ada",
}
POLES = ["uv1", "ir1", "ir2", "finite"]
REFERENCE_LIMIT = Fraction(1, 10**20)
CONVERGENCE_LIMIT = Fraction(1, 2**160)
INTEGER_OR_RATIO = re.compile(r"([+-]?\d+)(?:/([+]?[1-9]\d*))?\Z")
DECIMAL = re.compile(r"([+-]?)(\d*)(?:\.(\d*))?(?:[eEdD]([+-]?\d+))?\Z")


def demand(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def decode(raw):
    return json.loads(raw, parse_float=Decimal)


def exact(text):
    """Parse the native integer/rational and quoted-decimal grammars exactly."""
    demand(type(text) is str, "numeric component must be a string")
    value = text.strip()
    match = INTEGER_OR_RATIO.fullmatch(value)
    if match:
        return Fraction(int(match[1]), int(match[2] or "1"))
    match = DECIMAL.fullmatch(value)
    demand(match is not None and bool(match[2] or match[3]), "invalid exact numeric string")
    sign, whole, fractional, exponent = match.groups()
    fractional = fractional or ""
    coefficient = int((whole or "0") + fractional)
    if sign == "-":
        coefficient = -coefficient
    power = int(exponent or "0") - len(fractional)
    return Fraction(coefficient) * Fraction(10) ** power


def norm2(pair):
    return pair[0] * pair[0] + pair[1] * pair[1]


def residual2(left, right, unit2):
    demand(unit2 > 0 and len(left) == len(right) == 2, "invalid complex error inputs")
    difference = (left[0] - right[0], left[1] - right[1])
    return norm2(difference) / max(unit2, norm2(right))


def display(squared):
    with localcontext() as context:
        context.prec = 100
        return str((Decimal(squared.numerator) / Decimal(squared.denominator)).sqrt())


def controls():
    checks = []
    values = {
        "0": Fraction(0), "-0": Fraction(0), "  +17  ": Fraction(17),
        "-9/7": Fraction(-9, 7), "3/+8": Fraction(3, 8),
        "1.25": Fraction(5, 4), "-.125": Fraction(-1, 8),
        "+3.": Fraction(3), "1E+0004": Fraction(10000),
        " -1.25e-3 ": Fraction(-1, 800), "2.5D-2": Fraction(1, 40),
        "9007199254740993": Fraction(9007199254740993),
        "1.00000000000000000000000000000000000001": Fraction(10**38 + 1, 10**38),
    }
    for spelling, answer in values.items():
        demand(exact(spelling) == answer, "parser positive control")
        checks.append("parse:" + spelling)
    for spelling in ("", ".", "NaN", "Infinity", "1/0", "1/-2", "1//2", "0x1", "1 2", "1e", True, 0.25):
        try:
            exact(spelling)
        except (ValueError, TypeError):
            checks.append("reject:" + repr(spelling))
        else:
            raise ValueError("parser accepted malformed/non-string control")
    for label, amplitude, limit in (
        ("reference", Fraction(1, 10**10), REFERENCE_LIMIT),
        ("convergence", Fraction(1, 2**80), CONVERGENCE_LIMIT),
    ):
        for side, multiplier, expected in (
            ("below", Fraction(10**40 - 1, 10**40), True),
            ("equal", Fraction(1), True),
            ("above", Fraction(10**40 + 1, 10**40), False),
        ):
            value = residual2((0, amplitude * multiplier), (0, 0), Fraction(1))
            demand((value <= limit) is expected, "inclusive exact threshold control")
            checks.append(label + ":" + side)
    demand(residual2((3, 5), (3, 4), Fraction(1)) == Fraction(1, 25), "complex relative denominator")
    demand(residual2((3, 5), (3, 4), Fraction(100)) == Fraction(1, 100), "dimensional normalization floor")
    checks.extend(["complex-relative-norm", "dimensional-floor"])
    return checks


def tensor_basis():
    # Independently enumerate weak compositions; sorting fixes IREGI ordering.
    result = sorted((alpha for alpha in product(range(8), repeat=4) if sum(alpha) <= 7),
                    key=lambda alpha: (sum(alpha), tuple(-entry for entry in alpha)))
    demand(len(result) == 330 and Counter(map(sum, result)) == dict(enumerate((1, 4, 10, 20, 35, 56, 84, 120))),
           "weak-composition basis count")
    return [list(alpha) for alpha in result]


def mass_unit2(sample):
    propagators = sample["propagators"][:2]
    candidates = [Fraction(1)]
    for propagator in propagators:
        candidates.append(abs(exact(propagator["mass_squared"][0])))
    difference = [exact(a) - exact(b) for a, b in zip(propagators[0]["shift"], propagators[1]["shift"])]
    candidates.append(abs(difference[0] ** 2 - sum(value ** 2 for value in difference[1:])))
    return max(candidates)


def native_input(sample):
    propagators = sample["propagators"][:2]
    result = [[str(exact(component)), "0"] for propagator in propagators for component in propagator["shift"]]
    result.extend([[str(exact(component)) for component in propagator["mass_squared"]] for propagator in propagators])
    result.append([str(exact(sample["mu"])), "0"])
    return result


def audit_saved(files):
    """Return independent receipt and deterministic full gate ledger bytes."""
    tested_controls = controls()
    for name, expected in EXPECTED.items():
        demand(digest(files[name]) == expected, "changed pinned input: " + name)
    catalog = decode(files["catalog.json"])
    saved = decode(files["comparison.json"])
    anchors_document = decode(files["anchors-n2.json"])
    fixture = decode(files["fixture.json"])
    basis = tensor_basis()
    samples = fixture["samples"]
    demand([sample["id"] for sample in samples] == ["base", "scaled_by_two", "first_mass_squared_plus_one"], "fixed sample names/order")
    demand([mass_unit2(sample) for sample in samples] == [2, 8, 2], "independently reconstructed dimensional units")
    demand(anchors_document["fixture_sha256"] == EXPECTED["fixture.json"], "oracle fixture identity")
    for name in ("reference_validation", "reference_protocol", "original_independent_saved_review"):
        demand(digest(files[name + ".json"]) == anchors_document[name]["sha256"], "direct oracle provenance binding: " + name)
    reference_validation = decode(files["reference_validation.json"])
    historical_review = decode(files["original_independent_saved_review.json"])
    demand(not historical_review["findings"], "saved original reference review must have no findings")
    source_cases = {case["id"]: case for case in reference_validation["cases"]}
    anchors = {}
    for anchor in anchors_document["anchors"]:
        sample_index = next(index for index, sample in enumerate(samples) if sample["id"] == anchor["sample"])
        sample = samples[sample_index]
        demand(anchor["mode"] == 0 and anchor["native_stable"] is True and anchor["applicable_identities_pass"] is True,
               "only admitted pure-IBP stable anchors")
        demand(sample_index == 2 or anchor["IBP_scaling_pass"] is True, "scaling-eligible anchors")
        demand(anchor["exact_propagators"] == sample["propagators"][:2] and exact(anchor["exact_scale"]) == exact(sample["mu"]),
               "reference exact input/routing identity")
        source = source_cases[anchor["id"]]
        demand(source["eligible_IBP_reference_anchor"] is True and source["response"] == anchor["response"],
               "anchor arrays exactly equal independently reviewed source arrays")
        response = anchor["response"]
        demand(response["stable"] is True and response["poles"] == POLES and len(response["moments"]) == 330,
               "full native reference array/pole order")
        parsed = []
        for moment in response["moments"]:
            demand(len(moment) == 4 and all(len(pair) == 2 for pair in moment), "reference complex/Laurent shape")
            parsed.append([tuple(map(exact, pair)) for pair in moment])
        demand(sample_index not in anchors, "duplicate anchor")
        anchors[sample_index] = parsed
    demand(set(anchors) == {0, 1, 2}, "three complete original quad IBP arrays")
    counters = dict.fromkeys(("reference_slots", "precision_slots", "scaling_slots", "reference_failures", "precision_failures",
                             "scaling_failures", "analytic_IR_zero_slots", "analytic_IR_zero_failures", "analytic_convergent_UV_slots",
                             "analytic_convergent_UV_failures"), 0)
    records, ledger, failures, parsed_candidates = [], [], [], {}
    maxima = {}
    precision_histograms = {}
    exact_ir_zero_slots = 0

    def gate(kind, left, right, unit2, limit, witness):
        squared = residual2(left, right, unit2)
        passed = squared <= limit
        error = display(squared)
        row = {"kind": kind, **witness, "normalized_error_squared_exact": str(squared),
               "normalized_complex_error": error, "squared_threshold_exact": str(limit), "passed": passed}
        ledger.append(row)
        counters[kind + "_slots"] += 1
        if not passed:
            counters[kind + "_failures"] += 1
            failures.append(row)
        if kind not in maxima or squared > maxima[kind][0]:
            maxima[kind] = (squared, row)
        return squared, error

    expected_counters = {"analytic_rows": 0, "argument_rows": 3, "fallback_rows": 0, "fallback_successes": 0,
                         "input_rows": 3, "master_family_batches": 2, "master_rows": 9, "pentagon_box_rows": 0, "reduction_rows": 3}
    expected_settings = {"algorithm": "Ibp", "convention": "IregiNative", "dimension_shift": 0, "input_policy": "Preserve",
                         "invariants": "FromShifts", "powers": [1, 1], "propagators": 2, "rank": 7, "tensor_weights": "Components"}
    for case in catalog["cases"]:
        case_id, bits = case["id"], case["working_bits"]
        prefix = "captures/" + case_id + "/"
        receipt, data = decode(files[prefix + "receipt.json"]), decode(files[prefix + "result.json"])
        demand(receipt["status"] == "terminal_capture" and receipt["case"] == case and receipt["protocol_sha256"] == EXPECTED["catalog.json"], "capture identity")
        demand(receipt["inputs_unchanged"] is True and receipt["cleanup_errors"] == [] and receipt["cancellation"] is None,
               "recorded capture terminal outcome")
        demand(len(receipt["steps"]) == 1 and receipt["steps"][0]["returncode"] == 0 and receipt["steps"][0]["owned_group_gone"] is True,
               "recorded successful step (no fresh process claim)")
        demand(receipt["driver_ledger_sha256"] == digest(files[prefix + "result.json"]), "candidate hash binding")
        demand(data["settings"] == expected_settings and data["algorithm_used"] == "Ibp" and data["status"] == "all_lanes_success", "pure IBP settings/outcome")
        demand(data["working_bits"] == bits and data["requested_bits"] == 53 and data["components"] == 1 and data["rows"] == 3,
               "numeric/sample metadata")
        demand(data["basis"] == basis and data["lane_statuses"] == ["Success"] * 3 and len(data["lanes"]) == 3, "complete independent basis/lanes")
        demand(data["input_exact_rational"] == [native_input(sample) for sample in samples], "exact independent candidate input identity")
        demand(data["execution"] == expected_counters and all(type(value) is int for value in data["execution"].values()), "instruction-major batch counters")
        demand(data["fallback_used"] == [False] * 3 and data["analytic_used"] == [False] * 3 and data["diagnostics"] == [[], [], []], "no analytic/fallback route")
        demand(data["master_count"] == 3 and data["alias_count"] == 618 and data["preparation_notes"] == [], "master/preparation metadata")
        rows, histogram, maximum = [], Counter(), Decimal(0)
        for row_index, lane in enumerate(data["lanes"]):
            demand(lane["row"] == row_index and lane["status"] == "Success" and len(lane["moments"]) == 330, "complete lane")
            moments = []
            for index, alpha in enumerate(basis):
                native_moment = lane["moments"][index]
                demand(len(native_moment) == 4, "full candidate native Laurent array")
                unit2 = mass_unit2(samples[row_index]) ** sum(alpha)
                moment = []
                for slot, component in enumerate(native_moment):
                    demand(set(component) == {"real", "imaginary", "real_precision", "imaginary_precision"}, "component schema")
                    for field in ("real_precision", "imaginary_precision"):
                        value = component[field]
                        demand(type(value) is int and 0 < value <= bits, "stored precision bound")
                        histogram[value] += 1
                    pair = (exact(component["real"]), exact(component["imaginary"]))
                    moment.append(pair)
                    witness = {"case": case_id, "row": row_index, "moment": index, "monomial": alpha, "slot": slot}
                    _, error = gate("reference", pair, anchors[row_index][index][slot], unit2, REFERENCE_LIMIT, witness)
                    maximum = max(maximum, Decimal(error))
                    if slot in (1, 2):
                        gate("analytic_IR_zero", pair, (Fraction(0), Fraction(0)), unit2, REFERENCE_LIMIT, witness)
                        exact_ir_zero_slots += int(pair == (0, 0))
                moments.append(moment)
            rows.append(moments)
        parsed_candidates[bits] = rows
        precision_histograms[str(bits)] = {str(key): histogram[key] for key in sorted(histogram)}
        records.append({"case": case_id, "status": "complete_success_array_compared", "receipt_sha256": digest(files[prefix + "receipt.json"]),
                        "result_sha256": digest(files[prefix + "result.json"]), "slots_compared": 3960, "maximum_reference_error": str(maximum),
                        "stored_component_precision_min": min(histogram), "stored_component_precision_max": max(histogram),
                        "algorithm_used": data["algorithm_used"], "preparation_notes": data["preparation_notes"], "master_count": data["master_count"],
                        "alias_count": data["alias_count"], "execution": data["execution"], "diagnostics": data["diagnostics"],
                        "fallback_used": data["fallback_used"], "analytic_used": data["analytic_used"]})
    demand(set(parsed_candidates) == {128, 256}, "both working precision cases present")
    for row_index, sample in enumerate(samples):
        for index, alpha in enumerate(basis):
            for slot in range(4):
                gate("precision", parsed_candidates[128][row_index][index][slot], parsed_candidates[256][row_index][index][slot],
                     mass_unit2(sample) ** sum(alpha), CONVERGENCE_LIMIT,
                     {"n": 2, "row": row_index, "moment": index, "monomial": alpha, "slot": slot})
    for bits in (128, 256):
        for index, alpha in enumerate(basis):
            factor = Fraction(2) ** sum(alpha)
            for slot in range(4):
                base = parsed_candidates[bits][0][index][slot]
                gate("scaling", parsed_candidates[bits][1][index][slot], tuple(value * factor for value in base),
                     mass_unit2(samples[1]) ** sum(alpha), CONVERGENCE_LIMIT,
                     {"n": 2, "bits": bits, "moment": index, "monomial": alpha, "slot": slot})
    demand(counters == saved["counters"], "all independently reconstructed gate/failure counts exactly match producer summary")
    demand(records == saved["cases"], "complete independently reconstructed per-case records/max errors exactly match saved report")
    demand(not failures and saved["failures"] == [] and len(ledger) == 18480, "complete zero-failure 18,480-gate corpus")
    demand(saved["complete_cases"] == saved["expected_cases"] == 2, "complete case accounting")
    demand(saved["status"] == "passed_restricted_fresh_Cargo_N2_IBP_rank7_postfix" and saved["protocol_sha256"] == EXPECTED["catalog.json"], "saved report status/catalog identity")
    demand(saved["comparator_sha256"] == catalog["comparator_sha256"], "comparator attestation identity")
    demand(exact(saved["squared_threshold_exact"]) == REFERENCE_LIMIT and exact(saved["precision_and_scaling_squared_threshold_exact"]) == CONVERGENCE_LIMIT,
           "reported exact squared tolerances")
    demand(exact(saved["precision_and_scaling_tolerance_exact"]) == Fraction(1, 2**80), "reported amplitude convergence tolerance")
    for field in ("original_PV_failures_accepted_as_anchors", "working_precision_is_achieved_accuracy", "full_rank7_domain_qualified",
                  "Dual_or_dotted_or_dimension_shift_qualified", "performance_qualified"):
        demand(saved[field] is False, "no broader qualification: " + field)
    raw_ledger = b"".join((json.dumps(row, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode() for row in ledger)
    compressed_ledger = gzip.compress(raw_ledger, mtime=0)
    receipt = {
        "status": "passed_independent_saved_only_N2_IBP_rank7_postfix_full_math_audit",
        "input_sha256": {name: digest(raw) for name, raw in sorted(files.items())},
        "parser_and_exact_threshold_controls": tested_controls,
        "independently_reconstructed_gate_records": len(ledger),
        "counters": counters,
        "exact_case_records_match": True,
        "case_records": records,
        "maxima": {kind: row for kind, (_, row) in sorted(maxima.items())},
        "stored_component_precision_histograms": precision_histograms,
        "represented_exact_zero_IR_slots": exact_ir_zero_slots,
        "full_gate_ledger": {"path": "gates.jsonl.gz", "sha256": digest(compressed_ledger), "bytes": len(compressed_ledger),
                             "uncompressed_sha256": digest(raw_ledger), "uncompressed_bytes": len(raw_ledger), "records": len(ledger)},
        "findings": [],
        "pure_saved_replay": True,
        "producer_imported_or_executed": False,
        "native_or_compiler_jobs": 0,
        "process_or_binary_checks": 0,
        "zero_projection_or_pole_merging": False,
        "current_process_cleanup_independently_rechecked": False,
        "original_PV_failures_admitted": False,
        "earlier_timeouts_or_cleanup_failures_upgraded": False,
        "working_precision_is_achieved_accuracy": False,
        "full_domain_Dual_dotted_dimension_shift_or_performance_qualified": False,
        "scope": "Two fresh actual-Cargo pure-IBP N2 rank-seven captures, Float128/256, three fixed positive-mass fixture rows, native Components [uv1,ir1,ir2,finite], unit powers, dimension shift zero, Preserve. Direct admitted quad-IBP subset and original reference validation only; no recursive historical closure. Earlier original PV failures/timeouts remain historical failures. Timings are diagnostic only.",
    }
    return receipt, compressed_ledger


def read_inputs():
    files = {name: (INPUT / name).read_bytes() for name in ("catalog.json", "comparison.json", "anchors-n2.json")}
    catalog = decode(files["catalog.json"])
    anchors = decode(files["anchors-n2.json"])
    files["fixture.json"] = Path(catalog["fixture"]).read_bytes()
    for name in ("reference_validation", "reference_protocol", "original_independent_saved_review"):
        files[name + ".json"] = Path(anchors[name]["path"]).read_bytes()
    for case in catalog["cases"]:
        for name in ("receipt.json", "result.json"):
            key = "captures/" + case["id"] + "/" + name
            files[key] = (INPUT / key).read_bytes()
    return files


def main():
    demand(not (OUTPUT / "receipt.json").exists(), "preserve prior audit attempt")
    files = read_inputs()
    receipt, ledger = audit_saved(files)
    receipt["review_source_sha256"] = digest(Path(__file__).read_bytes())
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / "gates.jsonl.gz").write_bytes(ledger)
    raw = (json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()
    (OUTPUT / "receipt.json").write_bytes(raw)
    print(json.dumps({"status": receipt["status"], "receipt_sha256": digest(raw), "review_source_sha256": receipt["review_source_sha256"],
                      "gate_records": receipt["independently_reconstructed_gate_records"], "findings": receipt["findings"]}))


if __name__ == "__main__":
    main()
