"""Saved-only exact Fraction N2 rank7 IBP postfix qualification with fresh owned Cargo artifact.

No reducer, master, Symbolica, native reference, compiler or numerical producer
is imported/invoked. Original stable quad IBP supplies the reference arrays;
known original PV failures remain rejected diagnostics.
"""
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
ROOT = Path.cwd().resolve()
HERE = Path(__file__).resolve().parent
THRESHOLD2 = Fraction(1, 10**20)
PRECISION_SCALING_THRESHOLD2 = Fraction(1, 2**160)


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def error(left, right, unit_squared, threshold2=THRESHOLD2):
    squared = sum((a-b)**2 for a,b in zip(left,right))/max(unit_squared, sum(v*v for v in right))
    with localcontext() as c:
        c.prec = 100
        display = str((Decimal(squared.numerator)/Decimal(squared.denominator)).sqrt())
    return squared <= threshold2, display


def scale_squared(sample, n):
    props = sample["propagators"][:n]
    scale = max(Fraction(1), *(abs(Fraction(p["mass_squared"][0])) for p in props))
    for i, a in enumerate(props):
        for b in props[:i]:
            q = [Fraction(x)-Fraction(y) for x,y in zip(a["shift"],b["shift"])]
            scale = max(scale, abs(q[0]**2-sum(v*v for v in q[1:])))
    return scale


def complex_rows(response):
    require(response["stable"] is True and response["poles"] == ["uv1","ir1","ir2","finite"],
            "stable native quad IBP and correct Laurent slots required")
    require(len(response["moments"]) == 330, "incomplete independent reference array")
    result = []
    for row in response["moments"]:
        require(len(row) == 4 and all(len(z) == 2 for z in row), "reference complex/Laurent shape")
        result.append([tuple(Fraction(v) for v in z) for z in row])
    return result


def input_row(sample, n):
    row = [[str(Fraction(v)), "0"] for prop in sample["propagators"][:n] for v in prop["shift"]]
    row += [[str(Fraction(v)) for v in prop["mass_squared"]] for prop in sample["propagators"][:n]]
    row.append([str(Fraction(sample["mu"])), "0"])
    return row


def main():
    output = HERE/"comparison.json"
    require(not output.exists(), "preserve existing saved comparison")
    protocol = read(HERE/"catalog.json")
    require(sha(protocol["oracle_subset"]) == protocol["oracle_subset_sha256"], "unchanged admitted N2 oracle subset")
    oracle = read(protocol["oracle_subset"])
    for name in ("reference_validation", "reference_protocol", "original_independent_saved_review"):
        item = oracle[name]
        require(sha(item["path"]) == item["sha256"], "changed admitted independent oracle provenance "+name)
    fixture = read(protocol["fixture"])
    require(sha(protocol["fixture"]) == protocol["fixture_sha256"] and len(fixture["samples"]) == 3,
            "frozen exact three-sample fixture")
    samples = fixture["samples"]
    basis = [[t,x,y,r-t-x-y] for r in range(8) for t in range(r,-1,-1)
             for x in range(r-t,-1,-1) for y in range(r-t-x,-1,-1)]
    require(oracle["fixture_sha256"] == protocol["fixture_sha256"], "oracle fixture identity")
    anchors = {}
    for case in oracle["anchors"]:
        sample = next(sample for sample in samples if sample["id"] == case["sample"])
        require(case["mode"] == 0 and case["native_stable"] is True
                and case["applicable_identities_pass"] is True
                and (sample["id"] == samples[2]["id"] or case["IBP_scaling_pass"] is True), "admitted pure quad IBP anchor required")
        require(case["exact_propagators"] == sample["propagators"][:2]
                and Fraction(case["exact_scale"]) == Fraction(sample["mu"]), "exact oracle input identity")
        anchors[2, sample["id"]] = complex_rows(case["response"])
    require(len(anchors) == 3, "all three independent N2 IBP arrays required")
    records, failures, parsed = [], [], {}
    counters = {"reference_slots":0, "precision_slots":0, "scaling_slots":0,
                "reference_failures":0, "precision_failures":0, "scaling_failures":0,
                "analytic_IR_zero_slots":0, "analytic_IR_zero_failures":0,
                "analytic_convergent_UV_slots":0, "analytic_convergent_UV_failures":0}
    for case in protocol["cases"]:
        directory = HERE/"captures"/case["id"]
        try:
            receipt = read(directory/"receipt.json")
            require(receipt["status"] == "terminal_capture" and receipt["inputs_unchanged"] is True
                    and not receipt["cleanup_errors"] and receipt["cancellation"] is None
                    and receipt["protocol_sha256"] == sha(HERE/"catalog.json")
                    and receipt["case"] == case and len(receipt["steps"]) == 1
                    and receipt["steps"][0]["owned_group_gone"] is True
                    and receipt["steps"][0]["returncode"] == 0, "capture failed/rejected/incomplete")
            data = read(directory/"result.json")
            require(sha(directory/"result.json") == receipt["driver_ledger_sha256"], "driver ledger changed")
            n, bits = case["n"], case["working_bits"]
            expected_settings = {"propagators":n,"rank":7,"powers":[1]*n,"dimension_shift":0,
                "algorithm":"Ibp","convention":"IregiNative","tensor_weights":"Components",
                "invariants":"FromShifts","input_policy":"Preserve"}
            require(data["status"] == "all_lanes_success" and data["settings"] == expected_settings
                    and data["working_bits"] == bits and data["requested_bits"] == 53
                    and data["rows"] == 3 and data["components"] == 1 and data["basis"] == basis
                    and data["lane_statuses"] == ["Success"]*3 and len(data["lanes"]) == 3,
                    "public input/settings/complete success metadata differs")
            require(data["input_exact_rational"] == [input_row(s,n) for s in samples], "candidate exact input identity")
            require(data["algorithm_used"] == "Ibp"
                    and len(data["diagnostics"]) == len(data["fallback_used"]) == len(data["analytic_used"]) == 3
                    and all(isinstance(v,bool) for v in data["fallback_used"]+data["analytic_used"]),
                    "branch/diagnostic metadata incomplete")
            require(not any(data["fallback_used"] + data["analytic_used"]), "original regular pure-IBP cohort must not use analytic or fallback lanes")
            execution = data["execution"]
            expected_counters = {"input_rows","argument_rows","master_family_batches","master_rows",
                "pentagon_box_rows","reduction_rows","fallback_rows","fallback_successes","analytic_rows"}
            require(set(execution) == expected_counters and execution["input_rows"] == 3
                    and all(type(v) is int and v >= 0 for v in execution.values())
                    and execution["fallback_successes"] <= execution["fallback_rows"], "execution counters invalid")
            rows = []
            maximum, nonzero_precisions = Decimal(0), set()
            for row_index, (lane, sample) in enumerate(zip(data["lanes"], samples)):
                require(lane["row"] == row_index and lane["status"] == "Success"
                        and len(lane["moments"]) == 330, "incomplete successful lane")
                moments = []
                s2 = scale_squared(sample,n)
                for index, (alpha, moment) in enumerate(zip(basis,lane["moments"])):
                    require(len(moment) == 4, "incomplete candidate Laurent slots")
                    unit2 = s2**(sum(alpha)+4-2*n)
                    values = []
                    for slot, z in enumerate(moment):
                        require(set(z) == {"real","imaginary","real_precision","imaginary_precision"}
                                and all(type(z[k]) is int and 0 < z[k] <= bits for k in
                                ("real_precision","imaginary_precision")), "stored component precision metadata invalid")
                        nonzero_precisions.update((z["real_precision"],z["imaginary_precision"]))
                        value = (Fraction(z["real"]), Fraction(z["imaginary"]))
                        values.append(value)
                        ok, display = error(value,anchors[n,sample["id"]][index][slot],unit2)
                        counters["reference_slots"] += 1
                        maximum = max(maximum,Decimal(display))
                        if not ok:
                            counters["reference_failures"] += 1
                            failures.append({"kind":"quad_IBP_reference","case":case["id"],"row":row_index,
                                "moment":index,"monomial":alpha,"slot":slot,"normalized_complex_error":display})
                        identity = "analytic_IR_zero" if slot in (1,2) else (
                            "analytic_convergent_UV" if slot == 0 and 4+sum(alpha)-2*n < 0 else None)
                        if identity:
                            counters[identity+"_slots"] += 1
                            passed, residual = error(value,(Fraction(0),Fraction(0)),unit2)
                            if not passed:
                                counters[identity+"_failures"] += 1
                                failures.append({"kind":identity,"case":case["id"],"row":row_index,
                                    "moment":index,"slot":slot,"normalized_complex_error":residual})
                    moments.append(values)
                rows.append(moments)
            parsed[n,bits] = rows
            records.append({"case":case["id"],"status":"complete_success_array_compared",
                "receipt_sha256":sha(directory/"receipt.json"),"result_sha256":sha(directory/"result.json"),
                "slots_compared":3960,"maximum_reference_error":str(maximum),
                "stored_component_precision_min":min(nonzero_precisions),"stored_component_precision_max":max(nonzero_precisions),
                "algorithm_used":data["algorithm_used"],"preparation_notes":data["preparation_notes"],
                "master_count":data["master_count"],"alias_count":data["alias_count"],
                "execution":execution,"diagnostics":data["diagnostics"],
                "fallback_used":data["fallback_used"],"analytic_used":data["analytic_used"]})
        except Exception as problem:
            records.append({"case":case["id"],"status":"failed_rejected_or_incomplete_capture","reason":repr(problem)})
            failures.append({"kind":"capture","case":case["id"],"reason":repr(problem)})
    for n in (2,):
        if (n,128) in parsed and (n,256) in parsed:
            for row,sample in enumerate(samples):
                s2 = scale_squared(sample,n)
                for index,alpha in enumerate(basis):
                    for slot in range(4):
                        ok,display = error(parsed[n,128][row][index][slot], parsed[n,256][row][index][slot],s2**(sum(alpha)+4-2*n),PRECISION_SCALING_THRESHOLD2)
                        counters["precision_slots"] += 1
                        if not ok:
                            counters["precision_failures"] += 1
                            failures.append({"kind":"precision_pair","n":n,"row":row,"moment":index,"slot":slot,"normalized_complex_error":display})
        for bits in (128,256):
            if (n,bits) not in parsed:
                continue
            for index,alpha in enumerate(basis):
                factor = Fraction(2)**(sum(alpha)+4-2*n)
                for slot in range(4):
                    expected = tuple(v*factor for v in parsed[n,bits][0][index][slot])
                    ok,display = error(parsed[n,bits][1][index][slot],expected,
                        scale_squared(samples[1],n)**(sum(alpha)+4-2*n),PRECISION_SCALING_THRESHOLD2)
                    counters["scaling_slots"] += 1
                    if not ok:
                        counters["scaling_failures"] += 1
                        failures.append({"kind":"uniform_scaling","n":n,"bits":bits,"moment":index,"slot":slot,"normalized_complex_error":display})
    complete = len(parsed) == 2 and counters["reference_slots"] == 7920 and counters["precision_slots"] == 3960 and counters["scaling_slots"] == 2640
    report = {"status":"passed_restricted_fresh_Cargo_N2_IBP_rank7_postfix" if complete and not failures else "failed_or_incomplete_restricted_corpus",
        "protocol_sha256":sha(HERE/"catalog.json"),"comparator_sha256":sha(__file__),
        "squared_threshold_exact":str(THRESHOLD2),"reference_tolerance":"1e-10 mixed absolute/relative per dimensionally normalized complex slot",
        "precision_and_scaling_tolerance_exact":"1/1208925819614629174706176",
        "precision_and_scaling_squared_threshold_exact":str(PRECISION_SCALING_THRESHOLD2),
        "complete_cases":len(parsed),"expected_cases":2,"counters":counters,"cases":records,"failures":failures,
        "original_PV_failures_accepted_as_anchors":False,"working_precision_is_achieved_accuracy":False,
        "full_rank7_domain_qualified":False,"Dual_or_dotted_or_dimension_shift_qualified":False,
        "performance_qualified":False,"scope":"N2 IBP rank7 native Components unitpowers Preserve three original exact positive-mass fixture rows; fresh actual-Cargo owned artifact/context with scoped Symbolica condition facts; Float128/256, req53. Earlier timeouts remain unchanged. Full raw arrays are retained in captures."}
    output.write_text(json.dumps(report,indent=2,allow_nan=False)+"\n")
    print(json.dumps({"status":report["status"],"complete_cases":len(parsed),"counters":counters,
                      "failures":len(failures),"comparison_sha256":sha(output)}))
    return 0 if complete and not failures else 1


if __name__ == "__main__":
    sys.exit(main())
