"""Two conditional root-authorized fresh-artifact N2 IBP rank-seven captures.

No compiler, new reference producer, source edits or automatic retries. The
fresh owned Cargo executable and passed eighteen-test gate are prerequisites.
"""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,sys,time
sys.dont_write_bytecode=True
ROOT=Path.cwd().resolve();HERE=Path(__file__).resolve().parent

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save(path,value):
    temporary=path.with_suffix('.partial');temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)
def require(ok,reason):
    if not ok:raise ValueError(reason)

def main():
    catalog_path=HERE/'catalog.json';p=read(catalog_path)
    require(p.get('root_execution_grant_received') is True,'fixed conditional root grant required')
    require(p['aggregate_total_seconds']==660 and p['cleanup_reserve_seconds']==60 and p['saved_compare_cap_seconds']==20,'fixed aggregate bounds')
    require([(c['n'],c['rank'],c['algorithm'],c['working_bits'],c['requested_bits'],c['rows'],c['cpu'],c['child_cap_seconds']) for c in p['cases']]==[(2,7,'ibp',128,53,3,10,240),(2,7,'ibp',256,53,3,12,240)],'two exact sequential cases')
    gate=p['library_tests'];require(sha(gate['path'])==gate['sha256'],'eighteen-test gate identity')
    qualified=read(gate['path']);require(qualified['status']=='passed' and qualified.get('completed_selected_tests')==18 and qualified.get('inputs_unchanged') is True and not qualified['cleanup_errors'],'eighteen-test prerequisite')
    fresh=p['fresh_artifact'];require(fresh['path'] and fresh['sha256'] and fresh['build_receipt_path'] and fresh['build_receipt_sha256'],'actual fresh artifact binding required')
    require(sha(fresh['build_receipt_path'])==fresh['build_receipt_sha256'],'fresh actual Cargo receipt identity')
    built=read(fresh['build_receipt_path'])
    require(built['status']=='passed-owned-highpoint-product' and built.get('inputs_unchanged_at_product_capture') is True and built['command_result']['status']=='exited' and built['command_result']['returncode']==0 and built['command_result']['owned_group_gone'] is True and built.get('owned_process_group_absent') is True,'actual selected highpoint product must pass; unrelated whole catalog need not be terminal')
    require(built['product']['path']==fresh['path'] and built['product']['sha256']==fresh['sha256'] and built['cargo_artifact']['target']['name']=='highpoint_public','successful product identity')
    helper=Path(p['lifecycle']);require(sha(helper)==p['lifecycle_sha256'],'reviewed longer cleanup helper')
    spec=importlib.util.spec_from_file_location('owned_n2_postfix',helper);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
    budget=h.Budget(660);budget.work_deadline=budget.deadline-60
    directory=HERE/'execution-001';directory.mkdir(exist_ok=False)
    receipt=directory/'receipt.json';record={'status':'preflight','catalog_sha256':sha(catalog_path),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':[],'unrun_labels':[c['id'] for c in p['cases']],'cleanup_errors':[],'steps':[],'performance_qualified':False,'full_rank7_domain_qualified':False}
    guards={str(catalog_path):sha(catalog_path),str(Path(__file__).resolve()):p['runner_sha256'],str(HERE/'compare.py'):p['comparator_sha256'],str(helper):p['lifecycle_sha256'],p['fixture']:p['fixture_sha256'],p['oracle_subset']:p['oracle_subset_sha256'],gate['path']:gate['sha256'],fresh['path']:fresh['sha256'],fresh['build_receipt_path']:fresh['build_receipt_sha256']}
    # Reuse the owner's already copied immutable source context; do not freeze
    # live sources again or guard the deliberately mutable unrelated catalog.
    guards.update(built['inputs'])
    if fresh.get('handover_path'):guards[fresh['handover_path']]=fresh['handover_sha256']
    oracle=read(p['oracle_subset'])
    for name in ('reference_validation','reference_protocol','original_independent_saved_review'):
        item=oracle[name];guards[item['path']]=item['sha256']
    def verify(deadline):
        for path,digest in guards.items():require(time.monotonic()<deadline and sha(path)==digest,'changed guarded input '+path)
    env=os.environ.copy();env.update(p['profile_environment']);env['RUST_TEST_THREADS']='1'
    require(env.get('SYMBOLICA_LICENSE'),'source private license before capture')
    complete=False;save(receipt,record);budget.arm()
    try:
        verify(budget.work_deadline)
        for case in p['cases']:
            out=HERE/'captures'/case['id'];out.mkdir(parents=True,exist_ok=False)
            row={'status':'preflight','case':case,'protocol_sha256':sha(catalog_path),'steps':[],'cleanup_errors':[],'cancellation':None,'performance_evidence':False}
            record['cases'].append({'id':case['id'],'status':'running','receipt':str(out/'receipt.json')});record['unrun_labels'].remove(case['id']);save(out/'receipt.json',row);save(receipt,record)
            try:
                verify(budget.work_deadline)
                owned=h.freeze_binary(fresh['path'],fresh['sha256'],out/'highpoint_public-owned',budget);guards[str(owned)]=fresh['sha256']
                command=[p['taskset'],'-c',str(case['cpu']),str(owned),p['fixture'],'2','7','ibp',str(case['working_bits']),'53','3',str(out/'result.json')]
                step={};row['steps'].append(step)
                def persist(value):step.update(value);save(out/'receipt.json',row)
                result=h.execute(command,out/'step.log',budget,240,row['cleanup_errors'],persist,env)
                result_path=out/'result.json'
                if result_path.exists():
                    data=read(result_path);row.update(driver_ledger_sha256=sha(result_path),driver_status=data.get('status'))
                else:data={}
                require(result.get('returncode')==0 and result.get('status')=='exited' and result.get('owned_group_gone') is True and not result.get('timeout') and not row['cleanup_errors'] and not budget.cancelled,'native capture failed or incomplete')
                require(data.get('status')=='all_lanes_success' and data.get('lane_statuses')==['Success']*3 and data.get('working_bits')==case['working_bits'] and data.get('requested_bits')==53 and data.get('rows')==3 and data.get('components')==1 and len(data.get('basis',[]))==330 and len(data.get('lanes',[]))==3 and all(len(lane.get('moments',[]))==330 for lane in data['lanes']),'first complete successful full-array prerequisite')
                row['status']='terminal_capture'
            except BaseException as error:row.update(status='failed_or_incomplete',error=repr(error))
            finally:
                try:verify(budget.deadline-1);row['inputs_unchanged']=True
                except BaseException as error:row.update(inputs_unchanged=False,post_guard_error=repr(error),status='failed_or_incomplete')
                row.update(cancellation=budget.cancelled,inputs=dict(guards));save(out/'receipt.json',row)
                record['cases'][-1].update(status=row['status'],receipt_sha256=sha(out/'receipt.json'))
                record['cleanup_errors'].extend(row['cleanup_errors']);save(receipt,record)
            require(row['status']=='terminal_capture' and row['inputs_unchanged'] is True,'stop after first failed capture; preserve remaining UNRUN labels')
        step={};record['steps'].append(step)
        def persist_compare(value):step.update(value);save(receipt,record)
        compared=h.execute([p['taskset'],'-c','10',sys.executable,str(HERE/'compare.py')],directory/'comparison.log',budget,20,record['cleanup_errors'],persist_compare,env)
        require(compared.get('status')=='exited' and compared.get('returncode')==0 and compared.get('owned_group_gone') is True,'saved comparison failed')
        report=read(HERE/'comparison.json');require(report['status']=='passed_restricted_fresh_Cargo_N2_IBP_rank7_postfix' and report['counters']['reference_slots']==7920 and report['counters']['precision_slots']==3960 and report['counters']['scaling_slots']==2640 and not report['failures'],'complete exact all-slot gates')
        record['comparison_sha256']=sha(HERE/'comparison.json');record['status']='passed_restricted_N2_rank7_IBP_postfix';complete=True
    except BaseException as error:record.update(status='failed_or_incomplete',error=repr(error))
    finally:
        budget.disarm()
        try:verify(budget.deadline-1);record['inputs_unchanged']=True
        except BaseException as error:record.update(inputs_unchanged=False,post_guard_error=repr(error))
        record.update(elapsed_seconds=budget.elapsed(),cancellation=budget.cancelled,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if not complete or not record.get('inputs_unchanged') or record['cleanup_errors'] or budget.cancelled or budget.elapsed()>660:record['status']='failed_or_incomplete'
        save(receipt,record)
    print(json.dumps({'status':record['status'],'receipt_sha256':sha(receipt),'elapsed_seconds':record['elapsed_seconds'],'unrun_labels':record['unrun_labels']}))
    return 0 if complete and record['status']=='passed_restricted_N2_rank7_IBP_postfix' else 1
if __name__=='__main__':raise SystemExit(main())
