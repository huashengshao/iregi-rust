# Corrected ThinLTO provenance proposal

This directory contains read-only evidence and a proposal. It grants no compilation, integral evaluation, timing or production adoption.

The first matched opt3 build stopped after four baseline archives and a successful baseline captured probe compiler process. The immutable build receipt failed because the linker map did not contain original pure Rust archive paths. Rust 1.99 `add_static_crate` removes those objects after ThinLTO and can omit empty archives; preserving the failed criterion is correct. See `../reviews/thinlto-link-map-source-followup.json`.

`lower-admission-inputs.json` is the completed scoped proof, SHA `2795e02bb2032578d168eb2a440cf662716885641274a72e354071cf14556399`. It validates 2,416 metadata dependency edges against four fresh project root identities and 127 observed lower root identities. The 108 non-sysroot archives were already hash guarded in the first build. Full metadata for 19 sysroot companions is newly observed from `.rmeta`; original matching `.rlib` bindings are separately preserved. No new metadata file is falsely claimed as an original pre-run guard.

The first exhaustive read-only lower inspection stopped after 108 successes because listing the link-stub `panic_unwind.rlib` metadata caused a compiler decoder ICE. That failed scope is preserved in `lower-metadata/proof.json`. A separately authorized 60-second scope read the 19 full `.rmeta` companions successfully in 1.58 seconds, recorded in `sysroot-rmeta-supplement/receipt.json`. The ICE report was moved byte-for-byte from project root into `lower-metadata`; `ice-relocation.json` records its original path and SHA. No same-file retry was performed.

Fresh baseline crate hashes:

- Symbolica: `7c84847822fd5e68c9ccd704c897511c`
- OneLoop: `df6743efc68dcc154eaf324551cb1842`
- masters: `2d43ff82d3f0ad5994be769c0cc53ddd`
- captured core: `51d93eda6769d5a443b3c0951cad178b`

Each downstream archive explicitly records its own fresh predecessors. Ten observed stale archive/rmeta root identities are disjoint. The compiler's `locator.rs` rejects hash-mismatched dependencies. Exact argv, fixed explicit extern paths, source/output byte guards and the observed metadata graph together form the proposed pre-LTO input proof. This is not an operating-system trace of all compiler opens and does not assert that the first attempt's entire broad search directory was inventoried before compilation.

The 108-entry `closed_lower_symlink_inventory` covers every direct lower extern in all 14 original commands. A separately reviewed continuation should make this the complete lower search directory for only the nine unrun products, preserving flags/features/source and fresh per-variant externs. It should hash guard filenames, symlink targets and target bytes, observe metadata for every newly built project archive, retain final linker maps as transformed/native evidence, and label reused five products under corrected provenance. Do not rewrite original failure as a passing original map proof.

The existing captured probe has supplemental SHA `c951c1e4cbe1885069181f58e22308387468694862599aabf10ca2e92c2c4587`. The original runner computed and checked its hash in memory but failed before persisting its output object. Its first durable byte-hash record is this supplemental preparation; preserve that distinction.

All commands must run from `/shared/external/iregi/iregi-rust`. Metadata-only command pattern, with bootstrap only in that child:

```sh
source scripts/env.sh
env RUSTC_BOOTSTRAP=1 /nix/store/1qg7z7i461qsv0lczc40nyi8ps6snlca-rustc-1.99.0/bin/rustc -Zls=root /absolute/hash-bound/library.rlib
```

Use the reviewed owned-process lifecycle helper and fixed bounds when running that pattern. No source `.rs`, codegen flag, executable-under-test or integral is involved. `complete_provenance.py` independently revalidates saved metadata/hashes and refuses to overwrite the completed proof; it does not run a subprocess. `inspect_lower.py` is preserved as the failed first read-only scope, not an instruction to retry it.

The exact build continuation, merged product admission and later 60-request numerical protocol are separate artifacts prepared by the parent. The suggested continuation envelope is 2,400 seconds with 30 seconds reserve on CPU 32,33, pending final review and root coordination. No mathematical, precision or performance gate changes. Numerical and performance qualification remain false.
