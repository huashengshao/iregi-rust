"""Read-only metadata root/dependency proof; never compile source or run a kernel."""
from pathlib import Path
import hashlib,json,os,re,sys
ROOT=Path('/shared/external/iregi/iregi-rust');HERE=ROOT/'target/guard-performance-review/optimized-performance-proposal';OUT=HERE/'provenance-v3-research/lower-metadata'
sys.path.insert(0,str(HERE));from fresh_lifecycle import Budget,execute
RUSTC='/nix/store/1qg7z7i461qsv0lczc40nyi8ps6snlca-rustc-1.99.0/bin/rustc'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def parse(text):
 name=re.search(r'^name (.+)$',text,re.M);root=re.search(r'^hash ([0-9a-f]+) stable_crate_id (.+)$',text,re.M);assert name and root
 return {'name':name[1],'crate_hash':root[1],'stable_crate_id':root[2],'dependencies':dict(re.findall(r'^\d+ ([\w-]+) hash ([0-9a-f]+)',text,re.M))}
def main():
 assert Path.cwd()==ROOT;OUT.mkdir(exist_ok=False);protocol=json.loads((HERE/'fresh-build-protocol.json').read_text());bindings={Path(k)if Path(k).is_absolute()else ROOT/k:v for k,v in protocol['protected_sha256'].items()};by_name={}
 for p,h in bindings.items():by_name.setdefault(p.name,[]).append((p,h))
 fresh={parse(p.read_text())['name']:parse(p.read_text())for p in OUT.parent.glob('fresh-*.txt')};todo={}
 for item in fresh.values():
  for name,ch in item['dependencies'].items():
   if name in fresh:assert fresh[name]['crate_hash']==ch
   else:assert name not in todo or todo[name]==ch;todo[name]=ch
 record={'status':'preparing','scope':'read-only rustc -Zls=root lower ABI metadata','budget_seconds':120,'cleanup_errors':[],'steps':[],'fresh':fresh,'bindings':{}};receipt=OUT/'proof.json';budget=Budget(120);budget.work_deadline=budget.deadline-10;budget.arm()
 def save():receipt.write_text(json.dumps(record,indent=2)+'\n')
 try:
  done={}
  while todo:
   name,wanted=todo.popitem()
   if name in done:assert done[name]['crate_hash']==wanted;continue
   choices=[v for suffix in ['.rlib','.so']for v in by_name.get('lib'+name+suffix,[])];assert len(choices)==1,(name,choices);path,expected=choices[0];assert sha(path)==expected
   step={'name':name,'artifact':str(path),'sha256':expected};record['steps'].append(step)
   def persist(result):step.update(result);save()
   env=dict(os.environ);env['RUSTC_BOOTSTRAP']='1';log=OUT/(name+'.txt');result=execute([RUSTC,'-Zls=root',str(path)],log,budget,3,record['cleanup_errors'],persist,env);assert result['status']=='exited';actual=parse(log.read_text());assert actual['name']==name and actual['crate_hash']==wanted,(name,wanted,actual);assert sha(path)==expected
   step.update(metadata=actual,metadata_sha256=sha(log));done[name]=actual;record['bindings'][str(path)]=expected
   for dep,ch in actual['dependencies'].items():
    if dep in fresh:assert fresh[dep]['crate_hash']==ch
    elif dep in done:assert done[dep]['crate_hash']==ch
    else:assert dep not in todo or todo[dep]==ch;todo[dep]=ch
   save()
  record.update(status='passed',root_identities=len(done),elapsed_seconds_diagnostic=budget.elapsed());save()
 finally:budget.disarm()
 print(json.dumps({'status':record['status'],'root_identities':len(record['steps']),'receipt_sha256':sha(receipt),'elapsed_seconds_diagnostic':budget.elapsed()}))
if __name__=='__main__':main()
