"""Validate saved metadata observations and construct a scoped provenance proof.
No compiler subprocess, source compilation, integral or timing occurs here.
"""
from pathlib import Path
import hashlib,json,re,datetime
ROOT=Path('/shared/external/iregi/iregi-rust');HERE=ROOT/'target/guard-performance-review/optimized-performance-proposal';OUT=HERE/'provenance-v3-research'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def parse(text):
 name=re.search(r'^name (.+)$',text,re.M);root=re.search(r'^hash ([0-9a-f]+) stable_crate_id (.+)$',text,re.M);assert name and root
 return {'name':name[1],'crate_hash':root[1],'stable_crate_id':root[2],'dependencies':dict(re.findall(r'^\d+ ([\w-]+) hash ([0-9a-f]+)',text,re.M))}
def main():
 assert Path.cwd()==ROOT
 protocol=read(HERE/'fresh-build-protocol.json');assert sha(HERE/'fresh-build-protocol.json')=='4821d86ef2ecfc5be1490da7b88f631a22db9386cc02697f7b506897dd1fac67'
 buildpath=HERE/'fresh-build-001/build.json';build=read(buildpath);assert sha(buildpath)=='9069bc03597f0a423ef1271257472ce90e79b685b8f2e5f7d6f8824ee88386d8';assert build['status']=='failed' and build['guard_before'] and build['guard_after'] and not build['cleanup_errors']
 bindings={Path(k)if Path(k).is_absolute()else ROOT/k:v for k,v in protocol['protected_sha256'].items()};by_name={p.name:(p,h)for p,h in bindings.items()}
 for path,h in bindings.items():assert sha(path)==h
 initial=read(OUT/'metadata-inspection.json');assert initial['status']=='passed' and len(initial['steps'])==14;fresh={};stale=[]
 for step in initial['steps']:
  assert step['status']=='exited' and step['returncode']==0 and step['owned_group_gone'];path=Path(step['artifact']);assert sha(path)==step['sha256'];log=OUT/(step['label']+'.txt');assert sha(log)==step['metadata_sha256'];item={**parse(log.read_text()),'artifact':str(path),'sha256':sha(path),'metadata_path':str(log),'metadata_sha256':sha(log)}
  if step['label'].startswith('fresh-'):fresh[item['name']]=item
  else:stale.append(item)
 assert set(fresh)=={'symbolica','oneloop','iregi_masters','iregi_rust'}
 for item in build['outputs'].values():assert sha(Path(item['path']))==item['sha256']
 fresh_hash={n:v['crate_hash']for n,v in fresh.items()};assert all(x['crate_hash']not in fresh_hash.values()for x in stale)
 expected={}
 for item in fresh.values():
  for name,ch in item['dependencies'].items():
   if name in fresh:assert fresh[name]['crate_hash']==ch
   else:assert name not in expected or expected[name]==ch;expected[name]=ch
 assert len(expected)==127
 failed=read(OUT/'lower-metadata/proof.json');assert len(failed['steps'])==109 and failed['steps'][-1]['status']=='failed' and failed['steps'][-1]['returncode']==101 and failed['steps'][-1]['owned_group_gone'];lower={}
 for step in failed['steps'][:-1]:
  assert step['status']=='exited' and step['returncode']==0 and step['owned_group_gone'];item=dict(step['metadata']);name=item['name'];path=Path(step['artifact']);log=OUT/'lower-metadata'/(name+'.txt');assert sha(log)==step['metadata_sha256'] and sha(path)==step['sha256'];assert item==parse(log.read_text());assert expected[name]==item['crate_hash'];assert bindings[path]==step['sha256'];lower[name]={**item,'artifact':str(path),'sha256':sha(path),'metadata_path':str(log),'metadata_sha256':sha(log),'original_guarded_artifact':str(path),'original_guarded_sha256':sha(path),'metadata_context_origin':'actual root metadata of archive guarded before and after original build'}
 assert len(lower)==108
 supplement=read(OUT/'sysroot-rmeta-supplement/receipt.json');assert supplement['status']=='passed' and len(supplement['steps'])==19
 for step in supplement['steps']:
  assert step['status']=='exited' and step['returncode']==0 and step['owned_group_gone'];path=Path(step['artifact']);log=OUT/'sysroot-rmeta-supplement'/(step['name']+'.txt');assert sha(path)==step['sha256'] and sha(log)==step['metadata_sha256'];item=parse(log.read_text());name=item['name'];assert name not in lower and expected[name]==item['crate_hash'];guarded=path.with_suffix('.rlib');assert bindings[guarded]==sha(guarded);lower[name]={**item,'artifact':str(path),'sha256':sha(path),'metadata_path':str(log),'metadata_sha256':sha(log),'original_guarded_artifact':str(guarded),'original_guarded_sha256':sha(guarded),'metadata_context_origin':'NEW supplemental full sysroot rmeta root identity; original guarded matching-name rlib remains separately bound. No original rmeta guard claimed.'}
 assert set(lower)==set(expected)
 identities={**{n:v['crate_hash']for n,v in lower.items()},**fresh_hash};edges=0
 for item in [*lower.values(),*fresh.values()]:
  for name,ch in item['dependencies'].items():assert identities.get(name)==ch,(item['name'],name,ch);edges+=1
 closed={Path(v['artifact']).name:{'target':v['artifact'],'sha256':v['sha256'],'name':n,'crate_hash':v['crate_hash']}for n,v in lower.items()if not v['artifact'].startswith('/nix/store/')};assert len(closed)==108
 direct=set()
 for step in protocol['steps']:
  for p in step['explicit_externs'].values():
   if '/6b24c03-complete-kinds/deps/' in p:direct.add(p)
 assert direct<={x['target']for x in closed.values()}
 probe=Path(protocol['steps'][4]['output']);linkmap=Path(protocol['steps'][4]['link_map']);s=build['steps'][4];assert s['status']=='exited' and s['returncode']==0 and s['owned_group_gone'];assert probe.read_bytes()[:4]==b'\x7fELF'
 source_files=[HERE/'fresh-build-protocol.json',buildpath,OUT/'metadata-inspection.json',OUT/'lower-metadata/proof.json',OUT/'sysroot-rmeta-supplement/receipt.json',Path(__file__),OUT/'inspect_lower.py'];proof={'schema_version':1,'status':'completed_readonly_project_dependency_identity_proof_no_build','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual metadata identity graph from existing fresh archives,108 original guarded lower archives and19 newly bound full sysroot rmeta companions. No source compilation, integral, test or timing. This is a corrected pre-LTO compiler-input provenance proof, not an original archive-path link-map proof.','source_sha256':{str(p):sha(p)for p in source_files},'original_failed_build_receipt':str(buildpath),'original_failed_build_receipt_sha256':sha(buildpath),'original_failure_preserved':True,'original_full_search_directory_was_pre_guarded':False,'fresh':fresh,'lower_roots':lower,'lower_root_counts':{'actual_guarded_non_sysroot_archives':108,'new_full_sysroot_rmeta_observations':19,'total_observed_lower_root_identities':127},'validated_metadata_dependency_edges':edges,'closed_lower_symlink_inventory':closed,'new_sysroot_rmeta_bindings':{v['artifact']:v['sha256']for v in lower.values()if v['artifact'].startswith('/nix/store/')},'original_guarded_sysroot_rlibs':{v['original_guarded_artifact']:v['original_guarded_sha256']for v in lower.values()if v['artifact'].startswith('/nix/store/')},'stale_root_observations':stale,'fresh_root_hashes_disjoint_from_all_observed_stale_roots':True,'reusable_baseline_probe':{'path':str(probe),'sha256':sha(probe),'bytes':probe.stat().st_size,'link_map':str(linkmap),'link_map_sha256':sha(linkmap),'compiler_returncode':0,'compiler_owned_group_gone':True,'source_of_command':'original build receipt steps[4] and protocol steps[4], identical argv','identity_scope':'Probe byte hash first persisted by this supplemental preparation; original runner computed it before map gate and checked its in-memory value in final guards, but did not persist the probe output object due map assertion. Do not claim original durable output SHA record exists.','original_map_gate_passed':False},'metadata_decoder_failure_preserved':{'receipt':str(OUT/'lower-metadata/proof.json'),'receipt_sha256':sha(OUT/'lower-metadata/proof.json'),'artifact':failed['steps'][-1]['artifact'],'returncode':101,'owned_group_gone':True,'description':'First full sysroot rlib root listing panicked MemDecoder exhausted; no same-file retry. Separate authorized full rmeta scope observed all19 root identities successfully.'},'numerical_qualified':False,'performance_qualified':False,'production_adoption_authorized':False};output=OUT/'lower-admission-inputs.json';assert not output.exists();output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'proof':str(output.relative_to(ROOT)),'sha256':sha(output),'lower_roots':len(lower),'edges':edges,'closed_lower_entries':len(closed),'probe_sha256':sha(probe)}))
if __name__=='__main__':main()
