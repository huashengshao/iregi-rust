"""UNEXECUTED runner. Invoke only for the exact stage separately granted by root."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/shared/external/iregi/iregi-rust')
PACKET = ROOT / 'target/guard-performance-review/qualification-plan-v2'


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def dump(path: Path, obj: object) -> None:
    path.write_text(json.dumps(obj, indent=2) + '\n')


def check_guard(protocol: dict) -> None:
    for path, expected in {**protocol['protected_sha256'], **protocol['tool_sha256']}.items():
        actual_path = Path(path) if Path(path).is_absolute() else ROOT / path
        if sha(actual_path) != expected:
            raise RuntimeError('Guard mismatch: ' + path)


def execute(command: list[str], env: dict[str, str], cap: float, directory: Path, label: str) -> dict:
    started = time.monotonic()
    item = {'command': command, 'timeout_seconds': cap, 'started_unix_time': time.time()}
    with (directory / (label + '.stdout')).open('wb') as out, (directory / (label + '.stderr')).open('wb') as err:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=out, stderr=err, start_new_session=True)
        item['pid'] = process.pid
        try:
            item['exit_code'] = process.wait(timeout=cap)
            item['timed_out'] = False
        except BaseException as error:
            item['timed_out'] = isinstance(error, subprocess.TimeoutExpired)
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
            item['exit_code'] = process.returncode
            if not item['timed_out']:
                raise
    item['elapsed_seconds_diagnostic'] = time.monotonic() - started
    item['stdout_sha256'] = sha(directory / (label + '.stdout'))
    item['stderr_sha256'] = sha(directory / (label + '.stderr'))
    return item


if len(sys.argv) != 3 or sys.argv[1] not in ['compile', 'tests']:
    raise SystemExit('Expected separately authorized stage: run_stage.py compile|tests REVIEWED_PROTOCOL_SHA256')
stage, reviewed_hash = sys.argv[1:]


def interrupted(signum: int, _frame: object) -> None:
    raise KeyboardInterrupt('Received signal ' + str(signum))


signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)
protocol_path = PACKET / 'protocol.json'
assert sha(protocol_path) == reviewed_hash, 'Protocol changed since review'
protocol = json.loads(protocol_path.read_text())
directory = PACKET / ('compile-001' if stage == 'compile' else 'tests-001')
directory.mkdir(exist_ok=False)
receipt = {'scope': stage, 'protocol_sha256': reviewed_hash, 'runner_sha256': sha(Path(__file__)), 'steps': [], 'success': False, 'tirust_reduction_kernel_evaluation': False, 'performance_measurement': False}
code = 1
try:
    assert Path.cwd() == ROOT, 'Run commands from the project root'
    assert not os.environ.get('RUSTC_BOOTSTRAP'), 'Do not alter the reviewed stable compiler semantics'
    check_guard(protocol)
    receipt['guard_before'] = True
    env = dict(os.environ)
    env.update(protocol['compile_environment_overrides'])
    env['RUST_TEST_THREADS'] = '1'
    if stage == 'compile':
        item = execute(protocol['compile_command'], env, protocol['compile_timeout_seconds'], directory, 'compile')
        receipt['steps'].append(item)
        assert item['exit_code'] == 0 and not item['timed_out'], 'Compiler failed or exceeded its cap; no retry authorized'
        binary = Path(protocol['binary'])
        receipt['binary_sha256'] = sha(binary)
        receipt['binary_bytes'] = binary.stat().st_size
    else:
        previous = json.loads((PACKET / 'compile-001/receipt.json').read_text())
        assert previous['success'] and previous['guard_after']
        assert previous['protocol_sha256'] == reviewed_hash
        binary = Path(protocol['binary'])
        assert sha(binary) == previous['binary_sha256']
        receipt['binary_sha256'] = previous['binary_sha256']
        deadline = time.monotonic() + protocol['test_total_timeout_seconds']
        for definition in protocol['test_stages']:
            remaining = deadline - time.monotonic()
            assert remaining > 0, 'Total test cap exhausted'
            command = protocol['compile_command'][:3] + [str(binary)] + definition['args']
            item = execute(command, env, min(definition['timeout_seconds'], remaining), directory, definition['name'])
            receipt['steps'].append(item)
            assert item['exit_code'] == 0 and not item['timed_out'], 'Test failed or exceeded its cap; stop'
            output = (directory / (definition['name'] + '.stdout')).read_text()
            if 'expected_test_count' in definition:
                names = re.findall(r'^(.+): test$', output, re.MULTILINE)
                assert len(names) == definition['expected_test_count'], 'Incorrect actual batch/focused test inventory'
            else:
                assert re.search(r'test result: ok\. ' + str(definition['expected_pass_count']) + r' passed; 0 failed;', output), 'Expected tests did not all run'
    check_guard(protocol)
    receipt['guard_after'] = True
    receipt['success'] = True
    code = 0
except BaseException as error:
    receipt['failure'] = type(error).__name__ + ': ' + str(error)
    try:
        check_guard(protocol)
        receipt['guard_after'] = True
    except BaseException as guard_error:
        receipt['guard_after'] = False
        receipt['guard_failure'] = type(guard_error).__name__ + ': ' + str(guard_error)
finally:
    dump(directory / 'receipt.json', receipt)
print(json.dumps({'stage': stage, 'success': receipt['success'], 'receipt_sha256': sha(directory / 'receipt.json')}))
raise SystemExit(code)
