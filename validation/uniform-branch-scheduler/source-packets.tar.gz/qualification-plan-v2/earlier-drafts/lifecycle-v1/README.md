# Private uniform-branch qualification v2 — source-only proposal

This packet is **unexecuted**. It proposes one isolated, non-Python Symbolica unit-test build while the live wheel build continues. It changes no live source, Cargo files, dependency artifacts, guards, numerical predicates or tolerances. Root must review the final protocol and explicitly grant each execution stage.

The production candidate remains SHA `6db2acb4b342e5fb1ac78ac04f39abaf72541acff7279ddce505fcfe095a53bf`. Removing test-only instrumentation from the private candidate reproduces that file exactly. Removing one trace hook and reversing two mechanical names from `uniform_branch_baseline.rs` reproduces the actual frozen original production evaluator prefix, SHA `eb73974b0c176422863e4fbe512d392813d83085b2ae5c476db24d028012efcf` for the complete original file. The original five batch tests occur once in the candidate module; the baseline has no duplicate test/symbol registrations.

`source/symbolica` contains all 85 current Symbolica source files plus six package/provenance files and two added test-only source modules: 93 files total. `source-inventory.json` binds the 91 original files and 93 private files. `prepare_private.py` checks the mechanical transformations and live-source preservation. The snapshot uses Symbolica's actual instruction types, arithmetic, evaluator, Dualizer and scheduler; it is not a reconstructed interpreter.

`extern-map.json` recovers 28 exact direct non-Python extern identities by matching the historical Symbolica Cargo dependency-fingerprint integers to little-endian fingerprint receipts and then requiring the corresponding immutable archive. All 116 files in the retained complete dependency/native closure are SHA checked, including GMP/MPFR/MPC. The exact compatible features are `bincode,float-mpfr,integer-gmp,native_code_generation,serde,tracing_max_level_info`; Python, NumPy, FeynKit and Typst features are absent.

No compatible incremental-cache reuse was established. The prior full optimized Symbolica unit-test build took 1,093 seconds; it does not predict this new opt0 build's duration. The old log does not contain its exact rustc command. This protocol reconstructs the exact features, extern identities and required build-script environment, then deliberately declares new opt0/debug-assertions/overflow-checks settings, eight codegen units, no LTO/debuginfo and the pinned compiler/linker. No dependency compilation or Cargo command is proposed.

The proposed compile uses CPUs `32,33`, one 180-second cap and three seconds of process-group cleanup. Root may reject that affinity/cap before freezing approval. `protocol.json` gives the full argument array; `run_stage.py` checks every bound source/artifact/tool before and after, records complete stdout/stderr, kills the whole process group on timeout or interruption, and stops on a failure without retrying. A compiler/API failure or timeout must remain visible before proposing any repair or longer attempt.

After a separate test grant, the first gate lists the actual five existing batch tests plus six focused tests and requires all 11 to run. Four existing nested/shared evaluator tests run separately. Per-command caps are 15/30/60 seconds with a 180-second total test cap. The license is inherited through the supported environment and its value is never logged.

The focused tests compare genuine original-batch, candidate-batch and scalar results exactly. Active instruction descriptor, PC, invocation width and ordered lane membership must agree between old and candidate; empty dispatch is intentionally excluded because skipping it is the proposed optimization. Both jump types and destination labels/joins are asserted. Controls include nested all-true/all-false branches, prior inactive root lanes, sparse helper callers, mixed helper branches, the inactive `ExternalFun` continue, empty/singleton/tail/reordered workspace sizes, an inactive trapping callback, imaginary branch conditions and signed-zero bit patterns. The existing callback-order test remains mandatory.

Numeric tests require finite real and imaginary components before equality, preserving precision and debug observations. They cover f64, DoubleFloat and alternating 80/192-bit Float samples, values separated beyond 53 bits, static/dynamic three-component Duals, and a downward-closed nine-component mixed order-four shape. Nonzero condition derivatives must not activate a zero primal branch. The mixed fixture uses a polynomial and a reciprocal with nonsingular positive inputs.

After this source/test gate, a separate protocol must rebuild uninstrumented baseline/candidate Symbolica archives and minimally relink OneLoop, masters, core and a probe. Existing dependent archives embed the old Symbolica identity and cannot be combined with a new candidate archive as if compatible. All unchanged externs may be reused. Only complete tensor/Laurent/Taylor/status/fallback/request/counter observations and exact own repeats can qualify that stage. Optimized timings require another comparable-build cohort after numerical qualification. This packet makes no runtime gain, performance parity, full-reduction correctness or production-adoption claim.

Proposed commands after the corresponding explicit root grant, from the project root:

```sh
source scripts/env.sh
python3 target/guard-performance-review/qualification-plan-v2/run_stage.py compile REVIEWED_PROTOCOL_SHA256
```

The `tests` stage requires compile success and a separate grant; substitute `tests` for `compile` and retain the same reviewed protocol hash. The runner refuses existing output directories to preserve failed attempts. Do not execute these commands merely because they are documented.
