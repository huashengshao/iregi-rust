# Uniform branch scheduling and fused recurrence review

Status: **private source proposal only**. No live Rust/Cargo/dependency source was changed. No build, Rust test, numerical evaluation, timing, installation or external write was performed. The six proposed Rust tests have not been compiled or executed. Parent review and a separately bounded qualification protocol are required before execution or adoption.

## Decision and evidence boundary

The narrow first candidate is to skip dispatch of a wholly inactive branch in the **existing Symbolica instruction-major batch interpreter**. It changes scheduling only. It preserves the exact predicate test, every executed numeric instruction and operand order, all local/primal/output stability checks, derived-invariant certificates, input validation, tolerances, failure precedence, master selection and public result conventions.

The retained 6b24 diagnostic reports N2/rank1/batch32 reduction-plus-guards at 100.946 us per batch (about 70.6% of that separate profiled total). It does not separate the fused evaluator from the following Rust inspection loops. N3/rank0 is master dominated. Therefore there is no evidence that all 100.946 us can be removed by a scheduler or guard change, and no projected speedup is claimed. The current private selected-native A/B/C whole-call evidence is a separate cohort and cannot be combined algebraically with these old component medians.

The retained exact census shows the N2/rank1 native-convention fused evaluator has 1,013 instructions, 246 outputs (20 moments, 196 local monitor outputs, 30 primal monitor outputs), 237 temporary slots, 73 IfElse, 73 Goto, 146 Label and 73 Join instructions. CSE previously removed zero instructions; repeating that candidate is not proposed. The OneLOop-convention graph has 850 instructions and the same 73 branch groups. Text-only inspection in `static-control-widths.json` finds forward branch spans of 1–25 instruction positions for false-arm skips and 1–48 for Goto skips. These overlapping static spans are not executed traces, total avoided work or a performance forecast.

Regular nonzero binary64 distances already avoid exact Rational conversion at `execution.rs:264–276`. The prior isolated selected-zero diagnostic spent about 90% inside ComplexBall evaluation and about 1.6–1.7% in exact conversion. A new approximate proof filter or eager exact-conversion optimization is not the right candidate for ordinary rank-one timings. The rejected slim-real-ball and lazy-capture cohorts remain rejected under their all-family criteria.

## Exact production delta

`uniform-branch.patch` changes only `evaluate_program` in a frozen private copy of `dependencies/symbolica/src/evaluate/batch.rs`:

1. Replace `for ... enumerate()` with a forward program counter. Capture `instruction_index`, fetch the instruction, then set the default next pc **before dispatch**. This preserves the existing `ExternalFun` arm's `continue` when no lanes are active; an increment-at-the-end conversion would hang there.
2. At Goto, record whether every caller lane was active before the existing resume writes and `active.clear()`. Only in that case, set next pc to the existing forward target.
3. At IfElse, record the same premise before the existing `retain` closure. If every caller lane was active and every lane chose the false arm, use the existing target as next pc.
4. Execute the destination Label normally. Its original `resume[lane] <= instruction_index` reconstruction restores the lane list. All mixed/incompletely active branches retain the original sequential schedule.

The production candidate adds no trace fields, constants, numeric cache, branch classifier, approximate predicate or shape reinterpretation. Both numeric and Dual branch decisions still use the same `is_fully_zero` on the original condition. The separate test-only instrumentation patch records visited instructions and taken uniform jumps; it must never be included in timings.

Base source SHA-256: `eb73974b0c176422863e4fbe512d392813d83085b2ae5c476db24d028012efcf`.
Production candidate SHA-256: `6db2acb4b342e5fb1ac78ac04f39abaf72541acff7279ddce505fcfe095a53bf`.

## Scheduling invariant and proof

For each individual program invocation, `lanes` is an ordered unique caller list. It is the root prefix `0..rows`, or the active ordered subset passed to one shared helper. It is not the arena stride and need not contain every root sample. The current initialization, retain and Label reconstruction keep `active` an ordered subset of that invocation's `lanes`. Consequently equality of lengths proves set equality without any additional numeric or lane scan.

At a proposed jump, every caller lane receives exactly the same forward resume target by the original writes, and `active` is empty. Before the target, each Label in the original implementation would reconstruct an empty list because every resume target is larger than that label's pc. Empty Add/Mul/Pow/Builtin/Join loops do not touch stack values or the temporary. Empty IfElse/Goto do not alter resume values. Empty ExternalFun returns to the loop via its existing continue without allocating, calling a callback or reporting a missing implementation. Thus all skipped instructions are inert for every caller lane and the temporary, and the two programs reach the destination with identical numeric/active/resume state. Executing the destination Label then restores precisely the same caller order.

This induction covers nested branches, multiple joins at one merge, and helper-local sparse callers. A prior inactive lane makes `active.len() < lanes.len()` and prevents the fast path, so a lane waiting for an earlier inner/outer label is not skipped. Root empty batches return before program invocation; singleton batches retain the original scalar evaluator. Scratch capacity, stride, chunking and requested numeric precision do not enter this scheduling decision.

The proof assumes the existing valid structured forward IR: target pc denotes a Label, targets are forward, and caller lanes are unique/in range. `tree.rs:1341–1375` constructs those branches and `evaluator.rs:902–917` fixes target positions. This does not extend support to malformed manually constructed IR. Existing forward debug assertions are retained. No new claim about a symbolic predicate's mathematical truth is made; only its previously selected lanes are scheduled differently.

Independent source review by `/root/native_stack_batch/peer_cse_review` confirmed these invariants and independently identified the inactive-ExternalFun continue hazard. Actual candidate/test review is still pending; no independent test-pass claim is made.

## Existing API and algebra reuse checks

1. **Symbolica/Numerica source:** reuse the current `BatchWorkspace` active/resume scheduler (`batch.rs:190–340`) and scalar forward-jump semantics (`evaluator.rs:418–431`). Keep Symbolica's IR, storage allocation, arithmetic domains, `is_fully_zero`, `Dualizer` flattening and shared body calls. No new symbolic operation or arithmetic engine is introduced.
2. **Existing usage/tests:** the original `batch_calls_are_instruction_major_and_skip_inactive_lanes`, `batch_shared_functions_keep_inactive_branches_lazy`, `batch_complex_precision_domains_and_flattened_duals`, shape/empty-batch tests, and `evaluator.rs::cse_tests::nested_multi_result_branches_keep_common_operations_in_scope` already provide the relevant patterns. The new raw 16-instruction nested fixture reuses that existing CSE test schedule, and the new tests compare full outputs with the existing scalar evaluator.
3. **FeynKit/gammaloop/HEPKit/COLLIER:** FeynKit's `TensorReducer` retains contraction orbits and `IntegralFamily` provides family mappings, but neither replaces numeric conditional scheduling. The existing SymJIT review records why its scalar/packet scheduling is not a compliant substitute. COLLIER's fixed routines avoid a generic interpreter, which motivates separately compiled fused graphs below; no Fortran algebra is copied. This scheduler delta therefore needs no missing-algebra exception.

## Focused qualification source and staged gates

`tests/uniform_branch_tests.rs` contains six **unrun** tests, and `tests/batch.rs` is the production candidate plus isolated test-only trace hooks and a module include. To assemble a future isolated Symbolica source copy, place those two files at its `src/evaluate/{batch.rs,uniform_branch_tests.rs}`. The untouched base and minimal production delta are retained separately. Do not overwrite the wheel's live dependency tree.

The source covers:

- All-false and both all-true/inner-selected nested branches, exact visited-pc assertions, preserved destination Labels, multiple joins and positive IfElse/Goto jump counters.
- Mixed outer/inner paths, prior inactive callers, exact scalar comparison, empty/singleton/odd/batch32/33 and decreasing/reused capacities, invalid-shape sentinels and a subsequent valid call.
- An inactive trapping external callback reached with an empty active list on a mixed parent path; this specifically exercises the continue migration hazard.
- Shared helpers called by a strict sparse subset of root lanes, first uniform then mixed helper branches and workspace reuse.
- Real/complex f64, DoubleFloat and mixed 80/192-bit Float inputs, a displacement beyond 53 bits, static and dynamic three-component Dual layouts with nonzero condition derivatives but zero primal, precision metadata and scalar comparisons.
- Imaginary-only conditions and signed-zero input/output bit patterns.

Before a build, independently review these sources against the actual pinned APIs. Then one bounded isolated test build/run should include both the six new tests and all existing Symbolica batch/evaluator branch tests. A missing API or test failure must be retained before repair; no test run has yet been authorized by this proposal.

After those pass, qualify uninstrumented private baseline and candidate cores using identical frozen dependencies except this source delta. Compare every returned Laurent/tensor/Taylor coefficient, exact per-backend repeats, complete statuses/diagnostics, fallback/analytic flags, master requests and batch counters. Capture execution counters in an untimed companion diagnostic to demonstrate real skips and identical executed numeric operations; both jumps must occur. Use all eight original ordinary N2/N3 families plus true-zero, lightlike/equal-mass, complex-branch, scaleless-pole, failed-neighbor, nonzero derivative at zero primal, mixed-Dual, higher/mixed Float precision, DD sparse-limb, tiny/huge/subnormal and accuracy-update/reuse cases. Keep all prior conditioning witnesses and higher-point paths that instantiate the same dependency. Existing tests/fixtures provide these controls; do not invent f64 downcasts or new tolerances.

Only then preregister one complete singleton/batch32 whole-call timing cohort under the existing paired 99% CI/2% width policy. All families and controls remain visible. The singleton entry path is numerically unchanged, but compiler/layout effects and mixed-branch extra length comparisons could regress it or other families. No default adoption follows from dispatch counters or a favorable rank-one median.

## Next emitter step, deferred

If the interpreter remains the dominant measured stage, use the existing `oneloop::rust_codegen::RustEmitter::emit_batch(ExpressionEvaluator<Complex<Rational>>, EmitOptions)` on the **unchanged whole fused evaluator**, including every moment/local/primal monitor root and original ordered parameters/aliases. `emit_batch` already preserves forward lazy active-lane scheduling, shared functions, generic constants and scalar singleton dispatch. The exact Euler–Mascheroni/PI descriptors required by native convention are supported by the current emitter; no new normalizer or handwritten recurrence is required.

Start with opt-in precompiled N2/N3 rank0/1 preserved-input unit-power h0 plans, and keep all unrecognized plans on the existing interpreter. This is a small registry, not runtime rustc/JIT dependency or replacement of general plan support. Dispatch must bind the full ordered graph, settings, parameter/output ordering, constants/registered descriptors, helper signatures and ordered Dual shape. Settings/arity alone are insufficient: the retained initialization-order diagnostic demonstrates that symbol preparation can change binary64 operand ordering. A mismatch must fall back explicitly, not pretend to match. Prefer matching a hash-bound exact graph generated by the same pinned preparation API; normalize symbol descriptors by full namespace/name and tags while retaining numeric instruction/operand order.

The emitter's runtime uses specialized complex inverse, abs/norm and product primitives. Even f64 can differ by ULPs from the Symbolica interpreter; DD compensated multiplication can differ more visibly. Do not assert bit identity across backends from an identical symbolic graph. Require complete dimensionally normalized 1e-10 agreement with the original stable binary64 references, exact own repeats, unchanged diagnostics/branch requests, higher-precision convergence and independent derivative identities before extending a native Dual/Float path. A first f64-only optimization can leave DD/Float/all Dual shapes on the shared interpreter without losing API support. Preserve all guards and status checks after either executor.

This route has greater implementation/qualification cost than the scheduler patch, compilation/code-size risks, and no measured speedup yet. No broad emitter implementation is started here. The existing exact CSE, shared/dense-span native and lazy-capture regressions remain visible and are not rerun or rebranded as this experiment.
