"""Prepare an explicit unexecuted compiler/test protocol from frozen receipts."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import shutil

ROOT = Path('/shared/external/iregi/iregi-rust')
PACKET = ROOT / 'target/guard-performance-review/qualification-plan-v4'


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


externs = json.loads((PACKET / 'extern-map.json').read_text())
inventory = json.loads((PACKET / 'source-inventory.json').read_text())
closure_path = ROOT / externs['closure_receipt']
assert sha(closure_path) == externs['closure_receipt_sha256']
closure = json.loads(closure_path.read_text())
protected = {str(closure_path.relative_to(ROOT)): sha(closure_path)}
protected.update(inventory['private_source_sha256'])
protected.update(inventory['live_source_sha256'])
for entry in closure['files']:
    path = ROOT / entry['frozen']
    assert path.stat().st_size == entry['bytes']
    assert sha(path) == entry['sha256'], str(path)
    protected[entry['frozen']] = entry['sha256']
for entry in externs['externs']:
    assert sha(ROOT / entry['artifact']) == entry['sha256']
    for key in ['fingerprint_receipt', 'fingerprint_metadata']:
        assert sha(ROOT / entry[key]) == entry[key + '_sha256']
        protected[entry[key]] = entry[key + '_sha256']
lib_receipt = ROOT / externs['symbolica_library_receipt']
assert sha(lib_receipt) == externs['symbolica_library_receipt_sha256']
protected[externs['symbolica_library_receipt']] = externs['symbolica_library_receipt_sha256']
rustc = Path('/nix/store/1qg7z7i461qsv0lczc40nyi8ps6snlca-rustc-1.99.0/bin/rustc')
assert sha(rustc) == '9ea4b7398bce9713ac47ea137032cf985ec6b5ea21be152beda9bd77320dc13f'
taskset = Path(shutil.which('taskset')).resolve()
linker = Path('/nix/store/788mx070y81zjlg5ipcl0cra3afviw9k-gcc-wrapper-15.2.0/bin/cc')
tools = {str(p): sha(p) for p in [rustc, taskset, linker]}
source = PACKET / 'source/symbolica'
binary = PACKET / 'compile-003/unit-tests'
command = [str(taskset), '-c', '32,33', str(rustc), '--edition=2024', '--crate-name', 'symbolica', '--test', str(source / 'src/lib.rs'), '-C', 'opt-level=0', '-C', 'debuginfo=0', '-C', 'strip=debuginfo', '-C', 'lto=off', '-C', 'codegen-units=8', '-C', 'debug-assertions=yes', '-C', 'overflow-checks=yes', '-C', 'metadata=tirust_uniform_branch_v2', '-C', 'linker=' + str(linker), '-L', 'dependency=' + str(ROOT / 'target/e6-direct-n2/deps'), '-L', 'native=' + str(ROOT / 'target/e6-direct-n2/native')]
for feature in externs['features']:
    command.extend(['--cfg', 'feature=' + json.dumps(feature)])
for entry in externs['externs']:
    command.extend(['--extern', entry['name'] + '=' + str(ROOT / entry['artifact'])])
command.extend(['-o', str(binary)])
for name in ['extern-map.json', 'source-inventory.json', 'prepare_private.py', 'prepare_protocol.py', 'run_stage.py', 'lifecycle.py', 'frozen-module-mechanical.patch', 'focused-tests-v2.patch', 'evaluate-test-module.patch', 'batch.rs', 'evaluate.rs', 'uniform_branch_baseline.rs', 'uniform_branch_tests.rs']:
    protected[str((PACKET / name).relative_to(ROOT))] = sha(PACKET / name)
lifecycle_source = ROOT / 'target/native-f64-opt-in/qualification/lifecycle.py'
assert sha(lifecycle_source) == sha(PACKET / 'lifecycle.py') == 'c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824'
protected[str(lifecycle_source.relative_to(ROOT))] = sha(lifecycle_source)
prior = json.loads((PACKET / 'prior-failure-binding.json').read_text())
prior_manifest_path = ROOT / prior['prior_source_manifest']
assert sha(prior_manifest_path) == prior['prior_source_manifest_sha256']
prior_manifest = json.loads(prior_manifest_path.read_text())
for name, entry in prior_manifest['files'].items():
    path = prior_manifest_path.parent / name
    assert path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256']
    protected[str(path.relative_to(ROOT))] = entry['sha256']
for key in ['prior_source_manifest', 'prior_protocol', 'prior_compile_receipt', 'prior_compile_log']:
    path = ROOT / prior[key]
    assert sha(path) == prior[key + '_sha256']
    protected[prior[key]] = prior[key + '_sha256']
prior_protocol = json.loads((ROOT / prior['prior_protocol']).read_text())
for path, expected in prior_protocol['protected_sha256'].items():
    if path in protected:
        assert protected[path] == expected
    else:
        assert sha(ROOT / path) == expected
        protected[path] = expected
for name in ['prior-failure-binding.json', 'constructor-trait-selection.patch', 'source-api-check.json']:
    protected[str((PACKET / name).relative_to(ROOT))] = sha(PACKET / name)
api_check = json.loads((PACKET / 'source-api-check.json').read_text())
for path, expected in api_check['sources'].items():
    assert sha(ROOT / path) == expected
    protected[path] = expected
existing_tests = re.findall(r'#\[test\]\s+fn\s+(\w+)', (PACKET / 'batch.rs').read_text())
focused_tests = re.findall(r'#\[test\]\s+fn\s+(\w+)', (PACKET / 'uniform_branch_tests.rs').read_text())
assert len(existing_tests) == 5 and len(focused_tests) == 6
batch_names = ['evaluate::batch::tests::' + name for name in existing_tests] + ['evaluate::batch::uniform_branch_tests::' + name for name in focused_tests]
protocol = {
    'status': 'PROPOSED_UNEXECUTED_REQUIRES_ROOT_BUILD_GRANT',
    'scope': 'One isolated non-Python opt0 Symbolica test crate, no Cargo, dependency builds or numerical reduction kernel.',
    'cwd': str(ROOT),
    'compile_command': command,
    'compile_environment_overrides': {'CARGO_CRATE_NAME': 'symbolica', 'CARGO_PKG_VERSION': '3.0.1', 'CARGO_MANIFEST_DIR': str(source), 'SYMBOLICA_VERSION': 'symbolica-' + externs['symbolica_version']},
    'compile_timeout_seconds': 180,
    'compile_aggregate_budget_seconds': 183,
    'lifecycle_helper_source': str(lifecycle_source.relative_to(ROOT)),
    'lifecycle_helper_sha256': sha(lifecycle_source),
    'aggregate_cleanup_and_bookkeeping_reserve_seconds': 8,
    'compile_effective_work_deadline_seconds': 175,
    'lifecycle': 'Byte-identical reviewed Budget/execute helper: work deadline includes pre/post guards; owned group checked after leader exit; cleanup signals deferred; terminal event persisted before hashes.',
    'proposed_cpu_affinity': '32,33',
    'binary': str(binary),
    'protected_sha256': protected,
    'tool_sha256': tools,
    'no_incremental_reuse_claim': True,
    'historical_exact_rustc_command_available': False,
    'flag_reconstruction': 'Exact Cargo features/extern identities recovered; this is a new explicit opt0 command, not an exact historical command replay.',
    'test_stages': [
        {'name': 'list-batch', 'args': ['evaluate::batch::', '--list'], 'timeout_seconds': 15, 'expected_test_count': 11, 'expected_test_names': batch_names},
        {'name': 'actual-batch-and-six-focused', 'args': ['evaluate::batch::', '--test-threads=1'], 'timeout_seconds': 60, 'expected_pass_count': 11, 'expected_test_names': batch_names},
        *[{'name': name, 'args': ['evaluate::test::' + name, '--exact', '--test-threads=1'], 'timeout_seconds': 30, 'expected_pass_count': 1, 'expected_test_names': ['evaluate::test::' + name]} for name in ['completed_conditionals_reuse_only_their_parent_scope', 'completed_shared_conditionals_keep_captures_and_mixed_dual_components', 'non_inlined_stack_reuse_preserves_nested_lazy_branches', 'non_inlined_function_reuses_body_for_repeated_nested_calls']],
    ],
    'test_total_timeout_seconds': 180,
    'test_execution_requires_separate_root_grant_after_compile': True,
    'license': 'Inherit an authorized SYMBOLICA_LICENSE or supported existing license; never record its value or bypass checks.',
    'failure_policy': 'Stop on first failure/timeout, preserve all bytes and diagnostics, inspect before any new protocol or retry.',
    'acceptance': {'focused_old_candidate_scalar_exact_outputs': True, 'active_instruction_and_ordered_lane_trace_exact': True, 'finite_components_required': True, 'existing_batch_tests_required': True, 'optimized_performance_qualified': False, 'full_reduction_qualified': False, 'production_adoption_authorized': False},
}
(PACKET / 'protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
print(json.dumps({'protocol_sha256': sha(PACKET / 'protocol.json'), 'protected_files': len(protected), 'externs': len(externs['externs']), 'closure_files': len(closure['files']), 'no_compiler_or_test_invoked': True}))
