"""UNEXECUTED runner; invoke only for the exact stage separately granted by root."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
from lifecycle import Budget, execute

ROOT = Path('/shared/external/iregi/iregi-rust')
PACKET = ROOT / 'target/guard-performance-review/qualification-plan-v4'


def sha(path: Path) -> str:
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n')


def main() -> int:
    if len(sys.argv) != 3 or sys.argv[1] not in ['compile', 'tests']:
        raise SystemExit('Expected separately authorized stage: run_stage.py compile|tests REVIEWED_PROTOCOL_SHA256')
    stage, reviewed_hash = sys.argv[1:]
    protocol_path = PACKET / 'protocol.json'
    assert sha(protocol_path) == reviewed_hash, 'Protocol changed since review'
    protocol = json.loads(protocol_path.read_text())
    directory = PACKET / ('compile-003' if stage == 'compile' else 'tests-003')
    directory.mkdir(exist_ok=False)
    cap = protocol['compile_aggregate_budget_seconds'] if stage == 'compile' else protocol['test_total_timeout_seconds']
    budget = Budget(cap)
    if stage == 'compile':
        definitions = [{'name': 'compile', 'command': protocol['compile_command'], 'timeout_seconds': protocol['compile_timeout_seconds']}]
    else:
        definitions = [dict(item, command=protocol['compile_command'][:3] + [protocol['binary']] + item['args']) for item in protocol['test_stages']]
    record = {'scope': stage, 'protocol_sha256': reviewed_hash, 'runner_sha256': sha(Path(__file__)), 'status': 'preparing', 'steps': [dict(item, status='unrun') for item in definitions], 'cleanup_errors': [], 'success': False, 'aggregate_budget_seconds': cap, 'tirust_reduction_kernel_evaluation': False, 'performance_measurement': False}
    receipt = directory / 'receipt.json'
    dump(receipt, record)
    runtime_guards: dict[Path, str] = {}

    def verify() -> None:
        assert sha(protocol_path) == reviewed_hash, 'Protocol changed during execution'
        for path, expected in {**protocol['protected_sha256'], **protocol['tool_sha256']}.items():
            budget.remaining()
            actual_path = Path(path) if Path(path).is_absolute() else ROOT / path
            assert sha(actual_path) == expected, 'Guard mismatch: ' + path
        for path, expected in runtime_guards.items():
            budget.remaining()
            assert sha(path) == expected, 'Generated artifact changed: ' + str(path)

    budget.arm()
    try:
        assert Path.cwd() == ROOT, 'Run commands from the project root'
        assert not os.environ.get('RUSTC_BOOTSTRAP'), 'Do not alter the reviewed stable compiler semantics'
        verify()
        record['guard_before'] = True
        env = dict(os.environ)
        env.update(protocol['compile_environment_overrides'])
        env['RUST_TEST_THREADS'] = '1'
        if stage == 'tests':
            previous_path = PACKET / 'compile-003/receipt.json'
            previous_bytes = previous_path.read_bytes()
            previous_sha = hashlib.sha256(previous_bytes).hexdigest()
            previous = json.loads(previous_bytes)
            assert previous['success'] and previous['guard_after']
            assert previous['protocol_sha256'] == reviewed_hash
            assert sha(Path(protocol['binary'])) == previous['binary_sha256']
            record['binary_sha256'] = previous['binary_sha256']
            record['compile_receipt'] = {'path': str(previous_path), 'sha256': previous_sha}
            runtime_guards[previous_path] = previous_sha
            runtime_guards[Path(protocol['binary'])] = previous['binary_sha256']
            verify()
        for step in record['steps']:
            budget.remaining()

            def persist(result: dict) -> None:
                step.update(result)
                dump(receipt, record)

            log = directory / (step['name'] + '.log')
            result = execute(step['command'], log, budget, step['timeout_seconds'], record['cleanup_errors'], persist, env)
            # execute() persists a terminal event and proves the owned group
            # gone even if its original leader had already exited normally.
            assert result['status'] == 'exited', 'Child failed or exceeded its cap; no retry authorized'
            verify()
            step['log_sha256'] = sha(log)
            if stage == 'compile':
                binary = Path(protocol['binary'])
                record['binary_sha256'] = sha(binary)
                record['binary_bytes'] = binary.stat().st_size
                runtime_guards[binary] = record['binary_sha256']
            else:
                output = log.read_text()
                if 'expected_test_count' in step:
                    names = re.findall(r'^(.+): test$', output, re.MULTILINE)
                    assert len(names) == step['expected_test_count'], 'Incorrect actual batch/focused test inventory'
                    assert sorted(names) == sorted(step['expected_test_names']), 'Listed test names differ'
                else:
                    assert re.search(r'test result: ok\. ' + str(step['expected_pass_count']) + r' passed; 0 failed;', output), 'Expected tests did not all run'
                    names = re.findall(r'^test (.+) \.\.\. ok$', output, re.MULTILINE)
                    assert sorted(names) == sorted(step['expected_test_names']), 'Executed test names differ'
            step['status'] = 'passed'
            dump(receipt, record)
        record['status'] = 'completed-awaiting-final-guards'
    except Exception as error:
        record.update(status='failed', error=repr(error))
    dump(receipt, record)
    try:
        verify()
        record['guard_after'] = True
    except Exception as error:
        record.update(guard_after=False, guard_error=repr(error))
    record['elapsed_seconds_diagnostic'] = budget.elapsed()
    record['deadline_exceeded'] = record['elapsed_seconds_diagnostic'] > cap
    if budget.cancelled:
        record['cancellation'] = budget.cancelled
    record['success'] = all(item['status'] == 'passed' for item in record['steps']) and record['guard_after'] and not record['cleanup_errors'] and not record['deadline_exceeded'] and not budget.cancelled and 'error' not in record
    record['status'] = 'passed' if record['success'] else 'failed'
    dump(receipt, record)
    budget.disarm()
    print(json.dumps({'stage': stage, 'success': record['success'], 'receipt_sha256': sha(receipt)}))
    return 0 if record['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
