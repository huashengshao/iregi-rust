"""Source/metadata preparation only. This script never invokes a compiler/test."""
from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path('/shared/external/iregi/iregi-rust')
PACKET = ROOT / 'target/guard-performance-review/qualification-plan-v3'
SOURCE = ROOT / 'dependencies/symbolica'
PRIVATE = PACKET / 'source/symbolica'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n')


base = (PACKET.parent / 'base/batch.rs').read_text()
assert sha(PACKET.parent / 'base/batch.rs') == 'eb73974b0c176422863e4fbe512d392813d83085b2ae5c476db24d028012efcf'
assert (SOURCE / 'src/evaluate/batch.rs').read_text() == base
prefix = base.split('#[cfg(test)]\nmod tests {', 1)[0]
assert (PACKET / 'frozen-production-prefix.rs').read_text() == prefix
renamed = prefix.replace('BatchExpressionEvaluator', 'FrozenBatchExpressionEvaluator').replace('into_batch_evaluator', 'into_frozen_batch_evaluator')
old_trace = '            #[cfg(test)]\n            super::batch::uniform_branch_tests::record_step(pc, instruction, lanes.len(), active);\n'
baseline = (PACKET / 'uniform_branch_baseline.rs').read_text()
assert baseline.count(old_trace) == 1
assert baseline.replace(old_trace, '') == renamed
candidate = (PACKET / 'batch.rs').read_text()
candidate_trace = '            #[cfg(test)]\n            uniform_branch_tests::record_step(instruction_index, instruction, lanes.len(), active);\n'
jump_trace = '                        #[cfg(test)]\n                        uniform_branch_tests::record_jump(instruction_index, label.0, instruction, lanes.len());\n'
suffix = '\n#[cfg(test)]\n#[path = "uniform_branch_tests.rs"]\npub(super) mod uniform_branch_tests;\n'
assert candidate.count(candidate_trace) == 1
assert candidate.count(jump_trace) == 2
assert candidate.endswith(suffix)
production = candidate.removesuffix(suffix).replace(candidate_trace, '').replace(jump_trace, '')
assert production == (PACKET.parent / 'candidate/batch.rs').read_text()
assert hashlib.sha256(production.encode()).hexdigest() == '6db2acb4b342e5fb1ac78ac04f39abaf72541acff7279ddce505fcfe095a53bf'
evaluate = (SOURCE / 'src/evaluate.rs').read_text()
assert (PACKET / 'evaluate.rs').read_text() == evaluate.replace('mod batch;\n', 'mod batch;\n#[cfg(test)]\nmod uniform_branch_baseline;\n', 1)

source_files = sorted((SOURCE / 'src').rglob('*'))
source_files = [p for p in source_files if p.is_file()]
source_files += [SOURCE / name for name in ['Cargo.toml', 'build.rs', 'License.md', 'Readme.md', 'IREGI_UPSTREAM_VERSION', 'IREGI_PROVENANCE.json']]
live_before = {str(p.relative_to(ROOT)): sha(p) for p in source_files}
if PRIVATE.exists():
    raise SystemExit('Private snapshot already exists; preserve it and use a separately reviewed preparation directory.')
PRIVATE.mkdir(parents=True)
for path in source_files:
    target = PRIVATE / path.relative_to(SOURCE)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
replacements = {
    'evaluate.rs': 'src/evaluate.rs',
    'batch.rs': 'src/evaluate/batch.rs',
    'uniform_branch_baseline.rs': 'src/evaluate/uniform_branch_baseline.rs',
    'uniform_branch_tests.rs': 'src/evaluate/uniform_branch_tests.rs',
}
for source_name, target_name in replacements.items():
    shutil.copyfile(PACKET / source_name, PRIVATE / target_name)
assert live_before == {str(p.relative_to(ROOT)): sha(p) for p in source_files}
private_files = {str(p.relative_to(ROOT)): sha(p) for p in sorted(PRIVATE.rglob('*')) if p.is_file()}
dump(PACKET / 'source-inventory.json', {
    'scope': 'Source preparation only; no compiler, Cargo or test execution.',
    'live_source_sha256': live_before,
    'private_source_sha256': private_files,
    'replacements': replacements,
    'baseline_mechanical_reversal_matches_original_prefix': True,
    'candidate_trace_reversal_matches_reviewed_production': True,
    'live_source_unchanged': True,
})
original_tests = (PACKET.parent / 'tests/uniform_branch_tests.rs').read_text()
new_tests = (PACKET / 'uniform_branch_tests.rs').read_text()
(PACKET / 'focused-tests-v2.patch').write_text(''.join(difflib.unified_diff(original_tests.splitlines(True), new_tests.splitlines(True), fromfile='frozen-tests/uniform_branch_tests.rs', tofile='v2-tests/uniform_branch_tests.rs')))
print(json.dumps({'private_source_files': len(private_files), 'live_source_files': len(live_before), 'source_inventory_sha256': sha(PACKET / 'source-inventory.json'), 'no_compiler_or_test_invoked': True}))
