# Current locked-Cargo native-policy qualification

This initial stage targets only the applied 17-file native policy composition.
It requires no N7 module, export or successful N7 capture. Root owns integration
and has assigned this agent the sole Cargo lease; no further user permission is
needed. The reviewed five-lane validation example is the only additional source:
`crates/iregi-rust/examples/native_policy_validation.rs`. It is an untimed API
example, adds no Cargo dependency, and changes no CLI/Python/default behavior.

Use the existing normal `target` / `target/cargo-build` cache with the locked
568-package graph, no profile/RUSTFLAGS/private-extern substitution. All builds
are `--locked --offline -vv --message-format=json`, CPUs20,21/jobs2. Capture the
newly emitted Cargo artifacts, features, profiles, package identities, hashes and
full stdout/stderr. Select executable paths from compiler-artifact records, not
old filenames or private direct-rustc archives. Native Symbolica must not select
Python features. Source and tool hashes remain guarded before/after each step.

First run the four metadata-only Cargo checks in `commands-and-selection.json`:

| Configuration | Explicit Cargo feature |
| --- | --- |
| default | none |
| selective | `iregi-rust/native-f64-abc` |
| broad legacy | `iregi-masters/native-batch` |
| both | both of the above |

This checks core forwarding and actual dependency feature unification. There is
no core `native-batch` forwarding feature to invent. Project products in this
phase must be rmeta only. Never run `cargo test`/`cargo build` for broad/both;
that would reintroduce large legacy generated D0 LLVM work. The four-check cap is
600s including 30s reserve, 240s per invocation, whole-group RSS limit32GiB.

Only default and selective then produce real library-test binaries for both
crates and the validation example. Per configuration: 600s total including40s
reserve, at most450s for `test --lib --no-run` and120s for the example. The same
32GiB whole-group sampled RSS limit applies. A fresh matching dependency build is
allowed naturally by Cargo; an old cache name never proves current source.
No automatic retries, cap changes, cache surgery or source edits follow failure.

Run exactly26 named tests from actual Cargo executables: default9/selective17.
The subset includes nine configuration/name cases from the prior27 core policy
inventory, six generic ordinary cases, one mixed-input precision guard and ten
master-policy cases. It deliberately avoids the expensive high-point constructor
cohort already qualified independently. Master tests assert all six stored
outputs and exact unchanged DD/Float/Dual values, non-f64 type exclusion,
D0/dB0 exclusion, static/dynamic and one-component Dual handling, selected ABC
errors/repeats and default backend behavior. Generic tests exercise values beyond
53bits and second-order static/dynamic Dual carriers. The Float256 prototype with
mixed80/256bit inputs must reject the unstable lane while preserving neighbors.

List both actual test binaries, require every selected exact name, then invoke
one test per process with `--exact`, `--test-threads=1`, `--nocapture`. Require one
pass, no ignored/zero-test pass. Runtime caps: default180s/selective240s including
20s reserve, at most60s per test, CPU20. Root explicitly allows these correctness
jobs beside independent N7 work on CPU6; no timing experiment may overlap them.

The single validation example evaluates one five-lane rank-one massive triangle
batch in each configuration: three retained physical points, one input differing
only by invalid `mu=-1`, and a repeat of lane0. Default and explicit Symbolica
records must match exactly. Selective additionally requests NativeF64Abc and
checks the same complete four-slot moment arrays. The exact invalid-scale reason
is preserved, failed values are null, all input bytes remain unchanged, and
counters require five inputs, four active lanes, two master groups and16 master
rows. Its Float53 constructor stays Symbolica. There is no capture cfg, profiling
or timing mode. Each example stage has120s including20s reserve on CPU20.

`probe-reference.json` is the exact original IREGI serial24 response subset from
the independently audited WHOLE38 corpus. No reference executable is run here.
All80 complex native tensor slots per policy, including the scalar moment, use
the existing benchmark helper's unchanged dimensionally normalized `1e-10` gate.
The invalid lane is validated explicitly before projecting the four declared
successful lanes for numerical comparison. It cannot suppress unstable neighbors.

The c193 whole-group cleanup helper is copied unchanged. The thin wrapper moves
the work deadline earlier to retain the declared30/40/20s reserves, samples the
entire owned group, kills descendants after any failure, and saves terminal state
before hashes. Source guards include current core/masters/OneLoop/Symbolica/
Numerica/Graphica inputs, the lock, manifests, tools, selected safe environment
and the three existing GMP/MPFR/MPC archives. Newly emitted compiler/native build
outputs must be identified separately; this is not a complete transitive native
build-input closure claim, and the old capsule's post-run-only archives remain
historical, not retroactively corrected.

The original Cargo SixPoint capsule remains immutable. This stage qualifies the
new actual Cargo policy/precision/batch/reference integration only. It does not
repeat the old complete high-point matrix harnesses, establish performance parity,
qualify broad-native runtime, or add N6/N7/generalized/derivative numerical claims.
A later N7 integration requires a fresh source freeze/current Cargo products and
its own stated validation; optional N7 notes in the recipe cannot block this
native-only milestone.
