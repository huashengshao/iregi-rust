"""Seal saved current-Cargo evidence on CPU10; no compiler or evaluator."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,os,tarfile
ROOT=Path.cwd();HERE=ROOT/'target/native-f64-sixpoint-port/current-cargo-proposal';OUT=ROOT/'validation/native-f64-sixpoint-current-cargo'
def sha(path):
    with Path(path).open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def main():
    assert not OUT.exists();OUT.mkdir()
    metadata=read(HERE/'runs/metadata-001/results.json');assert metadata['status']=='failed'and metadata['steps'][2]['timeout']and metadata['steps'][3]['status']=='unrun'
    records={}
    for configuration in ['default','selective']:
        for kind in ['build','tests','probe']:
            key=f'{kind}-{configuration}';path=HERE/f'runs/{key}-001/results.json';record=read(path)
            assert record['status']=='passed'and record['inputs_unchanged']and not record['cleanup_errors']and not record['deadline_exceeded']
            records[key]={'member':f'runs/{key}-001/results.json','sha256':sha(path),'elapsed_seconds':record['elapsed_seconds'],'aggregate_cap_seconds':record['aggregate_cap_seconds'],'reserve_seconds':record['reserve_seconds'],'protected_inputs':len(record['input_sha256']),'owned_groups':len(record['steps'])}
    assert read(HERE/'lease-release.json')['all_owned_process_groups_absent']is True
    audits=sorted((ROOT/'target/resume-20261025-review').glob('current-cargo-*-audit.json'))
    required=['current-cargo-metadata-independent-saved-audit.json','current-cargo-default-independent-provenance-audit.json','current-cargo-selective-independent-provenance-audit.json','current-cargo-probe-independent-numeric-audit.json']
    assert set(required)<=set(p.name for p in audits),[p.name for p in audits]
    members={}
    for path in HERE.rglob('*'):
        if not path.is_file()or '__pycache__'in path.parts:continue
        relative=path.relative_to(HERE)
        if relative.parts[0]=='products'and path.name!='products.json':continue
        if path.name=='capsule_check.py':continue
        assert not path.read_bytes().startswith((b'\x7fELF',b'!<arch>\n'))
        members[str(relative)]=path
    for path in audits:members['reviews/external-'+path.name]=path
    independent_script=ROOT/'target/resume-20261025-review/audit_current_cargo_probe_independent.py'
    members['reviews/audit_current_cargo_probe_independent.py']=independent_script
    members['comparison-helper.py']=HERE/'comparison-helper.py'
    for name in ['combined.patch','source-inventory.json']:members['source-provenance/'+name]=ROOT/'target/native-f64-sixpoint-port'/name
    parent_path=ROOT/'validation/winddown/native-f64-sixpoint-composition.tar.gz';inventory=read(ROOT/'target/native-f64-sixpoint-port/source-inventory.json')['proposed'];parent_files={}
    with tarfile.open(parent_path,'r:gz')as archive:
        for relative,value in inventory.items():
            name='proposed/'+relative;data=archive.extractfile(name).read();assert hashlib.sha256(data).hexdigest()==value
            parent_files[relative]={'parent_member':name,'sha256':value,'bytes':len(data)}
    save(OUT/'parent.json',{'path':str(parent_path.relative_to(ROOT)),'sha256':sha(parent_path),'role':'exact85 uncaptured native-policy production files already committed; no duplicate historical source','production_source_files':parent_files})
    probes={c:read(HERE/f'runs/probe-{c}-001/admission.json')for c in ['default','selective']}
    comparisons={c:v['comparisons']for c,v in probes.items()}
    qualification={'status':'current-Cargo-native-policy-qualified-with-legacy-metadata-timeout','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer':'/root/native_whole_port','native_only_qualification_passed':True,'full_metadata_matrix_passed':False,
      'source':{'live_source_files':399,'preparation_inputs':431,'matched_qualified_production_files':85,'additional_public_API_validation_example':1,'preparation_sha256':sha(HERE/'preparation.json'),'source_freeze_sha256':sha(HERE/'source-freeze.json'),'commands_sha256':sha(HERE/'commands-and-selection.json'),'Cargo_lock_sha256':sha(HERE/'locked-source/Cargo.lock'),'native_patch_sha256':sha(ROOT/'target/native-f64-sixpoint-port/combined.patch')},
      'metadata':{'status':'failed-broad-fixed-cap-timeout-both-unrun','member':'runs/metadata-001/results.json','sha256':sha(HERE/'runs/metadata-001/results.json'),'elapsed_seconds':metadata['elapsed_seconds'],'aggregate_cap_seconds':600,'default':'passed','selective':'passed','broad':'fixed240s-timeout','both':'unrun','no_broad_or_both_codegen':True,'no_retry':True},
      'native_only_continuation':{'freeze_sha256':sha(HERE/'execution-continuation-freeze.json'),'independent_source_review_sha256':sha(HERE/'reviews/continuation-source-review.json'),'scope':'Exact successful default/selective metadata admits only their original bounded builds; failed matrix retained unmodified.'},
      'stages':records,'correctness':{'selected_exact_tests':26,'default_tests':9,'selective_tests':17,'test_listings':4,'one_pass_per_selected_test':True,'five_lane_N3_rank1_probes':2,'valid_lanes_per_probe':4,'invalid_lanes_per_probe':1,'unique_physical_points':3,'native_tensor_complex_slots_per_policy':80,'policies_compared_to_original_reference':5,'original_reference_complex_comparisons':400,'selected_vs_symbolica_complex_comparisons':80,'complete_default_and_explicit_symbolica_records_exact':True,'comparison_tolerance':1e-10,'comparisons':comparisons,'maximum_original_reference_error':max(v['max_error']for c in comparisons.values()for name,v in c.items()if name!='selected_vs_symbolica'),'generic_ordinary_precision_Dual_and_type_exclusion_assertions':'actual selected Cargo unit tests; no new high-point derivative numerical envelope'},
      'comparison_helper_sha256':sha(HERE/'comparison-helper.py'),'independent_audits':{p.name:{'member':'reviews/external-'+p.name,'sha256':sha(p)}for p in audits},
      'native_archive_guard_scope':read(HERE/'preparation.json')['native_guard_scope'],'all_owned_groups_absent_at_release':True,'diagnostic_durations_are_not_performance_measurements':True,
      'not_qualified_by_this_capsule':{'full_legacy_metadata_matrix':True,'broad_or_both_native_runtime':True,'performance_or_parity':True,'N6_or_N7_numerical_envelope':True,'new_generalized_or_highpoint_Dual_envelope':True,'CLI_or_Python_runtime':True,'complete_transitive_native_build_input_closure':True},
      'Cargo_execution':True,'compiler_execution':True,'numerical_execution':True,'benchmark_execution':False,'automatic_retries':False,'compiled_artifacts_committed':False}
    save(OUT/'qualification.json',qualification)
    (OUT/'check.py').write_bytes((HERE/'capsule_check.py').read_bytes())
    (OUT/'README.md').write_text('''# Current Cargo native-policy qualification

The integrated 17-file native-policy composition passes actual locked/offline
Cargo builds, all 26 selected exact tests and two public five-lane N3/rank1 probes.
Default and explicit Symbolica records are exact; all 400 original-IREGI complex
tensor comparisons and 80 selected-vs-Symbolica comparisons pass the unchanged
dimensionally normalized 1e-10 gate. The invalid-scale lane, all four Laurent
slots, complete basis/metadata/diagnostics, input bits, repeats and batch counters
remain explicit. Unit assertions cover ordinary DD/Float/static+dynamic Dual
carriers, precision guards and selective native type/family exclusions.

The full metadata feature matrix did not pass. Default and native-f64-abc checks
passed; broad legacy hit its fixed 240s frontend cap and the both-feature case
remained unrun. The failed matrix and raw logs are retained unchanged. A separate
root-authorized, independently reviewed admission used exactly the two successful
native-only metadata cases for the original bounded builds. There was no retry,
cap extension, broad/both code generation or weakened numerical gate.

Builds used the normal locked 568-package cache, CPUs 20/21, two jobs, unchanged profiles
and no supplemental externs/RUSTFLAGS. Runtime used CPU 20. Exact executable paths,
features, profiles and hashes came from matching Cargo compiler-artifact records.
Owned copies preserve the default example after Cargo replaced its common path.
Every owned group was closed. Durations are lifecycle diagnostics, not benchmarks.

The archive contains frozen commands/helpers, complete raw logs, output arrays,
receipts, product identities and independent saved audits. It inherits 85 exact
production files from the existing composition capsule and includes the new API
example. All 399 live source hashes and pinned tools are recorded. Three existing
GMP/MPFR/MPC archives were guarded before/after execution; this does not claim a
complete transitive native build-input closure. No binaries, archives of compiled
code or license values are committed. Existing historical capsules stay unchanged.

Verify saved data without a compiler, license or numerical evaluator:

```sh
source scripts/env.sh
python3 validation/native-f64-sixpoint-current-cargo/check.py
```

Use `--origins` while the private saved inputs remain available. The checker
rehashes all payloads, reconstructs the 85 inherited source files and reruns the
reviewed saved-output numerical admission with the pinned benchmark comparison.
Independent raw-number and command/provenance audits are also preserved.

Fresh execution requires restoring the inherited native-only source and archived
example into an isolated checkout, regenerating location-bound freezes and new
exclusive attempt directories, then following commands-and-selection.json.
The original attempts are immutable and must not be resumed or overwritten.
This capsule adds no performance, full legacy feature, N6/N7 numerical, generalized
or high-point derivative qualification. CLI/Python runtime is outside its scope.
''')
    entries={};license_hits=0
    with (OUT/'evidence.tar.gz').open('xb')as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9)as compressed:
            with tarfile.open(fileobj=compressed,mode='w')as archive:
                for name,path in sorted(members.items()):
                    data=path.read_bytes();license_hits+=data.count(bytes([83,45,49,51,48,45]))
                    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
                    entries[name]={'origin':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    assert license_hits==0
    metadata_files={name:{'sha256':sha(OUT/name),'bytes':(OUT/name).stat().st_size}for name in ['README.md','check.py','parent.json','qualification.json']}
    save(OUT/'manifest.json',{'status':'compact-current-Cargo-native-policy-capsule','archive':{'path':'evidence.tar.gz','sha256':sha(OUT/'evidence.tar.gz'),'bytes':(OUT/'evidence.tar.gz').stat().st_size,'members':entries},'metadata_files':metadata_files,'content_audit':{'ELF_or_ar_payloads':0,'provided_license_occurrences':license_hits},'compiled_artifacts_committed':False})
    print(json.dumps({'status':'sealed','archive_payloads':len(entries),'archive_bytes':(OUT/'evidence.tar.gz').stat().st_size,'archive_sha256':sha(OUT/'evidence.tar.gz'),'qualification_sha256':sha(OUT/'qualification.json'),'manifest_sha256':sha(OUT/'manifest.json')}))
if __name__=='__main__':main()
