"""Admit saved actual-Cargo example output; never launches an evaluator."""
from pathlib import Path
from fractions import Fraction
import importlib.util,json,math,struct,sys
ROOT=Path.cwd();HERE=ROOT/'target/native-f64-sixpoint-port/current-cargo-proposal'
helper=ROOT/'validation/benchmark/run.py';spec=importlib.util.spec_from_file_location('cargo_policy_existing_comparison',helper)
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)

def exact(a,b):return json.dumps(a,sort_keys=True,allow_nan=False)==json.dumps(b,sort_keys=True,allow_nan=False)
def represented(part,native):
    assert type(part)is dict and set(part)=={'rational','precision','negative_sign','finite'}
    assert part['finite']is True and part['precision']==53 and type(part['negative_sign'])is bool
    assert type(native)in [int,float]and math.isfinite(native)
    value=Fraction(part['rational']);assert Fraction.from_float(float(value))==value
    if value:assert (value<0)==part['negative_sign']
    actual=math.copysign(0.,-1.0 if part['negative_sign'] else 1.0)if not value else float(value)
    assert struct.pack('>d',actual)==struct.pack('>d',float(native))

def qualify(configuration,result,source,reference):
    assert configuration in ['default','selective'];selected=configuration=='selective'
    assert result['status']=='passed'and result['id']==source['id']and result['rows']==5 and result['numeric_type']=='f64'
    assert result['compiled_selective_feature']is selected and result['master_default_backend']=='SymbolicaBatch'
    assert result['capture_cfg']is False and result['timing']is False
    assert (result['selected']is not None)is selected
    expected_basis=[[0,0,0,0],[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]
    counts={'input_rows':5,'argument_rows':4,'master_family_batches':2,'master_rows':16,'pentagon_box_rows':0,'reduction_rows':4,'fallback_rows':0,'fallback_successes':0,'analytic_rows':0}
    policies={'default':'Default','symbolica':'Symbolica',**({'selected':'NativeF64Abc'}if selected else{})}
    active=[0,1,2,4];comparisons={}
    for name,policy in policies.items():
        value=result[name];assert value['requested_master_policy']==policy and value['components']==1
        assert exact(value['basis'],expected_basis)and exact(value['metadata'],{'convention':'IregiNative','tensor_weights':'Components','dual_shape':None})
        assert exact(value['execution'],counts)and value['input_unchanged']is True and value['profiling_enabled']is False
        assert len(value['lanes'])==5 and exact(value['diagnostics'],[[]for _ in range(5)])
        original=[]
        for sample in source['samples']:
            original.extend([[x,0.]for p in sample['shifts']for x in p]);original.extend(sample['masses']);original.append([sample['mu'],0.])
        assert len(original)==len(value['input'])==80
        for actual,pair in zip(value['input'],original):
            assert len(actual)==len(pair)==2
            for part,number in zip(actual,pair):represented(part,number)
        for index,lane in enumerate(value['lanes']):
            assert lane['fallback_used']is False and lane['analytic_used']is False
            if index==3:
                assert lane['status']=='InvalidInput("mu must be positive and real")'and lane['moments']is None and lane['represented']is None
                continue
            assert lane['status']=='success'and len(lane['moments'])==5 and len(lane['represented'])==20
            numeric=[z for moment in lane['moments']for z in moment]
            assert len(numeric)==20 and all(len(moment)==4 for moment in lane['moments'])
            for actual,pair in zip(lane['represented'],numeric):
                assert len(actual)==len(pair)==2
                for part,number in zip(actual,pair):represented(part,number)
        assert exact(value['lanes'][0],value['lanes'][4]),'repeated input lane differs'
        # The one declared invalid row remains explicit above; every declared active lane must succeed.
        rust={'stable':True,'lanes':[value['lanes'][i]for i in active]}
        oracle={'stable':True,'lanes':[reference['lanes'][i]for i in active]}
        comparison=h.compare(rust,oracle,{'n':3,'rank':1},[source['samples'][i]for i in active])
        assert comparison['status']=='passed',comparison;comparisons[name]=comparison
    for field in ['basis','metadata','components','lanes','diagnostics','input','execution']:
        assert exact(result['default'][field],result['symbolica'][field]),field
    if selected:
        comparison=h.compare({'stable':True,'lanes':[result['selected']['lanes'][i]for i in active]},
                             {'stable':True,'lanes':[result['symbolica']['lanes'][i]for i in active]},
                             {'n':3,'rank':1},[source['samples'][i]for i in active])
        assert comparison['status']=='passed';comparisons['selected_vs_symbolica']=comparison
    return {'status':'passed','configuration':configuration,'rows':5,'successful_rows':4,'expected_invalid_rows':1,'unique_retained_physical_points':3,'complex_tensor_slots_per_policy':80,'all_native_laurent_slots_compared':True,'comparisons':comparisons,'default_and_explicit_symbolica_complete_records_exact':True,'no_numerical_evaluator_launched_by_validator':True}

def main():
    assert len(sys.argv)==3,'configuration stdout-log'
    lines=Path(sys.argv[2]).read_bytes().splitlines();outputs=[json.loads(line[7:])for line in lines if line.startswith(b'RESULT ')]
    assert len(outputs)==1,'expected exactly one RESULT record'
    result=qualify(sys.argv[1],outputs[0],json.loads((HERE/'probe-input.json').read_text()),json.loads((HERE/'probe-reference.json').read_text()))
    print(json.dumps(result,allow_nan=False))
if __name__=='__main__':main()
