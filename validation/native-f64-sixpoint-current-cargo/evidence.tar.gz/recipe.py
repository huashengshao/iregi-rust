"""Source-only command proposal. No subprocess/Cargo/compiler is invoked here."""
from pathlib import Path
import json
ROOT=Path.cwd();HERE=ROOT/'target/native-f64-sixpoint-port/current-cargo-proposal'
FEATURES={'default':[], 'selective':['iregi-rust/native-f64-abc'],
          'broad':['iregi-masters/native-batch'],
          'both':['iregi-rust/native-f64-abc','iregi-masters/native-batch']}
EXPECTED={'default':{'iregi_rust':['default'],'iregi_masters':['default']},
          'selective':{'iregi_rust':['default','native-f64-abc'],'iregi_masters':['default','native-f64-abc']},
          'broad':{'iregi_rust':['default'],'iregi_masters':['default','native-batch']},
          'both':{'iregi_rust':['default','native-f64-abc'],'iregi_masters':['default','native-batch','native-f64-abc']}}
GENERIC=['scalar_tadpole_empty_mixed_lanes_and_reused_workspace',
         'reduction_keeps_double_double_and_arbitrary_precision_inputs',
         'typed_static_and_dynamic_dual_carriers_agree']
CORE_DEFAULT=[('execution::master_policy_tests::','explicit_symbolica_overrides_the_legacy_feature_and_preserves_default_cache'),
              ('execution::master_policy_tests::','unavailable_selective_policy_fails_before_exact_preparation'),
              ('execution::tests::','workspace_policy_default_preserves_values_without_sidecar_allocation')]
CORE_SELECTED=[('execution::master_policy_tests::','explicit_symbolica_overrides_the_legacy_feature_and_preserves_default_cache'),
               ('execution::master_policy_tests::','selective_workspaces_keep_cache_policy_and_recursive_lane_semantics'),
               ('execution::master_policy_tests::','selective_policy_keeps_high_precision_and_component_one_duals_on_symbolica'),
               ('execution::policy_composition_tests::','composition_sidecars_share_exact_cache_but_master_policies_do_not'),
               ('execution::policy_composition_tests::','composition_ordered_dual_shapes_and_master_policy_separate_exact_entries'),
               ('execution::policy_composition_tests::','composition_selected_policy_survives_eager_dual_and_lazy_children')]
MASTER_DEFAULT=['existing_defaults_and_explicit_symbolica_remain_distinct',
                'unavailable_selection_errors_before_fallback_or_preparation',
                'explicit_dual_policy_keeps_lazy_scalar_children_symbolica']
MASTER_SELECTED=['existing_defaults_and_explicit_symbolica_remain_distinct',
                 'selective_feature_does_not_enable_the_legacy_broad_constructor',
                 'selected_batches_keep_six_outputs_errors_and_own_repeats',
                 'higher_precision_and_unselected_families_remain_exact_symbolica',
                 'explicit_dual_policy_keeps_lazy_scalar_children_symbolica',
                 'one_component_and_seeded_dual_shapes_never_select_native',
                 'static_and_dynamic_dual_adapters_keep_policy_and_shape']

def cases():
    out=[]
    for config in ['default','selective']:
        for prefix,name in CORE_DEFAULT if config=='default'else CORE_SELECTED:
            out.append({'configuration':config,'crate':'iregi_rust','name':prefix+name,'group':'focused_subset_of_private27'})
        for name in GENERIC:
            out.append({'configuration':config,'crate':'iregi_rust','name':'execution::tests::'+name,'group':'generic_ordinary'})
        if config=='selective':out.append({'configuration':config,'crate':'iregi_rust','name':'execution::tests::derived_distance_guard_respects_input_precision_within_one_batch','group':'actual_input_precision_guard'})
        for name in MASTER_DEFAULT if config=='default'else MASTER_SELECTED:
            out.append({'configuration':config,'crate':'iregi_masters','name':'execution_policy_tests::'+name,'group':'actual_cargo_master_policy'})
    assert len(out)==26 and len({(x['configuration'],x['crate'],x['name'])for x in out})==26
    return out

def recipe():
    taskset='/nix/store/156fzvaz2nsq2hk0fkzn9jwk90bnzyn9-util-linux-2.42.2-bin/bin/taskset'
    cargo='/nix/store/1jwkiz96iwqdhm4bh2hvgd86ysb0b67q-cargo-1.99.0/bin/cargo'
    base=[taskset,'-c','20,21',cargo];shared=['--locked','--offline','--jobs','2','-vv','--message-format=json']
    metadata=[];build=[]
    for config,features in FEATURES.items():
        flags=['--features',','.join(features)]if features else[]
        metadata.append({'configuration':config,'command':base+['check','-p','iregi-rust','-p','iregi-masters','--tests']+shared+flags,
            'per_invocation_cap_seconds':240,'LLVM_codegen_for_project_D0':False,'runtime':False})
        if config not in ['default','selective']:continue
        build.append({'configuration':config,'label':'library-tests','command':base+['test','-p','iregi-rust','-p','iregi-masters','--lib','--no-run']+shared+flags,'per_invocation_cap_seconds':450,'runtime':False})
        build.append({'configuration':config,'label':'one-batch-validation-example','command':base+['build','-p','iregi-rust','--example','native_policy_validation']+shared+flags,'per_invocation_cap_seconds':120,'runtime':False})
    return {'status':'source-only-proposal-not-an-executable-freeze','initial_source_context':'native-policy-only; no N7 source/export is required',
      'cargo_preflight':{'command':base+['metadata','--locked','--offline','--format-version','1','--no-deps'],'cap_seconds':30,'purpose':'workspace manifests/default feature declarations only; resolved compiler artifacts establish selected feature graph'},
      'metadata_feature_matrix':metadata,'metadata_aggregate_seconds':600,'metadata_cleanup_and_final_hash_reserve_seconds':30,
      'codegen_commands':build,'codegen_aggregate_per_configuration_seconds':600,'codegen_cleanup_and_final_hash_reserve_seconds':40,
      'expected_project_features':EXPECTED,'sole_Cargo_owner_required':True,'current_Cargo_cache':'unchanged target + target/cargo-build; no RUSTFLAGS/profile/supplemental-extern substitution',
      'runtime_cases':cases(),'runtime_aggregate_seconds':{'default':180,'selective':240},'runtime_reserve_seconds':20,'per_test_seconds':60,'test_threads':1,'runtime_cpu':20,
      'runtime_binaries':'resolve exact executable paths/hashes from successful matching compiler-artifact records, never a filename glob or private rlib',
      'probe':{'runtime_per_configuration_seconds':120,'runtime_reserve_seconds':20,'configuration':['default','selective'],'rows':5,'valid_rows':[0,1,2,4],'invalid_rows':[3],'unique_retained_physical_points':3,'propagators':3,'rank':1,'components':1,'laurent_slots':4,'tensor_moments_per_lane':5,'complex_outputs_per_policy':80,'input':'probe-input.json','reference':'probe-reference.json','comparison_helper':'validation/benchmark/run.py::compare','tolerance':1e-10,'binary_arguments':['<exact-Cargo-example-copy>',str(HERE/'probe-input.json')],'kernel_timing':False},
      'optional_later_N7':{'required_for_initial_stage':False,'requires_new_live_source_freeze_and_current_Cargo_artifacts':True,'inputs':['target/public-seven-point-proposal/integration.patch','target/public-seven-point-proposal/native-policy-overlay.patch'],'cheap_guard_tests':['seven_point::tests::unsupported_domain_is_rejected_before_symbolic_preparation','seven_point::tests::exact_supported_domain_passes_the_cheap_preparation_guard'],'numerical_N7_claim_from_this_native_only_probe':False},
      'execution_status':'NOT EXECUTED; root must first apply approved source and assign sole Cargo/numerical leases; no additional user permission is implied'}
if __name__=='__main__':print(json.dumps(recipe(),indent=2))
