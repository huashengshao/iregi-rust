"""Freeze live native-only sources/tools/commands; no Cargo/compiler invocation."""
from pathlib import Path
import ast,datetime,hashlib,json,os
ROOT=Path.cwd();HERE=ROOT/'target/native-f64-sixpoint-port/current-cargo-proposal'

def sha(path):
    with Path(path).open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save_new(path,value):
    with Path(path).open('x')as stream:stream.write(json.dumps(value,indent=2)+'\n')
def main():
    assert not(HERE/'preparation.json').exists()
    base=read(ROOT/'validation/highpoint-six-point-current-cargo/source-freeze.json')
    native=read(ROOT/'target/native-f64-sixpoint-port/source-inventory.json')['proposed']
    assert len(native)==85 and all(sha(ROOT/path)==value for path,value in native.items())
    assert not(ROOT/'crates/iregi-rust/src/seven_point.rs').exists(),'initial native-only milestone'
    assert sha(ROOT/'Cargo.lock')=='33865b33512eb2a5f7f9f7d54075baee1c8c7e90167ae8f5b87019966c381d80'
    live=ROOT/'crates/iregi-rust/examples/native_policy_validation.rs';assert sha(live)==sha(HERE/'native_policy_validation.rs')=='5fa1347a8b702f2f66c6c71b9df81fbb5eb786593372e2dfd1894c568c12fc87'
    source={str(ROOT/path):sha(ROOT/path)for path in base['files']}
    for directory in ['crates/iregi-rust','crates/iregi-masters','dependencies/oneloopmaster','dependencies/symbolica']:
        for path in(ROOT/directory).rglob('*.rs'):
            if not any(part in ['target','.git','__pycache__']for part in path.parts):source[str(path)]=sha(path)
    for relative in ['crates/iregi-cli/Cargo.toml','crates/iregi-python/Cargo.toml']:
        path=ROOT/relative;source[str(path)]=sha(path)
    for directory in ['crates/iregi-cli/src','crates/iregi-python/src']:
        for path in(ROOT/directory).rglob('*.rs'):source[str(path)]=sha(path)
    for relative in ['.cargo/config','.cargo/config.toml','.local/cargo-home/config','.local/cargo-home/config.toml']:
        path=ROOT/relative
        if path.exists():source[str(path)]=sha(path)
    previous=read(ROOT/'validation/highpoint-six-point-current-cargo/preparation.json');tools=previous['tools']
    bindings={Path(path):value for path,value in source.items()}
    for item in tools.values():assert sha(item['path'])==item['sha256'];bindings[Path(item['path'])]=item['sha256']
    archives=read(ROOT/'validation/highpoint-six-point-current-cargo/native-archives-postrun.json')['archives']
    for item in archives:
        path=ROOT/item['path'];assert sha(path)==item['sha256'];bindings[path]=item['sha256']
    for path in HERE.rglob('*'):
        if path.is_file()and '__pycache__'not in path.parts and 'runs'not in path.parts:
            bindings[path]=sha(path)
            if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    for relative in ['validation/benchmark/run.py','validation/native-f64-sixpoint-whole/qualification.json','validation/native-f64-sixpoint-whole/manifest.json','validation/native-f64-sixpoint-whole/evidence.tar.gz','target/native-f64-sixpoint-port/combined.patch','target/native-f64-sixpoint-port/source-inventory.json','validation/highpoint-six-point-current-cargo/qualification.json','validation/highpoint-six-point-current-cargo/preparation.json','validation/highpoint-six-point-current-cargo/native-archives-postrun.json']:
        path=ROOT/relative;bindings[path]=sha(path)
    env_names=['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_BUILD_DIR','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_PROFILE_DEV_OPT_LEVEL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_DEV_CODEGEN_UNITS','CARGO_PROFILE_DEV_LTO','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','CC','CXX']
    environment={name:os.environ.get(name)for name in env_names}
    for name in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_PROFILE_DEV_OPT_LEVEL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_DEV_CODEGEN_UNITS','CARGO_PROFILE_DEV_LTO','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']:assert environment[name]is None,name
    assert environment['CARGO_TARGET_DIR']==str(ROOT/'target')and environment['CARGO_BUILD_BUILD_DIR']==str(ROOT/'target/cargo-build')
    assert sha(HERE/'lifecycle.py')=='c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824'
    save_new(HERE/'source-freeze.json',{'status':'native-policy-live-source-frozen-before-current-Cargo','base_commit':'2c1f3342e189a20fef3bbf7dd9e0baa372e2b4a2','native_patch_sha256':sha(ROOT/'target/native-f64-sixpoint-port/combined.patch'),'matched_private_candidate_files':85,'additional_validation_example':str(live.relative_to(ROOT)),'files':source})
    bindings[HERE/'source-freeze.json']=sha(HERE/'source-freeze.json')
    manifest={'status':'live-source-command-freeze-no-Cargo-or-compiler-invoked','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_context':'native-policy-only; N7 absent','tools':tools,'selected_environment_only':environment,'source_files':len(source),'preexisting_native_archive_inputs':archives,'native_guard_scope':'three archives previously linked by the same lockednative context now pre/post guarded; actual emitted units/link paths recorded separately; not complete transitive build-input closure','input_sha256':{str(k):v for k,v in sorted(bindings.items())},'commands_sha256':sha(HERE/'commands-and-selection.json'),'sole_Cargo_owner':'/root/native_whole_port','no_automatic_retries':True}
    save_new(HERE/'preparation.json',manifest)
    print(json.dumps({'status':manifest['status'],'source_files':len(source),'bindings':len(bindings),'preparation_sha256':sha(HERE/'preparation.json'),'source_freeze_sha256':sha(HERE/'source-freeze.json'),'commands_sha256':manifest['commands_sha256']}))
if __name__=='__main__':main()
