"""Execute one root-authorized frozen Cargo stage; no numerical target execution."""
from pathlib import Path
import datetime,json,sys
from common import HERE,ROOT,read,save,sha,budget,guards,execute

def artifacts(path,configuration):
    import recipe
    all_rows=[];selected=[];seen=set()
    for line in Path(path).read_text().splitlines():
        row=json.loads(line)
        if row.get('reason')!='compiler-artifact':continue
        all_rows.append(row);name=row['target']['name']
        if name in ['iregi_rust','iregi_masters']:
            assert sorted(row['features'])==sorted(recipe.EXPECTED[configuration][name]),(name,row['features'])
            seen.add(name)
        if name=='symbolica':assert not({'python_export','python_no_module','pyo3'}&set(row['features']))
        if name not in ['iregi_rust','iregi_masters','native_policy_validation','symbolica','oneloop','numerica','graphica']:continue
        files={}
        for value in row['filenames']:
            path=Path(value)
            if path.is_file():files[value]={'sha256':sha(path),'bytes':path.stat().st_size}
        selected.append({**row,'bound_files':files})
    assert seen=={'iregi_rust','iregi_masters'},seen
    return {'all_compiler_artifacts':all_rows,'selected_artifact_identities':selected}

def main():
    assert len(sys.argv)==2 and sys.argv[1]in ['metadata','build-default','build-selective']
    stage=sys.argv[1];prep_path=HERE/'preparation.json';prep=read(prep_path);plan=read(HERE/'commands-and-selection.json');grant_path=HERE/'execution-freeze.json';grant=read(grant_path)
    assert grant['preparation_sha256']==sha(prep_path)and grant['commands_sha256']==sha(HERE/'commands-and-selection.json')
    assert stage in grant['allowed_cargo_stages']
    if stage=='metadata':steps=plan['metadata_feature_matrix'];cap=600;reserve=30
    else:
        config=stage.removeprefix('build-');steps=[v for v in plan['codegen_commands']if v['configuration']==config];cap=600;reserve=40
        previous=read(HERE/'runs/metadata-001/results.json');assert previous['status']=='passed'
    attempt=HERE/'runs'/f'{stage}-001';attempt.mkdir(parents=True,exist_ok=False)
    bindings={Path(path):value for path,value in prep['input_sha256'].items()};bindings[prep_path]=sha(prep_path);bindings[grant_path]=sha(grant_path)
    record={'status':'preparing','stage':stage,'scope':'actual locked/offline current Cargo, no numerical target execution','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'aggregate_cap_seconds':cap,'reserve_seconds':reserve,'input_sha256':{str(k):v for k,v in bindings.items()},'steps':[{**value,'status':'unrun'}for value in steps],'cleanup_errors':[]}
    save(attempt/'results.json',record);clock=budget(cap,reserve);clock.arm()
    try:
        guards(bindings,clock)
        for index,step in enumerate(record['steps']):
            clock.remaining();out=attempt/f'step-{index}.stdout.jsonl';err=attempt/f'step-{index}.stderr.log'
            def persist(result):step.update(result);save(attempt/'results.json',record)
            result=execute(step['command'],out,err,clock,step['per_invocation_cap_seconds'],record['cleanup_errors'],persist)
            assert result['status']=='exited','Cargo stage failed; no retry or later-step execution'
            step['artifacts']=artifacts(out,step['configuration'])
            if stage=='metadata':
                assert all(all(Path(path).suffix=='.rmeta'for path in row['filenames'])for row in step['artifacts']['selected_artifact_identities']if row['target']['name']in ['iregi_rust','iregi_masters']),'project metadata step emitted a non-rmeta product'
            step['stdout_sha256']=sha(out);step['stderr_sha256']=sha(err);guards(bindings,clock);step['status']='passed';save(attempt/'results.json',record)
        record['status']='completed-awaiting-final-guards'
    except Exception as error:record.update(status='failed',error=repr(error))
    record['elapsed_seconds']=clock.elapsed();record['deadline_exceeded']=record['elapsed_seconds']>cap;save(attempt/'results.json',record)
    try:guards(bindings,clock);record['inputs_unchanged']=True
    except Exception as error:record.update(inputs_unchanged=False,guard_error=repr(error))
    record['elapsed_seconds']=clock.elapsed();record['deadline_exceeded']|=record['elapsed_seconds']>cap
    record['status']='passed'if all(v['status']=='passed'for v in record['steps'])and record.get('inputs_unchanged')is True and not record['cleanup_errors']and not record['deadline_exceeded']and'error'not in record else'failed'
    record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(attempt/'results.json',record);clock.disarm()
    print(json.dumps({'status':record['status'],'stage':stage,'elapsed_seconds':record['elapsed_seconds'],'steps':[{k:v.get(k)for k in ['configuration','status','returncode','elapsed_seconds']}for v in record['steps']]}))
    return 0 if record['status']=='passed'else 1
if __name__=='__main__':sys.exit(main())
