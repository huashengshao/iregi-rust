"""Independent saved f64 policy-example audit; Python standard library only.

Run only after the owner confirms BOTH probe stages terminal and immutable.
No producer, admission, benchmark helper, compiler, binary or evaluator import/run.
The parent reviewer separately admits the actual Cargo artifacts and provenance.
"""
from fractions import Fraction
from pathlib import Path
import datetime
import hashlib
import json
import math
import re
import struct
import sys

ROOT = Path.cwd()
HERE = ROOT / "target/native-f64-sixpoint-port/current-cargo-proposal"
OUT = ROOT / "target/resume-20261025-review/current-cargo-probe-independent-numeric-audit.json"
INPUT_SHA = "93052d4a208d784624f7ad3d9ac566f8866498afb82e8cf092e3d371c5f1f31c"
REFERENCE_SHA = "a26419d02d4b31a7b2b402731ac173fa31caae1034bf24c9f607fd5397d55d2b"
BASIS = [[0, 0, 0, 0], [1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
DEGREES = [0, 1, 1, 1, 1]
ACTIVE = [0, 1, 2, 4]
COUNTERS = {"input_rows": 5, "argument_rows": 4, "master_family_batches": 2, "master_rows": 16,
            "pentagon_box_rows": 0, "reduction_rows": 4, "fallback_rows": 0, "fallback_successes": 0, "analytic_rows": 0}
NORMALIZATION = "abs(a-b)/(E^(4+rank-2*n)+abs(b)); E=max(1,mu,abs(shifts),sqrt(abs(mass_squared)))"
CHECKS = 0
INPUTS = {}


def require(condition, context="check"):
    global CHECKS
    CHECKS += 1
    if not condition:
        raise AssertionError(context)


def unique(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("duplicate JSON key: " + key)
        value[key] = item
    return value


def decode(text):
    def invalid_constant(value):
        raise ValueError("nonstandard JSON constant: " + value)
    return json.loads(text, object_pairs_hook=unique, parse_constant=invalid_constant)


def exact(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(path):
    path = Path(path)
    INPUTS[str(path.relative_to(ROOT))] = digest(path)
    return path


def read(path):
    return decode(bound(path).read_text())


def array(value, length):
    require(type(value) is list and len(value) == length, ("array", length))
    return value


def native_pair(value):
    require(all(type(q) in (int, float) and math.isfinite(q) for q in array(value, 2)), "finite f64 complex pair")
    return value


def metadata_number(value, native):
    require(type(value) is dict and set(value) == {"rational", "precision", "negative_sign", "finite"})
    require(value["finite"] is True and type(value["precision"]) is int and value["precision"] == 53 and type(value["negative_sign"]) is bool)
    require(type(value["rational"]) is str and re.fullmatch(r"-?\d+(?:/[1-9]\d*)?", value["rational"]) is not None)
    rational = Fraction(value["rational"])
    require(rational.denominator & (rational.denominator - 1) == 0)
    decoded = float(rational)
    require(math.isfinite(decoded) and Fraction.from_float(decoded) == rational)
    require(rational == 0 or value["negative_sign"] == (rational < 0))
    if rational == 0:
        decoded = math.copysign(0., -1. if value["negative_sign"] else 1.)
    require(type(native) in (int, float) and math.isfinite(native))
    require(struct.pack(">d", decoded) == struct.pack(">d", float(native)), "represented f64 value/sign disagrees with native byte pattern")


def metadata_pair(value, native):
    for number, component in zip(array(value, 2), native_pair(native)):
        metadata_number(number, component)


def compare(actual, expected, samples):
    maximum = 0.; count = 0
    for lane, sample in zip(ACTIVE, samples):
        left = actual["lanes"][lane]; right = expected["lanes"][lane]
        require(left["status"] == right["status"] == "success")
        energy = max(1., sample["mu"], *(abs(q) for p in sample["shifts"] for q in p),
                     *(math.sqrt(math.hypot(*mass)) for mass in sample["masses"]))
        for degree, a, b in zip(DEGREES, array(left["moments"], 5), array(right["moments"], 5)):
            unit = energy**(4+degree-2*3)
            for av, bv in zip(array(a, 4), array(b, 4)):
                native_pair(av); native_pair(bv)
                error = math.hypot(av[0]-bv[0], av[1]-bv[1]) / (unit + math.hypot(*bv))
                require(math.isfinite(error) and error <= 1e-10, ("full-complex dimensional normalized error", lane, error))
                maximum = max(maximum, error); count += 1
    require(count == 80)
    return dict(status="passed", complex_slots=count, max_error=maximum, tolerance=1e-10)


def original_reference(source, reference):
    require(digest(HERE/"probe-input.json") == INPUT_SHA and digest(HERE/"probe-reference.json") == REFERENCE_SHA)
    require(reference["input_sha256"] == INPUT_SHA and reference["n"] == 3 and reference["rank"] == 1)
    require(reference["native_laurent_order"] == ["UV single", "IR single", "IR double", "finite"] and reference["degrees"] == DEGREES and reference["tolerance"] == 1e-10)
    require(source["id"] == "n3-r1-massive-five-lane-current-cargo" and len(source["samples"]) == 5)
    require(exact(source["samples"][0], source["samples"][4]))
    invalid = dict(source["samples"][0]); invalid["mu"] = -1.
    require(exact(source["samples"][3], invalid), "only scale differs for declared invalid input")
    corpus_path = bound(ROOT/reference["fixture_corpus"])
    require(digest(corpus_path) == reference["fixture_corpus_sha256"])
    corpus = decode(corpus_path.read_text())
    original_case = [case for case in corpus if case["id"] == "n3-r1-massive"]
    require(len(original_case) == 1 and original_case[0]["n"] == 3 and original_case[0]["rank"] == 1)
    require(exact(source["samples"][:3], original_case[0]["samples"][:3]))
    raw_path = bound(ROOT/reference["source_raw"])
    require(digest(raw_path) == reference["source_raw_sha256"] == "69a1a91d3b5504ee41afad6ae84d835325f237e10eb8f6fc2b92f356030fdfc0")
    events = [decode(line) for line in raw_path.read_text().splitlines()]
    require(len(events) == 76 and reference["source_original_reference_serial"] == 24)
    request, response = events[46:48]
    require(request["event"] == "request" and response["event"] == "response" and request["serial"] == response["serial"] == 24)
    require(request["engine"] == response["engine"] == "IREGI" and request["stage"] == response["stage"] == "reference")
    require(exact(request["key"], ["n3-r1-massive", 32]) and exact(response["key"], request["key"]) and request["payload"] == response["payload"])
    original = response["response"]
    require(original["id"] == "n3-r1-massive" and original["stable"] is True and len(original["lanes"]) == 32)
    require(exact(reference["lanes"], [original["lanes"][0], original["lanes"][1], original["lanes"][2], None, original["lanes"][0]]))
    return dict(source_original_reference_serial=24, sample_mapping=[0, 1, 2, None, 0], native_laurent_slots=4,
                original_reference_response_exactly_preserved=True, no_reference_evaluator_executed=True)


def qualify(configuration, result, source, reference):
    selective = configuration == "selective"
    require(result["id"] == source["id"] and result["status"] == "passed" and result["numeric_type"] == "f64")
    require(type(result["rows"]) is int and result["rows"] == 5 and result["compiled_selective_feature"] is selective)
    require(result["master_default_backend"] == "SymbolicaBatch" and result["capture_cfg"] is False and result["timing"] is False)
    require((type(result["selected"]) is dict) if selective else result["selected"] is None)
    policies = {"default": "Default", "symbolica": "Symbolica"}
    if selective:
        policies["selected"] = "NativeF64Abc"
    inputs = []
    for sample in source["samples"]:
        require(len(sample["shifts"]) == len(sample["masses"]) == 3)
        inputs.extend([[q, 0.] for shift in sample["shifts"] for q in array(shift, 4)])
        inputs.extend(sample["masses"]); inputs.append([sample["mu"], 0.])
    require(len(inputs) == 80)
    comparisons = {}
    for name, policy in policies.items():
        value = result[name]
        require(value["requested_master_policy"] == policy and type(value["components"]) is int and value["components"] == 1)
        require(exact(value["basis"], BASIS) and exact(value["metadata"], dict(convention="IregiNative", tensor_weights="Components", dual_shape=None)))
        require(exact(value["execution"], COUNTERS) and all(type(q) is int for q in value["execution"].values()))
        require(value["input_unchanged"] is True and value["profiling_enabled"] is False)
        require(exact(value["diagnostics"], [[] for _ in range(5)]))
        for actual, expected in zip(array(value["input"], 80), inputs):
            metadata_pair(actual, expected)
        for row, lane in enumerate(array(value["lanes"], 5)):
            require(lane["fallback_used"] is False and lane["analytic_used"] is False)
            if row == 3:
                require(lane["status"] == 'InvalidInput("mu must be positive and real")' and lane["moments"] is None and lane["represented"] is None)
            else:
                require(lane["status"] == "success")
                numbers = [z for moment in array(lane["moments"], 5) for z in array(moment, 4)]
                for actual, expected in zip(array(lane["represented"], 20), numbers):
                    metadata_pair(actual, expected)
        require(exact(value["lanes"][0], value["lanes"][4]), "repeated physical input has different complete result")
        comparisons[name] = compare(value, reference, [source["samples"][i] for i in ACTIVE])
    default = {k: v for k, v in result["default"].items() if k != "requested_master_policy"}
    symbolica = {k: v for k, v in result["symbolica"].items() if k != "requested_master_policy"}
    require(exact(default, symbolica), "all default/explicit-Symbolica record fields must agree exactly")
    if selective:
        comparisons["selected_vs_symbolica"] = compare(result["selected"], result["symbolica"], [source["samples"][i] for i in ACTIVE])
    return dict(configuration=configuration, policies=list(policies), physical_unique_points=3, input_rows=5, successful_rows_per_policy=4,
                exact_invalid_rows_per_policy=1, complex_tensor_slots_per_policy=80, complex_input_components_per_policy=80,
                complete_default_symbolica_record_exact=True, repeat_lane_record_exact=True, comparisons=comparisons)


def main():
    require(sys.argv[1:] == ["--both-probes-terminal-confirmed"], "owner must confirm both runtime probe stages terminal before this audit")
    source = read(HERE/"probe-input.json"); reference = read(HERE/"probe-reference.json")
    provenance = original_reference(source, reference)
    reports = {}; records = {}
    for configuration in ["default", "selective"]:
        folder = HERE/"runs"/("probe-"+configuration+"-001")
        terminal = read(folder/"results.json"); require(terminal["status"] == "passed", "runtime receipt not passed")
        admission = read(folder/"admission.json")
        stdout = bound(folder/"step-0.stdout.log").read_bytes()
        bound(folder/"step-0.stderr.log")
        require(stdout.endswith(b"\n"))
        outputs = [decode(line[7:]) for line in stdout.splitlines() if line.startswith(b"RESULT ")]
        result = array(outputs, 1)[0]; records[configuration] = result
        report = qualify(configuration, result, source, reference); reports[configuration] = report
        require(admission["status"] == "passed" and admission["configuration"] == configuration)
        for key, expected in [("rows", 5), ("successful_rows", 4), ("expected_invalid_rows", 1), ("unique_retained_physical_points", 3), ("complex_tensor_slots_per_policy", 80)]:
            require(type(admission[key]) is int and admission[key] == expected)
        for key in ["all_native_laurent_slots_compared", "default_and_explicit_symbolica_complete_records_exact", "no_numerical_evaluator_launched_by_validator"]:
            require(admission[key] is True)
        require(set(admission["comparisons"]) == set(report["comparisons"]))
        for policy, comparison in report["comparisons"].items():
            saved = admission["comparisons"][policy]
            require(saved["status"] == "passed" and saved["errors"] == [] and saved["tolerance"] == 1e-10 and saved["normalization"] == NORMALIZATION)
            require(type(saved["max_error"]) in (int, float) and math.isfinite(saved["max_error"]) and math.isclose(saved["max_error"], comparison["max_error"], rel_tol=1e-12, abs_tol=1e-30))
    for path in [Path(__file__), HERE/"README.md", HERE/"commands-and-selection.json", HERE/"native_policy_validation.rs", HERE/"admit_probe.py"]:
        bound(path)
    output = dict(status="independent-current-cargo-probe-saved-numerical-audit-passed", reviewer="/root/resume_auditor/whole_probe_review",
                  created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), checks=CHECKS, source_and_data_sha256=INPUTS,
                  reference_subset=provenance, configurations=reports, complex_reference_slots_compared=400, additional_cross_policy_slots_compared=80,
                  cross_configuration_default_record_exact=exact(records["default"]["default"], records["selective"]["default"]), findings=[],
                  limitations=["The parent separately validates Cargo compiler-artifact selection, features, build/native closure, test logs and owned-process-group runtime provenance; this audit does not infer those from filenames.",
                               "This independently audits the saved low-point f64 example arrays and one declared invalid row. No N6/N7, generalized, high-precision, derivative, broad-native runtime or performance qualification follows.",
                               "No private master capture is compiled into the example. Actual selected per-family backend and Float53 exclusion rely on separately reviewed executed Rust assertions/tests; this record checks the public policy, complete outputs and batch counters.",
                               "The original IREGI serial24 result is reused as an immutable reference; no new reference executable or numerical evaluator is invoked."])
    with OUT.open("x") as stream:
        json.dump(output, stream, indent=2, allow_nan=False); stream.write("\n")
    print(json.dumps(dict(status=output["status"], path=str(OUT.relative_to(ROOT)), sha256=digest(OUT), checks=CHECKS)))


if __name__ == "__main__":
    main()
