"""Check the pinned ordinary Cargo environment before the reviewed runner starts."""
import os,sys
from common import HERE,read,sha

def admitted_environment(preparation):
    result={name:os.environ.get(name) for name in preparation['selected_environment_only']}
    for name in ['PATH','RUSTC','RUSTDOC','CARGO_BUILD_RUSTC','CARGO_BUILD_RUSTDOC','CARGO_BUILD_RUSTC_WRAPPER','CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET_DIR']:
        result[name]=os.environ.get(name)
    extra=[name for name in os.environ if (name.startswith('CARGO_PROFILE_') or name.startswith('CARGO_TARGET_')) and name not in result]
    assert not extra,('unadmitted Cargo override keys',extra)
    return result

def main():
    grant=read(HERE/'execution-freeze.json');preparation=read(HERE/'preparation.json')
    assert sha(__file__)==grant['stage_entry_sha256']
    assert sha(HERE/'preparation.json')==grant['preparation_sha256']
    for path,value in grant['supplemental_input_sha256'].items():assert sha(path)==value
    environment=admitted_environment(preparation)
    assert environment==grant['admitted_environment'],'Cargo environment differs from its pre-execution admission'
    assert all(environment[name]==value for name,value in preparation['selected_environment_only'].items())
    import run_cargo
    original_artifacts=run_cargo.artifacts
    def strict_artifacts(path,configuration):
        result=original_artifacts(path,configuration)
        assert result['selected_artifact_identities'],'no selected compiler artifacts'
        for row in result['selected_artifact_identities']:
            assert row['filenames'],('empty artifact filename list',row['target']['name'])
            assert set(row['bound_files'])==set(row['filenames']),('declared artifact file missing',row['target']['name'])
            if row.get('executable')is not None:assert row['executable']in row['bound_files']
        return result
    run_cargo.artifacts=strict_artifacts
    return run_cargo.main()

if __name__=='__main__':sys.exit(main())
