"""Owned bounded process helper layered on the unchanged qualified c193 cleanup."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time
from lifecycle import Budget,cleanup,group_exists
ROOT=Path.cwd();HERE=ROOT/'target/native-f64-sixpoint-port/current-cargo-proposal'

def sha(path):
    with Path(path).open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def budget(seconds,reserve):
    result=Budget(seconds);assert reserve>=8;result.work_deadline=result.deadline-reserve;return result

def guards(bindings,clock):
    for path,value in bindings.items():clock.remaining();assert sha(path)==value,'changed input: '+str(path)

def group_sample(group):
    rows=[];page=os.sysconf('SC_PAGE_SIZE')
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():continue
        try:
            raw=(path/'stat').read_text();tail=raw[raw.rfind(')')+2:].split()
            if int(tail[2])!=group:continue
            item={'pid':int(path.name),'ppid':int(tail[1]),'state':tail[0],'rss_bytes':max(0,int(tail[21]))*page}
            if 'rustc'in raw[:raw.rfind(')')+1]:
                item['argv']=[part.decode(errors='replace')for part in(path/'cmdline').read_bytes().split(b'\0')if part]
                item['affinity']=sorted(os.sched_getaffinity(int(path.name)))
            rows.append(item)
        except (FileNotFoundError,ProcessLookupError,PermissionError,ValueError,IndexError):continue
    return rows

def execute(command,stdout_path,stderr_path,clock,cap,errors,persist,rss_cap=32*1024**3):
    record={'command':command,'status':'preparing','timeout_seconds':min(cap,clock.remaining()),'whole_group_rss_cap_bytes':rss_cap}
    owner=None;started=time.monotonic();persist(record)
    try:
        with Path(stdout_path).open('xb')as out,Path(stderr_path).open('xb')as err:
            owner=subprocess.Popen(command,stdout=out,stderr=err,start_new_session=True)
            record.update(status='running',owned_process_group=owner.pid);persist(record)
            deadline=min(started+cap,clock.work_deadline);next_sample=0.;samples=[];peak=0
            while owner.poll()is None:
                remaining=clock.remaining();elapsed=time.monotonic()-started
                if time.monotonic()>=deadline:record['timeout']=True;break
                if elapsed>=next_sample:
                    rows=group_sample(owner.pid);rss=sum(row['rss_bytes']for row in rows);peak=max(peak,rss)
                    samples.append({'elapsed_seconds':elapsed,'whole_group_rss_bytes':rss,'processes':rows})
                    record.update(peak_sampled_whole_group_rss_bytes=peak,resource_samples=samples);persist(record)
                    if rss>rss_cap:record['rss_limit']=True;break
                    next_sample=elapsed+2
                time.sleep(min(.1,remaining))
            record['returncode']=owner.poll()
    except Exception as error:
        record['error']=repr(error)
        raise
    finally:
        if owner is not None:
            cleanup(owner,record,errors,clock);record['returncode']=owner.returncode
        record['elapsed_seconds']=time.monotonic()-started
        if clock.cancelled:record['cancellation']=clock.cancelled
        record['status']='exited'if record.get('returncode')==0 and not record.get('timeout')and not record.get('rss_limit')and'error'not in record and not errors and not clock.cancelled and record.get('owned_group_gone')is True else'failed'
        persist(record)  # Durable whole-group terminal event before caller hashes/log parsing.
    return record

def frozen(source,expected,destination,clock):
    assert sha(source)==expected
    with Path(source).open('rb')as original,Path(destination).open('xb')as output:
        while data:=original.read(1024*1024):clock.remaining();output.write(data)
    Path(destination).chmod(0o500);assert sha(destination)==expected
    return destination
