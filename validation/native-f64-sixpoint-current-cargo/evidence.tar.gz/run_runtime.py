"""Run only reviewed exact tests / one saved-input probe from actual Cargo products."""
from pathlib import Path
import datetime,json,sys
from common import HERE,ROOT,read,save,sha,budget,guards,execute,frozen
from stage_entry import admitted_environment

TASKSET='/nix/store/156fzvaz2nsq2hk0fkzn9jwk90bnzyn9-util-linux-2.42.2-bin/bin/taskset'

def cargo_products(configuration,clock):
    path=HERE/'runs'/f'build-{configuration}-001/results.json';build=read(path)
    assert build['status']=='passed'and build['inputs_unchanged']is True
    assert build['stage']=='build-'+configuration
    assert build['input_sha256'][str(HERE/'preparation.json')]==sha(HERE/'preparation.json')
    directory=HERE/'products'/configuration
    products={}
    for name in ['iregi_rust','iregi_masters','native_policy_validation']:
        rows=[row for step in build['steps']for row in step['artifacts']['selected_artifact_identities']
              if row['target']['name']==name and row.get('executable')is not None
              and (name=='native_policy_validation' or row['profile']['test']is True)]
        assert len(rows)==1,(name,len(rows));row=rows[0];source=row['executable']
        identity=row['bound_files'][source];destination=directory/name
        products[name]={'source_path':source,'owned_path':str(destination),'sha256':identity['sha256'],
                        'bytes':identity['bytes'],'features':row['features'],'target':row['target'],'profile':row['profile']}
    manifest={'status':'frozen-actual-Cargo-products','configuration':configuration,
              'build_receipt':str(path),'build_receipt_sha256':sha(path),'products':products}
    if (directory/'products.json').exists():
        assert read(directory/'products.json')==manifest,'saved products do not match the exact current Cargo artifact identities'
        for item in products.values():assert sha(item['owned_path'])==item['sha256']and Path(item['owned_path']).stat().st_size==item['bytes']
        return manifest
    directory.mkdir(parents=True,exist_ok=False)
    for item in products.values():
        frozen(item['source_path'],item['sha256'],item['owned_path'],clock)
        assert Path(item['owned_path']).stat().st_size==item['bytes']
    save(directory/'products.json',manifest);return manifest

def main():
    assert len(sys.argv)==2 and sys.argv[1]in ['tests-default','tests-selective','probe-default','probe-selective']
    stage=sys.argv[1];kind,configuration=stage.split('-');prep=read(HERE/'preparation.json');grant_path=HERE/f'runtime-freeze-{configuration}.json';grant=read(grant_path)
    assert grant['preparation_sha256']==sha(HERE/'preparation.json')and grant['run_runtime_sha256']==sha(__file__)
    assert stage in grant['allowed_runtime_stages']
    environment=admitted_environment(prep);assert environment==grant['admitted_environment']
    assert all(environment[name]==value for name,value in prep['selected_environment_only'].items())
    assert grant['extra_input_sha256'][str(HERE/'stage_entry.py')]==sha(HERE/'stage_entry.py')
    for path,value in grant['extra_input_sha256'].items():assert sha(path)==value
    plan=read(HERE/'commands-and-selection.json');cap=plan['runtime_aggregate_seconds'][configuration]if kind=='tests'else plan['probe']['runtime_per_configuration_seconds']
    reserve=plan['runtime_reserve_seconds']if kind=='tests'else plan['probe']['runtime_reserve_seconds']
    attempt=HERE/'runs'/f'{stage}-001';attempt.mkdir(parents=True,exist_ok=False)
    bindings={Path(path):value for path,value in prep['input_sha256'].items()}
    bindings[HERE/'preparation.json']=sha(HERE/'preparation.json');bindings[grant_path]=sha(grant_path)
    bindings.update({Path(path):value for path,value in grant['extra_input_sha256'].items()})
    build_path=HERE/'runs'/f'build-{configuration}-001/results.json';bindings[build_path]=sha(build_path)
    record={'status':'preparing','stage':stage,'scope':'untimed actual-Cargo correctness only; no N7 or generalized numerical qualification',
            'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'aggregate_cap_seconds':cap,'reserve_seconds':reserve,
            'input_sha256':{str(k):v for k,v in bindings.items()},'steps':[],'cleanup_errors':[]}
    save(attempt/'results.json',record);clock=budget(cap,reserve);clock.arm()
    try:
        guards(bindings,clock);products=cargo_products(configuration,clock);record['products']=products
        for item in products['products'].values():bindings[Path(item['owned_path'])]=item['sha256']
        manifest_path=HERE/'products'/configuration/'products.json';bindings[manifest_path]=sha(manifest_path)
        record['input_sha256']={str(k):v for k,v in bindings.items()};save(attempt/'results.json',record)
        def invoke(label,command,limit):
            index=len(record['steps']);out=attempt/f'step-{index}.stdout.log';err=attempt/f'step-{index}.stderr.log'
            step={'label':label,'status':'unrun'};record['steps'].append(step)
            def persist(result):step.update(result);save(attempt/'results.json',record)
            result=execute(command,out,err,clock,limit,record['cleanup_errors'],persist)
            assert result['status']=='exited',('runtime child failed',label)
            step.update(stdout_path=str(out),stderr_path=str(err),stdout_sha256=sha(out),stderr_sha256=sha(err))
            return step,out
        if kind=='tests':
            cases=[row for row in plan['runtime_cases']if row['configuration']==configuration];listed={}
            for name in ['iregi_rust','iregi_masters']:
                exe=products['products'][name]['owned_path'];step,out=invoke('list-'+name,[TASKSET,'-c','20',exe,'--list'],10)
                lines=out.read_text().splitlines();listed[name]={line[:-6]for line in lines if line.endswith(': test')}
                assert listed[name];step['discovered_tests']=sorted(listed[name]);step['status']='passed';save(attempt/'results.json',record)
            for case in cases:
                assert case['name']in listed[case['crate']],case
                exe=products['products'][case['crate']]['owned_path'];assert sha(exe)==products['products'][case['crate']]['sha256']
                step,out=invoke(case['name'],[TASKSET,'-c','20',exe,'--exact',case['name'],'--test-threads=1','--nocapture'],plan['per_test_seconds'])
                text=out.read_text();assert text.count('test result: ok.')==1 and '1 passed; 0 failed; 0 ignored;'in text and 'running 1 test'in text
                assert 'test '+case['name']+' ... ok'in text,case
                step.update(status='passed',case=case);save(attempt/'results.json',record)
            record['selected_case_count']=len(cases);assert len(cases)==(9 if configuration=='default'else 17)
        else:
            exe=products['products']['native_policy_validation']['owned_path'];step,out=invoke('one-five-lane-N3-rank1-probe',[TASKSET,'-c','20',exe,str(HERE/'probe-input.json')],cap-reserve)
            import admit_probe
            outputs=[json.loads(line[7:])for line in out.read_bytes().splitlines()if line.startswith(b'RESULT ')]
            assert len(outputs)==1
            admission=admit_probe.qualify(configuration,outputs[0],read(HERE/'probe-input.json'),read(HERE/'probe-reference.json'))
            save(attempt/'admission.json',admission);step.update(status='passed',admission_sha256=sha(attempt/'admission.json'));record['admission']=admission
            save(attempt/'results.json',record)
        record['status']='completed-awaiting-final-guards'
    except Exception as error:record.update(status='failed',error=repr(error))
    record['elapsed_seconds']=clock.elapsed();record['deadline_exceeded']=record['elapsed_seconds']>cap;save(attempt/'results.json',record)
    try:guards(bindings,clock);record['inputs_unchanged']=True
    except Exception as error:record.update(inputs_unchanged=False,guard_error=repr(error))
    record['elapsed_seconds']=clock.elapsed();record['deadline_exceeded']|=record['elapsed_seconds']>cap
    record['status']='passed'if record['status']=='completed-awaiting-final-guards'and all(v['status']=='passed'for v in record['steps'])and record.get('inputs_unchanged')is True and not record['cleanup_errors']and not record['deadline_exceeded']else'failed'
    record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(attempt/'results.json',record);clock.disarm()
    print(json.dumps({'status':record['status'],'stage':stage,'elapsed_seconds':record['elapsed_seconds'],'steps':len(record['steps']),'selected_case_count':record.get('selected_case_count'),'error':record.get('error')}))
    return 0 if record['status']=='passed'else 1

if __name__=='__main__':sys.exit(main())
