#!/usr/bin/env python3
"""Saved-output comparison only, preserving every original algorithm outcome."""
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rational(value):
    x = Fraction(value)
    return Decimal(x.numerator)/Decimal(x.denominator)


def norm(pair):
    return sum(x*x for x in pair).sqrt()


def main():
    path = HERE/'runs/compare-001/comparison.json'
    assert not path.exists()
    record = {'status':'started','cases':[], 'scope':'One new N7 rank0 dyadic fixture, Float128/request53; four native complex slots only. No rank7, Dual, batching or general-domain qualification.'}
    def save():
        tmp = path.with_suffix('.tmp')
        tmp.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
        tmp.replace(path)
    save()
    try:
        paths = [HERE/'fixture.json',HERE/'runs/capture-001/result.json',HERE/'runs/oracle-001/oracle.json']
        paths += [HERE/f'runs/reference-001/mode{m}.log' for m in range(3)]
        record['inputs'] = {str(p):digest(p) for p in paths}
        fixture = json.loads(paths[0].read_text())
        rust = json.loads(paths[1].read_text())
        oracle = json.loads(paths[2].read_text())
        assert rust['status']=='all_lanes_success' and rust['lane_statuses']==['Success']
        assert rust['basis']==[[0,0,0,0]] and rust['rows']==1 and rust['components']==1
        assert rust['working_bits']==128 and rust['requested_bits']==53
        assert rust['metadata']=={'convention':'IregiNative','tensor_weights':'Components','dual_shape':None}
        assert rust['settings']=={'propagators':7,'rank':0,'powers':[1]*7,'dimension_shift':0,
                                 'algorithm':'PassarinoVeltman','convention':'IregiNative',
                                 'tensor_weights':'Components','invariants':'FromShifts','input_policy':'Preserve'}
        sample = fixture['samples'][0]
        expected_input = [[str(Fraction(v)),'0'] for p in sample['propagators'] for v in p['shift']]
        expected_input += [[str(Fraction(v)) for v in p['mass_squared']] for p in sample['propagators']]
        expected_input += [[str(Fraction(sample['mu'])),'0']]
        assert rust['input_exact_rational']==[expected_input]
        assert rust['domain_audit']['domain_accepted'] is True
        assert rational(rust['domain_audit']['positive_F_lower_bound']) == Decimal(15)/16
        assert rational(rust['domain_audit']['normalization_q_squared']) == 4
        assert len(rust['domain_audit']['six_systems'])==7 and len(rust['domain_audit']['five_subsets'])==21
        assert rust['execution']['child_batch_calls']==1 and rust['execution']['packed_child_rows']==21
        assert rust['execution']['parent_batch_calls']==1 and rust['execution']['packed_parent_rows']==1
        assert rust['execution']['parent_input_rows']==1
        lane = rust['lanes'][0]
        assert lane['status']=='Success' and lane['row']==0 and len(lane['moments'])==1 and len(lane['moments'][0])==4
        assert oracle['status']=='completed' and oracle['fixture_sha256']==digest(HERE/'fixture.json')
        assert oracle['script_sha256']==digest(HERE/'oracle.py')
        assert {(r['order'],r['mapping']) for r in oracle['runs']}=={(o,m) for o in [8,12,16] for m in [0,1]}
        assert len(oracle['runs'])==6 and all(r['status']=='completed' for r in oracle['runs'])
        with localcontext() as context:
            context.prec = 100
            natural = Decimal(1)/1024  # Q²=max(masses²,|pair distance²|)=4; Q^(4-2N).
            tolerance = Decimal('1e-10')
            values = [(rational(s['real']),rational(s['imaginary'])) for s in lane['moments'][0]]
            assert all(x.is_finite() for pair in values for x in pair)
            pole_residues = [norm(pair)/natural for pair in values[:3]]
            record['native_exact_zero_poles'] = all(pair==(0,0) for pair in values[:3])
            record['pole_normalized_residues'] = [str(v) for v in pole_residues]
            reference_passes = []
            for mode in range(3):
                entry = {'mode':mode,'status':'parsing'}
                record['cases'].append(entry)
                try:
                    text = (HERE/f'runs/reference-001/mode{mode}.log').read_text()
                    responses = [json.loads(line[7:],parse_float=str) for line in text.splitlines() if line.startswith('RESULT ')]
                    assert len(responses)==1
                    response = responses[0]
                    assert response['id']==f'n7_rank0_mode{mode}' and type(response['stable']) is bool
                    assert response['poles']==['uv1','ir1','ir2','finite']
                    moments = response['moments']
                    assert len(moments)==1 and len(moments[0])==4 and all(len(s)==2 for s in moments[0])
                    refs = [tuple(Decimal(str(x)) for x in slot) for slot in moments[0]]
                    assert all(x.is_finite() for pair in refs for x in pair)
                    errors = [norm(tuple(a-b for a,b in zip(actual,ref)))/max(natural,norm(ref)) for actual,ref in zip(values,refs)]
                    ref_poles = [norm(pair)/natural for pair in refs[:3]]
                    passed = response['stable'] and max(errors+ref_poles)<=tolerance
                    entry.update(status='compared',stable=response['stable'],response=response,
                                 normalized_errors=[str(e) for e in errors],
                                 pole_normalized_residues=[str(e) for e in ref_poles],passed=passed)
                except Exception as error:
                    passed=False
                    entry.update(status='malformed_or_missing',error=f'{type(error).__name__}: {error}',passed=False)
                reference_passes.append(passed)
            expected = (Decimal(0),Decimal(str(oracle['comparison']['native_finite_imaginary'])))
            uncertainty = Decimal(str(oracle['comparison']['estimated_native_absolute_uncertainty']))
            assert uncertainty.is_finite() and uncertainty >= 0
            scale = max(natural,norm(expected))
            error = norm(tuple(a-b for a,b in zip(values[3],expected)))
            independent_pass = (error+uncertainty)/scale<=tolerance and uncertainty/natural<=tolerance and max(pole_residues)<=tolerance
            record['independent_scalar'] = {'normalized_difference':str(error/scale),
                'normalized_estimated_uncertainty':str(uncertainty/scale),
                'difference_plus_estimated_uncertainty':str((error+uncertainty)/scale),
                'natural_scale':str(natural),'tolerance':str(tolerance),'passed':independent_pass,
                'limitation':'estimated quadrature convergence, not a certified error bound'}
            record['all_three_original_modes_agree'] = all(reference_passes)
            record['all_four_complex_slots_compared_per_mode'] = 4
            record['status'] = 'passed' if independent_pass and all(reference_passes) else 'failed_or_requires_adjudication'
    except BaseException as error:
        record.update(status='failed',error=f'{type(error).__name__}: {error}')
    finally:
        save()
    print({'status':record['status'],'path':str(path)})
    return 0 if record['status']=='passed' else 1


if __name__=='__main__':
    sys.exit(main())
