# Private N7 rank-zero vertical slice — source/protocol only

No stage has been built or executed. This protocol requires a frozen independent
source review and an explicit ROOT grant before `protocol/run.py` will start.
It does not modify the qualified N7 core, live workspace, dependencies or Python
wheel. The proposed driver links the already compiled private N7 core archive
from `thin-n7-source/qualification/build-001`; only one small driver is rebuilt.

## Fixed input and domain

One ordinary Float128 lane requests binary64 accuracy (53 bits), N=7, rank=0,
unit powers, h=0, preserved shifts, PV, native Cartesian components. All four
separate Laurent slots are captured. The plan coalesces all 21 N5 rank-zero
subsets in one child batch; it does not wrap seven N6 evaluations. No numerical
cofactor pruning, disabled guard, lowered precision target, quadrature import
or scalar-backend change is permitted.

`fixture.json` is a **new, unqualified** dyadic fixture. It preserves the masses
and spatial coordinates of `conditioned_masses/base`, changing only line6's
time component from zero to 1/4. Every retained public-highpoint family has the
old geometry: omitting its sole nonzero-time line makes a required six-line
system singular. That known unsupported point will not be run or silently
projected. The new point must first pass `domain.rs`; it is not called regular
merely because its coordinates look generic.

The standalone domain stage uses Symbolica's existing `Matrix<Q>::rank`,
`det` and `inv` APIs. It records all seven exact 5×5 determinants and inverse
infinity condition estimates, all 21 child coordinate ranks/determinants and
four constant-identity charts per child, and the exact positive-F bound. A child
must have coordinate rank4 or rank3 with an available constant chart. These
are necessary domain checks; the actual child and parent stability checks still
decide acceptance. Matrix construction follows the frozen N7 geometry and the
existing planar-pentagon chart definitions. There is no new solver, determinant,
symbolic elimination, polynomial manipulation or approximate chart selection.

For this fixed real-mass point, `F = Σ x_i m_i² + Var(spatial p) − Var(time p)`.
The time range is 1/2 and the smallest squared mass is1, hence `F >= 15/16`.
The exact domain stage recomputes this and `Q²=max(m_i², |(p_i-p_j)²|)=4` with
Symbolica rationals. The normalization is consequently `Q^(4−2N)=1/1024`.
The positive bound and UV degree −10 imply all three pole slots vanish.

## Independent observations

The frozen original IREGI executable receives three fresh, identical rank-zero
requests, modes0/1/2. Every raw log, stability flag and all four slots remain
visible. Reference stability is an observation, not proof. A failed mode does
not suppress the other two requests. Requests are byte-bound and separately
checked against the exact fixture during source review.

`oracle.py` reuses the existing independent N6 Gauss-Jacobi simplex method,
with the defining N7 scalar integrand `(-1)^7 Gamma(5)/F^5 = -24/F^5`.
SciPy supplies every quadrature node and weight. The six-dimensional
stick-breaking map uses weights `(1-t_a)^(5-a)` and reproduces volume1/720.
Fixed orders8/12/16 and two fixed line orderings run once each; no accuracy- or
result-dependent extra rule is allowed. Native finite equals `i*pi²` times
the OneLoop scalar because all poles vanish. Order/mapping differences and a
floating reporting floor provide an **estimated**, non-certified uncertainty.
The implementation is numerical evaluation of the defining integral, not a
new algebra system. The original N6 oracle source/hash is retained as provenance.

Comparison uses the existing dimensionful rule: complex error divided by
`max(Q^-10, |reference|)` must be at most1e-10. Every original mode is checked
individually. For the independent oracle, difference **plus** estimated
uncertainty must fit the same threshold, and the uncertainty itself must fit
the absolute natural-scale target. Insufficient convergence remains a failure;
it cannot trigger extra rules or relaxed tolerances. Successful scalar evidence
would cover this one lane only, not general N7, higher ranks, Duals or batching.

## Proposed bounded sequence

1. Driver-only relink:120s global cap, CPUs6/7; existing native-object dependency
   closure, opt0/no debug, explicit compiler/linker. No core or dependency rebuild.
2. Exact necessary domain audit:30s global cap, CPU6. A rejection stops numerical
   preparation. It is retained and requires a new reviewed proposal to change.
3. Fresh full generic plan/workspace and one numeric capture:300s global cap,
   CPU6, Float128/request53. The ledger is written before each stage, and global
   reduction errors retain execution statistics and diagnostics.
4. Untouched reference modes:30s each within120s global, CPU6, no retries.
5. Six fixed scalar-oracle rules:180s global, CPU6, serial BLAS, partial ledger
   before each rule. No adaptive extension.
6. Saved-data comparison:30s global, CPU6. Failures and all observed modes remain
   in the record; no performance conclusion is made.

The existing generic N6/rank7 phase log recorded one parent structural plan at
27.782s and full plan at35.766s; the Float256 diagnostic parent was36.041s.
N7 prepares seven related 5×5 systems with five shared RHS each. Multiplying
the observed parent preparation by seven gives a rough 195–252s planning
estimate, not a measured N7 cost or a deadline guarantee. Rank-zero child
preparation/evaluation is smaller than the rank-six children in that diagnostic.
The proposed300s bound keeps a slow constructor visible instead of authorizing
an unbounded run. No timing acceptance is inferred from these diagnostic times.

Every stage owns and reaps its process group. Soft signals record interruption;
polling terminates safely rather than raising during cleanup. Terminal receipts
are written before post-run hashing. Frozen source/dependency/search-directory
guards run before and after; partial result files are retained on failure.
Comparison also retains and gates on every prerequisite terminal and each
original-mode process result. Agreement in a partial output cannot turn a
nonzero exit, timeout, interrupted cleanup or failed provenance gate into a pass.
The first source-only protocol is preserved under `earlier-protocols/001`;
independent review caught that missing terminal gate before any execution.
Revision002 retains the pre-execution staged-grant fix: each stage now binds
its own immutable `protocol/grants/{stage}.json`, so a later authorization
cannot invalidate an earlier stage by changing its recorded grant file.
The underlying N7 exact qualification remains17PASS with the generic constructor
test explicitlyUNRUN. A later numeric capture would be a separate qualification.
