#!/usr/bin/env python3
"""One grant-bound stage; no retries or mutable shared build targets."""
import os
from pathlib import Path
import sys
import time
from common import (ROOT, BUNDLE, bindings, execute, finish, install_signal_handlers,
                    load_protocol, save, sha, utc, verify)


def main():
    install_signal_handlers()
    assert len(sys.argv) == 2
    stage = sys.argv[1]
    protocol = load_protocol()
    assert stage in protocol['stages']
    spec = protocol['stage_specs'][stage]
    output = BUNDLE/'runs'/f'{stage}-002'
    output.mkdir(parents=True, exist_ok=False)
    path = output/'run.json'
    record = {'status':'running','stage':stage,'started_utc':utc(),
              'bound_seconds':spec['bound_seconds'],'stages':[],
              'scope':protocol['scope'],'outputs':{}}
    save(path,record)
    files = {}
    start = time.monotonic()
    try:
        files = bindings(protocol,stage)
        # Every prerequisite terminal and generated artifact must remain bound.
        for required in spec.get('requires',[]):
            previous_path = BUNDLE/'runs'/f'{required}-002'/'run.json'
            import json
            previous = json.loads(previous_path.read_text())
            assert previous['status'] in (['passed','failed'] if stage=='compare' else ['passed'])
            assert previous['inputs_unchanged'] is True
            assert not previous.get('total_bound_exceeded',False)
            for key,digest in previous['inputs'].items():
                assert sha(key)==digest, f'changed prerequisite input: {key}'
                files[Path(key)] = digest
            for key,digest in previous['outputs'].items():
                artifact = ROOT/key
                assert sha(artifact)==digest
                files[artifact] = digest
            files[previous_path] = sha(previous_path)
        verify(files,protocol)
        record['inputs'] = {str(p):digest for p,digest in files.items()}
        env = os.environ.copy()
        env.update(CARGO_CRATE_NAME='thin_n7_rank0', CARGO_MANIFEST_DIR=str(BUNDLE),
                   RAYON_NUM_THREADS='1',RUST_TEST_THREADS='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
        for item in spec['commands']:
            verify(files,protocol)
            remaining = spec['bound_seconds']-(time.monotonic()-start)
            step = execute(item['command'],output/item['log'],
                           min(remaining,item.get('bound_seconds',remaining)),env,
                           ROOT/item['stdin'] if 'stdin' in item else None)
            step['name'] = item['name']
            record['stages'].append(step)
            save(path,record)
            # Reference failures are retained independently; do not drop modes1/2.
            if not step['passed'] and stage!='reference':
                raise AssertionError(f"{item['name']} failed")
            verify(files,protocol)
        record['status'] = 'passed' if all(s['passed'] for s in record['stages']) else 'failed'
        save(path,record)  # Terminal precedes potentially failing file digests.
    except BaseException as error:
        record.update(status='failed',error=f'{type(error).__name__}: {error}')
    finally:
        # Capture partial result ledgers as evidence even when a bounded child
        # failed. An incomplete artifact never changes the terminal to passed.
        save(path,record)
        try:
            record['outputs'] = {name:sha(ROOT/name) for name in spec['outputs'] if (ROOT/name).is_file()}
            record['missing_outputs'] = [name for name in spec['outputs'] if not (ROOT/name).is_file()]
            if record['missing_outputs']:
                record['status']='failed'
        except BaseException as error:
            record.update(status='failed',output_hash_error=f'{type(error).__name__}: {error}')
        finish(record,path,files,protocol,start)
    print({'stage':stage,'status':record['status'],'receipt':str(path)})
    return 0 if record['status']=='passed' else 1


if __name__=='__main__':
    sys.exit(main())
