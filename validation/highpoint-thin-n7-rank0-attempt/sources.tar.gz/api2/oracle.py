#!/usr/bin/env python3
"""Independent scalar validation: existing SciPy Gauss-Jacobi simplex method.

This is numerical quadrature of the Feynman-parameter definition, not a tensor
reduction or symbolic algebra implementation. Fixed rules/mappings are retained
even if they fail to converge. No Rust, IREGI, or scalar-master calls occur here.
Adapted from target/certified-scalar-matched/independent-n6/oracle.py.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
NUMPY = Path('/nix/store/0xfxw2wqm5hmjkzlc2hdvy7gmdyb17bv-python3.13-numpy-2.5.4/lib/python3.13/site-packages')
SCIPY = Path('/nix/store/aa51afs73ayq7jirfbhxsr1qqlhphrza-python3.13-scipy-1.17.1/lib/python3.13/site-packages')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, record):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    tmp.replace(path)


def main():
    assert len(sys.argv) == 2
    output = Path(sys.argv[1])
    assert not output.exists(), 'never overwrite a captured oracle'
    os.environ['OPENBLAS_NUM_THREADS'] = '1'
    os.environ['OMP_NUM_THREADS'] = '1'
    sys.path[:0] = [str(NUMPY), str(SCIPY)]
    import numpy as np
    import scipy
    from scipy.special import roots_jacobi
    assert Path(np.__file__).resolve() == NUMPY/'numpy/__init__.py'
    assert Path(scipy.__file__).resolve() == SCIPY/'scipy/__init__.py'
    fixture = json.loads((HERE/'fixture.json').read_text())
    sample = fixture['samples'][0]
    # The frozen dyadic fixture is converted exactly to binary64 here.
    expected = [['0','0','0','0'],['0','1','0','0'],['0','0','1','0'],
                ['0','0','0','1'],['1/2','0','0','0'],['0','1','1','0'],['1/4','0','1','1']]
    assert [p['shift'] for p in sample['propagators']] == expected
    assert [p['mass_squared'] for p in sample['propagators']] == [[str(m),'0'] for m in [1,2,3,4,2,3,4]]
    assert [p['power'] for p in sample['propagators']] == [1]*7
    shifts = np.array([[0,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1],
                       [.5,0,0,0],[0,1,1,0],[.25,0,1,1]], dtype=float)
    masses = np.array([1,2,3,4,2,3,4], dtype=float)
    p_squared = shifts[:,0]**2 - np.sum(shifts[:,1:]**2,axis=1)
    record = {'status':'running', 'runs':[], 'fixture_sha256':sha(HERE/'fixture.json'),
              'script_sha256':sha(__file__), 'python':sys.version,
              'numpy_version':np.__version__, 'numpy_path':np.__file__,
              'scipy_version':scipy.__version__, 'scipy_path':scipy.__file__,
              'integrand_oneloop':'(-1)^7 Gamma(7-2)/F^(7-2) = -24/F^5',
              'F':'sum(x*m_squared)-sum(x*p_squared)+(sum(x*p))^2, metric +---',
              'native_conversion':'finite = i*pi^2*OneLoop finite; all poles vanish',
              'positive_F_lower_bound':'15/16', 'pole_reason':'UV degree 4-14=-10; positive F excludes IR',
              'uncertainty_kind':'successive fixed library rules, two mappings and floating floor; not a certified interval bound',
              'order_policy':[8,12,16], 'mappings':[[0,1,2,3,4,5,6],[6,4,2,0,5,3,1]]}
    save(output,record)
    all_started = time.monotonic()
    try:
        for order in record['order_policy']:
            for mapping, ordering in enumerate(record['mappings']):
                run = {'order':order,'mapping':mapping,'ordering':ordering,'status':'running',
                       'points_evaluated':0,'minimum_observed_F':None,'maximum_observed_F':None}
                record['runs'].append(run)
                save(output,record)
                started = time.monotonic()
                nodes, weights = [], []
                for axis in range(6):
                    alpha = 5-axis
                    z,w = roots_jacobi(order,alpha,0)
                    nodes.append((z+1)/2)
                    weights.append(w/2**(alpha+1))
                volume = float(np.prod([np.sum(w) for w in weights]))
                assert abs(volume-1/720) <= 1e-16
                partials = []
                for start in range(0,order**6,65536):
                    ids = np.unravel_index(np.arange(start,min(start+65536,order**6)),(order,)*6)
                    remaining = np.ones(len(ids[0]))
                    weight = np.ones(len(ids[0]))
                    x = np.empty((len(ids[0]),7))
                    for axis in range(6):
                        t = nodes[axis][ids[axis]]
                        x[:,ordering[axis]] = remaining*t
                        remaining *= 1-t
                        weight *= weights[axis][ids[axis]]
                    x[:,ordering[6]] = remaining
                    center = x@shifts
                    f = x@(masses-p_squared)+center[:,0]**2-np.sum(center[:,1:]**2,axis=1)
                    assert np.all(np.isfinite(f)) and np.all(f >= 15/16-1e-13)
                    lo,hi = float(f.min()),float(f.max())
                    run['minimum_observed_F'] = lo if run['minimum_observed_F'] is None else min(lo,run['minimum_observed_F'])
                    run['maximum_observed_F'] = hi if run['maximum_observed_F'] is None else max(hi,run['maximum_observed_F'])
                    partials.append(float(np.sum(weight*(-24/f**5))))
                    run['points_evaluated'] += len(f)
                estimate = math.fsum(partials)
                assert math.isfinite(estimate) and estimate < 0
                run.update(status='completed',oneloop_finite=estimate,
                           native_finite_imaginary=math.pi**2*estimate,
                           simplex_volume_from_rule=volume,
                           validation_seconds=time.monotonic()-started)
                save(output,record)
                print(json.dumps(run),flush=True)
        rows = {(r['order'],r['mapping']):r['oneloop_finite'] for r in record['runs']}
        result = rows[16,1]
        differences = [abs(rows[16,m]-rows[12,m]) for m in (0,1)] + [abs(rows[16,0]-result)]
        uncertainty = max(*differences,64*np.finfo(float).eps*abs(result))
        record['comparison'] = {'oneloop_finite':result,
             'native_finite_imaginary':math.pi**2*result,
             'estimated_native_absolute_uncertainty':math.pi**2*uncertainty,
             'order_and_mapping_differences':differences,
             'natural_scale':'1/1024', 'normalized_uncertainty':math.pi**2*uncertainty*1024,
             'uncertainty_below_1e_minus_10':math.pi**2*uncertainty*1024 <= 1e-10}
        record['status'] = 'completed' if record['comparison']['uncertainty_below_1e_minus_10'] else 'insufficient_convergence'
    except BaseException as error:
        record.update(status='failed',error=f'{type(error).__name__}: {error}')
        raise
    finally:
        record['elapsed_seconds'] = time.monotonic()-all_started
        save(output,record)
    return 0 if record['status']=='completed' else 2


if __name__ == '__main__':
    sys.exit(main())
