"""Independent saved N6 provenance. No producer imports or executable launches."""
from pathlib import Path
import datetime, hashlib, json, math, os

ROOT = Path.cwd()
H = ROOT / "target/native-f64-sixpoint-port/six-regression"
OUT = ROOT / "target/resume-20261025-review"
ALL = {}

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def absolute(name):
    return Path(name) if Path(name).is_absolute() else ROOT/name

def key(path):
    path = Path(path).resolve()
    return str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)

def bind(path, digest):
    name = key(absolute(path))
    assert name not in ALL or ALL[name] == digest
    ALL[name] = digest

def grant(operation, chain, inputs):
    label = "build" if operation == "build" else chain+"-"+operation
    path = H/('grant-'+label+'-001.json')
    value = read(path)
    assert value['approved_by'] == '/root' and value['operation'] == operation and value['chain'] == chain
    assert value['preparation_sha256'] == sha(H/'preparation.json')
    assert value['plan_sha256'] == sha(H/'command-plan.json') and value['runner_sha256'] == sha(H/'run.py')
    assert value['lifecycle_sha256'] == sha(H/'lifecycle.py') == 'c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824'
    cap = 120 if operation.startswith('ordinary-') else 180
    reserve = 25 if operation == 'build' else 20
    assert value['bound_seconds'] == cap and value['reserve_seconds'] == reserve
    assert value['cpus'] == ([6,7] if operation == 'build' else [22])
    constructors = False
    for item in value['prerequisites']:
        assert set(item) == {'path','sha256','expected_status','role'}
        receipt = read(absolute(item['path']))
        assert receipt['status'] == item['expected_status']
        inputs[key(absolute(item['path']))] = item['sha256']
        if item['role'] == 'constructors':
            assert item['path'] == 'validation/native-f64-sixpoint-constructors/qualification.json'
            assert item['sha256'] == 'a2df4383da9fa77e53c456749367eb76457cac3a187c139540e8cb532163b345'
            assert receipt['private_combined_patch_sha256'] == '70b5f94487f79d25c9bc831c0895fe2970ba8e222297ba0baf9f683d67101f9a'
            assert receipt['new_execution']['constructor_cases'] == 7
            for audit in receipt['independent_audits'].values():
                inputs[key(absolute(item['path']).parent/audit['path'])] = audit['sha256']
            constructors = True
    if operation != 'build':
        assert value['numerical_lease'] is True and constructors
    inputs[key(path)] = sha(path)
    return cap, reserve

def main():
    prep, plan, build = [read(H/name) for name in ['preparation.json','command-plan.json','build-001/run.json']]
    assert sha(H/'preparation.json') == '466af3c4ced8440304c3d182a02157eb97ac07078e203c16cc5b740a36673742'
    assert prep['command_plan_sha256'] == sha(H/'command-plan.json') == '69d1b6d9a52bd72736ab234d6429c4d80d003dfadc1b8c89c6e3555ab7351684'
    assert sha(H/'build-001/run.json') == '8564418a2f53dab1caf3aaab79f94af65734e6ab1764dad29091016060a2f03e'
    base = dict(prep['input_sha256'])
    base[key(H/'preparation.json')] = sha(H/'preparation.json')
    grant('build',None,base)
    assert build['inputs'] == base and len(base) == 655
    assert build['status'] == 'passed' and build['inputs_unchanged'] is True and build['cleanup_errors'] == []
    assert 0 <= build['elapsed_seconds'] <= 180 and build['reserve_seconds'] == 25
    assert len(build['steps']) == len(build['outputs']) == 7
    assert not any(build.get(k) for k in ['error','guard_error','cancellation','postguard_cancellation'])
    assert build['environment_additions'] == {}
    # Compile environments are specified by the frozen recipe and applied by
    # the frozen runner, rather than separately repeated in each child receipt.
    assert 'environment.update(spec["environment"])' in (H/'run.py').read_text()
    groups = []
    def terminal(step, cap, phase):
        assert step['status'] == 'exited' and step['returncode'] == 0 and step['owned_group_gone'] is True
        assert not any(step.get(k) for k in ['timeout','error','cancellation'])
        assert 0 < step['timeout_seconds'] <= cap and 0 <= step['elapsed_seconds'] <= 180
        assert math.isfinite(step['elapsed_seconds'])
        group = step['owned_process_group']
        assert type(group) is int and group > 0
        try:
            os.killpg(group,0)
            gone = False
        except ProcessLookupError:
            gone = True
        assert gone
        groups.append({'phase':phase,'owned_process_group':group,'currently_absent':True})
    for expected, actual in zip(plan['steps'],build['steps']):
        assert actual['command'] == expected['command']
        assert expected['environment']['CARGO_CRATE_NAME'] == 'iregi_rust'
        terminal(actual,90,'build-'+expected['label'])
        product = build['outputs'][expected['label']]
        assert product['path'] == expected['output'] and Path(product['path']).is_file()
    base[key(H/'build-001/run.json')] = sha(H/'build-001/run.json')
    for product in build['outputs'].values():
        base[key(product['path'])] = product['sha256']
    for label,digest in build['log_sha256'].items():
        base[key(H/'build-001'/(label+'.log'))] = digest
    for name,digest in base.items():
        bind(name,digest)
    stages = {}
    for chain in ['default','selective']:
        stages[chain] = {}
        for operation in ['ordinary-baseline','ordinary-candidate','128','256','lifecycle']:
            folder = H/chain/(operation+'-001')
            record = read(folder/'run.json')
            inputs = dict(base)
            cap,reserve = grant(operation,chain,inputs)
            if operation != 'ordinary-baseline':
                prior = H/chain/('ordinary-baseline-001/run.json' if operation == 'ordinary-candidate' else 'comparison-'+{'128':'ordinary','256':'128','lifecycle':'256'}[operation]+'.json')
                value = read(prior)
                assert value['status'] == 'passed'
                inputs[key(prior)] = sha(prior)
                for name,digest in value['inputs' if 'inputs' in value else 'input_sha256'].items():
                    assert name not in inputs or inputs[name] == digest
                    inputs[name] = digest
            assert record['inputs'] == inputs and record['operation'] == operation and record['chain'] == chain
            assert record['environment_additions'] == dict(RAYON_NUM_THREADS='1',RUST_TEST_THREADS='1',IREGI_PREPARATION_PROFILE='1',IREGI_PV_PREPARATION_PROFILE='1')
            assert record['status'] == 'passed' and record['inputs_unchanged'] is True and record['cleanup_errors'] == []
            assert record['bound_seconds'] == cap and record['reserve_seconds'] == reserve
            assert 0 <= record['elapsed_seconds'] <= cap and len(record['steps']) == 1
            assert not any(record.get(k) for k in ['error','guard_error','cancellation','postguard_cancellation'])
            product = chain+('-ordinary' if operation.startswith('ordinary-') else '-six_point' if operation in ['128','256'] else '-lifecycle')
            assert set(record['outputs']) == {'result.json','step-0.log','frozen-executable'}
            assert record['outputs']['frozen-executable'] == build['outputs'][product]['sha256']
            command = [plan['steps'][0]['command'][0],'-c','22',str(folder/'frozen-executable')]
            if operation.startswith('ordinary-'):
                command += [str(folder/'result.json'),operation.removeprefix('ordinary-')]
            elif operation in ['128','256']:
                command += ['validation/public-highpoint/fixture-conditioned_masses.json','6','3','pv',operation,'53','1',str(folder/'result.json')]
            else:
                command += ['validation/public-highpoint/fixture-conditioned_masses.json',str(folder/'result.json')]
            assert record['steps'][0]['command'] == command
            terminal(record['steps'][0],cap-reserve,chain+'-'+operation)
            for name,digest in inputs.items():
                bind(name,digest)
            bind(folder/'run.json',sha(folder/'run.json'))
            for name,digest in record['outputs'].items():
                bind(folder/name,digest)
            stages[chain][operation] = dict(receipt_sha256=sha(folder/'run.json'),protected_inputs=len(inputs),elapsed_seconds=record['elapsed_seconds'],bound_seconds=cap,reserve_seconds=reserve,same_built_product=product)
        for label in ['ordinary','128','256','lifecycle']:
            path = H/chain/('comparison-'+label+'.json')
            value = read(path)
            assert value['status'] == 'passed' and value['inputs_unchanged'] is True
            assert value['performance_qualified'] is value['production_application'] is value['current_cargo_qualified'] is False
            for name,digest in value['input_sha256'].items():
                bind(name,digest)
            bind(path,sha(path))
    summary,release = read(H/'stage-summary.json'),read(H/'numerical-release.json')
    assert len(groups) == len({g['owned_process_group'] for g in groups}) == 17
    assert summary['failed_or_unrun_stages'] == [] and type(summary['automatic_retries']) is int and summary['automatic_retries'] == 0
    assert summary['all_producer_owned_groups_absent'] is True
    assert release['status'] == 'numerical-lease-released' and release['all_owned_groups_absent'] is True
    assert release['stage_summary']['sha256'] == sha(H/'stage-summary.json')
    assert {g['group'] for g in release['owned_group_checks']} == {g['owned_process_group'] for g in groups}
    bind(H/'stage-summary.json',sha(H/'stage-summary.json'))
    bind(H/'numerical-release.json',sha(H/'numerical-release.json'))
    for name,digest in ALL.items():
        assert sha(absolute(name)) == digest,name
    review = dict(status='passed-independent-retained-n6-provenance-audit',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reviewer='/root/resume_auditor',
        scope='Independent deduplicated source/native/tool/reference/binary/log closure; exact7compile/10runtime argv/grants/prerequisites/ownedcopies and17wholePG checks. Compileenvs are fromfrozenrecipe+runner, notseparatelyrecorded perchild. No producerimports or compiled/numerical/test execution.',
        preparation_sha256=sha(H/'preparation.json'),command_plan_sha256=sha(H/'command-plan.json'),stage_summary_sha256=sha(H/'stage-summary.json'),release_sha256=sha(H/'numerical-release.json'),
        unique_bound_files_rehashed=len(ALL),build_input_bindings=655,fresh_build_products=7,runtime_stages=stages,saved_gates_passed=8,owned_groups=groups,
        independent_numeric_audit_sha256=sha(OUT/'six-regression-independent-numeric-audit.json'),independent_numeric_script_sha256=sha(OUT/'audit_six_regression_independent.py'),findings=[],
        limitations=['Privatecombineddefault/selectiveopt0 frozen-dependency regression only; currentCargo andproductionapplication remainseparate.',
                    'SixPointconstructors forceSymbolica. These N6gates preservevalues; nativeABCexecution was qualifiedseparately bywhole38.',
                    'No publichighpointf64/DD/Dual/generalized/complexmass/rank7/N7/performance expansion inferred.'])
    destination = OUT/'six-regression-independent-provenance-audit.json'
    with destination.open('x') as stream:
        json.dump(review,stream,indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=review['status'],sha256=sha(destination),unique_files=len(ALL),build_products=7,runtime_stages=10,gates=8,groups_absent=17)))

if __name__ == '__main__':
    main()
