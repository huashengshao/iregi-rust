"""Independent retained-N6 saved-data audit; stdlib only, never runs a kernel.

Do not run until the runtime owner confirms BOTH chains and ALL stages terminal.
No producer/common/comparator modules are imported. Dependency/command closure
auditing belongs to the parent reviewer; numerical and capture checks are here.
"""
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
import datetime
import hashlib
import json
import math
import re
import sys

R = Path.cwd()
H = R / "target/native-f64-sixpoint-port/six-regression"
V2 = R / "validation/highpoint-six-point-api/qualified-v2"
FIXTURE = R / "validation/public-highpoint/fixture-conditioned_masses.json"
REFERENCE = R / "validation/public-highpoint/reference-conditioned_masses.json"
OUT = R / "target/resume-20261025-review/six-regression-independent-numeric-audit.json"
CHECKS = 0
BOUND = {}
PARTS = ("real", "imaginary")
STAT = {"input_rows", "argument_rows", "master_family_batches", "master_rows", "pentagon_box_rows", "reduction_rows", "fallback_rows", "fallback_successes", "analytic_rows"}
CERT = {"input_rows", "evaluated_rows", "passes", "reduction_batches"}
SCHEDULE = [("singleton_base", [0]), ("singleton_scaled", [1]), ("singleton_singular", [2]), ("empty_after_failure", []),
            ("mixed", [0, 2, 1, 0, 2]), ("reordered", [2, 0, 1, 2, 0]), ("mixed_chunk_first", [0, 2]),
            ("mixed_chunk_second", [1, 0, 2]), ("repeated_good", [0, 1, 0, 1, 0]), ("empty_after_repetition", []), ("base_after_empty", [0])]
TERMS = [[0, 0, 0, 0], [1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 1]]
COEFFICIENTS = [2, -3, 1, 4]


def check(condition, message="check"):
    global CHECKS
    CHECKS += 1
    if not condition:
        raise AssertionError(message)


def exact(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def decode(text, **options):
    def bad(value):
        raise ValueError("nonstandard JSON constant: " + value)
    return json.loads(text, object_pairs_hook=unique, parse_constant=bad, **options)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    path = Path(path)
    BOUND[str(path.relative_to(R))] = digest(path)
    return decode(path.read_text())


def size(values, count):
    check(type(values) is list and len(values) == count, ("length", count))
    return values


def basis(rank):
    return [[t, x, y, total-t-x-y] for total in range(rank+1) for t in range(total, -1, -1)
            for x in range(total-t, -1, -1) for y in range(total-t-x, -1, -1)]


def rational(text):
    check(type(text) is str and re.fullmatch(r"-?\d+(?:/[1-9]\d*)?", text) is not None)
    q = Fraction(text)
    check(q.denominator & (q.denominator - 1) == 0, "represented output is binary")
    return q


def dec(value):
    q = value if isinstance(value, Fraction) else Fraction(value)
    return Decimal(q.numerator) / Decimal(q.denominator)


def norm(values):
    return sum((q*q for q in values), Decimal(0)).sqrt()


def distance(a, b):
    return norm(tuple(x-y for x, y in zip(a, b)))


def scale(sample):
    ps = sample["propagators"][:6]
    momenta = [[dec(q) for q in p["shift"]] for p in ps]
    squared = max(Decimal(1), *(abs(dec(p["mass_squared"][0])) for p in ps))
    for i in range(6):
        for j in range(i):
            delta = [x-y for x, y in zip(momenta[i], momenta[j])]
            squared = max(squared, abs(delta[0]**2-sum(q*q for q in delta[1:])))
    return squared.sqrt()


def settings(rank):
    return dict(propagators=6, rank=rank, powers=[1]*6, dimension_shift=0, algorithm="PassarinoVeltman",
                convention="IregiNative", tensor_weights="Components", invariants="FromShifts", input_policy="Preserve")


def inputs(sample):
    ps = sample["propagators"][:6]
    check(len(ps) == 6 and all(p["power"] == 1 for p in ps))
    return [[str(Fraction(q)), "0"] for p in ps for q in p["shift"]] + [[str(Fraction(q)) for q in p["mass_squared"]] for p in ps] + [[str(Fraction(sample["mu"])), "0"]]


def coefficient(slot, signed):
    keys = {"real", "imaginary", "real_precision", "imaginary_precision"} | ({"real_negative", "imaginary_negative"} if signed else set())
    check(type(slot) is dict and set(slot) == keys)
    for part in PARTS:
        q = rational(slot[part]); bits = slot[part + "_precision"]
        check(type(bits) is int and bits >= 0 and (q == 0 or bits > 0))
        if signed:
            sign = slot[part + "_negative"]
            check(type(sign) is bool and (q == 0 or sign == (q < 0)))
    return tuple(dec(slot[part]) for part in PARTS)


def moment_array(moments, rank, signed):
    poles = 0
    for row in size(moments, len(basis(rank))):
        for pole, slot in enumerate(size(row, 4)):
            values = coefficient(slot, signed)
            if pole < 3:
                check(values == (Decimal(0), Decimal(0)), "massive convergent poles exactly zero")
                poles += 1
    return poles


def compare_moments(actual, target, sample, rank, original=False):
    q = scale(sample); errors = []
    for monomial, a, b in zip(basis(rank), size(actual, len(basis(rank))), target[:len(basis(rank))]):
        natural = q**(sum(monomial)-8)
        for left, right in zip(size(a, 4), size(b, 4)):
            av = tuple(dec(left[p]) for p in PARTS)
            bv = tuple(Decimal(str(v)) for v in right) if original else tuple(dec(right[p]) for p in PARTS)
            errors.append(distance(av, bv) / max(natural, norm(bv)))
    check(len(errors) == len(basis(rank))*4)
    return errors


def stat(value, keys):
    if type(value) is str:
        typename = "ExecutionStats" if keys == STAT else "CertificateExecutionStats"
        match = re.fullmatch(typename + r" \{ (.*) \}", value)
        check(match is not None)
        fields = [entry.split(": ") for entry in match[1].split(", ")]
        check(all(len(entry) == 2 and entry[1].isdigit() for entry in fields))
        value = {k: int(v) for k, v in fields}
        check(len(value) == len(fields))
    check(type(value) is dict and set(value) == keys and all(type(v) is int and v >= 0 for v in value.values()))
    if keys == CERT:
        check(value["passes"] <= value["evaluated_rows"] and value["reduction_batches"] <= value["input_rows"])
        if value["input_rows"] == 0:
            check(not any(value.values()))
    return value


def execution(value, count, ids):
    check(set(value) == {"parent_input_rows", "child_batch_calls", "packed_child_rows", "parent_batch_calls", "packed_parent_rows", "child_execution", "parent_execution", "child_certificate_execution", "parent_certificate_execution"})
    for k in ["parent_input_rows", "child_batch_calls", "packed_child_rows", "parent_batch_calls", "packed_parent_rows"]:
        check(type(value[k]) is int and value[k] >= 0)
    child = stat(value["child_execution"], STAT); parent = stat(value["parent_execution"], STAT)
    cc = stat(value["child_certificate_execution"], CERT); pc = stat(value["parent_certificate_execution"], CERT)
    check(not any(pc.values()) and cc["input_rows"] <= child["fallback_rows"])
    check(value["parent_input_rows"] == count and value["child_batch_calls"] == int(count > 0) and value["packed_child_rows"] == 6*count and child["input_rows"] == 6*count)
    packed = value["packed_parent_rows"]
    check(sum(i < 2 for i in ids) <= packed <= count and value["parent_batch_calls"] == int(packed > 0))
    check(parent["input_rows"] == parent["argument_rows"] == packed and parent["reduction_rows"] <= packed)
    check(all(parent[k] == 0 for k in ["master_family_batches", "master_rows", "pentagon_box_rows", "fallback_rows", "fallback_successes", "analytic_rows"]))
    if count == 0:
        check(not any(child.values()) and not any(parent.values()) and not any(cc.values()) and not any(pc.values()))
    else:
        check(child["argument_rows"] >= 6*count)


def validate_reference(fixture, reference):
    check(reference["status"] == "complete" and reference["reference"] == "untouched original IREGI" and reference["fixture_sha256"] == digest(FIXTURE))
    check(reference["executable_sha256"] == "8ee49ae42cb6994f4bd42ed3a3920152e767407ecdafd8986577d5496370a379")
    samples = {s["id"]: s for s in fixture["samples"]}; retained = {}
    seen = set()
    for case in reference["cases"]:
        sample = samples[case["sample"]]; n = case["propagators"]; mode = case["mode"]
        label = f'n{n}_{sample["id"]}_mode{mode}'
        check(n in [6, 7] and mode in [0, 1, 2] and case["rank"] == 7 and case["id"] == label and label not in seen)
        seen.add(label); lines = case["request"].splitlines(); check(len(lines) == n+2 and lines[-1] == "QUIT")
        header = lines[0].split()
        check(len(header) == 10 and header[:7] == ["EVAL", label, "tensor", str(mode), str(n), "7", "0"] and Fraction(header[7]) == Fraction(sample["mu"]) and header[8] == "0" and Fraction(header[9]) == Fraction("1e-6"))
        for line, p in zip(lines[1:-1], sample["propagators"][:n]):
            check(list(map(Fraction, line.split())) == list(map(Fraction, p["shift"] + p["mass_squared"] + [str(p["power"])])))
        if case["status"] == "captured":
            response = case["response"]
            raw = [decode(line[7:], parse_float=str) for line in case["stdout"].splitlines() if line.startswith("RESULT ")]
            check(case["exit_code"] == 0 and exact(raw, [response]) and response["id"] == label)
            check(type(response["stable"]) is bool and response["poles"] == ["uv1", "ir1", "ir2", "finite"])
            for moment in size(response["moments"], 330):
                for slot in size(moment, 4):
                    check(all(Decimal(str(v)).is_finite() for v in size(slot, 2)))
            if n == 6 and mode == 0 and sample["id"] in ["base", "scaled_by_two"]:
                check(response["stable"] is True)
                retained[sample["id"]] = response["moments"]
    check(len(seen) == 18 and set(retained) == {"base", "scaled_by_two"})
    return [retained["base"], retained["scaled_by_two"]]


def debug_statuses(text):
    check(type(text) is str and text.startswith("[") and text.endswith("]"))
    result = []; start = 1; depth = 0; quoted = escaped = False
    for i, char in enumerate(text[1:-1], 1):
        if quoted:
            if escaped: escaped = False
            elif char == "\\": escaped = True
            elif char == '"': quoted = False
        elif char == '"': quoted = True
        elif char in "([": depth += 1
        elif char in ")]": depth -= 1
        elif char == "," and depth == 0:
            result.append(text[start:i].strip()); start = i+1
        check(depth >= 0)
    check(depth == 0 and not quoted and not escaped)
    if text[start:-1].strip(): result.append(text[start:-1].strip())
    return result


def ordinary_number(value, domain):
    check(set(value) == {"rational", "bits", "negative_sign"})
    q = rational(value["rational"]); bits = value["bits"]
    check(type(bits) is int and bits >= 0 and (q == 0 or bits > 0) and type(value["negative_sign"]) is bool)
    check(q == 0 or value["negative_sign"] == (q < 0))
    if domain in ["f64", "DoubleFloat"]: check(bits == {"f64": 53, "DoubleFloat": 106}[domain])


def ordinary(chain):
    a = read(H/chain/"ordinary-baseline-001/result.json"); b = read(H/chain/"ordinary-candidate-001/result.json")
    check(exact(a, b), "complete ordinary baseline/candidate record parity")
    expected = [(domain, n, rank, components) for domain in ["f64", "DoubleFloat", "Float128"] for n, rank, components in [(1, 2, 1), (2, 2, 1), (3, 1, 1), (2, 1, 3)]]
    check([(x["domain"], x["propagators"], x["rank"], x["components"]) for x in size(a, 12)] == expected)
    successes = failures = slots = contracted_slots = 0
    for case in a:
        result = case["result"]; components = case["components"]; rank = case["rank"]
        for z in size(case["input"], 5*(5*case["propagators"]+1)*components):
            for number in size(z, 2): ordinary_number(number, case["domain"])
        check(result["components"] == components)
        check(result["basis"] == "[" + ", ".join("Monomial(" + str(m) + ")" for m in basis(rank)) + "]")
        check(result["metadata"] == "ResultMetadata { convention: IregiNative, tensor_weights: Components, dual_shape: " + ("None" if components == 1 else "Some([[0], [1], [2]])") + " }")
        statuses = size(debug_statuses(result["statuses"]), 5)
        check(statuses[4].startswith("InvalidInput("))
        for key in ["metadata", "statuses", "fallback", "analytic", "diagnostics", "statistics"]:
            check(exact(result[key], result["repeat_"+key]), ("ordinary repeat metadata", key))
        check(result["contraction_statuses"] == result["statuses"] and exact(result["contraction_fallback"], result["fallback"]) and exact(result["contraction_analytic"], result["analytic"]))
        check(exact(result["moments"], result["repeat"]))
        for key in ["fallback", "analytic"]: check(all(type(v) is bool for v in size(result[key], 5)))
        check(all(type(notes) is list and all(type(v) is str for v in notes) for notes in size(result["diagnostics"], 5)))
        check(stat(result["statistics"], STAT)["input_rows"] == 5)
        for index, (moment, contraction) in enumerate(zip(size(result["moments"], 5), size(result["contracted"], 5))):
            if moment is None:
                check(contraction is None and statuses[index] != "Success"); failures += 1
            else:
                check(statuses[index] == "Success")
                width = len(basis(rank))*4*components
                for z in size(moment, width) + size(contraction, 4*components):
                    for number in size(z, 2): ordinary_number(number, case["domain"])
                successes += 1; slots += width; contracted_slots += 4*components
    check((successes, failures, slots) == (42, 18, 2200))
    return dict(pairs=12, successful_lanes=successes, explicit_matching_failure_controls=failures, complex_taylor_laurent_slots=slots, contracted_taylor_laurent_slots=contracted_slots, complete_record_exact_parity=True)


def rank3(chain, fixture, originals):
    records = {}; report = {}; arrays = {}
    for bits in [128, 256]:
        record = read(H/chain/(str(bits)+"-001")/"result.json"); records[bits] = record
        check(record["settings"] == settings(3) and record["working_bits"] == bits and record["requested_bits"] == 53)
        check(record["status"] == "all_lanes_success" and record["rows"] == record["components"] == 1 and record["lane_statuses"] == ["Success"])
        check(record["basis"] == basis(3) and record["fixture"] == str(FIXTURE.relative_to(R)) and record["input_exact_rational"] == [inputs(fixture["samples"][0])])
        lane = size(record["lanes"], 1)[0]; check(lane["row"] == 0 and lane["status"] == "Success")
        arrays[bits] = lane["moments"]; poles = moment_array(arrays[bits], 3, False); check(poles == 105)
        execution(record["execution"], 1, [0])
        check(all(type(q) is bool for field in ["fallback_used", "analytic_used"] for q in size(record[field], 1)))
        check(all(type(v) is list and all(type(q) is str for q in v) for v in size(record["diagnostics"], 1)))
        old = read(R/f"validation/highpoint-thin-n6-generic/fixed/n6-rank3-{bits}-001/result.json")
        check(old["settings"] == record["settings"] and old["input_exact_rational"] == record["input_exact_rational"] and old["basis"] == record["basis"])
        original_errors = compare_moments(arrays[bits], originals[0], fixture["samples"][0], 3, True)
        historical_errors = compare_moments(arrays[bits], old["lanes"][0]["moments"], fixture["samples"][0], 3)
        check(max(original_errors) <= Decimal("1e-10") and max(historical_errors) <= Decimal("1e-10"))
        report[str(bits)] = dict(complex_slots=140, exact_zero_poles=105, maximum_original_error=str(max(original_errors)), maximum_historical_error=str(max(historical_errors)),
                                 historical_exact_slot_differences=sum(not exact(x, y) for a, b in zip(arrays[bits], old["lanes"][0]["moments"]) for x, y in zip(a, b)))
    convergence = compare_moments(arrays[128], arrays[256], fixture["samples"][0], 3)
    check(max(convergence) <= Decimal(2)**-80)
    report["convergence"] = dict(complex_slots=140, tolerance="2^-80", maximum_error=str(max(convergence)))
    return report


def differences(actual, target):
    result = []
    for moment, (left, right) in enumerate(zip(actual, target)):
        for pole, (a, b) in enumerate(zip(left, right)):
            for part in PARTS:
                p = part+"_precision"; n = part+"_negative"
                same = (a[part] == b[part], a[p] == b[p], a[n] == b[n])
                if not all(same):
                    result.append(dict(moment=moment, laurent_slot=pole, part=part, same_exact_value=same[0], same_precision=same[1], same_sign_bit=same[2],
                                       current=dict(value=a[part], precision=a[p], negative=a[n]), singleton=dict(value=b[part], precision=b[p], negative=b[n])))
    return result


def contraction_targets(moments, original=False):
    positions = [basis(2).index(term) for term in TERMS]
    return [tuple(dec(sum((Fraction(c)*Fraction(str(moments[i][pole][part_index]) if original else moments[i][pole][part]) for c, i in zip(COEFFICIENTS, positions)), Fraction(0)))
                  for part_index, part in enumerate(PARTS)) for pole in range(4)]


def lifecycle(chain, fixture, originals):
    record = read(H/chain/"lifecycle-001/result.json")
    check(record["schema_version"] == 1 and record["status"] == "capture_complete_status_contract_passed" and record["active_case"] is None)
    check(record["settings"] == settings(2) and record["working_bits"] == 128 and record["requested_bits"] == 53 and record["basis"] == basis(2))
    check(record["fixture"] == str(FIXTURE.relative_to(R)) and record["input_exact_rational"] == [inputs(s) for s in fixture["samples"]])
    check(record["schedule"] == [dict(name=name, fixture_indices=ids) for name, ids in SCHEDULE])
    check(record["interface"] == "restricted public SixPointReductionPlan / SixPointWorkspace<Float>" and record["workspace_lifecycle"] == "one owned workspace reused for every scheduled call")
    check(record["expected_successful_fixture_indices"] == [0, 1] and record["expected_rejected_fixture_indices"] == [2])
    check(record["numerical_tolerance_qualification"] == "pending_independent_qualifier")
    check(type(record["elapsed_seconds"]) in [int, float] and math.isfinite(record["elapsed_seconds"]) and 0 <= record["elapsed_seconds"] <= 180)
    baseline = {}; contracted_baseline = {}; flags = {}; good = bad = zero_poles = 0
    max_original = max_singleton = Decimal(0); maxima = {k: Decimal(0) for k in ["captured_moment_sum", "original_reference_sum", "singleton"]}
    value_diffs = contraction_diffs = 0; rows = []
    for call, ((name, ids), case) in enumerate(zip(SCHEDULE, size(record["cases"], 11))):
        n = len(ids); check(case["name"] == name and case["fixture_indices"] == ids and case["rows"] == n and case["components"] == 1 and case["basis"] == basis(2))
        check(case["metadata"] == dict(convention="IregiNative", tensor_weights="Components", dual_shape=None))
        for key in ["status_shape_contract_pass", "input_preserved_exactly", "packing_contract_pass"]: check(case[key] is True)
        check(case["capture_status"] == "captured")
        check(type(case["diagnostic_reduction_seconds"]) in [int, float] and math.isfinite(case["diagnostic_reduction_seconds"]) and 0 <= case["diagnostic_reduction_seconds"] <= record["elapsed_seconds"])
        for key in ["lanes", "lane_statuses", "fallback_used", "analytic_used", "diagnostics", "singleton_comparisons"]: size(case[key], n)
        check(all(type(q) is bool for k in ["fallback_used", "analytic_used"] for q in case[k]))
        check(all(type(notes) is list and all(type(q) is str for q in notes) for notes in case["diagnostics"]))
        execution(case["execution"], n, ids)
        check(case["empty_work_and_diagnostics_reset"] is (True if n == 0 else None))
        contraction = case["contraction"]
        check(set(contraction) == {"monomials", "coefficients", "evaluated_rows", "lanes", "fallback_used", "analytic_used"})
        check(contraction["monomials"] == TERMS and contraction["coefficients"] == COEFFICIENTS and type(contraction["evaluated_rows"]) is int and contraction["evaluated_rows"] == sum(i < 2 for i in ids))
        check(exact(contraction["fallback_used"], case["fallback_used"]) and exact(contraction["analytic_used"], case["analytic_used"]))
        expected_comparisons = []
        for row, (fixture_index, lane, contracted) in enumerate(zip(ids, case["lanes"], size(contraction["lanes"], n))):
            check(lane["row"] == row and lane["fixture_index"] == fixture_index and lane["status"] == case["lane_statuses"][row])
            check(lane["fallback_used"] is case["fallback_used"][row] and lane["analytic_used"] is case["analytic_used"][row])
            check(set(contracted) == {"row", "fixture_index", "status", "slots"} and contracted["row"] == row and contracted["fixture_index"] == fixture_index and contracted["status"] == lane["status"])
            observed_flags = (lane["fallback_used"], lane["analytic_used"])
            if fixture_index in flags: check(observed_flags == flags[fixture_index])
            else: flags[fixture_index] = observed_flags
            if fixture_index == 2:
                check(lane["expected_outcome"] == "explicit_rejection" and type(lane["status"]) is str and lane["status"].startswith(("Unstable(", "MasterFailure(")))
                check(lane["moments"] is None and lane["complete_native_array"] is False and contracted["slots"] is None)
                expected_comparisons.append(dict(row=row, fixture_index=2, comparison="failure_control_not_numerical_agreement")); bad += 1
                continue
            check(lane["expected_outcome"] == lane["status"] == "Success" and lane["complete_native_array"] is True)
            zero_poles += moment_array(lane["moments"], 2, True)
            for pole, slot in enumerate(size(contracted["slots"], 4)):
                value = coefficient(slot, True)
                if pole < 3: check(value == (Decimal(0), Decimal(0)))
            if fixture_index not in baseline:
                check(call == fixture_index); baseline[fixture_index] = lane["moments"]; contracted_baseline[fixture_index] = contracted["slots"]
            delta = differences(lane["moments"], baseline[fixture_index]); value_diffs += len(delta)
            expected_comparisons.append(dict(row=row, fixture_index=fixture_index, comparison="complete_successful_native_arrays", exact_value_precision_sign_identity=not delta,
                                             differences=delta, numerical_tolerance_qualification="deferred_to_independent_normalized_1e-10_qualifier"))
            sample = fixture["samples"][fixture_index]
            errors = compare_moments(lane["moments"], originals[fixture_index], sample, 2, True)
            reuse_errors = compare_moments(lane["moments"], baseline[fixture_index], sample, 2)
            check(max(errors) <= Decimal("1e-10") and max(reuse_errors) <= Decimal("1e-10"))
            max_original = max(max_original, max(errors)); max_singleton = max(max_singleton, max(reuse_errors))
            q = scale(sample); natural = sum((Decimal(abs(c))*q**(sum(term)-8) for c, term in zip(COEFFICIENTS, TERMS)), Decimal(0))
            targets = {"captured_moment_sum": contraction_targets(lane["moments"]), "original_reference_sum": contraction_targets(originals[fixture_index], True),
                       "singleton": [tuple(dec(s[p]) for p in PARTS) for s in contracted_baseline[fixture_index]]}
            per = {}
            for label, target in targets.items():
                contracted_errors = [distance(coefficient(actual, True), expected)/max(natural, norm(expected)) for actual, expected in zip(contracted["slots"], target)]
                check(len(contracted_errors) == 4 and max(contracted_errors) <= Decimal("1e-10"))
                maxima[label] = max(maxima[label], max(contracted_errors)); per[label] = str(max(contracted_errors))
            contraction_diffs += len(differences([contracted["slots"]], [contracted_baseline[fixture_index]]))
            rows.append(dict(call=name, row=row, fixture_index=fixture_index, original_maximum_error=str(max(errors)), singleton_maximum_error=str(max(reuse_errors)), contraction_maxima=per)); good += 1
        check(exact(case["singleton_comparisons"], expected_comparisons), "complete exact-value/precision/sign difference inventory")
    check((good, bad, zero_poles) == (17, 7, 765))
    return dict(calls=11, empty_calls=2, successful_lanes=good, explicit_failure_controls=bad, complex_moment_slots=1020, exact_zero_poles=zero_poles, contracted_complex_slots=68,
                maximum_original_error=str(max_original), maximum_singleton_error=str(max_singleton), contraction_maxima={k: str(v) for k, v in maxima.items()},
                singleton_value_precision_sign_difference_entries=value_diffs, contraction_singleton_difference_entries=contraction_diffs, rows=rows)


def terminal_records(chain):
    for op in ["ordinary-baseline", "ordinary-candidate", "128", "256", "lifecycle"]:
        record = read(H/chain/(op+"-001")/"run.json")
        cap = 120 if op.startswith("ordinary-") else 180
        check(record["status"] == "passed" and record["operation"] == op and record["chain"] == chain and record["bound_seconds"] == cap and record["reserve_seconds"] == 20)
        check(record["inputs_unchanged"] is True and record["cleanup_errors"] == [] and not any(record.get(k) for k in ["error", "guard_error", "cancellation", "postguard_cancellation"]))
        check(type(record["elapsed_seconds"]) in [int, float] and math.isfinite(record["elapsed_seconds"]) and 0 <= record["elapsed_seconds"] <= cap)
        step = size(record["steps"], 1)[0]
        check(step["status"] == "exited" and type(step["returncode"]) is int and step["returncode"] == 0 and step["owned_group_gone"] is True)
        check(not step.get("timeout") and not step.get("error") and not step.get("cancellation"))
        check(type(step["owned_process_group"]) is int and step["owned_process_group"] > 0)
        check(record["outputs"]["result.json"] == digest(H/chain/(op+"-001")/"result.json"))
    for op in ["ordinary", "128", "256", "lifecycle"]:
        record = read(H/chain/("comparison-"+op+".json"))
        check(record["status"] == "passed" and record["passed"] is True and record["chain"] == chain and record["inputs_unchanged"] is True)
        check(record["production_application"] is False and record["current_cargo_qualified"] is False)


def main():
    check(sys.argv[1:] == ["--all-stages-terminal-confirmed"], "Runtime owner must first confirm all stages terminal")
    fixture = read(FIXTURE); reference = read(REFERENCE)
    check([s["id"] for s in fixture["samples"]] == ["base", "scaled_by_two", "first_mass_squared_plus_one"])
    results = {}
    with localcontext() as context:
        context.prec = 220
        originals = validate_reference(fixture, reference)
        for chain in ["default", "selective"]:
            terminal_records(chain)
            results[chain] = dict(ordinary=ordinary(chain), rank3=rank3(chain, fixture, originals), lifecycle=lifecycle(chain, fixture, originals))
    for source in [Path(__file__), H/"protocol.md", H/"common.py", H/"compare.py", H/"preparation.json", H/"command-plan.json",
                   V2/"compare.py", V2/"compare-lifecycle.py", R/"validation/highpoint-six-point-api/source-v1/ordinary-equivalence-driver.rs", R/"validation/highpoint-six-point-api/source-v1/public-lifecycle-driver.rs"]:
        BOUND[str(source.relative_to(R))] = digest(source)
    output = dict(status="independent-retained-n6-saved-numerical-audit-passed", reviewer="/root/resume_auditor/whole_probe_review", created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  scope="Stdlib-only independent audit of saved records after both chains and all stages terminal; no producer module imports, compilers, kernels, masters or numerical library execution.",
                  checks=CHECKS, source_and_data_sha256=BOUND, chains=results, blocking_findings=[],
                  limitations=["The parent separately audits source, dependency, command and executable provenance; this audit rehashes only numerical data, small source and terminal receipts.",
                               "All quantities stay Fraction/Decimal; no intermediate f64 conversion is used.",
                               "Ordinary parity is complete represented value/precision/sign and record equality, not an independent integral oracle. Driver-local repeats and input construction rely on separately reviewed executed source assertions where separate before/after snapshots are not exported.",
                               "Lifecycle contractions are independently summed from saved moments as exact rational linear combinations and compared numerically; no integral evaluator or production algebra routine is replaced.",
                               "These are retained low-rank correctness checks. No public high-point Dual, f64/DD N6 accuracy, generalized, rank7/N7, current Cargo, native execution, performance or production-promotion claim follows."])
    with OUT.open("x") as stream:
        json.dump(output, stream, indent=2, allow_nan=False); stream.write("\n")
    print(json.dumps(dict(status=output["status"], path=str(OUT.relative_to(R)), sha256=digest(OUT), checks=CHECKS)))


if __name__ == "__main__":
    main()
