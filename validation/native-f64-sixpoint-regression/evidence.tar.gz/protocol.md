# Retained N6 regression for the combined optional native-master policy

This is a source-only proposal. Preparing it executes no compiler, reducer,
scalar master, reference or oracle. ROOT owns compiler scheduling and every
numerical lease. Every operation needs its own exact grant; a passed operation
never launches its successor, retries, extends its deadline or changes admission.
No production file is changed by these scripts.

The current live 80-file base is checked against the existing private `base`
snapshot. The 85-file combined proposal and 540-input existing codegen closure
are rebound by hash. Both combined core rlibs and their test binaries retain the
audited source/feature/artifact identities. The 30-file combined masters source
is the already-qualified native candidate; default/selective master rlibs are
reused, with their exact existing codegen provenance. This is the old frozen
non-Python dependency context with opt0 project code, **not current Cargo feature
qualification and not an optimized/performance build**.

## Exact minimal compiler products

One fresh base core rlib uses the current-base snapshot and the original frozen
`libiregi_masters-f07797f04e91954e.rlib`. Each of the two existing combined core
chains gets three unchanged Rust drivers:

1. The qualified `source-v1/ordinary-equivalence-driver.rs`, linked with the fresh
   current-base core as `baseline` and the chosen combined core as `candidate`.
2. The unchanged `examples/six_point.rs` from the actual combined frozen source.
3. The qualified `source-v1/public-lifecycle-driver.rs`.

Thus the exact plan has **seven fresh rustc products**, with no Symbolica,
oneloopmaster, masters or combined-core rebuild and no new unit-test binary.
The default/selective masters are separate dependencies; the baseline core's
original master identity remains in the old frozen dependency directory. Shared
`NativeFloat` comes from the same oneloop archive, as in existing qualification.
Commands are argument arrays in `command-plan.json`, generated without shell
interpolation. Compile CPUs are 6,7; opt0/debug assertions/overflow checks and
the compiler/linker paths match the existing combined build context.

The complete seven-step build has a fixed **180-second aggregate** cap and a
**25-second postwork reserve**, at most 90 seconds per compiler invocation.
The prior V2 six-product isolated build used 180 seconds; its products and
driver sources provide the same correctness-only context. A failure preserves
all remaining products as unrun; there is no automatic retry or cache rebuild.
If the proposed budget is rejected at review, change/review/freeze it before the
first attempt, never after observing a timeout.

## Numerical stages, separately for default and selective

CPU22, one Rayon thread and one Rust test thread. Preparation-profile environment
matches V2 and is recorded. The user's local licensed environment is sourced
silently; the key is never printed or bound into evidence. Each operation uses
an owned immutable executable copy whose hash matches its built product.

| Operation | Requested output | Aggregate | Postwork reserve | Historical V2 total |
| --- | --- | ---: | ---: | ---: |
| ordinary-baseline | 12 complete generic cases, current-base default constructors | 120s | 20s | 20.43s |
| ordinary-candidate | Same 12 cases, chosen combined default constructors | 120s | 20s | approximately 20s |
| 128 | N6/rank3/Float128/request53, retained base, 140 complex Laurent slots | 180s | 20s | 47.34s |
| 256 | N6/rank3/Float256/request53, retained base, 140 complex Laurent slots | 180s | 20s | 46.74s |
| lifecycle | N6/rank2/Float128/request53, original eleven-call schedule and contractions | 180s | 20s | 62.93s |

All caps include preflight hashing, executable freezing, owned-child termination,
terminal persistence, postrun source/output/log guards and bookkeeping. The
unchanged c193cd72 lifecycle helper checks/kills the whole owned PG even after
its leader exits. Each child terminal is persisted before final reads/hashes.
Signal cancellation or failure stops the stage and leaves successors unrun.

Numerical grants must bind the exact independently qualified seven-constructor
capsule at `validation/native-f64-sixpoint-constructors/qualification.json`, with
role `constructors` and expected status `private-constructor-cohort-qualified`.
The runner requires its combined-patch identity, all seven completed constructors,
unchanged inputs, absent owned groups, no deadline/cleanup error, and both pinned
independent audit files. ROOT can additionally require the separate 38-request
whole-call gate as an exact hash-bound `passed` receipt. This packet never
fabricates an outcome or assumes a current numerical lease.

Within each chain, build passes before ordinary-baseline; ordinary-baseline's
terminal passes before ordinary-candidate. The unchanged exact ordinary comparator
must pass before 128; the unchanged 128 original-reference gate must pass before
256; the unchanged 128/256 convergence gate must pass before lifecycle. The
saved lifecycle comparator is a separate explicit step. ROOT chooses when to
grant each stage and may require additional independent evidence review.

## Unchanged admission and precise overlap

`compare.py` is a provenance adapter to the *unchanged* V2 comparator functions.
The old producer-specific harness is replaced by validation of the seven actual
new compiler commands, their source/artifact/input closure, exact grants, owned
runtime records and frozen executable hashes. The original numerical logic,
ordering, complete-slot tests, reference validation, natural scales and thresholds
are reused. The committed V2 capsule sits one directory shallower than its old
target producer; lifecycle constant paths are rebound to the same pinned files,
without changing content hashes or numerical functions.

- Ordinary parity checks all 12 f64/DoubleFloat/Float128 ordinary/Dual cases:
  complete represented values, precision/sign, arrays, contraction, statuses,
  flags, diagnostics, metadata, execution counters, input and repeated calls.
  The retained expectation is 42 successful lanes, 18 explicit matching rejection
  controls and 2,200 successful complex Taylor/Laurent slots. Matching rejected
  lanes never count as numerical success.
- Every rank3 run compares all 140 native complex Laurent slots against untouched
  stable original IBP and the retained earlier rank3 capture. The dimensionally
  normalized mixed tolerance remains `1e-10`; 105 poles must be exact zeros per
  precision. 128/256 comparison checks every one of 140 slots at `2^-80`.
- Rank2 lifecycle reuses all eleven calls, 17 successful complete arrays (1,020
  complex slots), seven explicit rejected controls, two empty calls, input
  preservation, reordered/chunked/repeated samples, one workspace's resets,
  six-child packing and certificate/route counters. It compares 68 contracted
  Laurent slots against saved-moment sums, stable original moments and singleton
  captures. Existing numerical thresholds and precision/sign differences remain
  visible.

The 34 retained exact tests and 27 composition tests overlap constructors,
policies, layout, guard/failure handling and caches. They do **not** substitute for
these whole-array/reference/convergence/lifecycle gates. This packet does not
recompile/repeat those test cohorts. Existing current-Cargo N6 rank3 evidence
does not cover the new combined master-policy plumbing, and the old V2 lifecycle
does not qualify the combined core. This is why both chains repeat numerical
gates.

Both combined SixPoint constructors explicitly pin parent and six N5 children
to Symbolica, including internal Duals. Public SixPoint exposes no backend option.
The ordinary driver also deliberately uses *default* constructors, which stay
Symbolica on default/selective builds. Consequently these gates establish
regression preservation; they do **not** show native ABC execution. Explicit
`NativeF64Abc` call-by-call selection, f64-only dispatch and its generic/Dual
exclusions belong to the separate 38-request whole-call protocol. Primal-only
constructor Dual tests establish neither numerical high-point Dual accuracy nor
derivative-envelope transport.

No result here expands public N6 beyond its existing restricted unit-power,
dimension-shift-zero, native-component PV coordinate-input rank<=3 domain. No
public Dual, complex/generalized/rank7/N7/f64/DD high-point qualification,
production application, Cargo feature forwarding or performance claim follows.

## Operational commands (only after exact ROOT grants)

Run commands from the project root after `source scripts/env.sh` and silent local
license setup. Source-only preparation is `python3 target/native-f64-sixpoint-port/six-regression/prepare.py`.

The runner interface is `run.py build`, or `run.py OPERATION CHAIN`. The saved-only
qualifier is `compare.py {ordinary,128,256,lifecycle} {default,selective}`. Use
fresh immutable `*-001` attempt directories. A grant is
`grant-build-001.json` or `grant-CHAIN-OPERATION-001.json`, with exact preparation,
command-plan, runner and lifecycle hashes; operation/chain, bound/reserve, CPU
list, `/root` approval, and prerequisite list of
`{path,sha256,expected_status,role}`. Numerical grants additionally state
`numerical_lease=true` and bind the exact constructor gate with role `constructors`.
No grants or attempts are created as part of preparing this packet.

The complete v1 source/plan/preparation is preserved under `earlier-source-v1`.
Its only superseded issue was the external grant schema: it accepted an arbitrary
`passed` receipt rather than requiring the actual constructor capsule's distinct
successful status. No compiler or numerical attempt used that earlier packet.
The v2 correction changes no Rust source, compiler command, numerical admission,
runtime bounds or requested outputs.
