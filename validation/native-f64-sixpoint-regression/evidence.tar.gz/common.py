"""Retained N6 provenance/recipes only. Importing launches no producer."""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os

ROOT = Path.cwd().resolve()
assert (ROOT / "crates/iregi-rust/src/six_point.rs").is_file(), "execute from project root"
HERE = ROOT / "target/native-f64-sixpoint-port/six-regression"
PORT = HERE.parent
QUAL = PORT / "qualification"
V2 = ROOT / "validation/highpoint-six-point-api/qualified-v2"
V1 = ROOT / "validation/highpoint-six-point-api/source-v1"
BASE = PORT / "base/crates/iregi-rust"
CORE = QUAL / "public-source/crates/iregi-rust"
BUILD = HERE / "build-001"
PREP = HERE / "preparation.json"
PLAN = HERE / "command-plan.json"
FIXTURE = ROOT / "validation/public-highpoint/fixture-conditioned_masses.json"
REFERENCE = ROOT / "validation/public-highpoint/reference-conditioned_masses.json"
SHARED = ROOT / "validation/public-highpoint/compare_public.py"
ENVIRONMENT = dict(RAYON_NUM_THREADS="1", RUST_TEST_THREADS="1",
                   IREGI_PREPARATION_PROFILE="1", IREGI_PV_PREPARATION_PROFILE="1")
BOUNDS = dict(build=180, **{"ordinary-baseline": 120, "ordinary-candidate": 120,
                          "128": 180, "256": 180, "lifecycle": 180})
RESERVES = dict(build=25, runtime=20)
CHAINS = ("default", "selective")


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, default=str) + "\n")


def key(path):
    path = Path(path).resolve()
    return str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)


def absolute(path):
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def bind(path, inputs, expected=None):
    name = key(path)
    actual = sha(absolute(name))
    require(expected is None or actual == expected, f"changed input: {name}")
    require(name not in inputs or inputs[name] == actual, f"conflicting binding: {name}")
    inputs[name] = actual
    return actual


def final_verify(inputs, budget=None):
    for name, digest in inputs.items():
        if budget is not None:
            budget.remaining()
        require(sha(absolute(name)) == digest, f"changed input: {name}")


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def codegen():
    record = load(QUAL / "codegen-build-001/build.json")
    require(record["status"] == "passed" and record["inputs_unchanged"] is True
            and not record["cleanup_errors"] and not record["deadline_exceeded"],
            "combined codegen gate failed")
    require(set(record["outputs"]) == {"default-core", "selective-core",
            "default-core-tests", "selective-core-tests"}, "combined codegen output inventory differs")
    for output in record["outputs"].values():
        require(sha(output["path"]) == output["sha256"], "combined codegen artifact changed")
    return record


def build_commands():
    prep = load(QUAL / "codegen-preparation.json")
    tools = prep["tools"]
    common = [tools["taskset"]["path"], "-c", "6,7", tools["rustc"]["path"],
              "--edition=2024", "-C", "opt-level=0", "-C", "debuginfo=0",
              "-C", "strip=debuginfo", "-C", "debug-assertions=yes",
              "-C", "overflow-checks=yes", "-C", f'linker={tools["cc"]["path"]}']
    for kind, name in [("dependency", "dependency_directory"),
                       ("dependency", "supplemental_directory"), ("native", "native_directory")]:
        common += ["-L", f"{kind}={ROOT / prep[name]}"]
    old_master = ROOT / prep["dependency_directory"] / "libiregi_masters-f07797f04e91954e.rlib"
    externs = {name: ROOT / path for name, path in prep["externs"].items()}

    def emit(label, source, manifest, aliases, directories=(), library=False):
        output = BUILD / ("libbaseline.rlib" if library else label)
        command = common[:]
        for directory in directories:
            command += ["-L", f"dependency={directory}"]
        command += ["--crate-name", "iregi_rust" if library else label.replace("-", "_"),
                    "-C", "metadata=native_sixpoint_regression_" + label.replace("-", "_")]
        if library:
            command += ["--crate-type", "rlib"]
        command += [str(source), "-o", str(output)]
        for name, path in aliases.items():
            command += ["--extern", f"{name}={path}"]
        return dict(label=label, command=command, output=str(output), timeout_seconds=90,
                    environment=dict(CARGO_CRATE_NAME="iregi_rust", CARGO_MANIFEST_DIR=str(manifest)))

    aliases = {name: externs[name] for name in ("symbolica", "serde", "serde_json", "thiserror")}
    aliases["iregi_masters"] = old_master
    steps = [emit("baseline", BASE / "src/lib.rs", BASE, aliases, library=True)]
    for chain in CHAINS:
        core = QUAL / "codegen-build-001" / chain / "libiregi_rust.rlib"
        master = Path(prep["reused_masters"][chain]["path"])
        dirs = (BUILD, core.parent, master.parent)
        driver_externs = {name: externs[name] for name in ("symbolica", "serde_json")}
        driver_externs["iregi_masters"] = master
        steps.append(emit(chain + "-ordinary", V1 / "ordinary-equivalence-driver.rs", CORE,
                          dict(driver_externs, baseline=BUILD / "libbaseline.rlib", candidate=core), dirs))
        steps.append(emit(chain + "-six_point", CORE / "examples/six_point.rs", CORE,
                          dict(driver_externs, iregi_rust=core), dirs))
        steps.append(emit(chain + "-lifecycle", V1 / "public-lifecycle-driver.rs", CORE,
                          dict(driver_externs, iregi_rust=core), dirs))
    require(len(steps) == 7, "minimal build recipe changed")
    return steps


def operation_dir(chain, operation):
    return HERE / chain / (operation + "-001")


def prerequisites(chain, operation):
    if operation == "ordinary-baseline":
        return []
    if operation == "ordinary-candidate":
        return [(operation_dir(chain, "ordinary-baseline") / "run.json", "passed")]
    gate = {"128": "ordinary", "256": "128", "lifecycle": "256"}[operation]
    return [(HERE / chain / ("comparison-" + gate + ".json"), "passed")]


def validate_grant(operation, chain, inputs):
    label = "build" if operation == "build" else chain + "-" + operation
    path = HERE / ("grant-" + label + "-001.json")
    grant = load(path)
    require(grant.get("approved_by") == "/root" and grant.get("operation") == operation
            and grant.get("chain") == chain, "exact ROOT grant missing")
    for field, target in [("preparation_sha256", PREP), ("plan_sha256", PLAN),
                          ("runner_sha256", HERE / "run.py"), ("lifecycle_sha256", HERE / "lifecycle.py")]:
        require(grant.get(field) == sha(target), f"grant {field} differs")
    require(grant.get("bound_seconds") == BOUNDS[operation]
            and grant.get("reserve_seconds") == RESERVES["build" if operation == "build" else "runtime"],
            "grant bounds differ")
    require(grant.get("cpus") == ([6, 7] if operation == "build" else [22]), "grant CPU differs")
    # ROOT binds any external constructor/whole-call gates explicitly. A recipe
    # does not invent their outcome or authorize a numerical lease.
    require(isinstance(grant.get("prerequisites"), list), "grant prerequisite inventory missing")
    constructors = False
    for item in grant["prerequisites"]:
        require(set(item) == {"path", "sha256", "expected_status", "role"}, "external prerequisite schema differs")
        require(item["expected_status"] in ("passed", "private-constructor-cohort-qualified"),
                "unknown external success status")
        bind(item["path"], inputs, item["sha256"])
        receipt = load(absolute(item["path"]))
        require(receipt.get("status") == item["expected_status"], "external grant prerequisite failed")
        if item["role"] == "constructors":
            required = ROOT / "validation/native-f64-sixpoint-constructors/qualification.json"
            require(absolute(item["path"]).resolve() == required.resolve()
                    and item["expected_status"] == "private-constructor-cohort-qualified",
                    "numerical prerequisite is not the exact qualified constructor capsule")
            require(receipt["private_combined_patch_sha256"] == sha(PORT / "combined.patch"),
                    "constructor gate qualifies a different combined patch")
            observed = receipt["new_execution"]
            require(observed["constructor_cases"] == 7 and observed["all_inputs_unchanged"] is True
                    and observed["owned_groups_absent"] is True and observed["deadline_exceeded"] is False
                    and observed["cleanup_errors"] == [], "constructor completion/guards failed")
            require(set(receipt["independent_audits"]) == {"root_saved", "supplementary_saved"},
                    "constructor independent audit inventory differs")
            for audit in receipt["independent_audits"].values():
                bind(required.parent / audit["path"], inputs, audit["sha256"])
            constructors = True
    if operation != "build":
        require(grant.get("numerical_lease") is True, "ROOT numerical lease missing")
        require(constructors, "numerical stage must bind the exact independently qualified constructor gate")
    bind(path, inputs)
    return grant


def validate_preparation():
    prep = load(PREP)
    require(prep.get("status") == "source-only-frozen-not-built-or-run", "source preparation scope differs")
    require(load(PLAN)["steps"] == build_commands(), "build recipe changed")
    require(prep["command_plan_sha256"] == sha(PLAN), "command plan binding changed")
    require(sha(HERE / "lifecycle.py") == "c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824",
            "owned group helper changed")
    final_verify(prep["input_sha256"])
    return prep


def validate_terminal(record, cap, reserve, expected_steps):
    require(record.get("status") == "passed" and record.get("bound_seconds") == cap
            and record.get("reserve_seconds") == reserve and record.get("inputs_unchanged") is True
            and record.get("cleanup_errors") == [], "failed terminal receipt")
    require(type(record.get("elapsed_seconds")) in (int, float)
            and math.isfinite(record["elapsed_seconds"]) and 0 <= record["elapsed_seconds"] <= cap,
            "invalid aggregate duration")
    require(not any(record.get(k) for k in ("error", "guard_error", "cancellation", "postguard_cancellation")),
            "failed/cancelled terminal")
    require(len(record["steps"]) == expected_steps, "terminal step count differs")
    groups = []
    for step in record["steps"]:
        require(step.get("status") == "exited" and step.get("returncode") == 0
                and step.get("owned_group_gone") is True and not step.get("timeout")
                and not step.get("error") and not step.get("cancellation"), "owned child did not complete")
        timeout = step.get("timeout_seconds")
        elapsed = step.get("elapsed_seconds")
        require(type(timeout) in (int, float) and math.isfinite(timeout) and 0 < timeout <= cap - reserve,
                "child cap consumed postwork reserve")
        require(type(elapsed) in (int, float) and math.isfinite(elapsed) and 0 <= elapsed <= cap
                and type(step.get("group_existed_at_cleanup")) is bool, "child duration/group bookkeeping differs")
        group = step.get("owned_process_group")
        require(type(group) is int and group > 0, "missing owned child identity")
        groups.append(group)
    require(len(groups) == len(set(groups)), "duplicate owned group")


def validate_build():
    prep = validate_preparation()
    inputs = dict(prep["input_sha256"])
    bind(PREP, inputs)
    grant = validate_grant("build", None, inputs)
    record = load(BUILD / "run.json")
    require(record.get("inputs") == inputs, "build guard inventory differs")
    validate_terminal(record, BOUNDS["build"], RESERVES["build"], 7)
    expected = build_commands()
    require([step["command"] for step in record["steps"]] == [step["command"] for step in expected],
            "build commands differ")
    require(set(record["outputs"]) == {step["label"] for step in expected}, "build products incomplete")
    bind(BUILD / "run.json", inputs)
    for step in expected:
        bind(step["output"], inputs, record["outputs"][step["label"]]["sha256"])
        bind(BUILD / (step["label"] + ".log"), inputs, record["log_sha256"][step["label"]])
    return inputs


def runtime_command(chain, operation, binary):
    output = operation_dir(chain, operation) / "result.json"
    taskset = load(QUAL / "codegen-preparation.json")["tools"]["taskset"]["path"]
    start = [taskset, "-c", "22", str(binary)]
    if operation.startswith("ordinary-"):
        return start + [str(output), operation.removeprefix("ordinary-")]
    if operation in ("128", "256"):
        return start + [key(FIXTURE), "6", "3", "pv", operation, "53", "1", str(output)]
    require(operation == "lifecycle", "unknown numerical operation")
    return start + [key(FIXTURE), str(output)]


def runtime_inputs(chain, operation):
    require(chain in CHAINS and operation in BOUNDS and operation != "build", "unknown runtime stage")
    inputs = validate_build()
    validate_grant(operation, chain, inputs)
    for path, status in prerequisites(chain, operation):
        record = load(path)
        require(record.get("status") == status, "dependent gate failed")
        bind(path, inputs)
        for name, digest in record["inputs" if "inputs" in record else "input_sha256"].items():
            bind(absolute(name), inputs, digest)
    return inputs


def validate_run(chain, operation):
    inputs = runtime_inputs(chain, operation)
    directory = operation_dir(chain, operation)
    record = load(directory / "run.json")
    require(record.get("inputs") == inputs and record.get("operation") == operation
            and record.get("chain") == chain and record.get("environment_additions") == ENVIRONMENT,
            "runtime guard/operation/environment inventory differs")
    validate_terminal(record, BOUNDS[operation], RESERVES["runtime"], 1)
    binary = directory / "frozen-executable"
    require(record["steps"][0]["command"] == runtime_command(chain, operation, binary), "runtime command differs")
    bind(directory / "run.json", inputs)
    for name in ("result.json", "step-0.log", "frozen-executable"):
        bind(directory / name, inputs, record["outputs"][name])
    require(set(record["outputs"]) == {"result.json", "step-0.log", "frozen-executable"}, "runtime outputs differ")
    product = chain + ("-ordinary" if operation.startswith("ordinary-") else "-six_point" if operation in ("128", "256") else "-lifecycle")
    require(sha(binary) == load(BUILD / "run.json")["outputs"][product]["sha256"], "frozen runtime differs from built product")
    return dict(record=load(directory / "result.json"), run=record, input_sha256=inputs)
