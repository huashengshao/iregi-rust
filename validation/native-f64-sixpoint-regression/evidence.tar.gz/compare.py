"""Provenance adapter to unchanged V2 ordinary/reference/lifecycle math gates.

This reads saved records only. New run/build provenance is checked by common.py;
the original producer-specific harness is not used to admit new executables.
"""
from decimal import localcontext
from pathlib import Path
import sys
from types import SimpleNamespace
import common as h


def canonical(chain):
    adapter = SimpleNamespace(**{name: getattr(h, name) for name in
        ("ROOT", "SHARED", "FIXTURE", "REFERENCE", "require", "load", "sha", "key", "absolute", "bind", "final_verify")})
    adapter.HERE = h.HERE / chain
    adapter.validate_run = lambda operation: h.validate_run(chain, operation)
    previous = sys.modules.get("harness_common")
    sys.modules["harness_common"] = adapter
    try:
        result = h.module(h.V2 / "compare.py", "six_regression_canonical_comparator")
    finally:
        if previous is None:
            del sys.modules["harness_common"]
        else:
            sys.modules["harness_common"] = previous
    return result, adapter


def lifecycle(chain, inputs, adapter):
    source = h.V2 / "compare-lifecycle.py"
    original = h.module(source, "six_regression_canonical_lifecycle")
    old_root = original.R
    # The committed capsule has one fewer parent directory than its original
    # target producer. Rebind paths only; keep all pinned content hashes and all
    # numerical/schema/reference/counter/contraction functions unchanged.
    pins = {}
    for path, digest in original.PINS.items():
        if path.name in ("public-lifecycle-driver.rs", "public-lifecycle-source.json", "lifecycle-driver-review.json"):
            actual = h.V1 / path.name
        elif path.name in ("hardening.json", "source-review.json"):
            actual = h.V2 / path.name
        else:
            actual = h.ROOT / path.relative_to(old_root)
        pins[actual] = digest
    original.R = h.ROOT
    original.H = h.V2
    original.FIXTURE, original.REFERENCE, original.SHARED = h.FIXTURE, h.REFERENCE, h.SHARED
    original.HISTORY = h.ROOT / "validation/public-highpoint/qualification.json"
    original.REFERENCE_EXE = h.ROOT / "target/reference/iregi-reference-original"
    original.PINS = pins
    run = h.validate_run(chain, "lifecycle")
    for name, digest in run["input_sha256"].items():
        h.bind(h.absolute(name), inputs, digest)
    shared, fixture, references = original.validate_references(adapter, inputs)
    coverage = original.validate_capture(run["record"], fixture, references, shared, original.SETTINGS)
    return dict(passed=True, lifecycle_qualified=True, contraction_qualified=True,
                precision_convergence_qualified=False, performance_qualified=False,
                scope=original.SCOPE, coverage=coverage,
                reused_functions=["validate_references", "validate_capture"],
                adapter_scope="Path/provenance rebinding only; original numerical admission unchanged")


def main(operation, chain):
    h.require(chain in h.CHAINS and operation in ("ordinary", "128", "256", "lifecycle"), "unknown comparison")
    output = h.HERE / chain / ("comparison-" + operation + ".json")
    h.require(not output.exists(), "comparison output is immutable")
    inputs = {}
    h.bind(__file__, inputs)
    h.bind(h.HERE / "common.py", inputs)
    h.bind(h.V2 / "compare.py", inputs)
    h.bind(h.V2 / "compare-lifecycle.py", inputs)
    try:
        pure, adapter = canonical(chain)
        with localcontext() as context:
            context.prec = 220
            result = (pure.ordinary(inputs) if operation == "ordinary" else
                      lifecycle(chain, inputs, adapter) if operation == "lifecycle" else pure.numeric(operation, inputs))
        h.final_verify(inputs)
        result.update(status="passed" if result["passed"] else "failed", chain=chain,
                      input_sha256=inputs, inputs_unchanged=True,
                      production_application=False, current_cargo_qualified=False)
    except Exception as error:
        result = dict(status="failed", passed=False, chain=chain, error=repr(error), input_sha256=inputs)
    h.save(output, result)
    print(dict(status=result["status"], operation=operation, chain=chain, output=h.key(output)))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:]))
