"""Freeze exact source/recipe only; no rustc, reducer, master or oracle execution."""
import datetime
import common as h


def main():
    h.require(not h.PREP.exists() and not h.PLAN.exists(), "source preparation is immutable")
    inputs = {}
    port = h.load(h.PORT / "source-inventory.json")
    for variant in ("base", "proposed"):
        for name, digest in port[variant].items():
            h.bind(h.PORT / variant / name, inputs, digest)
            if variant == "base":
                h.bind(h.ROOT / name, inputs, digest)
    compiled = h.load(h.QUAL / "codegen-preparation.json")
    for name, digest in compiled["input_sha256"].items():
        h.bind(name, inputs, digest)
    for name, digest in compiled["compiled_source_mapping"].items():
        h.bind(h.QUAL / "public-source" / name, inputs, digest)
    h.codegen()
    for output in h.codegen()["outputs"].values():
        h.bind(output["path"], inputs, output["sha256"])
    for path in [h.PORT / "source-inventory.json", h.PORT / "combined.patch",
                 h.QUAL / "codegen-build-001/build.json", h.QUAL / "codegen-preparation.json",
                 h.QUAL / "reviews/codegen-build-001-independent-evidence-review.json",
                 h.ROOT / "validation/highpoint-six-point-api/qualification.json",
                 h.ROOT / "validation/highpoint-six-point-current-cargo/qualification.json",
                 h.V1 / "ordinary-equivalence-driver.rs", h.V1 / "public-lifecycle-driver.rs",
                 h.V1 / "public-lifecycle-source.json", h.V1 / "lifecycle-driver-review.json",
                 h.V2 / "compare.py", h.V2 / "compare-lifecycle.py", h.V2 / "harness_common.py",
                 h.V2 / "ordinary-comparison.json", h.V2 / "comparison-128-256.json",
                 h.V2 / "lifecycle-comparison.json", h.SHARED, h.FIXTURE, h.REFERENCE,
                 h.ROOT / "validation/highpoint-thin-n6-generic/qualification.json"]:
        h.bind(path, inputs)
    history = h.ROOT / "validation/highpoint-thin-n6-generic"
    for bits in (128, 256):
        h.bind(history / f"fixed/n6-rank3-{bits}-001/result.json", inputs)
    for path in sorted(h.HERE.iterdir()):
        if path.is_file() and path.suffix in (".py", ".md"):
            h.bind(path, inputs)
    h.save(h.PLAN, dict(status="source-only-exact-command-plan", steps=h.build_commands()))
    h.bind(h.PLAN, inputs)
    h.final_verify(inputs)
    h.save(h.PREP, dict(
        status="source-only-frozen-not-built-or-run",
        created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope="Retained N6 regression for combined default/selective opt0 cores; frozen old dependency closure, not current Cargo or performance",
        expected_fresh_rustc_products=7,
        dependency_or_master_rebuild=False, production_mutations=False,
        numerical_execution=False, algebra_changes=False,
        dependency_context="Exact reused non-Python closure from combined codegen-preparation; old core/masters product replaced only where explicit",
        base_live_source_exact=True,
        driver_policy="Unchanged qualified ordinary-equivalence and rank2 lifecycle drivers; unchanged public six_point example",
        child_policy="Both combined SixPoint parent/child ordinary/internal Dual construction explicitly Symbolica; six-point public has no backend option",
        ordinary_scope="Default constructors only; explicit NativeF64Abc whole-call parity remains a separate 38-request gate",
        command_plan_sha256=h.sha(h.PLAN), input_sha256=inputs))
    print({"status": "source-only-frozen-not-built-or-run", "inputs": len(inputs),
           "fresh_rustc_products": 7, "preparation_sha256": h.sha(h.PREP)})


if __name__ == "__main__":
    main()
