"""Separately granted bounded build/run operations; never auto-chain or retry."""
import datetime
import os
import sys
import time
import common as h
from lifecycle import Budget, execute, freeze_binary


def main(operation, chain=None):
    h.require(operation in h.BOUNDS and (chain is None if operation == "build" else chain in h.CHAINS),
              "usage: run.py build | run.py {ordinary-baseline,ordinary-candidate,128,256,lifecycle} {default,selective}")
    directory = h.BUILD if operation == "build" else h.operation_dir(chain, operation)
    directory.parent.mkdir(exist_ok=True)
    directory.mkdir(exist_ok=False)
    cap = h.BOUNDS[operation]
    reserve = h.RESERVES["build" if operation == "build" else "runtime"]
    budget = Budget(cap)
    budget.work_deadline = budget.deadline - reserve
    record = dict(status="preflight", operation=operation, chain=chain, bound_seconds=cap,
                  reserve_seconds=reserve, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  environment_additions={} if operation == "build" else h.ENVIRONMENT,
                  steps=[], cleanup_errors=[], outputs={})
    receipt = directory / "run.json"
    h.save(receipt, record)
    worked = False
    budget.arm()
    try:
        if operation == "build":
            prep = h.validate_preparation()
            inputs = dict(prep["input_sha256"])
            h.bind(h.PREP, inputs)
            h.validate_grant(operation, chain, inputs)
            steps = h.build_commands()
        else:
            inputs = h.runtime_inputs(chain, operation)
            product = chain + ("-ordinary" if operation.startswith("ordinary-") else
                               "-six_point" if operation in ("128", "256") else "-lifecycle")
            built = h.load(h.BUILD / "run.json")["outputs"][product]
            binary = freeze_binary(built["path"], built["sha256"], directory / "frozen-executable", budget)
            steps = [dict(label="step-0", command=h.runtime_command(chain, operation, binary),
                          timeout_seconds=cap - reserve, environment=h.ENVIRONMENT)]
        record.update(status="running", inputs=inputs)
        h.save(receipt, record)
        for spec in steps:
            budget.remaining()
            step = dict(label=spec["label"])
            record["steps"].append(step)
            environment = os.environ.copy()
            environment.update(spec["environment"])

            def persist(result):
                step.update(result)
                h.save(receipt, record)

            result = execute(spec["command"], directory / (spec["label"] + ".log"), budget,
                             spec["timeout_seconds"], record["cleanup_errors"], persist, environment)
            h.require(result["status"] == "exited" and result.get("owned_group_gone") is True,
                      "owned stage failed; later work remains unrun")
            if operation == "build":
                output = spec["output"]
                record["outputs"][spec["label"]] = dict(path=output, sha256=h.sha(output))
                h.save(receipt, record)
        worked = True
        record["status"] = "completed-awaiting-guards"
    except Exception as error:
        record.update(status="failed", error=repr(error))
    finally:
        budget.disarm()
        record["elapsed_seconds"] = budget.elapsed()
        if budget.cancelled:
            record["cancellation"] = budget.cancelled
        # Every child terminal has been persisted by the unchanged helper before
        # any final source/output/log read can fail.
        h.save(receipt, record)
    post = Budget(max(0, budget.deadline - time.monotonic()))
    try:
        post.arm()
        post.remaining()
        h.require("inputs" in record, "preflight did not establish bindings")
        h.final_verify(record["inputs"], post)
        record["inputs_unchanged"] = True
        if operation == "build":
            h.require(set(record["outputs"]) == {step["label"] for step in h.build_commands()}, "build products incomplete")
            for output in record["outputs"].values():
                post.remaining()
                h.require(h.sha(output["path"]) == output["sha256"], "compiled product changed")
            record["log_sha256"] = {}
            for step in record["steps"]:
                post.remaining()
                record["log_sha256"][step["label"]] = h.sha(directory / (step["label"] + ".log"))
        else:
            record["outputs"] = {}
            for name in ("result.json", "step-0.log", "frozen-executable"):
                post.remaining()
                record["outputs"][name] = h.sha(directory / name)
    except Exception as error:
        record.update(inputs_unchanged=False, guard_error=repr(error))
    finally:
        post.disarm()
    record.update(elapsed_seconds=budget.elapsed(), finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if post.cancelled:
        record["postguard_cancellation"] = post.cancelled
    record["status"] = "passed" if (worked and record.get("inputs_unchanged") is True
        and not record["cleanup_errors"] and not budget.cancelled and not post.cancelled
        and record["elapsed_seconds"] <= cap and not record.get("guard_error")
        and all(step.get("status") == "exited" and step.get("owned_group_gone") is True
                for step in record["steps"])) else "failed"
    h.save(receipt, record)
    print(dict(status=record["status"], operation=operation, chain=chain, elapsed_seconds=record["elapsed_seconds"]))
    return 0 if record["status"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:]))
