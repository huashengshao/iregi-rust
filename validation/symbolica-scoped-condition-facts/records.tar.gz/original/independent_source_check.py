"""Practical static current-Cargo controller/source review; no jobs launched."""
from pathlib import Path
import ast
import hashlib
import json
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path.cwd().resolve()
HERE = Path(__file__).resolve().parent
CHECKS = 0


def ck(value, label):
    global CHECKS
    CHECKS += 1
    if not value:
        raise AssertionError(label)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    protocol_sha = "d5c429db3e769a910ebd449aac71bac091edcf2fe137571784f8c7f1b0d9a059"
    runner_sha = "b86d88fa8be84f3c14e5948438c2436561315890acd577f22fb9674f24e9eaeb"
    output = HERE / "independent-source-runner-review.json"
    ck(not output.exists(), "fresh exact source review")
    ck(sha(HERE / "protocol.json") == protocol_sha and sha(HERE / "run.py") == runner_sha,
       "exact final protocol/runner")
    p = json.loads((HERE / "protocol.json").read_text())
    freeze = json.loads((HERE / "source-freeze.json").read_text())
    ck(sha(HERE / "source-freeze.json") == p["source_freeze_sha256"], "source-freeze identity")
    ck(freeze["file_count"] == len(freeze["source_files"]) == 202, "202 declared source files")
    snapshot = Path(freeze["snapshot"])
    ck({str(path.relative_to(snapshot)) for path in snapshot.rglob("*") if path.is_file()}
       == set(freeze["source_files"]), "closed202-file snapshot")
    total = 0
    for name, digest in freeze["source_files"].items():
        ck(sha(snapshot / name) == digest and sha(ROOT / name) == digest,
           "exact snapshot/current build input " + name)
        total += (snapshot / name).stat().st_size
    ck(total == freeze["source_bytes"] == 9666335, "9.67MB compact source context")
    for name, digest in p["bindings"].items():
        ck(sha(name) == digest, "admitted controller/patch/review binding " + name)
    tree = "dependencies/symbolica/src/evaluate/tree.rs"
    ck(freeze["source_files"][tree] == "a1b43f612a990295bb94ef48637e5f100e4527b30d81f202337a0f75286ac990",
       "applied source equals independently reviewed one-file candidate")
    ck(sha(ROOT / "target/ibp-workspace-preparation-research/known-condition-proposal/symbolica-scoped-condition.patch")
       == "e0474f4ba39481075f7cc36fa0f06bf34edfc64bacec844f42f670399bfed456",
       "exact reviewed one-file patch")
    ck(p["build"] == {"total_seconds":1200,"reserve_seconds":60,"child_cap_seconds":1080,"cpu":"14,16"}
       and p["tests"] == {"total_seconds":300,"reserve_seconds":30,"child_cap_seconds":30,"cpu":"14"},
       "root-authorized finite build/test resources")
    ck(p["build_command"] == [p["taskset"],"-c","14,16",
                              "/nix/store/1jwkiz96iwqdhm4bh2hvgd86ysb0b67q-cargo-1.99.0/bin/cargo",
                              "test","--locked","--offline","-p","symbolica","--lib","--no-run",
                              "--message-format=json","-j","2"], "exact actual Cargo command")
    ck(p["lifecycle_sha256"] == "8b069af14b2beeb9c3409cbe3eb5effdb4af3e63ff46e4b150aadb3a81fef985",
       "longer-wait reviewed owned-group lifecycle")
    selected = p["selected_tests"]
    ck(len(selected) == len(set(selected)) == 18
       and sum("::path_condition_tests::" in name for name in selected) == 7,
       "exact18 selected names: seven new plus11 relevant legacy")
    for name in selected:
        if "evaluate::tree::" in name:
            relative = tree
        elif "evaluate::dual::" in name:
            relative = "dependencies/symbolica/src/evaluate/dual.rs"
        elif "evaluate::batch::" in name:
            relative = "dependencies/symbolica/src/evaluate/batch.rs"
        else:
            relative = "dependencies/symbolica/src/evaluate.rs"
        text = (snapshot / relative).read_text()
        ck(len(re.findall(r"\bfn\s+" + re.escape(name.split("::")[-1]) + r"\s*\(",text)) == 1,
           "declared exact test exists in frozen source " + name)
    source = (HERE / "run.py").read_text()
    ast.parse(source, filename="run.py")
    for fragment in ["build.get('protocol_sha256')==sha(protocol_path)",
                     "build.get('source_freeze_sha256')==sha(HERE/'source-freeze.json')",
                     "lines.count('running 1 test')==1 and len(headers)==1",
                     "1 passed; 0 failed; 0 ignored; 0 measured;",
                     "len(summaries)==1 and re.fullmatch(",
                     "re.search(r'(?:^|\\s)ok$',block)",
                     "if operation=='build':guards[str(ROOT/name)]=digest",
                     "directory.mkdir(parents=True,exist_ok=False)",
                     "result['status']=='exited' and result.get('returncode')==0",
                     "result.get('owned_group_gone') is True",
                     "h.freeze_binary(emitted,digest,directory/'symbolica-library-tests-frozen'",
                     "'--exact','--test-threads=1','--nocapture'",
                     "verify(budget.deadline-1)"]:
        ck(fragment in source, "required reviewed controller behavior " + fragment)
    ck(not (HERE / "execution").exists(), "no build/test jobs started before review")
    ck(p["native_integral_jobs"] == 0 and p["numerical_accuracy_qualification"] is False
       and p["automatic_retry"] is False, "no numerical job or automatic retry admitted")
    result = {"status":"passed", "reviewer":"/root/highpoint_generalized_research/routing_source_review",
              "protocol_sha256":protocol_sha,"runner_sha256":runner_sha,
              "source_freeze_sha256":p["source_freeze_sha256"],"source_review_script_sha256":sha(__file__),
              "checks_passed":CHECKS,"source_files_verified_current_and_snapshot":202,
              "source_bytes":total,"controller_bindings_verified":len(p["bindings"]),
              "selected_exact_tests":18,"new_path_condition_tests":7,"selected_legacy_tests":11,
              "source_findings":[
                  "Actual locked/offline Cargo Symbolica library-test build, CPU14/16 j2, total1200/reserve60/child1080; no historical dependency walk or reference build.",
                  "Compact202-file source context matches live current library/local numeric sources and snapshot. Applied tree source is exact independently reviewed a1b43f61 candidate/e0474f4b patch.",
                  "Actual Cargo JSON must emit one Symbolica test executable; its bytes are hashed and frozen as a new owned copy. The later test stage requires matching saved successful build protocol and source-freeze identities.",
                  "Exact listing admits all18 declared test names once. Each separate exit0 log requires one running test/header, exact one-passed zero-failed/ignored/measured summary and explicit ok completion; profiling stderr may interrupt the NAME prefix.",
                  "Owned whole-group cleanup/reaping uses reviewed longer-wait8b069 helper. Terminal events precede log parsing/hashing; final guards, cancellation and total budgets remain failure gates.",
                  "Build guards live202 inputs and snapshot; tests guard the immutable snapshot and frozen artifact, allowing the live source lease to be released after a successful build.",
                  "Two initial practical harness findings were fixed before execution: exact matching build protocol/freeze and strict named one-test status. Unexecuted v1 protocol/runner are preserved and bound."
              ],"blocking_findings":[],
              "execution_condition":"Root already authorizes this reviewed fresh build and the matching selected-test stage; no additional root/user permission is required. This reviewer launches neither stage.",
              "scope_limits":["This is a practical current Cargo source/artifact qualification, not a hermetic full external dependency closure.",
                              "The known-condition semantic proposal has a separate exact source review; compilation and all runtime tests remain unobserved at this source-check point.",
                              "No N2/N7 integral job, numerical agreement, arbitrary-type integral accuracy, full port or performance claim is authorized by this gate."],
              "compiler_test_binary_or_numerical_runtime_executed_by_reviewer":False,
              "core_frontend_generated_or_rust_source_edited_by_reviewer":False,
              "numerical_or_performance_qualification":False}
    output.write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")
    print(json.dumps({"status":"passed","path":str(output.relative_to(ROOT)),
                      "sha256":sha(output),"checks":CHECKS,"new_native_execution":False}))


if __name__ == "__main__":
    main()
