"""Root-authorized finite actual-Cargo Symbolica build and selected tests.

No numerical integral jobs. One fresh build directory, one frozen emitted test
artifact, no automatic retries. Source snapshot is the durable build context.
"""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,re,sys,time
sys.dont_write_bytecode=True
ROOT=Path.cwd().resolve();HERE=Path(__file__).resolve().parent

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save(path,record):
    temporary=path.with_suffix('.partial');temporary.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');temporary.replace(path)
def require(ok,reason):
    if not ok:raise ValueError(reason)

def main(operation,review_path,review_sha):
    protocol_path=HERE/'protocol.json';protocol=read(protocol_path)
    require(operation in ('build','tests'),'run.py build|tests review_path review_sha256')
    review_path=Path(review_path).resolve();require(sha(review_path)==review_sha,'exact source review')
    review=read(review_path);require(review['status']=='passed' and review['protocol_sha256']==sha(protocol_path),'independent source review must pass')
    helper=Path(protocol['lifecycle']);require(sha(helper)==protocol['lifecycle_sha256'],'reviewed lifecycle')
    spec=importlib.util.spec_from_file_location('owned_symbolica_gate',helper);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
    limits=protocol[operation];budget=h.Budget(limits['total_seconds']);budget.work_deadline=budget.deadline-limits['reserve_seconds']
    directory=HERE/'execution'/(operation+'-001');directory.mkdir(parents=True,exist_ok=False)
    receipt=directory/'receipt.json';record={'status':'preflight','operation':operation,'protocol_sha256':sha(protocol_path),'source_review_sha256':review_sha,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limits':limits,'steps':[],'cleanup_errors':[],'performance_evidence':False,'numerical_integral_qualification':False}
    guards=dict(protocol['bindings']);guards[str(protocol_path)]=sha(protocol_path);guards[str(review_path)]=review_sha
    freeze=read(HERE/'source-freeze.json');snapshot=Path(freeze['snapshot'])
    for name,digest in freeze['source_files'].items():
        guards[str(snapshot/name)]=digest
        if operation=='build':guards[str(ROOT/name)]=digest
    def verify(deadline):
        for name,digest in guards.items():require(time.monotonic()<deadline and sha(name)==digest,'changed guarded input '+name)
        require({str(p.relative_to(snapshot)) for p in snapshot.rglob('*') if p.is_file()}==set(freeze['source_files']),'source snapshot membership')
    def run(command,log,cap):
        step={};record['steps'].append(step)
        def persist(value):step.update(value);save(receipt,record)
        result=h.execute(command,log,budget,cap,record['cleanup_errors'],persist,env)
        require(result['status']=='exited' and result.get('returncode')==0 and result.get('owned_group_gone') is True,'owned step failed')
        require(not record['cleanup_errors'] and not budget.cancelled,'owned lifecycle failed')
        step['log_sha256']=sha(log);save(receipt,record)
    complete=False;save(receipt,record);budget.arm()
    try:
        verify(budget.work_deadline)
        env=os.environ.copy();env.update(RUST_TEST_THREADS='1',RAYON_NUM_THREADS='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',SYMBOLICA_SCOPE_PROFILE='1')
        require(env.get('SYMBOLICA_LICENSE'),'source private license before gate')
        record['environment_additions']={key:env[key] for key in ('RUST_TEST_THREADS','RAYON_NUM_THREADS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','SYMBOLICA_SCOPE_PROFILE')}
        record['cargo_environment']={key:env[key] for key in ('CARGO_TARGET_DIR','CARGO_BUILD_BUILD_DIR','CARGO_HOME','RUSTFLAGS','RUSTC','RUSTC_WRAPPER') if key in env}
        record['license_present']=True;record['status']='running';save(receipt,record)
        if operation=='build':
            run(protocol['build_command'],directory/'cargo.log',limits['child_cap_seconds'])
            events=[]
            for line in (directory/'cargo.log').read_text().splitlines():
                try:events.append(json.loads(line))
                except json.JSONDecodeError:pass
            artifacts=[event for event in events if event.get('reason')=='compiler-artifact' and event.get('target',{}).get('name')=='symbolica' and event.get('profile',{}).get('test') is True and event.get('executable')]
            require(len(artifacts)==1,'one actual emitted Symbolica library test artifact')
            artifact=artifacts[0];save(directory/'cargo-artifact.json',artifact)
            emitted=Path(artifact['executable']);digest=sha(emitted)
            owned=h.freeze_binary(emitted,digest,directory/'symbolica-library-tests-frozen',budget)
            guards[str(owned)]=digest
            record.update(artifact_sha256=sha(directory/'cargo-artifact.json'),artifact=artifact,frozen_binary={'path':str(owned),'sha256':digest,'bytes':owned.stat().st_size},source_freeze_sha256=sha(HERE/'source-freeze.json'))
        else:
            build_path=HERE/'execution/build-001/receipt.json';build=read(build_path)
            require(build['status']=='passed' and build.get('inputs_unchanged') is True,'saved actual build must pass')
            require(build.get('protocol_sha256')==sha(protocol_path) and build.get('source_freeze_sha256')==sha(HERE/'source-freeze.json'),'saved build must match this exact protocol and source freeze')
            guards[str(build_path)]=sha(build_path)
            binary=Path(build['frozen_binary']['path']);guards[str(binary)]=build['frozen_binary']['sha256']
            verify(budget.work_deadline)
            owned=h.freeze_binary(binary,build['frozen_binary']['sha256'],directory/'symbolica-library-tests-owned',budget);guards[str(owned)]=build['frozen_binary']['sha256']
            record['build_receipt_sha256']=sha(build_path);record['frozen_binary_sha256']=build['frozen_binary']['sha256']
            run([protocol['taskset'],'-c',limits['cpu'],str(owned),'--list'],directory/'listing.log',20)
            listed=[line[:-6] for line in (directory/'listing.log').read_text().splitlines() if line.endswith(': test')]
            require(len(listed)==len(set(listed)),'unique test listing')
            require(all(listed.count(name)==1 for name in protocol['selected_tests']),'all declared exact tests listed once')
            record['listing_count']=len(listed);record['selected_count']=len(protocol['selected_tests'])
            for index,name in enumerate(protocol['selected_tests']):
                log=directory/('test-'+str(index+1).zfill(2)+'.log')
                run([protocol['taskset'],'-c',limits['cpu'],str(owned),name,'--exact','--test-threads=1','--nocapture'],log,limits['child_cap_seconds'])
                text=log.read_text();lines=text.splitlines()
                summaries=[line for line in lines if line.startswith('test result:')]
                headers=[line for line in lines if line.startswith('test ') and not line.startswith('test result:')]
                require(lines.count('running 1 test')==1 and len(headers)==1 and headers[0].startswith('test '+name+' ... '),'one exact named test '+name)
                require(len(summaries)==1 and re.fullmatch(r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out; finished in [^\n]+',summaries[0]),'strict one-test successful summary '+name)
                # Profiling emits stderr between libtest's NAME... prefix and
                # its terminal ok; require that exact completion before summary.
                block=text[text.index(headers[0]):text.index(summaries[0])].rstrip()
                require(re.search(r'(?:^|\s)ok$',block) is not None,'exact named test completed ok '+name)
            record['completed_selected_tests']=len(protocol['selected_tests'])
        complete=True;record['status']='passed'
    except BaseException as error:record.update(status='failed_or_incomplete',error=repr(error))
    finally:
        budget.disarm()
        try:verify(budget.deadline-1);record['inputs_unchanged']=True
        except BaseException as error:record.update(inputs_unchanged=False,post_guard_error=repr(error))
        record['inputs']=guards;record['elapsed_seconds']=budget.elapsed();record['cancellation']=budget.cancelled
        record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        if not complete or not record.get('inputs_unchanged') or record['cleanup_errors'] or budget.cancelled or budget.elapsed()>limits['total_seconds']:record['status']='failed_or_incomplete'
        save(receipt,record)
    print(json.dumps({'status':record['status'],'receipt':str(receipt),'receipt_sha256':sha(receipt),'elapsed_seconds':record['elapsed_seconds']}))
    return 0 if record['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main(*sys.argv[1:]))
