# Scoped reuse of an already tested SSA condition

Source-only review, 25 October 2026, by
`/root/highpoint_generalized_research/cayley_source_reuse`.

Recommendation: qualify the narrow target-only Symbolica direct-lowering
prototype. I found no source-level semantic blocker in the final patch below.
It adds compiler path facts, not an algebraic rewrite, numerical substitution,
new scalar formula, or specialization to the observed bubble point. Compilation,
runtime correctness and memory/time benefit are still unverified by this review.
No production source, Cargo input, compiler product or numerical result was
modified or produced by this reviewer.

## Reviewed subjects

All paths below are relative to `/shared/external/iregi/iregi-rust`.
The proposal directory is
`target/ibp-workspace-preparation-research/known-condition-proposal/`.

| Subject | SHA256 |
|---|---|
| `tree.baseline.rs` | `29d3263c414fd2d5b82eceeb7fe9f31cf0513f771307d2e5f90d7f9c4703e6fa` |
| `tree.candidate.rs` | `a1b43f612a990295bb94ef48637e5f100e4527b30d81f202337a0f75286ac990` |
| `symbolica-scoped-condition.patch` | `e0474f4ba39481075f7cc36fa0f06bf34edfc64bacec844f42f670399bfed456` |
| `tests.rs` | `c2a4dc0e11aa225fe082daeda77e1621a2e512a27a8df37a180419a3a0ed5d94` |

The current `dependencies/symbolica/src/evaluate/tree.rs` still matched the
baseline hash at the final source read. Earlier candidate hashes are superseded,
not runtime failures. The exact-domain test was corrected before any execution:
`Complex<Rational>` implements `EvaluationDomain`, but does not satisfy the
`Real` bound of `evaluate_single`. The final tests use existing
`map_to_ring(AtomField)` and `evaluate_single_in_ring` instead.

## Why this is a plausible bottleneck intervention

`crates/iregi-rust/src/ibp.rs:960-1001` caches the regular bubble determinant
handle and wraps each Laurent result in `IF(det, regular, ordinary)`.
Recursively compiled scalar requests can therefore contain many tests of the
same alias. The scalar alias DAG itself is already shared; this proposal does
not replace it.

In baseline `dependencies/symbolica/src/evaluate/tree.rs:1220-1387`, the direct
lowerer resolves a condition only when its instruction expression is numeric.
For an unknown condition it lowers both arms under separate expression-cache
checkpoints, then joins the results. The checkpoints correctly prevent a
branch-local value from escaping, but they do not record the condition already
tested by the dominating branch. Repeated guarded aliases can consequently be
expanded again along contradictory nested paths before `optimize_stack` starts.
`evaluate/optimize.rs:504-576` only reuses storage after instructions exist; it
cannot prevent this construction growth.

The parent reported a profiled N2/rank7 preparation reaching roughly 5.05 GiB
around 30 seconds, with the stall in exact evaluator construction/lowering or
stack optimization. I did not reproduce or independently profile that event.
The source explains a candidate cause, not a demonstrated causal attribution
or a performance qualification. Multiple independent conditions can still
produce many path contexts after this patch.

## Three checks for existing facilities

1. **Symbolica implementation/API check.** Inspected `ScopedSubexpressions`
   (`tree.rs:7-79`), direct IF lowering (`1220-1387`), ordinary inline function
   scopes (`1026-1082`), retained function construction (`881-1013`), the legacy
   tree IF lowerer (`2557-2698`), and the builder dispatch
   (`evaluate/function_map.rs:457-481`). Existing direct lowering has numeric
   constant resolution and parent-scoped completed-expression reuse, but no
   path-truth map keyed by SSA `Slot`. Existing `Slot` is already Copy/Eq/Hash
   (`evaluate/instruction.rs:3-16`). `AtomView` property inference, for example
   `atom/properties.rs:43-56`, examines IF payload properties; it is not a
   compiler path-fact facility. No new symbolic solver is needed.
2. **Existing Symbolica usage/tests check.** Inspected
   `completed_conditionals_reuse_only_their_parent_scope`
   (`evaluate.rs:590`), retained/captured-function and shadowing tests
   (`675`, `833`, `989`, `1047`), the scoped journal tests
   (`tree.rs:4683-4777`), batch lazy shared-function test
   (`evaluate/batch.rs:536`), and higher/mixed derivative branch tests
   (`evaluate/dual.rs:1534`, `1575`, `1818`). They establish relevant existing
   contracts but do not implement repeated *dominating-condition* reuse.
   Exact ring evaluator usage already exists in
   `dependencies/symbolica/tests/evaluation.rs:158-185`; the proposal reuses it.
3. **FeynKit/gammaloop ecosystem check.** Searched evaluator, alias, condition
   and path-fact implementations in
   `../references/gammaloop_feynkit/crates/{gammalooprs,spenso,spynso3,idenso}`.
   The substantive nearby facility is
   `gammalooprs/src/utils/symbols.rs:286-405`,
   `GammaloopSymbols::collect_orientation_if`. It preserves lazy zero-arm
   selector weights and merges same-key selector sums through Symbolica
   replacement APIs; its tests at `1623-1789` preserve factorization and
   symbolic payloads. It is not an SSA path-fact cache for general two-arm
   conditionals, and its orientation normalizations are not an appropriate
   drop-in transformation for IREGI's general `IF(det, regular, ordinary)`.
   Relevant scalar-pole and guarded-numerator tests also retain lazy IF guards.

This is a focused search of the relevant sources and APIs, not a claim that
every unrelated repository file was inspected. The implementation remains
inside Symbolica's compiler and leaves all algebra in Symbolica.

## Review of the final compiler change

The patch adds `HashMap<Slot, bool>` and a reversible condition journal to the
existing scoped cache. Checkpoints contain both journal lengths. A branch
records `cond != 0` in its true arm and `cond == 0` in its false arm, and restores
the checkpoint before lowering a sibling or propagating an error. The existing
`restore`-before-`?` ordering is preserved.

The IF lowerer still lowers its condition first. If that exact immutable SSA
slot has a fact on the active path, it lowers only the corresponding arm and
caches the completed IF expression in the existing scope. It does not remove
or truncate condition instructions on this path. The original numeric-constant
resolution/truncation path is unchanged. Active ancestor condition slots were
created before a nested condition's instruction checkpoint, so that existing
constant cleanup cannot invalidate an active fact.

Aliases intentionally inherit the caller cache and therefore its facts.
Ordinary inline functions keep a fresh `ScopedSubexpressions`; retained bodies
also start in `linearize_multiple_impl` with a fresh cache. This prevents formal
shadowing and local `Param(0)`/`Temp(n)` collisions from importing a caller fact
into another function's SSA space. No function-scope implementation changed.
All facts are restored before returning to the multiple-output root scope.

Important constraints maintained by the patch:

- **Facts are control-flow metadata only.** Never insert `cond -> 1` or
  `cond -> 0` into the expression/value cache. A nonzero condition can be `2`,
  `i`, or a value carrying derivatives; payload arithmetic must retain it.
- **Use identity, not algebraic equivalence.** Equal `Slot` in this SSA scope
  suffices. Do not infer truth for `c*c`, `1/c`, proportional expressions,
  matching symbol names or equal primal sample values.
- **Keep runtime branch semantics.** Scalar/batch evaluators test
  `is_fully_zero` (`evaluate/evaluator.rs:418-433`, `batch.rs:224-233`).
  Vectorized Dualizer guards use their existing leading component
  (`dual.rs:560-563`, `1307-1309`). The compiler adds no new zero test and does
  not alter these domain-specific contracts or nondifferentiability semantics.
- **Key facts before stack allocation only.** SSA `Temp` identities here are
  instruction positions. Allocated/reused stack indices later would not be
  valid persistent fact identities.
- **Preserve dominance and laziness.** A joined IF result may enter the parent
  expression cache; selected-arm scratch and facts may not. Conditions from
  one lane or prior numerical call must never enter this structural cache.

The only other change is an optional `SYMBOLICA_SCOPE_PROFILE` diagnostic
counter. Any downstream exact log parser should bind the changed line format;
this counter is not a kernel benchmark.

## Meaningful tests in the final source

There are seven new tests. They exercise behavior through the evaluator, apart
from one direct journal test:

| Test | Why it matters |
|---|---|
| `path_condition_journal_restores_nested_facts` | Restores overwritten true/false facts and removes nested temporary facts; checks root depth/journal cleanup. |
| `repeated_condition_alias_diamond_has_linear_instruction_growth` | Twelve-level alias DAG, one shared determinant condition, exact AtomField numeric oracle and a one-branch/instruction bound. Baseline lacks the structural pruning. |
| `same_condition_prunes_only_unreachable_poles_and_not_other_roots` | Contradictory nested inverse arms disappear, a second root keeps its own branch, mixed lanes at `z=0`, repeated/empty/singleton/odd batch calls. |
| `different_conditions_and_sibling_facts_remain_independent` | Four truth combinations of independent predicates, sibling/continuation separation and retained branch count. |
| `inline_and_retained_functions_do_not_inherit_caller_truth_by_name` | Formal `c` shadows root `c`; both policies produce independent values. Exported sub-evaluator count explicitly verifies Never=1 and Always=0. |
| `repeated_conditions_preserve_higher_mixed_duals_and_batch_laziness` | Independent x/y directions, second and mixed Taylor coefficients, nonzero condition derivatives, scalar and changing-size batch evaluation with an unreachable pole. |
| `pure_imaginary_truth_keeps_the_original_numeric_condition_value` | Exact `c=+i,0,-i`, payload `c*x`, `z=0`; rejects real-part-only truth tests and replacing a known-nonzero value by one. |

Two review findings were fixed before the final source freeze: exact-domain
evaluation now uses the supported ring API, and the pure-imaginary numeric
payload/policy-structure tests close real coverage gaps. The alias-diamond's
original `c=i` alone gives a real `c^2+q`; the additional seventh test is what
actually covers an imaginary-only nonzero predicate. The peer source reviewer
`rank7_driver_source_check` independently identified the complex-predicate and
policy-exercise gaps. This reviewer authored none of these candidate tests.
No tests were executed for this note, and API compatibility remains subject to
compilation.

## Qualification sequence and limits

First qualify the frozen Symbolica proposal with the seven new tests and the
existing scoped-cache, completed-conditional, function-shadow/capture, lazy
batch and mixed-Dual regressions. Keep exact exported instruction evidence in
addition to numerical values: numeric agreement alone would not establish that
the repeated paths were removed. A small ordinary bubble actual caller should
then show nonzero path-fact reuse while preserving all four native Laurent
slots, exact input metadata, fallback/certificate semantics, and repeated batch
behavior at the unchanged reference/precision gates.

Only after those gates pass should a separately bounded actual N2/rank7
construction/capture test assess the reported bottleneck, followed by the
other retained families. Retain stage markers, branch/instruction counts,
maximum memory and terminal receipts; preparation durations alone are not
reduction performance measurements. Successful low-level exact/f64/Dualizer
tests would not qualify arbitrary precision, every generic `Dual<T>`, all IREGI
methods or actual rank-seven tensors by themselves. This source review grants
no production adoption or performance claim.
