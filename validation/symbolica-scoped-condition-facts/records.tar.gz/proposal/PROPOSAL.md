# Rank-seven IBP workspace preparation: scoped condition facts

Source-only proposal, 25 October 2026. No compiler, test binary or integral was
run for this proposal. All edits are in this ignored target directory. The
production Symbolica, core and master sources are unchanged by this work.

## What the admitted diagnostic established

The one root-authorized existing-artifact N2/rank7/IBP/Float128/requested53/
rows1 diagnostic timed out after the 110-second child cap. Total supervised
phase time was 123.935721 seconds, below 150. It produced no tensor array and
does not complete or replace the two historical 255-second N2 attempts.

The retained profile completed structural plan construction at 1.136 seconds,
stability expressions in 3.495591 seconds, quadrature-stability evaluators in
0.001041 seconds, argument evaluator in 0.019480 seconds, and snapping evaluator
in 0.000517 seconds. It stalled before completion of the **reduction exact
evaluator**, which calls Symbolica evaluator construction followed by stack
optimization. Those two operations were not separately timed. One read-only
owned-process observation found RSS/HWM 5,295,656 KiB; this is an observed lower
bound, not a whole-lifetime peak measurement.

The new attempt's PG235649 was gone at cleanup; cleanup_errors is empty. Its
receipt preserves the work-alarm signal received during the bounded longer
cleanup. The older two N2 receipts retain their own timeout **and failed
cleanup**; only separate later observations show their groups absent. There
is no historical cleanup upgrade or claim that those runs were overlap-free.

Evidence is in `../profile-n2-rank7-128/diagnostic-summary.json` (72e34b61...),
its original receipt (013d174d...), log (cd13e6bd...), and independent source
review (2d680b41...). This is a correctness-completion/usability blocker,
not a comparison of low-rank backend performance.

## Source explanation and proposed change

`crates/iregi-rust/src/ibp.rs::compile_gram_regular_bubble` caches one determinant
alias per active pair, then wraps many shifted/dotted requests in the same
`IF(detS, regular, ordinary)`. Scalar request DAG aliases and direct evaluator
translation are already enabled. For a rank-r term with j metric pairs,
h=r-j and sum(nu)=2+r-2j; every j>=0 satisfies this regular-bubble path's
h>=sum(nu)-2 eligibility. Nested same-condition tests are therefore plausible
through most of a rank-seven bubble's scalar recurrence. N3's successful pure
IBP rank-seven workspace, despite more aliases than N2, is useful differential
evidence; it is not a proof of this cause.

`dependencies/symbolica/src/evaluate/tree.rs::linearize_impl` currently resolves
only fully numeric IF conditions. Each unresolved IF lowers both arms, using
scoped expression-cache checkpoints so an inactive singular expression is not
hoisted into another path. When a descendant tests the **same immutable SSA
Slot**, its truth is already fixed by the dominating arm. Current lowering
does not retain that fact and can repeatedly traverse both descendants.

The private patch adds `Slot -> bool` facts to the **existing Symbolica direct
lowerer** and journals them alongside its scoped expression cache:

1. Lower the condition using the existing translator and parameter map.
2. If this exact SSA slot has an inherited fact, lower only its selected arm.
3. Otherwise keep existing numeric resolution and lazy IF instructions.
4. After each branch checkpoint, record the condition as nonzero/zero for that
   arm; restore it before entering the sibling and before leaving the IF.

No condition is replaced by 0 or 1, no floating-point branch is guessed, no
symbolic equality/zero test is added, and no integral recurrence changes.
Complex truth remains zero-versus-nonzero. Alias bodies inherit caller facts;
ordinary inline and retained functions already create a fresh expression scope,
so the new facts reset conservatively there too. Facts refer to pre-allocation
SSA slots and are discarded before instruction compaction/stack optimization.

The proposed generic change may also benefit higher-point nested pinches. No
N7 preparation improvement is established by this N2 diagnostic or source-only
patch. N7's current memory growth must remain independently visible.

## Three reuse checks

1. **Symbolica API/source.** Inspected the existing scoped cache/checkpoint
   implementation, direct IF lowering and numeric resolver in
   `evaluate/tree.rs`, immutable `Slot` definitions in `evaluate/instruction.rs`,
   function registration/inlining in `evaluate/function_map.rs`, direct batch
   execution in `evaluate/batch.rs`, Dualizer IF/Join behavior in
   `evaluate/dual.rs`, and `optimize_stack` in `evaluate/optimize.rs`. Searched
   existing evaluator sources for known-condition/path-truth/branch-assumption
   facilities; none provides this missing direct-lowering reuse. This patch
   extends Symbolica's compiler and adds no independent algebra manipulation.
2. **Symbolica usage/tests.** Existing scoped-cache journal tests, completed
   conditional/root reuse tests, inline/retained function shadowing/capture
   tests, mixed higher-Dual shared-conditional tests and batch inactive-pole
   tests constrain the semantics. `AliasedAtom`/`FunctionMap` sharing APIs are
   already present. Never-inline function bodies are not chosen as a workaround:
   they could bound construction while re-evaluating an exponential runtime DAG.
3. **FeynKit/gammaloop/Spenso.** The existing source-only sharing review
   `../algebra-sharing-review.md` (9ee4712e...) inspected the FeynKit evaluator,
   factor-preserving aliases, function registration and Spenso tensor aliases.
   The companion independent known-conditions review examines zero-arm selector
   collection specifically. These facilities do not replace a scoped direct
   compiler condition-fact map. No FeynKit prepass or second solver is added.

## Source subjects and meaningful proposed tests

- Baseline exact production `tree.rs`: 29d3263c414fd2d5b82eceeb7fe9f31cf0513f771307d2e5f90d7f9c4703e6fa.
- Private candidate: `tree.candidate.rs`; exact patch:
  `symbolica-scoped-condition.patch`.
- Seven new tests under `evaluate::tree::path_condition_tests`:
  condition-journal restoration; depth-12 aliased conditional diamond with one
  emitted IF and linear instruction bound; inactive zero-denominator removal
  plus independent later roots; unrelated conditions and sibling isolation;
  actual inline/retained function scopes with exported retained-body checks;
  pure imaginary truth and unchanged numeric payload; higher and mixed Taylor
  components with seeded condition derivatives and empty/singleton/odd batches.
- The exact complex-rational test uses Symbolica AtomField/evaluate_in_ring,
  avoiding a rounded numerical reference. The fixture includes c=i,q=1,
  where c^2+q is exactly zero, and an actually imaginary tested condition.

These are unexecuted source tests. A source review is necessary before any
execution. Complete old tests remain present in the copied candidate.

## Proposed finite next gate (not authorization)

After independent source review, freeze a compact private workspace/source copy
with this single Symbolica source delta. Reuse the currently compatible Cargo
lock and cached dependency artifacts without rebuilding historical reference
closures or changing production files. An exact concrete controller/source
snapshot must be reviewed before execution.

1. One Symbolica library-test build, CPU18/19, at most 1200 seconds including
   60 seconds of cleanup reserve. Use the actual project feature set, locked
   offline resolution, -j2; preserve any build failure. This larger explicit
   cap accounts for the retained earlier Symbolica test build (which included
   build-directory lock waiting); it is not an open-ended compile. A smaller
   bound can be chosen from the current Cargo cache when freezing the recipe.
2. One 180-second/20-reserve exact evaluator gate on a single core: all seven
   new tests plus the existing scoped-journal, completed-conditional,
   function-shadow/capture, mixed-Dual and batch-laziness regression tests.
   Per test cap30 seconds; exact selected names and expected counts must be
   frozen. No full unrelated Symbolica test suite is needed.
3. Only if those pass, build one private actual core/public example with the
   same single lowerer change, CPU18/19, 600 seconds/40 reserve. Do not alter
   scalar formulas, stability guards, interfaces or fixtures. Save the actual
   Cargo artifact, source copy and executable identity.
4. One candidate N2/rank7/IBP/Float128/requested53/rows1 diagnostic on CPU14,
   total180/reserve30/child135, same base fixture and profiling flags
   IREGI_PREPARATION_PROFILE=1 plus SYMBOLICA_SCOPE_PROFILE=1. Its purpose is to
   test preparation completion and emitted branch-reuse counts. A failure
   stops this proposal; no automatic larger timeout or extra topology retry.
5. If positive, separately authorize the complete N2 Float128/256 three-lane
   array qualification against the admitted 15 quad-IBP anchors, original
   1e-10 gate and strict 2^-80 precision/scaling/PV controls. Passing one-row
   diagnosis alone never qualifies the original six-case IBP corpus.

All supervision should reuse the reviewed owned-process lifecycle with actual
cleanup waiting inside reserve and preserve timeout/cleanup failures honestly.
No timing parity, Dual integral qualification, N7 rank-seven or generalized
coverage follows from these compiler tests alone.
