# IBP tensor sharing before workspace preparation

Source-only review, 25 October 2026. No compiler, evaluator, integral, profiler
or native job was run; no production source was changed. The reported N2
255-second workspace timeouts motivate this review but do not identify a
specific expensive substage.

## Finding

Scalar recurrence DAG sharing is **already enabled**. A change that merely
turns on scalar aliases would duplicate current behavior. The smallest useful
source experiment is to preserve external coefficient factors during the
existing Symbolica auxiliary-polynomial extraction, then consider explicit
aliases for completed tensor coefficients if downstream traversal is expensive.
Neither is established as the timeout fix. Workspace/stability preparation
needs independent substage evidence before any implementation is promoted.

The immutable adoption-context and current `plan.rs` are byte-identical at
`ffc4b176c4e93b163fad361b2c471f15b70c3b7f67ef9e0418a34817db402526`;
both `ibp.rs` copies are
`81efd31ed0349a894458673208d4bd444b04cbcd827fe45f0199c645425611e7`.
The separately applied typed-Dual early-error reset is in `execution.rs`;
it does not change the tensor generator or recurrence compiler considered here.
Snapshot root: `target/routing-rational-cayley-adoption/current-cargo-qualification/source-snapshot`.

## Where sharing exists and where expressions remain inline

1. `crates/iregi-rust/src/plan.rs:922–984` creates independent distance aliases,
   sets routing, calls `enable_aliases()`, enables physical poles and regular
   bubble paths. `ibp.rs:428–457` caches each scalar request and its four slots;
   `cache_atom` at464–474 returns a unique variable for every nontrivial body.
   Dependencies are appended before users. Existing test
   `ibp.rs:1664–1690` checks exact expanded equivalence and repeated-request
   node/alias reuse.
2. At `plan.rs:1005–1042`, tensor generating terms multiply polynomial weights
   by those scalar **handles**, not expanded recurrence bodies. The subsequent
   `.expand()`/`to_polynomial_in_vars_with_field` at1052–1054 expands the
   auxiliary generating expression; scalar handle definitions remain opaque.
   `entry[pole]=term.coefficient/weight` at1063 remains an inline Atom in each
   returned tensor moment. The plan appends scalar/PV aliases at1075–1077.
3. The existing exact evaluator adapter at `execution.rs:2476–2491` already
   registers all aliases, uses `direct_translation(true)`, zero Horner iterations,
   one core, and Symbolica Dualizer/stack optimization. Enabling direct
   translation or disabling Horner optimization again is not a new solution.
4. Symbolica's `evaluate/tree.rs:727–759` shares one `ScopedSubexpressions`
   cache across roots. Alias bodies inherit the caller's parameter bindings
   and this cache (`1028–1082`); ordinary functions have their own scope.
   The translator does not first substitute every alias into a giant Atom.
   A variable-shaped alias takes an early return at1151–1161; repeated alias
   resolution still visits its body cache. That is a possible traversal/hash
   cost, not evidence of duplicate generated arithmetic or the observed stall.

## An N2-specific source clue

`ibp.rs:447–453,960–1001` prepares a regular augmented-S bubble path and
returns `IF(detS, regular_value, ordinary_value)` for eligible requests. For
an ordinary tensor term with rank r and j metric pairs, h'=r−j and
sum(ν')=2+r−2j. Thus the eligibility h'>=sum(ν')−2 holds for every j>=0;
only the unshifted unit-power scalar base is explicitly excluded. Many
high-rank N2 descendants therefore carry lazy IFs even at regular numerical
points. This is a structural inference, not a run-time observation.

Symbolica deliberately rolls back branch-only cache entries between sibling
branches (`evaluate/tree.rs:7–62,1344–1370`). A global memoization/hoisting pass
that reuses such entries unconditionally could evaluate an inactive singular
denominator. Do not replace these IFs with a kinematically selected primal
branch, distribute them by handwritten algebra, or weaken existing guards.

## Existing facilities and smallest experiments

| Option | Existing API and useful experiment | Limitation |
|---|---|---|
| Restricted polynomial extraction | `AtomCore::to_polynomial_in_vars_with_field`, `dependencies/symbolica/src/atom/core.rs:1483–1507`, already accepts factored input and preserves non-auxiliary expressions as coefficients. Try removing only the global `.expand()` before conversion in a private copy. | Does not change scalar recurrence DAG or avoid the required auxiliary coefficient collection. Later stability code may expand coefficients again. No preparation gain is proved. |
| Existing opaque alias container | `symbolica::atom::AliasedAtom`, `atom/alias.rs:13–32,148–189`: `register_alias`, `add_alias`, `apply_aliases`, `evaluator_multiple`; `AtomCore::alias_subexpressions` at `atom/core.rs:350–375`. Use existing Symbolica extraction if repeated coefficient subexpressions should become handles. | Do not write a local CSE/replacement engine. Preserve unique namespaces, dependency order, all native slots and the complete root set used by master arguments/activation/guards. |
| Additional moment handles | After Symbolica coefficient extraction, register each nontrivial completed coefficient body as an alias and return its handle, using the same dependency-ordered plan representation/evaluator registration as scalar nodes. | This relocates storage/traversal; it is not an algebraic simplification. It can add aliases and slow preparation, and cannot hide master dependence from stability guards. |
| Existing alias cleanup | `AliasedAtom::prune` and `fuse_duplicate_aliases`, `atom/alias.rs:348–398`. Exact duplicate-body rewriting is already supplied. | `prune` scans repeatedly; `fuse_duplicate_aliases` keeps the first HashMap encounter, not original topological order. A direct HashMap-to-Vec replacement is unsafe for IREGI's dependency-ordered consumers. Include all guard/argument roots, not tensor roots alone. Do not call `into_inner` or `flatten_operators` when preservation of sharing is intended. |
| Retained function bodies | `FunctionRegistrationOptions::new().inlining(InliningPolicy::Never)` with `EvaluatorBuilder::add_function_with_options`/`add_tagged_function_with_options`, `evaluate/function_map.rs:30–68,341–377`. Builds separate shared subevaluators. | Not a drop-in alias flag: `add_aliases` always uses caller-scope inlining; ordinary functions resolve globals/formal arguments differently. Existing stability, activation and uncertainty consumers accept aliases, not arbitrary opaque new functions. They must still see dependencies and lazy branches. |

The restricted converter is directly implemented at `symbolica/src/poly.rs:1547–1660`:
non-auxiliary parts remain Atom coefficients; integer powers, products and sums
are converted through Symbolica polynomial operations. Its public doc witness
`t*(x+y)^100` stays a one-term polynomial in t (`atom/core.rs:1491–1495`).
`expand_in` at612–631 is another existing restricted expansion API if needed;
there is no reason to implement one locally.

The default optimizer already selects direct translation; current IREGI sets
Horner=0 explicitly. Options for common-pair cache size/distance, CPE iterations,
hot starts and abort checks exist (`evaluate/function_map.rs:396–446,498–586`),
but enabling costly Horner/CPE optimization is not a justified fix for a
construction stall. `tree.rs:395–397` sends Horner=0 directly to linearization.

## Three reuse checks

1. **Symbolica API/source:** verified the restricted polynomial converter,
   `AliasedAtom`, subexpression extraction and cleanup APIs above; verified
   scoped direct translation and separate-function registration semantics.
   No missing algebra operation was identified. New local polynomial
   expansion, factoring, alias substitution, CSE or solver code is unnecessary.
2. **Symbolica usage/tests:** `atom/alias.rs:644–678` tests alias creation,
   nested representation and byte accounting; the later tests cover alias
   merging/renaming/conflicts. `evaluate.rs:1047–1065` checks capture aliases
   with explicit function arguments, and1101–1149 demonstrates shared nested
   function bodies without expanding an exponential call tree. IREGI's own
   `scalar_dag_preserves_inline_results_and_reuses_nodes` already tests the
   current recurrence alias contract. These are inspected source tests, not
   newly executed tests or proof of N2 performance.
3. **FeynKit/gammaloop/Spenso equivalents:**
   `references/gammaloop_feynkit/crates/gammalooprs/src/integrands/process/evaluators.rs:2982–3020`
   retains factored `AliasedAtom` roots, registers aliases and function maps,
   and records root/body sizes before building. Its
   `scalar_products_of_independent_sums_keep_linear_instruction_growth` test
   at4888–4935 explicitly covers unexpanded products, root aliases and map
   aliases. `integrands/process/param_builder.rs:838–864` distinguishes
   caller-scope aliases from retained functions. Spenso's
   `tensors/data/dense.rs:233–244` registers tensor components with Symbolica
   aliases. Reuse these conventions rather than constructing a second DAG/CAS.

All FeynKit paths above are under `/shared/external/iregi/references/gammaloop_feynkit`;
Symbolica paths are under `/shared/external/iregi/iregi-rust/dependencies/symbolica`.
The reference ecosystem is source inspiration; importing its large numerator
framework into the numerical reduction core is not needed for these APIs.

## Qualification boundary

First compare exact complete tensor coefficient arrays with old/new forms via
Symbolica, including symbolic unspecialized masses/routing and four Laurent
slots. Retain all generalized/routing/IF fallback identities. Compare root
bytes, total alias-body bytes, alias counts and emitted instruction counts
before an authorized bounded workspace experiment; avoid expanding all aliases
just to count them. Check N1/N2/N3 and rank progression to separate expression
growth from precision mapping, master preparation and guard preparation.

Any later numerical qualification must retain requested53, all coefficients,
unchanged1e-10/reference and2^-80 convergence gates, empty/batched/failed lanes,
precision-sensitive inputs and full first/higher/mixed Dual components.
`BatchExpressionEvaluator` already propagates batches through shared functions
and lazy active lanes (`evaluate/batch.rs:3–12,40–63`); preserve that path.
Do not turn a preparation improvement into a performance or correctness claim
without separate matched measurements. This note authorizes no such jobs.
