#[cfg(test)]
mod path_condition_tests {
    use super::*;

    fn build(expression: &str, parameters: &[Atom]) -> ExpressionEvaluator<Complex<Rational>> {
        crate::parse!(expression)
            .evaluator(parameters)
            .direct_translation(true)
            .horner_iterations(0)
            .build()
            .unwrap()
    }

    fn branches(exact: &ExpressionEvaluator<Complex<Rational>>) -> usize {
        exact.export_instructions().instructions.iter()
            .filter(|instruction| matches!(instruction, Instruction::IfElse(..))).count()
    }

    #[test]
    fn path_condition_journal_restores_nested_facts() {
        let mut cache = ScopedSubexpressions::default();
        let condition = Slot::Param(0);
        let outer = cache.checkpoint();
        cache.assume_condition(condition, true);
        let inner = cache.checkpoint();
        cache.assume_condition(condition, false);
        cache.assume_condition(Slot::Temp(10), true);
        cache.restore(inner);
        assert_eq!(cache.condition(condition), Some(true));
        assert_eq!(cache.condition(Slot::Temp(10)), None);
        cache.restore(outer);
        assert_eq!(cache.condition(condition), None);
        assert!(cache.condition_changes.is_empty());
        assert_eq!(cache.depth, 0);
    }

    #[test]
    fn repeated_condition_alias_diamond_has_linear_instruction_growth() {
        // Alias DAG, not an expanded expression tree. Both arms recursively
        // refer to the same predecessor and to the same parameter-only test.
        let condition = crate::parse!("path_condition::det");
        let parameters = [crate::parse!("c"), crate::parse!("q"), crate::parse!("x")];
        let mut aliases = vec![(condition.clone(), crate::parse!("c^2+q"))];
        let mut previous = parameters[2].clone();
        let depth = 12;
        for i in 1..=depth {
            let alias = Atom::var(crate::symbol!(format!("path_condition::node_{i}")));
            let body = crate::function!(Symbol::IF, &condition,
                &previous + Atom::num(i), 2 * &previous - Atom::num(i));
            aliases.push((alias.clone(), body));
            previous = alias;
        }
        let exact = previous.evaluator(&parameters).add_aliases(aliases).unwrap()
            .direct_translation(true).horner_iterations(0).build().unwrap();
        assert_eq!(branches(&exact), 1);
        assert!(exact.export_instructions().instructions.len() < 16 * depth as usize + 32);
        let ring = crate::domains::atom::AtomField::new();
        let mut exact = exact.map_to_ring(&ring).unwrap();
        // Pure imaginary c also exercises complex nonzero semantics; c=i,q=1
        // gives exactly zero, whereas c=i,q=0 gives nonzero.
        for (c, q, x) in [
            (Complex::new(0, 0), 0, 3),
            (Complex::new(1, 0), 0, -2),
            (Complex::new(0, 1), 1, 2),
            (Complex::new(0, 1), 0, -3),
        ] {
            let c = Complex::new(Rational::from(c.re), Rational::from(c.im));
            let q = Complex::new(Rational::from(q), Rational::zero());
            let x = Complex::new(Rational::from(x), Rational::zero());
            let active = !(&c * &c + &q).is_zero();
            let mut expected = x.clone();
            for i in 1..=depth {
                let offset = Complex::new(Rational::from(i), Rational::zero());
                expected = if active { expected + offset } else { &expected + &expected - offset };
            }
            let inputs = [Atom::num(c), Atom::num(q), Atom::num(x)];
            assert_eq!(exact.evaluate_single_in_ring(&inputs, &ring), Atom::num(expected));
        }
    }

    #[test]
    fn same_condition_prunes_only_unreachable_poles_and_not_other_roots() {
        let parameters = [crate::parse!("c"), crate::parse!("x"), crate::parse!("y"), crate::parse!("z")];
        let expressions = [
            crate::parse!("if(c,if(c,x,1/z),if(c,1/z,y))"),
            crate::parse!("if(c,y,x)"),
        ];
        let exact = Atom::evaluator_multiple(&expressions, &parameters)
            .direct_translation(true).horner_iterations(0).build().unwrap();
        // An outer fact cannot escape into the next output root.
        assert_eq!(branches(&exact), 2);
        assert!(!exact.export_instructions().instructions.iter()
            .any(|instruction| matches!(instruction, Instruction::Pow(_, _, -1, _))));
        let mut scalar = exact.map_coeff(&|value| value.re.to_f64());
        let mut batch = scalar.clone().into_batch_evaluator();
        let inputs = [1., 2., 3., 0., 0., 5., 7., 0., -1., 11., 13., 0., 0., 17., 19., 0., 1., 23., 29., 0.];
        let expected = [2., 3., 7., 5., 11., 13., 19., 17., 23., 29.];
        for (row, expected) in inputs.chunks_exact(4).zip(expected.chunks_exact(2)) {
            let mut actual = [0.; 2];
            scalar.evaluate(row, &mut actual);
            assert_eq!(actual, expected);
        }
        for rows in [5, 0, 1, 3, 5] {
            let mut actual = vec![f64::NAN; rows * 2];
            batch.evaluate_batch(&inputs[..rows * 4], &mut actual, rows).unwrap();
            assert_eq!(actual, expected[..rows * 2]);
        }
    }

    #[test]
    fn different_conditions_and_sibling_facts_remain_independent() {
        let params = [crate::parse!("c"), crate::parse!("d"), crate::parse!("x"), crate::parse!("y")];
        let exact = build("if(c,if(d,x,y),if(d,y,x))+if(d,3,4)", &params);
        assert_eq!(branches(&exact), 4);
        let mut actual = exact.map_coeff(&|value| value.re.to_f64());
        for (c, d, expected) in [(0., 0., 6.), (0., 1., 8.), (1., 0., 9.), (1., 1., 5.)] {
            assert_eq!(actual.evaluate_single(&[c, d, 2., 5.]), expected);
        }
    }

    #[test]
    fn inline_and_retained_functions_do_not_inherit_caller_truth_by_name() {
        let parameters = [crate::parse!("c"), crate::parse!("d"), crate::parse!("x"), crate::parse!("y")];
        for policy in [InliningPolicy::Always, InliningPolicy::Never] {
            let exact = crate::parse!("if(c,path_condition_scope::f(d),path_condition_scope::f(c))")
                .evaluator(&parameters)
                .add_function_with_options(crate::symbol!("path_condition_scope::f"),
                    vec![crate::symbol!("c")], crate::parse!("if(c,x,y)"),
                    FunctionRegistrationOptions::new().inlining(policy))
                .unwrap().direct_translation(true).horner_iterations(0).build().unwrap();
            assert_eq!(exact.export_instructions().sub_evaluators.len(),
                usize::from(policy == InliningPolicy::Never));
            let mut actual = exact.map_coeff(&|value| value.re.to_f64());
            for (c, d, expected) in [(1., 0., 5.), (1., 1., 2.), (0., 1., 5.), (0., 0., 5.)] {
                assert_eq!(actual.evaluate_single(&[c, d, 2., 5.]), expected);
            }
        }
    }

    #[test]
    fn repeated_conditions_preserve_higher_mixed_duals_and_batch_laziness() {
        let parameters = [crate::parse!("c"), crate::parse!("x"), crate::parse!("y"), crate::parse!("z")];
        let exact = build("if(c,if(c,x^2+x*y,1/z),if(c,1/z,x*y))", &parameters);
        assert_eq!(branches(&exact), 1);
        let shape = crate::domains::dual::HyperDual::<Complex<Rational>>::new(vec![
            vec![0, 0], vec![1, 0], vec![0, 1], vec![2, 0], vec![1, 1],
        ]);
        let mut scalar = exact.vectorize(&Dualizer::new(shape, vec![])).unwrap()
            .map_coeff(&|value| value.re.to_f64());
        let mut batch = scalar.clone().into_batch_evaluator();
        let mut inputs = Vec::new();
        let mut expected = Vec::new();
        for (c, x, y) in [(0., 2., 3.), (1., -2., 5.), (-1., 3., -1.)] {
            // Deliberately nonzero condition derivatives: analytic branches are
            // selected from the primal, and their derivatives remain separate.
            let row = [c, 7., 11., 13., 17., x, 1., 0., 0., 0., y, 0., 1., 0., 0., 0., 0., 0., 0., 0.];
            let reference = if c != 0. { [x*x+x*y, 2.*x+y, x, 1., 1.] } else { [x*y, y, x, 0., 1.] };
            let mut output = [0.; 5];
            scalar.evaluate(&row, &mut output);
            assert_eq!(output, reference);
            inputs.extend(row);
            expected.extend(reference);
        }
        for rows in [3, 0, 1, 3] {
            let mut actual = vec![f64::NAN; rows * 5];
            batch.evaluate_batch(&inputs[..rows * 20], &mut actual, rows).unwrap();
            assert_eq!(actual, expected[..rows * 5]);
        }
    }

    #[test]
    fn pure_imaginary_truth_keeps_the_original_numeric_condition_value() {
        let parameters = [crate::parse!("c"), crate::parse!("x"), crate::parse!("y"), crate::parse!("z")];
        let exact = build("if(c,if(c,c*x,1/z),if(c,1/z,y))", &parameters);
        assert_eq!(branches(&exact), 1);
        let ring = crate::domains::atom::AtomField::new();
        let mut exact = exact.map_to_ring(&ring).unwrap();
        for (condition, expected) in [(Atom::num(Complex::new(Rational::zero(), Rational::one())), Atom::num(Complex::new(Rational::zero(), Rational::from(2)))),
                                      (Atom::num(0), Atom::num(7)),
                                      (Atom::num(Complex::new(Rational::zero(), -Rational::one())), Atom::num(Complex::new(Rational::zero(), Rational::from(-2))))] {
            assert_eq!(exact.evaluate_single_in_ring(&[condition, Atom::num(2), Atom::num(7), Atom::num(0)], &ring), expected);
        }
    }
}
