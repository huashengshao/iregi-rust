use crate::shared_binary_kernel;
use oneloop::rust_codegen::runtime::{BatchWorkspace, C, ConstantSpec, Context, NativeFloat, batch, primitives};
#[allow(unused_assignments,dead_code)] #[path="b0_baseline.rs"] mod baseline;
#[allow(unused_assignments,dead_code)] #[path="b0_candidate.rs"] mod candidate;
#[path="constants.rs"] mod constants;
pub fn context<T:NativeFloat>(prototype:&T)->Context<T>{Context::new(constants::CONSTANTS,prototype.get_precision()).unwrap()}
pub fn evaluate<T:NativeFloat>(candidate:bool,input:&[C<T>],output:&mut[C<T>],rows:usize,context:&Context<T>,workspace:&mut BatchWorkspace<T>)->Result<(),String>{
 if candidate{self::candidate::evaluate_batch(input,output,rows,context,workspace)}else{baseline::evaluate_batch(input,output,rows,context,workspace)}
}
