# Two uninstrumented Symbolica archives — source/preflight

This is the next privately qualified build step after the local 15-test scheduler gate. It is not a TIRust reduction or performance run. Root grants exactly two sequential Symbolica rlibs after independent mechanical review/freeze, each compiler capped at 180 seconds, with a 420-second aggregate budget and 20 seconds reserved for cleanup/post-guards, on CPUs32,33. No retry/extension, Cargo/dependency build, live source change, OneLoop/master/core/probe build, or timing experiment is granted.

Each source snapshot has91 original files from the exact qualified live source inventory. Both omit the extra frozen evaluator/test modules and all custom trace hooks. The baseline is byte-identical to that inventory; the only candidate difference is the reviewed production batch.rs delta (`eb73974b...`→`6db2acb4...`). The compiler uses the prior28 exact non-Python externs/native closure and the same opt0/debug/overflow/no-LTO/codegen settings. Changes to its arguments are removal of `--test`, addition of `--crate-type rlib`, explicit source/output paths, and distinct baseline/candidate metadata identities. Package/environment semantics stay identical.

The protocol binds838 source/artifact inputs and3 tool hashes. It retains the successful15-test compile/receipt, the sealed durable capsule and its31 payloads, and both earlier fixture compile failures. The runner uses the byte-identical reviewed lifecycle helper. It selects the larger20-second caller reserve before arming the work deadline, persists terminal events before hashes, checks owned groups even after leader exit, and guards both input/protocol bytes and completed archives throughout the remaining step/final publication.

The two exact compiler argument arrays, environment maps and output paths are in protocol.json. The source inventory separately identifies all91 files in each variant and the sole production difference. A regular ar header, complete archive SHA/size and lifecycle/guard receipt establish build output only; no dependent final link or numerical correctness is inferred. Each archive must later reach its own matching dependency chain/process with one Symbolica kernel; existing OneLoop/masters/core artifacts cannot silently bind the old Symbolica identity.

After the root's conditional grant and independent mechanical PASS, the single stage invocation is:

```sh
source scripts/env.sh
python3 target/guard-performance-review/dependent-relink-qualification/build.py REVIEWED_PROTOCOL_SHA256
```

Do not execute merely because this command is documented. Runtime tests and the dependent chain require separate reviewed grants; the full tensor/Laurent/Taylor record comparison plan is retained in ../dependent-relink-proposal/PROPOSAL.md.
