"""Freeze two uninstrumented Symbolica sources/commands; launches no compiler."""
from pathlib import Path
import hashlib, json, shutil, datetime

ROOT = Path('/shared/external/iregi/iregi-rust')
HERE = ROOT / 'target/guard-performance-review/dependent-relink-qualification'
PRIOR = ROOT / 'target/guard-performance-review/qualification-plan-v4'
CAPSULE = ROOT / 'validation/uniform-branch-scheduler'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


assert Path.cwd() == ROOT
assert not (HERE / 'source').exists(), 'Preserve existing preparations; no overwrite'
prior_protocol = json.loads((PRIOR / 'protocol.json').read_text())
assert sha(PRIOR / 'protocol.json') == '093c8d1112b927851fe00c83d5eb7077e257c4e6789822a3abb9b3d7833e48f0'
prior_inventory = json.loads((PRIOR / 'source-inventory.json').read_text())
capsule = json.loads((CAPSULE / 'qualification.json').read_text())
assert sha(CAPSULE / 'qualification.json') == '5f8d8d5d925cc0c1e6d429e6182d041e8f0f50ed52cd3b7fb26b00168416d19a'
assert capsule['local_fixture_qualified'] and capsule['local_exact_test_count'] == 15
protected = dict(prior_protocol['protected_sha256'])
tools = dict(prior_protocol['tool_sha256'])
for raw, expected in {**protected, **tools}.items():
    path = Path(raw) if Path(raw).is_absolute() else ROOT / raw
    assert sha(path) == expected, raw
for path in [PRIOR / 'manifest.json', PRIOR / 'compile-003/receipt.json', PRIOR / 'tests-003/receipt.json', CAPSULE / 'qualification.json']:
    protected[str(path.relative_to(ROOT))] = sha(path)
for name, entry in capsule['files'].items():
    path = CAPSULE / name
    assert sha(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
    protected[str(path.relative_to(ROOT))] = entry['sha256']
base_batch = ROOT / 'target/guard-performance-review/base/batch.rs'
candidate_batch = ROOT / 'target/guard-performance-review/candidate/batch.rs'
assert sha(base_batch) == 'eb73974b0c176422863e4fbe512d392813d83085b2ae5c476db24d028012efcf'
assert sha(candidate_batch) == '6db2acb4b342e5fb1ac78ac04f39abaf72541acff7279ddce505fcfe095a53bf'
source_maps = {}
steps = []
for variant, batch in [('baseline', base_batch), ('candidate', candidate_batch)]:
    source = HERE / 'source' / variant / 'symbolica'
    mapping = {}
    for raw, expected in prior_inventory['live_source_sha256'].items():
        original = ROOT / raw
        assert sha(original) == expected
        relative = original.relative_to(ROOT / 'dependencies/symbolica')
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(batch if str(relative) == 'src/evaluate/batch.rs' else original, target)
        mapping[str(relative)] = sha(target)
        protected[str(target.relative_to(ROOT))] = sha(target)
    assert len(mapping) == 91
    assert 'src/evaluate/uniform_branch_baseline.rs' not in mapping
    assert 'src/evaluate/uniform_branch_tests.rs' not in mapping
    assert 'mod uniform_branch_baseline' not in (source / 'src/evaluate.rs').read_text()
    text = (source / 'src/evaluate/batch.rs').read_text()
    for marker in ['uniform_branch_tests', 'record_step(', 'record_jump(', 'FrozenBatchExpressionEvaluator']:
        assert marker not in text
    assert sha(source / 'src/evaluate/batch.rs') == sha(batch)
    source_maps[variant] = mapping
    output = HERE / 'symbolica-build-001' / variant / 'libsymbolica.rlib'
    command = list(prior_protocol['compile_command'])
    index = command.index('--test')
    command[index:index + 1] = ['--crate-type', 'rlib']
    command[command.index(str(PRIOR / 'source/symbolica/src/lib.rs'))] = str(source / 'src/lib.rs')
    index = command.index('metadata=tirust_uniform_branch_v2')
    command[index] = 'metadata=tirust_uniform_branch_' + variant + '_rlib_001'
    command[command.index('-o') + 1] = str(output)
    environment = dict(prior_protocol['compile_environment_overrides'])
    environment['CARGO_MANIFEST_DIR'] = str(source)
    steps.append({'variant': variant, 'command': command, 'environment': environment, 'compiler_cap_seconds': 180, 'output': str(output)})
assert source_maps['baseline'].keys() == source_maps['candidate'].keys()
assert [name for name in source_maps['baseline'] if source_maps['baseline'][name] != source_maps['candidate'][name]] == ['src/evaluate/batch.rs']
for name, expected in prior_inventory['live_source_sha256'].items():
    assert sha(ROOT / name) == expected
lifecycle_source = PRIOR / 'lifecycle.py'
shutil.copyfile(lifecycle_source, HERE / 'lifecycle.py')
assert sha(HERE / 'lifecycle.py') == 'c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824'
for name in ['prepare.py', 'build.py', 'lifecycle.py']:
    protected[str((HERE / name).relative_to(ROOT))] = sha(HERE / name)
inventory = {'scope': 'Two complete uninstrumented production source snapshots; no compiler executed.', 'source_sha256': source_maps, 'live_source_files': 91, 'variant_source_files': 91, 'only_variant_difference': 'src/evaluate/batch.rs', 'baseline_batch_sha256': sha(base_batch), 'candidate_batch_sha256': sha(candidate_batch), 'extra_frozen_evaluator_and_trace_modules_absent': True}
save(HERE / 'source-inventory.json', inventory)
protected[str((HERE / 'source-inventory.json').relative_to(ROOT))] = sha(HERE / 'source-inventory.json')
protocol = {'schema_version': 1, 'status': 'FROZEN_SOURCE_PREFLIGHT_PENDING_INDEPENDENT_REVIEW', 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Exactly two sequential uninstrumented Symbolica rlibs only; no OneLoop/masters/core/probe build or numerical/performance execution.', 'cwd': str(ROOT), 'aggregate_budget_seconds': 420, 'cleanup_postguard_reserve_seconds': 20, 'effective_work_deadline_seconds': 400, 'cpu_affinity': '32,33', 'steps': steps, 'protected_sha256': protected, 'tool_sha256': tools, 'local15_test_capsule': str(CAPSULE.relative_to(ROOT)), 'local15_test_capsule_sha256': sha(CAPSULE / 'qualification.json'), 'original_failed_attempts_preserved': ['001', '002'], 'same_opt0_debug_features_externs_native_closure_as_prior': True, 'extern_count': 28, 'archive_binding_policy': 'One separately identified Symbolica archive per future dependency chain/process; old Symbolica/OneLoop/masters archives never substituted.', 'numerical_qualified': False, 'performance_qualified': False, 'production_adoption_authorized': False, 'failure_policy': 'Stop first failure or timeout; preserve all terminal/source bytes; no retry or extension.'}
save(HERE / 'protocol.json', protocol)
print(json.dumps({'protocol_sha256': sha(HERE / 'protocol.json'), 'protected_inputs': len(protected), 'source_files_per_variant': 91, 'compiler_invocations': len(steps), 'no_compiler_executed': True}))
