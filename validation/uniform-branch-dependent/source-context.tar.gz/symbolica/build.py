"""One separately granted two-rlib stage; importing launches nothing."""
from pathlib import Path
import hashlib, json, os, sys
sys.dont_write_bytecode = True
from lifecycle import Budget, execute

ROOT = Path('/shared/external/iregi/iregi-rust')
HERE = ROOT / 'target/guard-performance-review/dependent-relink-qualification'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    assert len(sys.argv) == 2, 'Expected the independently reviewed protocol digest'
    assert Path.cwd() == ROOT
    protocol_path = HERE / 'protocol.json'
    reviewed = sys.argv[1]
    assert sha(protocol_path) == reviewed
    protocol = json.loads(protocol_path.read_text())
    attempt = HERE / 'symbolica-build-001'
    attempt.mkdir(exist_ok=False)
    budget = Budget(protocol['aggregate_budget_seconds'])
    # Reuse the exact proven helper; choose the larger caller-owned reserve
    # explicitly before arming its work-deadline signal.
    budget.work_deadline = budget.deadline - protocol['cleanup_postguard_reserve_seconds']
    record = {'status': 'preparing', 'success': False, 'protocol_sha256': reviewed, 'runner_sha256': sha(Path(__file__)), 'aggregate_budget_seconds': protocol['aggregate_budget_seconds'], 'cleanup_postguard_reserve_seconds': protocol['cleanup_postguard_reserve_seconds'], 'steps': [dict(step, status='unrun') for step in protocol['steps']], 'outputs': {}, 'cleanup_errors': [], 'scope': protocol['scope'], 'numerical_execution': False, 'performance_measurement': False}
    receipt = attempt / 'build.json'
    save(receipt, record)
    outputs = {}

    def verify():
        assert sha(protocol_path) == reviewed, 'Protocol changed during stage'
        for raw, expected in {**protocol['protected_sha256'], **protocol['tool_sha256']}.items():
            budget.remaining()
            path = Path(raw) if Path(raw).is_absolute() else ROOT / raw
            assert sha(path) == expected, 'Input changed: ' + raw
        for path, expected in outputs.items():
            budget.remaining()
            assert sha(path) == expected, 'Output changed: ' + str(path)

    budget.arm()
    try:
        assert not os.environ.get('RUSTC_BOOTSTRAP')
        verify()
        record['guard_before'] = True
        for step in record['steps']:
            budget.remaining()
            output = Path(step['output'])
            output.parent.mkdir(exist_ok=True)
            env = dict(os.environ)
            env.update(step['environment'])

            def persist(result):
                step.update(result)
                save(receipt, record)

            log = attempt / (step['variant'] + '.log')
            result = execute(step['command'], log, budget, step['compiler_cap_seconds'], record['cleanup_errors'], persist, env)
            assert result['status'] == 'exited', 'Compiler failed/timed out; stop, no retry or extension'
            verify()
            with output.open('rb') as stream:
                assert stream.read(8) == b'!<arch>\n', 'Expected a regular Rust library archive'
            fingerprint = sha(output)
            outputs[output] = fingerprint
            record['outputs'][step['variant']] = {'path': str(output), 'sha256': fingerprint, 'bytes': output.stat().st_size, 'format': 'regular ar archive; no final dependent link performed'}
            step['log_sha256'] = sha(log)
            step['output_sha256'] = fingerprint
            step['status'] = 'passed'
            save(receipt, record)
        record['status'] = 'completed-awaiting-final-guards'
    except Exception as error:
        record.update(status='failed', error=repr(error))
    save(receipt, record)
    try:
        verify()
        record['guard_after'] = True
    except Exception as error:
        record.update(guard_after=False, guard_error=repr(error))
    record['elapsed_seconds_diagnostic'] = budget.elapsed()
    record['deadline_exceeded'] = record['elapsed_seconds_diagnostic'] > protocol['aggregate_budget_seconds']
    if budget.cancelled:
        record['cancellation'] = budget.cancelled
    record['success'] = all(step['status'] == 'passed' for step in record['steps']) and record['guard_after'] and not record['cleanup_errors'] and not record['deadline_exceeded'] and not budget.cancelled and 'error' not in record
    record['status'] = 'passed' if record['success'] else 'failed'
    save(receipt, record)
    budget.disarm()
    print(json.dumps({'status': record['status'], 'receipt_sha256': sha(receipt), 'outputs': record['outputs'], 'elapsed_seconds_diagnostic': record['elapsed_seconds_diagnostic']}))
    return 0 if record['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
