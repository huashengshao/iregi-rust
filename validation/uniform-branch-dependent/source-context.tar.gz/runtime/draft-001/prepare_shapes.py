"""Reuse retained fixture inputs and shapes/masks only; no kernel execution."""
from pathlib import Path
import hashlib,json
ROOT=Path('/shared/external/iregi/iregi-rust');HERE=ROOT/'target/guard-performance-review/dependent-runtime-proposal'
assert Path.cwd()==ROOT
raw=ROOT/'target/native-f64-opt-in/qualification/whole-qualification-001/responses.jsonl'
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
controls=None
for line in raw.open():
 event=json.loads(line)
 if event['event']=='response'and event['stage']=='controls':controls=event['response'];break
assert controls is not None
masters=controls['controls']['masters']
def snapshot_shape(s):return{'rows':s['rows'],'components':s['components'],'errors':[lane['error']for lane in s['lanes']]}
def selected(f):return{'family':f['family'],'cases':[{'label':c['label'],'input_metadata':c['input_metadata'],**snapshot_shape(c['baseline'])}for c in f['cases']]}
def unchanged(f):
 return{'label':f['label'],'family':f['family'],'shape':f['shape'],'components':f['components'],'cases':[{'label':c['label'],'input_metadata':c['input_metadata'],**snapshot_shape(c['represented_outputs'])}for c in f['cases']]}
def core(c):return{'label':c['label'],'components':c['components'],'input':c['input'],'complex_output_count':len(c['result']['values'])}
shape={'scope':'Only fixed input metadata, expected errors, row/component counts and shapes from retained validated controls. No integrated/master result values copied.','source':str(raw.relative_to(ROOT)),'source_sha256':sha(raw),'core':[core(c)for c in controls['controls']['baseline']],'extended_core':[core(c)for c in controls['extended_unchanged_controls']['baseline']],'selected_families':[selected(f)for f in masters['selected_families']],'unchanged_paths':[unchanged(f)for f in masters['unchanged_paths']],'extended_unchanged_paths':[unchanged(f)for f in masters['extended_unchanged_paths']],'extended_inventory':masters['extended_inventory'],'cache_shapes':[False,True,False,True],'cache_indices':[2,1,0,3,2,0,3,1]}
p=HERE/'control-shapes.json'
with p.open('x')as f:json.dump(shape,f,indent=2);f.write('\n')
print(json.dumps({'control_shapes_sha256':sha(p),'prior_outputs_copied':False}))
