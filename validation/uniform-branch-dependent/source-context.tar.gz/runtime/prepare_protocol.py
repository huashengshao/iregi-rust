"""Freeze a concrete future runtime protocol; launches no executable."""
from pathlib import Path
import datetime,hashlib,json
ROOT=Path('/shared/external/iregi/iregi-rust');HERE=ROOT/'target/guard-performance-review/dependent-runtime-proposal'
BUILD=ROOT/'target/guard-performance-review/dependent-chain-proposal'
assert Path.cwd()==ROOT and not(HERE/'protocol.json').exists()
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
bp=BUILD/'protocol.json';assert sha(bp)=='2e9732b14c6cc2b352fc43a4dcd0f5910ef36036b392c6188bffb681e291c814'
build_protocol=read(bp);receipt=BUILD/'chain-build-001/build.json'
assert sha(receipt)=='36dc506beedf0ac9c217a6549e297efc054a975fb1043f6f7fcd0b903a30455d'
build=read(receipt);assert build['success']and build['status']=='passed'and build['guard_after']and build['guard_before']and not build['cleanup_errors']
assert len(build['steps'])==8 and all(x['status']=='passed'for x in build['steps'])
protected=dict(build_protocol['protected_sha256']);tools=dict(build_protocol['tool_sha256'])
for raw,expected in {**protected,**tools}.items():assert sha(Path(raw)if Path(raw).is_absolute()else ROOT/raw)==expected,raw
for p in [bp,BUILD/'manifest.json',receipt,ROOT/'target/guard-performance-review/dependent-chain-build-grant-001.json']+list((BUILD/'chain-build-001').glob('*.log')):
 protected[str(p.relative_to(ROOT))]=sha(p)
for item in build['outputs'].values():
 p=Path(item['path']);assert sha(p)==item['sha256']and p.stat().st_size==item['bytes'];protected[str(p.relative_to(ROOT))]=item['sha256']
 if'link_map'in item:
  m=item['link_map'];p=Path(m['path']);assert sha(p)==m['sha256']and p.stat().st_size==m['bytes'];protected[str(p.relative_to(ROOT))]=m['sha256']
probes={}
for variant in ['baseline','candidate']:
 item=build['outputs'][variant+'-probe'];assert item['one_symbolica_archive_linked']is True
 probes[variant]={k:item[k]for k in ['path','sha256','bytes','archive_binding','link_map']}
shape=read(HERE/'control-shapes.json');source=ROOT/shape['source'];assert sha(source)==shape['source_sha256'];protected[shape['source']]=shape['source_sha256']
for p in HERE.rglob('*'):
 if p.is_file()and p not in [HERE/'protocol.json',HERE/'manifest.json']and'reviews'not in p.relative_to(HERE).parts:protected[str(p.relative_to(ROOT))]=sha(p)
inputs=BUILD/'frozen-inputs.json';cases=read(inputs)
assert len(cases)==4 and{(c['n'],c['rank'])for c in cases}=={(2,0),(2,1),(3,0),(3,1)}and all(len(c['samples'])>=32 for c in cases)
for p in HERE.glob('*.py'):compile(p.read_text(),str(p),'exec')
assert sha(HERE/'lifecycle.py')=='c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824'
original=ROOT/'target/native-f64-opt-in/qualification/interactive.py';protected[str(original.relative_to(ROOT))]=sha(original)
assert(HERE/'interactive.py').read_text()==original.read_text().replace("command=[taskset,'-c','22',str(binary)]","command=[taskset,'-c','32',str(binary)]")
protocol={'schema_version':1,'status':'SOURCE_PROPOSAL_ONLY_NO_NUMERICAL_GRANT','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(ROOT),
 'scope':'One future untimed complete-record original/candidate generic-only scheduler comparison; no performance/live-application claim. No numerical execution authorized by this source packet.',
 'aggregate_budget_seconds':240,'cleanup_postguard_reserve_seconds':20,'effective_work_deadline_seconds':220,'cpu_affinity':'32','taskset':build_protocol['steps'][0]['command'][0],
 'request_count':60,'responses_per_process':30,'probes':probes,'build_receipt':str(receipt),'build_receipt_sha256':sha(receipt),'inputs':str(inputs),'inputs_sha256':sha(inputs),
 'control_shapes':str(HERE/'control-shapes.json'),'control_shapes_sha256':sha(HERE/'control-shapes.json'),'protected_sha256':protected,'tool_sha256':tools,
 'future_command':['python3',str(HERE/'run.py'),'<reviewed-protocol-sha256>'],
 'environment':'Use scripts/env.sh and the user-provided .local/symbolica-license.env before a separately granted runtime. Record only license presence, never its value.',
 'complete_comparison':'Exact complete cross-archive records, all represented values/precision/sign, tensor/Laurent/Taylor/master/status/fallback/diagnostic/counters; own-repeat and retained comparison ignores only plan_reused.',
 'failure_policy':'First failure, timeout, changed input/output guard, cancellation, incomplete output or cleanup error terminates the stage; no retry/extension. Preserve terminal/raw evidence.',
 'numerical_executed':False,'numerical_qualified':False,'performance_qualified':False,'production_adoption_authorized':False}
save(HERE/'protocol.json',protocol)
files={str(p.relative_to(HERE)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(HERE.rglob('*'))if p.is_file()and p!=HERE/'manifest.json'and'reviews'not in p.relative_to(HERE).parts}
save(HERE/'manifest.json',{'scope':'Frozen runtime source-only proposal, not executed','protocol_sha256':sha(HERE/'protocol.json'),'files':files,'compiler_or_numerical_run':False,'performance_measurement':False,'self_exclusion':'manifest.json and independent reviews/ files only'})
print(json.dumps({'protocol_sha256':sha(HERE/'protocol.json'),'manifest_sha256':sha(HERE/'manifest.json'),'payload_files':len(files),'protected_inputs':len(protected),'tools':len(tools),'numerical_executed':False}))
