# Untimed scheduler comparison: source-only proposal

The eight dependent compilers completed once under the root's compile-only grant.
This separate packet has not launched a probe, numerical kernel, test or timing.
A separate reviewed runtime grant is required before invoking `run.py`.

Each executable links one matching Symbolica→OneLoop→masters→core chain. The
completed build receipt and both exact probe hashes, all archive/map hashes,
source/extern/native/tool closure, prior15-test capsule and retained failures
are bound in the runtime protocol. The actual schedulers are uninstrumented;
identical read-only master capture hooks are enabled in both core snapshots.

Proposed runtime: two independent owned processes, each executing an exact fresh
read-only copy of its reviewed probe, pinned to CPU32. One 240-second aggregate
ceiling includes20 seconds reserved for cleanup/post-run guards. Both sessions
must terminate normally with no remaining owned group. The retained lifecycle
helper is byte-identical; the retained interactive helper changes only CPU22 to
CPU32. Compiler/profile/source changes and retries are outside this proposal.

The60-request schedule has30 responses per process: the eight frozen
N2/N3rank0/1batch1/32 families with initial, own-repeat and retained evaluations;
complete controls and their own repeat; four requests that must reject timing or
backend selection fields. All numerical timing counts are zero, and profiling
is disabled. Recorded wall time is only a lifecycle diagnostic and never a
kernel performance measurement.

Cross-archive comparisons require exact complete JSON records, including exact
represented rational values, every precision and sign field, master inputs and
six outputs, every tensor moment and four native Laurent slots, each requested
Taylor component, errors, diagnostics, fallback flags and operation/request
counters. Own repeats additionally ignore only `plan_reused`, which describes
workspace initialization and is intentionally different on the first request.
The Rust probe also asserts exact own repeats before adding that metadata.

Admission checks completeness and expected masks independently of cross equality.
Every successful output must be finite and represented by an exact binary
rational. Failed lanes must retain their expected explicit error with null
outputs. Nativef64 moment slots are checked bit-for-bit against their represented
rational/sign fields. DoubleFloat and Float values are checked through rational
metadata without f64 conversions. Core master group/order/request/lane counts and
all execution counts are fixed. The unchanged existing inputs cover failing
neighbors, scaleless poles, complex branches, empty/singleton/odd/reused master
batches, first-order DualA0/B0/C0, DB0/D0, DoubleFloat beyond53 bits and increasing
and mixed64/128/256-bit FloatA0 inputs. This does not add new shape or topology
coverage; higher/mixed Dual local scheduler controls remain in the15-test packet.

`control-shapes.json` is a projection of retained validated fixture records that
copies only exact INPUT metadata, labels, row/component/shape counts and expected
errors. It contains no integral/master result values. It cannot supply passing
new scheduler values. Its extraction source/hash is retained. Existing native
policy numerical outputs are never substituted into this comparison.

The runtime runner hashes source/build bindings before and after execution;
checks protocol, build receipt and frozen executable hashes around each request;
retains every raw request and response plus complete stdout/stderr; and persists
terminal/cleanup evidence before final hashes. Any missing/extra record, failure,
precision/sign/output mismatch, timeout, changed guard, cancellation or cleanup
error rejects the stage without retry. A producer pass awaits independent saved
data review of every request/result, source/build/run/archive binding, expected
mask and complete exact comparison. This packet makes no numerical, performance,
full-domain, production adoption or live-application claim.
