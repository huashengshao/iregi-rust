"""Narrow source-schema correction requested by peer and authorized by ROOT."""
from pathlib import Path
import difflib
HERE=Path('/shared/external/iregi/iregi-rust/target/guard-performance-review/dependent-runtime-proposal')
p=HERE/'admission.py';old=p.read_text();text=old
def replace(a,b,n=1):
 global text
 assert text.count(a)==n,(a,text.count(a),n)
 text=text.replace(a,b)
replace('def number(v,allow_nonfinite=False):\n assert type(v)is dict and set(v)in[{\'rational\',\'precision\',\'negative_sign\'},{\'rational\',\'precision\',\'negative_sign\',\'finite\'}]', '''def number(v,allow_nonfinite=False,*,finite_field=True,domain=None):
 fields={'rational','precision','negative_sign'}|({'finite'}if finite_field else set())
 assert type(v)is dict and set(v)==fields''')
replace(" bits=integer(v['precision']);assert 0<bits<2**32 and type(v['negative_sign'])is bool", " bits=integer(v['precision']);assert 0<bits<2**32 and type(v['negative_sign'])is bool\n if domain in('f64','DoubleFloat'):assert bits=={'f64':53,'DoubleFloat':106}[domain]\n else:assert domain in(None,'Float')")
a=text.index('def complex_value(');b=text.index('def snapshot(',a)
text=text[:a]+'''def complex_value(v,allow_nonfinite=False,*,finite_field=True,domain=None):
 return tuple(number(x,allow_nonfinite,finite_field=finite_field,domain=domain)for x in array(v,2))
def numeric_domain(label):
 return 'DoubleFloat'if label.startswith('DoubleFloat')else'Float'if label.startswith('Float')else'f64'
'''+text[b:]
replace('def snapshot(v,spec):','def snapshot(v,spec,domain=\'f64\'):')
replace("for z in array(lane['six_outputs'],6*spec['components']):complex_value(z)","for z in array(lane['six_outputs'],6*spec['components']):complex_value(z,finite_field=False,domain=domain)")
replace('def captures(v,n,rank,rows,components):',"def captures(v,n,rank,rows,components,domain='f64'):")
replace("assert g['requests']==[[leaf,lane]for leaf in leaves for lane in range(rows)]","assert exact(g['requests'],[[leaf,lane]for leaf in leaves for lane in range(rows)])")
replace("assert g['valid_lanes']==list(range(rows))and g['output_order']==ORDER","assert exact(g['valid_lanes'],list(range(rows)))and exact(g['output_order'],ORDER)")
replace("for z in array(g['input'],ARITY[family]*count*components):complex_value(z)","for z in array(g['input'],ARITY[family]*count*components):complex_value(z,domain=domain)")
replace("for z in array(lane,6*components):complex_value(z)","for z in array(lane,6*components):complex_value(z,domain=domain)")
replace('def moment_lane(lane,moments,components,has_native):',"def moment_lane(lane,moments,components,has_native,domain='f64'):")
replace('for z in values:complex_value(z)','for z in values:complex_value(z,domain=domain)')
replace('q=number(part);x=float(q)',"q=number(part,domain='f64');x=float(q)")
replace("r['degrees']==([0]if case['rank']==0 else[0,1,1,1,1])","exact(r['degrees'],[0]if case['rank']==0 else[0,1,1,1,1])")
replace("assert v['label']==spec['label']and v['components']==spec['components']and exact(v['input'],spec['input'])","assert v['label']==spec['label']and exact(v['input'],spec['input']);integer(v['components'],spec['components']);domain=numeric_domain(spec['label'])")
replace("for z in v['input']:complex_value(z)","for z in v['input']:complex_value(z,domain=domain)")
replace("r['fallback_used']==[False]and r['analytic_used']==[False]","exact(r['fallback_used'],[False])and exact(r['analytic_used'],[False])")
replace("for z in array(r['values'],spec['complex_output_count']):complex_value(z)","for z in array(r['values'],spec['complex_output_count']):complex_value(z,domain=domain)")
replace("captures(r['master_captures'],2,1,1,spec['components'])","captures(r['master_captures'],2,1,1,spec['components'],domain)")
replace("def selected(v,spec):\n assert v['family']", "def selected(v,spec):\n assert set(v)=={'family','status','layout_and_overflow_errors_checked','ordinary_dual_adapter_rejected','warm_clone_checked','cases'}\n assert v['family']")
replace("  assert case['label']==expected['label']and case['family']==spec['family']and case['status']=='passed'", "  assert set(case)=={'label','family','status','baseline_backend','candidate_backend','independent_generic_instances_exact','own_repeated_outputs_exact','input_metadata','input_unchanged','baseline','candidate'}\n  assert case['label']==expected['label']and case['family']==spec['family']and case['status']=='passed'")
replace("for z in array(case['input_metadata'],expected['rows']*ARITY[spec['family']]):complex_value(z,True)","for z in array(case['input_metadata'],expected['rows']*ARITY[spec['family']]):complex_value(z,True,domain='f64')")
replace("def unchanged(v,spec):\n assert v['label']==spec['label']and v['family']==spec['family']and v['shape']==spec['shape']and v['components']==spec['components']", "def unchanged(v,spec):\n assert set(v)=={'label','family','status','backend','shape','components','cases'}\n assert v['label']==spec['label']and v['family']==spec['family']and exact(v['shape'],spec['shape']);integer(v['components'],spec['components']);domain=numeric_domain(spec['label'])")
replace("  assert case['label']==expected['label']and case['status']=='passed'and case['input_unchanged']is True", "  assert set(case)=={'label','status','represented_outputs','baseline','candidate','candidate_exactly_matches_baseline','own_repeated_outputs_exact','input_metadata','input_unchanged'}\n  assert case['label']==expected['label']and case['status']=='passed'and case['input_unchanged']is True")
replace("for z in array(case['input_metadata'],expected['rows']*ARITY[spec['family']]*spec['components']):complex_value(z,True)","for z in array(case['input_metadata'],expected['rows']*ARITY[spec['family']]*spec['components']):complex_value(z,True,domain=domain)")
replace("total+=snapshot(case['represented_outputs'],expected)","total+=snapshot(case['represented_outputs'],expected,domain)")
replace("snapshot(case[field],expected);assert exact", "snapshot(case[field],expected,domain);assert exact")
replace(' recursive_numbers(v);whole=[]',' whole=[]')
replace(" masters=v['masters'];assert masters['status']=='passed'", " masters=v['masters'];assert set(masters)=={'status','scope','comparison','unchanged_comparison','failed_lane_output_policy','selected_families','unchanged_paths','extended_unchanged_paths','extended_inventory'}\n assert masters['unchanged_comparison']=='exact represented rational, component precision and sign; explicit expected errors'\n assert masters['status']=='passed'")
replace(" cache=v['cache_interleaving'];assert cache['status']=='passed'", " cache=v['cache_interleaving'];assert set(cache)=={'status','same_immutable_plan','expected_current_process_records','steps'}\n assert cache['status']=='passed'")
replace("  assert step['workspace_case']==index and step['backend']=='SymbolicaBatch'and step['dual']==spec['cache_shapes'][index]", "  assert set(step)=={'workspace_case','backend','dual','result'};integer(step['workspace_case'],index)\n  assert step['backend']=='SymbolicaBatch'and step['dual']is spec['cache_shapes'][index]")
compile(text,str(p),'exec');p.write_text(text)
(HERE/'admission-schema-hardening.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='draft-001/admission.py',tofile='admission.py')))
print('Four-category source metadata/schema hardening only; no import/test/probe execution')
