# Preserved source-only documentation refresh

The first preflight (protocol `24a99d65`) observed a concurrent five-line
SixPoint module-documentation update and correctly rejected the stale live
binding. No compiler was launched. `draft-001/` preserves the original protocol,
inventory, old private file and failed preflight. Root authorized refreshing only
that common private documentation file; `refresh_sixpoint_docs.py` verifies exact
old/new hashes and identical bytes after removing Rust doc-comment lines. The
complete eight command/environment/feature/output/cap entries remain identical.
The refreshed protocol is `2e9732b1`; all 1093 protected inputs and three tools
pass source-only preflight. Both source review receipts remain historical and
must be read with their stated scope; the old guard-blocked review is retained.
