"""Freeze eight proposed compiler commands; importing/running launches none."""
from pathlib import Path
import datetime,hashlib,json,shutil
ROOT=Path('/shared/external/iregi/iregi-rust');HERE=ROOT/'target/guard-performance-review/dependent-chain-proposal'
PRIOR=ROOT/'target/guard-performance-review/dependent-relink-qualification'
assert Path.cwd()==ROOT and not (HERE/'protocol.json').exists()
def sha(p):
    with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def read(p):return json.loads(p.read_text())
prior=read(PRIOR/'protocol.json');assert sha(PRIOR/'protocol.json')=='3324807578af3d6d04f8ef552d54469d786ccb78222ea6492a8c7144a5ebf99d'
receipt=PRIOR/'symbolica-build-001/build.json';built=read(receipt)
assert sha(receipt)=='bff644a54ce86a749f866236247e38e85fd53ebe7e74470ae8749222e232dcbd'
assert built['success']and built['status']=='passed'and built['guard_before']and built['guard_after']and not built['cleanup_errors']
protected=dict(prior['protected_sha256']);tools=dict(prior['tool_sha256'])
for raw,expected in {**protected,**tools}.items():assert sha(Path(raw)if Path(raw).is_absolute()else ROOT/raw)==expected,raw
for path in [PRIOR/'protocol.json',PRIOR/'manifest.json',receipt]+list((PRIOR/'symbolica-build-001').glob('*.log')):
    protected[str(path.relative_to(ROOT))]=sha(path)
for item in built['outputs'].values():
    p=Path(item['path']);assert sha(p)==item['sha256']and p.stat().st_size==item['bytes'];protected[str(p.relative_to(ROOT))]=sha(p)
inventory=read(HERE/'source-inventory.json')
for raw,expected in inventory['live_source_sha256'].items():assert sha(ROOT/raw)==expected;protected[raw]=expected
for raw,item in inventory['origins'].items():
    original=ROOT/item['path'];assert sha(original)==item['sha256'];protected[item['path']]=item['sha256']
# Pin actual live workspace/fingerprints used for package/features/dependency provenance.
for raw in ['Cargo.toml','Cargo.lock','target/cargo-build/debug/.fingerprint/oneloop-ad2b1eccf125afee/lib-oneloop.json','target/native-f64-opt-in/qualification/observation-command-plan.json']:
    protected[raw]=sha(ROOT/raw)
closure=ROOT/'validation/core-fused-cse-census/dependency-closure.json';protected[str(closure.relative_to(ROOT))]=sha(closure)
for item in read(closure)['files']:
    p=ROOT/item['frozen'];assert sha(p)==item['sha256'];protected[str(p.relative_to(ROOT))]=item['sha256']
for raw in ['target/core-fused-cse-census/supplemental-deps/libthiserror-0527e2191ec3561c.rlib','target/core-fused-cse-census/supplemental-deps/libthiserror_impl-415c566ab8174dc4.so']:
    protected[raw]=sha(ROOT/raw)
shutil.copyfile(PRIOR/'lifecycle.py',HERE/'lifecycle.py');assert sha(HERE/'lifecycle.py')=='c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824'
# Reuse the exact flags/features/native closure of the two passed Symbolica rlibs.
symcmd=prior['steps'][0]['command'];taskset=symcmd[0];rustc=symcmd[3]
common=[taskset,'-c','32,33',rustc,'--edition=2024']
for setting in ['opt-level=0','debuginfo=0','strip=debuginfo','lto=off','codegen-units=8','debug-assertions=yes','overflow-checks=yes','linker=/nix/store/788mx070y81zjlg5ipcl0cra3afviw9k-gcc-wrapper-15.2.0/bin/cc']:
    assert setting in symcmd;common+=['-C',setting]
deps=ROOT/'target/e6-direct-n2/deps';supplemental=ROOT/'target/core-fused-cse-census/supplemental-deps';native=ROOT/'target/e6-direct-n2/native'
externs={v.split('=',1)[0]:v.split('=',1)[1]for i,v in enumerate(symcmd)if i and symcmd[i-1]=='--extern'}
serde=externs['serde'];serde_json=str(deps/'libserde_json-d657c5438f354a41.rlib');thiserror=str(supplemental/'libthiserror-0527e2191ec3561c.rlib')
assert sha(Path(serde_json))==protected[str(Path(serde_json).relative_to(ROOT))]
steps=[]
for variant in ['baseline','candidate']:
    out=HERE/'chain-build-001'/variant;sym=Path(built['outputs'][variant]['path'])
    products={'symbolica':str(sym),'oneloop':str(out/'liboneloop.rlib'),'iregi_masters':str(out/'libiregi_masters.rlib'),'iregi_rust':str(out/'libiregi_rust.rlib')}
    specs=[('oneloop','oneloop',HERE/'source/dependencies/oneloopmaster',{'symbolica':str(sym),'bincode':externs['bincode'],'symjit':externs['symjit']},['default','generated-evaluators','prebuilt','rust-codegen']),
        ('masters','iregi_masters',HERE/'source/crates/iregi-masters',{'symbolica':str(sym),'oneloop':products['oneloop']},['default']),
        ('core','iregi_rust',HERE/'source/crates/iregi-rust',{'symbolica':str(sym),'iregi_masters':products['iregi_masters'],'serde':serde,'thiserror':thiserror},[]),
        ('probe','tirust_scheduler_probe',HERE/'source/probe',{'iregi_rust':products['iregi_rust'],'iregi_masters':products['iregi_masters'],'symbolica':str(sym),'oneloop':products['oneloop'],'serde':serde,'serde_json':serde_json},[])]
    for product,crate,source,ext,features in specs:
        output=out/('probe'if product=='probe'else'lib'+crate+'.rlib')
        command=list(common)+['--crate-name',crate,'--crate-type','bin'if product=='probe'else'rlib','-C','metadata=tirust_uniform_'+variant+'_'+product+'_001']
        # Fresh matching chain precedes the frozen closure. No opposite variant
        # directory is visible; explicit externs never use old kernel/OneLoop.
        for directory in [out,sym.parent,deps,supplemental]:command+=['-L','dependency='+str(directory)]
        command+=['-L','native='+str(native)]
        for feature in features:command+=['--cfg','feature="'+feature+'"']
        if product!='oneloop':command+=['--cfg','iregi_qualification_capture']
        command+=[str(source/('probe.rs'if product=='probe'else'src/lib.rs'))]
        for name,path in ext.items():command+=['--extern',name+'='+path]
        step={'label':variant+'-'+product,'variant':variant,'product':product,'command':command,'environment':{'CARGO_CRATE_NAME':crate,'CARGO_PKG_VERSION':'0.1.0','CARGO_MANIFEST_DIR':str(source)},'compiler_cap_seconds':180,'output':str(output),'explicit_externs':ext,'features':features}
        if product=='probe':
            link_map=out/'probe.link-map';command+=['-C','link-arg=-Wl,-Map='+str(link_map)]
            step.update(link_map=str(link_map),expected_link_archives=products)
        command+=['-o',str(output)];steps.append(step)
assert len(steps)==8
for step in steps:
    assert '--test'not in step['command']and'--emit'not in step['command']
    for name,path in step['explicit_externs'].items():
        if name in ['symbolica','oneloop','iregi_masters','iregi_rust']:
            assert '/target/e6-direct-n2/deps/'not in path
    assert not any('native-f64-abc'in arg or'native-batch'in arg for arg in step['command'])
for p in HERE.rglob('*'):
    if p.is_file()and p.name not in ['protocol.json','manifest.json']and'reviews'not in p.relative_to(HERE).parts:protected[str(p.relative_to(ROOT))]=sha(p)
protocol={'schema_version':1,'status':'PROPOSAL_ONLY_NO_BUILD_OR_RUNTIME_GRANT','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(ROOT),
    'scope':'Exactly eight sequential opt0 compiler invocations only, baseline then candidate OneLoop/masters/core/probe. Common generic-only sources and identical observation hooks; no Cargo/dependency build/probe execution/performance/live changes.',
    'aggregate_budget_seconds':900,'cleanup_postguard_reserve_seconds':20,'effective_work_deadline_seconds':880,'cpu_affinity':'32,33','steps':steps,'protected_sha256':protected,'tool_sha256':tools,
    'authoritative_symbolica_build':{'path':str(receipt.relative_to(ROOT)),'sha256':sha(receipt),'outputs':built['outputs']},
    'archive_binding_policy':'Each probe map must show exactly its own newly built Symbolica/OneLoop/masters/core archive paths; the opposite variant is absent from search paths. Map failure rejects qualification. Old closure archives stay historical, never explicit selected-chain externs.',
    'local15_qualification':'validation/uniform-branch-scheduler/qualification.json','local15_qualification_sha256':sha(ROOT/'validation/uniform-branch-scheduler/qualification.json'),'original_failed_compile_attempts_preserved':['001','002'],
    'input_inventory_reuse':'The existing four N2/N3 rank0/1 input sets at batch1/32; retained master input expressions/masks/types/shapes. No native-policy numerical outputs imported.',
    'runtime_proposal':'Separate future grant: fresh own copies of two probe binaries in independent processes; exact full represented outputs/precision/sign/complete tensor-Laurent-Taylor/status/diagnostic/fallback/master records and own repeats. No run is granted by this protocol.',
    'failure_policy':'Stop on first failed compiler, guard, map binding, timeout, cancellation or cleanup; preserve partial terminal receipts/logs/output bytes; no retry or extension.',
    'numerical_qualified':False,'performance_qualified':False,'production_adoption_authorized':False}
save(HERE/'protocol.json',protocol)
print(json.dumps({'protocol_sha256':sha(HERE/'protocol.json'),'compiler_invocations':len(steps),'protected_inputs':len(protected),'tools':len(tools),'no_compiler_executed':True}))
