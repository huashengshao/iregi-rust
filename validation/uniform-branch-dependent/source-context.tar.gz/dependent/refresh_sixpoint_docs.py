"""Record the authorized single documentation-only refresh; launches no build."""
from pathlib import Path
import difflib,hashlib,json,shutil
ROOT=Path('/shared/external/iregi/iregi-rust');HERE=ROOT/'target/guard-performance-review/dependent-chain-proposal'
assert Path.cwd()==ROOT
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
private=HERE/'source/crates/iregi-rust/src/six_point.rs';live=ROOT/'crates/iregi-rust/src/six_point.rs'
assert sha(private)=='ea256a4e5540366e2db10c12bb898718289f8269dd57b6956a0b11960dbe4cf8'
assert sha(live)=='8e4341a868ff5fe50310c930d38c730fd59a96c01132495ff22054c8aaf7f72f'
old=private.read_text();new=live.read_text()
strip=lambda s:''.join(line for line in s.splitlines(True)if not line.lstrip().startswith(('//!','///')))
assert strip(old)==strip(new),'Non-documentation source change forbidden'
draft=HERE/'draft-001';draft.mkdir(exist_ok=False)
for name in ['protocol.json','source-inventory.json','preflight-001-live-drift.json']:
 shutil.copyfile(HERE/name,draft/name)
shutil.copyfile(private,draft/'six_point.rs')
(HERE/'six-point-doc-only-refresh.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='draft-001/six_point.rs',tofile='source/crates/iregi-rust/src/six_point.rs')))
shutil.copyfile(live,private)
inv=json.loads((HERE/'source-inventory.json').read_text())
inv['live_source_sha256']['crates/iregi-rust/src/six_point.rs']=sha(live)
inv['origins']['source/crates/iregi-rust/src/six_point.rs']['sha256']=sha(live)
inv['private_source_sha256']['source/crates/iregi-rust/src/six_point.rs']=sha(private)
inv['authorized_refresh']={'path':'crates/iregi-rust/src/six_point.rs','change':'module documentation only; bytes after removing Rust doc-comment lines are identical','old_sha256':sha(draft/'six_point.rs'),'new_sha256':sha(private),'initial_protocol_sha256':sha(draft/'protocol.json'),'initial_preflight_sha256':sha(draft/'preflight-001-live-drift.json'),'all_other_private_source_unchanged':True}
save(HERE/'source-inventory.json',inv)
(HERE/'protocol.json').unlink()
print(json.dumps(inv['authorized_refresh']))
