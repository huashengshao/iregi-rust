"""Frozen dependent compiler stage only; no probe or test execution."""
from pathlib import Path
import hashlib,json,os,re,sys
sys.dont_write_bytecode=True
from lifecycle import Budget,execute
ROOT=Path('/shared/external/iregi/iregi-rust')
HERE=ROOT/'target/guard-performance-review/dependent-chain-proposal'
def sha(path):
    with Path(path).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def linked_archives(path,crate):
    # GNU-style and LLVM-style map entries expose archive paths followed by
    # whitespace or an opening member parenthesis. Repeated member rows collapse.
    text=path.read_text()
    return sorted(set(re.findall(r'(/[^\s()]*?/lib'+re.escape(crate)+r'(?:-[A-Za-z0-9_]+)?\.rlib)',text)))
def main():
    assert Path.cwd()==ROOT and len(sys.argv)==2
    reviewed=sys.argv[1];protocol_path=HERE/'protocol.json'
    assert sha(protocol_path)==reviewed
    protocol=json.loads(protocol_path.read_text())
    attempt=HERE/'chain-build-001';attempt.mkdir(exist_ok=False)
    budget=Budget(protocol['aggregate_budget_seconds'])
    budget.work_deadline=budget.deadline-protocol['cleanup_postguard_reserve_seconds']
    record={'status':'preparing','success':False,'protocol_sha256':reviewed,'runner_sha256':sha(Path(__file__)),
        'aggregate_budget_seconds':protocol['aggregate_budget_seconds'],'cleanup_postguard_reserve_seconds':protocol['cleanup_postguard_reserve_seconds'],
        'steps':[dict(step,status='unrun')for step in protocol['steps']], 'outputs':{},'cleanup_errors':[],
        'scope':protocol['scope'],'numerical_execution':False,'performance_measurement':False}
    receipt=attempt/'build.json';save(receipt,record);outputs={}
    def verify():
        assert sha(protocol_path)==reviewed,'Protocol changed during stage'
        for raw,expected in {**protocol['protected_sha256'],**protocol['tool_sha256']}.items():
            budget.remaining();p=Path(raw)if Path(raw).is_absolute()else ROOT/raw
            assert sha(p)==expected,'Input changed: '+raw
        for p,expected in outputs.items():
            budget.remaining();assert sha(p)==expected,'Output changed: '+str(p)
    budget.arm()
    try:
        assert not os.environ.get('RUSTC_BOOTSTRAP')
        verify();record['guard_before']=True
        for step in record['steps']:
            budget.remaining();output=Path(step['output']);output.parent.mkdir(exist_ok=True)
            env=dict(os.environ);env.update(step['environment'])
            def persist(result):step.update(result);save(receipt,record)
            log=attempt/(step['label']+'.log')
            result=execute(step['command'],log,budget,step['compiler_cap_seconds'],record['cleanup_errors'],persist,env)
            assert result['status']=='exited','Compiler failed/timed out: stop, no retry or extension'
            verify()
            with output.open('rb')as f:header=f.read(8)
            assert header==(b'!<arch>\n' if step['product']!='probe'else b'\x7fELF\x02\x01\x01\x00'),'Wrong expected artifact format'
            fingerprint=sha(output);outputs[output]=fingerprint
            item={'path':str(output),'sha256':fingerprint,'bytes':output.stat().st_size}
            if step['product']=='probe':
                link_map=Path(step['link_map']);assert link_map.is_file()
                item['archive_binding']={}
                for crate,expected in step['expected_link_archives'].items():
                    actual=linked_archives(link_map,crate)
                    assert actual==[expected],f'{crate} map binding differs: {actual}'
                    item['archive_binding'][crate]={'paths':actual,'expected_sha256':sha(Path(expected))}
                # A map-based archive identity observation is required; executable
                # running and Symbolica kernel initialization are not performed here.
                item['link_map']={'path':str(link_map),'sha256':sha(link_map),'bytes':link_map.stat().st_size}
                outputs[link_map]=item['link_map']['sha256']
                item['one_symbolica_archive_linked']=True
            record['outputs'][step['label']]=item
            step.update(log_sha256=sha(log),output_sha256=fingerprint,status='passed')
            save(receipt,record)
        record['status']='completed-awaiting-final-guards'
    except Exception as error:record.update(status='failed',error=repr(error))
    save(receipt,record)
    try:verify();record['guard_after']=True
    except Exception as error:record.update(guard_after=False,guard_error=repr(error))
    record['elapsed_seconds_diagnostic']=budget.elapsed()
    record['deadline_exceeded']=record['elapsed_seconds_diagnostic']>protocol['aggregate_budget_seconds']
    if budget.cancelled:record['cancellation']=budget.cancelled
    record['success']=all(s['status']=='passed'for s in record['steps'])and record['guard_after']and not record['cleanup_errors']and not record['deadline_exceeded']and not budget.cancelled and'error'not in record
    record['status']='passed'if record['success']else'failed';save(receipt,record);budget.disarm()
    print(json.dumps({'status':record['status'],'receipt_sha256':sha(receipt),'outputs':record['outputs'],'elapsed_seconds_diagnostic':record['elapsed_seconds_diagnostic']}))
    return 0 if record['success']else 1
if __name__=='__main__':raise SystemExit(main())
