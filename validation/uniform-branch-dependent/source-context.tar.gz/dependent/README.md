# Generic scheduler dependent qualification: source-only proposal

No compiler, kernel, test, or timing has been run by this packet. The separately
reviewed `dependent-relink-qualification/symbolica-build-001/build.json` is the
authoritative completed two-Symbolica-archive stage; its hashes are bound here.
The actual original and candidate schedulers remain uninstrumented. Their sole
production difference is the reviewed uniform-branch jump patch.

The eight exact proposed commands are `protocol.json` → `steps`: baseline
OneLoop, masters, core, probe, then candidate OneLoop, masters, core, probe. Each
has a 180-second child ceiling, CPU 32,33, and the same opt0/debug/no-LTO/codegen8
flags as the completed two archives. The proposed aggregate ceiling is 900
seconds, including 20 seconds reserved for owned cleanup and final guards. The
runner reuses the byte-identical reviewed lifecycle helper. A failed compiler,
input/output guard, archive-map check, timeout, cancellation, or cleanup ends the
stage; there is no retry or extension. A separate root grant and reviewed final
protocol digest are required before invoking `build.py`.

Both chains compile the same private common source. OneLoop preserves its exact
package/namespace name and all four original features. The two small TIRust
crates keep the generic Symbolica master backend; neither optional native master
feature is enabled. OneLoop, masters and core must all be rebuilt because the
old archives carry the original Symbolica crate identity. Every new dependent
uses explicit matching extern paths and distinct metadata. No Cargo, dependency
build, Python, FeynKit, prepare-crate, CLI, or application source changes occur.

The matching fresh dependency directory and Symbolica directory are the only
variant directories searched. Each probe compiler also emits a linker map in the
same invocation. The build receipt requires exactly that variant's four archive
paths (Symbolica, OneLoop, masters, core) in the map and records their hashes.
Opposite-variant directories are absent. The frozen old dependency closure still
exists as a historical search closure, but old kernel/OneLoop/masters/core
archives are never explicit externs and a stale archive appearing in the map
rejects this qualification. This is an archive-link identity check; no probe or
Symbolica kernel initialization happens during the build stage.

`observation-only.patch` contains only a read-only six-master-output accessor,
a cfg capture export and a cfg observation call after ordinary evaluation. The
capture module is byte-identical to the existing reviewed observation module.
It obtains exact represented rationals, component precision, sign and finite
metadata through existing Symbolica/NativeFloat APIs. No algebra, numerical
formula, branch, guard, tolerance, or scalar-master policy is added or changed.
All other private crate files copy the current live generic source, including
its thin-N6 and SixPoint additions, byte for byte. This does not extend the
numerical fixture domain to those additions.

The probe adapts the already validated preparation and record source, retaining
its numerical expressions, expected masks, types, Taylor shapes, row sizes,
reuse order and repeats. `core_probe.rs.patch` and `master_controls.rs.patch`
show the complete adaptations. There is one generic instance per executable;
two same-backend master instances inside the master controls are only an
independent-instance/repeat check. Real cross-scheduler comparison must happen
between separate executable processes. Their represented outputs are required
to agree exactly, including precision and zero sign; no tolerance-only native
policy comparison survives in this adapter. Four previous interleaving context
positions remain four independent generic workspaces with the same ordered
primal/Dual shapes and index sequence.

The copied historical `frozen-control-inventory.json` retains old fixture/schema
and expected-mask provenance, including historical record bytes. It is not
compiled into the new probe and is not a numerical result oracle. The copied
`frozen-inputs.json` supplies the same four bubble/triangle rank-zero/rank-one
input sets for batch 1 and 32. No old native-policy output is substituted for a
new scheduler output. Static/dynamic higher and mixed Dual local scheduler
fixtures remain in the previous 15-test qualification; this narrow dependent
cohort does not claim to add new complete-reduction shape coverage.

A later, separately reviewed runtime protocol must freeze both executable
copies and their build receipt, run identical request/reuse/control sequences
in independent processes, preserve every raw response, and compare complete
records. All requested tensor moments and four native Laurent slots, every
requested Taylor component, exact master inputs and all six outputs, failures,
diagnostics, fallback flags, precision/sign/finite metadata, execution counters,
and own repeats must be checked. Failed lanes remain null with their explicit
expected error. Profiling and all timing counts are disabled. This packet grants
none of that execution, and it makes no full-reduction, performance, production
application, or adoption claim.
