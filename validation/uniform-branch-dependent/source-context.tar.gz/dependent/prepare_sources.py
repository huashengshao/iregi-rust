"""Private source-only adapter; no compiler, kernel, test or timing is launched."""
from pathlib import Path
import difflib, hashlib, json, shutil
ROOT=Path('/shared/external/iregi/iregi-rust')
HERE=ROOT/'target/guard-performance-review/dependent-chain-proposal'
OLD=ROOT/'target/native-f64-opt-in/qualification/source'
assert Path.cwd()==ROOT
assert not (HERE/'source').exists(), 'Preserve prior preparations'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def replace(text,a,b,n=1):
    assert text.count(a)==n,(a,text.count(a),n)
    return text.replace(a,b)
source=HERE/'source';source.mkdir()
origins={};live={}
for raw in ['dependencies/oneloopmaster','crates/iregi-masters','crates/iregi-rust']:
    root=ROOT/raw;target=source/raw
    files=list((root/'src').rglob('*.rs'))+[root/'Cargo.toml']
    if raw.startswith('dependencies/'):
        files+=list((root/'assets').rglob('*'))+list((root/'tests/data').rglob('*'))
        files += [p for p in root.iterdir() if p.is_file() and p.name not in ['Cargo.toml','Cargo.lock']]
    for p in sorted(set(p for p in files if p.is_file())):
        q=target/p.relative_to(root);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
        live[str(p.relative_to(ROOT))]=sha(p);origins[str(q.relative_to(HERE))]={'path':str(p.relative_to(ROOT)),'sha256':sha(p)}
# Exactly three observation-only insertions plus one previously reviewed capture module.
p=source/'crates/iregi-masters/src/lib.rs';text=p.read_text()
text=replace(text,'impl<T: FloatLike> MasterBatch<T> {\n','impl<T: FloatLike> MasterBatch<T> {\n    /// Qualification-only observation of all outputs; no mutation or conversion.\n    #[cfg(iregi_qualification_capture)]\n    pub fn private_six_values(&self) -> &[Complex<T>] {\n        &self.values\n    }\n\n');p.write_text(text)
p=source/'crates/iregi-rust/src/lib.rs';p.write_text(p.read_text()+'''\n#[cfg(iregi_qualification_capture)]
mod master_capture;
#[cfg(iregi_qualification_capture)]
pub use master_capture::{set_master_capture, take_master_captures};
#[cfg(iregi_qualification_capture)]
pub const QUALIFICATION_CAPTURE_ENABLED: bool = true;
''')
p=source/'crates/iregi-rust/src/execution.rs';text=p.read_text();a='''                ScalarMasterEvaluator::OneLoop(evaluator) => {
                    let evaluated = evaluator.evaluate_batch(&group.input, rows);
''';b=a+'''                    #[cfg(iregi_qualification_capture)]
                    if crate::master_capture::enabled() {
                        crate::master_capture::record(family.name(), evaluator.backend(), self.components, &group.input, &group.requests, &self.valid_lanes, &evaluated);
                    }
''';p.write_text(replace(text,a,b))
p=source/'crates/iregi-rust/src/master_capture.rs';original=OLD/'observation-overlay/crates/iregi-rust/src/master_capture.rs';shutil.copyfile(original,p);origins[str(p.relative_to(HERE))]={'path':str(original.relative_to(ROOT)),'sha256':sha(original)}
# Retain fixture expressions, expected masks and exact output serializers; only remove
# the unrelated optional master-policy switch from the already-qualified harness.
probe=source/'probe';probe.mkdir()
text=(OLD/'core_probe.rs').read_text()
text=replace(text,'// Included twice against one core crate; only the public POLICY value differs.','// One generic Symbolica-only module per separately linked scheduler archive.')
text=replace(text,', MasterExecutionPolicy','')
a=text.index('fn check_backends<');b=text.index('\nfn observe<',a)
text=text[:a]+'''fn check_backends(captures: &Value) {
    let captures=captures.as_array().expect("capture array");
    assert!(!captures.is_empty(),"qualification fixture produced no observed masters");
    for capture in captures { assert_eq!(capture["backend"],json!("SymbolicaBatch")); }
}
'''+text[b:]
text=replace(text,'moments: usize, policy: MasterExecutionPolicy, dual: bool','moments: usize, dual: bool')
text=replace(text,'    assert_eq!(workspace.master_execution_policy(),policy);\n','')
text=replace(text,'check_backends::<T>(&captures,policy,dual);','check_backends(&captures);')
text=replace(text,'Workspace::new_with_master_policy(plan,0.,POLICY)','Workspace::new(plan,0.)')
text=replace(text,',POLICY,false',',false',2)
text=replace(text,'"requested_master_policy":format!("{POLICY:?}"),"scope":"untimed public-policy whole-reduction qualification"','"requested_master_backend":"SymbolicaBatch","scope":"untimed generic-only scheduler whole-reduction qualification"')
text=replace(text,', dual: bool, policy: MasterExecutionPolicy',', dual: bool')
text=replace(text,'Workspace::new_dual_with_master_policy(plan,prototype,HyperDual::<f64>::new(vec![vec![0],vec![1]]),policy)','Workspace::new_dual(plan,prototype,HyperDual::<f64>::new(vec![vec![0],vec![1]]))')
text=replace(text,'Workspace::new_with_master_policy(plan,prototype,policy)','Workspace::new(plan,prototype)')
text=replace(text,',dual,POLICY',',dual')
text=replace(text,',POLICY,dual',',dual',2)
a=text.index('pub fn cache_interleaving()');text=text[:a]+'''pub fn cache_interleaving() -> Value {
    let plan=control_plan();
    // Preserve the four original context positions and exact interleaving order.
    // All use the generic backend; paired positions have independent workspaces.
    let shapes=[false,true,false,true];
    let mut expected=Vec::new();
    for dual in shapes {
        let batch=control_batch(&0f64,dual,false);
        let mut workspace=control_workspace(&plan,0f64,dual);
        let record=observe(&mut workspace,&batch,plan.basis().len(),dual).unwrap();
        assert!(record["stable"].as_bool().unwrap());expected.push(record);
    }
    let mut steps=Vec::new();
    for index in [2usize,1,0,3,2,0,3,1] {
        let dual=shapes[index];
        let batch=control_batch(&0f64,dual,false);
        let mut workspace=control_workspace(&plan,0f64,dual);
        let record=observe(&mut workspace,&batch,plan.basis().len(),dual).unwrap();
        assert_eq!(record,expected[index],"workspace/shape cache interleaving changed complete record");
        steps.push(json!({"workspace_case":index,"backend":"SymbolicaBatch","dual":dual,"result":record}));
    }
    json!({"status":"passed","same_immutable_plan":true,"expected_current_process_records":expected,"steps":steps})
}
'''
assert 'POLICY' not in text and 'MasterExecutionPolicy' not in text
(probe/'core_probe.rs').write_text(text)
text=(OLD/'master_controls.rs').read_text()
text=replace(text,'//! Bounded, untimed controls for the public master execution policies.','//! Bounded generic-only controls; cross-archive equality is checked by the external driver.')
text=replace(text,'MasterEvaluator, MasterExecutionPolicy, NativeFloat','MasterEvaluator, NativeFloat')
for a,b,n in [('.instantiate_with_policy(prototype.clone(),MasterExecutionPolicy::Symbolica)','.instantiate(prototype.clone())',1),('.instantiate_with_policy(prototype,MasterExecutionPolicy::NativeF64Abc)','.instantiate(prototype)',1),('.instantiate_with_policy(0_f64,MasterExecutionPolicy::Symbolica)','.instantiate(0_f64)',1),('.instantiate_with_policy(0_f64,MasterExecutionPolicy::NativeF64Abc)','.instantiate(0_f64)',2),('.instantiate_with_policy(zero,MasterExecutionPolicy::NativeF64Abc)','.instantiate(zero)',1),('.instantiate_with_policy(Float::new(53),MasterExecutionPolicy::NativeF64Abc)','.instantiate(Float::new(53))',1),('.instantiate_with_policy(Float::new(prototype_bits),MasterExecutionPolicy::NativeF64Abc)','.instantiate(Float::new(prototype_bits))',1)]:text=replace(text,a,b,n)
text=replace(text,'assert_eq!(candidate.backend(), MasterBackend::RustBatch);','assert_eq!(candidate.backend(), MasterBackend::SymbolicaBatch);')
text=replace(text,'assert_eq!(cloned.backend(),MasterBackend::RustBatch);','assert_eq!(cloned.backend(),MasterBackend::SymbolicaBatch);')
a=text.index('    let mut maximum=0_f64;');b=text.index('        if label=="scaleless" {',a)
text=text[:a]+'''    // These are two independent generic instances in this process, not the
    // cross-archive comparison. Preserve every represented value and metadata.
    assert_eq!(av,bv,"independent generic master instances differ: {label}");
    for lane in 0..expected.len() {
        if expected[lane].is_some() { continue; }
        for batch in [&a,&b] {
            let discriminant=&batch.private_six_values()[lane*6+5];
            assert_eq!((discriminant.re,discriminant.im),(0.,0.));
        }
'''+text[b:]
text=replace(text,"// Two repeated public calls check each backend's own value, precision and zero sign.","// Two repeated calls check each instance's own value, precision and zero sign.")
text=replace(text,'"candidate_backend":"RustBatch","maximum_normalized_error":maximum,\n        "represented_component_differences":differences,"signed_zero_differences":signed_zero_differences,','"candidate_backend":"SymbolicaBatch","independent_generic_instances_exact":true,')
text=replace(text,'// A binary64-precision Float is still a distinct numeric type and must not select native.','// Retain the distinct binary64-precision Float numeric-type control.')
text=replace(text,'"scope":"untimed public-policy selected f64 master adapter controls; no performance claim",\n        "comparison":"all six successful outputs; dimensional abs(delta)/(unit+abs(Symbolica)) <= 1e-10",','"scope":"untimed generic-only master adapter controls; no performance claim",\n        "comparison":"exact represented rational, precision and sign of all six successful outputs; external cross-archive comparison required",')
assert 'MasterExecutionPolicy' not in text and 'RustBatch' not in text
(probe/'master_controls.rs').write_text(text)
for name in ['core_probe.rs','master_controls.rs']:
    original=OLD/name;new=probe/name
    (HERE/(name+'.patch')).write_text(''.join(difflib.unified_diff(original.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(original.relative_to(ROOT)),tofile=str(new.relative_to(ROOT)))))
    origins[str(new.relative_to(HERE))]={'path':str(original.relative_to(ROOT)),'sha256':sha(original),'adapted':True}
# Tiny transport wrapper; no timing/reference/native-policy execution modes.
(probe/'probe.rs').write_text('''//! One generic-only TIRust instance; scheduler variants run in separate processes.
#[cfg(not(iregi_qualification_capture))]
compile_error!("qualification requires the observation-only capture cfg");
use serde::Deserialize;
use serde_json::json;
use std::{collections::HashMap, io::{self, BufRead, Write}};
#[derive(Deserialize)]
pub struct Sample { shifts: Vec<[f64;4]>, masses: Vec<[f64;2]>, mu: f64 }
#[derive(Deserialize)]
pub struct Request {
    id:String,n:usize,rank:u16,algorithm:String,samples:Vec<Sample>,
    #[serde(default)]engine:Option<String>,#[serde(default)]warmup:usize,
    #[serde(default)]repeats:usize,#[serde(default)]iterations:usize,
}
type PlanCache=HashMap<(usize,u16,String),iregi_rust::ReductionPlan>;
mod core {use iregi_rust as core_impl;include!("core_probe.rs");}
mod master_controls;
fn main() {
    assert!(iregi_rust::QUALIFICATION_CAPTURE_ENABLED);
    assert_eq!(iregi_masters::default_master_backend(),iregi_masters::MasterBackend::SymbolicaBatch);
    let mut prepared=None;let mut plans=PlanCache::new();
    let stdin=io::stdin();let mut out=io::stdout().lock();
    for line in stdin.lock().lines() {
        let line=line.unwrap();if line.trim()=="QUIT"{break;}if line.trim().is_empty(){continue;}
        let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            if line.trim()=="CONTROLS" {
                json!({"id":"controls","status":"passed","core":core::unchanged_controls(),
                    "extended_core":core::extended_unchanged_controls(),"masters":master_controls::run(),
                    "cache_interleaving":core::cache_interleaving(),"backend":"SymbolicaBatch"})
            } else {
                match serde_json::from_str::<Request>(&line) {
                    Ok(r) if r.engine.is_none()&&r.warmup==0&&r.repeats==0&&r.iterations==0 =>
                        json!({"id":r.id,"result":core::run(&r,&mut prepared,&mut plans).unwrap_or_else(|e|json!({"error":e}))}),
                    Ok(_)=>json!({"status":"invalid_request","error":"qualification is untimed; engine and timing counts are forbidden"}),
                    Err(e)=>json!({"status":"invalid_request","error":e.to_string()}),
                }
            }
        }));
        let result=result.unwrap_or_else(|_| {iregi_rust::set_master_capture(false);let _=iregi_rust::take_master_captures();
            json!({"status":"failed","error":"qualification assertion failed; see stderr"})});
        writeln!(out,"RESULT {result}").unwrap();out.flush().unwrap();
    }
}
''')
# Copy input bytes and inventory only; prior native-policy numerical outputs are not imported.
for raw in ['validation/native-master-replay/inputs.json','target/native-f64-opt-in/qualification/control-inventory.json']:
    p=ROOT/raw;q=HERE/('frozen-'+p.name);shutil.copyfile(p,q);origins[q.name]={'path':raw,'sha256':sha(p)}
# Diff scope and all original source/input guards remain separately inspectable.
patches=[]
for raw in ['crates/iregi-masters/src/lib.rs','crates/iregi-rust/src/lib.rs','crates/iregi-rust/src/execution.rs']:
    p=ROOT/raw;q=source/raw
    patches.extend(difflib.unified_diff(p.read_text().splitlines(True),q.read_text().splitlines(True),fromfile=raw,tofile='private/'+raw))
(HERE/'observation-only.patch').write_text(''.join(patches))
for raw,expected in live.items():assert sha(ROOT/raw)==expected,'Changed live source: '+raw
save(HERE/'source-inventory.json',{'scope':'source-only, one common generic-only source for both archive variants; no compiler or numeric execution','live_source_sha256':live,'origins':origins,'private_source_sha256':{str(p.relative_to(HERE)):sha(p) for p in source.rglob('*') if p.is_file()},'observation_changes':['iregi-masters/src/lib.rs read-only six-output accessor','iregi-rust/src/lib.rs cfg capture export','iregi-rust/src/execution.rs cfg observation call','byte-identical existing master_capture.rs'],'fixture_changes':'No numerical input, expected lane mask, Taylor shape, or numeric type added. Optional native master policy removed; four interleaving context positions retained as generic instances.','numerical_qualified':False,'performance_qualified':False,'production_adoption_authorized':False})
print(json.dumps({'private_source_files':sum(1 for p in source.rglob('*') if p.is_file()),'live_source_files':len(live),'no_compiler_executed':True}))
