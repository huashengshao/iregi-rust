use symbolica::{
    atom::{Atom, AtomCore, EvaluationInfo, Symbol},
    domains::{
        Ring,
        finite_field::{FiniteFieldCore, Zp},
        float::{Complex, ErrorPropagatingFloat, Float, FloatLike, RealLike},
        rational::Rational,
    },
    evaluate::{
        CompileOptions, CudaComplexf64, CudaLoadSettings, CudaRealf64, ExportSettings,
        ExpressionEvaluator, InlineASM, OptimizationSettings,
    },
    parse, symbol,
};

#[test]
#[ignore = "may stack overflow in debug build"]
fn create_evaluator_with_1000_variables() {
    const VARIABLE_COUNT: usize = 1000;

    let variable_names = (0..VARIABLE_COUNT)
        .map(|i| format!("x{i}"))
        .collect::<Vec<_>>();
    let expression =
        (parse!(&variable_names.join("+")) * parse!(&variable_names[..100].join("+"))).expand();

    println!(
        "{}",
        expression
            .evaluate(
                &variable_names
                    .iter()
                    .enumerate()
                    .map(|(i, x)| (parse!(x), i as f64))
                    .collect::<std::collections::HashMap<_, _>>()
            )
            .unwrap()
    );

    let params = variable_names.iter().map(|x| parse!(x)).collect::<Vec<_>>();

    let start = std::time::Instant::now();
    let evaluator = expression
        .evaluator(&params)
        .direct_translation(true)
        //.max_horner_scheme_variables(10)
        // .cpe_iterations(Some(0))
        //.max_common_pair_cache_entries(10)
        .horner_iterations(1)
        .verbose(true)
        .build()
        .unwrap();
    let elapsed = start.elapsed();

    eprintln!("created evaluator with {VARIABLE_COUNT} variables in {elapsed:?}");

    let mut evaluator = evaluator.map_coeff(&|x| x.re.to_f64());

    println!(
        "{}",
        evaluator.evaluate_single(&(0..VARIABLE_COUNT).map(|i| i as f64).collect::<Vec<_>>())
    )

    // assert_eq!(
    //     evaluator.evaluate_single(&vec![1.0; VARIABLE_COUNT]),
    //     VARIABLE_COUNT as f64
    // );
}

#[test]
fn common_pair_elimination_edits_the_same_instruction_multiple_times() {
    let expressions = [parse!("if(q,a+b+c+d,g)"), parse!("a+b+e"), parse!("c+d+f")];
    let params = [
        parse!("q"),
        parse!("a"),
        parse!("b"),
        parse!("c"),
        parse!("d"),
        parse!("e"),
        parse!("f"),
        parse!("g"),
    ];

    let evaluator = Atom::evaluator_multiple(&expressions, &params)
        .direct_translation(true)
        .horner_iterations(1)
        .max_horner_scheme_variables(0)
        .cpe_iterations(Some(1))
        .build()
        .unwrap();

    // Both (a, b) and (c, d) are extracted in one CPE pass. The first
    // expression is safely rewritten twice, reducing seven additions to five.
    assert_eq!(evaluator.count_operations().additions, 5);

    let mut evaluator = evaluator.map_coeff(&|x| x.re.to_f64());
    let mut output = [0.0; 3];
    evaluator.evaluate(&[1.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0], &mut output);
    assert_eq!(output, [10.0, 8.0, 13.0]);

    evaluator.evaluate(&[0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0], &mut output);
    assert_eq!(output, [7.0, 8.0, 13.0]);
}

#[test]
fn common_pair_elimination_revalidates_overlapping_candidates() {
    let expressions = [parse!("a+b+c"), parse!("a+b+d"), parse!("a+c+e")];
    let params = [
        parse!("a"),
        parse!("b"),
        parse!("c"),
        parse!("d"),
        parse!("e"),
    ];

    let evaluator = Atom::evaluator_multiple(&expressions, &params)
        .direct_translation(true)
        .horner_iterations(1)
        .max_horner_scheme_variables(0)
        .cpe_iterations(Some(1))
        .build()
        .unwrap();

    // Whichever pair is extracted first consumes an operand in the first
    // expression. The other candidate then has only one current use and must
    // not produce a redundant temporary instruction.
    assert_eq!(evaluator.count_operations().additions, 5);
    assert_eq!(evaluator.export_instructions().instructions.len(), 4);

    let mut evaluator = evaluator.map_coeff(&|x| x.re.to_f64());
    let mut output = [0.0; 3];
    evaluator.evaluate(&[1.0, 2.0, 3.0, 4.0, 5.0], &mut output);
    assert_eq!(output, [6.0, 7.0, 9.0]);
}

#[test]
fn common_pair_elimination_tracks_known_pairs_after_cache_limit() {
    let expressions = [parse!("a+b+c"), parse!("a+b+d")];
    let params = [parse!("a"), parse!("b"), parse!("c"), parse!("d")];

    let evaluator = Atom::evaluator_multiple(&expressions, &params)
        .direct_translation(true)
        .horner_iterations(1)
        .max_horner_scheme_variables(0)
        .max_common_pair_cache_entries(0)
        .cpe_iterations(Some(1))
        .build()
        .unwrap();

    // The cache admits (a, b), then refuses new candidates. Its occurrence
    // on the second line must still be collected and extracted.
    assert_eq!(evaluator.count_operations().additions, 3);

    let mut evaluator = evaluator.map_coeff(&|x| x.re.to_f64());
    let mut output = [0.0; 2];
    evaluator.evaluate(&[1.0, 2.0, 3.0, 4.0], &mut output);
    assert_eq!(output, [6.0, 7.0]);
}

#[test]
fn evaluator_in_finite_field_ring() {
    let params = vec![parse!("x"), parse!("y")];
    let field = Zp::new(7);

    let mut evaluator = parse!("x^3 + 2*x*y + y^-1")
        .evaluator(&params)
        .build()
        .unwrap()
        .map_to_ring(&field)
        .unwrap();

    let inputs = [field.to_element(3), field.to_element(5)];
    assert_eq!(
        evaluator.evaluate_single_in_ring(&inputs, &field),
        field.to_element(4)
    );

    let exprs = vec![parse!("if(x, x + y, y)"), parse!("(x + y)^2")];
    let mut evaluator = Atom::evaluator_multiple(&exprs, &params)
        .build()
        .unwrap()
        .map_to_ring(&field)
        .unwrap();

    let inputs = [field.zero(), field.to_element(5)];
    let mut out = vec![field.zero(); 2];
    evaluator.evaluate_in_ring(&inputs, &mut out, &field);
    assert_eq!(out, vec![field.to_element(5), field.to_element(4)]);
}

#[test]
fn merge_evaluator_with_external_functions() {
    let _double = symbol!(
        "symbolica::test::merge_external_double",
        eval = EvaluationInfo::new().register(|args: &[f64]| 2.0 * args[0])
    );
    let _shift = symbol!(
        "symbolica::test::merge_external_shift",
        eval = EvaluationInfo::new().register(|args: &[f64]| args[0] + 10.0)
    );
    let _left_constant = symbol!(
        "symbolica::test::merge_external_left_constant",
        eval = EvaluationInfo::constant(|_, prec| Ok(Float::with_val(prec, 1.0).into()))
    );
    let _right_constant = symbol!(
        "symbolica::test::merge_external_right_constant",
        eval = EvaluationInfo::constant(|_, prec| Ok(Float::with_val(prec, 5.0).into()))
    );

    let params = vec![parse!("x")];
    let settings = OptimizationSettings::new().horner_iterations(0);

    let mut left = parse!(
        "symbolica::test::merge_external_double(x) + symbolica::test::merge_external_left_constant"
    )
    .evaluator(&params)
    .optimization_settings(settings.clone())
    .build()
    .unwrap();
    let right = parse!(
        "symbolica::test::merge_external_shift(x) + symbolica::test::merge_external_right_constant"
    )
    .evaluator(&params)
    .optimization_settings(settings)
    .build()
    .unwrap();

    left.merge(right, Some(0)).unwrap();

    let mut evaluator = left.map_coeff(&|x| x.re.to_f64());
    let mut out = vec![0.0; 2];
    evaluator.evaluate(&[3.0], &mut out);

    assert_eq!(out, vec![7.0, 18.0]);
}

#[test]
fn merge_evaluator_preserves_external_constant_source_indices() {
    let params: Vec<_> = [
        "f", "dL", "dR", "rL", "sL", "uL", "vL", "hL", "rR", "sR", "uR", "vR", "hR",
    ]
    .into_iter()
    .map(|s| parse!(s))
    .collect();
    let common = parse!("f/(dL*dR*rL^2*rR^2)");
    let left = parse!("uL/(rL-sL)+vL/(-rL-sL)");
    let right = parse!("uR/(rR-sR)+vR/(-rR-sR)");
    let pi = Atom::var(Symbol::PI);
    // Merging these evaluators moves pi to an index occupied by a later
    // incoming literal. Subsequent merges also exercise reuse of pi.
    let expressions = [
        &common * &left * &right,
        Atom::i() * &pi * &common * &left * parse!("hR"),
        -Atom::i() * &pi * &common * parse!("hL") * &right,
        &pi * &pi * &common * parse!("hL*hR"),
    ];
    let mut input =
        [1., 1., 1., 2., 1., 1., 1., 0.3, 3., 1., 1., 1., 0.4].map(|x| Complex::new(x, 0.0));
    input[0] = Complex::new(0.0, 1.0);
    let pi = std::f64::consts::PI;
    let expected = [
        Complex::new(0.0, 1.0 / 216.0),
        Complex::new(-pi / 135.0, 0.0),
        Complex::new(pi / 480.0, 0.0),
        Complex::new(0.0, pi * pi / 300.0),
    ];
    let convert = |c: &Complex<Rational>| Complex::new(c.re.to_f64(), c.im.to_f64());
    let convert_prec = |c: &Complex<Rational>| {
        Complex::new(c.re.to_multi_prec_float(256), c.im.to_multi_prec_float(256))
    };
    let input_prec =
        input.map(|c| Complex::new(Float::with_val(256, c.re), Float::with_val(256, c.im)));

    for expanded in [false, true] {
        let expressions: Vec<_> = expressions
            .iter()
            .map(|a| if expanded { a.expand() } else { a.clone() })
            .collect();
        let evaluators: Vec<_> = expressions
            .iter()
            .map(|a| a.evaluator(&params).build().unwrap())
            .collect();
        let separate: Vec<_> = evaluators
            .iter()
            .cloned()
            .map(|e| e.map_coeff(&convert).evaluate_single(&input))
            .collect();
        let separate_prec: Vec<_> = evaluators
            .iter()
            .cloned()
            .map(|e| {
                e.map_coeff_with_prec(&convert_prec, 256)
                    .evaluate_single(&input_prec)
            })
            .collect();
        let mut joint_output = [Complex::new(0.0, 0.0); 4];
        Atom::evaluator_multiple(&expressions, &params)
            .build()
            .unwrap()
            .map_coeff(&convert)
            .evaluate(&input, &mut joint_output);

        for cpe_rounds in [None, Some(0)] {
            let mut merged = evaluators[0].clone();
            for evaluator in evaluators.iter().skip(1) {
                merged.merge(evaluator.clone(), cpe_rounds).unwrap();
            }
            let mut merged_output = [Complex::new(0.0, 0.0); 4];
            merged
                .clone()
                .map_coeff(&convert)
                .evaluate(&input, &mut merged_output);
            for (route, output) in [
                ("separate", separate.as_slice()),
                ("joint", joint_output.as_slice()),
                ("merged", merged_output.as_slice()),
            ] {
                for (i, (actual, expected)) in output.iter().zip(&expected).enumerate() {
                    assert!(
                        (actual.re - expected.re).abs() < 1e-12
                            && (actual.im - expected.im).abs() < 1e-12,
                        "{route} output {i}, expanded={expanded}, cpe_rounds={cpe_rounds:?}: expected {expected:?}, got {actual:?}"
                    );
                }
            }

            // Keep builtin pi exact until mapping to the requested precision.
            let mut merged_prec =
                vec![Complex::new(Float::with_val(256, 0), Float::with_val(256, 0)); 4];
            merged
                .map_coeff_with_prec(&convert_prec, 256)
                .evaluate(&input_prec, &mut merged_prec);
            for (i, (actual, expected)) in merged_prec.iter().zip(&separate_prec).enumerate() {
                assert!(
                    (actual.re.clone() - &expected.re).to_f64().abs() < 1e-65
                        && (actual.im.clone() - &expected.im).to_f64().abs() < 1e-65,
                    "256-bit output {i}, expanded={expanded}, cpe_rounds={cpe_rounds:?}: expected {expected:?}, got {actual:?}"
                );
            }
        }
    }
}

#[test]
fn merge_evaluator_with_imaginary_pi() {
    let x = parse!("x");
    let expressions = [-&x, Atom::i() * Atom::var(Symbol::PI) * &x];
    let params = [x];
    let evaluators: Vec<_> = expressions
        .iter()
        .map(|a| a.evaluator(&params).build().unwrap())
        .collect();
    for cpe_rounds in [None, Some(0)] {
        let mut merged = evaluators[0].clone();
        merged.merge(evaluators[1].clone(), cpe_rounds).unwrap();
        let mut output = [Complex::new(0.0, 0.0); 2];
        merged
            .map_coeff(&|c| Complex::new(c.re.to_f64(), c.im.to_f64()))
            .evaluate(&[Complex::new(2.0, 0.0)], &mut output);
        assert_eq!(output[0], Complex::new(-2.0, 0.0));
        assert_eq!(output[1].re, 0.0);
        assert!((output[1].im - 2.0 * std::f64::consts::PI).abs() < 1e-12);
    }
}

#[test]
fn error_propagating_float_transcendental_evaluator() {
    let params = vec![
        parse!("x"),
        parse!("y"),
        parse!("z"),
        parse!("a"),
        parse!("b"),
    ];
    let expr = parse!(
        "sqrt(y)+log(y)+exp(z)+sin(x)+cos(x)+tan(x)+asin(a)+acos(b)+atan(x)+atan(x,y)+sinh(x)+cosh(x)+tanh(x)+asinh(x)+acosh(y)+atanh(a)+x^y+abs(x)+conj(x)+cot(x)+sec(x)+csc(x)+acot(x)+asec(y)+acsc(y)+coth(x)+sech(x)+csch(x)+acoth(y)+asech(b)+acsch(x)"
    );

    let evaluator = expr
        .evaluator(&params)
        .horner_iterations(0)
        .build()
        .unwrap();

    let f64_params = [0.5, 2.0, 0.1, 0.3, 0.5];
    let expected = evaluator
        .clone()
        .map_coeff(&|x| x.re.to_f64())
        .evaluate_single(&f64_params);

    let epf64_params = f64_params.map(|x| ErrorPropagatingFloat::new(x, 15.0));
    let epf64 = evaluator
        .clone()
        .map_coeff(&|x| ErrorPropagatingFloat::new(x.re.to_f64(), 15.0))
        .evaluate_single(&epf64_params);
    assert!((*epf64.get_num() - expected).abs() < 1e-12);
    assert!(epf64.get_precision().is_some());

    let epfloat_params =
        f64_params.map(|x| ErrorPropagatingFloat::new(Float::with_val(80, x), 20.0));
    let epfloat = evaluator
        .map_coeff(&|x| ErrorPropagatingFloat::new(Float::with_val(80, x.re.to_f64()), 20.0))
        .evaluate_single(&epfloat_params);
    assert!((epfloat.get_num().to_f64() - expected).abs() < 1e-12);
    assert!(epfloat.get_precision().is_some());
}

#[test]
fn float_evaluator_keeps_exact_differences() {
    // sqrt(x) carries one bit more than x, and `a - b` is evaluated as
    // `a + (-1) b` with a `-1` at the working precision.
    let x = parse!("x");
    let evaluator = parse!("sqrt(x) - abs(sqrt(x))")
        .evaluator(&[x])
        .build()
        .unwrap();
    for bits in [128, 256, 512] {
        let mut evaluator = evaluator
            .clone()
            .map_coeff(&|c| Float::with_val(bits, c.re.to_f64()));
        for k in 2..100 {
            let result = evaluator.evaluate_single(&[Float::with_val(bits, k)]);
            assert!(result.is_fully_zero(), "{bits} bits, x = {k}: {result}");
        }
    }
}

#[test]
fn float_transcendental_evaluator() {
    let params = vec![
        parse!("x"),
        parse!("y"),
        parse!("z"),
        parse!("a"),
        parse!("b"),
    ];
    let expr = parse!(
        "tan(x)+asin(a)+acos(b)+atan(x)+atan(x,y)+sinh(x)+cosh(x)+tanh(x)+cot(x)+sec(x)+csc(x)+acot(x)+asec(y)+acsc(y)+coth(x)+sech(x)+csch(x)+asinh(x)+acosh(y)+atanh(a)+acoth(y)+asech(b)+acsch(x)+gamma(y)+erf(x)+zeta(y)+polygamma(1,y)+polylog(2,a)+bessel_j(0,x)+bessel_y(0,y)+bessel_i(0,x)+bessel_k(0,y)"
    );

    let evaluator = expr
        .evaluator(&params)
        .horner_iterations(0)
        .build()
        .unwrap();

    let f64_params = [0.5, 2.0, 0.1, 0.3, 0.5];
    let expected = evaluator
        .clone()
        .map_coeff(&|x| x.re.to_f64())
        .evaluate_single(&f64_params);

    let float_params = f64_params.map(|x| Float::with_val(53, x));
    let result = evaluator
        .map_coeff(&|x| Float::with_val(53, x.re.to_f64()))
        .evaluate_single(&float_params);

    assert!(
        (result.to_f64() - expected).abs() < 1e-10,
        "Float result {} differs from f64 result {}",
        result,
        expected
    );
}

const F13: &'static str = "-48*ammu*amuq*ammu2*amuq2*x6*xcp4*e1234-48*ammu*amuq*ammu2*amuq2*x6*xcp3*e1234+48*ammu*amuq*ammu2*amuq2*x6*xcp2*e1234+48*ammu*amuq*ammu2*amuq2*x6*xcp1*e1234+48*ammu*amuq*ammu2*amuq2*x6^2*xcp3*e1234-48*ammu*amuq*ammu2*amuq2*x6^2*xcp2*e1234-144*ammu*
amuq*ammu2*amuq2*x5*xcp4*e1234-48*ammu*amuq*ammu2*amuq2*x5*xcp3*e1234+48*ammu*amuq*ammu2*amuq2*x5*xcp2*e1234+144*ammu*amuq*ammu2*amuq2*x5*xcp1*e1234+96*ammu*amuq*ammu2*amuq2*x5*x6*xcp3*e1234-96*ammu*amuq*ammu2*amuq2*x5*x6*xcp2*e1234+48*ammu*amuq*
ammu2*amuq2*x5^2*xcp3*e1234-48*ammu*amuq*ammu2*amuq2*x5^2*xcp2*e1234-96*ammu*amuq*ammu2*amuq2*x4*xcp4*e1245-48*ammu*amuq*ammu2*amuq2*x4*xcp3*e1245-96*ammu*amuq*ammu2*amuq2*x4*xcp3*e1234+48*ammu*amuq*ammu2*amuq2*x4*xcp2*e1245+96*ammu*amuq*ammu2*
amuq2*x4*xcp2*e1234+96*ammu*amuq*ammu2*amuq2*x4*xcp1*e1245+48*ammu*amuq*ammu2*amuq2*x4*x6*xcp4*e1234-48*ammu*amuq*ammu2*amuq2*x4*x6*xcp1*e1234+48*ammu*amuq*ammu2*amuq2*x4*x6^2*xcp4*e1234-48*ammu*amuq*ammu2*amuq2*x4*x6^2*xcp1*e1234+144*ammu*amuq*
ammu2*amuq2*x4*x5*xcp4*e1234-144*ammu*amuq*ammu2*amuq2*x4*x5*xcp1*e1234+48*ammu*amuq*ammu2*amuq2*x4*x5*x6*xcp4*e1234+144*ammu*amuq*ammu2*amuq2*x4*x5*x6*xcp3*e1234-144*ammu*amuq*ammu2*amuq2*x4*x5*x6*xcp2*e1234-48*ammu*amuq*ammu2*amuq2*x4*x5*x6*xcp1*
e1234+96*ammu*amuq*ammu2*amuq2*x4*x5^2*xcp3*e1234-96*ammu*amuq*ammu2*amuq2*x4*x5^2*xcp2*e1234+144*ammu*amuq*ammu2*amuq2*x4^2*xcp4*e1245-96*ammu*amuq*ammu2*amuq2*x4^2*xcp3*e1245+48*ammu*amuq*ammu2*amuq2*x4^2*xcp3*e1234+96*ammu*amuq*ammu2*amuq2*x4^2*
xcp2*e1245-48*ammu*amuq*ammu2*amuq2*x4^2*xcp2*e1234-144*ammu*amuq*ammu2*amuq2*x4^2*xcp1*e1245+48*ammu*amuq*ammu2*amuq2*x4^2*x6*xcp4*e1245-48*ammu*amuq*ammu2*amuq2*x4^2*x6*xcp4*e1234+48*ammu*amuq*ammu2*amuq2*x4^2*x6*xcp3*e1234-48*ammu*amuq*ammu2*
amuq2*x4^2*x6*xcp2*e1234-48*ammu*amuq*ammu2*amuq2*x4^2*x6*xcp1*e1245+48*ammu*amuq*ammu2*amuq2*x4^2*x6*xcp1*e1234-48*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp4*e1234+144*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp3*e1245+48*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp3*e1235+48
*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp3*e1234-144*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp2*e1245-48*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp2*e1235-48*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp2*e1234+48*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp1*e1234-48*ammu*amuq*ammu2*amuq2*x4^3
*xcp4*e1245+48*ammu*amuq*ammu2*amuq2*x4^3*xcp3*e1245-48*ammu*amuq*ammu2*amuq2*x4^3*xcp2*e1245+48*ammu*amuq*ammu2*amuq2*x4^3*xcp1*e1245-96*ammu*amuq*ammu2^2*x6*xcp4*e1245-48*ammu*amuq*ammu2^2*x6*xcp4*e1235-48*ammu*amuq*ammu2^2*x6*xcp3*e1235+48*ammu*
amuq*ammu2^2*x6*xcp2*e1235+96*ammu*amuq*ammu2^2*x6*xcp1*e1245+48*ammu*amuq*ammu2^2*x6*xcp1*e1235-48*ammu*amuq*ammu2^2*x6^2*xcp4*e1245+48*ammu*amuq*ammu2^2*x6^2*xcp3*e1245+48*ammu*amuq*ammu2^2*x6^2*xcp3*e1235-48*ammu*amuq*ammu2^2*x6^2*xcp2*e1245-48*
ammu*amuq*ammu2^2*x6^2*xcp2*e1235+48*ammu*amuq*ammu2^2*x6^2*xcp1*e1245-96*ammu*amuq*ammu2^2*x5*xcp4*e1245-48*ammu*amuq*ammu2^2*x5*xcp4*e1235+96*ammu*amuq*ammu2^2*x5*xcp4*e1234-48*ammu*amuq*ammu2^2*x5*xcp3*e1235+48*ammu*amuq*ammu2^2*x5*xcp2*e1235+96
*ammu*amuq*ammu2^2*x5*xcp1*e1245+48*ammu*amuq*ammu2^2*x5*xcp1*e1235-96*ammu*amuq*ammu2^2*x5*xcp1*e1234-96*ammu*amuq*ammu2^2*x5*x6*xcp4*e1245+48*ammu*amuq*ammu2^2*x5*x6*xcp4*e1235+48*ammu*amuq*ammu2^2*x5*x6*xcp4*e1234-96*ammu*amuq*ammu2^2*x5*x6*xcp3
*e1234+96*ammu*amuq*ammu2^2*x5*x6*xcp2*e1234+96*ammu*amuq*ammu2^2*x5*x6*xcp1*e1245-48*ammu*amuq*ammu2^2*x5*x6*xcp1*e1235-48*ammu*amuq*ammu2^2*x5*x6*xcp1*e1234+48*ammu*amuq*ammu2^2*x5*x6^2*xcp4*e1235+48*ammu*amuq*ammu2^2*x5*x6^2*xcp4*e1234+48*ammu*
amuq*ammu2^2*x5*x6^2*xcp3*e1235+48*ammu*amuq*ammu2^2*x5*x6^2*xcp3*e1234-48*ammu*amuq*ammu2^2*x5*x6^2*xcp2*e1235-48*ammu*amuq*ammu2^2*x5*x6^2*xcp2*e1234-48*ammu*amuq*ammu2^2*x5*x6^2*xcp1*e1235-48*ammu*amuq*ammu2^2*x5*x6^2*xcp1*e1234+96*ammu*amuq*
ammu2^2*x5^2*xcp4*e1245+144*ammu*amuq*ammu2^2*x5^2*xcp4*e1235+144*ammu*amuq*ammu2^2*x5^2*xcp4*e1234-192*ammu*amuq*ammu2^2*x5^2*xcp3*e1245-48*ammu*amuq*ammu2^2*x5^2*xcp3*e1235-96*ammu*amuq*ammu2^2*x5^2*xcp3*e1234+192*ammu*amuq*ammu2^2*x5^2*xcp2*
e1245+48*ammu*amuq*ammu2^2*x5^2*xcp2*e1235+96*ammu*amuq*ammu2^2*x5^2*xcp2*e1234-96*ammu*amuq*ammu2^2*x5^2*xcp1*e1245-144*ammu*amuq*ammu2^2*x5^2*xcp1*e1235-144*ammu*amuq*ammu2^2*x5^2*xcp1*e1234+48*ammu*amuq*ammu2^2*x5^2*x6*xcp4*e1245+48*ammu*amuq*
ammu2^2*x5^2*x6*xcp4*e1235+48*ammu*amuq*ammu2^2*x5^2*x6*xcp4*e1234+48*ammu*amuq*ammu2^2*x5^2*x6*xcp3*e1245+240*ammu*amuq*ammu2^2*x5^2*x6*xcp3*e1235+240*ammu*amuq*ammu2^2*x5^2*x6*xcp3*e1234-48*ammu*amuq*ammu2^2*x5^2*x6*xcp2*e1245-240*ammu*amuq*
ammu2^2*x5^2*x6*xcp2*e1235-240*ammu*amuq*ammu2^2*x5^2*x6*xcp2*e1234-48*ammu*amuq*ammu2^2*x5^2*x6*xcp1*e1245-48*ammu*amuq*ammu2^2*x5^2*x6*xcp1*e1235-48*ammu*amuq*ammu2^2*x5^2*x6*xcp1*e1234+192*ammu*amuq*ammu2^2*x5^3*xcp3*e1245+192*ammu*amuq*ammu2^2*
x5^3*xcp3*e1235+192*ammu*amuq*ammu2^2*x5^3*xcp3*e1234-192*ammu*amuq*ammu2^2*x5^3*xcp2*e1245-192*ammu*amuq*ammu2^2*x5^3*xcp2*e1235-192*ammu*amuq*ammu2^2*x5^3*xcp2*e1234-96*ammu*amuq*ammu2^2*x4*xcp3*e1235+96*ammu*amuq*ammu2^2*x4*xcp2*e1235+48*ammu*
amuq*ammu2^2*x4*x6*xcp4*e1235-48*ammu*amuq*ammu2^2*x4*x6*xcp3*e1245+48*ammu*amuq*ammu2^2*x4*x6*xcp2*e1245-48*ammu*amuq*ammu2^2*x4*x6*xcp1*e1235+48*ammu*amuq*ammu2^2*x4*x6^2*xcp4*e1235-48*ammu*amuq*ammu2^2*x4*x6^2*xcp1*e1235+288*ammu*amuq*ammu2^2*x4
*x5*xcp4*e1245+144*ammu*amuq*ammu2^2*x4*x5*xcp4*e1235-288*ammu*amuq*ammu2^2*x4*x5*xcp3*e1245+48*ammu*amuq*ammu2^2*x4*x5*xcp3*e1235+48*ammu*amuq*ammu2^2*x4*x5*xcp3*e1234+288*ammu*amuq*ammu2^2*x4*x5*xcp2*e1245-48*ammu*amuq*ammu2^2*x4*x5*xcp2*e1235-48
*ammu*amuq*ammu2^2*x4*x5*xcp2*e1234-288*ammu*amuq*ammu2^2*x4*x5*xcp1*e1245-144*ammu*amuq*ammu2^2*x4*x5*xcp1*e1235+96*ammu*amuq*ammu2^2*x4*x5*x6*xcp4*e1245-48*ammu*amuq*ammu2^2*x4*x5*x6*xcp4*e1234+48*ammu*amuq*ammu2^2*x4*x5*x6*xcp3*e1245+192*ammu*
amuq*ammu2^2*x4*x5*x6*xcp3*e1235+48*ammu*amuq*ammu2^2*x4*x5*x6*xcp3*e1234-48*ammu*amuq*ammu2^2*x4*x5*x6*xcp2*e1245-192*ammu*amuq*ammu2^2*x4*x5*x6*xcp2*e1235-48*ammu*amuq*ammu2^2*x4*x5*x6*xcp2*e1234-96*ammu*amuq*ammu2^2*x4*x5*x6*xcp1*e1245+48*ammu*
amuq*ammu2^2*x4*x5*x6*xcp1*e1234-48*ammu*amuq*ammu2^2*x4*x5^2*xcp4*e1245-48*ammu*amuq*ammu2^2*x4*x5^2*xcp4*e1235-48*ammu*amuq*ammu2^2*x4*x5^2*xcp4*e1234+384*ammu*amuq*ammu2^2*x4*x5^2*xcp3*e1245+192*ammu*amuq*ammu2^2*x4*x5^2*xcp3*e1235+96*ammu*amuq*
ammu2^2*x4*x5^2*xcp3*e1234-384*ammu*amuq*ammu2^2*x4*x5^2*xcp2*e1245-192*ammu*amuq*ammu2^2*x4*x5^2*xcp2*e1235-96*ammu*amuq*ammu2^2*x4*x5^2*xcp2*e1234+48*ammu*amuq*ammu2^2*x4*x5^2*xcp1*e1245+48*ammu*amuq*ammu2^2*x4*x5^2*xcp1*e1235+48*ammu*amuq*
ammu2^2*x4*x5^2*xcp1*e1234+48*ammu*amuq*ammu2^2*x4^2*xcp3*e1235-48*ammu*amuq*ammu2^2*x4^2*xcp2*e1235-48*ammu*amuq*ammu2^2*x4^2*x6*xcp4*e1235+48*ammu*amuq*ammu2^2*x4^2*x6*xcp3*e1235-48*ammu*amuq*ammu2^2*x4^2*x6*xcp2*e1235+48*ammu*amuq*ammu2^2*x4^2*
x6*xcp1*e1235-96*ammu*amuq*ammu2^2*x4^2*x5*xcp4*e1245-48*ammu*amuq*ammu2^2*x4^2*x5*xcp4*e1235+96*ammu*amuq*ammu2^2*x4^2*x5*xcp3*e1245-96*ammu*amuq*ammu2^2*x4^2*x5*xcp2*e1245+96*ammu*amuq*ammu2^2*x4^2*x5*xcp1*e1245+48*ammu*amuq*ammu2^2*x4^2*x5*xcp1*
e1235+480*ammu*amuq*amel2*amuq2*xcp4*e1234+768*ammu*amuq*amel2*amuq2*xcp3*e1234-768*ammu*amuq*amel2*amuq2*xcp2*e1234-480*ammu*amuq*amel2*amuq2*xcp1*e1234+192*ammu*amuq*amel2*amuq2*x6*xcp4*e1234+144*ammu*amuq*amel2*amuq2*x6*xcp3*e1234-144*ammu*amuq*
amel2*amuq2*x6*xcp2*e1234-192*ammu*amuq*amel2*amuq2*x6*xcp1*e1234-192*ammu*amuq*amel2*amuq2*x6^2*xcp4*e1234-144*ammu*amuq*amel2*amuq2*x6^2*xcp3*e1234+144*ammu*amuq*amel2*amuq2*x6^2*xcp2*e1234+192*ammu*amuq*amel2*amuq2*x6^2*xcp1*e1234-384*ammu*amuq*
amel2*amuq2*x5*xcp4*e1234-432*ammu*amuq*amel2*amuq2*x5*xcp3*e1234+432*ammu*amuq*amel2*amuq2*x5*xcp2*e1234+384*ammu*amuq*amel2*amuq2*x5*xcp1*e1234-576*ammu*amuq*amel2*amuq2*x5*x6*xcp4*e1234-480*ammu*amuq*amel2*amuq2*x5*x6*xcp3*e1234+480*ammu*amuq*
amel2*amuq2*x5*x6*xcp2*e1234+576*ammu*amuq*amel2*amuq2*x5*x6*xcp1*e1234-384*ammu*amuq*amel2*amuq2*x5^2*xcp4*e1234-336*ammu*amuq*amel2*amuq2*x5^2*xcp3*e1234+336*ammu*amuq*amel2*amuq2*x5^2*xcp2*e1234+384*ammu*amuq*amel2*amuq2*x5^2*xcp1*e1234-480*ammu
*amuq*amel2*amuq2*x4*xcp4*e2345-480*ammu*amuq*amel2*amuq2*x4*xcp4*e1345-576*ammu*amuq*amel2*amuq2*x4*xcp4*e1245+576*ammu*amuq*amel2*amuq2*x4*xcp4*e1235+672*ammu*amuq*amel2*amuq2*x4*xcp4*e1234-528*ammu*amuq*amel2*amuq2*x4*xcp3*e2345-480*ammu*amuq*
amel2*amuq2*x4*xcp3*e1345-576*ammu*amuq*amel2*amuq2*x4*xcp3*e1245+576*ammu*amuq*amel2*amuq2*x4*xcp3*e1235+384*ammu*amuq*amel2*amuq2*x4*xcp3*e1234+528*ammu*amuq*amel2*amuq2*x4*xcp2*e2345+480*ammu*amuq*amel2*amuq2*x4*xcp2*e1345+576*ammu*amuq*amel2*
amuq2*x4*xcp2*e1245-576*ammu*amuq*amel2*amuq2*x4*xcp2*e1235-384*ammu*amuq*amel2*amuq2*x4*xcp2*e1234+480*ammu*amuq*amel2*amuq2*x4*xcp1*e2345+480*ammu*amuq*amel2*amuq2*x4*xcp1*e1345+576*ammu*amuq*amel2*amuq2*x4*xcp1*e1245-576*ammu*amuq*amel2*amuq2*x4
*xcp1*e1235-672*ammu*amuq*amel2*amuq2*x4*xcp1*e1234-192*ammu*amuq*amel2*amuq2*x4*x6*xcp4*e1245+192*ammu*amuq*amel2*amuq2*x4*x6*xcp4*e1235-528*ammu*amuq*amel2*amuq2*x4*x6*xcp4*e1234-192*ammu*amuq*amel2*amuq2*x4*x6*xcp3*e1245+192*ammu*amuq*amel2*
amuq2*x4*x6*xcp3*e1235-96*ammu*amuq*amel2*amuq2*x4*x6*xcp3*e1234+192*ammu*amuq*amel2*amuq2*x4*x6*xcp2*e1245-192*ammu*amuq*amel2*amuq2*x4*x6*xcp2*e1235+96*ammu*amuq*amel2*amuq2*x4*x6*xcp2*e1234+192*ammu*amuq*amel2*amuq2*x4*x6*xcp1*e1245-192*ammu*
amuq*amel2*amuq2*x4*x6*xcp1*e1235+528*ammu*amuq*amel2*amuq2*x4*x6*xcp1*e1234+96*ammu*amuq*amel2*amuq2*x4*x6^2*xcp4*e1234+48*ammu*amuq*amel2*amuq2*x4*x6^2*xcp3*e1234-48*ammu*amuq*amel2*amuq2*x4*x6^2*xcp2*e1234-96*ammu*amuq*amel2*amuq2*x4*x6^2*xcp1*
e1234-192*ammu*amuq*amel2*amuq2*x4*x5*xcp4*e1245+192*ammu*amuq*amel2*amuq2*x4*x5*xcp4*e1235-336*ammu*amuq*amel2*amuq2*x4*x5*xcp4*e1234-192*ammu*amuq*amel2*amuq2*x4*x5*xcp3*e1245+192*ammu*amuq*amel2*amuq2*x4*x5*xcp3*e1235-288*ammu*amuq*amel2*amuq2*
x4*x5*xcp3*e1234+192*ammu*amuq*amel2*amuq2*x4*x5*xcp2*e1245-192*ammu*amuq*amel2*amuq2*x4*x5*xcp2*e1235+288*ammu*amuq*amel2*amuq2*x4*x5*xcp2*e1234+192*ammu*amuq*amel2*amuq2*x4*x5*xcp1*e1245-192*ammu*amuq*amel2*amuq2*x4*x5*xcp1*e1235+336*ammu*amuq*
amel2*amuq2*x4*x5*xcp1*e1234+288*ammu*amuq*amel2*amuq2*x4*x5*x6*xcp4*e1234+192*ammu*amuq*amel2*amuq2*x4*x5*x6*xcp3*e1234-192*ammu*amuq*amel2*amuq2*x4*x5*x6*xcp2*e1234-288*ammu*amuq*amel2*amuq2*x4*x5*x6*xcp1*e1234+192*ammu*amuq*amel2*amuq2*x4*x5^2*
xcp4*e1234+144*ammu*amuq*amel2*amuq2*x4*x5^2*xcp3*e1234-144*ammu*amuq*amel2*amuq2*x4*x5^2*xcp2*e1234-192*ammu*amuq*amel2*amuq2*x4*x5^2*xcp1*e1234+432*ammu*amuq*amel2*amuq2*x4^2*xcp4*e2345+576*ammu*amuq*amel2*amuq2*x4^2*xcp4*e1345-192*ammu*amuq*
amel2*amuq2*x4^2*xcp4*e1235-624*ammu*amuq*amel2*amuq2*x4^2*xcp4*e1234+96*ammu*amuq*amel2*amuq2*x4^2*xcp3*e2345+192*ammu*amuq*amel2*amuq2*x4^2*xcp3*e1235-96*ammu*amuq*amel2*amuq2*x4^2*xcp3*e1234-96*ammu*amuq*amel2*amuq2*x4^2*xcp2*e2345-192*ammu*amuq
*amel2*amuq2*x4^2*xcp2*e1235+96*ammu*amuq*amel2*amuq2*x4^2*xcp2*e1234-432*ammu*amuq*amel2*amuq2*x4^2*xcp1*e2345-576*ammu*amuq*amel2*amuq2*x4^2*xcp1*e1345+192*ammu*amuq*amel2*amuq2*x4^2*xcp1*e1235+624*ammu*amuq*amel2*amuq2*x4^2*xcp1*e1234+96*ammu*
amuq*amel2*amuq2*x4^2*x6*xcp4*e2345+96*ammu*amuq*amel2*amuq2*x4^2*x6*xcp4*e1345+192*ammu*amuq*amel2*amuq2*x4^2*x6*xcp4*e1245+96*ammu*amuq*amel2*amuq2*x4^2*x6*xcp4*e1234+144*ammu*amuq*amel2*amuq2*x4^2*x6*xcp3*e2345+96*ammu*amuq*amel2*amuq2*x4^2*x6*
xcp3*e1345+192*ammu*amuq*amel2*amuq2*x4^2*x6*xcp3*e1245-384*ammu*amuq*amel2*amuq2*x4^2*x6*xcp3*e1235-48*ammu*amuq*amel2*amuq2*x4^2*x6*xcp3*e1234-144*ammu*amuq*amel2*amuq2*x4^2*x6*xcp2*e2345-96*ammu*amuq*amel2*amuq2*x4^2*x6*xcp2*e1345-192*ammu*amuq*
amel2*amuq2*x4^2*x6*xcp2*e1245+384*ammu*amuq*amel2*amuq2*x4^2*x6*xcp2*e1235+48*ammu*amuq*amel2*amuq2*x4^2*x6*xcp2*e1234-96*ammu*amuq*amel2*amuq2*x4^2*x6*xcp1*e2345-96*ammu*amuq*amel2*amuq2*x4^2*x6*xcp1*e1345-192*ammu*amuq*amel2*amuq2*x4^2*x6*xcp1*
e1245-96*ammu*amuq*amel2*amuq2*x4^2*x6*xcp1*e1234-48*ammu*amuq*amel2*amuq2*x4^2*x5*xcp4*e1345+192*ammu*amuq*amel2*amuq2*x4^2*x5*xcp4*e1245+240*ammu*amuq*amel2*amuq2*x4^2*x5*xcp4*e1234+432*ammu*amuq*amel2*amuq2*x4^2*x5*xcp3*e2345+528*ammu*amuq*amel2
*amuq2*x4^2*x5*xcp3*e1345+192*ammu*amuq*amel2*amuq2*x4^2*x5*xcp3*e1245-384*ammu*amuq*amel2*amuq2*x4^2*x5*xcp3*e1235-96*ammu*amuq*amel2*amuq2*x4^2*x5*xcp3*e1234-432*ammu*amuq*amel2*amuq2*x4^2*x5*xcp2*e2345-528*ammu*amuq*amel2*amuq2*x4^2*x5*xcp2*
e1345-192*ammu*amuq*amel2*amuq2*x4^2*x5*xcp2*e1245+384*ammu*amuq*amel2*amuq2*x4^2*x5*xcp2*e1235+96*ammu*amuq*amel2*amuq2*x4^2*x5*xcp2*e1234+48*ammu*amuq*amel2*amuq2*x4^2*x5*xcp1*e1345-192*ammu*amuq*amel2*amuq2*x4^2*x5*xcp1*e1245-240*ammu*amuq*amel2
*amuq2*x4^2*x5*xcp1*e1234-96*ammu*amuq*amel2*amuq2*x4^3*xcp4*e2345-192*ammu*amuq*amel2*amuq2*x4^3*xcp4*e1345+192*ammu*amuq*amel2*amuq2*x4^3*xcp4*e1245+96*ammu*amuq*amel2*amuq2*x4^3*xcp4*e1234+96*ammu*amuq*amel2*amuq2*x4^3*xcp3*e2345+96*ammu*amuq*
amel2*amuq2*x4^3*xcp3*e1345+192*ammu*amuq*amel2*amuq2*x4^3*xcp3*e1245-384*ammu*amuq*amel2*amuq2*x4^3*xcp3*e1235-144*ammu*amuq*amel2*amuq2*x4^3*xcp3*e1234-96*ammu*amuq*amel2*amuq2*x4^3*xcp2*e2345-96*ammu*amuq*amel2*amuq2*x4^3*xcp2*e1345-192*ammu*
amuq*amel2*amuq2*x4^3*xcp2*e1245+384*ammu*amuq*amel2*amuq2*x4^3*xcp2*e1235+144*ammu*amuq*amel2*amuq2*x4^3*xcp2*e1234+96*ammu*amuq*amel2*amuq2*x4^3*xcp1*e2345+192*ammu*amuq*amel2*amuq2*x4^3*xcp1*e1345-192*ammu*amuq*amel2*amuq2*x4^3*xcp1*e1245-96*
ammu*amuq*amel2*amuq2*x4^3*xcp1*e1234+720*ammu*amuq*amel2*amuq2*x3*xcp4*e1234+624*ammu*amuq*amel2*amuq2*x3*xcp3*e1234-624*ammu*amuq*amel2*amuq2*x3*xcp2*e1234-720*ammu*amuq*amel2*amuq2*x3*xcp1*e1234-144*ammu*amuq*amel2*amuq2*x3*x6*xcp4*e1234-144*
ammu*amuq*amel2*amuq2*x3*x6*xcp3*e1234+144*ammu*amuq*amel2*amuq2*x3*x6*xcp2*e1234+144*ammu*amuq*amel2*amuq2*x3*x6*xcp1*e1234-336*ammu*amuq*amel2*amuq2*x3*x5*xcp4*e1234-336*ammu*amuq*amel2*amuq2*x3*x5*xcp3*e1234+336*ammu*amuq*amel2*amuq2*x3*x5*xcp2*
e1234+336*ammu*amuq*amel2*amuq2*x3*x5*xcp1*e1234-192*ammu*amuq*amel2*amuq2*x3*x4*xcp4*e1245+192*ammu*amuq*amel2*amuq2*x3*x4*xcp4*e1235-576*ammu*amuq*amel2*amuq2*x3*x4*xcp4*e1234-192*ammu*amuq*amel2*amuq2*x3*x4*xcp3*e1245+192*ammu*amuq*amel2*amuq2*
x3*x4*xcp3*e1235-48*ammu*amuq*amel2*amuq2*x3*x4*xcp3*e1234+192*ammu*amuq*amel2*amuq2*x3*x4*xcp2*e1245-192*ammu*amuq*amel2*amuq2*x3*x4*xcp2*e1235+48*ammu*amuq*amel2*amuq2*x3*x4*xcp2*e1234+192*ammu*amuq*amel2*amuq2*x3*x4*xcp1*e1245-192*ammu*amuq*
amel2*amuq2*x3*x4*xcp1*e1235+576*ammu*amuq*amel2*amuq2*x3*x4*xcp1*e1234+48*ammu*amuq*amel2*amuq2*x3*x4*x6*xcp3*e1234-48*ammu*amuq*amel2*amuq2*x3*x4*x6*xcp2*e1234+144*ammu*amuq*amel2*amuq2*x3*x4*x5*xcp4*e1234-144*ammu*amuq*amel2*amuq2*x3*x4*x5*xcp1*
e1234-48*ammu*amuq*amel2*amuq2*x3*x4^2*xcp4*e1345+192*ammu*amuq*amel2*amuq2*x3*x4^2*xcp4*e1245+48*ammu*amuq*amel2*amuq2*x3*x4^2*xcp4*e1234-48*ammu*amuq*amel2*amuq2*x3*x4^2*xcp3*e1345+192*ammu*amuq*amel2*amuq2*x3*x4^2*xcp3*e1245-384*ammu*amuq*amel2*
amuq2*x3*x4^2*xcp3*e1235-144*ammu*amuq*amel2*amuq2*x3*x4^2*xcp3*e1234+48*ammu*amuq*amel2*amuq2*x3*x4^2*xcp2*e1345-192*ammu*amuq*amel2*amuq2*x3*x4^2*xcp2*e1245+384*ammu*amuq*amel2*amuq2*x3*x4^2*xcp2*e1235+144*ammu*amuq*amel2*amuq2*x3*x4^2*xcp2*e1234
+48*ammu*amuq*amel2*amuq2*x3*x4^2*xcp1*e1345-192*ammu*amuq*amel2*amuq2*x3*x4^2*xcp1*e1245-48*ammu*amuq*amel2*amuq2*x3*x4^2*xcp1*e1234+48*ammu*amuq*amel2*amuq2*x3^2*xcp4*e1234+48*ammu*amuq*amel2*amuq2*x3^2*xcp3*e1234-48*ammu*amuq*amel2*amuq2*x3^2*
xcp2*e1234-48*ammu*amuq*amel2*amuq2*x3^2*xcp1*e1234-48*ammu*amuq*amel2*amuq2*x3^2*x4*xcp4*e1234+48*ammu*amuq*amel2*amuq2*x3^2*x4*xcp1*e1234+576*ammu*amuq*amel2*amuq2*x1*xcp4*e1234+720*ammu*amuq*amel2*amuq2*x1*xcp3*e1234-720*ammu*amuq*amel2*amuq2*x1
*xcp2*e1234-576*ammu*amuq*amel2*amuq2*x1*xcp1*e1234-240*ammu*amuq*amel2*amuq2*x1*x6*xcp4*e1234-144*ammu*amuq*amel2*amuq2*x1*x6*xcp3*e1234+144*ammu*amuq*amel2*amuq2*x1*x6*xcp2*e1234+240*ammu*amuq*amel2*amuq2*x1*x6*xcp1*e1234-432*ammu*amuq*amel2*
amuq2*x1*x5*xcp4*e1234-336*ammu*amuq*amel2*amuq2*x1*x5*xcp3*e1234+336*ammu*amuq*amel2*amuq2*x1*x5*xcp2*e1234+432*ammu*amuq*amel2*amuq2*x1*x5*xcp1*e1234-192*ammu*amuq*amel2*amuq2*x1*x4*xcp4*e1245+192*ammu*amuq*amel2*amuq2*x1*x4*xcp4*e1235-480*ammu*
amuq*amel2*amuq2*x1*x4*xcp4*e1234-192*ammu*amuq*amel2*amuq2*x1*x4*xcp3*e1245+192*ammu*amuq*amel2*amuq2*x1*x4*xcp3*e1235-240*ammu*amuq*amel2*amuq2*x1*x4*xcp3*e1234+192*ammu*amuq*amel2*amuq2*x1*x4*xcp2*e1245-192*ammu*amuq*amel2*amuq2*x1*x4*xcp2*e1235
+240*ammu*amuq*amel2*amuq2*x1*x4*xcp2*e1234+192*ammu*amuq*amel2*amuq2*x1*x4*xcp1*e1245-192*ammu*amuq*amel2*amuq2*x1*x4*xcp1*e1235+480*ammu*amuq*amel2*amuq2*x1*x4*xcp1*e1234+192*ammu*amuq*amel2*amuq2*x1*x4*x6*xcp4*e1234+48*ammu*amuq*amel2*amuq2*x1*
x4*x6*xcp3*e1234-48*ammu*amuq*amel2*amuq2*x1*x4*x6*xcp2*e1234-192*ammu*amuq*amel2*amuq2*x1*x4*x6*xcp1*e1234+288*ammu*amuq*amel2*amuq2*x1*x4*x5*xcp4*e1234+144*ammu*amuq*amel2*amuq2*x1*x4*x5*xcp3*e1234-144*ammu*amuq*amel2*amuq2*x1*x4*x5*xcp2*e1234-
288*ammu*amuq*amel2*amuq2*x1*x4*x5*xcp1*e1234+192*ammu*amuq*amel2*amuq2*x1*x4^2*xcp4*e1245+96*ammu*amuq*amel2*amuq2*x1*x4^2*xcp4*e1234+48*ammu*amuq*amel2*amuq2*x1*x4^2*xcp3*e2345+192*ammu*amuq*amel2*amuq2*x1*x4^2*xcp3*e1245-384*ammu*amuq*amel2*
amuq2*x1*x4^2*xcp3*e1235-96*ammu*amuq*amel2*amuq2*x1*x4^2*xcp3*e1234-48*ammu*amuq*amel2*amuq2*x1*x4^2*xcp2*e2345-192*ammu*amuq*amel2*amuq2*x1*x4^2*xcp2*e1245+384*ammu*amuq*amel2*amuq2*x1*x4^2*xcp2*e1235+96*ammu*amuq*amel2*amuq2*x1*x4^2*xcp2*e1234-
192*ammu*amuq*amel2*amuq2*x1*x4^2*xcp1*e1245-96*ammu*amuq*amel2*amuq2*x1*x4^2*xcp1*e1234-48*ammu*amuq*amel2*amuq2*x1^2*xcp4*e1234+48*ammu*amuq*amel2*amuq2*x1^2*xcp1*e1234+96*ammu*amuq*amel2*amuq2*x1^2*x4*xcp4*e1234-96*ammu*amuq*amel2*amuq2*x1^2*x4*
xcp1*e1234+768*ammu*amuq*amel2*ammu2*xcp4*e1245+2016*ammu*amuq*amel2*ammu2*xcp4*e1235+1536*ammu*amuq*amel2*ammu2*xcp4*e1234-384*ammu*amuq*amel2*ammu2*xcp3*e1245-768*ammu*amuq*amel2*ammu2*xcp3*e1235+384*ammu*amuq*amel2*ammu2*xcp2*e1245+768*ammu*amuq
*amel2*ammu2*xcp2*e1235-768*ammu*amuq*amel2*ammu2*xcp1*e1245-2016*ammu*amuq*amel2*ammu2*xcp1*e1235-1536*ammu*amuq*amel2*ammu2*xcp1*e1234+864*ammu*amuq*amel2*ammu2*x6*xcp4*e2345+96*ammu*amuq*amel2*ammu2*x6*xcp4*e1345+384*ammu*amuq*amel2*ammu2*x6*
xcp4*e1245+144*ammu*amuq*amel2*ammu2*x6*xcp4*e1235-48*ammu*amuq*amel2*ammu2*x6*xcp3*e1345-96*ammu*amuq*amel2*ammu2*x6*xcp3*e1245+864*ammu*amuq*amel2*ammu2*x6*xcp3*e1235+384*ammu*amuq*amel2*ammu2*x6*xcp3*e1234+48*ammu*amuq*amel2*ammu2*x6*xcp2*e1345+
96*ammu*amuq*amel2*ammu2*x6*xcp2*e1245-864*ammu*amuq*amel2*ammu2*x6*xcp2*e1235-384*ammu*amuq*amel2*ammu2*x6*xcp2*e1234-864*ammu*amuq*amel2*ammu2*x6*xcp1*e2345-96*ammu*amuq*amel2*ammu2*x6*xcp1*e1345-384*ammu*amuq*amel2*ammu2*x6*xcp1*e1245-144*ammu*
amuq*amel2*ammu2*x6*xcp1*e1235-432*ammu*amuq*amel2*ammu2*x6^2*xcp4*e2345+48*ammu*amuq*amel2*ammu2*x6^2*xcp4*e1345-528*ammu*amuq*amel2*ammu2*x6^2*xcp4*e1245-768*ammu*amuq*amel2*ammu2*x6^2*xcp4*e1235-576*ammu*amuq*amel2*ammu2*x6^2*xcp4*e1234-336*ammu
*amuq*amel2*ammu2*x6^2*xcp3*e2345-144*ammu*amuq*amel2*ammu2*x6^2*xcp3*e1345-144*ammu*amuq*amel2*ammu2*x6^2*xcp3*e1245+864*ammu*amuq*amel2*ammu2*x6^2*xcp3*e1235+192*ammu*amuq*amel2*ammu2*x6^2*xcp3*e1234+336*ammu*amuq*amel2*ammu2*x6^2*xcp2*e2345+144*
ammu*amuq*amel2*ammu2*x6^2*xcp2*e1345+144*ammu*amuq*amel2*ammu2*x6^2*xcp2*e1245-864*ammu*amuq*amel2*ammu2*x6^2*xcp2*e1235-192*ammu*amuq*amel2*ammu2*x6^2*xcp2*e1234+432*ammu*amuq*amel2*ammu2*x6^2*xcp1*e2345-48*ammu*amuq*amel2*ammu2*x6^2*xcp1*e1345+
528*ammu*amuq*amel2*ammu2*x6^2*xcp1*e1245+768*ammu*amuq*amel2*ammu2*x6^2*xcp1*e1235+576*ammu*amuq*amel2*ammu2*x6^2*xcp1*e1234+144*ammu*amuq*amel2*ammu2*x6^3*xcp4*e2345+96*ammu*amuq*amel2*ammu2*x6^3*xcp4*e1345+144*ammu*amuq*amel2*ammu2*x6^3*xcp4*
e1245+192*ammu*amuq*amel2*ammu2*x6^3*xcp4*e1235+192*ammu*amuq*amel2*ammu2*x6^3*xcp4*e1234+144*ammu*amuq*amel2*ammu2*x6^3*xcp3*e2345+96*ammu*amuq*amel2*ammu2*x6^3*xcp3*e1345+144*ammu*amuq*amel2*ammu2*x6^3*xcp3*e1245-576*ammu*amuq*amel2*ammu2*x6^3*
xcp3*e1235-192*ammu*amuq*amel2*ammu2*x6^3*xcp3*e1234-144*ammu*amuq*amel2*ammu2*x6^3*xcp2*e2345-96*ammu*amuq*amel2*ammu2*x6^3*xcp2*e1345-144*ammu*amuq*amel2*ammu2*x6^3*xcp2*e1245+576*ammu*amuq*amel2*ammu2*x6^3*xcp2*e1235+192*ammu*amuq*amel2*ammu2*
x6^3*xcp2*e1234-144*ammu*amuq*amel2*ammu2*x6^3*xcp1*e2345-96*ammu*amuq*amel2*ammu2*x6^3*xcp1*e1345-144*ammu*amuq*amel2*ammu2*x6^3*xcp1*e1245-192*ammu*amuq*amel2*ammu2*x6^3*xcp1*e1235-192*ammu*amuq*amel2*ammu2*x6^3*xcp1*e1234-864*ammu*amuq*amel2*
ammu2*x5*xcp4*e2345-1632*ammu*amuq*amel2*ammu2*x5*xcp4*e1345-1536*ammu*amuq*amel2*ammu2*x5*xcp4*e1245-672*ammu*amuq*amel2*ammu2*x5*xcp4*e1235-48*ammu*amuq*amel2*ammu2*x5*xcp4*e1234+576*ammu*amuq*amel2*ammu2*x5*xcp3*e2345+384*ammu*amuq*amel2*ammu2*
x5*xcp3*e1345+1248*ammu*amuq*amel2*ammu2*x5*xcp3*e1245+1056*ammu*amuq*amel2*ammu2*x5*xcp3*e1235-768*ammu*amuq*amel2*ammu2*x5*xcp3*e1234-576*ammu*amuq*amel2*ammu2*x5*xcp2*e2345-384*ammu*amuq*amel2*ammu2*x5*xcp2*e1345-1248*ammu*amuq*amel2*ammu2*x5*
xcp2*e1245-1056*ammu*amuq*amel2*ammu2*x5*xcp2*e1235+768*ammu*amuq*amel2*ammu2*x5*xcp2*e1234+864*ammu*amuq*amel2*ammu2*x5*xcp1*e2345+1632*ammu*amuq*amel2*ammu2*x5*xcp1*e1345+1536*ammu*amuq*amel2*ammu2*x5*xcp1*e1245+672*ammu*amuq*amel2*ammu2*x5*xcp1*
e1235+48*ammu*amuq*amel2*ammu2*x5*xcp1*e1234-576*ammu*amuq*amel2*ammu2*x5*x6*xcp4*e2345+432*ammu*amuq*amel2*ammu2*x5*x6*xcp4*e1345-1392*ammu*amuq*amel2*ammu2*x5*x6*xcp4*e1245-2112*ammu*amuq*amel2*ammu2*x5*x6*xcp4*e1235-1488*ammu*amuq*amel2*ammu2*x5
*x6*xcp4*e1234-1440*ammu*amuq*amel2*ammu2*x5*x6*xcp3*e2345-1104*ammu*amuq*amel2*ammu2*x5*x6*xcp3*e1345-624*ammu*amuq*amel2*ammu2*x5*x6*xcp3*e1245+1776*ammu*amuq*amel2*ammu2*x5*x6*xcp3*e1235+528*ammu*amuq*amel2*ammu2*x5*x6*xcp3*e1234+1440*ammu*amuq*
amel2*ammu2*x5*x6*xcp2*e2345+1104*ammu*amuq*amel2*ammu2*x5*x6*xcp2*e1345+624*ammu*amuq*amel2*ammu2*x5*x6*xcp2*e1245-1776*ammu*amuq*amel2*ammu2*x5*x6*xcp2*e1235-528*ammu*amuq*amel2*ammu2*x5*x6*xcp2*e1234+576*ammu*amuq*amel2*ammu2*x5*x6*xcp1*e2345-
432*ammu*amuq*amel2*ammu2*x5*x6*xcp1*e1345+1392*ammu*amuq*amel2*ammu2*x5*x6*xcp1*e1245+2112*ammu*amuq*amel2*ammu2*x5*x6*xcp1*e1235+1488*ammu*amuq*amel2*ammu2*x5*x6*xcp1*e1234+288*ammu*amuq*amel2*ammu2*x5*x6^2*xcp4*e2345+144*ammu*amuq*amel2*ammu2*x5
*x6^2*xcp4*e1345+480*ammu*amuq*amel2*ammu2*x5*x6^2*xcp4*e1245+864*ammu*amuq*amel2*ammu2*x5*x6^2*xcp4*e1235+912*ammu*amuq*amel2*ammu2*x5*x6^2*xcp4*e1234+864*ammu*amuq*amel2*ammu2*x5*x6^2*xcp3*e2345+720*ammu*amuq*amel2*ammu2*x5*x6^2*xcp3*e1345+288*
ammu*amuq*amel2*ammu2*x5*x6^2*xcp3*e1245-1824*ammu*amuq*amel2*ammu2*x5*x6^2*xcp3*e1235-240*ammu*amuq*amel2*ammu2*x5*x6^2*xcp3*e1234-864*ammu*amuq*amel2*ammu2*x5*x6^2*xcp2*e2345-720*ammu*amuq*amel2*ammu2*x5*x6^2*xcp2*e1345-288*ammu*amuq*amel2*ammu2*
x5*x6^2*xcp2*e1245+1824*ammu*amuq*amel2*ammu2*x5*x6^2*xcp2*e1235+240*ammu*amuq*amel2*ammu2*x5*x6^2*xcp2*e1234-288*ammu*amuq*amel2*ammu2*x5*x6^2*xcp1*e2345-144*ammu*amuq*amel2*ammu2*x5*x6^2*xcp1*e1345-480*ammu*amuq*amel2*ammu2*x5*x6^2*xcp1*e1245-864
*ammu*amuq*amel2*ammu2*x5*x6^2*xcp1*e1235-912*ammu*amuq*amel2*ammu2*x5*x6^2*xcp1*e1234+864*ammu*amuq*amel2*ammu2*x5^2*xcp4*e2345+1536*ammu*amuq*amel2*ammu2*x5^2*xcp4*e1345-96*ammu*amuq*amel2*ammu2*x5^2*xcp4*e1245-1344*ammu*amuq*amel2*ammu2*x5^2*
xcp4*e1235-816*ammu*amuq*amel2*ammu2*x5^2*xcp4*e1234-1536*ammu*amuq*amel2*ammu2*x5^2*xcp3*e2345-1440*ammu*amuq*amel2*ammu2*x5^2*xcp3*e1345-864*ammu*amuq*amel2*ammu2*x5^2*xcp3*e1245+912*ammu*amuq*amel2*ammu2*x5^2*xcp3*e1235+720*ammu*amuq*amel2*ammu2
*x5^2*xcp3*e1234+1536*ammu*amuq*amel2*ammu2*x5^2*xcp2*e2345+1440*ammu*amuq*amel2*ammu2*x5^2*xcp2*e1345+864*ammu*amuq*amel2*ammu2*x5^2*xcp2*e1245-912*ammu*amuq*amel2*ammu2*x5^2*xcp2*e1235-720*ammu*amuq*amel2*ammu2*x5^2*xcp2*e1234-864*ammu*amuq*amel2
*ammu2*x5^2*xcp1*e2345-1536*ammu*amuq*amel2*ammu2*x5^2*xcp1*e1345+96*ammu*amuq*amel2*ammu2*x5^2*xcp1*e1245+1344*ammu*amuq*amel2*ammu2*x5^2*xcp1*e1235+816*ammu*amuq*amel2*ammu2*x5^2*xcp1*e1234+240*ammu*amuq*amel2*ammu2*x5^2*x6*xcp4*e2345+96*ammu*
amuq*amel2*ammu2*x5^2*x6*xcp4*e1345+912*ammu*amuq*amel2*ammu2*x5^2*x6*xcp4*e1245+1248*ammu*amuq*amel2*ammu2*x5^2*x6*xcp4*e1235+1296*ammu*amuq*amel2*ammu2*x5^2*x6*xcp4*e1234+1392*ammu*amuq*amel2*ammu2*x5^2*x6*xcp3*e2345+1248*ammu*amuq*amel2*ammu2*
x5^2*x6*xcp3*e1345+144*ammu*amuq*amel2*ammu2*x5^2*x6*xcp3*e1245-2208*ammu*amuq*amel2*ammu2*x5^2*x6*xcp3*e1235+336*ammu*amuq*amel2*ammu2*x5^2*x6*xcp3*e1234-1392*ammu*amuq*amel2*ammu2*x5^2*x6*xcp2*e2345-1248*ammu*amuq*amel2*ammu2*x5^2*x6*xcp2*e1345-
144*ammu*amuq*amel2*ammu2*x5^2*x6*xcp2*e1245+2208*ammu*amuq*amel2*ammu2*x5^2*x6*xcp2*e1235-336*ammu*amuq*amel2*ammu2*x5^2*x6*xcp2*e1234-240*ammu*amuq*amel2*ammu2*x5^2*x6*xcp1*e2345-96*ammu*amuq*amel2*ammu2*x5^2*x6*xcp1*e1345-912*ammu*amuq*amel2*
ammu2*x5^2*x6*xcp1*e1245-1248*ammu*amuq*amel2*ammu2*x5^2*x6*xcp1*e1235-1296*ammu*amuq*amel2*ammu2*x5^2*x6*xcp1*e1234-96*ammu*amuq*amel2*ammu2*x5^3*xcp4*e1345+576*ammu*amuq*amel2*ammu2*x5^3*xcp4*e1245+576*ammu*amuq*amel2*ammu2*x5^3*xcp4*e1235+576*
ammu*amuq*amel2*ammu2*x5^3*xcp4*e1234+960*ammu*amuq*amel2*ammu2*x5^3*xcp3*e2345+1056*ammu*amuq*amel2*ammu2*x5^3*xcp3*e1345-960*ammu*amuq*amel2*ammu2*x5^3*xcp3*e1235+384*ammu*amuq*amel2*ammu2*x5^3*xcp3*e1234-960*ammu*amuq*amel2*ammu2*x5^3*xcp2*e2345
-1056*ammu*amuq*amel2*ammu2*x5^3*xcp2*e1345+960*ammu*amuq*amel2*ammu2*x5^3*xcp2*e1235-384*ammu*amuq*amel2*ammu2*x5^3*xcp2*e1234+96*ammu*amuq*amel2*ammu2*x5^3*xcp1*e1345-576*ammu*amuq*amel2*ammu2*x5^3*xcp1*e1245-576*ammu*amuq*amel2*ammu2*x5^3*xcp1*
e1235-576*ammu*amuq*amel2*ammu2*x5^3*xcp1*e1234-1152*ammu*amuq*amel2*ammu2*x4*xcp4*e2345-1152*ammu*amuq*amel2*ammu2*x4*xcp4*e1345-1056*ammu*amuq*amel2*ammu2*x4*xcp4*e1245+864*ammu*amuq*amel2*ammu2*x4*xcp4*e1235+768*ammu*amuq*amel2*ammu2*x4*xcp4*
e1234-48*ammu*amuq*amel2*ammu2*x4*xcp3*e1345-96*ammu*amuq*amel2*ammu2*x4*xcp3*e1245+96*ammu*amuq*amel2*ammu2*x4*xcp3*e1235+48*ammu*amuq*amel2*ammu2*x4*xcp2*e1345+96*ammu*amuq*amel2*ammu2*x4*xcp2*e1245-96*ammu*amuq*amel2*ammu2*x4*xcp2*e1235+1152*
ammu*amuq*amel2*ammu2*x4*xcp1*e2345+1152*ammu*amuq*amel2*ammu2*x4*xcp1*e1345+1056*ammu*amuq*amel2*ammu2*x4*xcp1*e1245-864*ammu*amuq*amel2*ammu2*x4*xcp1*e1235-768*ammu*amuq*amel2*ammu2*x4*xcp1*e1234-480*ammu*amuq*amel2*ammu2*x4*x6*xcp4*e2345+144*
ammu*amuq*amel2*ammu2*x4*x6*xcp4*e1345-1200*ammu*amuq*amel2*ammu2*x4*x6*xcp4*e1245-1632*ammu*amuq*amel2*ammu2*x4*x6*xcp4*e1235-960*ammu*amuq*amel2*ammu2*x4*x6*xcp4*e1234-240*ammu*amuq*amel2*ammu2*x4*x6*xcp3*e2345-240*ammu*amuq*amel2*ammu2*x4*x6*
xcp3*e1345-240*ammu*amuq*amel2*ammu2*x4*x6*xcp3*e1245+1248*ammu*amuq*amel2*ammu2*x4*x6*xcp3*e1235+384*ammu*amuq*amel2*ammu2*x4*x6*xcp3*e1234+240*ammu*amuq*amel2*ammu2*x4*x6*xcp2*e2345+240*ammu*amuq*amel2*ammu2*x4*x6*xcp2*e1345+240*ammu*amuq*amel2*
ammu2*x4*x6*xcp2*e1245-1248*ammu*amuq*amel2*ammu2*x4*x6*xcp2*e1235-384*ammu*amuq*amel2*ammu2*x4*x6*xcp2*e1234+480*ammu*amuq*amel2*ammu2*x4*x6*xcp1*e2345-144*ammu*amuq*amel2*ammu2*x4*x6*xcp1*e1345+1200*ammu*amuq*amel2*ammu2*x4*x6*xcp1*e1245+1632*
ammu*amuq*amel2*ammu2*x4*x6*xcp1*e1235+960*ammu*amuq*amel2*ammu2*x4*x6*xcp1*e1234-144*ammu*amuq*amel2*ammu2*x4*x6^2*xcp4*e2345-144*ammu*amuq*amel2*ammu2*x4*x6^2*xcp4*e1345+240*ammu*amuq*amel2*ammu2*x4*x6^2*xcp4*e1245+528*ammu*amuq*amel2*ammu2*x4*
x6^2*xcp4*e1235+384*ammu*amuq*amel2*ammu2*x4*x6^2*xcp4*e1234+144*ammu*amuq*amel2*ammu2*x4*x6^2*xcp3*e2345+96*ammu*amuq*amel2*ammu2*x4*x6^2*xcp3*e1345+96*ammu*amuq*amel2*ammu2*x4*x6^2*xcp3*e1245-912*ammu*amuq*amel2*ammu2*x4*x6^2*xcp3*e1235-192*ammu*
amuq*amel2*ammu2*x4*x6^2*xcp3*e1234-144*ammu*amuq*amel2*ammu2*x4*x6^2*xcp2*e2345-96*ammu*amuq*amel2*ammu2*x4*x6^2*xcp2*e1345-96*ammu*amuq*amel2*ammu2*x4*x6^2*xcp2*e1245+912*ammu*amuq*amel2*ammu2*x4*x6^2*xcp2*e1235+192*ammu*amuq*amel2*ammu2*x4*x6^2*
xcp2*e1234+144*ammu*amuq*amel2*ammu2*x4*x6^2*xcp1*e2345+144*ammu*amuq*amel2*ammu2*x4*x6^2*xcp1*e1345-240*ammu*amuq*amel2*ammu2*x4*x6^2*xcp1*e1245-528*ammu*amuq*amel2*ammu2*x4*x6^2*xcp1*e1235-384*ammu*amuq*amel2*ammu2*x4*x6^2*xcp1*e1234+1536*ammu*
amuq*amel2*ammu2*x4*x5*xcp4*e2345+2544*ammu*amuq*amel2*ammu2*x4*x5*xcp4*e1345-2976*ammu*amuq*amel2*ammu2*x4*x5*xcp4*e1235-2592*ammu*amuq*amel2*ammu2*x4*x5*xcp4*e1234-576*ammu*amuq*amel2*ammu2*x4*x5*xcp3*e2345-720*ammu*amuq*amel2*ammu2*x4*x5*xcp3*
e1345-336*ammu*amuq*amel2*ammu2*x4*x5*xcp3*e1245+1344*ammu*amuq*amel2*ammu2*x4*x5*xcp3*e1235+336*ammu*amuq*amel2*ammu2*x4*x5*xcp3*e1234+576*ammu*amuq*amel2*ammu2*x4*x5*xcp2*e2345+720*ammu*amuq*amel2*ammu2*x4*x5*xcp2*e1345+336*ammu*amuq*amel2*ammu2*
x4*x5*xcp2*e1245-1344*ammu*amuq*amel2*ammu2*x4*x5*xcp2*e1235-336*ammu*amuq*amel2*ammu2*x4*x5*xcp2*e1234-1536*ammu*amuq*amel2*ammu2*x4*x5*xcp1*e2345-2544*ammu*amuq*amel2*ammu2*x4*x5*xcp1*e1345+2976*ammu*amuq*amel2*ammu2*x4*x5*xcp1*e1235+2592*ammu*
amuq*amel2*ammu2*x4*x5*xcp1*e1234-96*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp4*e2345-144*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp4*e1345+1392*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp4*e1245+1392*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp4*e1235+1008*ammu*amuq*amel2*ammu2*x4
*x5*x6*xcp4*e1234+528*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp3*e2345+528*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp3*e1345+288*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp3*e1245-2592*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp3*e1235-192*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp3*e1234
-528*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp2*e2345-528*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp2*e1345-288*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp2*e1245+2592*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp2*e1235+192*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp2*e1234+96*ammu*amuq*
amel2*ammu2*x4*x5*x6*xcp1*e2345+144*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp1*e1345-1392*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp1*e1245-1392*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp1*e1235-1008*ammu*amuq*amel2*ammu2*x4*x5*x6*xcp1*e1234-240*ammu*amuq*amel2*ammu2*x4*
x5^2*xcp4*e2345-480*ammu*amuq*amel2*ammu2*x4*x5^2*xcp4*e1345+1440*ammu*amuq*amel2*ammu2*x4*x5^2*xcp4*e1245+1008*ammu*amuq*amel2*ammu2*x4*x5^2*xcp4*e1235+768*ammu*amuq*amel2*ammu2*x4*x5^2*xcp4*e1234+1056*ammu*amuq*amel2*ammu2*x4*x5^2*xcp3*e2345+1344
*ammu*amuq*amel2*ammu2*x4*x5^2*xcp3*e1345+480*ammu*amuq*amel2*ammu2*x4*x5^2*xcp3*e1245-2112*ammu*amuq*amel2*ammu2*x4*x5^2*xcp3*e1235+48*ammu*amuq*amel2*ammu2*x4*x5^2*xcp3*e1234-1056*ammu*amuq*amel2*ammu2*x4*x5^2*xcp2*e2345-1344*ammu*amuq*amel2*
ammu2*x4*x5^2*xcp2*e1345-480*ammu*amuq*amel2*ammu2*x4*x5^2*xcp2*e1245+2112*ammu*amuq*amel2*ammu2*x4*x5^2*xcp2*e1235-48*ammu*amuq*amel2*ammu2*x4*x5^2*xcp2*e1234+240*ammu*amuq*amel2*ammu2*x4*x5^2*xcp1*e2345+480*ammu*amuq*amel2*ammu2*x4*x5^2*xcp1*
e1345-1440*ammu*amuq*amel2*ammu2*x4*x5^2*xcp1*e1245-1008*ammu*amuq*amel2*ammu2*x4*x5^2*xcp1*e1235-768*ammu*amuq*amel2*ammu2*x4*x5^2*xcp1*e1234+576*ammu*amuq*amel2*ammu2*x4^2*xcp4*e2345+576*ammu*amuq*amel2*ammu2*x4^2*xcp4*e1345-240*ammu*amuq*amel2*
ammu2*x4^2*xcp4*e1245-1200*ammu*amuq*amel2*ammu2*x4^2*xcp4*e1235-768*ammu*amuq*amel2*ammu2*x4^2*xcp4*e1234+48*ammu*amuq*amel2*ammu2*x4^2*xcp3*e1345+48*ammu*amuq*amel2*ammu2*x4^2*xcp3*e1245+528*ammu*amuq*amel2*ammu2*x4^2*xcp3*e1235-48*ammu*amuq*
amel2*ammu2*x4^2*xcp2*e1345-48*ammu*amuq*amel2*ammu2*x4^2*xcp2*e1245-528*ammu*amuq*amel2*ammu2*x4^2*xcp2*e1235-576*ammu*amuq*amel2*ammu2*x4^2*xcp1*e2345-576*ammu*amuq*amel2*ammu2*x4^2*xcp1*e1345+240*ammu*amuq*amel2*ammu2*x4^2*xcp1*e1245+1200*ammu*
amuq*amel2*ammu2*x4^2*xcp1*e1235+768*ammu*amuq*amel2*ammu2*x4^2*xcp1*e1234-48*ammu*amuq*amel2*ammu2*x4^2*x6*xcp4*e1345+336*ammu*amuq*amel2*ammu2*x4^2*x6*xcp4*e1245+240*ammu*amuq*amel2*ammu2*x4^2*x6*xcp4*e1235+192*ammu*amuq*amel2*ammu2*x4^2*x6*xcp4*
e1234+48*ammu*amuq*amel2*ammu2*x4^2*x6*xcp3*e1345-48*ammu*amuq*amel2*ammu2*x4^2*x6*xcp3*e1245-384*ammu*amuq*amel2*ammu2*x4^2*x6*xcp3*e1235-48*ammu*amuq*amel2*ammu2*x4^2*x6*xcp2*e1345+48*ammu*amuq*amel2*ammu2*x4^2*x6*xcp2*e1245+384*ammu*amuq*amel2*
ammu2*x4^2*x6*xcp2*e1235+48*ammu*amuq*amel2*ammu2*x4^2*x6*xcp1*e1345-336*ammu*amuq*amel2*ammu2*x4^2*x6*xcp1*e1245-240*ammu*amuq*amel2*ammu2*x4^2*x6*xcp1*e1235-192*ammu*amuq*amel2*ammu2*x4^2*x6*xcp1*e1234-192*ammu*amuq*amel2*ammu2*x4^2*x5*xcp4*e2345
-432*ammu*amuq*amel2*ammu2*x4^2*x5*xcp4*e1345+960*ammu*amuq*amel2*ammu2*x4^2*x5*xcp4*e1245+480*ammu*amuq*amel2*ammu2*x4^2*x5*xcp4*e1235+288*ammu*amuq*amel2*ammu2*x4^2*x5*xcp4*e1234+192*ammu*amuq*amel2*ammu2*x4^2*x5*xcp3*e2345+192*ammu*amuq*amel2*
ammu2*x4^2*x5*xcp3*e1345+384*ammu*amuq*amel2*ammu2*x4^2*x5*xcp3*e1245-1392*ammu*amuq*amel2*ammu2*x4^2*x5*xcp3*e1235-96*ammu*amuq*amel2*ammu2*x4^2*x5*xcp3*e1234-192*ammu*amuq*amel2*ammu2*x4^2*x5*xcp2*e2345-192*ammu*amuq*amel2*ammu2*x4^2*x5*xcp2*
e1345-384*ammu*amuq*amel2*ammu2*x4^2*x5*xcp2*e1245+1392*ammu*amuq*amel2*ammu2*x4^2*x5*xcp2*e1235+96*ammu*amuq*amel2*ammu2*x4^2*x5*xcp2*e1234+192*ammu*amuq*amel2*ammu2*x4^2*x5*xcp1*e2345+432*ammu*amuq*amel2*ammu2*x4^2*x5*xcp1*e1345-960*ammu*amuq*
amel2*ammu2*x4^2*x5*xcp1*e1245-480*ammu*amuq*amel2*ammu2*x4^2*x5*xcp1*e1235-288*ammu*amuq*amel2*ammu2*x4^2*x5*xcp1*e1234+144*ammu*amuq*amel2*ammu2*x4^3*xcp4*e1245+96*ammu*amuq*amel2*ammu2*x4^3*xcp4*e1235+48*ammu*amuq*amel2*ammu2*x4^3*xcp3*e1245-144
*ammu*amuq*amel2*ammu2*x4^3*xcp3*e1235-48*ammu*amuq*amel2*ammu2*x4^3*xcp2*e1245+144*ammu*amuq*amel2*ammu2*x4^3*xcp2*e1235-144*ammu*amuq*amel2*ammu2*x4^3*xcp1*e1245-96*ammu*amuq*amel2*ammu2*x4^3*xcp1*e1235+384*ammu*amuq*amel2*ammu2*x3*xcp4*e1245+
2256*ammu*amuq*amel2*ammu2*x3*xcp4*e1235+1536*ammu*amuq*amel2*ammu2*x3*xcp4*e1234-384*ammu*amuq*amel2*ammu2*x3*xcp3*e1245-912*ammu*amuq*amel2*ammu2*x3*xcp3*e1235+384*ammu*amuq*amel2*ammu2*x3*xcp2*e1245+912*ammu*amuq*amel2*ammu2*x3*xcp2*e1235-384*
ammu*amuq*amel2*ammu2*x3*xcp1*e1245-2256*ammu*amuq*amel2*ammu2*x3*xcp1*e1235-1536*ammu*amuq*amel2*ammu2*x3*xcp1*e1234-768*ammu*amuq*amel2*ammu2*x3*x6*xcp4*e2345-96*ammu*amuq*amel2*ammu2*x3*x6*xcp4*e1345-960*ammu*amuq*amel2*ammu2*x3*x6*xcp4*e1245-
912*ammu*amuq*amel2*ammu2*x3*x6*xcp4*e1235-768*ammu*amuq*amel2*ammu2*x3*x6*xcp4*e1234-96*ammu*amuq*amel2*ammu2*x3*x6*xcp3*e1245+1392*ammu*amuq*amel2*ammu2*x3*x6*xcp3*e1235+384*ammu*amuq*amel2*ammu2*x3*x6*xcp3*e1234+96*ammu*amuq*amel2*ammu2*x3*x6*
xcp2*e1245-1392*ammu*amuq*amel2*ammu2*x3*x6*xcp2*e1235-384*ammu*amuq*amel2*ammu2*x3*x6*xcp2*e1234+768*ammu*amuq*amel2*ammu2*x3*x6*xcp1*e2345+96*ammu*amuq*amel2*ammu2*x3*x6*xcp1*e1345+960*ammu*amuq*amel2*ammu2*x3*x6*xcp1*e1245+912*ammu*amuq*amel2*
ammu2*x3*x6*xcp1*e1235+768*ammu*amuq*amel2*ammu2*x3*x6*xcp1*e1234+192*ammu*amuq*amel2*ammu2*x3*x6^2*xcp4*e1245+192*ammu*amuq*amel2*ammu2*x3*x6^2*xcp4*e1235+192*ammu*amuq*amel2*ammu2*x3*x6^2*xcp4*e1234-48*ammu*amuq*amel2*ammu2*x3*x6^2*xcp3*e1345+144
*ammu*amuq*amel2*ammu2*x3*x6^2*xcp3*e1245-576*ammu*amuq*amel2*ammu2*x3*x6^2*xcp3*e1235-192*ammu*amuq*amel2*ammu2*x3*x6^2*xcp3*e1234+48*ammu*amuq*amel2*ammu2*x3*x6^2*xcp2*e1345-144*ammu*amuq*amel2*ammu2*x3*x6^2*xcp2*e1245+576*ammu*amuq*amel2*ammu2*
x3*x6^2*xcp2*e1235+192*ammu*amuq*amel2*ammu2*x3*x6^2*xcp2*e1234-192*ammu*amuq*amel2*ammu2*x3*x6^2*xcp1*e1245-192*ammu*amuq*amel2*ammu2*x3*x6^2*xcp1*e1235-192*ammu*amuq*amel2*ammu2*x3*x6^2*xcp1*e1234-768*ammu*amuq*amel2*ammu2*x3*x5*xcp4*e2345-1584*
ammu*amuq*amel2*ammu2*x3*x5*xcp4*e1245-2352*ammu*amuq*amel2*ammu2*x3*x5*xcp4*e1235-2016*ammu*amuq*amel2*ammu2*x3*x5*xcp4*e1234+240*ammu*amuq*amel2*ammu2*x3*x5*xcp3*e1245+1872*ammu*amuq*amel2*ammu2*x3*x5*xcp3*e1235-96*ammu*amuq*amel2*ammu2*x3*x5*
xcp3*e1234-240*ammu*amuq*amel2*ammu2*x3*x5*xcp2*e1245-1872*ammu*amuq*amel2*ammu2*x3*x5*xcp2*e1235+96*ammu*amuq*amel2*ammu2*x3*x5*xcp2*e1234+768*ammu*amuq*amel2*ammu2*x3*x5*xcp1*e2345+1584*ammu*amuq*amel2*ammu2*x3*x5*xcp1*e1245+2352*ammu*amuq*amel2*
ammu2*x3*x5*xcp1*e1235+2016*ammu*amuq*amel2*ammu2*x3*x5*xcp1*e1234-48*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp4*e1345+432*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp4*e1245+576*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp4*e1235+576*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp4*
e1234+48*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp3*e1345+144*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp3*e1245-1296*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp3*e1235-144*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp3*e1234-48*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp2*e1345-144*ammu*amuq
*amel2*ammu2*x3*x5*x6*xcp2*e1245+1296*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp2*e1235+144*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp2*e1234+48*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp1*e1345-432*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp1*e1245-576*ammu*amuq*amel2*ammu2*x3*x5
*x6*xcp1*e1235-576*ammu*amuq*amel2*ammu2*x3*x5*x6*xcp1*e1234-96*ammu*amuq*amel2*ammu2*x3*x5^2*xcp4*e1345+624*ammu*amuq*amel2*ammu2*x3*x5^2*xcp4*e1245+528*ammu*amuq*amel2*ammu2*x3*x5^2*xcp4*e1235+528*ammu*amuq*amel2*ammu2*x3*x5^2*xcp4*e1234-1152*
ammu*amuq*amel2*ammu2*x3*x5^2*xcp3*e1235+1152*ammu*amuq*amel2*ammu2*x3*x5^2*xcp2*e1235+96*ammu*amuq*amel2*ammu2*x3*x5^2*xcp1*e1345-624*ammu*amuq*amel2*ammu2*x3*x5^2*xcp1*e1245-528*ammu*amuq*amel2*ammu2*x3*x5^2*xcp1*e1235-528*ammu*amuq*amel2*ammu2*
x3*x5^2*xcp1*e1234-1200*ammu*amuq*amel2*ammu2*x3*x4*xcp4*e1245-1536*ammu*amuq*amel2*ammu2*x3*x4*xcp4*e1235-768*ammu*amuq*amel2*ammu2*x3*x4*xcp4*e1234+48*ammu*amuq*amel2*ammu2*x3*x4*xcp3*e1345+48*ammu*amuq*amel2*ammu2*x3*x4*xcp3*e1245+912*ammu*amuq*
amel2*ammu2*x3*x4*xcp3*e1235-48*ammu*amuq*amel2*ammu2*x3*x4*xcp2*e1345-48*ammu*amuq*amel2*ammu2*x3*x4*xcp2*e1245-912*ammu*amuq*amel2*ammu2*x3*x4*xcp2*e1235+1200*ammu*amuq*amel2*ammu2*x3*x4*xcp1*e1245+1536*ammu*amuq*amel2*ammu2*x3*x4*xcp1*e1235+768*
ammu*amuq*amel2*ammu2*x3*x4*xcp1*e1234-48*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp4*e1345+240*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp4*e1245+192*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp4*e1235+192*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp4*e1234+48*ammu*amuq*amel2*ammu2*
x3*x4*x6*xcp3*e1345-48*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp3*e1245-336*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp3*e1235-48*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp2*e1345+48*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp2*e1245+336*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp2*e1235+
48*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp1*e1345-240*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp1*e1245-192*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp1*e1235-192*ammu*amuq*amel2*ammu2*x3*x4*x6*xcp1*e1234-144*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp4*e1345+912*ammu*amuq*amel2
*ammu2*x3*x4*x5*xcp4*e1245+384*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp4*e1235+240*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp4*e1234-96*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp3*e1345+432*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp3*e1245-1200*ammu*amuq*amel2*ammu2*x3*x4*x5*
xcp3*e1235-48*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp3*e1234+96*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp2*e1345-432*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp2*e1245+1200*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp2*e1235+48*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp2*e1234+144*ammu*
amuq*amel2*ammu2*x3*x4*x5*xcp1*e1345-912*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp1*e1245-384*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp1*e1235-240*ammu*amuq*amel2*ammu2*x3*x4*x5*xcp1*e1234+96*ammu*amuq*amel2*ammu2*x3*x4^2*xcp4*e1245+48*ammu*amuq*amel2*ammu2*x3*
x4^2*xcp4*e1235+96*ammu*amuq*amel2*ammu2*x3*x4^2*xcp3*e1245-144*ammu*amuq*amel2*ammu2*x3*x4^2*xcp3*e1235-96*ammu*amuq*amel2*ammu2*x3*x4^2*xcp2*e1245+144*ammu*amuq*amel2*ammu2*x3*x4^2*xcp2*e1235-96*ammu*amuq*amel2*ammu2*x3*x4^2*xcp1*e1245-48*ammu*
amuq*amel2*ammu2*x3*x4^2*xcp1*e1235-384*ammu*amuq*amel2*ammu2*x3^2*xcp4*e1245+48*ammu*amuq*amel2*ammu2*x3^2*xcp4*e1235+48*ammu*amuq*amel2*ammu2*x3^2*xcp3*e1235-48*ammu*amuq*amel2*ammu2*x3^2*xcp2*e1235+384*ammu*amuq*amel2*ammu2*x3^2*xcp1*e1245-48*
ammu*amuq*amel2*ammu2*x3^2*xcp1*e1235+96*ammu*amuq*amel2*ammu2*x3^2*x6*xcp4*e1245-96*ammu*amuq*amel2*ammu2*x3^2*x6*xcp1*e1245+48*ammu*amuq*amel2*ammu2*x3^2*x5*xcp4*e1245-48*ammu*amuq*amel2*ammu2*x3^2*x5*xcp4*e1235-48*ammu*amuq*amel2*ammu2*x3^2*x5*
xcp4*e1234+144*ammu*amuq*amel2*ammu2*x3^2*x5*xcp3*e1245+48*ammu*amuq*amel2*ammu2*x3^2*x5*xcp3*e1235+48*ammu*amuq*amel2*ammu2*x3^2*x5*xcp3*e1234-144*ammu*amuq*amel2*ammu2*x3^2*x5*xcp2*e1245-48*ammu*amuq*amel2*ammu2*x3^2*x5*xcp2*e1235-48*ammu*amuq*
amel2*ammu2*x3^2*x5*xcp2*e1234-48*ammu*amuq*amel2*ammu2*x3^2*x5*xcp1*e1245+48*ammu*amuq*amel2*ammu2*x3^2*x5*xcp1*e1235+48*ammu*amuq*amel2*ammu2*x3^2*x5*xcp1*e1234-48*ammu*amuq*amel2*ammu2*x3^2*x4*xcp4*e1245-48*ammu*amuq*amel2*ammu2*x3^2*x4*xcp4*
e1235+48*ammu*amuq*amel2*ammu2*x3^2*x4*xcp3*e1245-48*ammu*amuq*amel2*ammu2*x3^2*x4*xcp2*e1245+48*ammu*amuq*amel2*ammu2*x3^2*x4*xcp1*e1245+48*ammu*amuq*amel2*ammu2*x3^2*x4*xcp1*e1235+192*ammu*amuq*amel2*ammu2*x1*xcp4*e2345+672*ammu*amuq*amel2*ammu2*
x1*xcp4*e1245+2112*ammu*amuq*amel2*ammu2*x1*xcp4*e1235+1536*ammu*amuq*amel2*ammu2*x1*xcp4*e1234-96*ammu*amuq*amel2*ammu2*x1*xcp3*e2345-480*ammu*amuq*amel2*ammu2*x1*xcp3*e1245-816*ammu*amuq*amel2*ammu2*x1*xcp3*e1235+96*ammu*amuq*amel2*ammu2*x1*xcp2*
e2345+480*ammu*amuq*amel2*ammu2*x1*xcp2*e1245+816*ammu*amuq*amel2*ammu2*x1*xcp2*e1235-192*ammu*amuq*amel2*ammu2*x1*xcp1*e2345-672*ammu*amuq*amel2*ammu2*x1*xcp1*e1245-2112*ammu*amuq*amel2*ammu2*x1*xcp1*e1235-1536*ammu*amuq*amel2*ammu2*x1*xcp1*e1234+
192*ammu*amuq*amel2*ammu2*x1*x6*xcp4*e2345+768*ammu*amuq*amel2*ammu2*x1*x6*xcp4*e1345-240*ammu*amuq*amel2*ammu2*x1*x6*xcp4*e1245-1008*ammu*amuq*amel2*ammu2*x1*x6*xcp4*e1235-768*ammu*amuq*amel2*ammu2*x1*x6*xcp4*e1234-96*ammu*amuq*amel2*ammu2*x1*x6*
xcp3*e2345-96*ammu*amuq*amel2*ammu2*x1*x6*xcp3*e1245+1392*ammu*amuq*amel2*ammu2*x1*x6*xcp3*e1235+384*ammu*amuq*amel2*ammu2*x1*x6*xcp3*e1234+96*ammu*amuq*amel2*ammu2*x1*x6*xcp2*e2345+96*ammu*amuq*amel2*ammu2*x1*x6*xcp2*e1245-1392*ammu*amuq*amel2*
ammu2*x1*x6*xcp2*e1235-384*ammu*amuq*amel2*ammu2*x1*x6*xcp2*e1234-192*ammu*amuq*amel2*ammu2*x1*x6*xcp1*e2345-768*ammu*amuq*amel2*ammu2*x1*x6*xcp1*e1345+240*ammu*amuq*amel2*ammu2*x1*x6*xcp1*e1245+1008*ammu*amuq*amel2*ammu2*x1*x6*xcp1*e1235+768*ammu*
amuq*amel2*ammu2*x1*x6*xcp1*e1234+48*ammu*amuq*amel2*ammu2*x1*x6^2*xcp4*e2345+96*ammu*amuq*amel2*ammu2*x1*x6^2*xcp4*e1245+192*ammu*amuq*amel2*ammu2*x1*x6^2*xcp4*e1235+192*ammu*amuq*amel2*ammu2*x1*x6^2*xcp4*e1234+48*ammu*amuq*amel2*ammu2*x1*x6^2*
xcp3*e2345+144*ammu*amuq*amel2*ammu2*x1*x6^2*xcp3*e1245-576*ammu*amuq*amel2*ammu2*x1*x6^2*xcp3*e1235-192*ammu*amuq*amel2*ammu2*x1*x6^2*xcp3*e1234-48*ammu*amuq*amel2*ammu2*x1*x6^2*xcp2*e2345-144*ammu*amuq*amel2*ammu2*x1*x6^2*xcp2*e1245+576*ammu*amuq
*amel2*ammu2*x1*x6^2*xcp2*e1235+192*ammu*amuq*amel2*ammu2*x1*x6^2*xcp2*e1234-48*ammu*amuq*amel2*ammu2*x1*x6^2*xcp1*e2345-96*ammu*amuq*amel2*ammu2*x1*x6^2*xcp1*e1245-192*ammu*amuq*amel2*ammu2*x1*x6^2*xcp1*e1235-192*ammu*amuq*amel2*ammu2*x1*x6^2*xcp1
*e1234+288*ammu*amuq*amel2*ammu2*x1*x5*xcp4*e2345+768*ammu*amuq*amel2*ammu2*x1*x5*xcp4*e1345-768*ammu*amuq*amel2*ammu2*x1*x5*xcp4*e1245-2256*ammu*amuq*amel2*ammu2*x1*x5*xcp4*e1235-1824*ammu*amuq*amel2*ammu2*x1*x5*xcp4*e1234-96*ammu*amuq*amel2*ammu2
*x1*x5*xcp3*e2345+144*ammu*amuq*amel2*ammu2*x1*x5*xcp3*e1245+1728*ammu*amuq*amel2*ammu2*x1*x5*xcp3*e1235-240*ammu*amuq*amel2*ammu2*x1*x5*xcp3*e1234+96*ammu*amuq*amel2*ammu2*x1*x5*xcp2*e2345-144*ammu*amuq*amel2*ammu2*x1*x5*xcp2*e1245-1728*ammu*amuq*
amel2*ammu2*x1*x5*xcp2*e1235+240*ammu*amuq*amel2*ammu2*x1*x5*xcp2*e1234-288*ammu*amuq*amel2*ammu2*x1*x5*xcp1*e2345-768*ammu*amuq*amel2*ammu2*x1*x5*xcp1*e1345+768*ammu*amuq*amel2*ammu2*x1*x5*xcp1*e1245+2256*ammu*amuq*amel2*ammu2*x1*x5*xcp1*e1235+
1824*ammu*amuq*amel2*ammu2*x1*x5*xcp1*e1234+48*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp4*e2345+192*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp4*e1245+768*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp4*e1235+768*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp4*e1234+240*ammu*amuq*amel2*
ammu2*x1*x5*x6*xcp3*e2345+288*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp3*e1245-1200*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp3*e1235-48*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp3*e1234-240*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp2*e2345-288*ammu*amuq*amel2*ammu2*x1*x5*x6*
xcp2*e1245+1200*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp2*e1235+48*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp2*e1234-48*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp1*e2345-192*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp1*e1245-768*ammu*amuq*amel2*ammu2*x1*x5*x6*xcp1*e1235-768*ammu
*amuq*amel2*ammu2*x1*x5*x6*xcp1*e1234+480*ammu*amuq*amel2*ammu2*x1*x5^2*xcp4*e1245+672*ammu*amuq*amel2*ammu2*x1*x5^2*xcp4*e1235+672*ammu*amuq*amel2*ammu2*x1*x5^2*xcp4*e1234+192*ammu*amuq*amel2*ammu2*x1*x5^2*xcp3*e2345+144*ammu*amuq*amel2*ammu2*x1*
x5^2*xcp3*e1245-912*ammu*amuq*amel2*ammu2*x1*x5^2*xcp3*e1235+240*ammu*amuq*amel2*ammu2*x1*x5^2*xcp3*e1234-192*ammu*amuq*amel2*ammu2*x1*x5^2*xcp2*e2345-144*ammu*amuq*amel2*ammu2*x1*x5^2*xcp2*e1245+912*ammu*amuq*amel2*ammu2*x1*x5^2*xcp2*e1235-240*
ammu*amuq*amel2*ammu2*x1*x5^2*xcp2*e1234-480*ammu*amuq*amel2*ammu2*x1*x5^2*xcp1*e1245-672*ammu*amuq*amel2*ammu2*x1*x5^2*xcp1*e1235-672*ammu*amuq*amel2*ammu2*x1*x5^2*xcp1*e1234-432*ammu*amuq*amel2*ammu2*x1*x4*xcp4*e1245-1440*ammu*amuq*amel2*ammu2*x1
*x4*xcp4*e1235-768*ammu*amuq*amel2*ammu2*x1*x4*xcp4*e1234+48*ammu*amuq*amel2*ammu2*x1*x4*xcp3*e2345+48*ammu*amuq*amel2*ammu2*x1*x4*xcp3*e1245+720*ammu*amuq*amel2*ammu2*x1*x4*xcp3*e1235-48*ammu*amuq*amel2*ammu2*x1*x4*xcp2*e2345-48*ammu*amuq*amel2*
ammu2*x1*x4*xcp2*e1245-720*ammu*amuq*amel2*ammu2*x1*x4*xcp2*e1235+432*ammu*amuq*amel2*ammu2*x1*x4*xcp1*e1245+1440*ammu*amuq*amel2*ammu2*x1*x4*xcp1*e1235+768*ammu*amuq*amel2*ammu2*x1*x4*xcp1*e1234-48*ammu*amuq*amel2*ammu2*x1*x4*x6*xcp4*e2345+384*
ammu*amuq*amel2*ammu2*x1*x4*x6*xcp4*e1235+192*ammu*amuq*amel2*ammu2*x1*x4*x6*xcp4*e1234+48*ammu*amuq*amel2*ammu2*x1*x4*x6*xcp3*e2345-336*ammu*amuq*amel2*ammu2*x1*x4*x6*xcp3*e1235-48*ammu*amuq*amel2*ammu2*x1*x4*x6*xcp2*e2345+336*ammu*amuq*amel2*
ammu2*x1*x4*x6*xcp2*e1235+48*ammu*amuq*amel2*ammu2*x1*x4*x6*xcp1*e2345-384*ammu*amuq*amel2*ammu2*x1*x4*x6*xcp1*e1235-192*ammu*amuq*amel2*ammu2*x1*x4*x6*xcp1*e1234-48*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp4*e2345+768*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp4*
e1245+576*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp4*e1235+288*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp4*e1234+96*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp3*e2345+192*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp3*e1245-1104*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp3*e1235-96*ammu*amuq
*amel2*ammu2*x1*x4*x5*xcp3*e1234-96*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp2*e2345-192*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp2*e1245+1104*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp2*e1235+96*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp2*e1234+48*ammu*amuq*amel2*ammu2*x1*x4*
x5*xcp1*e2345-768*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp1*e1245-576*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp1*e1235-288*ammu*amuq*amel2*ammu2*x1*x4*x5*xcp1*e1234+192*ammu*amuq*amel2*ammu2*x1*x4^2*xcp4*e1245+96*ammu*amuq*amel2*ammu2*x1*x4^2*xcp4*e1235-96*ammu
*amuq*amel2*ammu2*x1*x4^2*xcp3*e1235+96*ammu*amuq*amel2*ammu2*x1*x4^2*xcp2*e1235-192*ammu*amuq*amel2*ammu2*x1*x4^2*xcp1*e1245-96*ammu*amuq*amel2*ammu2*x1*x4^2*xcp1*e1235+384*ammu*amuq*amel2*ammu2*x1^2*xcp4*e1245-48*ammu*amuq*amel2*ammu2*x1^2*xcp4*
e1235-48*ammu*amuq*amel2*ammu2*x1^2*xcp3*e1245+48*ammu*amuq*amel2*ammu2*x1^2*xcp2*e1245-384*ammu*amuq*amel2*ammu2*x1^2*xcp1*e1245+48*ammu*amuq*amel2*ammu2*x1^2*xcp1*e1235-48*ammu*amuq*amel2*ammu2*x1^2*x6*xcp4*e1245+48*ammu*amuq*amel2*ammu2*x1^2*x6*
xcp1*e1245-96*ammu*amuq*amel2*ammu2*x1^2*x5*xcp4*e1245+96*ammu*amuq*amel2*ammu2*x1^2*x5*xcp4*e1235+96*ammu*amuq*amel2*ammu2*x1^2*x5*xcp4*e1234+144*ammu*amuq*amel2*ammu2*x1^2*x5*xcp3*e1245+48*ammu*amuq*amel2*ammu2*x1^2*x5*xcp3*e1235+48*ammu*amuq*
amel2*ammu2*x1^2*x5*xcp3*e1234-144*ammu*amuq*amel2*ammu2*x1^2*x5*xcp2*e1245-48*ammu*amuq*amel2*ammu2*x1^2*x5*xcp2*e1235-48*ammu*amuq*amel2*ammu2*x1^2*x5*xcp2*e1234+96*ammu*amuq*amel2*ammu2*x1^2*x5*xcp1*e1245-96*ammu*amuq*amel2*ammu2*x1^2*x5*xcp1*
e1235-96*ammu*amuq*amel2*ammu2*x1^2*x5*xcp1*e1234-48*ammu*amuq*amel2*ammu2*x1^2*x4*xcp4*e1245+96*ammu*amuq*amel2*ammu2*x1^2*x4*xcp4*e1235+48*ammu*amuq*amel2*ammu2*x1^2*x4*xcp3*e1245-48*ammu*amuq*amel2*ammu2*x1^2*x4*xcp2*e1245+48*ammu*amuq*amel2*
ammu2*x1^2*x4*xcp1*e1245-96*ammu*amuq*amel2*ammu2*x1^2*x4*xcp1*e1235-768*ammu*amuq*amel2*ammu2^2*amuq2*x6*xcp4-768*ammu*amuq*amel2*ammu2^2*amuq2*x6*xcp3-768*ammu*amuq*amel2*ammu2^2*amuq2*x6*xcp2-768*ammu*amuq*amel2*ammu2^2*amuq2*x6*xcp1+384*ammu*
amuq*amel2*ammu2^2*amuq2*x6^2*xcp4+384*ammu*amuq*amel2*ammu2^2*amuq2*x6^2*xcp3+384*ammu*amuq*amel2*ammu2^2*amuq2*x6^2*xcp2+384*ammu*amuq*amel2*ammu2^2*amuq2*x6^2*xcp1-768*ammu*amuq*amel2*ammu2^2*amuq2*x5*xcp4-768*ammu*amuq*amel2*ammu2^2*amuq2*x5*
xcp3-768*ammu*amuq*amel2*ammu2^2*amuq2*x5*xcp2-768*ammu*amuq*amel2*ammu2^2*amuq2*x5*xcp1+1152*ammu*amuq*amel2*ammu2^2*amuq2*x5*x6*xcp4+1152*ammu*amuq*amel2*ammu2^2*amuq2*x5*x6*xcp3+1152*ammu*amuq*amel2*ammu2^2*amuq2*x5*x6*xcp2+1152*ammu*amuq*amel2*
ammu2^2*amuq2*x5*x6*xcp1+768*ammu*amuq*amel2*ammu2^2*amuq2*x5^2*xcp4+768*ammu*amuq*amel2*ammu2^2*amuq2*x5^2*xcp3+768*ammu*amuq*amel2*ammu2^2*amuq2*x5^2*xcp2+768*ammu*amuq*amel2*ammu2^2*amuq2*x5^2*xcp1+384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x6*xcp4+
384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x6*xcp3+384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x6*xcp2+384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x6*xcp1-384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x6^2*xcp4+384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x6^2*xcp3+384*ammu*amuq*amel2
*ammu2^2*amuq2*x4*x6^2*xcp2-384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x6^2*xcp1+384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x5*xcp4+384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x5*xcp3+384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x5*xcp2+384*ammu*amuq*amel2*ammu2^2*amuq2*x4*
x5*xcp1-384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x5*x6*xcp4+384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x5*x6*xcp3+384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x5*x6*xcp2-384*ammu*amuq*amel2*ammu2^2*amuq2*x4*x5*x6*xcp1-2304*ammu*amuq*amel2*ammu2^3*x6*xcp4-768*ammu*
amuq*amel2*ammu2^3*x6*xcp3-768*ammu*amuq*amel2*ammu2^3*x6*xcp2-2304*ammu*amuq*amel2*ammu2^3*x6*xcp1+1920*ammu*amuq*amel2*ammu2^3*x6^2*xcp4+384*ammu*amuq*amel2*ammu2^3*x6^2*xcp3+384*ammu*amuq*amel2*ammu2^3*x6^2*xcp2+1920*ammu*amuq*amel2*ammu2^3*x6^2
*xcp1-384*ammu*amuq*amel2*ammu2^3*x6^3*xcp4-384*ammu*amuq*amel2*ammu2^3*x6^3*xcp1-2304*ammu*amuq*amel2*ammu2^3*x5*xcp4-768*ammu*amuq*amel2*ammu2^3*x5*xcp3-768*ammu*amuq*amel2*ammu2^3*x5*xcp2-2304*ammu*amuq*amel2*ammu2^3*x5*xcp1+5760*ammu*amuq*amel2
*ammu2^3*x5*x6*xcp4+1152*ammu*amuq*amel2*ammu2^3*x5*x6*xcp3+1152*ammu*amuq*amel2*ammu2^3*x5*x6*xcp2+5760*ammu*amuq*amel2*ammu2^3*x5*x6*xcp1-1920*ammu*amuq*amel2*ammu2^3*x5*x6^2*xcp4-1920*ammu*amuq*amel2*ammu2^3*x5*x6^2*xcp1+3840*ammu*amuq*amel2*
ammu2^3*x5^2*xcp4+768*ammu*amuq*amel2*ammu2^3*x5^2*xcp3+768*ammu*amuq*amel2*ammu2^3*x5^2*xcp2+3840*ammu*amuq*amel2*ammu2^3*x5^2*xcp1-3072*ammu*amuq*amel2*ammu2^3*x5^2*x6*xcp4-3072*ammu*amuq*amel2*ammu2^3*x5^2*x6*xcp1-1536*ammu*amuq*amel2*ammu2^3*
x5^3*xcp4-1536*ammu*amuq*amel2*ammu2^3*x5^3*xcp1+1920*ammu*amuq*amel2*ammu2^3*x4*x6*xcp4+384*ammu*amuq*amel2*ammu2^3*x4*x6*xcp3+384*ammu*amuq*amel2*ammu2^3*x4*x6*xcp2+1920*ammu*amuq*amel2*ammu2^3*x4*x6*xcp1-384*ammu*amuq*amel2*ammu2^3*x4*x6^2*xcp4-
384*ammu*amuq*amel2*ammu2^3*x4*x6^2*xcp3-384*ammu*amuq*amel2*ammu2^3*x4*x6^2*xcp2-384*ammu*amuq*amel2*ammu2^3*x4*x6^2*xcp1+1920*ammu*amuq*amel2*ammu2^3*x4*x5*xcp4+384*ammu*amuq*amel2*ammu2^3*x4*x5*xcp3+384*ammu*amuq*amel2*ammu2^3*x4*x5*xcp2+1920*
ammu*amuq*amel2*ammu2^3*x4*x5*xcp1-1920*ammu*amuq*amel2*ammu2^3*x4*x5*x6*xcp4-384*ammu*amuq*amel2*ammu2^3*x4*x5*x6*xcp3-384*ammu*amuq*amel2*ammu2^3*x4*x5*x6*xcp2-1920*ammu*amuq*amel2*ammu2^3*x4*x5*x6*xcp1-1536*ammu*amuq*amel2*ammu2^3*x4*x5^2*xcp4-
1536*ammu*amuq*amel2*ammu2^3*x4*x5^2*xcp1-384*ammu*amuq*amel2*ammu2^3*x4^2*x6*xcp4-384*ammu*amuq*amel2*ammu2^3*x4^2*x6*xcp1-384*ammu*amuq*amel2*ammu2^3*x4^2*x5*xcp4-384*ammu*amuq*amel2*ammu2^3*x4^2*x5*xcp1-384*ammu*amuq*amel2^2*xcp4*e2345-288*ammu*
amuq*amel2^2*xcp4*e1345+1632*ammu*amuq*amel2^2*xcp4*e1235+1536*ammu*amuq*amel2^2*xcp4*e1234+384*ammu*amuq*amel2^2*xcp3*e1345+1152*ammu*amuq*amel2^2*xcp3*e1235-384*ammu*amuq*amel2^2*xcp2*e1345-1152*ammu*amuq*amel2^2*xcp2*e1235+384*ammu*amuq*amel2^2*
xcp1*e2345+288*ammu*amuq*amel2^2*xcp1*e1345-1632*ammu*amuq*amel2^2*xcp1*e1235-1536*ammu*amuq*amel2^2*xcp1*e1234+240*ammu*amuq*amel2^2*x6*xcp4*e2345+144*ammu*amuq*amel2^2*x6*xcp4*e1345-192*ammu*amuq*amel2^2*x6*xcp4*e1245+192*ammu*amuq*amel2^2*x6*
xcp4*e1235+192*ammu*amuq*amel2^2*x6*xcp4*e1234-240*ammu*amuq*amel2^2*x6*xcp3*e2345-48*ammu*amuq*amel2^2*x6*xcp3*e1345-192*ammu*amuq*amel2^2*x6*xcp3*e1245+912*ammu*amuq*amel2^2*x6*xcp3*e1235+192*ammu*amuq*amel2^2*x6*xcp3*e1234+240*ammu*amuq*amel2^2*
x6*xcp2*e2345+48*ammu*amuq*amel2^2*x6*xcp2*e1345+192*ammu*amuq*amel2^2*x6*xcp2*e1245-912*ammu*amuq*amel2^2*x6*xcp2*e1235-192*ammu*amuq*amel2^2*x6*xcp2*e1234-240*ammu*amuq*amel2^2*x6*xcp1*e2345-144*ammu*amuq*amel2^2*x6*xcp1*e1345+192*ammu*amuq*
amel2^2*x6*xcp1*e1245-192*ammu*amuq*amel2^2*x6*xcp1*e1235-192*ammu*amuq*amel2^2*x6*xcp1*e1234+48*ammu*amuq*amel2^2*x6^2*xcp4*e2345+48*ammu*amuq*amel2^2*x6^2*xcp4*e1345-768*ammu*amuq*amel2^2*x6^2*xcp4*e1235-384*ammu*amuq*amel2^2*x6^2*xcp4*e1234-144*
ammu*amuq*amel2^2*x6^2*xcp3*e2345-144*ammu*amuq*amel2^2*x6^2*xcp3*e1345+48*ammu*amuq*amel2^2*x6^2*xcp3*e1235+144*ammu*amuq*amel2^2*x6^2*xcp2*e2345+144*ammu*amuq*amel2^2*x6^2*xcp2*e1345-48*ammu*amuq*amel2^2*x6^2*xcp2*e1235-48*ammu*amuq*amel2^2*x6^2*
xcp1*e2345-48*ammu*amuq*amel2^2*x6^2*xcp1*e1345+768*ammu*amuq*amel2^2*x6^2*xcp1*e1235+384*ammu*amuq*amel2^2*x6^2*xcp1*e1234+192*ammu*amuq*amel2^2*x6^3*xcp4*e2345+96*ammu*amuq*amel2^2*x6^3*xcp4*e1345+192*ammu*amuq*amel2^2*x6^3*xcp4*e1245+192*ammu*
amuq*amel2^2*x6^3*xcp4*e1235+192*ammu*amuq*amel2^2*x6^3*xcp4*e1234+192*ammu*amuq*amel2^2*x6^3*xcp3*e2345+96*ammu*amuq*amel2^2*x6^3*xcp3*e1345+192*ammu*amuq*amel2^2*x6^3*xcp3*e1245-576*ammu*amuq*amel2^2*x6^3*xcp3*e1235-192*ammu*amuq*amel2^2*x6^3*
xcp3*e1234-192*ammu*amuq*amel2^2*x6^3*xcp2*e2345-96*ammu*amuq*amel2^2*x6^3*xcp2*e1345-192*ammu*amuq*amel2^2*x6^3*xcp2*e1245+576*ammu*amuq*amel2^2*x6^3*xcp2*e1235+192*ammu*amuq*amel2^2*x6^3*xcp2*e1234-192*ammu*amuq*amel2^2*x6^3*xcp1*e2345-96*ammu*
amuq*amel2^2*x6^3*xcp1*e1345-192*ammu*amuq*amel2^2*x6^3*xcp1*e1245-192*ammu*amuq*amel2^2*x6^3*xcp1*e1235-192*ammu*amuq*amel2^2*x6^3*xcp1*e1234-768*ammu*amuq*amel2^2*x5*xcp4*e2345-1488*ammu*amuq*amel2^2*x5*xcp4*e1345-1344*ammu*amuq*amel2^2*x5*xcp4*
e1245+192*ammu*amuq*amel2^2*x5*xcp4*e1235+816*ammu*amuq*amel2^2*x5*xcp4*e1234-1632*ammu*amuq*amel2^2*x5*xcp3*e2345-1104*ammu*amuq*amel2^2*x5*xcp3*e1345-1344*ammu*amuq*amel2^2*x5*xcp3*e1245+912*ammu*amuq*amel2^2*x5*xcp3*e1235+768*ammu*amuq*amel2^2*
x5*xcp3*e1234+1632*ammu*amuq*amel2^2*x5*xcp2*e2345+1104*ammu*amuq*amel2^2*x5*xcp2*e1345+1344*ammu*amuq*amel2^2*x5*xcp2*e1245-912*ammu*amuq*amel2^2*x5*xcp2*e1235-768*ammu*amuq*amel2^2*x5*xcp2*e1234+768*ammu*amuq*amel2^2*x5*xcp1*e2345+1488*ammu*amuq*
amel2^2*x5*xcp1*e1345+1344*ammu*amuq*amel2^2*x5*xcp1*e1245-192*ammu*amuq*amel2^2*x5*xcp1*e1235-816*ammu*amuq*amel2^2*x5*xcp1*e1234+336*ammu*amuq*amel2^2*x5*x6*xcp4*e2345+432*ammu*amuq*amel2^2*x5*x6*xcp4*e1345-384*ammu*amuq*amel2^2*x5*x6*xcp4*e1245-
1536*ammu*amuq*amel2^2*x5*x6*xcp4*e1235-960*ammu*amuq*amel2^2*x5*x6*xcp4*e1234-432*ammu*amuq*amel2^2*x5*x6*xcp3*e2345-1104*ammu*amuq*amel2^2*x5*x6*xcp3*e1345-384*ammu*amuq*amel2^2*x5*x6*xcp3*e1245+96*ammu*amuq*amel2^2*x5*x6*xcp3*e1235+816*ammu*amuq
*amel2^2*x5*x6*xcp3*e1234+432*ammu*amuq*amel2^2*x5*x6*xcp2*e2345+1104*ammu*amuq*amel2^2*x5*x6*xcp2*e1345+384*ammu*amuq*amel2^2*x5*x6*xcp2*e1245-96*ammu*amuq*amel2^2*x5*x6*xcp2*e1235-816*ammu*amuq*amel2^2*x5*x6*xcp2*e1234-336*ammu*amuq*amel2^2*x5*x6
*xcp1*e2345-432*ammu*amuq*amel2^2*x5*x6*xcp1*e1345+384*ammu*amuq*amel2^2*x5*x6*xcp1*e1245+1536*ammu*amuq*amel2^2*x5*x6*xcp1*e1235+960*ammu*amuq*amel2^2*x5*x6*xcp1*e1234+384*ammu*amuq*amel2^2*x5*x6^2*xcp4*e2345+144*ammu*amuq*amel2^2*x5*x6^2*xcp4*
e1345+576*ammu*amuq*amel2^2*x5*x6^2*xcp4*e1245+576*ammu*amuq*amel2^2*x5*x6^2*xcp4*e1235+672*ammu*amuq*amel2^2*x5*x6^2*xcp4*e1234+1152*ammu*amuq*amel2^2*x5*x6^2*xcp3*e2345+720*ammu*amuq*amel2^2*x5*x6^2*xcp3*e1345+576*ammu*amuq*amel2^2*x5*x6^2*xcp3*
e1245-1728*ammu*amuq*amel2^2*x5*x6^2*xcp3*e1235-288*ammu*amuq*amel2^2*x5*x6^2*xcp3*e1234-1152*ammu*amuq*amel2^2*x5*x6^2*xcp2*e2345-720*ammu*amuq*amel2^2*x5*x6^2*xcp2*e1345-576*ammu*amuq*amel2^2*x5*x6^2*xcp2*e1245+1728*ammu*amuq*amel2^2*x5*x6^2*xcp2
*e1235+288*ammu*amuq*amel2^2*x5*x6^2*xcp2*e1234-384*ammu*amuq*amel2^2*x5*x6^2*xcp1*e2345-144*ammu*amuq*amel2^2*x5*x6^2*xcp1*e1345-576*ammu*amuq*amel2^2*x5*x6^2*xcp1*e1245-576*ammu*amuq*amel2^2*x5*x6^2*xcp1*e1235-672*ammu*amuq*amel2^2*x5*x6^2*xcp1*
e1234+288*ammu*amuq*amel2^2*x5^2*xcp4*e2345+384*ammu*amuq*amel2^2*x5^2*xcp4*e1345-384*ammu*amuq*amel2^2*x5^2*xcp4*e1245-768*ammu*amuq*amel2^2*x5^2*xcp4*e1235-192*ammu*amuq*amel2^2*x5^2*xcp4*e1234-288*ammu*amuq*amel2^2*x5^2*xcp3*e2345-960*ammu*amuq*
amel2^2*x5^2*xcp3*e1345-384*ammu*amuq*amel2^2*x5^2*xcp3*e1245+48*ammu*amuq*amel2^2*x5^2*xcp3*e1235+816*ammu*amuq*amel2^2*x5^2*xcp3*e1234+288*ammu*amuq*amel2^2*x5^2*xcp2*e2345+960*ammu*amuq*amel2^2*x5^2*xcp2*e1345+384*ammu*amuq*amel2^2*x5^2*xcp2*
e1245-48*ammu*amuq*amel2^2*x5^2*xcp2*e1235-816*ammu*amuq*amel2^2*x5^2*xcp2*e1234-288*ammu*amuq*amel2^2*x5^2*xcp1*e2345-384*ammu*amuq*amel2^2*x5^2*xcp1*e1345+384*ammu*amuq*amel2^2*x5^2*xcp1*e1245+768*ammu*amuq*amel2^2*x5^2*xcp1*e1235+192*ammu*amuq*
amel2^2*x5^2*xcp1*e1234+192*ammu*amuq*amel2^2*x5^2*x6*xcp4*e2345+576*ammu*amuq*amel2^2*x5^2*x6*xcp4*e1245+576*ammu*amuq*amel2^2*x5^2*x6*xcp4*e1235+864*ammu*amuq*amel2^2*x5^2*x6*xcp4*e1234+1728*ammu*amuq*amel2^2*x5^2*x6*xcp3*e2345+1152*ammu*amuq*
amel2^2*x5^2*x6*xcp3*e1345+576*ammu*amuq*amel2^2*x5^2*x6*xcp3*e1245-1728*ammu*amuq*amel2^2*x5^2*x6*xcp3*e1235+96*ammu*amuq*amel2^2*x5^2*x6*xcp3*e1234-1728*ammu*amuq*amel2^2*x5^2*x6*xcp2*e2345-1152*ammu*amuq*amel2^2*x5^2*x6*xcp2*e1345-576*ammu*amuq*
amel2^2*x5^2*x6*xcp2*e1245+1728*ammu*amuq*amel2^2*x5^2*x6*xcp2*e1235-96*ammu*amuq*amel2^2*x5^2*x6*xcp2*e1234-192*ammu*amuq*amel2^2*x5^2*x6*xcp1*e2345-576*ammu*amuq*amel2^2*x5^2*x6*xcp1*e1245-576*ammu*amuq*amel2^2*x5^2*x6*xcp1*e1235-864*ammu*amuq*
amel2^2*x5^2*x6*xcp1*e1234-48*ammu*amuq*amel2^2*x5^3*xcp4*e1345+192*ammu*amuq*amel2^2*x5^3*xcp4*e1245+192*ammu*amuq*amel2^2*x5^3*xcp4*e1235+384*ammu*amuq*amel2^2*x5^3*xcp4*e1234+768*ammu*amuq*amel2^2*x5^3*xcp3*e2345+528*ammu*amuq*amel2^2*x5^3*xcp3*
e1345+192*ammu*amuq*amel2^2*x5^3*xcp3*e1245-576*ammu*amuq*amel2^2*x5^3*xcp3*e1235+192*ammu*amuq*amel2^2*x5^3*xcp3*e1234-768*ammu*amuq*amel2^2*x5^3*xcp2*e2345-528*ammu*amuq*amel2^2*x5^3*xcp2*e1345-192*ammu*amuq*amel2^2*x5^3*xcp2*e1245+576*ammu*amuq*
amel2^2*x5^3*xcp2*e1235-192*ammu*amuq*amel2^2*x5^3*xcp2*e1234+48*ammu*amuq*amel2^2*x5^3*xcp1*e1345-192*ammu*amuq*amel2^2*x5^3*xcp1*e1245-192*ammu*amuq*amel2^2*x5^3*xcp1*e1235-384*ammu*amuq*amel2^2*x5^3*xcp1*e1234-1104*ammu*amuq*amel2^2*x4*xcp4*
e2345-576*ammu*amuq*amel2^2*x4*xcp4*e1345-1344*ammu*amuq*amel2^2*x4*xcp4*e1245+672*ammu*amuq*amel2^2*x4*xcp4*e1235+576*ammu*amuq*amel2^2*x4*xcp4*e1234-432*ammu*amuq*amel2^2*x4*xcp3*e1345-192*ammu*amuq*amel2^2*x4*xcp3*e1245+576*ammu*amuq*amel2^2*x4*
xcp3*e1235+192*ammu*amuq*amel2^2*x4*xcp3*e1234+432*ammu*amuq*amel2^2*x4*xcp2*e1345+192*ammu*amuq*amel2^2*x4*xcp2*e1245-576*ammu*amuq*amel2^2*x4*xcp2*e1235-192*ammu*amuq*amel2^2*x4*xcp2*e1234+1104*ammu*amuq*amel2^2*x4*xcp1*e2345+576*ammu*amuq*
amel2^2*x4*xcp1*e1345+1344*ammu*amuq*amel2^2*x4*xcp1*e1245-672*ammu*amuq*amel2^2*x4*xcp1*e1235-576*ammu*amuq*amel2^2*x4*xcp1*e1234-48*ammu*amuq*amel2^2*x4*x6*xcp4*e2345+384*ammu*amuq*amel2^2*x4*x6*xcp4*e1345-768*ammu*amuq*amel2^2*x4*x6*xcp4*e1245-
1488*ammu*amuq*amel2^2*x4*x6*xcp4*e1235-960*ammu*amuq*amel2^2*x4*x6*xcp4*e1234-288*ammu*amuq*amel2^2*x4*x6*xcp3*e2345-336*ammu*amuq*amel2^2*x4*x6*xcp3*e1345-384*ammu*amuq*amel2^2*x4*x6*xcp3*e1245+96*ammu*amuq*amel2^2*x4*x6*xcp3*e1235+384*ammu*amuq*
amel2^2*x4*x6*xcp3*e1234+288*ammu*amuq*amel2^2*x4*x6*xcp2*e2345+336*ammu*amuq*amel2^2*x4*x6*xcp2*e1345+384*ammu*amuq*amel2^2*x4*x6*xcp2*e1245-96*ammu*amuq*amel2^2*x4*x6*xcp2*e1235-384*ammu*amuq*amel2^2*x4*x6*xcp2*e1234+48*ammu*amuq*amel2^2*x4*x6*
xcp1*e2345-384*ammu*amuq*amel2^2*x4*x6*xcp1*e1345+768*ammu*amuq*amel2^2*x4*x6*xcp1*e1245+1488*ammu*amuq*amel2^2*x4*x6*xcp1*e1235+960*ammu*amuq*amel2^2*x4*x6*xcp1*e1234-192*ammu*amuq*amel2^2*x4*x6^2*xcp4*e2345-96*ammu*amuq*amel2^2*x4*x6^2*xcp4*e1345
+192*ammu*amuq*amel2^2*x4*x6^2*xcp4*e1245+480*ammu*amuq*amel2^2*x4*x6^2*xcp4*e1235+384*ammu*amuq*amel2^2*x4*x6^2*xcp4*e1234+240*ammu*amuq*amel2^2*x4*x6^2*xcp3*e2345+144*ammu*amuq*amel2^2*x4*x6^2*xcp3*e1345+192*ammu*amuq*amel2^2*x4*x6^2*xcp3*e1245-
912*ammu*amuq*amel2^2*x4*x6^2*xcp3*e1235-192*ammu*amuq*amel2^2*x4*x6^2*xcp3*e1234-240*ammu*amuq*amel2^2*x4*x6^2*xcp2*e2345-144*ammu*amuq*amel2^2*x4*x6^2*xcp2*e1345-192*ammu*amuq*amel2^2*x4*x6^2*xcp2*e1245+912*ammu*amuq*amel2^2*x4*x6^2*xcp2*e1235+
192*ammu*amuq*amel2^2*x4*x6^2*xcp2*e1234+192*ammu*amuq*amel2^2*x4*x6^2*xcp1*e2345+96*ammu*amuq*amel2^2*x4*x6^2*xcp1*e1345-192*ammu*amuq*amel2^2*x4*x6^2*xcp1*e1245-480*ammu*amuq*amel2^2*x4*x6^2*xcp1*e1235-384*ammu*amuq*amel2^2*x4*x6^2*xcp1*e1234+
1440*ammu*amuq*amel2^2*x4*x5*xcp4*e2345+1728*ammu*amuq*amel2^2*x4*x5*xcp4*e1345-192*ammu*amuq*amel2^2*x4*x5*xcp4*e1245-1872*ammu*amuq*amel2^2*x4*x5*xcp4*e1235-1824*ammu*amuq*amel2^2*x4*x5*xcp4*e1234-768*ammu*amuq*amel2^2*x4*x5*xcp3*e2345-432*ammu*
amuq*amel2^2*x4*x5*xcp3*e1345-960*ammu*amuq*amel2^2*x4*x5*xcp3*e1245+96*ammu*amuq*amel2^2*x4*x5*xcp3*e1235+288*ammu*amuq*amel2^2*x4*x5*xcp3*e1234+768*ammu*amuq*amel2^2*x4*x5*xcp2*e2345+432*ammu*amuq*amel2^2*x4*x5*xcp2*e1345+960*ammu*amuq*amel2^2*x4
*x5*xcp2*e1245-96*ammu*amuq*amel2^2*x4*x5*xcp2*e1235-288*ammu*amuq*amel2^2*x4*x5*xcp2*e1234-1440*ammu*amuq*amel2^2*x4*x5*xcp1*e2345-1728*ammu*amuq*amel2^2*x4*x5*xcp1*e1345+192*ammu*amuq*amel2^2*x4*x5*xcp1*e1245+1872*ammu*amuq*amel2^2*x4*x5*xcp1*
e1235+1824*ammu*amuq*amel2^2*x4*x5*xcp1*e1234-240*ammu*amuq*amel2^2*x4*x5*x6*xcp4*e2345-96*ammu*amuq*amel2^2*x4*x5*x6*xcp4*e1345+960*ammu*amuq*amel2^2*x4*x5*x6*xcp4*e1245+1056*ammu*amuq*amel2^2*x4*x5*x6*xcp4*e1235+864*ammu*amuq*amel2^2*x4*x5*x6*
xcp4*e1234+864*ammu*amuq*amel2^2*x4*x5*x6*xcp3*e2345+768*ammu*amuq*amel2^2*x4*x5*x6*xcp3*e1345+576*ammu*amuq*amel2^2*x4*x5*x6*xcp3*e1245-2496*ammu*amuq*amel2^2*x4*x5*x6*xcp3*e1235-432*ammu*amuq*amel2^2*x4*x5*x6*xcp3*e1234-864*ammu*amuq*amel2^2*x4*
x5*x6*xcp2*e2345-768*ammu*amuq*amel2^2*x4*x5*x6*xcp2*e1345-576*ammu*amuq*amel2^2*x4*x5*x6*xcp2*e1245+2496*ammu*amuq*amel2^2*x4*x5*x6*xcp2*e1235+432*ammu*amuq*amel2^2*x4*x5*x6*xcp2*e1234+240*ammu*amuq*amel2^2*x4*x5*x6*xcp1*e2345+96*ammu*amuq*amel2^2
*x4*x5*x6*xcp1*e1345-960*ammu*amuq*amel2^2*x4*x5*x6*xcp1*e1245-1056*ammu*amuq*amel2^2*x4*x5*x6*xcp1*e1235-864*ammu*amuq*amel2^2*x4*x5*x6*xcp1*e1234-240*ammu*amuq*amel2^2*x4*x5^2*xcp4*e2345-288*ammu*amuq*amel2^2*x4*x5^2*xcp4*e1345+768*ammu*amuq*
amel2^2*x4*x5^2*xcp4*e1245+576*ammu*amuq*amel2^2*x4*x5^2*xcp4*e1235+624*ammu*amuq*amel2^2*x4*x5^2*xcp4*e1234+1200*ammu*amuq*amel2^2*x4*x5^2*xcp3*e2345+1488*ammu*amuq*amel2^2*x4*x5^2*xcp3*e1345+384*ammu*amuq*amel2^2*x4*x5^2*xcp3*e1245-1584*ammu*amuq
*amel2^2*x4*x5^2*xcp3*e1235-240*ammu*amuq*amel2^2*x4*x5^2*xcp3*e1234-1200*ammu*amuq*amel2^2*x4*x5^2*xcp2*e2345-1488*ammu*amuq*amel2^2*x4*x5^2*xcp2*e1345-384*ammu*amuq*amel2^2*x4*x5^2*xcp2*e1245+1584*ammu*amuq*amel2^2*x4*x5^2*xcp2*e1235+240*ammu*
amuq*amel2^2*x4*x5^2*xcp2*e1234+240*ammu*amuq*amel2^2*x4*x5^2*xcp1*e2345+288*ammu*amuq*amel2^2*x4*x5^2*xcp1*e1345-768*ammu*amuq*amel2^2*x4*x5^2*xcp1*e1245-576*ammu*amuq*amel2^2*x4*x5^2*xcp1*e1235-624*ammu*amuq*amel2^2*x4*x5^2*xcp1*e1234+1008*ammu*
amuq*amel2^2*x4^2*xcp4*e2345+576*ammu*amuq*amel2^2*x4^2*xcp4*e1345+192*ammu*amuq*amel2^2*x4^2*xcp4*e1245-816*ammu*amuq*amel2^2*x4^2*xcp4*e1235-768*ammu*amuq*amel2^2*x4^2*xcp4*e1234-96*ammu*amuq*amel2^2*x4^2*xcp3*e2345-96*ammu*amuq*amel2^2*x4^2*xcp3
*e1345+96*ammu*amuq*amel2^2*x4^2*xcp3*e1235+96*ammu*amuq*amel2^2*x4^2*xcp2*e2345+96*ammu*amuq*amel2^2*x4^2*xcp2*e1345-96*ammu*amuq*amel2^2*x4^2*xcp2*e1235-1008*ammu*amuq*amel2^2*x4^2*xcp1*e2345-576*ammu*amuq*amel2^2*x4^2*xcp1*e1345-192*ammu*amuq*
amel2^2*x4^2*xcp1*e1245+816*ammu*amuq*amel2^2*x4^2*xcp1*e1235+768*ammu*amuq*amel2^2*x4^2*xcp1*e1234+384*ammu*amuq*amel2^2*x4^2*x6*xcp4*e1245+480*ammu*amuq*amel2^2*x4^2*x6*xcp4*e1235+384*ammu*amuq*amel2^2*x4^2*x6*xcp4*e1234+192*ammu*amuq*amel2^2*
x4^2*x6*xcp3*e2345+240*ammu*amuq*amel2^2*x4^2*x6*xcp3*e1345+192*ammu*amuq*amel2^2*x4^2*x6*xcp3*e1245-816*ammu*amuq*amel2^2*x4^2*x6*xcp3*e1235-192*ammu*amuq*amel2^2*x4^2*x6*xcp3*e1234-192*ammu*amuq*amel2^2*x4^2*x6*xcp2*e2345-240*ammu*amuq*amel2^2*
x4^2*x6*xcp2*e1345-192*ammu*amuq*amel2^2*x4^2*x6*xcp2*e1245+816*ammu*amuq*amel2^2*x4^2*x6*xcp2*e1235+192*ammu*amuq*amel2^2*x4^2*x6*xcp2*e1234-384*ammu*amuq*amel2^2*x4^2*x6*xcp1*e1245-480*ammu*amuq*amel2^2*x4^2*x6*xcp1*e1235-384*ammu*amuq*amel2^2*
x4^2*x6*xcp1*e1234-288*ammu*amuq*amel2^2*x4^2*x5*xcp4*e2345-576*ammu*amuq*amel2^2*x4^2*x5*xcp4*e1345+960*ammu*amuq*amel2^2*x4^2*x5*xcp4*e1245+624*ammu*amuq*amel2^2*x4^2*x5*xcp4*e1235+480*ammu*amuq*amel2^2*x4^2*x5*xcp4*e1234+672*ammu*amuq*amel2^2*
x4^2*x5*xcp3*e2345+960*ammu*amuq*amel2^2*x4^2*x5*xcp3*e1345+384*ammu*amuq*amel2^2*x4^2*x5*xcp3*e1245-1680*ammu*amuq*amel2^2*x4^2*x5*xcp3*e1235-480*ammu*amuq*amel2^2*x4^2*x5*xcp3*e1234-672*ammu*amuq*amel2^2*x4^2*x5*xcp2*e2345-960*ammu*amuq*amel2^2*
x4^2*x5*xcp2*e1345-384*ammu*amuq*amel2^2*x4^2*x5*xcp2*e1245+1680*ammu*amuq*amel2^2*x4^2*x5*xcp2*e1235+480*ammu*amuq*amel2^2*x4^2*x5*xcp2*e1234+288*ammu*amuq*amel2^2*x4^2*x5*xcp1*e2345+576*ammu*amuq*amel2^2*x4^2*x5*xcp1*e1345-960*ammu*amuq*amel2^2*
x4^2*x5*xcp1*e1245-624*ammu*amuq*amel2^2*x4^2*x5*xcp1*e1235-480*ammu*amuq*amel2^2*x4^2*x5*xcp1*e1234-96*ammu*amuq*amel2^2*x4^3*xcp4*e2345-288*ammu*amuq*amel2^2*x4^3*xcp4*e1345+384*ammu*amuq*amel2^2*x4^3*xcp4*e1245+288*ammu*amuq*amel2^2*x4^3*xcp4*
e1235+192*ammu*amuq*amel2^2*x4^3*xcp4*e1234+96*ammu*amuq*amel2^2*x4^3*xcp3*e2345+144*ammu*amuq*amel2^2*x4^3*xcp3*e1345+192*ammu*amuq*amel2^2*x4^3*xcp3*e1245-528*ammu*amuq*amel2^2*x4^3*xcp3*e1235-192*ammu*amuq*amel2^2*x4^3*xcp3*e1234-96*ammu*amuq*
amel2^2*x4^3*xcp2*e2345-144*ammu*amuq*amel2^2*x4^3*xcp2*e1345-192*ammu*amuq*amel2^2*x4^3*xcp2*e1245+528*ammu*amuq*amel2^2*x4^3*xcp2*e1235+192*ammu*amuq*amel2^2*x4^3*xcp2*e1234+96*ammu*amuq*amel2^2*x4^3*xcp1*e2345+288*ammu*amuq*amel2^2*x4^3*xcp1*
e1345-384*ammu*amuq*amel2^2*x4^3*xcp1*e1245-288*ammu*amuq*amel2^2*x4^3*xcp1*e1235-192*ammu*amuq*amel2^2*x4^3*xcp1*e1234+384*ammu*amuq*amel2^2*x3*xcp4*e1345-192*ammu*amuq*amel2^2*x3*xcp4*e1245+2064*ammu*amuq*amel2^2*x3*xcp4*e1235+1344*ammu*amuq*
amel2^2*x3*xcp4*e1234+48*ammu*amuq*amel2^2*x3*xcp3*e2345-240*ammu*amuq*amel2^2*x3*xcp3*e1345-192*ammu*amuq*amel2^2*x3*xcp3*e1245+1200*ammu*amuq*amel2^2*x3*xcp3*e1235+192*ammu*amuq*amel2^2*x3*xcp3*e1234-48*ammu*amuq*amel2^2*x3*xcp2*e2345+240*ammu*
amuq*amel2^2*x3*xcp2*e1345+192*ammu*amuq*amel2^2*x3*xcp2*e1245-1200*ammu*amuq*amel2^2*x3*xcp2*e1235-192*ammu*amuq*amel2^2*x3*xcp2*e1234-384*ammu*amuq*amel2^2*x3*xcp1*e1345+192*ammu*amuq*amel2^2*x3*xcp1*e1245-2064*ammu*amuq*amel2^2*x3*xcp1*e1235-
1344*ammu*amuq*amel2^2*x3*xcp1*e1234+144*ammu*amuq*amel2^2*x3*x6*xcp4*e1345-384*ammu*amuq*amel2^2*x3*x6*xcp4*e1245-720*ammu*amuq*amel2^2*x3*x6*xcp4*e1235-768*ammu*amuq*amel2^2*x3*x6*xcp4*e1234-336*ammu*amuq*amel2^2*x3*x6*xcp3*e2345-96*ammu*amuq*
amel2^2*x3*x6*xcp3*e1345-384*ammu*amuq*amel2^2*x3*x6*xcp3*e1245+816*ammu*amuq*amel2^2*x3*x6*xcp3*e1235+384*ammu*amuq*amel2^2*x3*x6*xcp3*e1234+336*ammu*amuq*amel2^2*x3*x6*xcp2*e2345+96*ammu*amuq*amel2^2*x3*x6*xcp2*e1345+384*ammu*amuq*amel2^2*x3*x6*
xcp2*e1245-816*ammu*amuq*amel2^2*x3*x6*xcp2*e1235-384*ammu*amuq*amel2^2*x3*x6*xcp2*e1234-144*ammu*amuq*amel2^2*x3*x6*xcp1*e1345+384*ammu*amuq*amel2^2*x3*x6*xcp1*e1245+720*ammu*amuq*amel2^2*x3*x6*xcp1*e1235+768*ammu*amuq*amel2^2*x3*x6*xcp1*e1234+48*
ammu*amuq*amel2^2*x3*x6^2*xcp4*e1345+192*ammu*amuq*amel2^2*x3*x6^2*xcp4*e1245+192*ammu*amuq*amel2^2*x3*x6^2*xcp4*e1235+192*ammu*amuq*amel2^2*x3*x6^2*xcp4*e1234+48*ammu*amuq*amel2^2*x3*x6^2*xcp3*e2345+192*ammu*amuq*amel2^2*x3*x6^2*xcp3*e1245-576*
ammu*amuq*amel2^2*x3*x6^2*xcp3*e1235-192*ammu*amuq*amel2^2*x3*x6^2*xcp3*e1234-48*ammu*amuq*amel2^2*x3*x6^2*xcp2*e2345-192*ammu*amuq*amel2^2*x3*x6^2*xcp2*e1245+576*ammu*amuq*amel2^2*x3*x6^2*xcp2*e1235+192*ammu*amuq*amel2^2*x3*x6^2*xcp2*e1234-48*ammu
*amuq*amel2^2*x3*x6^2*xcp1*e1345-192*ammu*amuq*amel2^2*x3*x6^2*xcp1*e1245-192*ammu*amuq*amel2^2*x3*x6^2*xcp1*e1235-192*ammu*amuq*amel2^2*x3*x6^2*xcp1*e1234+48*ammu*amuq*amel2^2*x3*x5*xcp4*e2345-240*ammu*amuq*amel2^2*x3*x5*xcp4*e1345-768*ammu*amuq*
amel2^2*x3*x5*xcp4*e1245-720*ammu*amuq*amel2^2*x3*x5*xcp4*e1235-1248*ammu*amuq*amel2^2*x3*x5*xcp4*e1234-480*ammu*amuq*amel2^2*x3*x5*xcp3*e2345+288*ammu*amuq*amel2^2*x3*x5*xcp3*e1345-768*ammu*amuq*amel2^2*x3*x5*xcp3*e1245+816*ammu*amuq*amel2^2*x3*x5
*xcp3*e1235-96*ammu*amuq*amel2^2*x3*x5*xcp3*e1234+480*ammu*amuq*amel2^2*x3*x5*xcp2*e2345-288*ammu*amuq*amel2^2*x3*x5*xcp2*e1345+768*ammu*amuq*amel2^2*x3*x5*xcp2*e1245-816*ammu*amuq*amel2^2*x3*x5*xcp2*e1235+96*ammu*amuq*amel2^2*x3*x5*xcp2*e1234-48*
ammu*amuq*amel2^2*x3*x5*xcp1*e2345+240*ammu*amuq*amel2^2*x3*x5*xcp1*e1345+768*ammu*amuq*amel2^2*x3*x5*xcp1*e1245+720*ammu*amuq*amel2^2*x3*x5*xcp1*e1235+1248*ammu*amuq*amel2^2*x3*x5*xcp1*e1234-48*ammu*amuq*amel2^2*x3*x5*x6*xcp4*e2345+384*ammu*amuq*
amel2^2*x3*x5*x6*xcp4*e1245+384*ammu*amuq*amel2^2*x3*x5*x6*xcp4*e1235+384*ammu*amuq*amel2^2*x3*x5*x6*xcp4*e1234+240*ammu*amuq*amel2^2*x3*x5*x6*xcp3*e2345+288*ammu*amuq*amel2^2*x3*x5*x6*xcp3*e1345+384*ammu*amuq*amel2^2*x3*x5*x6*xcp3*e1245-1152*ammu*
amuq*amel2^2*x3*x5*x6*xcp3*e1235-336*ammu*amuq*amel2^2*x3*x5*x6*xcp3*e1234-240*ammu*amuq*amel2^2*x3*x5*x6*xcp2*e2345-288*ammu*amuq*amel2^2*x3*x5*x6*xcp2*e1345-384*ammu*amuq*amel2^2*x3*x5*x6*xcp2*e1245+1152*ammu*amuq*amel2^2*x3*x5*x6*xcp2*e1235+336*
ammu*amuq*amel2^2*x3*x5*x6*xcp2*e1234+48*ammu*amuq*amel2^2*x3*x5*x6*xcp1*e2345-384*ammu*amuq*amel2^2*x3*x5*x6*xcp1*e1245-384*ammu*amuq*amel2^2*x3*x5*x6*xcp1*e1235-384*ammu*amuq*amel2^2*x3*x5*x6*xcp1*e1234-48*ammu*amuq*amel2^2*x3*x5^2*xcp4*e2345-48*
ammu*amuq*amel2^2*x3*x5^2*xcp4*e1345+192*ammu*amuq*amel2^2*x3*x5^2*xcp4*e1245+192*ammu*amuq*amel2^2*x3*x5^2*xcp4*e1235+336*ammu*amuq*amel2^2*x3*x5^2*xcp4*e1234+192*ammu*amuq*amel2^2*x3*x5^2*xcp3*e2345+288*ammu*amuq*amel2^2*x3*x5^2*xcp3*e1345+192*
ammu*amuq*amel2^2*x3*x5^2*xcp3*e1245-576*ammu*amuq*amel2^2*x3*x5^2*xcp3*e1235-192*ammu*amuq*amel2^2*x3*x5^2*xcp3*e1234-192*ammu*amuq*amel2^2*x3*x5^2*xcp2*e2345-288*ammu*amuq*amel2^2*x3*x5^2*xcp2*e1345-192*ammu*amuq*amel2^2*x3*x5^2*xcp2*e1245+576*
ammu*amuq*amel2^2*x3*x5^2*xcp2*e1235+192*ammu*amuq*amel2^2*x3*x5^2*xcp2*e1234+48*ammu*amuq*amel2^2*x3*x5^2*xcp1*e2345+48*ammu*amuq*amel2^2*x3*x5^2*xcp1*e1345-192*ammu*amuq*amel2^2*x3*x5^2*xcp1*e1245-192*ammu*amuq*amel2^2*x3*x5^2*xcp1*e1235-336*ammu
*amuq*amel2^2*x3*x5^2*xcp1*e1234+816*ammu*amuq*amel2^2*x3*x4*xcp4*e2345-384*ammu*amuq*amel2^2*x3*x4*xcp4*e1245-768*ammu*amuq*amel2^2*x3*x4*xcp4*e1235-768*ammu*amuq*amel2^2*x3*x4*xcp4*e1234-144*ammu*amuq*amel2^2*x3*x4*xcp3*e2345-192*ammu*amuq*
amel2^2*x3*x4*xcp3*e1345+144*ammu*amuq*amel2^2*x3*x4*xcp3*e1235+144*ammu*amuq*amel2^2*x3*x4*xcp2*e2345+192*ammu*amuq*amel2^2*x3*x4*xcp2*e1345-144*ammu*amuq*amel2^2*x3*x4*xcp2*e1235-816*ammu*amuq*amel2^2*x3*x4*xcp1*e2345+384*ammu*amuq*amel2^2*x3*x4*
xcp1*e1245+768*ammu*amuq*amel2^2*x3*x4*xcp1*e1235+768*ammu*amuq*amel2^2*x3*x4*xcp1*e1234+48*ammu*amuq*amel2^2*x3*x4*x6*xcp4*e2345+96*ammu*amuq*amel2^2*x3*x4*x6*xcp4*e1345+384*ammu*amuq*amel2^2*x3*x4*x6*xcp4*e1245+576*ammu*amuq*amel2^2*x3*x4*x6*xcp4
*e1235+576*ammu*amuq*amel2^2*x3*x4*x6*xcp4*e1234+336*ammu*amuq*amel2^2*x3*x4*x6*xcp3*e2345+384*ammu*amuq*amel2^2*x3*x4*x6*xcp3*e1345+384*ammu*amuq*amel2^2*x3*x4*x6*xcp3*e1245-1296*ammu*amuq*amel2^2*x3*x4*x6*xcp3*e1235-384*ammu*amuq*amel2^2*x3*x4*x6
*xcp3*e1234-336*ammu*amuq*amel2^2*x3*x4*x6*xcp2*e2345-384*ammu*amuq*amel2^2*x3*x4*x6*xcp2*e1345-384*ammu*amuq*amel2^2*x3*x4*x6*xcp2*e1245+1296*ammu*amuq*amel2^2*x3*x4*x6*xcp2*e1235+384*ammu*amuq*amel2^2*x3*x4*x6*xcp2*e1234-48*ammu*amuq*amel2^2*x3*
x4*x6*xcp1*e2345-96*ammu*amuq*amel2^2*x3*x4*x6*xcp1*e1345-384*ammu*amuq*amel2^2*x3*x4*x6*xcp1*e1245-576*ammu*amuq*amel2^2*x3*x4*x6*xcp1*e1235-576*ammu*amuq*amel2^2*x3*x4*x6*xcp1*e1234-144*ammu*amuq*amel2^2*x3*x4*x5*xcp4*e2345-384*ammu*amuq*amel2^2*
x3*x4*x5*xcp4*e1345+960*ammu*amuq*amel2^2*x3*x4*x5*xcp4*e1245+720*ammu*amuq*amel2^2*x3*x4*x5*xcp4*e1235+624*ammu*amuq*amel2^2*x3*x4*x5*xcp4*e1234+912*ammu*amuq*amel2^2*x3*x4*x5*xcp3*e2345+1392*ammu*amuq*amel2^2*x3*x4*x5*xcp3*e1345+576*ammu*amuq*
amel2^2*x3*x4*x5*xcp3*e1245-2112*ammu*amuq*amel2^2*x3*x4*x5*xcp3*e1235-816*ammu*amuq*amel2^2*x3*x4*x5*xcp3*e1234-912*ammu*amuq*amel2^2*x3*x4*x5*xcp2*e2345-1392*ammu*amuq*amel2^2*x3*x4*x5*xcp2*e1345-576*ammu*amuq*amel2^2*x3*x4*x5*xcp2*e1245+2112*
ammu*amuq*amel2^2*x3*x4*x5*xcp2*e1235+816*ammu*amuq*amel2^2*x3*x4*x5*xcp2*e1234+144*ammu*amuq*amel2^2*x3*x4*x5*xcp1*e2345+384*ammu*amuq*amel2^2*x3*x4*x5*xcp1*e1345-960*ammu*amuq*amel2^2*x3*x4*x5*xcp1*e1245-720*ammu*amuq*amel2^2*x3*x4*x5*xcp1*e1235-
624*ammu*amuq*amel2^2*x3*x4*x5*xcp1*e1234-192*ammu*amuq*amel2^2*x3*x4^2*xcp4*e2345-672*ammu*amuq*amel2^2*x3*x4^2*xcp4*e1345+768*ammu*amuq*amel2^2*x3*x4^2*xcp4*e1245+624*ammu*amuq*amel2^2*x3*x4^2*xcp4*e1235+576*ammu*amuq*amel2^2*x3*x4^2*xcp4*e1234+
192*ammu*amuq*amel2^2*x3*x4^2*xcp3*e2345+240*ammu*amuq*amel2^2*x3*x4^2*xcp3*e1345+576*ammu*amuq*amel2^2*x3*x4^2*xcp3*e1245-1488*ammu*amuq*amel2^2*x3*x4^2*xcp3*e1235-576*ammu*amuq*amel2^2*x3*x4^2*xcp3*e1234-192*ammu*amuq*amel2^2*x3*x4^2*xcp2*e2345-
240*ammu*amuq*amel2^2*x3*x4^2*xcp2*e1345-576*ammu*amuq*amel2^2*x3*x4^2*xcp2*e1245+1488*ammu*amuq*amel2^2*x3*x4^2*xcp2*e1235+576*ammu*amuq*amel2^2*x3*x4^2*xcp2*e1234+192*ammu*amuq*amel2^2*x3*x4^2*xcp1*e2345+672*ammu*amuq*amel2^2*x3*x4^2*xcp1*e1345-
768*ammu*amuq*amel2^2*x3*x4^2*xcp1*e1245-624*ammu*amuq*amel2^2*x3*x4^2*xcp1*e1235-576*ammu*amuq*amel2^2*x3*x4^2*xcp1*e1234+384*ammu*amuq*amel2^2*x3^2*xcp4*e2345+432*ammu*amuq*amel2^2*x3^2*xcp4*e1235-48*ammu*amuq*amel2^2*x3^2*xcp3*e2345-96*ammu*amuq
*amel2^2*x3^2*xcp3*e1345-336*ammu*amuq*amel2^2*x3^2*xcp3*e1235+48*ammu*amuq*amel2^2*x3^2*xcp2*e2345+96*ammu*amuq*amel2^2*x3^2*xcp2*e1345+336*ammu*amuq*amel2^2*x3^2*xcp2*e1235-384*ammu*amuq*amel2^2*x3^2*xcp1*e2345-432*ammu*amuq*amel2^2*x3^2*xcp1*
e1235+48*ammu*amuq*amel2^2*x3^2*x6*xcp4*e2345+96*ammu*amuq*amel2^2*x3^2*x6*xcp4*e1345+192*ammu*amuq*amel2^2*x3^2*x6*xcp4*e1245+192*ammu*amuq*amel2^2*x3^2*x6*xcp4*e1235+192*ammu*amuq*amel2^2*x3^2*x6*xcp4*e1234+144*ammu*amuq*amel2^2*x3^2*x6*xcp3*
e2345+144*ammu*amuq*amel2^2*x3^2*x6*xcp3*e1345+192*ammu*amuq*amel2^2*x3^2*x6*xcp3*e1245-576*ammu*amuq*amel2^2*x3^2*x6*xcp3*e1235-192*ammu*amuq*amel2^2*x3^2*x6*xcp3*e1234-144*ammu*amuq*amel2^2*x3^2*x6*xcp2*e2345-144*ammu*amuq*amel2^2*x3^2*x6*xcp2*
e1345-192*ammu*amuq*amel2^2*x3^2*x6*xcp2*e1245+576*ammu*amuq*amel2^2*x3^2*x6*xcp2*e1235+192*ammu*amuq*amel2^2*x3^2*x6*xcp2*e1234-48*ammu*amuq*amel2^2*x3^2*x6*xcp1*e2345-96*ammu*amuq*amel2^2*x3^2*x6*xcp1*e1345-192*ammu*amuq*amel2^2*x3^2*x6*xcp1*
e1245-192*ammu*amuq*amel2^2*x3^2*x6*xcp1*e1235-192*ammu*amuq*amel2^2*x3^2*x6*xcp1*e1234-48*ammu*amuq*amel2^2*x3^2*x5*xcp4*e2345-96*ammu*amuq*amel2^2*x3^2*x5*xcp4*e1345+192*ammu*amuq*amel2^2*x3^2*x5*xcp4*e1245+192*ammu*amuq*amel2^2*x3^2*x5*xcp4*
e1235+144*ammu*amuq*amel2^2*x3^2*x5*xcp4*e1234+432*ammu*amuq*amel2^2*x3^2*x5*xcp3*e2345+720*ammu*amuq*amel2^2*x3^2*x5*xcp3*e1345+192*ammu*amuq*amel2^2*x3^2*x5*xcp3*e1245-576*ammu*amuq*amel2^2*x3^2*x5*xcp3*e1235-336*ammu*amuq*amel2^2*x3^2*x5*xcp3*
e1234-432*ammu*amuq*amel2^2*x3^2*x5*xcp2*e2345-720*ammu*amuq*amel2^2*x3^2*x5*xcp2*e1345-192*ammu*amuq*amel2^2*x3^2*x5*xcp2*e1245+576*ammu*amuq*amel2^2*x3^2*x5*xcp2*e1235+336*ammu*amuq*amel2^2*x3^2*x5*xcp2*e1234+48*ammu*amuq*amel2^2*x3^2*x5*xcp1*
e2345+96*ammu*amuq*amel2^2*x3^2*x5*xcp1*e1345-192*ammu*amuq*amel2^2*x3^2*x5*xcp1*e1245-192*ammu*amuq*amel2^2*x3^2*x5*xcp1*e1235-144*ammu*amuq*amel2^2*x3^2*x5*xcp1*e1234-96*ammu*amuq*amel2^2*x3^2*x4*xcp4*e2345-480*ammu*amuq*amel2^2*x3^2*x4*xcp4*
e1345+576*ammu*amuq*amel2^2*x3^2*x4*xcp4*e1245+528*ammu*amuq*amel2^2*x3^2*x4*xcp4*e1235+576*ammu*amuq*amel2^2*x3^2*x4*xcp4*e1234+96*ammu*amuq*amel2^2*x3^2*x4*xcp3*e2345+48*ammu*amuq*amel2^2*x3^2*x4*xcp3*e1345+576*ammu*amuq*amel2^2*x3^2*x4*xcp3*
e1245-1536*ammu*amuq*amel2^2*x3^2*x4*xcp3*e1235-576*ammu*amuq*amel2^2*x3^2*x4*xcp3*e1234-96*ammu*amuq*amel2^2*x3^2*x4*xcp2*e2345-48*ammu*amuq*amel2^2*x3^2*x4*xcp2*e1345-576*ammu*amuq*amel2^2*x3^2*x4*xcp2*e1245+1536*ammu*amuq*amel2^2*x3^2*x4*xcp2*
e1235+576*ammu*amuq*amel2^2*x3^2*x4*xcp2*e1234+96*ammu*amuq*amel2^2*x3^2*x4*xcp1*e2345+480*ammu*amuq*amel2^2*x3^2*x4*xcp1*e1345-576*ammu*amuq*amel2^2*x3^2*x4*xcp1*e1245-528*ammu*amuq*amel2^2*x3^2*x4*xcp1*e1235-576*ammu*amuq*amel2^2*x3^2*x4*xcp1*
e1234-96*ammu*amuq*amel2^2*x3^3*xcp4*e1345+192*ammu*amuq*amel2^2*x3^3*xcp4*e1245+192*ammu*amuq*amel2^2*x3^3*xcp4*e1235+192*ammu*amuq*amel2^2*x3^3*xcp4*e1234-48*ammu*amuq*amel2^2*x3^3*xcp3*e1345+192*ammu*amuq*amel2^2*x3^3*xcp3*e1245-576*ammu*amuq*
amel2^2*x3^3*xcp3*e1235-192*ammu*amuq*amel2^2*x3^3*xcp3*e1234+48*ammu*amuq*amel2^2*x3^3*xcp2*e1345-192*ammu*amuq*amel2^2*x3^3*xcp2*e1245+576*ammu*amuq*amel2^2*x3^3*xcp2*e1235+192*ammu*amuq*amel2^2*x3^3*xcp2*e1234+96*ammu*amuq*amel2^2*x3^3*xcp1*
e1345-192*ammu*amuq*amel2^2*x3^3*xcp1*e1245-192*ammu*amuq*amel2^2*x3^3*xcp1*e1235-192*ammu*amuq*amel2^2*x3^3*xcp1*e1234+336*ammu*amuq*amel2^2*x1*xcp4*e2345+144*ammu*amuq*amel2^2*x1*xcp4*e1345-192*ammu*amuq*amel2^2*x1*xcp4*e1245+1152*ammu*amuq*
amel2^2*x1*xcp4*e1235+1344*ammu*amuq*amel2^2*x1*xcp4*e1234-144*ammu*amuq*amel2^2*x1*xcp3*e2345+144*ammu*amuq*amel2^2*x1*xcp3*e1345-192*ammu*amuq*amel2^2*x1*xcp3*e1245+2064*ammu*amuq*amel2^2*x1*xcp3*e1235+192*ammu*amuq*amel2^2*x1*xcp3*e1234+144*ammu
*amuq*amel2^2*x1*xcp2*e2345-144*ammu*amuq*amel2^2*x1*xcp2*e1345+192*ammu*amuq*amel2^2*x1*xcp2*e1245-2064*ammu*amuq*amel2^2*x1*xcp2*e1235-192*ammu*amuq*amel2^2*x1*xcp2*e1234-336*ammu*amuq*amel2^2*x1*xcp1*e2345-144*ammu*amuq*amel2^2*x1*xcp1*e1345+192
*ammu*amuq*amel2^2*x1*xcp1*e1245-1152*ammu*amuq*amel2^2*x1*xcp1*e1235-1344*ammu*amuq*amel2^2*x1*xcp1*e1234+96*ammu*amuq*amel2^2*x1*x6*xcp4*e2345+192*ammu*amuq*amel2^2*x1*x6*xcp4*e1345-1200*ammu*amuq*amel2^2*x1*x6*xcp4*e1235-384*ammu*amuq*amel2^2*x1
*x6*xcp4*e1234-480*ammu*amuq*amel2^2*x1*x6*xcp3*e2345-144*ammu*amuq*amel2^2*x1*x6*xcp3*e1345+432*ammu*amuq*amel2^2*x1*x6*xcp3*e1235+480*ammu*amuq*amel2^2*x1*x6*xcp2*e2345+144*ammu*amuq*amel2^2*x1*x6*xcp2*e1345-432*ammu*amuq*amel2^2*x1*x6*xcp2*e1235
-96*ammu*amuq*amel2^2*x1*x6*xcp1*e2345-192*ammu*amuq*amel2^2*x1*x6*xcp1*e1345+1200*ammu*amuq*amel2^2*x1*x6*xcp1*e1235+384*ammu*amuq*amel2^2*x1*x6*xcp1*e1234+480*ammu*amuq*amel2^2*x1*x6^2*xcp4*e2345+192*ammu*amuq*amel2^2*x1*x6^2*xcp4*e1345+576*ammu*
amuq*amel2^2*x1*x6^2*xcp4*e1245+576*ammu*amuq*amel2^2*x1*x6^2*xcp4*e1235+576*ammu*amuq*amel2^2*x1*x6^2*xcp4*e1234+432*ammu*amuq*amel2^2*x1*x6^2*xcp3*e2345+192*ammu*amuq*amel2^2*x1*x6^2*xcp3*e1345+576*ammu*amuq*amel2^2*x1*x6^2*xcp3*e1245-1728*ammu*
amuq*amel2^2*x1*x6^2*xcp3*e1235-576*ammu*amuq*amel2^2*x1*x6^2*xcp3*e1234-432*ammu*amuq*amel2^2*x1*x6^2*xcp2*e2345-192*ammu*amuq*amel2^2*x1*x6^2*xcp2*e1345-576*ammu*amuq*amel2^2*x1*x6^2*xcp2*e1245+1728*ammu*amuq*amel2^2*x1*x6^2*xcp2*e1235+576*ammu*
amuq*amel2^2*x1*x6^2*xcp2*e1234-480*ammu*amuq*amel2^2*x1*x6^2*xcp1*e2345-192*ammu*amuq*amel2^2*x1*x6^2*xcp1*e1345-576*ammu*amuq*amel2^2*x1*x6^2*xcp1*e1245-576*ammu*amuq*amel2^2*x1*x6^2*xcp1*e1235-576*ammu*amuq*amel2^2*x1*x6^2*xcp1*e1234+336*ammu*
amuq*amel2^2*x1*x5*xcp4*e2345+528*ammu*amuq*amel2^2*x1*x5*xcp4*e1345-384*ammu*amuq*amel2^2*x1*x5*xcp4*e1245-1200*ammu*amuq*amel2^2*x1*x5*xcp4*e1235-672*ammu*amuq*amel2^2*x1*x5*xcp4*e1234-624*ammu*amuq*amel2^2*x1*x5*xcp3*e2345-960*ammu*amuq*amel2^2*
x1*x5*xcp3*e1345-384*ammu*amuq*amel2^2*x1*x5*xcp3*e1245+432*ammu*amuq*amel2^2*x1*x5*xcp3*e1235+528*ammu*amuq*amel2^2*x1*x5*xcp3*e1234+624*ammu*amuq*amel2^2*x1*x5*xcp2*e2345+960*ammu*amuq*amel2^2*x1*x5*xcp2*e1345+384*ammu*amuq*amel2^2*x1*x5*xcp2*
e1245-432*ammu*amuq*amel2^2*x1*x5*xcp2*e1235-528*ammu*amuq*amel2^2*x1*x5*xcp2*e1234-336*ammu*amuq*amel2^2*x1*x5*xcp1*e2345-528*ammu*amuq*amel2^2*x1*x5*xcp1*e1345+384*ammu*amuq*amel2^2*x1*x5*xcp1*e1245+1200*ammu*amuq*amel2^2*x1*x5*xcp1*e1235+672*
ammu*amuq*amel2^2*x1*x5*xcp1*e1234+576*ammu*amuq*amel2^2*x1*x5*x6*xcp4*e2345+96*ammu*amuq*amel2^2*x1*x5*x6*xcp4*e1345+1152*ammu*amuq*amel2^2*x1*x5*x6*xcp4*e1245+1152*ammu*amuq*amel2^2*x1*x5*x6*xcp4*e1235+1344*ammu*amuq*amel2^2*x1*x5*x6*xcp4*e1234+
2016*ammu*amuq*amel2^2*x1*x5*x6*xcp3*e2345+1248*ammu*amuq*amel2^2*x1*x5*x6*xcp3*e1345+1152*ammu*amuq*amel2^2*x1*x5*x6*xcp3*e1245-3456*ammu*amuq*amel2^2*x1*x5*x6*xcp3*e1235-624*ammu*amuq*amel2^2*x1*x5*x6*xcp3*e1234-2016*ammu*amuq*amel2^2*x1*x5*x6*
xcp2*e2345-1248*ammu*amuq*amel2^2*x1*x5*x6*xcp2*e1345-1152*ammu*amuq*amel2^2*x1*x5*x6*xcp2*e1245+3456*ammu*amuq*amel2^2*x1*x5*x6*xcp2*e1235+624*ammu*amuq*amel2^2*x1*x5*x6*xcp2*e1234-576*ammu*amuq*amel2^2*x1*x5*x6*xcp1*e2345-96*ammu*amuq*amel2^2*x1*
x5*x6*xcp1*e1345-1152*ammu*amuq*amel2^2*x1*x5*x6*xcp1*e1245-1152*ammu*amuq*amel2^2*x1*x5*x6*xcp1*e1235-1344*ammu*amuq*amel2^2*x1*x5*x6*xcp1*e1234+96*ammu*amuq*amel2^2*x1*x5^2*xcp4*e2345-96*ammu*amuq*amel2^2*x1*x5^2*xcp4*e1345+576*ammu*amuq*amel2^2*
x1*x5^2*xcp4*e1245+576*ammu*amuq*amel2^2*x1*x5^2*xcp4*e1235+864*ammu*amuq*amel2^2*x1*x5^2*xcp4*e1234+1584*ammu*amuq*amel2^2*x1*x5^2*xcp3*e2345+1056*ammu*amuq*amel2^2*x1*x5^2*xcp3*e1345+576*ammu*amuq*amel2^2*x1*x5^2*xcp3*e1245-1728*ammu*amuq*amel2^2
*x1*x5^2*xcp3*e1235+48*ammu*amuq*amel2^2*x1*x5^2*xcp3*e1234-1584*ammu*amuq*amel2^2*x1*x5^2*xcp2*e2345-1056*ammu*amuq*amel2^2*x1*x5^2*xcp2*e1345-576*ammu*amuq*amel2^2*x1*x5^2*xcp2*e1245+1728*ammu*amuq*amel2^2*x1*x5^2*xcp2*e1235-48*ammu*amuq*amel2^2*
x1*x5^2*xcp2*e1234-96*ammu*amuq*amel2^2*x1*x5^2*xcp1*e2345+96*ammu*amuq*amel2^2*x1*x5^2*xcp1*e1345-576*ammu*amuq*amel2^2*x1*x5^2*xcp1*e1245-576*ammu*amuq*amel2^2*x1*x5^2*xcp1*e1235-864*ammu*amuq*amel2^2*x1*x5^2*xcp1*e1234+48*ammu*amuq*amel2^2*x1*x4
*xcp4*e2345+384*ammu*amuq*amel2^2*x1*x4*xcp4*e1345-768*ammu*amuq*amel2^2*x1*x4*xcp4*e1245-1824*ammu*amuq*amel2^2*x1*x4*xcp4*e1235-1152*ammu*amuq*amel2^2*x1*x4*xcp4*e1234-192*ammu*amuq*amel2^2*x1*x4*xcp3*e2345-480*ammu*amuq*amel2^2*x1*x4*xcp3*e1345-
384*ammu*amuq*amel2^2*x1*x4*xcp3*e1245+720*ammu*amuq*amel2^2*x1*x4*xcp3*e1235+384*ammu*amuq*amel2^2*x1*x4*xcp3*e1234+192*ammu*amuq*amel2^2*x1*x4*xcp2*e2345+480*ammu*amuq*amel2^2*x1*x4*xcp2*e1345+384*ammu*amuq*amel2^2*x1*x4*xcp2*e1245-720*ammu*amuq*
amel2^2*x1*x4*xcp2*e1235-384*ammu*amuq*amel2^2*x1*x4*xcp2*e1234-48*ammu*amuq*amel2^2*x1*x4*xcp1*e2345-384*ammu*amuq*amel2^2*x1*x4*xcp1*e1345+768*ammu*amuq*amel2^2*x1*x4*xcp1*e1245+1824*ammu*amuq*amel2^2*x1*x4*xcp1*e1235+1152*ammu*amuq*amel2^2*x1*x4
*xcp1*e1234-384*ammu*amuq*amel2^2*x1*x4*x6*xcp4*e2345-192*ammu*amuq*amel2^2*x1*x4*x6*xcp4*e1345+384*ammu*amuq*amel2^2*x1*x4*x6*xcp4*e1245+768*ammu*amuq*amel2^2*x1*x4*x6*xcp4*e1235+576*ammu*amuq*amel2^2*x1*x4*x6*xcp4*e1234+432*ammu*amuq*amel2^2*x1*
x4*x6*xcp3*e2345+240*ammu*amuq*amel2^2*x1*x4*x6*xcp3*e1345+384*ammu*amuq*amel2^2*x1*x4*x6*xcp3*e1245-1680*ammu*amuq*amel2^2*x1*x4*x6*xcp3*e1235-384*ammu*amuq*amel2^2*x1*x4*x6*xcp3*e1234-432*ammu*amuq*amel2^2*x1*x4*x6*xcp2*e2345-240*ammu*amuq*
amel2^2*x1*x4*x6*xcp2*e1345-384*ammu*amuq*amel2^2*x1*x4*x6*xcp2*e1245+1680*ammu*amuq*amel2^2*x1*x4*x6*xcp2*e1235+384*ammu*amuq*amel2^2*x1*x4*x6*xcp2*e1234+384*ammu*amuq*amel2^2*x1*x4*x6*xcp1*e2345+192*ammu*amuq*amel2^2*x1*x4*x6*xcp1*e1345-384*ammu*
amuq*amel2^2*x1*x4*x6*xcp1*e1245-768*ammu*amuq*amel2^2*x1*x4*x6*xcp1*e1235-576*ammu*amuq*amel2^2*x1*x4*x6*xcp1*e1234-432*ammu*amuq*amel2^2*x1*x4*x5*xcp4*e2345-288*ammu*amuq*amel2^2*x1*x4*x5*xcp4*e1345+960*ammu*amuq*amel2^2*x1*x4*x5*xcp4*e1245+864*
ammu*amuq*amel2^2*x1*x4*x5*xcp4*e1235+672*ammu*amuq*amel2^2*x1*x4*x5*xcp4*e1234+624*ammu*amuq*amel2^2*x1*x4*x5*xcp3*e2345+528*ammu*amuq*amel2^2*x1*x4*x5*xcp3*e1345+576*ammu*amuq*amel2^2*x1*x4*x5*xcp3*e1245-2352*ammu*amuq*amel2^2*x1*x4*x5*xcp3*e1235
-480*ammu*amuq*amel2^2*x1*x4*x5*xcp3*e1234-624*ammu*amuq*amel2^2*x1*x4*x5*xcp2*e2345-528*ammu*amuq*amel2^2*x1*x4*x5*xcp2*e1345-576*ammu*amuq*amel2^2*x1*x4*x5*xcp2*e1245+2352*ammu*amuq*amel2^2*x1*x4*x5*xcp2*e1235+480*ammu*amuq*amel2^2*x1*x4*x5*xcp2*
e1234+432*ammu*amuq*amel2^2*x1*x4*x5*xcp1*e2345+288*ammu*amuq*amel2^2*x1*x4*x5*xcp1*e1345-960*ammu*amuq*amel2^2*x1*x4*x5*xcp1*e1245-864*ammu*amuq*amel2^2*x1*x4*x5*xcp1*e1235-672*ammu*amuq*amel2^2*x1*x4*x5*xcp1*e1234-96*ammu*amuq*amel2^2*x1*x4^2*
xcp4*e2345-96*ammu*amuq*amel2^2*x1*x4^2*xcp4*e1345+384*ammu*amuq*amel2^2*x1*x4^2*xcp4*e1245+288*ammu*amuq*amel2^2*x1*x4^2*xcp4*e1235+192*ammu*amuq*amel2^2*x1*x4^2*xcp4*e1234+96*ammu*amuq*amel2^2*x1*x4^2*xcp3*e2345+96*ammu*amuq*amel2^2*x1*x4^2*xcp3*
e1345+192*ammu*amuq*amel2^2*x1*x4^2*xcp3*e1245-672*ammu*amuq*amel2^2*x1*x4^2*xcp3*e1235-192*ammu*amuq*amel2^2*x1*x4^2*xcp3*e1234-96*ammu*amuq*amel2^2*x1*x4^2*xcp2*e2345-96*ammu*amuq*amel2^2*x1*x4^2*xcp2*e1345-192*ammu*amuq*amel2^2*x1*x4^2*xcp2*
e1245+672*ammu*amuq*amel2^2*x1*x4^2*xcp2*e1235+192*ammu*amuq*amel2^2*x1*x4^2*xcp2*e1234+96*ammu*amuq*amel2^2*x1*x4^2*xcp1*e2345+96*ammu*amuq*amel2^2*x1*x4^2*xcp1*e1345-384*ammu*amuq*amel2^2*x1*x4^2*xcp1*e1245-288*ammu*amuq*amel2^2*x1*x4^2*xcp1*
e1235-192*ammu*amuq*amel2^2*x1*x4^2*xcp1*e1234+96*ammu*amuq*amel2^2*x1*x3*xcp4*e2345+144*ammu*amuq*amel2^2*x1*x3*xcp4*e1345-384*ammu*amuq*amel2^2*x1*x3*xcp4*e1245-384*ammu*amuq*amel2^2*x1*x3*xcp4*e1235-384*ammu*amuq*amel2^2*x1*x3*xcp4*e1234-240*
ammu*amuq*amel2^2*x1*x3*xcp3*e2345-240*ammu*amuq*amel2^2*x1*x3*xcp3*e1345-384*ammu*amuq*amel2^2*x1*x3*xcp3*e1245+1152*ammu*amuq*amel2^2*x1*x3*xcp3*e1235+384*ammu*amuq*amel2^2*x1*x3*xcp3*e1234+240*ammu*amuq*amel2^2*x1*x3*xcp2*e2345+240*ammu*amuq*
amel2^2*x1*x3*xcp2*e1345+384*ammu*amuq*amel2^2*x1*x3*xcp2*e1245-1152*ammu*amuq*amel2^2*x1*x3*xcp2*e1235-384*ammu*amuq*amel2^2*x1*x3*xcp2*e1234-96*ammu*amuq*amel2^2*x1*x3*xcp1*e2345-144*ammu*amuq*amel2^2*x1*x3*xcp1*e1345+384*ammu*amuq*amel2^2*x1*x3*
xcp1*e1245+384*ammu*amuq*amel2^2*x1*x3*xcp1*e1235+384*ammu*amuq*amel2^2*x1*x3*xcp1*e1234+96*ammu*amuq*amel2^2*x1*x3*x6*xcp4*e1345+384*ammu*amuq*amel2^2*x1*x3*x6*xcp4*e1245+384*ammu*amuq*amel2^2*x1*x3*x6*xcp4*e1235+384*ammu*amuq*amel2^2*x1*x3*x6*
xcp4*e1234+48*ammu*amuq*amel2^2*x1*x3*x6*xcp3*e2345-48*ammu*amuq*amel2^2*x1*x3*x6*xcp3*e1345+384*ammu*amuq*amel2^2*x1*x3*x6*xcp3*e1245-1152*ammu*amuq*amel2^2*x1*x3*x6*xcp3*e1235-384*ammu*amuq*amel2^2*x1*x3*x6*xcp3*e1234-48*ammu*amuq*amel2^2*x1*x3*
x6*xcp2*e2345+48*ammu*amuq*amel2^2*x1*x3*x6*xcp2*e1345-384*ammu*amuq*amel2^2*x1*x3*x6*xcp2*e1245+1152*ammu*amuq*amel2^2*x1*x3*x6*xcp2*e1235+384*ammu*amuq*amel2^2*x1*x3*x6*xcp2*e1234-96*ammu*amuq*amel2^2*x1*x3*x6*xcp1*e1345-384*ammu*amuq*amel2^2*x1*
x3*x6*xcp1*e1245-384*ammu*amuq*amel2^2*x1*x3*x6*xcp1*e1235-384*ammu*amuq*amel2^2*x1*x3*x6*xcp1*e1234-48*ammu*amuq*amel2^2*x1*x3*x5*xcp4*e2345+384*ammu*amuq*amel2^2*x1*x3*x5*xcp4*e1245+384*ammu*amuq*amel2^2*x1*x3*x5*xcp4*e1235+384*ammu*amuq*amel2^2*
x1*x3*x5*xcp4*e1234+192*ammu*amuq*amel2^2*x1*x3*x5*xcp3*e2345+240*ammu*amuq*amel2^2*x1*x3*x5*xcp3*e1345+384*ammu*amuq*amel2^2*x1*x3*x5*xcp3*e1245-1152*ammu*amuq*amel2^2*x1*x3*x5*xcp3*e1235-384*ammu*amuq*amel2^2*x1*x3*x5*xcp3*e1234-192*ammu*amuq*
amel2^2*x1*x3*x5*xcp2*e2345-240*ammu*amuq*amel2^2*x1*x3*x5*xcp2*e1345-384*ammu*amuq*amel2^2*x1*x3*x5*xcp2*e1245+1152*ammu*amuq*amel2^2*x1*x3*x5*xcp2*e1235+384*ammu*amuq*amel2^2*x1*x3*x5*xcp2*e1234+48*ammu*amuq*amel2^2*x1*x3*x5*xcp1*e2345-384*ammu*
amuq*amel2^2*x1*x3*x5*xcp1*e1245-384*ammu*amuq*amel2^2*x1*x3*x5*xcp1*e1235-384*ammu*amuq*amel2^2*x1*x3*x5*xcp1*e1234-144*ammu*amuq*amel2^2*x1*x3*x4*xcp4*e2345-96*ammu*amuq*amel2^2*x1*x3*x4*xcp4*e1345+384*ammu*amuq*amel2^2*x1*x3*x4*xcp4*e1245+384*
ammu*amuq*amel2^2*x1*x3*x4*xcp4*e1235+384*ammu*amuq*amel2^2*x1*x3*x4*xcp4*e1234+144*ammu*amuq*amel2^2*x1*x3*x4*xcp3*e2345+96*ammu*amuq*amel2^2*x1*x3*x4*xcp3*e1345+384*ammu*amuq*amel2^2*x1*x3*x4*xcp3*e1245-1152*ammu*amuq*amel2^2*x1*x3*x4*xcp3*e1235-
384*ammu*amuq*amel2^2*x1*x3*x4*xcp3*e1234-144*ammu*amuq*amel2^2*x1*x3*x4*xcp2*e2345-96*ammu*amuq*amel2^2*x1*x3*x4*xcp2*e1345-384*ammu*amuq*amel2^2*x1*x3*x4*xcp2*e1245+1152*ammu*amuq*amel2^2*x1*x3*x4*xcp2*e1235+384*ammu*amuq*amel2^2*x1*x3*x4*xcp2*
e1234+144*ammu*amuq*amel2^2*x1*x3*x4*xcp1*e2345+96*ammu*amuq*amel2^2*x1*x3*x4*xcp1*e1345-384*ammu*amuq*amel2^2*x1*x3*x4*xcp1*e1245-384*ammu*amuq*amel2^2*x1*x3*x4*xcp1*e1235-384*ammu*amuq*amel2^2*x1*x3*x4*xcp1*e1234-48*ammu*amuq*amel2^2*x1*x3^2*xcp4
*e2345+192*ammu*amuq*amel2^2*x1*x3^2*xcp4*e1245+192*ammu*amuq*amel2^2*x1*x3^2*xcp4*e1235+192*ammu*amuq*amel2^2*x1*x3^2*xcp4*e1234+48*ammu*amuq*amel2^2*x1*x3^2*xcp3*e2345+192*ammu*amuq*amel2^2*x1*x3^2*xcp3*e1245-576*ammu*amuq*amel2^2*x1*x3^2*xcp3*
e1235-192*ammu*amuq*amel2^2*x1*x3^2*xcp3*e1234-48*ammu*amuq*amel2^2*x1*x3^2*xcp2*e2345-192*ammu*amuq*amel2^2*x1*x3^2*xcp2*e1245+576*ammu*amuq*amel2^2*x1*x3^2*xcp2*e1235+192*ammu*amuq*amel2^2*x1*x3^2*xcp2*e1234+48*ammu*amuq*amel2^2*x1*x3^2*xcp1*
e2345-192*ammu*amuq*amel2^2*x1*x3^2*xcp1*e1245-192*ammu*amuq*amel2^2*x1*x3^2*xcp1*e1235-192*ammu*amuq*amel2^2*x1*x3^2*xcp1*e1234+48*ammu*amuq*amel2^2*x1^2*xcp4*e2345+144*ammu*amuq*amel2^2*x1^2*xcp4*e1345-432*ammu*amuq*amel2^2*x1^2*xcp4*e1235-336*
ammu*amuq*amel2^2*x1^2*xcp3*e2345+384*ammu*amuq*amel2^2*x1^2*xcp3*e1235+336*ammu*amuq*amel2^2*x1^2*xcp2*e2345-384*ammu*amuq*amel2^2*x1^2*xcp2*e1235-48*ammu*amuq*amel2^2*x1^2*xcp1*e2345-144*ammu*amuq*amel2^2*x1^2*xcp1*e1345+432*ammu*amuq*amel2^2*
x1^2*xcp1*e1235+384*ammu*amuq*amel2^2*x1^2*x6*xcp4*e2345+96*ammu*amuq*amel2^2*x1^2*x6*xcp4*e1345+576*ammu*amuq*amel2^2*x1^2*x6*xcp4*e1245+576*ammu*amuq*amel2^2*x1^2*x6*xcp4*e1235+576*ammu*amuq*amel2^2*x1^2*x6*xcp4*e1234+288*ammu*amuq*amel2^2*x1^2*
x6*xcp3*e2345+96*ammu*amuq*amel2^2*x1^2*x6*xcp3*e1345+576*ammu*amuq*amel2^2*x1^2*x6*xcp3*e1245-1728*ammu*amuq*amel2^2*x1^2*x6*xcp3*e1235-576*ammu*amuq*amel2^2*x1^2*x6*xcp3*e1234-288*ammu*amuq*amel2^2*x1^2*x6*xcp2*e2345-96*ammu*amuq*amel2^2*x1^2*x6*
xcp2*e1345-576*ammu*amuq*amel2^2*x1^2*x6*xcp2*e1245+1728*ammu*amuq*amel2^2*x1^2*x6*xcp2*e1235+576*ammu*amuq*amel2^2*x1^2*x6*xcp2*e1234-384*ammu*amuq*amel2^2*x1^2*x6*xcp1*e2345-96*ammu*amuq*amel2^2*x1^2*x6*xcp1*e1345-576*ammu*amuq*amel2^2*x1^2*x6*
xcp1*e1245-576*ammu*amuq*amel2^2*x1^2*x6*xcp1*e1235-576*ammu*amuq*amel2^2*x1^2*x6*xcp1*e1234+192*ammu*amuq*amel2^2*x1^2*x5*xcp4*e2345-48*ammu*amuq*amel2^2*x1^2*x5*xcp4*e1345+576*ammu*amuq*amel2^2*x1^2*x5*xcp4*e1245+576*ammu*amuq*amel2^2*x1^2*x5*
xcp4*e1235+672*ammu*amuq*amel2^2*x1^2*x5*xcp4*e1234+864*ammu*amuq*amel2^2*x1^2*x5*xcp3*e2345+528*ammu*amuq*amel2^2*x1^2*x5*xcp3*e1345+576*ammu*amuq*amel2^2*x1^2*x5*xcp3*e1245-1728*ammu*amuq*amel2^2*x1^2*x5*xcp3*e1235-336*ammu*amuq*amel2^2*x1^2*x5*
xcp3*e1234-864*ammu*amuq*amel2^2*x1^2*x5*xcp2*e2345-528*ammu*amuq*amel2^2*x1^2*x5*xcp2*e1345-576*ammu*amuq*amel2^2*x1^2*x5*xcp2*e1245+1728*ammu*amuq*amel2^2*x1^2*x5*xcp2*e1235+336*ammu*amuq*amel2^2*x1^2*x5*xcp2*e1234-192*ammu*amuq*amel2^2*x1^2*x5*
xcp1*e2345+48*ammu*amuq*amel2^2*x1^2*x5*xcp1*e1345-576*ammu*amuq*amel2^2*x1^2*x5*xcp1*e1245-576*ammu*amuq*amel2^2*x1^2*x5*xcp1*e1235-672*ammu*amuq*amel2^2*x1^2*x5*xcp1*e1234-192*ammu*amuq*amel2^2*x1^2*x4*xcp4*e2345-96*ammu*amuq*amel2^2*x1^2*x4*xcp4
*e1345+192*ammu*amuq*amel2^2*x1^2*x4*xcp4*e1245+288*ammu*amuq*amel2^2*x1^2*x4*xcp4*e1235+192*ammu*amuq*amel2^2*x1^2*x4*xcp4*e1234+192*ammu*amuq*amel2^2*x1^2*x4*xcp3*e2345+96*ammu*amuq*amel2^2*x1^2*x4*xcp3*e1345+192*ammu*amuq*amel2^2*x1^2*x4*xcp3*
e1245-768*ammu*amuq*amel2^2*x1^2*x4*xcp3*e1235-192*ammu*amuq*amel2^2*x1^2*x4*xcp3*e1234-192*ammu*amuq*amel2^2*x1^2*x4*xcp2*e2345-96*ammu*amuq*amel2^2*x1^2*x4*xcp2*e1345-192*ammu*amuq*amel2^2*x1^2*x4*xcp2*e1245+768*ammu*amuq*amel2^2*x1^2*x4*xcp2*
e1235+192*ammu*amuq*amel2^2*x1^2*x4*xcp2*e1234+192*ammu*amuq*amel2^2*x1^2*x4*xcp1*e2345+96*ammu*amuq*amel2^2*x1^2*x4*xcp1*e1345-192*ammu*amuq*amel2^2*x1^2*x4*xcp1*e1245-288*ammu*amuq*amel2^2*x1^2*x4*xcp1*e1235-192*ammu*amuq*amel2^2*x1^2*x4*xcp1*
e1234+48*ammu*amuq*amel2^2*x1^2*x3*xcp4*e1345+192*ammu*amuq*amel2^2*x1^2*x3*xcp4*e1245+192*ammu*amuq*amel2^2*x1^2*x3*xcp4*e1235+192*ammu*amuq*amel2^2*x1^2*x3*xcp4*e1234-48*ammu*amuq*amel2^2*x1^2*x3*xcp3*e1345+192*ammu*amuq*amel2^2*x1^2*x3*xcp3*
e1245-576*ammu*amuq*amel2^2*x1^2*x3*xcp3*e1235-192*ammu*amuq*amel2^2*x1^2*x3*xcp3*e1234+48*ammu*amuq*amel2^2*x1^2*x3*xcp2*e1345-192*ammu*amuq*amel2^2*x1^2*x3*xcp2*e1245+576*ammu*amuq*amel2^2*x1^2*x3*xcp2*e1235+192*ammu*amuq*amel2^2*x1^2*x3*xcp2*
e1234-48*ammu*amuq*amel2^2*x1^2*x3*xcp1*e1345-192*ammu*amuq*amel2^2*x1^2*x3*xcp1*e1245-192*ammu*amuq*amel2^2*x1^2*x3*xcp1*e1235-192*ammu*amuq*amel2^2*x1^2*x3*xcp1*e1234+96*ammu*amuq*amel2^2*x1^3*xcp4*e2345+192*ammu*amuq*amel2^2*x1^3*xcp4*e1245+192*
ammu*amuq*amel2^2*x1^3*xcp4*e1235+192*ammu*amuq*amel2^2*x1^3*xcp4*e1234+48*ammu*amuq*amel2^2*x1^3*xcp3*e2345+192*ammu*amuq*amel2^2*x1^3*xcp3*e1245-576*ammu*amuq*amel2^2*x1^3*xcp3*e1235-192*ammu*amuq*amel2^2*x1^3*xcp3*e1234-48*ammu*amuq*amel2^2*x1^3
*xcp2*e2345-192*ammu*amuq*amel2^2*x1^3*xcp2*e1245+576*ammu*amuq*amel2^2*x1^3*xcp2*e1235+192*ammu*amuq*amel2^2*x1^3*xcp2*e1234-96*ammu*amuq*amel2^2*x1^3*xcp1*e2345-192*ammu*amuq*amel2^2*x1^3*xcp1*e1245-192*ammu*amuq*amel2^2*x1^3*xcp1*e1235-192*ammu*
amuq*amel2^2*x1^3*xcp1*e1234-192*ammu*amuq*amel2^2*ammu2*amuq2*x6*xcp4-192*ammu*amuq*amel2^2*ammu2*amuq2*x6*xcp3-192*ammu*amuq*amel2^2*ammu2*amuq2*x6*xcp2-192*ammu*amuq*amel2^2*ammu2*amuq2*x6*xcp1+192*ammu*amuq*amel2^2*ammu2*amuq2*x6^2*xcp4+192*
ammu*amuq*amel2^2*ammu2*amuq2*x6^2*xcp3+192*ammu*amuq*amel2^2*ammu2*amuq2*x6^2*xcp2+192*ammu*amuq*amel2^2*ammu2*amuq2*x6^2*xcp1+192*ammu*amuq*amel2^2*ammu2*amuq2*x5*x6*xcp4+192*ammu*amuq*amel2^2*ammu2*amuq2*x5*x6*xcp3+192*ammu*amuq*amel2^2*ammu2*
amuq2*x5*x6*xcp2+192*ammu*amuq*amel2^2*ammu2*amuq2*x5*x6*xcp1-576*ammu*amuq*amel2^2*ammu2*amuq2*x4*xcp4+192*ammu*amuq*amel2^2*ammu2*amuq2*x4*xcp3+192*ammu*amuq*amel2^2*ammu2*amuq2*x4*xcp2-576*ammu*amuq*amel2^2*ammu2*amuq2*x4*xcp1+192*ammu*amuq*
amel2^2*ammu2*amuq2*x4*x6*xcp4-960*ammu*amuq*amel2^2*ammu2*amuq2*x4*x6*xcp3-960*ammu*amuq*amel2^2*ammu2*amuq2*x4*x6*xcp2+192*ammu*amuq*amel2^2*ammu2*amuq2*x4*x6*xcp1-192*ammu*amuq*amel2^2*ammu2*amuq2*x4*x6^2*xcp4+192*ammu*amuq*amel2^2*ammu2*amuq2*
x4*x6^2*xcp3+192*ammu*amuq*amel2^2*ammu2*amuq2*x4*x6^2*xcp2-192*ammu*amuq*amel2^2*ammu2*amuq2*x4*x6^2*xcp1+576*ammu*amuq*amel2^2*ammu2*amuq2*x4*x5*xcp4-960*ammu*amuq*amel2^2*ammu2*amuq2*x4*x5*xcp3-960*ammu*amuq*amel2^2*ammu2*amuq2*x4*x5*xcp2+576*
ammu*amuq*amel2^2*ammu2*amuq2*x4*x5*xcp1-576*ammu*amuq*amel2^2*ammu2*amuq2*x4*x5*x6*xcp4+576*ammu*amuq*amel2^2*ammu2*amuq2*x4*x5*x6*xcp3+576*ammu*amuq*amel2^2*ammu2*amuq2*x4*x5*x6*xcp2-576*ammu*amuq*amel2^2*ammu2*amuq2*x4*x5*x6*xcp1-384*ammu*amuq*
amel2^2*ammu2*amuq2*x4*x5^2*xcp4+384*ammu*amuq*amel2^2*ammu2*amuq2*x4*x5^2*xcp3+384*ammu*amuq*amel2^2*ammu2*amuq2*x4*x5^2*xcp2-384*ammu*amuq*amel2^2*ammu2*amuq2*x4*x5^2*xcp1+768*ammu*amuq*amel2^2*ammu2*amuq2*x4^2*xcp4+384*ammu*amuq*amel2^2*ammu2*
amuq2*x4^2*xcp3+384*ammu*amuq*amel2^2*ammu2*amuq2*x4^2*xcp2+768*ammu*amuq*amel2^2*ammu2*amuq2*x4^2*xcp1+384*ammu*amuq*amel2^2*ammu2*amuq2*x4^2*x6*xcp3+384*ammu*amuq*amel2^2*ammu2*amuq2*x4^2*x6*xcp2-192*ammu*amuq*amel2^2*ammu2*amuq2*x4^2*x5*xcp4+192
*ammu*amuq*amel2^2*ammu2*amuq2*x4^2*x5*xcp3+192*ammu*amuq*amel2^2*ammu2*amuq2*x4^2*x5*xcp2-192*ammu*amuq*amel2^2*ammu2*amuq2*x4^2*x5*xcp1-192*ammu*amuq*amel2^2*ammu2*amuq2*x4^3*xcp4-192*ammu*amuq*amel2^2*ammu2*amuq2*x4^3*xcp3-192*ammu*amuq*amel2^2*
ammu2*amuq2*x4^3*xcp2-192*ammu*amuq*amel2^2*ammu2*amuq2*x4^3*xcp1-192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x6*xcp4-192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x6*xcp3-192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x6*xcp2-192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x6*xcp1-
192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4*xcp4+576*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4*xcp3+576*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4*xcp2-192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4*xcp1+192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4*x6*xcp4-192*ammu*amuq*
amel2^2*ammu2*amuq2*x3*x4*x6*xcp3-192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4*x6*xcp2+192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4*x6*xcp1+384*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4*x5*xcp4-384*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4*x5*xcp3-384*ammu*amuq*amel2^2*
ammu2*amuq2*x3*x4*x5*xcp2+384*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4*x5*xcp1+192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4^2*xcp4-192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4^2*xcp3-192*ammu*amuq*amel2^2*ammu2*amuq2*x3*x4^2*xcp2+192*ammu*amuq*amel2^2*ammu2*amuq2
*x3*x4^2*xcp1+192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x6*xcp4+192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x6*xcp3+192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x6*xcp2+192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x6*xcp1+192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4*xcp4-576*ammu*
amuq*amel2^2*ammu2*amuq2*x1*x4*xcp3-576*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4*xcp2+192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4*xcp1-192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4*x6*xcp4+192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4*x6*xcp3+192*ammu*amuq*amel2^2*
ammu2*amuq2*x1*x4*x6*xcp2-192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4*x6*xcp1-384*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4*x5*xcp4+384*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4*x5*xcp3+384*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4*x5*xcp2-384*ammu*amuq*amel2^2*ammu2*
amuq2*x1*x4*x5*xcp1-192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4^2*xcp4+192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4^2*xcp3+192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4^2*xcp2-192*ammu*amuq*amel2^2*ammu2*amuq2*x1*x4^2*xcp1-4032*ammu*amuq*amel2^2*ammu2^2*x6*xcp4-
576*ammu*amuq*amel2^2*ammu2^2*x6*xcp3-576*ammu*amuq*amel2^2*ammu2^2*x6*xcp2-4032*ammu*amuq*amel2^2*ammu2^2*x6*xcp1+3648*ammu*amuq*amel2^2*ammu2^2*x6^2*xcp4-768*ammu*amuq*amel2^2*ammu2^2*x6^2*xcp3-768*ammu*amuq*amel2^2*ammu2^2*x6^2*xcp2+3648*ammu*
amuq*amel2^2*ammu2^2*x6^2*xcp1-768*ammu*amuq*amel2^2*ammu2^2*x6^3*xcp4+576*ammu*amuq*amel2^2*ammu2^2*x6^3*xcp3+576*ammu*amuq*amel2^2*ammu2^2*x6^3*xcp2-768*ammu*amuq*amel2^2*ammu2^2*x6^3*xcp1-4608*ammu*amuq*amel2^2*ammu2^2*x5*xcp4-384*ammu*amuq*
amel2^2*ammu2^2*x5*xcp3-384*ammu*amuq*amel2^2*ammu2^2*x5*xcp2-4608*ammu*amuq*amel2^2*ammu2^2*x5*xcp1+9024*ammu*amuq*amel2^2*ammu2^2*x5*x6*xcp4-2496*ammu*amuq*amel2^2*ammu2^2*x5*x6*xcp3-2496*ammu*amuq*amel2^2*ammu2^2*x5*x6*xcp2+9024*ammu*amuq*
amel2^2*ammu2^2*x5*x6*xcp1-3456*ammu*amuq*amel2^2*ammu2^2*x5*x6^2*xcp4+2112*ammu*amuq*amel2^2*ammu2^2*x5*x6^2*xcp3+2112*ammu*amuq*amel2^2*ammu2^2*x5*x6^2*xcp2-3456*ammu*amuq*amel2^2*ammu2^2*x5*x6^2*xcp1+6144*ammu*amuq*amel2^2*ammu2^2*x5^2*xcp4-1920
*ammu*amuq*amel2^2*ammu2^2*x5^2*xcp3-1920*ammu*amuq*amel2^2*ammu2^2*x5^2*xcp2+6144*ammu*amuq*amel2^2*ammu2^2*x5^2*xcp1-4608*ammu*amuq*amel2^2*ammu2^2*x5^2*x6*xcp4+3072*ammu*amuq*amel2^2*ammu2^2*x5^2*x6*xcp3+3072*ammu*amuq*amel2^2*ammu2^2*x5^2*x6*
xcp2-4608*ammu*amuq*amel2^2*ammu2^2*x5^2*x6*xcp1-2304*ammu*amuq*amel2^2*ammu2^2*x5^3*xcp4+1536*ammu*amuq*amel2^2*ammu2^2*x5^3*xcp3+1536*ammu*amuq*amel2^2*ammu2^2*x5^3*xcp2-2304*ammu*amuq*amel2^2*ammu2^2*x5^3*xcp1+192*ammu*amuq*amel2^2*ammu2^2*x4*
xcp4+192*ammu*amuq*amel2^2*ammu2^2*x4*xcp3+192*ammu*amuq*amel2^2*ammu2^2*x4*xcp2+192*ammu*amuq*amel2^2*ammu2^2*x4*xcp1+2880*ammu*amuq*amel2^2*ammu2^2*x4*x6*xcp4-576*ammu*amuq*amel2^2*ammu2^2*x4*x6*xcp3-576*ammu*amuq*amel2^2*ammu2^2*x4*x6*xcp2+2880*
ammu*amuq*amel2^2*ammu2^2*x4*x6*xcp1-960*ammu*amuq*amel2^2*ammu2^2*x4*x6^2*xcp4-960*ammu*amuq*amel2^2*ammu2^2*x4*x6^2*xcp1+4416*ammu*amuq*amel2^2*ammu2^2*x4*x5*xcp4-576*ammu*amuq*amel2^2*ammu2^2*x4*x5*xcp3-576*ammu*amuq*amel2^2*ammu2^2*x4*x5*xcp2+
4416*ammu*amuq*amel2^2*ammu2^2*x4*x5*xcp1-2880*ammu*amuq*amel2^2*ammu2^2*x4*x5*x6*xcp4+1728*ammu*amuq*amel2^2*ammu2^2*x4*x5*x6*xcp3+1728*ammu*amuq*amel2^2*ammu2^2*x4*x5*x6*xcp2-2880*ammu*amuq*amel2^2*ammu2^2*x4*x5*x6*xcp1-3072*ammu*amuq*amel2^2*
ammu2^2*x4*x5^2*xcp4+1536*ammu*amuq*amel2^2*ammu2^2*x4*x5^2*xcp3+1536*ammu*amuq*amel2^2*ammu2^2*x4*x5^2*xcp2-3072*ammu*amuq*amel2^2*ammu2^2*x4*x5^2*xcp1+384*ammu*amuq*amel2^2*ammu2^2*x4^2*xcp4-192*ammu*amuq*amel2^2*ammu2^2*x4^2*xcp3-192*ammu*amuq*
amel2^2*ammu2^2*x4^2*xcp2+384*ammu*amuq*amel2^2*ammu2^2*x4^2*xcp1-768*ammu*amuq*amel2^2*ammu2^2*x4^2*x6*xcp4+576*ammu*amuq*amel2^2*ammu2^2*x4^2*x6*xcp3+576*ammu*amuq*amel2^2*ammu2^2*x4^2*x6*xcp2-768*ammu*amuq*amel2^2*ammu2^2*x4^2*x6*xcp1-1728*ammu*
amuq*amel2^2*ammu2^2*x4^2*x5*xcp4+384*ammu*amuq*amel2^2*ammu2^2*x4^2*x5*xcp3+384*ammu*amuq*amel2^2*ammu2^2*x4^2*x5*xcp2-1728*ammu*amuq*amel2^2*ammu2^2*x4^2*x5*xcp1-192*ammu*amuq*amel2^2*ammu2^2*x4^3*xcp4-192*ammu*amuq*amel2^2*ammu2^2*x4^3*xcp1-576*
ammu*amuq*amel2^2*ammu2^2*x3*x6*xcp4-960*ammu*amuq*amel2^2*ammu2^2*x3*x6*xcp3-960*ammu*amuq*amel2^2*ammu2^2*x3*x6*xcp2-576*ammu*amuq*amel2^2*ammu2^2*x3*x6*xcp1+576*ammu*amuq*amel2^2*ammu2^2*x3*x6^2*xcp3+576*ammu*amuq*amel2^2*ammu2^2*x3*x6^2*xcp2-
384*ammu*amuq*amel2^2*ammu2^2*x3*x5*xcp4-768*ammu*amuq*amel2^2*ammu2^2*x3*x5*xcp3-768*ammu*amuq*amel2^2*ammu2^2*x3*x5*xcp2-384*ammu*amuq*amel2^2*ammu2^2*x3*x5*xcp1+384*ammu*amuq*amel2^2*ammu2^2*x3*x5*x6*xcp4+1152*ammu*amuq*amel2^2*ammu2^2*x3*x5*x6*
xcp3+1152*ammu*amuq*amel2^2*ammu2^2*x3*x5*x6*xcp2+384*ammu*amuq*amel2^2*ammu2^2*x3*x5*x6*xcp1+384*ammu*amuq*amel2^2*ammu2^2*x3*x5^2*xcp4+384*ammu*amuq*amel2^2*ammu2^2*x3*x5^2*xcp3+384*ammu*amuq*amel2^2*ammu2^2*x3*x5^2*xcp2+384*ammu*amuq*amel2^2*
ammu2^2*x3*x5^2*xcp1+576*ammu*amuq*amel2^2*ammu2^2*x3*x4*xcp4-192*ammu*amuq*amel2^2*ammu2^2*x3*x4*xcp3-192*ammu*amuq*amel2^2*ammu2^2*x3*x4*xcp2+576*ammu*amuq*amel2^2*ammu2^2*x3*x4*xcp1-576*ammu*amuq*amel2^2*ammu2^2*x3*x4*x6*xcp4+960*ammu*amuq*
amel2^2*ammu2^2*x3*x4*x6*xcp3+960*ammu*amuq*amel2^2*ammu2^2*x3*x4*x6*xcp2-576*ammu*amuq*amel2^2*ammu2^2*x3*x4*x6*xcp1-768*ammu*amuq*amel2^2*ammu2^2*x3*x4*x5*xcp4+768*ammu*amuq*amel2^2*ammu2^2*x3*x4*x5*xcp3+768*ammu*amuq*amel2^2*ammu2^2*x3*x4*x5*
xcp2-768*ammu*amuq*amel2^2*ammu2^2*x3*x4*x5*xcp1-192*ammu*amuq*amel2^2*ammu2^2*x3*x4^2*xcp4-192*ammu*amuq*amel2^2*ammu2^2*x3*x4^2*xcp1-384*ammu*amuq*amel2^2*ammu2^2*x3^2*x6*xcp4+384*ammu*amuq*amel2^2*ammu2^2*x3^2*x6*xcp3+384*ammu*amuq*amel2^2*
ammu2^2*x3^2*x6*xcp2-384*ammu*amuq*amel2^2*ammu2^2*x3^2*x6*xcp1-384*ammu*amuq*amel2^2*ammu2^2*x3^2*x5*xcp4+384*ammu*amuq*amel2^2*ammu2^2*x3^2*x5*xcp3+384*ammu*amuq*amel2^2*ammu2^2*x3^2*x5*xcp2-384*ammu*amuq*amel2^2*ammu2^2*x3^2*x5*xcp1+1344*ammu*
amuq*amel2^2*ammu2^2*x1*x6*xcp4+192*ammu*amuq*amel2^2*ammu2^2*x1*x6*xcp3+192*ammu*amuq*amel2^2*ammu2^2*x1*x6*xcp2+1344*ammu*amuq*amel2^2*ammu2^2*x1*x6*xcp1-768*ammu*amuq*amel2^2*ammu2^2*x1*x6^2*xcp4+192*ammu*amuq*amel2^2*ammu2^2*x1*x6^2*xcp3+192*
ammu*amuq*amel2^2*ammu2^2*x1*x6^2*xcp2-768*ammu*amuq*amel2^2*ammu2^2*x1*x6^2*xcp1+1152*ammu*amuq*amel2^2*ammu2^2*x1*x5*xcp4+1152*ammu*amuq*amel2^2*ammu2^2*x1*x5*xcp1-1920*ammu*amuq*amel2^2*ammu2^2*x1*x5*x6*xcp4+384*ammu*amuq*amel2^2*ammu2^2*x1*x5*
x6*xcp3+384*ammu*amuq*amel2^2*ammu2^2*x1*x5*x6*xcp2-1920*ammu*amuq*amel2^2*ammu2^2*x1*x5*x6*xcp1-1152*ammu*amuq*amel2^2*ammu2^2*x1*x5^2*xcp4+384*ammu*amuq*amel2^2*ammu2^2*x1*x5^2*xcp3+384*ammu*amuq*amel2^2*ammu2^2*x1*x5^2*xcp2-1152*ammu*amuq*
amel2^2*ammu2^2*x1*x5^2*xcp1-576*ammu*amuq*amel2^2*ammu2^2*x1*x4*xcp4+192*ammu*amuq*amel2^2*ammu2^2*x1*x4*xcp3+192*ammu*amuq*amel2^2*ammu2^2*x1*x4*xcp2-576*ammu*amuq*amel2^2*ammu2^2*x1*x4*xcp1-192*ammu*amuq*amel2^2*ammu2^2*x1*x4*x6*xcp4-192*ammu*
amuq*amel2^2*ammu2^2*x1*x4*x6*xcp3-192*ammu*amuq*amel2^2*ammu2^2*x1*x4*x6*xcp2-192*ammu*amuq*amel2^2*ammu2^2*x1*x4*x6*xcp1+192*ammu*amuq*amel2^2*ammu2^2*x1*x4^2*xcp4+192*ammu*amuq*amel2^2*ammu2^2*x1*x4^2*xcp1-384*ammu*amuq*amel2^2*ammu2^2*x1^2*x6*
xcp4+384*ammu*amuq*amel2^2*ammu2^2*x1^2*x6*xcp3+384*ammu*amuq*amel2^2*ammu2^2*x1^2*x6*xcp2-384*ammu*amuq*amel2^2*ammu2^2*x1^2*x6*xcp1-384*ammu*amuq*amel2^2*ammu2^2*x1^2*x5*xcp4+384*ammu*amuq*amel2^2*ammu2^2*x1^2*x5*xcp3+384*ammu*amuq*amel2^2*
ammu2^2*x1^2*x5*xcp2-384*ammu*amuq*amel2^2*ammu2^2*x1^2*x5*xcp1-192*ammu*amuq*amel2^3*amuq2*x4*xcp4-192*ammu*amuq*amel2^3*amuq2*x4*xcp3-192*ammu*amuq*amel2^3*amuq2*x4*xcp2-192*ammu*amuq*amel2^3*amuq2*x4*xcp1+192*ammu*amuq*amel2^3*amuq2*x4*x6*xcp4+
192*ammu*amuq*amel2^3*amuq2*x4*x6*xcp3+192*ammu*amuq*amel2^3*amuq2*x4*x6*xcp2+192*ammu*amuq*amel2^3*amuq2*x4*x6*xcp1+192*ammu*amuq*amel2^3*amuq2*x4*x5*xcp4+192*ammu*amuq*amel2^3*amuq2*x4*x5*xcp3+192*ammu*amuq*amel2^3*amuq2*x4*x5*xcp2+192*ammu*amuq*
amel2^3*amuq2*x4*x5*xcp1+576*ammu*amuq*amel2^3*amuq2*x4^2*xcp4+192*ammu*amuq*amel2^3*amuq2*x4^2*xcp3+192*ammu*amuq*amel2^3*amuq2*x4^2*xcp2+576*ammu*amuq*amel2^3*amuq2*x4^2*xcp1-192*ammu*amuq*amel2^3*amuq2*x4^2*x6*xcp4+192*ammu*amuq*amel2^3*amuq2*
x4^2*x6*xcp3+192*ammu*amuq*amel2^3*amuq2*x4^2*x6*xcp2-192*ammu*amuq*amel2^3*amuq2*x4^2*x6*xcp1-192*ammu*amuq*amel2^3*amuq2*x4^2*x5*xcp4+192*ammu*amuq*amel2^3*amuq2*x4^2*x5*xcp3+192*ammu*amuq*amel2^3*amuq2*x4^2*x5*xcp2-192*ammu*amuq*amel2^3*amuq2*
x4^2*x5*xcp1-192*ammu*amuq*amel2^3*amuq2*x4^3*xcp4-192*ammu*amuq*amel2^3*amuq2*x4^3*xcp3-192*ammu*amuq*amel2^3*amuq2*x4^3*xcp2-192*ammu*amuq*amel2^3*amuq2*x4^3*xcp1-192*ammu*amuq*amel2^3*amuq2*x3*x4*xcp4-192*ammu*amuq*amel2^3*amuq2*x3*x4*xcp3-192*
ammu*amuq*amel2^3*amuq2*x3*x4*xcp2-192*ammu*amuq*amel2^3*amuq2*x3*x4*xcp1+192*ammu*amuq*amel2^3*amuq2*x3*x4^2*xcp4-192*ammu*amuq*amel2^3*amuq2*x3*x4^2*xcp3-192*ammu*amuq*amel2^3*amuq2*x3*x4^2*xcp2+192*ammu*amuq*amel2^3*amuq2*x3*x4^2*xcp1+192*ammu*
amuq*amel2^3*amuq2*x1*x4*xcp4+192*ammu*amuq*amel2^3*amuq2*x1*x4*xcp3+192*ammu*amuq*amel2^3*amuq2*x1*x4*xcp2+192*ammu*amuq*amel2^3*amuq2*x1*x4*xcp1-192*ammu*amuq*amel2^3*amuq2*x1*x4^2*xcp4+192*ammu*amuq*amel2^3*amuq2*x1*x4^2*xcp3+192*ammu*amuq*
amel2^3*amuq2*x1*x4^2*xcp2-192*ammu*amuq*amel2^3*amuq2*x1*x4^2*xcp1-768*ammu*amuq*amel2^3*ammu2*xcp4-768*ammu*amuq*amel2^3*ammu2*xcp1-1920*ammu*amuq*amel2^3*ammu2*x6*xcp4-576*ammu*amuq*amel2^3*ammu2*x6*xcp3-576*ammu*amuq*amel2^3*ammu2*x6*xcp2-1920*
ammu*amuq*amel2^3*ammu2*x6*xcp1+2496*ammu*amuq*amel2^3*ammu2*x6^2*xcp4-576*ammu*amuq*amel2^3*ammu2*x6^2*xcp3-576*ammu*amuq*amel2^3*ammu2*x6^2*xcp2+2496*ammu*amuq*amel2^3*ammu2*x6^2*xcp1-384*ammu*amuq*amel2^3*ammu2*x6^3*xcp4+576*ammu*amuq*amel2^3*
ammu2*x6^3*xcp3+576*ammu*amuq*amel2^3*ammu2*x6^3*xcp2-384*ammu*amuq*amel2^3*ammu2*x6^3*xcp1-2304*ammu*amuq*amel2^3*ammu2*x5*xcp4-960*ammu*amuq*amel2^3*ammu2*x5*xcp3-960*ammu*amuq*amel2^3*ammu2*x5*xcp2-2304*ammu*amuq*amel2^3*ammu2*x5*xcp1+5184*ammu*
amuq*amel2^3*ammu2*x5*x6*xcp4-1728*ammu*amuq*amel2^3*ammu2*x5*x6*xcp3-1728*ammu*amuq*amel2^3*ammu2*x5*x6*xcp2+5184*ammu*amuq*amel2^3*ammu2*x5*x6*xcp1-1728*ammu*amuq*amel2^3*ammu2*x5*x6^2*xcp4+1920*ammu*amuq*amel2^3*ammu2*x5*x6^2*xcp3+1920*ammu*amuq
*amel2^3*ammu2*x5*x6^2*xcp2-1728*ammu*amuq*amel2^3*ammu2*x5*x6^2*xcp1+3456*ammu*amuq*amel2^3*ammu2*x5^2*xcp4-768*ammu*amuq*amel2^3*ammu2*x5^2*xcp3-768*ammu*amuq*amel2^3*ammu2*x5^2*xcp2+3456*ammu*amuq*amel2^3*ammu2*x5^2*xcp1-2496*ammu*amuq*amel2^3*
ammu2*x5^2*x6*xcp4+2304*ammu*amuq*amel2^3*ammu2*x5^2*x6*xcp3+2304*ammu*amuq*amel2^3*ammu2*x5^2*x6*xcp2-2496*ammu*amuq*amel2^3*ammu2*x5^2*x6*xcp1-1152*ammu*amuq*amel2^3*ammu2*x5^3*xcp4+960*ammu*amuq*amel2^3*ammu2*x5^3*xcp3+960*ammu*amuq*amel2^3*
ammu2*x5^3*xcp2-1152*ammu*amuq*amel2^3*ammu2*x5^3*xcp1+960*ammu*amuq*amel2^3*ammu2*x4*xcp4+192*ammu*amuq*amel2^3*ammu2*x4*xcp3+192*ammu*amuq*amel2^3*ammu2*x4*xcp2+960*ammu*amuq*amel2^3*ammu2*x4*xcp1+2304*ammu*amuq*amel2^3*ammu2*x4*x6*xcp4-384*ammu*
amuq*amel2^3*ammu2*x4*x6*xcp3-384*ammu*amuq*amel2^3*ammu2*x4*x6*xcp2+2304*ammu*amuq*amel2^3*ammu2*x4*x6*xcp1-960*ammu*amuq*amel2^3*ammu2*x4*x6^2*xcp4+192*ammu*amuq*amel2^3*ammu2*x4*x6^2*xcp3+192*ammu*amuq*amel2^3*ammu2*x4*x6^2*xcp2-960*ammu*amuq*
amel2^3*ammu2*x4*x6^2*xcp1+4608*ammu*amuq*amel2^3*ammu2*x4*x5*xcp4+384*ammu*amuq*amel2^3*ammu2*x4*x5*xcp3+384*ammu*amuq*amel2^3*ammu2*x4*x5*xcp2+4608*ammu*amuq*amel2^3*ammu2*x4*x5*xcp1-2880*ammu*amuq*amel2^3*ammu2*x4*x5*x6*xcp4+1728*ammu*amuq*
amel2^3*ammu2*x4*x5*x6*xcp3+1728*ammu*amuq*amel2^3*ammu2*x4*x5*x6*xcp2-2880*ammu*amuq*amel2^3*ammu2*x4*x5*x6*xcp1-2880*ammu*amuq*amel2^3*ammu2*x4*x5^2*xcp4+1344*ammu*amuq*amel2^3*ammu2*x4*x5^2*xcp3+1344*ammu*amuq*amel2^3*ammu2*x4*x5^2*xcp2-2880*
ammu*amuq*amel2^3*ammu2*x4*x5^2*xcp1+1344*ammu*amuq*amel2^3*ammu2*x4^2*xcp4-192*ammu*amuq*amel2^3*ammu2*x4^2*xcp3-192*ammu*amuq*amel2^3*ammu2*x4^2*xcp2+1344*ammu*amuq*amel2^3*ammu2*x4^2*xcp1-960*ammu*amuq*amel2^3*ammu2*x4^2*x6*xcp4+768*ammu*amuq*
amel2^3*ammu2*x4^2*x6*xcp3+768*ammu*amuq*amel2^3*ammu2*x4^2*x6*xcp2-960*ammu*amuq*amel2^3*ammu2*x4^2*x6*xcp1-2880*ammu*amuq*amel2^3*ammu2*x4^2*x5*xcp4+384*ammu*amuq*amel2^3*ammu2*x4^2*x5*xcp3+384*ammu*amuq*amel2^3*ammu2*x4^2*x5*xcp2-2880*ammu*amuq*
amel2^3*ammu2*x4^2*x5*xcp1-768*ammu*amuq*amel2^3*ammu2*x4^3*xcp4-768*ammu*amuq*amel2^3*ammu2*x4^3*xcp1+1152*ammu*amuq*amel2^3*ammu2*x3*x6*xcp4-384*ammu*amuq*amel2^3*ammu2*x3*x6*xcp3-384*ammu*amuq*amel2^3*ammu2*x3*x6*xcp2+1152*ammu*amuq*amel2^3*
ammu2*x3*x6*xcp1+384*ammu*amuq*amel2^3*ammu2*x3*x6^2*xcp3+384*ammu*amuq*amel2^3*ammu2*x3*x6^2*xcp2+768*ammu*amuq*amel2^3*ammu2*x3*x5*xcp4-384*ammu*amuq*amel2^3*ammu2*x3*x5*xcp3-384*ammu*amuq*amel2^3*ammu2*x3*x5*xcp2+768*ammu*amuq*amel2^3*ammu2*x3*
x5*xcp1-576*ammu*amuq*amel2^3*ammu2*x3*x5*x6*xcp4+576*ammu*amuq*amel2^3*ammu2*x3*x5*x6*xcp3+576*ammu*amuq*amel2^3*ammu2*x3*x5*x6*xcp2-576*ammu*amuq*amel2^3*ammu2*x3*x5*x6*xcp1-384*ammu*amuq*amel2^3*ammu2*x3*x5^2*xcp4-384*ammu*amuq*amel2^3*ammu2*x3*
x5^2*xcp1+2496*ammu*amuq*amel2^3*ammu2*x3*x4*xcp4-192*ammu*amuq*amel2^3*ammu2*x3*x4*xcp3-192*ammu*amuq*amel2^3*ammu2*x3*x4*xcp2+2496*ammu*amuq*amel2^3*ammu2*x3*x4*xcp1-1344*ammu*amuq*amel2^3*ammu2*x3*x4*x6*xcp4+1344*ammu*amuq*amel2^3*ammu2*x3*x4*x6
*xcp3+1344*ammu*amuq*amel2^3*ammu2*x3*x4*x6*xcp2-1344*ammu*amuq*amel2^3*ammu2*x3*x4*x6*xcp1-2112*ammu*amuq*amel2^3*ammu2*x3*x4*x5*xcp4+960*ammu*amuq*amel2^3*ammu2*x3*x4*x5*xcp3+960*ammu*amuq*amel2^3*ammu2*x3*x4*x5*xcp2-2112*ammu*amuq*amel2^3*ammu2*
x3*x4*x5*xcp1-1152*ammu*amuq*amel2^3*ammu2*x3*x4^2*xcp4-1152*ammu*amuq*amel2^3*ammu2*x3*x4^2*xcp1+768*ammu*amuq*amel2^3*ammu2*x3^2*xcp4+768*ammu*amuq*amel2^3*ammu2*x3^2*xcp1-384*ammu*amuq*amel2^3*ammu2*x3^2*x6*xcp4+576*ammu*amuq*amel2^3*ammu2*x3^2*
x6*xcp3+576*ammu*amuq*amel2^3*ammu2*x3^2*x6*xcp2-384*ammu*amuq*amel2^3*ammu2*x3^2*x6*xcp1-768*ammu*amuq*amel2^3*ammu2*x3^2*x5*xcp4+576*ammu*amuq*amel2^3*ammu2*x3^2*x5*xcp3+576*ammu*amuq*amel2^3*ammu2*x3^2*x5*xcp2-768*ammu*amuq*amel2^3*ammu2*x3^2*x5
*xcp1-384*ammu*amuq*amel2^3*ammu2*x3^2*x4*xcp4-384*ammu*amuq*amel2^3*ammu2*x3^2*x4*xcp1+2688*ammu*amuq*amel2^3*ammu2*x1*x6*xcp4-1152*ammu*amuq*amel2^3*ammu2*x1*x6*xcp3-1152*ammu*amuq*amel2^3*ammu2*x1*x6*xcp2+2688*ammu*amuq*amel2^3*ammu2*x1*x6*xcp1-
768*ammu*amuq*amel2^3*ammu2*x1*x6^2*xcp4+1152*ammu*amuq*amel2^3*ammu2*x1*x6^2*xcp3+1152*ammu*amuq*amel2^3*ammu2*x1*x6^2*xcp2-768*ammu*amuq*amel2^3*ammu2*x1*x6^2*xcp1+3072*ammu*amuq*amel2^3*ammu2*x1*x5*xcp4-1152*ammu*amuq*amel2^3*ammu2*x1*x5*xcp3-
1152*ammu*amuq*amel2^3*ammu2*x1*x5*xcp2+3072*ammu*amuq*amel2^3*ammu2*x1*x5*xcp1-2496*ammu*amuq*amel2^3*ammu2*x1*x5*x6*xcp4+2496*ammu*amuq*amel2^3*ammu2*x1*x5*x6*xcp3+2496*ammu*amuq*amel2^3*ammu2*x1*x5*x6*xcp2-2496*ammu*amuq*amel2^3*ammu2*x1*x5*x6*
xcp1-1920*ammu*amuq*amel2^3*ammu2*x1*x5^2*xcp4+1536*ammu*amuq*amel2^3*ammu2*x1*x5^2*xcp3+1536*ammu*amuq*amel2^3*ammu2*x1*x5^2*xcp2-1920*ammu*amuq*amel2^3*ammu2*x1*x5^2*xcp1+576*ammu*amuq*amel2^3*ammu2*x1*x4*xcp4+192*ammu*amuq*amel2^3*ammu2*x1*x4*
xcp3+192*ammu*amuq*amel2^3*ammu2*x1*x4*xcp2+576*ammu*amuq*amel2^3*ammu2*x1*x4*xcp1-960*ammu*amuq*amel2^3*ammu2*x1*x4*x6*xcp4+192*ammu*amuq*amel2^3*ammu2*x1*x4*x6*xcp3+192*ammu*amuq*amel2^3*ammu2*x1*x4*x6*xcp2-960*ammu*amuq*amel2^3*ammu2*x1*x4*x6*
xcp1-1728*ammu*amuq*amel2^3*ammu2*x1*x4*x5*xcp4+576*ammu*amuq*amel2^3*ammu2*x1*x4*x5*xcp3+576*ammu*amuq*amel2^3*ammu2*x1*x4*x5*xcp2-1728*ammu*amuq*amel2^3*ammu2*x1*x4*x5*xcp1-384*ammu*amuq*amel2^3*ammu2*x1*x4^2*xcp4-384*ammu*amuq*amel2^3*ammu2*x1*
x4^2*xcp1+1536*ammu*amuq*amel2^3*ammu2*x1*x3*xcp4+1536*ammu*amuq*amel2^3*ammu2*x1*x3*xcp1+384*ammu*amuq*amel2^3*ammu2*x1*x3*x6*xcp3+384*ammu*amuq*amel2^3*ammu2*x1*x3*x6*xcp2-768*ammu*amuq*amel2^3*ammu2*x1*x3*x5*xcp4+384*ammu*amuq*amel2^3*ammu2*x1*
x3*x5*xcp3+384*ammu*amuq*amel2^3*ammu2*x1*x3*x5*xcp2-768*ammu*amuq*amel2^3*ammu2*x1*x3*x5*xcp1-768*ammu*amuq*amel2^3*ammu2*x1*x3*x4*xcp4-768*ammu*amuq*amel2^3*ammu2*x1*x3*x4*xcp1+768*ammu*amuq*amel2^3*ammu2*x1^2*xcp4+768*ammu*amuq*amel2^3*ammu2*
x1^2*xcp1-384*ammu*amuq*amel2^3*ammu2*x1^2*x6*xcp4+576*ammu*amuq*amel2^3*ammu2*x1^2*x6*xcp3+576*ammu*amuq*amel2^3*ammu2*x1^2*x6*xcp2-384*ammu*amuq*amel2^3*ammu2*x1^2*x6*xcp1-768*ammu*amuq*amel2^3*ammu2*x1^2*x5*xcp4+576*ammu*amuq*amel2^3*ammu2*x1^2*
x5*xcp3+576*ammu*amuq*amel2^3*ammu2*x1^2*x5*xcp2-768*ammu*amuq*amel2^3*ammu2*x1^2*x5*xcp1-384*ammu*amuq*amel2^3*ammu2*x1^2*x4*xcp4-384*ammu*amuq*amel2^3*ammu2*x1^2*x4*xcp1-576*ammu*amuq*amel2^4*xcp4-576*ammu*amuq*amel2^4*xcp3-576*ammu*amuq*amel2^4*
xcp2-576*ammu*amuq*amel2^4*xcp1+576*ammu*amuq*amel2^4*x6^2*xcp4+576*ammu*amuq*amel2^4*x6^2*xcp3+576*ammu*amuq*amel2^4*x6^2*xcp2+576*ammu*amuq*amel2^4*x6^2*xcp1-384*ammu*amuq*amel2^4*x5*xcp4-384*ammu*amuq*amel2^4*x5*xcp3-384*ammu*amuq*amel2^4*x5*
xcp2-384*ammu*amuq*amel2^4*x5*xcp1+1536*ammu*amuq*amel2^4*x5*x6*xcp4+1536*ammu*amuq*amel2^4*x5*x6*xcp3+1536*ammu*amuq*amel2^4*x5*x6*xcp2+1536*ammu*amuq*amel2^4*x5*x6*xcp1+960*ammu*amuq*amel2^4*x5^2*xcp4+960*ammu*amuq*amel2^4*x5^2*xcp3+960*ammu*amuq
*amel2^4*x5^2*xcp2+960*ammu*amuq*amel2^4*x5^2*xcp1+768*ammu*amuq*amel2^4*x4*xcp4+768*ammu*amuq*amel2^4*x4*xcp1+768*ammu*amuq*amel2^4*x4*x6*xcp4+1152*ammu*amuq*amel2^4*x4*x6*xcp3+1152*ammu*amuq*amel2^4*x4*x6*xcp2+768*ammu*amuq*amel2^4*x4*x6*xcp1-384
*ammu*amuq*amel2^4*x4*x6^2*xcp4-384*ammu*amuq*amel2^4*x4*x6^2*xcp1+1728*ammu*amuq*amel2^4*x4*x5*xcp4+1728*ammu*amuq*amel2^4*x4*x5*xcp3+1728*ammu*amuq*amel2^4*x4*x5*xcp2+1728*ammu*amuq*amel2^4*x4*x5*xcp1-960*ammu*amuq*amel2^4*x4*x5*x6*xcp4+192*ammu*
amuq*amel2^4*x4*x5*x6*xcp3+192*ammu*amuq*amel2^4*x4*x5*x6*xcp2-960*ammu*amuq*amel2^4*x4*x5*x6*xcp1-576*ammu*amuq*amel2^4*x4*x5^2*xcp4+192*ammu*amuq*amel2^4*x4*x5^2*xcp3+192*ammu*amuq*amel2^4*x4*x5^2*xcp2-576*ammu*amuq*amel2^4*x4*x5^2*xcp1+768*ammu*
amuq*amel2^4*x4^2*xcp4+576*ammu*amuq*amel2^4*x4^2*xcp3+576*ammu*amuq*amel2^4*x4^2*xcp2+768*ammu*amuq*amel2^4*x4^2*xcp1-576*ammu*amuq*amel2^4*x4^2*x6*xcp4-576*ammu*amuq*amel2^4*x4^2*x6*xcp1-1152*ammu*amuq*amel2^4*x4^2*x5*xcp4-192*ammu*amuq*amel2^4*
x4^2*x5*xcp3-192*ammu*amuq*amel2^4*x4^2*x5*xcp2-1152*ammu*amuq*amel2^4*x4^2*x5*xcp1-576*ammu*amuq*amel2^4*x4^3*xcp4-576*ammu*amuq*amel2^4*x4^3*xcp1+1152*ammu*amuq*amel2^4*x3*x6*xcp4+1152*ammu*amuq*amel2^4*x3*x6*xcp3+1152*ammu*amuq*amel2^4*x3*x6*
xcp2+1152*ammu*amuq*amel2^4*x3*x6*xcp1+768*ammu*amuq*amel2^4*x3*x5*xcp4+768*ammu*amuq*amel2^4*x3*x5*xcp3+768*ammu*amuq*amel2^4*x3*x5*xcp2+768*ammu*amuq*amel2^4*x3*x5*xcp1+1536*ammu*amuq*amel2^4*x3*x4*xcp4+1152*ammu*amuq*amel2^4*x3*x4*xcp3+1152*ammu
*amuq*amel2^4*x3*x4*xcp2+1536*ammu*amuq*amel2^4*x3*x4*xcp1-768*ammu*amuq*amel2^4*x3*x4*x6*xcp4-768*ammu*amuq*amel2^4*x3*x4*x6*xcp1-576*ammu*amuq*amel2^4*x3*x4*x5*xcp4-192*ammu*amuq*amel2^4*x3*x4*x5*xcp3-192*ammu*amuq*amel2^4*x3*x4*x5*xcp2-576*ammu*
amuq*amel2^4*x3*x4*x5*xcp1-960*ammu*amuq*amel2^4*x3*x4^2*xcp4-960*ammu*amuq*amel2^4*x3*x4^2*xcp1+576*ammu*amuq*amel2^4*x3^2*xcp4+576*ammu*amuq*amel2^4*x3^2*xcp3+576*ammu*amuq*amel2^4*x3^2*xcp2+576*ammu*amuq*amel2^4*x3^2*xcp1-384*ammu*amuq*amel2^4*
x3^2*x4*xcp4-384*ammu*amuq*amel2^4*x3^2*x4*xcp1+1152*ammu*amuq*amel2^4*x1*x6*xcp4+1152*ammu*amuq*amel2^4*x1*x6*xcp3+1152*ammu*amuq*amel2^4*x1*x6*xcp2+1152*ammu*amuq*amel2^4*x1*x6*xcp1+1536*ammu*amuq*amel2^4*x1*x5*xcp4+1536*ammu*amuq*amel2^4*x1*x5*
xcp3+1536*ammu*amuq*amel2^4*x1*x5*xcp2+1536*ammu*amuq*amel2^4*x1*x5*xcp1+768*ammu*amuq*amel2^4*x1*x4*xcp4+1152*ammu*amuq*amel2^4*x1*x4*xcp3+1152*ammu*amuq*amel2^4*x1*x4*xcp2+768*ammu*amuq*amel2^4*x1*x4*xcp1-768*ammu*amuq*amel2^4*x1*x4*x6*xcp4-768*
ammu*amuq*amel2^4*x1*x4*x6*xcp1-960*ammu*amuq*amel2^4*x1*x4*x5*xcp4+192*ammu*amuq*amel2^4*x1*x4*x5*xcp3+192*ammu*amuq*amel2^4*x1*x4*x5*xcp2-960*ammu*amuq*amel2^4*x1*x4*x5*xcp1-576*ammu*amuq*amel2^4*x1*x4^2*xcp4-576*ammu*amuq*amel2^4*x1*x4^2*xcp1+
1152*ammu*amuq*amel2^4*x1*x3*xcp4+1152*ammu*amuq*amel2^4*x1*x3*xcp3+1152*ammu*amuq*amel2^4*x1*x3*xcp2+1152*ammu*amuq*amel2^4*x1*x3*xcp1-768*ammu*amuq*amel2^4*x1*x3*x4*xcp4-768*ammu*amuq*amel2^4*x1*x3*x4*xcp1+576*ammu*amuq*amel2^4*x1^2*xcp4+576*ammu
*amuq*amel2^4*x1^2*xcp3+576*ammu*amuq*amel2^4*x1^2*xcp2+576*ammu*amuq*amel2^4*x1^2*xcp1-384*ammu*amuq*amel2^4*x1^2*x4*xcp4-384*ammu*amuq*amel2^4*x1^2*x4*xcp1-144*e2e1*ammu*amuq*amuq2*x6*xcp4*e1234-144*e2e1*ammu*amuq*amuq2*x6*xcp3*e1234+144*e2e1*
ammu*amuq*amuq2*x6*xcp2*e1234+144*e2e1*ammu*amuq*amuq2*x6*xcp1*e1234+144*e2e1*ammu*amuq*amuq2*x6^2*xcp4*e1234+144*e2e1*ammu*amuq*amuq2*x6^2*xcp3*e1234-144*e2e1*ammu*amuq*amuq2*x6^2*xcp2*e1234-144*e2e1*ammu*amuq*amuq2*x6^2*xcp1*e1234-336*e2e1*ammu*
amuq*amuq2*x5*xcp4*e1234-336*e2e1*ammu*amuq*amuq2*x5*xcp3*e1234+336*e2e1*ammu*amuq*amuq2*x5*xcp2*e1234+336*e2e1*ammu*amuq*amuq2*x5*xcp1*e1234+480*e2e1*ammu*amuq*amuq2*x5*x6*xcp4*e1234+480*e2e1*ammu*amuq*amuq2*x5*x6*xcp3*e1234-480*e2e1*ammu*amuq*
amuq2*x5*x6*xcp2*e1234-480*e2e1*ammu*amuq*amuq2*x5*x6*xcp1*e1234+336*e2e1*ammu*amuq*amuq2*x5^2*xcp4*e1234+336*e2e1*ammu*amuq*amuq2*x5^2*xcp3*e1234-336*e2e1*ammu*amuq*amuq2*x5^2*xcp2*e1234-336*e2e1*ammu*amuq*amuq2*x5^2*xcp1*e1234-288*e2e1*ammu*amuq*
amuq2*x4*xcp4*e2345-288*e2e1*ammu*amuq*amuq2*x4*xcp4*e1345-192*e2e1*ammu*amuq*amuq2*x4*xcp4*e1245+192*e2e1*ammu*amuq*amuq2*x4*xcp4*e1235+48*e2e1*ammu*amuq*amuq2*x4*xcp4*e1234-288*e2e1*ammu*amuq*amuq2*x4*xcp3*e2345-240*e2e1*ammu*amuq*amuq2*x4*xcp3*
e1345-192*e2e1*ammu*amuq*amuq2*x4*xcp3*e1245+192*e2e1*ammu*amuq*amuq2*x4*xcp3*e1235+96*e2e1*ammu*amuq*amuq2*x4*xcp3*e1234+288*e2e1*ammu*amuq*amuq2*x4*xcp2*e2345+240*e2e1*ammu*amuq*amuq2*x4*xcp2*e1345+192*e2e1*ammu*amuq*amuq2*x4*xcp2*e1245-192*e2e1*
ammu*amuq*amuq2*x4*xcp2*e1235-96*e2e1*ammu*amuq*amuq2*x4*xcp2*e1234+288*e2e1*ammu*amuq*amuq2*x4*xcp1*e2345+288*e2e1*ammu*amuq*amuq2*x4*xcp1*e1345+192*e2e1*ammu*amuq*amuq2*x4*xcp1*e1245-192*e2e1*ammu*amuq*amuq2*x4*xcp1*e1235-48*e2e1*ammu*amuq*amuq2*
x4*xcp1*e1234+192*e2e1*ammu*amuq*amuq2*x4*x6*xcp4*e1245-192*e2e1*ammu*amuq*amuq2*x4*x6*xcp4*e1235+144*e2e1*ammu*amuq*amuq2*x4*x6*xcp4*e1234+192*e2e1*ammu*amuq*amuq2*x4*x6*xcp3*e1245-192*e2e1*ammu*amuq*amuq2*x4*x6*xcp3*e1235+96*e2e1*ammu*amuq*amuq2*
x4*x6*xcp3*e1234-192*e2e1*ammu*amuq*amuq2*x4*x6*xcp2*e1245+192*e2e1*ammu*amuq*amuq2*x4*x6*xcp2*e1235-96*e2e1*ammu*amuq*amuq2*x4*x6*xcp2*e1234-192*e2e1*ammu*amuq*amuq2*x4*x6*xcp1*e1245+192*e2e1*ammu*amuq*amuq2*x4*x6*xcp1*e1235-144*e2e1*ammu*amuq*
amuq2*x4*x6*xcp1*e1234-48*e2e1*ammu*amuq*amuq2*x4*x6^2*xcp3*e1234+48*e2e1*ammu*amuq*amuq2*x4*x6^2*xcp2*e1234+192*e2e1*ammu*amuq*amuq2*x4*x5*xcp4*e1245-192*e2e1*ammu*amuq*amuq2*x4*x5*xcp4*e1235+480*e2e1*ammu*amuq*amuq2*x4*x5*xcp4*e1234+192*e2e1*ammu
*amuq*amuq2*x4*x5*xcp3*e1245-192*e2e1*ammu*amuq*amuq2*x4*x5*xcp3*e1235+240*e2e1*ammu*amuq*amuq2*x4*x5*xcp3*e1234-192*e2e1*ammu*amuq*amuq2*x4*x5*xcp2*e1245+192*e2e1*ammu*amuq*amuq2*x4*x5*xcp2*e1235-240*e2e1*ammu*amuq*amuq2*x4*x5*xcp2*e1234-192*e2e1*
ammu*amuq*amuq2*x4*x5*xcp1*e1245+192*e2e1*ammu*amuq*amuq2*x4*x5*xcp1*e1235-480*e2e1*ammu*amuq*amuq2*x4*x5*xcp1*e1234-144*e2e1*ammu*amuq*amuq2*x4*x5*x6*xcp4*e1234-48*e2e1*ammu*amuq*amuq2*x4*x5*x6*xcp3*e1234+48*e2e1*ammu*amuq*amuq2*x4*x5*x6*xcp2*
e1234+144*e2e1*ammu*amuq*amuq2*x4*x5*x6*xcp1*e1234-144*e2e1*ammu*amuq*amuq2*x4*x5^2*xcp4*e1234+144*e2e1*ammu*amuq*amuq2*x4*x5^2*xcp1*e1234+192*e2e1*ammu*amuq*amuq2*x4^2*xcp4*e2345+336*e2e1*ammu*amuq*amuq2*x4^2*xcp4*e1345+192*e2e1*ammu*amuq*amuq2*
x4^2*xcp4*e1245-384*e2e1*ammu*amuq*amuq2*x4^2*xcp4*e1235-192*e2e1*ammu*amuq*amuq2*x4^2*xcp4*e1234-96*e2e1*ammu*amuq*amuq2*x4^2*xcp3*e1345+192*e2e1*ammu*amuq*amuq2*x4^2*xcp3*e1245+48*e2e1*ammu*amuq*amuq2*x4^2*xcp3*e1234+96*e2e1*ammu*amuq*amuq2*x4^2*
xcp2*e1345-192*e2e1*ammu*amuq*amuq2*x4^2*xcp2*e1245-48*e2e1*ammu*amuq*amuq2*x4^2*xcp2*e1234-192*e2e1*ammu*amuq*amuq2*x4^2*xcp1*e2345-336*e2e1*ammu*amuq*amuq2*x4^2*xcp1*e1345-192*e2e1*ammu*amuq*amuq2*x4^2*xcp1*e1245+384*e2e1*ammu*amuq*amuq2*x4^2*
xcp1*e1235+192*e2e1*ammu*amuq*amuq2*x4^2*xcp1*e1234+96*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp4*e2345+96*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp4*e1345+192*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp4*e1235+96*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp3*e2345+48*e2e1*ammu*amuq*amuq2
*x4^2*x6*xcp3*e1345-192*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp3*e1235-96*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp3*e1234-96*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp2*e2345-48*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp2*e1345+192*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp2*e1235+96*e2e1*
ammu*amuq*amuq2*x4^2*x6*xcp2*e1234-96*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp1*e2345-96*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp1*e1345-192*e2e1*ammu*amuq*amuq2*x4^2*x6*xcp1*e1235+48*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp4*e2345+192*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp4*
e1235-96*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp4*e1234+240*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp3*e2345+336*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp3*e1345-192*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp3*e1235-192*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp3*e1234-240*e2e1*ammu*amuq*
amuq2*x4^2*x5*xcp2*e2345-336*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp2*e1345+192*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp2*e1235+192*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp2*e1234-48*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp1*e2345-192*e2e1*ammu*amuq*amuq2*x4^2*x5*xcp1*e1235+96*
e2e1*ammu*amuq*amuq2*x4^2*x5*xcp1*e1234-96*e2e1*ammu*amuq*amuq2*x4^3*xcp4*e1345+192*e2e1*ammu*amuq*amuq2*x4^3*xcp4*e1235+96*e2e1*ammu*amuq*amuq2*x4^3*xcp4*e1234+96*e2e1*ammu*amuq*amuq2*x4^3*xcp3*e2345+96*e2e1*ammu*amuq*amuq2*x4^3*xcp3*e1345-192*
e2e1*ammu*amuq*amuq2*x4^3*xcp3*e1235-96*e2e1*ammu*amuq*amuq2*x4^3*xcp3*e1234-96*e2e1*ammu*amuq*amuq2*x4^3*xcp2*e2345-96*e2e1*ammu*amuq*amuq2*x4^3*xcp2*e1345+192*e2e1*ammu*amuq*amuq2*x4^3*xcp2*e1235+96*e2e1*ammu*amuq*amuq2*x4^3*xcp2*e1234+96*e2e1*
ammu*amuq*amuq2*x4^3*xcp1*e1345-192*e2e1*ammu*amuq*amuq2*x4^3*xcp1*e1235-96*e2e1*ammu*amuq*amuq2*x4^3*xcp1*e1234+144*e2e1*ammu*amuq*amuq2*x3*x6*xcp4*e1234+96*e2e1*ammu*amuq*amuq2*x3*x6*xcp3*e1234-96*e2e1*ammu*amuq*amuq2*x3*x6*xcp2*e1234-144*e2e1*
ammu*amuq*amuq2*x3*x6*xcp1*e1234+336*e2e1*ammu*amuq*amuq2*x3*x5*xcp4*e1234+288*e2e1*ammu*amuq*amuq2*x3*x5*xcp3*e1234-288*e2e1*ammu*amuq*amuq2*x3*x5*xcp2*e1234-336*e2e1*ammu*amuq*amuq2*x3*x5*xcp1*e1234+192*e2e1*ammu*amuq*amuq2*x3*x4*xcp4*e1245-192*
e2e1*ammu*amuq*amuq2*x3*x4*xcp4*e1235-144*e2e1*ammu*amuq*amuq2*x3*x4*xcp4*e1234+192*e2e1*ammu*amuq*amuq2*x3*x4*xcp3*e1245-192*e2e1*ammu*amuq*amuq2*x3*x4*xcp3*e1235-192*e2e1*ammu*amuq*amuq2*x3*x4*xcp2*e1245+192*e2e1*ammu*amuq*amuq2*x3*x4*xcp2*e1235-
192*e2e1*ammu*amuq*amuq2*x3*x4*xcp1*e1245+192*e2e1*ammu*amuq*amuq2*x3*x4*xcp1*e1235+144*e2e1*ammu*amuq*amuq2*x3*x4*xcp1*e1234-48*e2e1*ammu*amuq*amuq2*x3*x4*x6*xcp4*e1234-48*e2e1*ammu*amuq*amuq2*x3*x4*x6*xcp3*e1234+48*e2e1*ammu*amuq*amuq2*x3*x4*x6*
xcp2*e1234+48*e2e1*ammu*amuq*amuq2*x3*x4*x6*xcp1*e1234-144*e2e1*ammu*amuq*amuq2*x3*x4*x5*xcp4*e1234-144*e2e1*ammu*amuq*amuq2*x3*x4*x5*xcp3*e1234+144*e2e1*ammu*amuq*amuq2*x3*x4*x5*xcp2*e1234+144*e2e1*ammu*amuq*amuq2*x3*x4*x5*xcp1*e1234+48*e2e1*ammu*
amuq*amuq2*x3*x4^2*xcp4*e2345+192*e2e1*ammu*amuq*amuq2*x3*x4^2*xcp4*e1235+96*e2e1*ammu*amuq*amuq2*x3*x4^2*xcp4*e1234+48*e2e1*ammu*amuq*amuq2*x3*x4^2*xcp3*e2345-192*e2e1*ammu*amuq*amuq2*x3*x4^2*xcp3*e1235-96*e2e1*ammu*amuq*amuq2*x3*x4^2*xcp3*e1234-
48*e2e1*ammu*amuq*amuq2*x3*x4^2*xcp2*e2345+192*e2e1*ammu*amuq*amuq2*x3*x4^2*xcp2*e1235+96*e2e1*ammu*amuq*amuq2*x3*x4^2*xcp2*e1234-48*e2e1*ammu*amuq*amuq2*x3*x4^2*xcp1*e2345-192*e2e1*ammu*amuq*amuq2*x3*x4^2*xcp1*e1235-96*e2e1*ammu*amuq*amuq2*x3*x4^2
*xcp1*e1234+144*e2e1*ammu*amuq*amuq2*x1*x6*xcp4*e1234+144*e2e1*ammu*amuq*amuq2*x1*x6*xcp3*e1234-144*e2e1*ammu*amuq*amuq2*x1*x6*xcp2*e1234-144*e2e1*ammu*amuq*amuq2*x1*x6*xcp1*e1234+336*e2e1*ammu*amuq*amuq2*x1*x5*xcp4*e1234+336*e2e1*ammu*amuq*amuq2*
x1*x5*xcp3*e1234-336*e2e1*ammu*amuq*amuq2*x1*x5*xcp2*e1234-336*e2e1*ammu*amuq*amuq2*x1*x5*xcp1*e1234+192*e2e1*ammu*amuq*amuq2*x1*x4*xcp4*e1245-192*e2e1*ammu*amuq*amuq2*x1*x4*xcp4*e1235+192*e2e1*ammu*amuq*amuq2*x1*x4*xcp3*e1245-192*e2e1*ammu*amuq*
amuq2*x1*x4*xcp3*e1235-96*e2e1*ammu*amuq*amuq2*x1*x4*xcp3*e1234-192*e2e1*ammu*amuq*amuq2*x1*x4*xcp2*e1245+192*e2e1*ammu*amuq*amuq2*x1*x4*xcp2*e1235+96*e2e1*ammu*amuq*amuq2*x1*x4*xcp2*e1234-192*e2e1*ammu*amuq*amuq2*x1*x4*xcp1*e1245+192*e2e1*ammu*
amuq*amuq2*x1*x4*xcp1*e1235-48*e2e1*ammu*amuq*amuq2*x1*x4*x6*xcp3*e1234+48*e2e1*ammu*amuq*amuq2*x1*x4*x6*xcp2*e1234-144*e2e1*ammu*amuq*amuq2*x1*x4*x5*xcp4*e1234+144*e2e1*ammu*amuq*amuq2*x1*x4*x5*xcp1*e1234+192*e2e1*ammu*amuq*amuq2*x1*x4^2*xcp4*
e1235-48*e2e1*ammu*amuq*amuq2*x1*x4^2*xcp3*e1345-192*e2e1*ammu*amuq*amuq2*x1*x4^2*xcp3*e1235-48*e2e1*ammu*amuq*amuq2*x1*x4^2*xcp3*e1234+48*e2e1*ammu*amuq*amuq2*x1*x4^2*xcp2*e1345+192*e2e1*ammu*amuq*amuq2*x1*x4^2*xcp2*e1235+48*e2e1*ammu*amuq*amuq2*
x1*x4^2*xcp2*e1234-192*e2e1*ammu*amuq*amuq2*x1*x4^2*xcp1*e1235-48*e2e1*ammu*amuq*amuq2*x1*x3*xcp3*e1234+48*e2e1*ammu*amuq*amuq2*x1*x3*xcp2*e1234-48*e2e1*ammu*amuq*amuq2*x1*x3*x4*xcp4*e1234+48*e2e1*ammu*amuq*amuq2*x1*x3*x4*xcp1*e1234+672*e2e1*ammu*
amuq*ammu2*x6*xcp4*e2345-96*e2e1*ammu*amuq*ammu2*x6*xcp4*e1345+288*e2e1*ammu*amuq*ammu2*x6*xcp4*e1245-576*e2e1*ammu*amuq*ammu2*x6*xcp4*e1235-384*e2e1*ammu*amuq*ammu2*x6*xcp4*e1234+48*e2e1*ammu*amuq*ammu2*x6*xcp3*e2345+96*e2e1*ammu*amuq*ammu2*x6*
xcp3*e1245+192*e2e1*ammu*amuq*ammu2*x6*xcp3*e1235-48*e2e1*ammu*amuq*ammu2*x6*xcp2*e2345-96*e2e1*ammu*amuq*ammu2*x6*xcp2*e1245-192*e2e1*ammu*amuq*ammu2*x6*xcp2*e1235-672*e2e1*ammu*amuq*ammu2*x6*xcp1*e2345+96*e2e1*ammu*amuq*ammu2*x6*xcp1*e1345-288*
e2e1*ammu*amuq*ammu2*x6*xcp1*e1245+576*e2e1*ammu*amuq*ammu2*x6*xcp1*e1235+384*e2e1*ammu*amuq*ammu2*x6*xcp1*e1234-432*e2e1*ammu*amuq*ammu2*x6^2*xcp4*e2345+48*e2e1*ammu*amuq*ammu2*x6^2*xcp4*e1345-288*e2e1*ammu*amuq*ammu2*x6^2*xcp4*e1245+528*e2e1*ammu
*amuq*ammu2*x6^2*xcp4*e1235+384*e2e1*ammu*amuq*ammu2*x6^2*xcp4*e1234-240*e2e1*ammu*amuq*ammu2*x6^2*xcp3*e2345-48*e2e1*ammu*amuq*ammu2*x6^2*xcp3*e1345-144*e2e1*ammu*amuq*ammu2*x6^2*xcp3*e1245-192*e2e1*ammu*amuq*ammu2*x6^2*xcp3*e1235+240*e2e1*ammu*
amuq*ammu2*x6^2*xcp2*e2345+48*e2e1*ammu*amuq*ammu2*x6^2*xcp2*e1345+144*e2e1*ammu*amuq*ammu2*x6^2*xcp2*e1245+192*e2e1*ammu*amuq*ammu2*x6^2*xcp2*e1235+432*e2e1*ammu*amuq*ammu2*x6^2*xcp1*e2345-48*e2e1*ammu*amuq*ammu2*x6^2*xcp1*e1345+288*e2e1*ammu*amuq
*ammu2*x6^2*xcp1*e1245-528*e2e1*ammu*amuq*ammu2*x6^2*xcp1*e1235-384*e2e1*ammu*amuq*ammu2*x6^2*xcp1*e1234+96*e2e1*ammu*amuq*ammu2*x6^3*xcp4*e2345+48*e2e1*ammu*amuq*ammu2*x6^3*xcp4*e1345+96*e2e1*ammu*amuq*ammu2*x6^3*xcp3*e2345+48*e2e1*ammu*amuq*ammu2
*x6^3*xcp3*e1345+48*e2e1*ammu*amuq*ammu2*x6^3*xcp3*e1245-96*e2e1*ammu*amuq*ammu2*x6^3*xcp2*e2345-48*e2e1*ammu*amuq*ammu2*x6^3*xcp2*e1345-48*e2e1*ammu*amuq*ammu2*x6^3*xcp2*e1245-96*e2e1*ammu*amuq*ammu2*x6^3*xcp1*e2345-48*e2e1*ammu*amuq*ammu2*x6^3*
xcp1*e1345+96*e2e1*ammu*amuq*ammu2*x5*xcp4*e2345-672*e2e1*ammu*amuq*ammu2*x5*xcp4*e1345-336*e2e1*ammu*amuq*ammu2*x5*xcp4*e1245-624*e2e1*ammu*amuq*ammu2*x5*xcp4*e1235-48*e2e1*ammu*amuq*ammu2*x5*xcp4*e1234+384*e2e1*ammu*amuq*ammu2*x5*xcp3*e2345+192*
e2e1*ammu*amuq*ammu2*x5*xcp3*e1345+432*e2e1*ammu*amuq*ammu2*x5*xcp3*e1245+96*e2e1*ammu*amuq*ammu2*x5*xcp3*e1235-288*e2e1*ammu*amuq*ammu2*x5*xcp3*e1234-384*e2e1*ammu*amuq*ammu2*x5*xcp2*e2345-192*e2e1*ammu*amuq*ammu2*x5*xcp2*e1345-432*e2e1*ammu*amuq*
ammu2*x5*xcp2*e1245-96*e2e1*ammu*amuq*ammu2*x5*xcp2*e1235+288*e2e1*ammu*amuq*ammu2*x5*xcp2*e1234-96*e2e1*ammu*amuq*ammu2*x5*xcp1*e2345+672*e2e1*ammu*amuq*ammu2*x5*xcp1*e1345+336*e2e1*ammu*amuq*ammu2*x5*xcp1*e1245+624*e2e1*ammu*amuq*ammu2*x5*xcp1*
e1235+48*e2e1*ammu*amuq*ammu2*x5*xcp1*e1234-816*e2e1*ammu*amuq*ammu2*x5*x6*xcp4*e2345+192*e2e1*ammu*amuq*ammu2*x5*x6*xcp4*e1345+96*e2e1*ammu*amuq*ammu2*x5*x6*xcp4*e1245+1248*e2e1*ammu*amuq*ammu2*x5*x6*xcp4*e1235+816*e2e1*ammu*amuq*ammu2*x5*x6*xcp4*
e1234-816*e2e1*ammu*amuq*ammu2*x5*x6*xcp3*e2345-480*e2e1*ammu*amuq*ammu2*x5*x6*xcp3*e1345-768*e2e1*ammu*amuq*ammu2*x5*x6*xcp3*e1245-432*e2e1*ammu*amuq*ammu2*x5*x6*xcp3*e1235+432*e2e1*ammu*amuq*ammu2*x5*x6*xcp3*e1234+816*e2e1*ammu*amuq*ammu2*x5*x6*
xcp2*e2345+480*e2e1*ammu*amuq*ammu2*x5*x6*xcp2*e1345+768*e2e1*ammu*amuq*ammu2*x5*x6*xcp2*e1245+432*e2e1*ammu*amuq*ammu2*x5*x6*xcp2*e1235-432*e2e1*ammu*amuq*ammu2*x5*x6*xcp2*e1234+816*e2e1*ammu*amuq*ammu2*x5*x6*xcp1*e2345-192*e2e1*ammu*amuq*ammu2*x5
*x6*xcp1*e1345-96*e2e1*ammu*amuq*ammu2*x5*x6*xcp1*e1245-1248*e2e1*ammu*amuq*ammu2*x5*x6*xcp1*e1235-816*e2e1*ammu*amuq*ammu2*x5*x6*xcp1*e1234+240*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp4*e2345+96*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp4*e1345-48*e2e1*ammu*amuq*
ammu2*x5*x6^2*xcp4*e1245-192*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp4*e1235-144*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp4*e1234+432*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp3*e2345+288*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp3*e1345+288*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp3*e1245+144
*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp3*e1235-192*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp3*e1234-432*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp2*e2345-288*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp2*e1345-288*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp2*e1245-144*e2e1*ammu*amuq*ammu2*x5*
x6^2*xcp2*e1235+192*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp2*e1234-240*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp1*e2345-96*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp1*e1345+48*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp1*e1245+192*e2e1*ammu*amuq*ammu2*x5*x6^2*xcp1*e1235+144*e2e1*ammu*
amuq*ammu2*x5*x6^2*xcp1*e1234+672*e2e1*ammu*amuq*ammu2*x5^2*xcp4*e1345+576*e2e1*ammu*amuq*ammu2*x5^2*xcp4*e1245+672*e2e1*ammu*amuq*ammu2*x5^2*xcp4*e1235+480*e2e1*ammu*amuq*ammu2*x5^2*xcp4*e1234-864*e2e1*ammu*amuq*ammu2*x5^2*xcp3*e2345-768*e2e1*ammu
*amuq*ammu2*x5^2*xcp3*e1345-816*e2e1*ammu*amuq*ammu2*x5^2*xcp3*e1245-96*e2e1*ammu*amuq*ammu2*x5^2*xcp3*e1235+576*e2e1*ammu*amuq*ammu2*x5^2*xcp3*e1234+864*e2e1*ammu*amuq*ammu2*x5^2*xcp2*e2345+768*e2e1*ammu*amuq*ammu2*x5^2*xcp2*e1345+816*e2e1*ammu*
amuq*ammu2*x5^2*xcp2*e1245+96*e2e1*ammu*amuq*ammu2*x5^2*xcp2*e1235-576*e2e1*ammu*amuq*ammu2*x5^2*xcp2*e1234-672*e2e1*ammu*amuq*ammu2*x5^2*xcp1*e1345-576*e2e1*ammu*amuq*ammu2*x5^2*xcp1*e1245-672*e2e1*ammu*amuq*ammu2*x5^2*xcp1*e1235-480*e2e1*ammu*
amuq*ammu2*x5^2*xcp1*e1234+288*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp4*e2345+144*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp4*e1345-288*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp4*e1245-336*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp4*e1235-288*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp4*e1234+
672*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp3*e2345+528*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp3*e1345+624*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp3*e1245+144*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp3*e1235-384*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp3*e1234-672*e2e1*ammu*amuq*ammu2*
x5^2*x6*xcp2*e2345-528*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp2*e1345-624*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp2*e1245-144*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp2*e1235+384*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp2*e1234-288*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp1*e2345-144*e2e1*
ammu*amuq*ammu2*x5^2*x6*xcp1*e1345+288*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp1*e1245+336*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp1*e1235+288*e2e1*ammu*amuq*ammu2*x5^2*x6*xcp1*e1234+96*e2e1*ammu*amuq*ammu2*x5^3*xcp4*e2345-240*e2e1*ammu*amuq*ammu2*x5^3*xcp4*e1245-
144*e2e1*ammu*amuq*ammu2*x5^3*xcp4*e1235-144*e2e1*ammu*amuq*ammu2*x5^3*xcp4*e1234+480*e2e1*ammu*amuq*ammu2*x5^3*xcp3*e2345+576*e2e1*ammu*amuq*ammu2*x5^3*xcp3*e1345+384*e2e1*ammu*amuq*ammu2*x5^3*xcp3*e1245-192*e2e1*ammu*amuq*ammu2*x5^3*xcp3*e1234-
480*e2e1*ammu*amuq*ammu2*x5^3*xcp2*e2345-576*e2e1*ammu*amuq*ammu2*x5^3*xcp2*e1345-384*e2e1*ammu*amuq*ammu2*x5^3*xcp2*e1245+192*e2e1*ammu*amuq*ammu2*x5^3*xcp2*e1234-96*e2e1*ammu*amuq*ammu2*x5^3*xcp1*e2345+240*e2e1*ammu*amuq*ammu2*x5^3*xcp1*e1245+144
*e2e1*ammu*amuq*ammu2*x5^3*xcp1*e1235+144*e2e1*ammu*amuq*ammu2*x5^3*xcp1*e1234-384*e2e1*ammu*amuq*ammu2*x4*xcp4*e2345-384*e2e1*ammu*amuq*ammu2*x4*xcp4*e1345-432*e2e1*ammu*amuq*ammu2*x4*xcp4*e1245-144*e2e1*ammu*amuq*ammu2*x4*xcp4*e1235+48*e2e1*ammu*
amuq*ammu2*x4*xcp3*e2345+48*e2e1*ammu*amuq*ammu2*x4*xcp3*e1245+192*e2e1*ammu*amuq*ammu2*x4*xcp3*e1235-48*e2e1*ammu*amuq*ammu2*x4*xcp2*e2345-48*e2e1*ammu*amuq*ammu2*x4*xcp2*e1245-192*e2e1*ammu*amuq*ammu2*x4*xcp2*e1235+384*e2e1*ammu*amuq*ammu2*x4*
xcp1*e2345+384*e2e1*ammu*amuq*ammu2*x4*xcp1*e1345+432*e2e1*ammu*amuq*ammu2*x4*xcp1*e1245+144*e2e1*ammu*amuq*ammu2*x4*xcp1*e1235-528*e2e1*ammu*amuq*ammu2*x4*x6*xcp4*e2345+96*e2e1*ammu*amuq*ammu2*x4*x6*xcp4*e1345+192*e2e1*ammu*amuq*ammu2*x4*x6*xcp4*
e1245+960*e2e1*ammu*amuq*ammu2*x4*x6*xcp4*e1235+576*e2e1*ammu*amuq*ammu2*x4*x6*xcp4*e1234-144*e2e1*ammu*amuq*ammu2*x4*x6*xcp3*e2345-144*e2e1*ammu*amuq*ammu2*x4*x6*xcp3*e1345-192*e2e1*ammu*amuq*ammu2*x4*x6*xcp3*e1245-864*e2e1*ammu*amuq*ammu2*x4*x6*
xcp3*e1235+144*e2e1*ammu*amuq*ammu2*x4*x6*xcp2*e2345+144*e2e1*ammu*amuq*ammu2*x4*x6*xcp2*e1345+192*e2e1*ammu*amuq*ammu2*x4*x6*xcp2*e1245+864*e2e1*ammu*amuq*ammu2*x4*x6*xcp2*e1235+528*e2e1*ammu*amuq*ammu2*x4*x6*xcp1*e2345-96*e2e1*ammu*amuq*ammu2*x4*
x6*xcp1*e1345-192*e2e1*ammu*amuq*ammu2*x4*x6*xcp1*e1245-960*e2e1*ammu*amuq*ammu2*x4*x6*xcp1*e1235-576*e2e1*ammu*amuq*ammu2*x4*x6*xcp1*e1234-48*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp4*e2345-48*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp4*e1345-96*e2e1*ammu*amuq*
ammu2*x4*x6^2*xcp4*e1245-144*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp4*e1235-192*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp4*e1234+96*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp3*e2345+48*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp3*e1345+96*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp3*e1245+336*
e2e1*ammu*amuq*ammu2*x4*x6^2*xcp3*e1235-96*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp2*e2345-48*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp2*e1345-96*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp2*e1245-336*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp2*e1235+48*e2e1*ammu*amuq*ammu2*x4*x6^2*
xcp1*e2345+48*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp1*e1345+96*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp1*e1245+144*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp1*e1235+192*e2e1*ammu*amuq*ammu2*x4*x6^2*xcp1*e1234+144*e2e1*ammu*amuq*ammu2*x4*x5*xcp4*e2345+1152*e2e1*ammu*amuq*
ammu2*x4*x5*xcp4*e1345+1392*e2e1*ammu*amuq*ammu2*x4*x5*xcp4*e1245+816*e2e1*ammu*amuq*ammu2*x4*x5*xcp4*e1235-432*e2e1*ammu*amuq*ammu2*x4*x5*xcp3*e2345-576*e2e1*ammu*amuq*ammu2*x4*x5*xcp3*e1345-864*e2e1*ammu*amuq*ammu2*x4*x5*xcp3*e1245-480*e2e1*ammu*
amuq*ammu2*x4*x5*xcp3*e1235+672*e2e1*ammu*amuq*ammu2*x4*x5*xcp3*e1234+432*e2e1*ammu*amuq*ammu2*x4*x5*xcp2*e2345+576*e2e1*ammu*amuq*ammu2*x4*x5*xcp2*e1345+864*e2e1*ammu*amuq*ammu2*x4*x5*xcp2*e1245+480*e2e1*ammu*amuq*ammu2*x4*x5*xcp2*e1235-672*e2e1*
ammu*amuq*ammu2*x4*x5*xcp2*e1234-144*e2e1*ammu*amuq*ammu2*x4*x5*xcp1*e2345-1152*e2e1*ammu*amuq*ammu2*x4*x5*xcp1*e1345-1392*e2e1*ammu*amuq*ammu2*x4*x5*xcp1*e1245-816*e2e1*ammu*amuq*ammu2*x4*x5*xcp1*e1235+144*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp4*e2345+
96*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp4*e1345-480*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp4*e1245-480*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp4*e1235-432*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp4*e1234+240*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp3*e2345+240*e2e1*ammu*amuq*ammu2
*x4*x5*x6*xcp3*e1345+432*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp3*e1245+672*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp3*e1235-528*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp3*e1234-240*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp2*e2345-240*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp2*e1345-
432*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp2*e1245-672*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp2*e1235+528*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp2*e1234-144*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp1*e2345-96*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp1*e1345+480*e2e1*ammu*amuq*ammu2
*x4*x5*x6*xcp1*e1245+480*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp1*e1235+432*e2e1*ammu*amuq*ammu2*x4*x5*x6*xcp1*e1234+96*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp4*e2345-144*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp4*e1345-672*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp4*e1245-240*
e2e1*ammu*amuq*ammu2*x4*x5^2*xcp4*e1235-144*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp4*e1234+576*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp3*e2345+864*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp3*e1345+816*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp3*e1245+48*e2e1*ammu*amuq*ammu2*x4*x5^2*
xcp3*e1235-720*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp3*e1234-576*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp2*e2345-864*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp2*e1345-816*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp2*e1245-48*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp2*e1235+720*e2e1*ammu*amuq
*ammu2*x4*x5^2*xcp2*e1234-96*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp1*e2345+144*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp1*e1345+672*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp1*e1245+240*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp1*e1235+144*e2e1*ammu*amuq*ammu2*x4*x5^2*xcp1*e1234+192
*e2e1*ammu*amuq*ammu2*x4^2*xcp4*e2345+192*e2e1*ammu*amuq*ammu2*x4^2*xcp4*e1345+624*e2e1*ammu*amuq*ammu2*x4^2*xcp4*e1245+192*e2e1*ammu*amuq*ammu2*x4^2*xcp4*e1235-48*e2e1*ammu*amuq*ammu2*x4^2*xcp3*e2345-48*e2e1*ammu*amuq*ammu2*x4^2*xcp3*e1245-288*
e2e1*ammu*amuq*ammu2*x4^2*xcp3*e1235+48*e2e1*ammu*amuq*ammu2*x4^2*xcp2*e2345+48*e2e1*ammu*amuq*ammu2*x4^2*xcp2*e1245+288*e2e1*ammu*amuq*ammu2*x4^2*xcp2*e1235-192*e2e1*ammu*amuq*ammu2*x4^2*xcp1*e2345-192*e2e1*ammu*amuq*ammu2*x4^2*xcp1*e1345-624*e2e1
*ammu*amuq*ammu2*x4^2*xcp1*e1245-192*e2e1*ammu*amuq*ammu2*x4^2*xcp1*e1235+48*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp4*e2345-192*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp4*e1245-432*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp4*e1235-192*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp4*e1234
-48*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp3*e2345+528*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp3*e1235+48*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp2*e2345-528*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp2*e1235-48*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp1*e2345+192*e2e1*ammu*amuq*ammu2*x4^2*
x6*xcp1*e1245+432*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp1*e1235+192*e2e1*ammu*amuq*ammu2*x4^2*x6*xcp1*e1234+48*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp4*e2345-192*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp4*e1345-672*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp4*e1245-240*e2e1*ammu*
amuq*ammu2*x4^2*x5*xcp4*e1235+96*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp4*e1234+192*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp3*e2345+192*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp3*e1345+288*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp3*e1245+48*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp3*e1235-
288*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp3*e1234-192*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp2*e2345-192*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp2*e1345-288*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp2*e1245-48*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp2*e1235+288*e2e1*ammu*amuq*ammu2*x4^2
*x5*xcp2*e1234-48*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp1*e2345+192*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp1*e1345+672*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp1*e1245+240*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp1*e1235-96*e2e1*ammu*amuq*ammu2*x4^2*x5*xcp1*e1234-192*e2e1*ammu*
amuq*ammu2*x4^3*xcp4*e1245-96*e2e1*ammu*amuq*ammu2*x4^3*xcp4*e1235+96*e2e1*ammu*amuq*ammu2*x4^3*xcp3*e1235-96*e2e1*ammu*amuq*ammu2*x4^3*xcp2*e1235+192*e2e1*ammu*amuq*ammu2*x4^3*xcp1*e1245+96*e2e1*ammu*amuq*ammu2*x4^3*xcp1*e1235-672*e2e1*ammu*amuq*
ammu2*x3*x6*xcp4*e2345-288*e2e1*ammu*amuq*ammu2*x3*x6*xcp4*e1245+528*e2e1*ammu*amuq*ammu2*x3*x6*xcp4*e1235+384*e2e1*ammu*amuq*ammu2*x3*x6*xcp4*e1234-96*e2e1*ammu*amuq*ammu2*x3*x6*xcp3*e1245-288*e2e1*ammu*amuq*ammu2*x3*x6*xcp3*e1235+96*e2e1*ammu*
amuq*ammu2*x3*x6*xcp2*e1245+288*e2e1*ammu*amuq*ammu2*x3*x6*xcp2*e1235+672*e2e1*ammu*amuq*ammu2*x3*x6*xcp1*e2345+288*e2e1*ammu*amuq*ammu2*x3*x6*xcp1*e1245-528*e2e1*ammu*amuq*ammu2*x3*x6*xcp1*e1235-384*e2e1*ammu*amuq*ammu2*x3*x6*xcp1*e1234-48*e2e1*
ammu*amuq*ammu2*x3*x6^2*xcp4*e1245+48*e2e1*ammu*amuq*ammu2*x3*x6^2*xcp3*e2345+48*e2e1*ammu*amuq*ammu2*x3*x6^2*xcp3*e1245-48*e2e1*ammu*amuq*ammu2*x3*x6^2*xcp2*e2345-48*e2e1*ammu*amuq*ammu2*x3*x6^2*xcp2*e1245+48*e2e1*ammu*amuq*ammu2*x3*x6^2*xcp1*
e1245-768*e2e1*ammu*amuq*ammu2*x3*x5*xcp4*e2345+240*e2e1*ammu*amuq*ammu2*x3*x5*xcp4*e1245+384*e2e1*ammu*amuq*ammu2*x3*x5*xcp4*e1235+48*e2e1*ammu*amuq*ammu2*x3*x5*xcp4*e1234-336*e2e1*ammu*amuq*ammu2*x3*x5*xcp3*e1245-96*e2e1*ammu*amuq*ammu2*x3*x5*
xcp3*e1235+384*e2e1*ammu*amuq*ammu2*x3*x5*xcp3*e1234+336*e2e1*ammu*amuq*ammu2*x3*x5*xcp2*e1245+96*e2e1*ammu*amuq*ammu2*x3*x5*xcp2*e1235-384*e2e1*ammu*amuq*ammu2*x3*x5*xcp2*e1234+768*e2e1*ammu*amuq*ammu2*x3*x5*xcp1*e2345-240*e2e1*ammu*amuq*ammu2*x3*
x5*xcp1*e1245-384*e2e1*ammu*amuq*ammu2*x3*x5*xcp1*e1235-48*e2e1*ammu*amuq*ammu2*x3*x5*xcp1*e1234+48*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp4*e2345-96*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp4*e1245-240*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp4*e1235-240*e2e1*ammu*amuq
*ammu2*x3*x5*x6*xcp4*e1234-48*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp3*e2345+96*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp3*e1245+48*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp3*e1235-336*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp3*e1234+48*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp2*e2345-
96*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp2*e1245-48*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp2*e1235+336*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp2*e1234-48*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp1*e2345+96*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp1*e1245+240*e2e1*ammu*amuq*ammu2*x3
*x5*x6*xcp1*e1235+240*e2e1*ammu*amuq*ammu2*x3*x5*x6*xcp1*e1234+96*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp4*e2345-240*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp4*e1245-144*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp4*e1235-144*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp4*e1234+240*e2e1*
ammu*amuq*ammu2*x3*x5^2*xcp3*e1245-240*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp3*e1235-624*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp3*e1234-240*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp2*e1245+240*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp2*e1235+624*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp2
*e1234-96*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp1*e2345+240*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp1*e1245+144*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp1*e1235+144*e2e1*ammu*amuq*ammu2*x3*x5^2*xcp1*e1234+432*e2e1*ammu*amuq*ammu2*x3*x4*xcp4*e1245+48*e2e1*ammu*amuq*ammu2*
x3*x4*xcp4*e1235-48*e2e1*ammu*amuq*ammu2*x3*x4*xcp3*e2345-48*e2e1*ammu*amuq*ammu2*x3*x4*xcp3*e1245-192*e2e1*ammu*amuq*ammu2*x3*x4*xcp3*e1235+48*e2e1*ammu*amuq*ammu2*x3*x4*xcp2*e2345+48*e2e1*ammu*amuq*ammu2*x3*x4*xcp2*e1245+192*e2e1*ammu*amuq*ammu2*
x3*x4*xcp2*e1235-432*e2e1*ammu*amuq*ammu2*x3*x4*xcp1*e1245-48*e2e1*ammu*amuq*ammu2*x3*x4*xcp1*e1235+48*e2e1*ammu*amuq*ammu2*x3*x4*x6*xcp4*e2345-240*e2e1*ammu*amuq*ammu2*x3*x4*x6*xcp4*e1235-192*e2e1*ammu*amuq*ammu2*x3*x4*x6*xcp4*e1234-48*e2e1*ammu*
amuq*ammu2*x3*x4*x6*xcp3*e2345+336*e2e1*ammu*amuq*ammu2*x3*x4*x6*xcp3*e1235+48*e2e1*ammu*amuq*ammu2*x3*x4*x6*xcp2*e2345-336*e2e1*ammu*amuq*ammu2*x3*x4*x6*xcp2*e1235-48*e2e1*ammu*amuq*ammu2*x3*x4*x6*xcp1*e2345+240*e2e1*ammu*amuq*ammu2*x3*x4*x6*xcp1*
e1235+192*e2e1*ammu*amuq*ammu2*x3*x4*x6*xcp1*e1234+144*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp4*e2345-384*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp4*e1245-48*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp4*e1235+96*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp4*e1234+96*e2e1*ammu*amuq*
ammu2*x3*x4*x5*xcp3*e2345+192*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp3*e1245-48*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp3*e1235-288*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp3*e1234-96*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp2*e2345-192*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp2*e1245
+48*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp2*e1235+288*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp2*e1234-144*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp1*e2345+384*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp1*e1245+48*e2e1*ammu*amuq*ammu2*x3*x4*x5*xcp1*e1235-96*e2e1*ammu*amuq*ammu2*
x3*x4*x5*xcp1*e1234-192*e2e1*ammu*amuq*ammu2*x3*x4^2*xcp4*e1245-96*e2e1*ammu*amuq*ammu2*x3*x4^2*xcp4*e1235+96*e2e1*ammu*amuq*ammu2*x3*x4^2*xcp3*e1235-96*e2e1*ammu*amuq*ammu2*x3*x4^2*xcp2*e1235+192*e2e1*ammu*amuq*ammu2*x3*x4^2*xcp1*e1245+96*e2e1*
ammu*amuq*ammu2*x3*x4^2*xcp1*e1235-192*e2e1*ammu*amuq*ammu2*x1*xcp4*e1345+96*e2e1*ammu*amuq*ammu2*x1*xcp3*e1345-48*e2e1*ammu*amuq*ammu2*x1*xcp3*e1245-96*e2e1*ammu*amuq*ammu2*x1*xcp2*e1345+48*e2e1*ammu*amuq*ammu2*x1*xcp2*e1245+192*e2e1*ammu*amuq*
ammu2*x1*xcp1*e1345+576*e2e1*ammu*amuq*ammu2*x1*x6*xcp4*e1345-288*e2e1*ammu*amuq*ammu2*x1*x6*xcp4*e1245+528*e2e1*ammu*amuq*ammu2*x1*x6*xcp4*e1235+384*e2e1*ammu*amuq*ammu2*x1*x6*xcp4*e1234+96*e2e1*ammu*amuq*ammu2*x1*x6*xcp3*e1345-96*e2e1*ammu*amuq*
ammu2*x1*x6*xcp3*e1245-240*e2e1*ammu*amuq*ammu2*x1*x6*xcp3*e1235-96*e2e1*ammu*amuq*ammu2*x1*x6*xcp2*e1345+96*e2e1*ammu*amuq*ammu2*x1*x6*xcp2*e1245+240*e2e1*ammu*amuq*ammu2*x1*x6*xcp2*e1235-576*e2e1*ammu*amuq*ammu2*x1*x6*xcp1*e1345+288*e2e1*ammu*
amuq*ammu2*x1*x6*xcp1*e1245-528*e2e1*ammu*amuq*ammu2*x1*x6*xcp1*e1235-384*e2e1*ammu*amuq*ammu2*x1*x6*xcp1*e1234-48*e2e1*ammu*amuq*ammu2*x1*x6^2*xcp4*e1345-48*e2e1*ammu*amuq*ammu2*x1*x6^2*xcp3*e1345+48*e2e1*ammu*amuq*ammu2*x1*x6^2*xcp3*e1245+48*e2e1
*ammu*amuq*ammu2*x1*x6^2*xcp2*e1345-48*e2e1*ammu*amuq*ammu2*x1*x6^2*xcp2*e1245+48*e2e1*ammu*amuq*ammu2*x1*x6^2*xcp1*e1345+480*e2e1*ammu*amuq*ammu2*x1*x5*xcp4*e1345+336*e2e1*ammu*amuq*ammu2*x1*x5*xcp4*e1245+528*e2e1*ammu*amuq*ammu2*x1*x5*xcp4*e1235+
192*e2e1*ammu*amuq*ammu2*x1*x5*xcp4*e1234+96*e2e1*ammu*amuq*ammu2*x1*x5*xcp3*e1345-432*e2e1*ammu*amuq*ammu2*x1*x5*xcp3*e1245-144*e2e1*ammu*amuq*ammu2*x1*x5*xcp3*e1235+288*e2e1*ammu*amuq*ammu2*x1*x5*xcp3*e1234-96*e2e1*ammu*amuq*ammu2*x1*x5*xcp2*
e1345+432*e2e1*ammu*amuq*ammu2*x1*x5*xcp2*e1245+144*e2e1*ammu*amuq*ammu2*x1*x5*xcp2*e1235-288*e2e1*ammu*amuq*ammu2*x1*x5*xcp2*e1234-480*e2e1*ammu*amuq*ammu2*x1*x5*xcp1*e1345-336*e2e1*ammu*amuq*ammu2*x1*x5*xcp1*e1245-528*e2e1*ammu*amuq*ammu2*x1*x5*
xcp1*e1235-192*e2e1*ammu*amuq*ammu2*x1*x5*xcp1*e1234-48*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp4*e1345-48*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp4*e1245-192*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp4*e1235-192*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp4*e1234-240*e2e1*ammu*
amuq*ammu2*x1*x5*x6*xcp3*e1345+240*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp3*e1245+144*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp3*e1235-240*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp3*e1234+240*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp2*e1345-240*e2e1*ammu*amuq*ammu2*x1*x5*x6*
xcp2*e1245-144*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp2*e1235+240*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp2*e1234+48*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp1*e1345+48*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp1*e1245+192*e2e1*ammu*amuq*ammu2*x1*x5*x6*xcp1*e1235+192*e2e1*ammu*
amuq*ammu2*x1*x5*x6*xcp1*e1234-240*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp4*e1245-144*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp4*e1235-144*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp4*e1234-192*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp3*e1345+384*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp3*
e1245-384*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp3*e1234+192*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp2*e1345-384*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp2*e1245+384*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp2*e1234+240*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp1*e1245+144*e2e1*ammu*amuq*
ammu2*x1*x5^2*xcp1*e1235+144*e2e1*ammu*amuq*ammu2*x1*x5^2*xcp1*e1234+432*e2e1*ammu*amuq*ammu2*x1*x4*xcp4*e1245+192*e2e1*ammu*amuq*ammu2*x1*x4*xcp4*e1235-48*e2e1*ammu*amuq*ammu2*x1*x4*xcp3*e1345-288*e2e1*ammu*amuq*ammu2*x1*x4*xcp3*e1235+48*e2e1*ammu
*amuq*ammu2*x1*x4*xcp2*e1345+288*e2e1*ammu*amuq*ammu2*x1*x4*xcp2*e1235-432*e2e1*ammu*amuq*ammu2*x1*x4*xcp1*e1245-192*e2e1*ammu*amuq*ammu2*x1*x4*xcp1*e1235+48*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp4*e1345-96*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp4*e1245-192*
e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp4*e1235-192*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp4*e1234-48*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp3*e1345+48*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp3*e1245+336*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp3*e1235+48*e2e1*ammu*amuq*ammu2*x1*x4
*x6*xcp2*e1345-48*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp2*e1245-336*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp2*e1235-48*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp1*e1345+96*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp1*e1245+192*e2e1*ammu*amuq*ammu2*x1*x4*x6*xcp1*e1235+192*e2e1*
ammu*amuq*ammu2*x1*x4*x6*xcp1*e1234+48*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp4*e1345-384*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp4*e1245-144*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp4*e1235-96*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp3*e1345-48*e2e1*ammu*amuq*ammu2*x1*x4*x5*
xcp3*e1245+48*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp3*e1235-336*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp3*e1234+96*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp2*e1345+48*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp2*e1245-48*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp2*e1235+336*e2e1*ammu*
amuq*ammu2*x1*x4*x5*xcp2*e1234-48*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp1*e1345+384*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp1*e1245+144*e2e1*ammu*amuq*ammu2*x1*x4*x5*xcp1*e1235-96*e2e1*ammu*amuq*ammu2*x1*x4^2*xcp4*e1245-192*e2e1*ammu*amuq*ammu2*x1*x4^2*xcp4*
e1235-96*e2e1*ammu*amuq*ammu2*x1*x4^2*xcp3*e1245+144*e2e1*ammu*amuq*ammu2*x1*x4^2*xcp3*e1235+96*e2e1*ammu*amuq*ammu2*x1*x4^2*xcp2*e1245-144*e2e1*ammu*amuq*ammu2*x1*x4^2*xcp2*e1235+96*e2e1*ammu*amuq*ammu2*x1*x4^2*xcp1*e1245+192*e2e1*ammu*amuq*ammu2*
x1*x4^2*xcp1*e1235+48*e2e1*ammu*amuq*ammu2*x1*x3*xcp3*e1245-48*e2e1*ammu*amuq*ammu2*x1*x3*xcp3*e1235-48*e2e1*ammu*amuq*ammu2*x1*x3*xcp2*e1245+48*e2e1*ammu*amuq*ammu2*x1*x3*xcp2*e1235-48*e2e1*ammu*amuq*ammu2*x1*x3*x6*xcp4*e1245+48*e2e1*ammu*amuq*
ammu2*x1*x3*x6*xcp1*e1245+48*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp4*e1245-48*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp4*e1235-48*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp4*e1234-288*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp3*e1245-96*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp3*e1235-
96*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp3*e1234+288*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp2*e1245+96*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp2*e1235+96*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp2*e1234-48*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp1*e1245+48*e2e1*ammu*amuq*ammu2*x1*
x3*x5*xcp1*e1235+48*e2e1*ammu*amuq*ammu2*x1*x3*x5*xcp1*e1234+96*e2e1*ammu*amuq*ammu2*x1*x3*x4*xcp4*e1245-48*e2e1*ammu*amuq*ammu2*x1*x3*x4*xcp4*e1235-96*e2e1*ammu*amuq*ammu2*x1*x3*x4*xcp3*e1245+96*e2e1*ammu*amuq*ammu2*x1*x3*x4*xcp2*e1245-96*e2e1*
ammu*amuq*ammu2*x1*x3*x4*xcp1*e1245+48*e2e1*ammu*amuq*ammu2*x1*x3*x4*xcp1*e1235-768*e2e1*ammu*amuq*ammu2^2*amuq2*x6*xcp4-768*e2e1*ammu*amuq*ammu2^2*amuq2*x6*xcp3-768*e2e1*ammu*amuq*ammu2^2*amuq2*x6*xcp2-768*e2e1*ammu*amuq*ammu2^2*amuq2*x6*xcp1+384*
e2e1*ammu*amuq*ammu2^2*amuq2*x6^2*xcp4+384*e2e1*ammu*amuq*ammu2^2*amuq2*x6^2*xcp3+384*e2e1*ammu*amuq*ammu2^2*amuq2*x6^2*xcp2+384*e2e1*ammu*amuq*ammu2^2*amuq2*x6^2*xcp1-768*e2e1*ammu*amuq*ammu2^2*amuq2*x5*xcp4-768*e2e1*ammu*amuq*ammu2^2*amuq2*x5*
xcp3-768*e2e1*ammu*amuq*ammu2^2*amuq2*x5*xcp2-768*e2e1*ammu*amuq*ammu2^2*amuq2*x5*xcp1+1152*e2e1*ammu*amuq*ammu2^2*amuq2*x5*x6*xcp4+1152*e2e1*ammu*amuq*ammu2^2*amuq2*x5*x6*xcp3+1152*e2e1*ammu*amuq*ammu2^2*amuq2*x5*x6*xcp2+1152*e2e1*ammu*amuq*
ammu2^2*amuq2*x5*x6*xcp1+768*e2e1*ammu*amuq*ammu2^2*amuq2*x5^2*xcp4+768*e2e1*ammu*amuq*ammu2^2*amuq2*x5^2*xcp3+768*e2e1*ammu*amuq*ammu2^2*amuq2*x5^2*xcp2+768*e2e1*ammu*amuq*ammu2^2*amuq2*x5^2*xcp1+384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x6*xcp4+384*
e2e1*ammu*amuq*ammu2^2*amuq2*x4*x6*xcp3+384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x6*xcp2+384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x6*xcp1-384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x6^2*xcp4+384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x6^2*xcp3+384*e2e1*ammu*amuq*ammu2^2*
amuq2*x4*x6^2*xcp2-384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x6^2*xcp1+384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x5*xcp4+384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x5*xcp3+384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x5*xcp2+384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x5*xcp1-384*
e2e1*ammu*amuq*ammu2^2*amuq2*x4*x5*x6*xcp4+384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x5*x6*xcp3+384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x5*x6*xcp2-384*e2e1*ammu*amuq*ammu2^2*amuq2*x4*x5*x6*xcp1-2304*e2e1*ammu*amuq*ammu2^3*x6*xcp4-768*e2e1*ammu*amuq*ammu2^3*
x6*xcp3-768*e2e1*ammu*amuq*ammu2^3*x6*xcp2-2304*e2e1*ammu*amuq*ammu2^3*x6*xcp1+1920*e2e1*ammu*amuq*ammu2^3*x6^2*xcp4+384*e2e1*ammu*amuq*ammu2^3*x6^2*xcp3+384*e2e1*ammu*amuq*ammu2^3*x6^2*xcp2+1920*e2e1*ammu*amuq*ammu2^3*x6^2*xcp1-384*e2e1*ammu*amuq*
ammu2^3*x6^3*xcp4-384*e2e1*ammu*amuq*ammu2^3*x6^3*xcp1-2304*e2e1*ammu*amuq*ammu2^3*x5*xcp4-768*e2e1*ammu*amuq*ammu2^3*x5*xcp3-768*e2e1*ammu*amuq*ammu2^3*x5*xcp2-2304*e2e1*ammu*amuq*ammu2^3*x5*xcp1+5760*e2e1*ammu*amuq*ammu2^3*x5*x6*xcp4+1152*e2e1*
ammu*amuq*ammu2^3*x5*x6*xcp3+1152*e2e1*ammu*amuq*ammu2^3*x5*x6*xcp2+5760*e2e1*ammu*amuq*ammu2^3*x5*x6*xcp1-1920*e2e1*ammu*amuq*ammu2^3*x5*x6^2*xcp4-1920*e2e1*ammu*amuq*ammu2^3*x5*x6^2*xcp1+3840*e2e1*ammu*amuq*ammu2^3*x5^2*xcp4+768*e2e1*ammu*amuq*
ammu2^3*x5^2*xcp3+768*e2e1*ammu*amuq*ammu2^3*x5^2*xcp2+3840*e2e1*ammu*amuq*ammu2^3*x5^2*xcp1-3072*e2e1*ammu*amuq*ammu2^3*x5^2*x6*xcp4-3072*e2e1*ammu*amuq*ammu2^3*x5^2*x6*xcp1-1536*e2e1*ammu*amuq*ammu2^3*x5^3*xcp4-1536*e2e1*ammu*amuq*ammu2^3*x5^3*
xcp1+1920*e2e1*ammu*amuq*ammu2^3*x4*x6*xcp4+384*e2e1*ammu*amuq*ammu2^3*x4*x6*xcp3+384*e2e1*ammu*amuq*ammu2^3*x4*x6*xcp2+1920*e2e1*ammu*amuq*ammu2^3*x4*x6*xcp1-384*e2e1*ammu*amuq*ammu2^3*x4*x6^2*xcp4-384*e2e1*ammu*amuq*ammu2^3*x4*x6^2*xcp3-384*e2e1*
ammu*amuq*ammu2^3*x4*x6^2*xcp2-384*e2e1*ammu*amuq*ammu2^3*x4*x6^2*xcp1+1920*e2e1*ammu*amuq*ammu2^3*x4*x5*xcp4+384*e2e1*ammu*amuq*ammu2^3*x4*x5*xcp3+384*e2e1*ammu*amuq*ammu2^3*x4*x5*xcp2+1920*e2e1*ammu*amuq*ammu2^3*x4*x5*xcp1-1920*e2e1*ammu*amuq*
ammu2^3*x4*x5*x6*xcp4-384*e2e1*ammu*amuq*ammu2^3*x4*x5*x6*xcp3-384*e2e1*ammu*amuq*ammu2^3*x4*x5*x6*xcp2-1920*e2e1*ammu*amuq*ammu2^3*x4*x5*x6*xcp1-1536*e2e1*ammu*amuq*ammu2^3*x4*x5^2*xcp4-1536*e2e1*ammu*amuq*ammu2^3*x4*x5^2*xcp1-384*e2e1*ammu*amuq*
ammu2^3*x4^2*x6*xcp4-384*e2e1*ammu*amuq*ammu2^3*x4^2*x6*xcp1-384*e2e1*ammu*amuq*ammu2^3*x4^2*x5*xcp4-384*e2e1*ammu*amuq*ammu2^3*x4^2*x5*xcp1+288*e2e1*ammu*amuq*amel2*xcp4*e2345+384*e2e1*ammu*amuq*amel2*xcp4*e1345-192*e2e1*ammu*amuq*amel2*xcp4*e1245
+1440*e2e1*ammu*amuq*amel2*xcp4*e1235+1344*e2e1*ammu*amuq*amel2*xcp4*e1234-384*e2e1*ammu*amuq*amel2*xcp3*e2345-192*e2e1*ammu*amuq*amel2*xcp3*e1245+1728*e2e1*ammu*amuq*amel2*xcp3*e1235+192*e2e1*ammu*amuq*amel2*xcp3*e1234+384*e2e1*ammu*amuq*amel2*
xcp2*e2345+192*e2e1*ammu*amuq*amel2*xcp2*e1245-1728*e2e1*ammu*amuq*amel2*xcp2*e1235-192*e2e1*ammu*amuq*amel2*xcp2*e1234-288*e2e1*ammu*amuq*amel2*xcp1*e2345-384*e2e1*ammu*amuq*amel2*xcp1*e1345+192*e2e1*ammu*amuq*amel2*xcp1*e1245-1440*e2e1*ammu*amuq*
amel2*xcp1*e1235-1344*e2e1*ammu*amuq*amel2*xcp1*e1234-144*e2e1*ammu*amuq*amel2*x6*xcp4*e2345-336*e2e1*ammu*amuq*amel2*x6*xcp4*e1345+48*e2e1*ammu*amuq*amel2*x6*xcp4*e1235+96*e2e1*ammu*amuq*amel2*x6*xcp3*e1345-96*e2e1*ammu*amuq*amel2*x6*xcp2*e1345+
144*e2e1*ammu*amuq*amel2*x6*xcp1*e2345+336*e2e1*ammu*amuq*amel2*x6*xcp1*e1345-48*e2e1*ammu*amuq*amel2*x6*xcp1*e1235-144*e2e1*ammu*amuq*amel2*x6^2*xcp4*e2345-144*e2e1*ammu*amuq*amel2*x6^2*xcp4*e1345+192*e2e1*ammu*amuq*amel2*x6^2*xcp4*e1245-240*e2e1*
ammu*amuq*amel2*x6^2*xcp4*e1235+192*e2e1*ammu*amuq*amel2*x6^2*xcp4*e1234+144*e2e1*ammu*amuq*amel2*x6^2*xcp3*e2345+96*e2e1*ammu*amuq*amel2*x6^2*xcp3*e1345+192*e2e1*ammu*amuq*amel2*x6^2*xcp3*e1245-192*e2e1*ammu*amuq*amel2*x6^2*xcp3*e1235-192*e2e1*
ammu*amuq*amel2*x6^2*xcp3*e1234-144*e2e1*ammu*amuq*amel2*x6^2*xcp2*e2345-96*e2e1*ammu*amuq*amel2*x6^2*xcp2*e1345-192*e2e1*ammu*amuq*amel2*x6^2*xcp2*e1245+192*e2e1*ammu*amuq*amel2*x6^2*xcp2*e1235+192*e2e1*ammu*amuq*amel2*x6^2*xcp2*e1234+144*e2e1*
ammu*amuq*amel2*x6^2*xcp1*e2345+144*e2e1*ammu*amuq*amel2*x6^2*xcp1*e1345-192*e2e1*ammu*amuq*amel2*x6^2*xcp1*e1245+240*e2e1*ammu*amuq*amel2*x6^2*xcp1*e1235-192*e2e1*ammu*amuq*amel2*x6^2*xcp1*e1234+96*e2e1*ammu*amuq*amel2*x6^3*xcp4*e2345+48*e2e1*ammu
*amuq*amel2*x6^3*xcp3*e2345-48*e2e1*ammu*amuq*amel2*x6^3*xcp2*e2345-96*e2e1*ammu*amuq*amel2*x6^3*xcp1*e2345-1632*e2e1*ammu*amuq*amel2*x5*xcp4*e2345-2592*e2e1*ammu*amuq*amel2*x5*xcp4*e1345-1536*e2e1*ammu*amuq*amel2*x5*xcp4*e1245+48*e2e1*ammu*amuq*
amel2*x5*xcp4*e1235+864*e2e1*ammu*amuq*amel2*x5*xcp4*e1234-1488*e2e1*ammu*amuq*amel2*x5*xcp3*e2345-1008*e2e1*ammu*amuq*amel2*x5*xcp3*e1345-1536*e2e1*ammu*amuq*amel2*x5*xcp3*e1245+864*e2e1*ammu*amuq*amel2*x5*xcp3*e1234+1488*e2e1*ammu*amuq*amel2*x5*
xcp2*e2345+1008*e2e1*ammu*amuq*amel2*x5*xcp2*e1345+1536*e2e1*ammu*amuq*amel2*x5*xcp2*e1245-864*e2e1*ammu*amuq*amel2*x5*xcp2*e1234+1632*e2e1*ammu*amuq*amel2*x5*xcp1*e2345+2592*e2e1*ammu*amuq*amel2*x5*xcp1*e1345+1536*e2e1*ammu*amuq*amel2*x5*xcp1*
e1245-48*e2e1*ammu*amuq*amel2*x5*xcp1*e1235-864*e2e1*ammu*amuq*amel2*x5*xcp1*e1234-144*e2e1*ammu*amuq*amel2*x5*x6*xcp4*e2345+240*e2e1*ammu*amuq*amel2*x5*x6*xcp4*e1345+384*e2e1*ammu*amuq*amel2*x5*x6*xcp4*e1245-480*e2e1*ammu*amuq*amel2*x5*x6*xcp4*
e1235+432*e2e1*ammu*amuq*amel2*x5*x6*xcp3*e2345-432*e2e1*ammu*amuq*amel2*x5*x6*xcp3*e1345+384*e2e1*ammu*amuq*amel2*x5*x6*xcp3*e1245-384*e2e1*ammu*amuq*amel2*x5*x6*xcp3*e1235+384*e2e1*ammu*amuq*amel2*x5*x6*xcp3*e1234-432*e2e1*ammu*amuq*amel2*x5*x6*
xcp2*e2345+432*e2e1*ammu*amuq*amel2*x5*x6*xcp2*e1345-384*e2e1*ammu*amuq*amel2*x5*x6*xcp2*e1245+384*e2e1*ammu*amuq*amel2*x5*x6*xcp2*e1235-384*e2e1*ammu*amuq*amel2*x5*x6*xcp2*e1234+144*e2e1*ammu*amuq*amel2*x5*x6*xcp1*e2345-240*e2e1*ammu*amuq*amel2*x5
*x6*xcp1*e1345-384*e2e1*ammu*amuq*amel2*x5*x6*xcp1*e1245+480*e2e1*ammu*amuq*amel2*x5*x6*xcp1*e1235+288*e2e1*ammu*amuq*amel2*x5*x6^2*xcp4*e2345+96*e2e1*ammu*amuq*amel2*x5*x6^2*xcp4*e1234+144*e2e1*ammu*amuq*amel2*x5*x6^2*xcp3*e2345+48*e2e1*ammu*amuq*
amel2*x5*x6^2*xcp3*e1234-144*e2e1*ammu*amuq*amel2*x5*x6^2*xcp2*e2345-48*e2e1*ammu*amuq*amel2*x5*x6^2*xcp2*e1234-288*e2e1*ammu*amuq*amel2*x5*x6^2*xcp1*e2345-96*e2e1*ammu*amuq*amel2*x5*x6^2*xcp1*e1234+384*e2e1*ammu*amuq*amel2*x5^2*xcp4*e1345+192*e2e1
*ammu*amuq*amel2*x5^2*xcp4*e1245-240*e2e1*ammu*amuq*amel2*x5^2*xcp4*e1235+336*e2e1*ammu*amuq*amel2*x5^2*xcp4*e1234+288*e2e1*ammu*amuq*amel2*x5^2*xcp3*e2345-528*e2e1*ammu*amuq*amel2*x5^2*xcp3*e1345+192*e2e1*ammu*amuq*amel2*x5^2*xcp3*e1245-192*e2e1*
ammu*amuq*amel2*x5^2*xcp3*e1235+528*e2e1*ammu*amuq*amel2*x5^2*xcp3*e1234-288*e2e1*ammu*amuq*amel2*x5^2*xcp2*e2345+528*e2e1*ammu*amuq*amel2*x5^2*xcp2*e1345-192*e2e1*ammu*amuq*amel2*x5^2*xcp2*e1245+192*e2e1*ammu*amuq*amel2*x5^2*xcp2*e1235-528*e2e1*
ammu*amuq*amel2*x5^2*xcp2*e1234-384*e2e1*ammu*amuq*amel2*x5^2*xcp1*e1345-192*e2e1*ammu*amuq*amel2*x5^2*xcp1*e1245+240*e2e1*ammu*amuq*amel2*x5^2*xcp1*e1235-336*e2e1*ammu*amuq*amel2*x5^2*xcp1*e1234+288*e2e1*ammu*amuq*amel2*x5^2*x6*xcp4*e2345+144*e2e1
*ammu*amuq*amel2*x5^2*x6*xcp4*e1234+144*e2e1*ammu*amuq*amel2*x5^2*x6*xcp3*e2345+240*e2e1*ammu*amuq*amel2*x5^2*x6*xcp3*e1234-144*e2e1*ammu*amuq*amel2*x5^2*x6*xcp2*e2345-240*e2e1*ammu*amuq*amel2*x5^2*x6*xcp2*e1234-288*e2e1*ammu*amuq*amel2*x5^2*x6*
xcp1*e2345-144*e2e1*ammu*amuq*amel2*x5^2*x6*xcp1*e1234+96*e2e1*ammu*amuq*amel2*x5^3*xcp4*e2345+48*e2e1*ammu*amuq*amel2*x5^3*xcp4*e1234+48*e2e1*ammu*amuq*amel2*x5^3*xcp3*e2345+192*e2e1*ammu*amuq*amel2*x5^3*xcp3*e1234-48*e2e1*ammu*amuq*amel2*x5^3*
xcp2*e2345-192*e2e1*ammu*amuq*amel2*x5^3*xcp2*e1234-96*e2e1*ammu*amuq*amel2*x5^3*xcp1*e2345-48*e2e1*ammu*amuq*amel2*x5^3*xcp1*e1234-1968*e2e1*ammu*amuq*amel2*x4*xcp4*e2345-1392*e2e1*ammu*amuq*amel2*x4*xcp4*e1345-1536*e2e1*ammu*amuq*amel2*x4*xcp4*
e1245+720*e2e1*ammu*amuq*amel2*x4*xcp4*e1235+768*e2e1*ammu*amuq*amel2*x4*xcp4*e1234+288*e2e1*ammu*amuq*amel2*x4*xcp3*e2345-192*e2e1*ammu*amuq*amel2*x4*xcp3*e1345-288*e2e1*ammu*amuq*amel2*x4*xcp3*e1235-288*e2e1*ammu*amuq*amel2*x4*xcp2*e2345+192*e2e1
*ammu*amuq*amel2*x4*xcp2*e1345+288*e2e1*ammu*amuq*amel2*x4*xcp2*e1235+1968*e2e1*ammu*amuq*amel2*x4*xcp1*e2345+1392*e2e1*ammu*amuq*amel2*x4*xcp1*e1345+1536*e2e1*ammu*amuq*amel2*x4*xcp1*e1245-720*e2e1*ammu*amuq*amel2*x4*xcp1*e1235-768*e2e1*ammu*amuq*
amel2*x4*xcp1*e1234-672*e2e1*ammu*amuq*amel2*x4*x6*xcp4*e2345-96*e2e1*ammu*amuq*amel2*x4*x6*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x4*x6*xcp4*e1235+288*e2e1*ammu*amuq*amel2*x4*x6*xcp3*e2345+192*e2e1*ammu*amuq*amel2*x4*x6*xcp3*e1345-768*e2e1*ammu*amuq*
amel2*x4*x6*xcp3*e1235-288*e2e1*ammu*amuq*amel2*x4*x6*xcp2*e2345-192*e2e1*ammu*amuq*amel2*x4*x6*xcp2*e1345+768*e2e1*ammu*amuq*amel2*x4*x6*xcp2*e1235+672*e2e1*ammu*amuq*amel2*x4*x6*xcp1*e2345+96*e2e1*ammu*amuq*amel2*x4*x6*xcp1*e1345+384*e2e1*ammu*
amuq*amel2*x4*x6*xcp1*e1235-288*e2e1*ammu*amuq*amel2*x4*x6^2*xcp4*e2345-192*e2e1*ammu*amuq*amel2*x4*x6^2*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x4*x6^2*xcp4*e1245-288*e2e1*ammu*amuq*amel2*x4*x6^2*xcp4*e1235-384*e2e1*ammu*amuq*amel2*x4*x6^2*xcp4*e1234-
336*e2e1*ammu*amuq*amel2*x4*x6^2*xcp3*e2345-288*e2e1*ammu*amuq*amel2*x4*x6^2*xcp3*e1345-384*e2e1*ammu*amuq*amel2*x4*x6^2*xcp3*e1245+1152*e2e1*ammu*amuq*amel2*x4*x6^2*xcp3*e1235+384*e2e1*ammu*amuq*amel2*x4*x6^2*xcp3*e1234+336*e2e1*ammu*amuq*amel2*x4
*x6^2*xcp2*e2345+288*e2e1*ammu*amuq*amel2*x4*x6^2*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x4*x6^2*xcp2*e1245-1152*e2e1*ammu*amuq*amel2*x4*x6^2*xcp2*e1235-384*e2e1*ammu*amuq*amel2*x4*x6^2*xcp2*e1234+288*e2e1*ammu*amuq*amel2*x4*x6^2*xcp1*e2345+192*e2e1*
ammu*amuq*amel2*x4*x6^2*xcp1*e1345+384*e2e1*ammu*amuq*amel2*x4*x6^2*xcp1*e1245+288*e2e1*ammu*amuq*amel2*x4*x6^2*xcp1*e1235+384*e2e1*ammu*amuq*amel2*x4*x6^2*xcp1*e1234+1104*e2e1*ammu*amuq*amel2*x4*x5*xcp4*e2345+1872*e2e1*ammu*amuq*amel2*x4*x5*xcp4*
e1345+1152*e2e1*ammu*amuq*amel2*x4*x5*xcp4*e1245-1008*e2e1*ammu*amuq*amel2*x4*x5*xcp4*e1235-1440*e2e1*ammu*amuq*amel2*x4*x5*xcp4*e1234-192*e2e1*ammu*amuq*amel2*x4*x5*xcp3*e2345+192*e2e1*ammu*amuq*amel2*x4*x5*xcp3*e1345-384*e2e1*ammu*amuq*amel2*x4*
x5*xcp3*e1245-432*e2e1*ammu*amuq*amel2*x4*x5*xcp3*e1235-240*e2e1*ammu*amuq*amel2*x4*x5*xcp3*e1234+192*e2e1*ammu*amuq*amel2*x4*x5*xcp2*e2345-192*e2e1*ammu*amuq*amel2*x4*x5*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x4*x5*xcp2*e1245+432*e2e1*ammu*amuq*amel2
*x4*x5*xcp2*e1235+240*e2e1*ammu*amuq*amel2*x4*x5*xcp2*e1234-1104*e2e1*ammu*amuq*amel2*x4*x5*xcp1*e2345-1872*e2e1*ammu*amuq*amel2*x4*x5*xcp1*e1345-1152*e2e1*ammu*amuq*amel2*x4*x5*xcp1*e1245+1008*e2e1*ammu*amuq*amel2*x4*x5*xcp1*e1235+1440*e2e1*ammu*
amuq*amel2*x4*x5*xcp1*e1234+192*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp4*e2345+384*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp4*e1245-240*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp4*e1235-480*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp4*
e1234-1392*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp3*e2345-1392*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp3*e1345-384*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp3*e1245+1296*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp3*e1235+336*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp3*e1234+1392*e2e1*ammu
*amuq*amel2*x4*x5*x6*xcp2*e2345+1392*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp2*e1245-1296*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp2*e1235-336*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp2*e1234-192*e2e1*ammu*amuq*amel2*x4*x5*x6*
xcp1*e2345-384*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp1*e1345+384*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp1*e1245+240*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp1*e1235+480*e2e1*ammu*amuq*amel2*x4*x5*x6*xcp1*e1234+192*e2e1*ammu*amuq*amel2*x4*x5^2*xcp4*e2345+96*e2e1*ammu*
amuq*amel2*x4*x5^2*xcp4*e1345+48*e2e1*ammu*amuq*amel2*x4*x5^2*xcp4*e1235-48*e2e1*ammu*amuq*amel2*x4*x5^2*xcp4*e1234-192*e2e1*ammu*amuq*amel2*x4*x5^2*xcp3*e2345+336*e2e1*ammu*amuq*amel2*x4*x5^2*xcp3*e1345+144*e2e1*ammu*amuq*amel2*x4*x5^2*xcp3*e1235-
96*e2e1*ammu*amuq*amel2*x4*x5^2*xcp3*e1234+192*e2e1*ammu*amuq*amel2*x4*x5^2*xcp2*e2345-336*e2e1*ammu*amuq*amel2*x4*x5^2*xcp2*e1345-144*e2e1*ammu*amuq*amel2*x4*x5^2*xcp2*e1235+96*e2e1*ammu*amuq*amel2*x4*x5^2*xcp2*e1234-192*e2e1*ammu*amuq*amel2*x4*
x5^2*xcp1*e2345-96*e2e1*ammu*amuq*amel2*x4*x5^2*xcp1*e1345-48*e2e1*ammu*amuq*amel2*x4*x5^2*xcp1*e1235+48*e2e1*ammu*amuq*amel2*x4*x5^2*xcp1*e1234+816*e2e1*ammu*amuq*amel2*x4^2*xcp4*e2345+240*e2e1*ammu*amuq*amel2*x4^2*xcp4*e1345+960*e2e1*ammu*amuq*
amel2*x4^2*xcp4*e1245-432*e2e1*ammu*amuq*amel2*x4^2*xcp4*e1235-576*e2e1*ammu*amuq*amel2*x4^2*xcp4*e1234+48*e2e1*ammu*amuq*amel2*x4^2*xcp3*e2345+192*e2e1*ammu*amuq*amel2*x4^2*xcp3*e1345+192*e2e1*ammu*amuq*amel2*x4^2*xcp3*e1245-48*e2e1*ammu*amuq*
amel2*x4^2*xcp3*e1235-192*e2e1*ammu*amuq*amel2*x4^2*xcp3*e1234-48*e2e1*ammu*amuq*amel2*x4^2*xcp2*e2345-192*e2e1*ammu*amuq*amel2*x4^2*xcp2*e1345-192*e2e1*ammu*amuq*amel2*x4^2*xcp2*e1245+48*e2e1*ammu*amuq*amel2*x4^2*xcp2*e1235+192*e2e1*ammu*amuq*
amel2*x4^2*xcp2*e1234-816*e2e1*ammu*amuq*amel2*x4^2*xcp1*e2345-240*e2e1*ammu*amuq*amel2*x4^2*xcp1*e1345-960*e2e1*ammu*amuq*amel2*x4^2*xcp1*e1245+432*e2e1*ammu*amuq*amel2*x4^2*xcp1*e1235+576*e2e1*ammu*amuq*amel2*x4^2*xcp1*e1234+480*e2e1*ammu*amuq*
amel2*x4^2*x6*xcp4*e2345+576*e2e1*ammu*amuq*amel2*x4^2*x6*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x4^2*x6*xcp4*e1245-480*e2e1*ammu*amuq*amel2*x4^2*x6*xcp4*e1235-384*e2e1*ammu*amuq*amel2*x4^2*x6*xcp4*e1234-336*e2e1*ammu*amuq*amel2*x4^2*x6*xcp3*e2345-288
*e2e1*ammu*amuq*amel2*x4^2*x6*xcp3*e1345-384*e2e1*ammu*amuq*amel2*x4^2*x6*xcp3*e1245+1200*e2e1*ammu*amuq*amel2*x4^2*x6*xcp3*e1235+384*e2e1*ammu*amuq*amel2*x4^2*x6*xcp3*e1234+336*e2e1*ammu*amuq*amel2*x4^2*x6*xcp2*e2345+288*e2e1*ammu*amuq*amel2*x4^2*
x6*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x4^2*x6*xcp2*e1245-1200*e2e1*ammu*amuq*amel2*x4^2*x6*xcp2*e1235-384*e2e1*ammu*amuq*amel2*x4^2*x6*xcp2*e1234-480*e2e1*ammu*amuq*amel2*x4^2*x6*xcp1*e2345-576*e2e1*ammu*amuq*amel2*x4^2*x6*xcp1*e1345+384*e2e1*ammu
*amuq*amel2*x4^2*x6*xcp1*e1245+480*e2e1*ammu*amuq*amel2*x4^2*x6*xcp1*e1235+384*e2e1*ammu*amuq*amel2*x4^2*x6*xcp1*e1234+288*e2e1*ammu*amuq*amel2*x4^2*x5*xcp4*e2345-48*e2e1*ammu*amuq*amel2*x4^2*x5*xcp4*e1235+96*e2e1*ammu*amuq*amel2*x4^2*x5*xcp3*e2345
+48*e2e1*ammu*amuq*amel2*x4^2*x5*xcp3*e1345-192*e2e1*ammu*amuq*amel2*x4^2*x5*xcp3*e1235-96*e2e1*ammu*amuq*amel2*x4^2*x5*xcp2*e2345-48*e2e1*ammu*amuq*amel2*x4^2*x5*xcp2*e1345+192*e2e1*ammu*amuq*amel2*x4^2*x5*xcp2*e1235-288*e2e1*ammu*amuq*amel2*x4^2*
x5*xcp1*e2345+48*e2e1*ammu*amuq*amel2*x4^2*x5*xcp1*e1235+96*e2e1*ammu*amuq*amel2*x4^3*xcp4*e2345+48*e2e1*ammu*amuq*amel2*x4^3*xcp3*e2345-48*e2e1*ammu*amuq*amel2*x4^3*xcp3*e1235-48*e2e1*ammu*amuq*amel2*x4^3*xcp2*e2345+48*e2e1*ammu*amuq*amel2*x4^3*
xcp2*e1235-96*e2e1*ammu*amuq*amel2*x4^3*xcp1*e2345-384*e2e1*ammu*amuq*amel2*x3*xcp4*e2345+2256*e2e1*ammu*amuq*amel2*x3*xcp4*e1235+1536*e2e1*ammu*amuq*amel2*x3*xcp4*e1234+240*e2e1*ammu*amuq*amel2*x3*xcp3*e2345-48*e2e1*ammu*amuq*amel2*x3*xcp3*e1345+
624*e2e1*ammu*amuq*amel2*x3*xcp3*e1235-240*e2e1*ammu*amuq*amel2*x3*xcp2*e2345+48*e2e1*ammu*amuq*amel2*x3*xcp2*e1345-624*e2e1*ammu*amuq*amel2*x3*xcp2*e1235+384*e2e1*ammu*amuq*amel2*x3*xcp1*e2345-2256*e2e1*ammu*amuq*amel2*x3*xcp1*e1235-1536*e2e1*ammu
*amuq*amel2*x3*xcp1*e1234-528*e2e1*ammu*amuq*amel2*x3*x6*xcp4*e2345-144*e2e1*ammu*amuq*amel2*x3*x6*xcp4*e1345+144*e2e1*ammu*amuq*amel2*x3*x6*xcp3*e2345+240*e2e1*ammu*amuq*amel2*x3*x6*xcp3*e1345-48*e2e1*ammu*amuq*amel2*x3*x6*xcp3*e1235-144*e2e1*ammu
*amuq*amel2*x3*x6*xcp2*e2345-240*e2e1*ammu*amuq*amel2*x3*x6*xcp2*e1345+48*e2e1*ammu*amuq*amel2*x3*x6*xcp2*e1235+528*e2e1*ammu*amuq*amel2*x3*x6*xcp1*e2345+144*e2e1*ammu*amuq*amel2*x3*x6*xcp1*e1345-288*e2e1*ammu*amuq*amel2*x3*x6^2*xcp4*e2345-192*e2e1
*ammu*amuq*amel2*x3*x6^2*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x3*x6^2*xcp4*e1245-384*e2e1*ammu*amuq*amel2*x3*x6^2*xcp4*e1235-384*e2e1*ammu*amuq*amel2*x3*x6^2*xcp4*e1234-336*e2e1*ammu*amuq*amel2*x3*x6^2*xcp3*e2345-288*e2e1*ammu*amuq*amel2*x3*x6^2*
xcp3*e1345-384*e2e1*ammu*amuq*amel2*x3*x6^2*xcp3*e1245+1152*e2e1*ammu*amuq*amel2*x3*x6^2*xcp3*e1235+384*e2e1*ammu*amuq*amel2*x3*x6^2*xcp3*e1234+336*e2e1*ammu*amuq*amel2*x3*x6^2*xcp2*e2345+288*e2e1*ammu*amuq*amel2*x3*x6^2*xcp2*e1345+384*e2e1*ammu*
amuq*amel2*x3*x6^2*xcp2*e1245-1152*e2e1*ammu*amuq*amel2*x3*x6^2*xcp2*e1235-384*e2e1*ammu*amuq*amel2*x3*x6^2*xcp2*e1234+288*e2e1*ammu*amuq*amel2*x3*x6^2*xcp1*e2345+192*e2e1*ammu*amuq*amel2*x3*x6^2*xcp1*e1345+384*e2e1*ammu*amuq*amel2*x3*x6^2*xcp1*
e1245+384*e2e1*ammu*amuq*amel2*x3*x6^2*xcp1*e1235+384*e2e1*ammu*amuq*amel2*x3*x6^2*xcp1*e1234-768*e2e1*ammu*amuq*amel2*x3*x5*xcp4*e2345-768*e2e1*ammu*amuq*amel2*x3*x5*xcp4*e1345-816*e2e1*ammu*amuq*amel2*x3*x5*xcp4*e1234+288*e2e1*ammu*amuq*amel2*x3*
x5*xcp3*e2345+1152*e2e1*ammu*amuq*amel2*x3*x5*xcp3*e1345-48*e2e1*ammu*amuq*amel2*x3*x5*xcp3*e1235-864*e2e1*ammu*amuq*amel2*x3*x5*xcp3*e1234-288*e2e1*ammu*amuq*amel2*x3*x5*xcp2*e2345-1152*e2e1*ammu*amuq*amel2*x3*x5*xcp2*e1345+48*e2e1*ammu*amuq*amel2
*x3*x5*xcp2*e1235+864*e2e1*ammu*amuq*amel2*x3*x5*xcp2*e1234+768*e2e1*ammu*amuq*amel2*x3*x5*xcp1*e2345+768*e2e1*ammu*amuq*amel2*x3*x5*xcp1*e1345+816*e2e1*ammu*amuq*amel2*x3*x5*xcp1*e1234-192*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp4*e2345-768*e2e1*ammu*
amuq*amel2*x3*x5*x6*xcp4*e1245-768*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp4*e1235-816*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp4*e1234-1824*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp3*e2345-1728*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp3*e1345-768*e2e1*ammu*amuq*amel2*x3*x5*x6*
xcp3*e1245+2304*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp3*e1235+672*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp3*e1234+1824*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp2*e2345+1728*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp2*e1345+768*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp2*e1245-2304*e2e1
*ammu*amuq*amel2*x3*x5*x6*xcp2*e1235-672*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp2*e1234+192*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp1*e2345+768*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp1*e1245+768*e2e1*ammu*amuq*amel2*x3*x5*x6*xcp1*e1235+816*e2e1*ammu*amuq*amel2*x3*x5*
x6*xcp1*e1234+96*e2e1*ammu*amuq*amel2*x3*x5^2*xcp4*e2345+192*e2e1*ammu*amuq*amel2*x3*x5^2*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x3*x5^2*xcp4*e1245-384*e2e1*ammu*amuq*amel2*x3*x5^2*xcp4*e1235-384*e2e1*ammu*amuq*amel2*x3*x5^2*xcp4*e1234-1488*e2e1*ammu*
amuq*amel2*x3*x5^2*xcp3*e2345-1440*e2e1*ammu*amuq*amel2*x3*x5^2*xcp3*e1345-384*e2e1*ammu*amuq*amel2*x3*x5^2*xcp3*e1245+1152*e2e1*ammu*amuq*amel2*x3*x5^2*xcp3*e1235+144*e2e1*ammu*amuq*amel2*x3*x5^2*xcp3*e1234+1488*e2e1*ammu*amuq*amel2*x3*x5^2*xcp2*
e2345+1440*e2e1*ammu*amuq*amel2*x3*x5^2*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x3*x5^2*xcp2*e1245-1152*e2e1*ammu*amuq*amel2*x3*x5^2*xcp2*e1235-144*e2e1*ammu*amuq*amel2*x3*x5^2*xcp2*e1234-96*e2e1*ammu*amuq*amel2*x3*x5^2*xcp1*e2345-192*e2e1*ammu*amuq*
amel2*x3*x5^2*xcp1*e1345+384*e2e1*ammu*amuq*amel2*x3*x5^2*xcp1*e1245+384*e2e1*ammu*amuq*amel2*x3*x5^2*xcp1*e1235+384*e2e1*ammu*amuq*amel2*x3*x5^2*xcp1*e1234+48*e2e1*ammu*amuq*amel2*x3*x4*xcp4*e2345-912*e2e1*ammu*amuq*amel2*x3*x4*xcp4*e1345+384*e2e1
*ammu*amuq*amel2*x3*x4*xcp4*e1245-336*e2e1*ammu*amuq*amel2*x3*x4*xcp4*e1235-384*e2e1*ammu*amuq*amel2*x3*x4*xcp4*e1234+144*e2e1*ammu*amuq*amel2*x3*x4*xcp3*e2345+240*e2e1*ammu*amuq*amel2*x3*x4*xcp3*e1345+384*e2e1*ammu*amuq*amel2*x3*x4*xcp3*e1245-432*
e2e1*ammu*amuq*amel2*x3*x4*xcp3*e1235-384*e2e1*ammu*amuq*amel2*x3*x4*xcp3*e1234-144*e2e1*ammu*amuq*amel2*x3*x4*xcp2*e2345-240*e2e1*ammu*amuq*amel2*x3*x4*xcp2*e1345-384*e2e1*ammu*amuq*amel2*x3*x4*xcp2*e1245+432*e2e1*ammu*amuq*amel2*x3*x4*xcp2*e1235+
384*e2e1*ammu*amuq*amel2*x3*x4*xcp2*e1234-48*e2e1*ammu*amuq*amel2*x3*x4*xcp1*e2345+912*e2e1*ammu*amuq*amel2*x3*x4*xcp1*e1345-384*e2e1*ammu*amuq*amel2*x3*x4*xcp1*e1245+336*e2e1*ammu*amuq*amel2*x3*x4*xcp1*e1235+384*e2e1*ammu*amuq*amel2*x3*x4*xcp1*
e1234+576*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp4*e2345+768*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp4*e1345-768*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp4*e1245-816*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp4*e1235-768*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp4*e1234-288*e2e1*ammu*
amuq*amel2*x3*x4*x6*xcp3*e2345-192*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp3*e1345-768*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp3*e1245+2304*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp3*e1235+768*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp3*e1234+288*e2e1*ammu*amuq*amel2*x3*x4*x6*
xcp2*e2345+192*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp2*e1345+768*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp2*e1245-2304*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp2*e1235-768*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp2*e1234-576*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp1*e2345-768*e2e1*
ammu*amuq*amel2*x3*x4*x6*xcp1*e1345+768*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp1*e1245+816*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp1*e1235+768*e2e1*ammu*amuq*amel2*x3*x4*x6*xcp1*e1234+672*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp4*e2345+672*e2e1*ammu*amuq*amel2*x3*x4*
x5*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp4*e1245-384*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp4*e1235-432*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp4*e1234-144*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp3*e2345-336*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp3*e1345-384*e2e1*
ammu*amuq*amel2*x3*x4*x5*xcp3*e1245+1008*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp3*e1235+432*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp3*e1234+144*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp2*e2345+336*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x3*x4*
x5*xcp2*e1245-1008*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp2*e1235-432*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp2*e1234-672*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp1*e2345-672*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp1*e1345+384*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp1*e1245+384*e2e1
*ammu*amuq*amel2*x3*x4*x5*xcp1*e1235+432*e2e1*ammu*amuq*amel2*x3*x4*x5*xcp1*e1234+288*e2e1*ammu*amuq*amel2*x3*x4^2*xcp4*e2345-48*e2e1*ammu*amuq*amel2*x3*x4^2*xcp4*e1235+144*e2e1*ammu*amuq*amel2*x3*x4^2*xcp3*e2345-48*e2e1*ammu*amuq*amel2*x3*x4^2*
xcp3*e1235-144*e2e1*ammu*amuq*amel2*x3*x4^2*xcp2*e2345+48*e2e1*ammu*amuq*amel2*x3*x4^2*xcp2*e1235-288*e2e1*ammu*amuq*amel2*x3*x4^2*xcp1*e2345+48*e2e1*ammu*amuq*amel2*x3*x4^2*xcp1*e1235-384*e2e1*ammu*amuq*amel2*x3^2*xcp4*e1345+192*e2e1*ammu*amuq*
amel2*x3^2*xcp4*e1245+624*e2e1*ammu*amuq*amel2*x3^2*xcp4*e1235+192*e2e1*ammu*amuq*amel2*x3^2*xcp4*e1234+96*e2e1*ammu*amuq*amel2*x3^2*xcp3*e2345+48*e2e1*ammu*amuq*amel2*x3^2*xcp3*e1345+192*e2e1*ammu*amuq*amel2*x3^2*xcp3*e1245-912*e2e1*ammu*amuq*
amel2*x3^2*xcp3*e1235-192*e2e1*ammu*amuq*amel2*x3^2*xcp3*e1234-96*e2e1*ammu*amuq*amel2*x3^2*xcp2*e2345-48*e2e1*ammu*amuq*amel2*x3^2*xcp2*e1345-192*e2e1*ammu*amuq*amel2*x3^2*xcp2*e1245+912*e2e1*ammu*amuq*amel2*x3^2*xcp2*e1235+192*e2e1*ammu*amuq*
amel2*x3^2*xcp2*e1234+384*e2e1*ammu*amuq*amel2*x3^2*xcp1*e1345-192*e2e1*ammu*amuq*amel2*x3^2*xcp1*e1245-624*e2e1*ammu*amuq*amel2*x3^2*xcp1*e1235-192*e2e1*ammu*amuq*amel2*x3^2*xcp1*e1234+96*e2e1*ammu*amuq*amel2*x3^2*x6*xcp4*e2345+192*e2e1*ammu*amuq*
amel2*x3^2*x6*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x3^2*x6*xcp4*e1245-384*e2e1*ammu*amuq*amel2*x3^2*x6*xcp4*e1235-384*e2e1*ammu*amuq*amel2*x3^2*x6*xcp4*e1234+48*e2e1*ammu*amuq*amel2*x3^2*x6*xcp3*e2345+96*e2e1*ammu*amuq*amel2*x3^2*x6*xcp3*e1345-384*
e2e1*ammu*amuq*amel2*x3^2*x6*xcp3*e1245+1152*e2e1*ammu*amuq*amel2*x3^2*x6*xcp3*e1235+384*e2e1*ammu*amuq*amel2*x3^2*x6*xcp3*e1234-48*e2e1*ammu*amuq*amel2*x3^2*x6*xcp2*e2345-96*e2e1*ammu*amuq*amel2*x3^2*x6*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x3^2*x6*
xcp2*e1245-1152*e2e1*ammu*amuq*amel2*x3^2*x6*xcp2*e1235-384*e2e1*ammu*amuq*amel2*x3^2*x6*xcp2*e1234-96*e2e1*ammu*amuq*amel2*x3^2*x6*xcp1*e2345-192*e2e1*ammu*amuq*amel2*x3^2*x6*xcp1*e1345+384*e2e1*ammu*amuq*amel2*x3^2*x6*xcp1*e1245+384*e2e1*ammu*
amuq*amel2*x3^2*x6*xcp1*e1235+384*e2e1*ammu*amuq*amel2*x3^2*x6*xcp1*e1234+96*e2e1*ammu*amuq*amel2*x3^2*x5*xcp4*e2345+192*e2e1*ammu*amuq*amel2*x3^2*x5*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x3^2*x5*xcp4*e1245-384*e2e1*ammu*amuq*amel2*x3^2*x5*xcp4*e1235
-432*e2e1*ammu*amuq*amel2*x3^2*x5*xcp4*e1234+48*e2e1*ammu*amuq*amel2*x3^2*x5*xcp3*e2345+96*e2e1*ammu*amuq*amel2*x3^2*x5*xcp3*e1345-384*e2e1*ammu*amuq*amel2*x3^2*x5*xcp3*e1245+1152*e2e1*ammu*amuq*amel2*x3^2*x5*xcp3*e1235+432*e2e1*ammu*amuq*amel2*
x3^2*x5*xcp3*e1234-48*e2e1*ammu*amuq*amel2*x3^2*x5*xcp2*e2345-96*e2e1*ammu*amuq*amel2*x3^2*x5*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x3^2*x5*xcp2*e1245-1152*e2e1*ammu*amuq*amel2*x3^2*x5*xcp2*e1235-432*e2e1*ammu*amuq*amel2*x3^2*x5*xcp2*e1234-96*e2e1*
ammu*amuq*amel2*x3^2*x5*xcp1*e2345-192*e2e1*ammu*amuq*amel2*x3^2*x5*xcp1*e1345+384*e2e1*ammu*amuq*amel2*x3^2*x5*xcp1*e1245+384*e2e1*ammu*amuq*amel2*x3^2*x5*xcp1*e1235+432*e2e1*ammu*amuq*amel2*x3^2*x5*xcp1*e1234+288*e2e1*ammu*amuq*amel2*x3^2*x4*xcp4
*e2345-48*e2e1*ammu*amuq*amel2*x3^2*x4*xcp4*e1235+144*e2e1*ammu*amuq*amel2*x3^2*x4*xcp3*e2345-144*e2e1*ammu*amuq*amel2*x3^2*x4*xcp2*e2345-288*e2e1*ammu*amuq*amel2*x3^2*x4*xcp1*e2345+48*e2e1*ammu*amuq*amel2*x3^2*x4*xcp1*e1235+96*e2e1*ammu*amuq*amel2
*x3^3*xcp4*e2345+48*e2e1*ammu*amuq*amel2*x3^3*xcp3*e2345-48*e2e1*ammu*amuq*amel2*x3^3*xcp2*e2345-96*e2e1*ammu*amuq*amel2*x3^3*xcp1*e2345-48*e2e1*ammu*amuq*amel2*x1*xcp4*e2345-336*e2e1*ammu*amuq*amel2*x1*xcp4*e1345+1344*e2e1*ammu*amuq*amel2*x1*xcp4*
e1235+1536*e2e1*ammu*amuq*amel2*x1*xcp4*e1234-96*e2e1*ammu*amuq*amel2*x1*xcp3*e2345+144*e2e1*ammu*amuq*amel2*x1*xcp3*e1345+1488*e2e1*ammu*amuq*amel2*x1*xcp3*e1235+96*e2e1*ammu*amuq*amel2*x1*xcp2*e2345-144*e2e1*ammu*amuq*amel2*x1*xcp2*e1345-1488*
e2e1*ammu*amuq*amel2*x1*xcp2*e1235+48*e2e1*ammu*amuq*amel2*x1*xcp1*e2345+336*e2e1*ammu*amuq*amel2*x1*xcp1*e1345-1344*e2e1*ammu*amuq*amel2*x1*xcp1*e1235-1536*e2e1*ammu*amuq*amel2*x1*xcp1*e1234-288*e2e1*ammu*amuq*amel2*x1*x6*xcp4*e2345-192*e2e1*ammu*
amuq*amel2*x1*x6*xcp4*e1345+384*e2e1*ammu*amuq*amel2*x1*x6*xcp4*e1245-480*e2e1*ammu*amuq*amel2*x1*x6*xcp4*e1235+384*e2e1*ammu*amuq*amel2*x1*x6*xcp4*e1234+192*e2e1*ammu*amuq*amel2*x1*x6*xcp3*e2345+432*e2e1*ammu*amuq*amel2*x1*x6*xcp3*e1345+384*e2e1*
ammu*amuq*amel2*x1*x6*xcp3*e1245-384*e2e1*ammu*amuq*amel2*x1*x6*xcp3*e1235-384*e2e1*ammu*amuq*amel2*x1*x6*xcp3*e1234-192*e2e1*ammu*amuq*amel2*x1*x6*xcp2*e2345-432*e2e1*ammu*amuq*amel2*x1*x6*xcp2*e1345-384*e2e1*ammu*amuq*amel2*x1*x6*xcp2*e1245+384*
e2e1*ammu*amuq*amel2*x1*x6*xcp2*e1235+384*e2e1*ammu*amuq*amel2*x1*x6*xcp2*e1234+288*e2e1*ammu*amuq*amel2*x1*x6*xcp1*e2345+192*e2e1*ammu*amuq*amel2*x1*x6*xcp1*e1345-384*e2e1*ammu*amuq*amel2*x1*x6*xcp1*e1245+480*e2e1*ammu*amuq*amel2*x1*x6*xcp1*e1235-
384*e2e1*ammu*amuq*amel2*x1*x6*xcp1*e1234+192*e2e1*ammu*amuq*amel2*x1*x6^2*xcp4*e2345-96*e2e1*ammu*amuq*amel2*x1*x6^2*xcp4*e1345+96*e2e1*ammu*amuq*amel2*x1*x6^2*xcp3*e2345-48*e2e1*ammu*amuq*amel2*x1*x6^2*xcp3*e1345-96*e2e1*ammu*amuq*amel2*x1*x6^2*
xcp2*e2345+48*e2e1*ammu*amuq*amel2*x1*x6^2*xcp2*e1345-192*e2e1*ammu*amuq*amel2*x1*x6^2*xcp1*e2345+96*e2e1*ammu*amuq*amel2*x1*x6^2*xcp1*e1345-144*e2e1*ammu*amuq*amel2*x1*x5*xcp4*e2345+336*e2e1*ammu*amuq*amel2*x1*x5*xcp4*e1345+384*e2e1*ammu*amuq*
amel2*x1*x5*xcp4*e1245-480*e2e1*ammu*amuq*amel2*x1*x5*xcp4*e1235-96*e2e1*ammu*amuq*amel2*x1*x5*xcp4*e1234+336*e2e1*ammu*amuq*amel2*x1*x5*xcp3*e2345-192*e2e1*ammu*amuq*amel2*x1*x5*xcp3*e1345+384*e2e1*ammu*amuq*amel2*x1*x5*xcp3*e1245-384*e2e1*ammu*
amuq*amel2*x1*x5*xcp3*e1235+48*e2e1*ammu*amuq*amel2*x1*x5*xcp3*e1234-336*e2e1*ammu*amuq*amel2*x1*x5*xcp2*e2345+192*e2e1*ammu*amuq*amel2*x1*x5*xcp2*e1345-384*e2e1*ammu*amuq*amel2*x1*x5*xcp2*e1245+384*e2e1*ammu*amuq*amel2*x1*x5*xcp2*e1235-48*e2e1*
ammu*amuq*amel2*x1*x5*xcp2*e1234+144*e2e1*ammu*amuq*amel2*x1*x5*xcp1*e2345-336*e2e1*ammu*amuq*amel2*x1*x5*xcp1*e1345-384*e2e1*ammu*amuq*amel2*x1*x5*xcp1*e1245+480*e2e1*ammu*amuq*amel2*x1*x5*xcp1*e1235+96*e2e1*ammu*amuq*amel2*x1*x5*xcp1*e1234+384*
e2e1*ammu*amuq*amel2*x1*x5*x6*xcp4*e2345-192*e2e1*ammu*amuq*amel2*x1*x5*x6*xcp4*e1345+192*e2e1*ammu*amuq*amel2*x1*x5*x6*xcp4*e1234+192*e2e1*ammu*amuq*amel2*x1*x5*x6*xcp3*e2345-96*e2e1*ammu*amuq*amel2*x1*x5*x6*xcp3*e1345+96*e2e1*ammu*amuq*amel2*x1*
x5*x6*xcp3*e1234-192*e2e1*ammu*amuq*amel2*x1*x5*x6*xcp2*e2345+96*e2e1*ammu*amuq*amel2*x1*x5*x6*xcp2*e1345-96*e2e1*ammu*amuq*amel2*x1*x5*x6*xcp2*e1234-384*e2e1*ammu*amuq*amel2*x1*x5*x6*xcp1*e2345+192*e2e1*ammu*amuq*amel2*x1*x5*x6*xcp1*e1345-192*e2e1
*ammu*amuq*amel2*x1*x5*x6*xcp1*e1234+192*e2e1*ammu*amuq*amel2*x1*x5^2*xcp4*e2345-96*e2e1*ammu*amuq*amel2*x1*x5^2*xcp4*e1345+144*e2e1*ammu*amuq*amel2*x1*x5^2*xcp4*e1234+96*e2e1*ammu*amuq*amel2*x1*x5^2*xcp3*e2345-48*e2e1*ammu*amuq*amel2*x1*x5^2*xcp3*
e1345+240*e2e1*ammu*amuq*amel2*x1*x5^2*xcp3*e1234-96*e2e1*ammu*amuq*amel2*x1*x5^2*xcp2*e2345+48*e2e1*ammu*amuq*amel2*x1*x5^2*xcp2*e1345-240*e2e1*ammu*amuq*amel2*x1*x5^2*xcp2*e1234-192*e2e1*ammu*amuq*amel2*x1*x5^2*xcp1*e2345+96*e2e1*ammu*amuq*amel2*
x1*x5^2*xcp1*e1345-144*e2e1*ammu*amuq*amel2*x1*x5^2*xcp1*e1234-576*e2e1*ammu*amuq*amel2*x1*x4*xcp4*e2345-96*e2e1*ammu*amuq*amel2*x1*x4*xcp4*e1345-1248*e2e1*ammu*amuq*amel2*x1*x4*xcp4*e1235-768*e2e1*ammu*amuq*amel2*x1*x4*xcp4*e1234+528*e2e1*ammu*
amuq*amel2*x1*x4*xcp3*e2345+96*e2e1*ammu*amuq*amel2*x1*x4*xcp3*e1345-336*e2e1*ammu*amuq*amel2*x1*x4*xcp3*e1235-528*e2e1*ammu*amuq*amel2*x1*x4*xcp2*e2345-96*e2e1*ammu*amuq*amel2*x1*x4*xcp2*e1345+336*e2e1*ammu*amuq*amel2*x1*x4*xcp2*e1235+576*e2e1*
ammu*amuq*amel2*x1*x4*xcp1*e2345+96*e2e1*ammu*amuq*amel2*x1*x4*xcp1*e1345+1248*e2e1*ammu*amuq*amel2*x1*x4*xcp1*e1235+768*e2e1*ammu*amuq*amel2*x1*x4*xcp1*e1234-384*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp4*e2345-192*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp4*e1345
-768*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp4*e1245-576*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp4*e1235-768*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp4*e1234-384*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp3*e2345-288*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp3*e1345-768*e2e1*ammu*amuq*
amel2*x1*x4*x6*xcp3*e1245+2304*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp3*e1235+768*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp3*e1234+384*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp2*e2345+288*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp2*e1345+768*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp2*
e1245-2304*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp2*e1235-768*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp2*e1234+384*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp1*e2345+192*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp1*e1345+768*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp1*e1245+576*e2e1*ammu*
amuq*amel2*x1*x4*x6*xcp1*e1235+768*e2e1*ammu*amuq*amel2*x1*x4*x6*xcp1*e1234+192*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp4*e1245-240*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp4*e1235-480*e2e1*ammu*amuq*amel2*x1*x4*x5*
xcp4*e1234-1488*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp3*e2345-1488*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp3*e1345-384*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp3*e1245+1296*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp3*e1235+336*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp3*e1234+1488*e2e1
*ammu*amuq*amel2*x1*x4*x5*xcp2*e2345+1488*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp2*e1245-1296*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp2*e1235-336*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp2*e1234-192*e2e1*ammu*amuq*amel2*x1*
x4*x5*xcp1*e1345+384*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp1*e1245+240*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp1*e1235+480*e2e1*ammu*amuq*amel2*x1*x4*x5*xcp1*e1234+384*e2e1*ammu*amuq*amel2*x1*x4^2*xcp4*e2345+480*e2e1*ammu*amuq*amel2*x1*x4^2*xcp4*e1345-384*e2e1
*ammu*amuq*amel2*x1*x4^2*xcp4*e1245-480*e2e1*ammu*amuq*amel2*x1*x4^2*xcp4*e1235-384*e2e1*ammu*amuq*amel2*x1*x4^2*xcp4*e1234-384*e2e1*ammu*amuq*amel2*x1*x4^2*xcp3*e2345-336*e2e1*ammu*amuq*amel2*x1*x4^2*xcp3*e1345-384*e2e1*ammu*amuq*amel2*x1*x4^2*
xcp3*e1245+1200*e2e1*ammu*amuq*amel2*x1*x4^2*xcp3*e1235+384*e2e1*ammu*amuq*amel2*x1*x4^2*xcp3*e1234+384*e2e1*ammu*amuq*amel2*x1*x4^2*xcp2*e2345+336*e2e1*ammu*amuq*amel2*x1*x4^2*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x1*x4^2*xcp2*e1245-1200*e2e1*ammu*
amuq*amel2*x1*x4^2*xcp2*e1235-384*e2e1*ammu*amuq*amel2*x1*x4^2*xcp2*e1234-384*e2e1*ammu*amuq*amel2*x1*x4^2*xcp1*e2345-480*e2e1*ammu*amuq*amel2*x1*x4^2*xcp1*e1345+384*e2e1*ammu*amuq*amel2*x1*x4^2*xcp1*e1245+480*e2e1*ammu*amuq*amel2*x1*x4^2*xcp1*
e1235+384*e2e1*ammu*amuq*amel2*x1*x4^2*xcp1*e1234-432*e2e1*ammu*amuq*amel2*x1*x3*xcp4*e2345-144*e2e1*ammu*amuq*amel2*x1*x3*xcp4*e1345+384*e2e1*ammu*amuq*amel2*x1*x3*xcp3*e2345+144*e2e1*ammu*amuq*amel2*x1*x3*xcp3*e1345-48*e2e1*ammu*amuq*amel2*x1*x3*
xcp3*e1235-384*e2e1*ammu*amuq*amel2*x1*x3*xcp2*e2345-144*e2e1*ammu*amuq*amel2*x1*x3*xcp2*e1345+48*e2e1*ammu*amuq*amel2*x1*x3*xcp2*e1235+432*e2e1*ammu*amuq*amel2*x1*x3*xcp1*e2345+144*e2e1*ammu*amuq*amel2*x1*x3*xcp1*e1345-384*e2e1*ammu*amuq*amel2*x1*
x3*x6*xcp4*e2345-192*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp4*e1345-768*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp4*e1245-768*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp4*e1235-768*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp4*e1234-384*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp3*e2345-288*
e2e1*ammu*amuq*amel2*x1*x3*x6*xcp3*e1345-768*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp3*e1245+2304*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp3*e1235+768*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp3*e1234+384*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp2*e2345+288*e2e1*ammu*amuq*amel2*
x1*x3*x6*xcp2*e1345+768*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp2*e1245-2304*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp2*e1235-768*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp2*e1234+384*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp1*e2345+192*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp1*e1345+
768*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp1*e1245+768*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp1*e1235+768*e2e1*ammu*amuq*amel2*x1*x3*x6*xcp1*e1234+192*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp4*e1345-768*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp4*e1245-768*e2e1*ammu*amuq*
amel2*x1*x3*x5*xcp4*e1235-816*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp4*e1234-1536*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp3*e2345-1440*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp3*e1345-768*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp3*e1245+2304*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp3*
e1235+672*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp3*e1234+1536*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp2*e2345+1440*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp2*e1345+768*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp2*e1245-2304*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp2*e1235-672*e2e1*ammu*
amuq*amel2*x1*x3*x5*xcp2*e1234-192*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp1*e1345+768*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp1*e1245+768*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp1*e1235+816*e2e1*ammu*amuq*amel2*x1*x3*x5*xcp1*e1234+384*e2e1*ammu*amuq*amel2*x1*x3*x4*
xcp4*e2345+576*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp4*e1345-768*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp4*e1245-816*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp4*e1235-768*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp4*e1234-384*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp3*e2345-288*e2e1*
ammu*amuq*amel2*x1*x3*x4*xcp3*e1345-768*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp3*e1245+2304*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp3*e1235+768*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp3*e1234+384*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp2*e2345+288*e2e1*ammu*amuq*amel2*x1*x3*
x4*xcp2*e1345+768*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp2*e1245-2304*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp2*e1235-768*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp2*e1234-384*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp1*e2345-576*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp1*e1345+768*e2e1
*ammu*amuq*amel2*x1*x3*x4*xcp1*e1245+816*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp1*e1235+768*e2e1*ammu*amuq*amel2*x1*x3*x4*xcp1*e1234+96*e2e1*ammu*amuq*amel2*x1*x3^2*xcp4*e1345-384*e2e1*ammu*amuq*amel2*x1*x3^2*xcp4*e1245-384*e2e1*ammu*amuq*amel2*x1*x3^2*
xcp4*e1235-384*e2e1*ammu*amuq*amel2*x1*x3^2*xcp4*e1234+48*e2e1*ammu*amuq*amel2*x1*x3^2*xcp3*e1345-384*e2e1*ammu*amuq*amel2*x1*x3^2*xcp3*e1245+1152*e2e1*ammu*amuq*amel2*x1*x3^2*xcp3*e1235+384*e2e1*ammu*amuq*amel2*x1*x3^2*xcp3*e1234-48*e2e1*ammu*amuq
*amel2*x1*x3^2*xcp2*e1345+384*e2e1*ammu*amuq*amel2*x1*x3^2*xcp2*e1245-1152*e2e1*ammu*amuq*amel2*x1*x3^2*xcp2*e1235-384*e2e1*ammu*amuq*amel2*x1*x3^2*xcp2*e1234-96*e2e1*ammu*amuq*amel2*x1*x3^2*xcp1*e1345+384*e2e1*ammu*amuq*amel2*x1*x3^2*xcp1*e1245+
384*e2e1*ammu*amuq*amel2*x1*x3^2*xcp1*e1235+384*e2e1*ammu*amuq*amel2*x1*x3^2*xcp1*e1234-144*e2e1*ammu*amuq*amel2*x1^2*xcp4*e2345-48*e2e1*ammu*amuq*amel2*x1^2*xcp4*e1345+192*e2e1*ammu*amuq*amel2*x1^2*xcp4*e1245-240*e2e1*ammu*amuq*amel2*x1^2*xcp4*
e1235+192*e2e1*ammu*amuq*amel2*x1^2*xcp4*e1234+48*e2e1*ammu*amuq*amel2*x1^2*xcp3*e2345+336*e2e1*ammu*amuq*amel2*x1^2*xcp3*e1345+192*e2e1*ammu*amuq*amel2*x1^2*xcp3*e1245-192*e2e1*ammu*amuq*amel2*x1^2*xcp3*e1235-192*e2e1*ammu*amuq*amel2*x1^2*xcp3*
e1234-48*e2e1*ammu*amuq*amel2*x1^2*xcp2*e2345-336*e2e1*ammu*amuq*amel2*x1^2*xcp2*e1345-192*e2e1*ammu*amuq*amel2*x1^2*xcp2*e1245+192*e2e1*ammu*amuq*amel2*x1^2*xcp2*e1235+192*e2e1*ammu*amuq*amel2*x1^2*xcp2*e1234+144*e2e1*ammu*amuq*amel2*x1^2*xcp1*
e2345+48*e2e1*ammu*amuq*amel2*x1^2*xcp1*e1345-192*e2e1*ammu*amuq*amel2*x1^2*xcp1*e1245+240*e2e1*ammu*amuq*amel2*x1^2*xcp1*e1235-192*e2e1*ammu*amuq*amel2*x1^2*xcp1*e1234+96*e2e1*ammu*amuq*amel2*x1^2*x6*xcp4*e2345-192*e2e1*ammu*amuq*amel2*x1^2*x6*
xcp4*e1345+48*e2e1*ammu*amuq*amel2*x1^2*x6*xcp3*e2345-96*e2e1*ammu*amuq*amel2*x1^2*x6*xcp3*e1345-48*e2e1*ammu*amuq*amel2*x1^2*x6*xcp2*e2345+96*e2e1*ammu*amuq*amel2*x1^2*x6*xcp2*e1345-96*e2e1*ammu*amuq*amel2*x1^2*x6*xcp1*e2345+192*e2e1*ammu*amuq*
amel2*x1^2*x6*xcp1*e1345+96*e2e1*ammu*amuq*amel2*x1^2*x5*xcp4*e2345-192*e2e1*ammu*amuq*amel2*x1^2*x5*xcp4*e1345+96*e2e1*ammu*amuq*amel2*x1^2*x5*xcp4*e1234+48*e2e1*ammu*amuq*amel2*x1^2*x5*xcp3*e2345-96*e2e1*ammu*amuq*amel2*x1^2*x5*xcp3*e1345+48*e2e1
*ammu*amuq*amel2*x1^2*x5*xcp3*e1234-48*e2e1*ammu*amuq*amel2*x1^2*x5*xcp2*e2345+96*e2e1*ammu*amuq*amel2*x1^2*x5*xcp2*e1345-48*e2e1*ammu*amuq*amel2*x1^2*x5*xcp2*e1234-96*e2e1*ammu*amuq*amel2*x1^2*x5*xcp1*e2345+192*e2e1*ammu*amuq*amel2*x1^2*x5*xcp1*
e1345-96*e2e1*ammu*amuq*amel2*x1^2*x5*xcp1*e1234-96*e2e1*ammu*amuq*amel2*x1^2*x4*xcp4*e2345-384*e2e1*ammu*amuq*amel2*x1^2*x4*xcp4*e1245-288*e2e1*ammu*amuq*amel2*x1^2*x4*xcp4*e1235-384*e2e1*ammu*amuq*amel2*x1^2*x4*xcp4*e1234-48*e2e1*ammu*amuq*amel2*
x1^2*x4*xcp3*e2345-384*e2e1*ammu*amuq*amel2*x1^2*x4*xcp3*e1245+1152*e2e1*ammu*amuq*amel2*x1^2*x4*xcp3*e1235+384*e2e1*ammu*amuq*amel2*x1^2*x4*xcp3*e1234+48*e2e1*ammu*amuq*amel2*x1^2*x4*xcp2*e2345+384*e2e1*ammu*amuq*amel2*x1^2*x4*xcp2*e1245-1152*e2e1
*ammu*amuq*amel2*x1^2*x4*xcp2*e1235-384*e2e1*ammu*amuq*amel2*x1^2*x4*xcp2*e1234+96*e2e1*ammu*amuq*amel2*x1^2*x4*xcp1*e2345+384*e2e1*ammu*amuq*amel2*x1^2*x4*xcp1*e1245+288*e2e1*ammu*amuq*amel2*x1^2*x4*xcp1*e1235+384*e2e1*ammu*amuq*amel2*x1^2*x4*xcp1
*e1234-96*e2e1*ammu*amuq*amel2*x1^2*x3*xcp4*e2345-384*e2e1*ammu*amuq*amel2*x1^2*x3*xcp4*e1245-384*e2e1*ammu*amuq*amel2*x1^2*x3*xcp4*e1235-384*e2e1*ammu*amuq*amel2*x1^2*x3*xcp4*e1234-48*e2e1*ammu*amuq*amel2*x1^2*x3*xcp3*e2345-384*e2e1*ammu*amuq*
amel2*x1^2*x3*xcp3*e1245+1152*e2e1*ammu*amuq*amel2*x1^2*x3*xcp3*e1235+384*e2e1*ammu*amuq*amel2*x1^2*x3*xcp3*e1234+48*e2e1*ammu*amuq*amel2*x1^2*x3*xcp2*e2345+384*e2e1*ammu*amuq*amel2*x1^2*x3*xcp2*e1245-1152*e2e1*ammu*amuq*amel2*x1^2*x3*xcp2*e1235-
384*e2e1*ammu*amuq*amel2*x1^2*x3*xcp2*e1234+96*e2e1*ammu*amuq*amel2*x1^2*x3*xcp1*e2345+384*e2e1*ammu*amuq*amel2*x1^2*x3*xcp1*e1245+384*e2e1*ammu*amuq*amel2*x1^2*x3*xcp1*e1235+384*e2e1*ammu*amuq*amel2*x1^2*x3*xcp1*e1234-96*e2e1*ammu*amuq*amel2*x1^3*
xcp4*e1345-48*e2e1*ammu*amuq*amel2*x1^3*xcp3*e1345+48*e2e1*ammu*amuq*amel2*x1^3*xcp2*e1345+96*e2e1*ammu*amuq*amel2*x1^3*xcp1*e1345-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x6*xcp4-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x6*xcp3-384*e2e1*ammu*amuq*amel2*
ammu2*amuq2*x6*xcp2-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x6*xcp1+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x6^2*xcp4+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x6^2*xcp3+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x6^2*xcp2+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x6^2*
xcp1+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x5*x6*xcp4+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x5*x6*xcp3+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x5*x6*xcp2+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x5*x6*xcp1-1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*xcp4+384*
e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*xcp3+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*xcp2-1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*xcp1+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x6*xcp4-1920*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x6*xcp3-1920*e2e1*ammu*amuq
*amel2*ammu2*amuq2*x4*x6*xcp2+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x6*xcp1-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x6^2*xcp4+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x6^2*xcp3+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x6^2*xcp2-384*e2e1*ammu*amuq*
amel2*ammu2*amuq2*x4*x6^2*xcp1+1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x5*xcp4-1920*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x5*xcp3-1920*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x5*xcp2+1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x5*xcp1-1152*e2e1*ammu*amuq*
amel2*ammu2*amuq2*x4*x5*x6*xcp4+1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x5*x6*xcp3+1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x5*x6*xcp2-1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x5*x6*xcp1-768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x5^2*xcp4+768*e2e1*
ammu*amuq*amel2*ammu2*amuq2*x4*x5^2*xcp3+768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x5^2*xcp2-768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4*x5^2*xcp1+1536*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^2*xcp4+768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^2*xcp3+768*e2e1*
ammu*amuq*amel2*ammu2*amuq2*x4^2*xcp2+1536*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^2*xcp1+768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^2*x6*xcp3+768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^2*x6*xcp2-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^2*x5*xcp4+384*e2e1*
ammu*amuq*amel2*ammu2*amuq2*x4^2*x5*xcp3+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^2*x5*xcp2-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^2*x5*xcp1-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^3*xcp4-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^3*xcp3-384*e2e1*ammu
*amuq*amel2*ammu2*amuq2*x4^3*xcp2-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x4^3*xcp1-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x6*xcp4-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x6*xcp3-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x6*xcp2-384*e2e1*ammu*amuq*
amel2*ammu2*amuq2*x3*x6*xcp1-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4*xcp4+1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4*xcp3+1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4*xcp2-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4*xcp1+384*e2e1*ammu*amuq*amel2*
ammu2*amuq2*x3*x4*x6*xcp4-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4*x6*xcp3-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4*x6*xcp2+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4*x6*xcp1+768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4*x5*xcp4-768*e2e1*ammu*amuq
*amel2*ammu2*amuq2*x3*x4*x5*xcp3-768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4*x5*xcp2+768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4*x5*xcp1+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4^2*xcp4-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4^2*xcp3-384*e2e1*ammu
*amuq*amel2*ammu2*amuq2*x3*x4^2*xcp2+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x3*x4^2*xcp1+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x6*xcp4+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x6*xcp3+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x6*xcp2+384*e2e1*ammu*
amuq*amel2*ammu2*amuq2*x1*x6*xcp1+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4*xcp4-1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4*xcp3-1152*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4*xcp2+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4*xcp1-384*e2e1*ammu*amuq*
amel2*ammu2*amuq2*x1*x4*x6*xcp4+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4*x6*xcp3+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4*x6*xcp2-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4*x6*xcp1-768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4*x5*xcp4+768*e2e1*
ammu*amuq*amel2*ammu2*amuq2*x1*x4*x5*xcp3+768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4*x5*xcp2-768*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4*x5*xcp1-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4^2*xcp4+384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4^2*xcp3+384*
e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4^2*xcp2-384*e2e1*ammu*amuq*amel2*ammu2*amuq2*x1*x4^2*xcp1-7680*e2e1*ammu*amuq*amel2*ammu2^2*x6*xcp4-1536*e2e1*ammu*amuq*amel2*ammu2^2*x6*xcp3-1536*e2e1*ammu*amuq*amel2*ammu2^2*x6*xcp2-7680*e2e1*ammu*amuq*amel2*
ammu2^2*x6*xcp1+6528*e2e1*ammu*amuq*amel2*ammu2^2*x6^2*xcp4-768*e2e1*ammu*amuq*amel2*ammu2^2*x6^2*xcp3-768*e2e1*ammu*amuq*amel2*ammu2^2*x6^2*xcp2+6528*e2e1*ammu*amuq*amel2*ammu2^2*x6^2*xcp1-1152*e2e1*ammu*amuq*amel2*ammu2^2*x6^3*xcp4+768*e2e1*ammu*
amuq*amel2*ammu2^2*x6^3*xcp3+768*e2e1*ammu*amuq*amel2*ammu2^2*x6^3*xcp2-1152*e2e1*ammu*amuq*amel2*ammu2^2*x6^3*xcp1-8832*e2e1*ammu*amuq*amel2*ammu2^2*x5*xcp4-1152*e2e1*ammu*amuq*amel2*ammu2^2*x5*xcp3-1152*e2e1*ammu*amuq*amel2*ammu2^2*x5*xcp2-8832*
e2e1*ammu*amuq*amel2*ammu2^2*x5*xcp1+16512*e2e1*ammu*amuq*amel2*ammu2^2*x5*x6*xcp4-3456*e2e1*ammu*amuq*amel2*ammu2^2*x5*x6*xcp3-3456*e2e1*ammu*amuq*amel2*ammu2^2*x5*x6*xcp2+16512*e2e1*ammu*amuq*amel2*ammu2^2*x5*x6*xcp1-5760*e2e1*ammu*amuq*amel2*
ammu2^2*x5*x6^2*xcp4+3072*e2e1*ammu*amuq*amel2*ammu2^2*x5*x6^2*xcp3+3072*e2e1*ammu*amuq*amel2*ammu2^2*x5*x6^2*xcp2-5760*e2e1*ammu*amuq*amel2*ammu2^2*x5*x6^2*xcp1+11520*e2e1*ammu*amuq*amel2*ammu2^2*x5^2*xcp4-3072*e2e1*ammu*amuq*amel2*ammu2^2*x5^2*
xcp3-3072*e2e1*ammu*amuq*amel2*ammu2^2*x5^2*xcp2+11520*e2e1*ammu*amuq*amel2*ammu2^2*x5^2*xcp1-8064*e2e1*ammu*amuq*amel2*ammu2^2*x5^2*x6*xcp4+4992*e2e1*ammu*amuq*amel2*ammu2^2*x5^2*x6*xcp3+4992*e2e1*ammu*amuq*amel2*ammu2^2*x5^2*x6*xcp2-8064*e2e1*
ammu*amuq*amel2*ammu2^2*x5^2*x6*xcp1-4224*e2e1*ammu*amuq*amel2*ammu2^2*x5^3*xcp4+2688*e2e1*ammu*amuq*amel2*ammu2^2*x5^3*xcp3+2688*e2e1*ammu*amuq*amel2*ammu2^2*x5^3*xcp2-4224*e2e1*ammu*amuq*amel2*ammu2^2*x5^3*xcp1+384*e2e1*ammu*amuq*amel2*ammu2^2*x4
*xcp4+384*e2e1*ammu*amuq*amel2*ammu2^2*x4*xcp3+384*e2e1*ammu*amuq*amel2*ammu2^2*x4*xcp2+384*e2e1*ammu*amuq*amel2*ammu2^2*x4*xcp1+4992*e2e1*ammu*amuq*amel2*ammu2^2*x4*x6*xcp4-384*e2e1*ammu*amuq*amel2*ammu2^2*x4*x6*xcp3-384*e2e1*ammu*amuq*amel2*
ammu2^2*x4*x6*xcp2+4992*e2e1*ammu*amuq*amel2*ammu2^2*x4*x6*xcp1-1152*e2e1*ammu*amuq*amel2*ammu2^2*x4*x6^2*xcp4-768*e2e1*ammu*amuq*amel2*ammu2^2*x4*x6^2*xcp3-768*e2e1*ammu*amuq*amel2*ammu2^2*x4*x6^2*xcp2-1152*e2e1*ammu*amuq*amel2*ammu2^2*x4*x6^2*
xcp1+8064*e2e1*ammu*amuq*amel2*ammu2^2*x4*x5*xcp4-384*e2e1*ammu*amuq*amel2*ammu2^2*x4*x5*xcp3-384*e2e1*ammu*amuq*amel2*ammu2^2*x4*x5*xcp2+8064*e2e1*ammu*amuq*amel2*ammu2^2*x4*x5*xcp1-4224*e2e1*ammu*amuq*amel2*ammu2^2*x4*x5*x6*xcp4+1920*e2e1*ammu*
amuq*amel2*ammu2^2*x4*x5*x6*xcp3+1920*e2e1*ammu*amuq*amel2*ammu2^2*x4*x5*x6*xcp2-4224*e2e1*ammu*amuq*amel2*ammu2^2*x4*x5*x6*xcp1-5376*e2e1*ammu*amuq*amel2*ammu2^2*x4*x5^2*xcp4+2304*e2e1*ammu*amuq*amel2*ammu2^2*x4*x5^2*xcp3+2304*e2e1*ammu*amuq*amel2
*ammu2^2*x4*x5^2*xcp2-5376*e2e1*ammu*amuq*amel2*ammu2^2*x4*x5^2*xcp1+768*e2e1*ammu*amuq*amel2*ammu2^2*x4^2*xcp4-384*e2e1*ammu*amuq*amel2*ammu2^2*x4^2*xcp3-384*e2e1*ammu*amuq*amel2*ammu2^2*x4^2*xcp2+768*e2e1*ammu*amuq*amel2*ammu2^2*x4^2*xcp1-1152*
e2e1*ammu*amuq*amel2*ammu2^2*x4^2*x6*xcp4+768*e2e1*ammu*amuq*amel2*ammu2^2*x4^2*x6*xcp3+768*e2e1*ammu*amuq*amel2*ammu2^2*x4^2*x6*xcp2-1152*e2e1*ammu*amuq*amel2*ammu2^2*x4^2*x6*xcp1-3072*e2e1*ammu*amuq*amel2*ammu2^2*x4^2*x5*xcp4+384*e2e1*ammu*amuq*
amel2*ammu2^2*x4^2*x5*xcp3+384*e2e1*ammu*amuq*amel2*ammu2^2*x4^2*x5*xcp2-3072*e2e1*ammu*amuq*amel2*ammu2^2*x4^2*x5*xcp1-384*e2e1*ammu*amuq*amel2*ammu2^2*x4^3*xcp4-384*e2e1*ammu*amuq*amel2*ammu2^2*x4^3*xcp1-1920*e2e1*ammu*amuq*amel2*ammu2^2*x3*x6*
xcp4-1152*e2e1*ammu*amuq*amel2*ammu2^2*x3*x6*xcp3-1152*e2e1*ammu*amuq*amel2*ammu2^2*x3*x6*xcp2-1920*e2e1*ammu*amuq*amel2*ammu2^2*x3*x6*xcp1+768*e2e1*ammu*amuq*amel2*ammu2^2*x3*x6^2*xcp4+384*e2e1*ammu*amuq*amel2*ammu2^2*x3*x6^2*xcp3+384*e2e1*ammu*
amuq*amel2*ammu2^2*x3*x6^2*xcp2+768*e2e1*ammu*amuq*amel2*ammu2^2*x3*x6^2*xcp1-1536*e2e1*ammu*amuq*amel2*ammu2^2*x3*x5*xcp4-768*e2e1*ammu*amuq*amel2*ammu2^2*x3*x5*xcp3-768*e2e1*ammu*amuq*amel2*ammu2^2*x3*x5*xcp2-1536*e2e1*ammu*amuq*amel2*ammu2^2*x3*
x5*xcp1+2304*e2e1*ammu*amuq*amel2*ammu2^2*x3*x5*x6*xcp4+768*e2e1*ammu*amuq*amel2*ammu2^2*x3*x5*x6*xcp3+768*e2e1*ammu*amuq*amel2*ammu2^2*x3*x5*x6*xcp2+2304*e2e1*ammu*amuq*amel2*ammu2^2*x3*x5*x6*xcp1+1536*e2e1*ammu*amuq*amel2*ammu2^2*x3*x5^2*xcp4+
1536*e2e1*ammu*amuq*amel2*ammu2^2*x3*x5^2*xcp1+1152*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4*xcp4-384*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4*xcp3-384*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4*xcp2+1152*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4*xcp1-384*e2e1*ammu*amuq*
amel2*ammu2^2*x3*x4*x6*xcp4+1152*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4*x6*xcp3+1152*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4*x6*xcp2-384*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4*x6*xcp1-768*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4*x5*xcp4+768*e2e1*ammu*amuq*amel2*
ammu2^2*x3*x4*x5*xcp3+768*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4*x5*xcp2-768*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4*x5*xcp1-384*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4^2*xcp4-384*e2e1*ammu*amuq*amel2*ammu2^2*x3*x4^2*xcp1-384*e2e1*ammu*amuq*amel2*ammu2^2*x3^2*x6
*xcp4+384*e2e1*ammu*amuq*amel2*ammu2^2*x3^2*x6*xcp3+384*e2e1*ammu*amuq*amel2*ammu2^2*x3^2*x6*xcp2-384*e2e1*ammu*amuq*amel2*ammu2^2*x3^2*x6*xcp1-384*e2e1*ammu*amuq*amel2*ammu2^2*x3^2*x5*xcp4+384*e2e1*ammu*amuq*amel2*ammu2^2*x3^2*x5*xcp3+384*e2e1*
ammu*amuq*amel2*ammu2^2*x3^2*x5*xcp2-384*e2e1*ammu*amuq*amel2*ammu2^2*x3^2*x5*xcp1+1920*e2e1*ammu*amuq*amel2*ammu2^2*x1*x6*xcp4+1152*e2e1*ammu*amuq*amel2*ammu2^2*x1*x6*xcp3+1152*e2e1*ammu*amuq*amel2*ammu2^2*x1*x6*xcp2+1920*e2e1*ammu*amuq*amel2*
ammu2^2*x1*x6*xcp1-768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x6^2*xcp4-384*e2e1*ammu*amuq*amel2*ammu2^2*x1*x6^2*xcp3-384*e2e1*ammu*amuq*amel2*ammu2^2*x1*x6^2*xcp2-768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x6^2*xcp1+1536*e2e1*ammu*amuq*amel2*ammu2^2*x1*x5*xcp4+
768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x5*xcp3+768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x5*xcp2+1536*e2e1*ammu*amuq*amel2*ammu2^2*x1*x5*xcp1-2304*e2e1*ammu*amuq*amel2*ammu2^2*x1*x5*x6*xcp4-768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x5*x6*xcp3-768*e2e1*ammu*amuq*
amel2*ammu2^2*x1*x5*x6*xcp2-2304*e2e1*ammu*amuq*amel2*ammu2^2*x1*x5*x6*xcp1-1536*e2e1*ammu*amuq*amel2*ammu2^2*x1*x5^2*xcp4-1536*e2e1*ammu*amuq*amel2*ammu2^2*x1*x5^2*xcp1-1152*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*xcp4+384*e2e1*ammu*amuq*amel2*ammu2^2*
x1*x4*xcp3+384*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*xcp2-1152*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*xcp1+384*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*x6*xcp4-1152*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*x6*xcp3-1152*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*x6*xcp2+384*
e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*x6*xcp1+768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*x5*xcp4-768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*x5*xcp3-768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*x5*xcp2+768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4*x5*xcp1+384*e2e1*ammu*
amuq*amel2*ammu2^2*x1*x4^2*xcp4+384*e2e1*ammu*amuq*amel2*ammu2^2*x1*x4^2*xcp1+768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x3*x6*xcp4-768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x3*x6*xcp3-768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x3*x6*xcp2+768*e2e1*ammu*amuq*amel2*
ammu2^2*x1*x3*x6*xcp1+768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x3*x5*xcp4-768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x3*x5*xcp3-768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x3*x5*xcp2+768*e2e1*ammu*amuq*amel2*ammu2^2*x1*x3*x5*xcp1-384*e2e1*ammu*amuq*amel2*ammu2^2*x1^2*
x6*xcp4+384*e2e1*ammu*amuq*amel2*ammu2^2*x1^2*x6*xcp3+384*e2e1*ammu*amuq*amel2*ammu2^2*x1^2*x6*xcp2-384*e2e1*ammu*amuq*amel2*ammu2^2*x1^2*x6*xcp1-384*e2e1*ammu*amuq*amel2*ammu2^2*x1^2*x5*xcp4+384*e2e1*ammu*amuq*amel2*ammu2^2*x1^2*x5*xcp3+384*e2e1*
ammu*amuq*amel2*ammu2^2*x1^2*x5*xcp2-384*e2e1*ammu*amuq*amel2*ammu2^2*x1^2*x5*xcp1-576*e2e1*ammu*amuq*amel2^2*amuq2*x4*xcp4-576*e2e1*ammu*amuq*amel2^2*amuq2*x4*xcp3-576*e2e1*ammu*amuq*amel2^2*amuq2*x4*xcp2-576*e2e1*ammu*amuq*amel2^2*amuq2*x4*xcp1+
576*e2e1*ammu*amuq*amel2^2*amuq2*x4*x6*xcp4+576*e2e1*ammu*amuq*amel2^2*amuq2*x4*x6*xcp3+576*e2e1*ammu*amuq*amel2^2*amuq2*x4*x6*xcp2+576*e2e1*ammu*amuq*amel2^2*amuq2*x4*x6*xcp1+576*e2e1*ammu*amuq*amel2^2*amuq2*x4*x5*xcp4+576*e2e1*ammu*amuq*amel2^2*
amuq2*x4*x5*xcp3+576*e2e1*ammu*amuq*amel2^2*amuq2*x4*x5*xcp2+576*e2e1*ammu*amuq*amel2^2*amuq2*x4*x5*xcp1+1728*e2e1*ammu*amuq*amel2^2*amuq2*x4^2*xcp4+576*e2e1*ammu*amuq*amel2^2*amuq2*x4^2*xcp3+576*e2e1*ammu*amuq*amel2^2*amuq2*x4^2*xcp2+1728*e2e1*
ammu*amuq*amel2^2*amuq2*x4^2*xcp1-576*e2e1*ammu*amuq*amel2^2*amuq2*x4^2*x6*xcp4+576*e2e1*ammu*amuq*amel2^2*amuq2*x4^2*x6*xcp3+576*e2e1*ammu*amuq*amel2^2*amuq2*x4^2*x6*xcp2-576*e2e1*ammu*amuq*amel2^2*amuq2*x4^2*x6*xcp1-576*e2e1*ammu*amuq*amel2^2*
amuq2*x4^2*x5*xcp4+576*e2e1*ammu*amuq*amel2^2*amuq2*x4^2*x5*xcp3+576*e2e1*ammu*amuq*amel2^2*amuq2*x4^2*x5*xcp2-576*e2e1*ammu*amuq*amel2^2*amuq2*x4^2*x5*xcp1-576*e2e1*ammu*amuq*amel2^2*amuq2*x4^3*xcp4-576*e2e1*ammu*amuq*amel2^2*amuq2*x4^3*xcp3-576*
e2e1*ammu*amuq*amel2^2*amuq2*x4^3*xcp2-576*e2e1*ammu*amuq*amel2^2*amuq2*x4^3*xcp1-576*e2e1*ammu*amuq*amel2^2*amuq2*x3*x4*xcp4-576*e2e1*ammu*amuq*amel2^2*amuq2*x3*x4*xcp3-576*e2e1*ammu*amuq*amel2^2*amuq2*x3*x4*xcp2-576*e2e1*ammu*amuq*amel2^2*amuq2*
x3*x4*xcp1+576*e2e1*ammu*amuq*amel2^2*amuq2*x3*x4^2*xcp4-576*e2e1*ammu*amuq*amel2^2*amuq2*x3*x4^2*xcp3-576*e2e1*ammu*amuq*amel2^2*amuq2*x3*x4^2*xcp2+576*e2e1*ammu*amuq*amel2^2*amuq2*x3*x4^2*xcp1+576*e2e1*ammu*amuq*amel2^2*amuq2*x1*x4*xcp4+576*e2e1*
ammu*amuq*amel2^2*amuq2*x1*x4*xcp3+576*e2e1*ammu*amuq*amel2^2*amuq2*x1*x4*xcp2+576*e2e1*ammu*amuq*amel2^2*amuq2*x1*x4*xcp1-576*e2e1*ammu*amuq*amel2^2*amuq2*x1*x4^2*xcp4+576*e2e1*ammu*amuq*amel2^2*amuq2*x1*x4^2*xcp3+576*e2e1*ammu*amuq*amel2^2*amuq2*
x1*x4^2*xcp2-576*e2e1*ammu*amuq*amel2^2*amuq2*x1*x4^2*xcp1-5376*e2e1*ammu*amuq*amel2^2*ammu2*x6*xcp4-2496*e2e1*ammu*amuq*amel2^2*ammu2*x6*xcp3-2496*e2e1*ammu*amuq*amel2^2*ammu2*x6*xcp2-5376*e2e1*ammu*amuq*amel2^2*ammu2*x6*xcp1+4416*e2e1*ammu*amuq*
amel2^2*ammu2*x6^2*xcp4-192*e2e1*ammu*amuq*amel2^2*ammu2*x6^2*xcp3-192*e2e1*ammu*amuq*amel2^2*ammu2*x6^2*xcp2+4416*e2e1*ammu*amuq*amel2^2*ammu2*x6^2*xcp1-768*e2e1*ammu*amuq*amel2^2*ammu2*x6^3*xcp4+960*e2e1*ammu*amuq*amel2^2*ammu2*x6^3*xcp3+960*e2e1
*ammu*amuq*amel2^2*ammu2*x6^3*xcp2-768*e2e1*ammu*amuq*amel2^2*ammu2*x6^3*xcp1-7680*e2e1*ammu*amuq*amel2^2*ammu2*x5*xcp4-3648*e2e1*ammu*amuq*amel2^2*ammu2*x5*xcp3-3648*e2e1*ammu*amuq*amel2^2*ammu2*x5*xcp2-7680*e2e1*ammu*amuq*amel2^2*ammu2*x5*xcp1+
9408*e2e1*ammu*amuq*amel2^2*ammu2*x5*x6*xcp4-2112*e2e1*ammu*amuq*amel2^2*ammu2*x5*x6*xcp3-2112*e2e1*ammu*amuq*amel2^2*ammu2*x5*x6*xcp2+9408*e2e1*ammu*amuq*amel2^2*ammu2*x5*x6*xcp1-2880*e2e1*ammu*amuq*amel2^2*ammu2*x5*x6^2*xcp4+3456*e2e1*ammu*amuq*
amel2^2*ammu2*x5*x6^2*xcp3+3456*e2e1*ammu*amuq*amel2^2*ammu2*x5*x6^2*xcp2-2880*e2e1*ammu*amuq*amel2^2*ammu2*x5*x6^2*xcp1+7296*e2e1*ammu*amuq*amel2^2*ammu2*x5^2*xcp4-768*e2e1*ammu*amuq*amel2^2*ammu2*x5^2*xcp3-768*e2e1*ammu*amuq*amel2^2*ammu2*x5^2*
xcp2+7296*e2e1*ammu*amuq*amel2^2*ammu2*x5^2*xcp1-4032*e2e1*ammu*amuq*amel2^2*ammu2*x5^2*x6*xcp4+4608*e2e1*ammu*amuq*amel2^2*ammu2*x5^2*x6*xcp3+4608*e2e1*ammu*amuq*amel2^2*ammu2*x5^2*x6*xcp2-4032*e2e1*ammu*amuq*amel2^2*ammu2*x5^2*x6*xcp1-1920*e2e1*
ammu*amuq*amel2^2*ammu2*x5^3*xcp4+2112*e2e1*ammu*amuq*amel2^2*ammu2*x5^3*xcp3+2112*e2e1*ammu*amuq*amel2^2*ammu2*x5^3*xcp2-1920*e2e1*ammu*amuq*amel2^2*ammu2*x5^3*xcp1+1728*e2e1*ammu*amuq*amel2^2*ammu2*x4*xcp4+576*e2e1*ammu*amuq*amel2^2*ammu2*x4*xcp3
+576*e2e1*ammu*amuq*amel2^2*ammu2*x4*xcp2+1728*e2e1*ammu*amuq*amel2^2*ammu2*x4*xcp1+1536*e2e1*ammu*amuq*amel2^2*ammu2*x4*x6*xcp4+384*e2e1*ammu*amuq*amel2^2*ammu2*x4*x6*xcp3+384*e2e1*ammu*amuq*amel2^2*ammu2*x4*x6*xcp2+1536*e2e1*ammu*amuq*amel2^2*
ammu2*x4*x6*xcp1-960*e2e1*ammu*amuq*amel2^2*ammu2*x4*x6^2*xcp4-960*e2e1*ammu*amuq*amel2^2*ammu2*x4*x6^2*xcp3-960*e2e1*ammu*amuq*amel2^2*ammu2*x4*x6^2*xcp2-960*e2e1*ammu*amuq*amel2^2*ammu2*x4*x6^2*xcp1+8448*e2e1*ammu*amuq*amel2^2*ammu2*x4*x5*xcp4+
2688*e2e1*ammu*amuq*amel2^2*ammu2*x4*x5*xcp3+2688*e2e1*ammu*amuq*amel2^2*ammu2*x4*x5*xcp2+8448*e2e1*ammu*amuq*amel2^2*ammu2*x4*x5*xcp1-2496*e2e1*ammu*amuq*amel2^2*ammu2*x4*x5*x6*xcp4+2112*e2e1*ammu*amuq*amel2^2*ammu2*x4*x5*x6*xcp3+2112*e2e1*ammu*
amuq*amel2^2*ammu2*x4*x5*x6*xcp2-2496*e2e1*ammu*amuq*amel2^2*ammu2*x4*x5*x6*xcp1-4416*e2e1*ammu*amuq*amel2^2*ammu2*x4*x5^2*xcp4+2496*e2e1*ammu*amuq*amel2^2*ammu2*x4*x5^2*xcp3+2496*e2e1*ammu*amuq*amel2^2*ammu2*x4*x5^2*xcp2-4416*e2e1*ammu*amuq*
amel2^2*ammu2*x4*x5^2*xcp1+1728*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*xcp4-576*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*xcp3-576*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*xcp2+1728*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*xcp1-192*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*x6*xcp4+
1536*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*x6*xcp3+1536*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*x6*xcp2-192*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*x6*xcp1-4800*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*x5*xcp4+384*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*x5*xcp3+384*e2e1*ammu*
amuq*amel2^2*ammu2*x4^2*x5*xcp2-4800*e2e1*ammu*amuq*amel2^2*ammu2*x4^2*x5*xcp1-1152*e2e1*ammu*amuq*amel2^2*ammu2*x4^3*xcp4-1152*e2e1*ammu*amuq*amel2^2*ammu2*x4^3*xcp1-1920*e2e1*ammu*amuq*amel2^2*ammu2*x3*x6*xcp4+384*e2e1*ammu*amuq*amel2^2*ammu2*x3*
x6*xcp3+384*e2e1*ammu*amuq*amel2^2*ammu2*x3*x6*xcp2-1920*e2e1*ammu*amuq*amel2^2*ammu2*x3*x6*xcp1+768*e2e1*ammu*amuq*amel2^2*ammu2*x3*x6^2*xcp4-384*e2e1*ammu*amuq*amel2^2*ammu2*x3*x6^2*xcp3-384*e2e1*ammu*amuq*amel2^2*ammu2*x3*x6^2*xcp2+768*e2e1*ammu
*amuq*amel2^2*ammu2*x3*x6^2*xcp1-3072*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5*xcp4+384*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5*xcp3+384*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5*xcp2-3072*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5*xcp1+2112*e2e1*ammu*amuq*amel2^2*ammu2*x3*
x5*x6*xcp4-1344*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5*x6*xcp3-1344*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5*x6*xcp2+2112*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5*x6*xcp1+1920*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5^2*xcp4-1536*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5^2*xcp3
-1536*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5^2*xcp2+1920*e2e1*ammu*amuq*amel2^2*ammu2*x3*x5^2*xcp1+2880*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4*xcp4-576*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4*xcp3-576*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4*xcp2+2880*e2e1*ammu*amuq*
amel2^2*ammu2*x3*x4*xcp1-960*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4*x6*xcp4+2496*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4*x6*xcp3+2496*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4*x6*xcp2-960*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4*x6*xcp1-960*e2e1*ammu*amuq*amel2^2*ammu2*
x3*x4*x5*xcp4+1344*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4*x5*xcp3+1344*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4*x5*xcp2-960*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4*x5*xcp1-1152*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4^2*xcp4-1152*e2e1*ammu*amuq*amel2^2*ammu2*x3*x4^2*
xcp1-768*e2e1*ammu*amuq*amel2^2*ammu2*x3^2*x6*xcp4+960*e2e1*ammu*amuq*amel2^2*ammu2*x3^2*x6*xcp3+960*e2e1*ammu*amuq*amel2^2*ammu2*x3^2*x6*xcp2-768*e2e1*ammu*amuq*amel2^2*ammu2*x3^2*x6*xcp1-768*e2e1*ammu*amuq*amel2^2*ammu2*x3^2*x5*xcp4+960*e2e1*ammu
*amuq*amel2^2*ammu2*x3^2*x5*xcp3+960*e2e1*ammu*amuq*amel2^2*ammu2*x3^2*x5*xcp2-768*e2e1*ammu*amuq*amel2^2*ammu2*x3^2*x5*xcp1+2688*e2e1*ammu*amuq*amel2^2*ammu2*x1*x6*xcp4-1920*e2e1*ammu*amuq*amel2^2*ammu2*x1*x6*xcp3-1920*e2e1*ammu*amuq*amel2^2*ammu2
*x1*x6*xcp2+2688*e2e1*ammu*amuq*amel2^2*ammu2*x1*x6*xcp1-1536*e2e1*ammu*amuq*amel2^2*ammu2*x1*x6^2*xcp4+1920*e2e1*ammu*amuq*amel2^2*ammu2*x1*x6^2*xcp3+1920*e2e1*ammu*amuq*amel2^2*ammu2*x1*x6^2*xcp2-1536*e2e1*ammu*amuq*amel2^2*ammu2*x1*x6^2*xcp1+
3840*e2e1*ammu*amuq*amel2^2*ammu2*x1*x5*xcp4-1920*e2e1*ammu*amuq*amel2^2*ammu2*x1*x5*xcp3-1920*e2e1*ammu*amuq*amel2^2*ammu2*x1*x5*xcp2+3840*e2e1*ammu*amuq*amel2^2*ammu2*x1*x5*xcp1-3648*e2e1*ammu*amuq*amel2^2*ammu2*x1*x5*x6*xcp4+4416*e2e1*ammu*amuq*
amel2^2*ammu2*x1*x5*x6*xcp3+4416*e2e1*ammu*amuq*amel2^2*ammu2*x1*x5*x6*xcp2-3648*e2e1*ammu*amuq*amel2^2*ammu2*x1*x5*x6*xcp1-2688*e2e1*ammu*amuq*amel2^2*ammu2*x1*x5^2*xcp4+3072*e2e1*ammu*amuq*amel2^2*ammu2*x1*x5^2*xcp3+3072*e2e1*ammu*amuq*amel2^2*
ammu2*x1*x5^2*xcp2-2688*e2e1*ammu*amuq*amel2^2*ammu2*x1*x5^2*xcp1-2880*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*xcp4+576*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*xcp3+576*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*xcp2-2880*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*xcp1+192*
e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*x6*xcp4-960*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*x6*xcp3-960*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*x6*xcp2+192*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*x6*xcp1+192*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*x5*xcp4+192*e2e1*ammu*
amuq*amel2^2*ammu2*x1*x4*x5*xcp3+192*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*x5*xcp2+192*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4*x5*xcp1+1152*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4^2*xcp4+1152*e2e1*ammu*amuq*amel2^2*ammu2*x1*x4^2*xcp1+768*e2e1*ammu*amuq*amel2^2*
ammu2*x1*x3*x6*xcp4-384*e2e1*ammu*amuq*amel2^2*ammu2*x1*x3*x6*xcp3-384*e2e1*ammu*amuq*amel2^2*ammu2*x1*x3*x6*xcp2+768*e2e1*ammu*amuq*amel2^2*ammu2*x1*x3*x6*xcp1+768*e2e1*ammu*amuq*amel2^2*ammu2*x1*x3*x5*xcp4-384*e2e1*ammu*amuq*amel2^2*ammu2*x1*x3*
x5*xcp3-384*e2e1*ammu*amuq*amel2^2*ammu2*x1*x3*x5*xcp2+768*e2e1*ammu*amuq*amel2^2*ammu2*x1*x3*x5*xcp1-768*e2e1*ammu*amuq*amel2^2*ammu2*x1^2*x6*xcp4+960*e2e1*ammu*amuq*amel2^2*ammu2*x1^2*x6*xcp3+960*e2e1*ammu*amuq*amel2^2*ammu2*x1^2*x6*xcp2-768*e2e1
*ammu*amuq*amel2^2*ammu2*x1^2*x6*xcp1-768*e2e1*ammu*amuq*amel2^2*ammu2*x1^2*x5*xcp4+960*e2e1*ammu*amuq*amel2^2*ammu2*x1^2*x5*xcp3+960*e2e1*ammu*amuq*amel2^2*ammu2*x1^2*x5*xcp2-768*e2e1*ammu*amuq*amel2^2*ammu2*x1^2*x5*xcp1-576*e2e1*ammu*amuq*amel2^3
*xcp4-576*e2e1*ammu*amuq*amel2^3*xcp3-576*e2e1*ammu*amuq*amel2^3*xcp2-576*e2e1*ammu*amuq*amel2^3*xcp1+576*e2e1*ammu*amuq*amel2^3*x6^2*xcp4+576*e2e1*ammu*amuq*amel2^3*x6^2*xcp3+576*e2e1*ammu*amuq*amel2^3*x6^2*xcp2+576*e2e1*ammu*amuq*amel2^3*x6^2*
xcp1-1536*e2e1*ammu*amuq*amel2^3*x5*xcp4-1536*e2e1*ammu*amuq*amel2^3*x5*xcp3-1536*e2e1*ammu*amuq*amel2^3*x5*xcp2-1536*e2e1*ammu*amuq*amel2^3*x5*xcp1+2688*e2e1*ammu*amuq*amel2^3*x5*x6*xcp4+2688*e2e1*ammu*amuq*amel2^3*x5*x6*xcp3+2688*e2e1*ammu*amuq*
amel2^3*x5*x6*xcp2+2688*e2e1*ammu*amuq*amel2^3*x5*x6*xcp1+2112*e2e1*ammu*amuq*amel2^3*x5^2*xcp4+2112*e2e1*ammu*amuq*amel2^3*x5^2*xcp3+2112*e2e1*ammu*amuq*amel2^3*x5^2*xcp2+2112*e2e1*ammu*amuq*amel2^3*x5^2*xcp1+1920*e2e1*ammu*amuq*amel2^3*x4*xcp4+
1920*e2e1*ammu*amuq*amel2^3*x4*xcp1-384*e2e1*ammu*amuq*amel2^3*x4*x6*xcp4+1152*e2e1*ammu*amuq*amel2^3*x4*x6*xcp3+1152*e2e1*ammu*amuq*amel2^3*x4*x6*xcp2-384*e2e1*ammu*amuq*amel2^3*x4*x6*xcp1-384*e2e1*ammu*amuq*amel2^3*x4*x6^2*xcp4-384*e2e1*ammu*amuq
*amel2^3*x4*x6^2*xcp1+3456*e2e1*ammu*amuq*amel2^3*x4*x5*xcp4+3456*e2e1*ammu*amuq*amel2^3*x4*x5*xcp3+3456*e2e1*ammu*amuq*amel2^3*x4*x5*xcp2+3456*e2e1*ammu*amuq*amel2^3*x4*x5*xcp1-1536*e2e1*ammu*amuq*amel2^3*x4*x5*x6*xcp4+768*e2e1*ammu*amuq*amel2^3*
x4*x5*x6*xcp3+768*e2e1*ammu*amuq*amel2^3*x4*x5*x6*xcp2-1536*e2e1*ammu*amuq*amel2^3*x4*x5*x6*xcp1-1152*e2e1*ammu*amuq*amel2^3*x4*x5^2*xcp4+768*e2e1*ammu*amuq*amel2^3*x4*x5^2*xcp3+768*e2e1*ammu*amuq*amel2^3*x4*x5^2*xcp2-1152*e2e1*ammu*amuq*amel2^3*x4
*x5^2*xcp1+1344*e2e1*ammu*amuq*amel2^3*x4^2*xcp4+576*e2e1*ammu*amuq*amel2^3*x4^2*xcp3+576*e2e1*ammu*amuq*amel2^3*x4^2*xcp2+1344*e2e1*ammu*amuq*amel2^3*x4^2*xcp1-2304*e2e1*ammu*amuq*amel2^3*x4^2*x5*xcp4-768*e2e1*ammu*amuq*amel2^3*x4^2*x5*xcp3-768*
e2e1*ammu*amuq*amel2^3*x4^2*x5*xcp2-2304*e2e1*ammu*amuq*amel2^3*x4^2*x5*xcp1-1152*e2e1*ammu*amuq*amel2^3*x4^3*xcp4-1152*e2e1*ammu*amuq*amel2^3*x4^3*xcp1+1152*e2e1*ammu*amuq*amel2^3*x3*x6*xcp4+1152*e2e1*ammu*amuq*amel2^3*x3*x6*xcp3+1152*e2e1*ammu*
amuq*amel2^3*x3*x6*xcp2+1152*e2e1*ammu*amuq*amel2^3*x3*x6*xcp1-384*e2e1*ammu*amuq*amel2^3*x3*x5*xcp4-384*e2e1*ammu*amuq*amel2^3*x3*x5*xcp3-384*e2e1*ammu*amuq*amel2^3*x3*x5*xcp2-384*e2e1*ammu*amuq*amel2^3*x3*x5*xcp1+2688*e2e1*ammu*amuq*amel2^3*x3*x4
*xcp4+1152*e2e1*ammu*amuq*amel2^3*x3*x4*xcp3+1152*e2e1*ammu*amuq*amel2^3*x3*x4*xcp2+2688*e2e1*ammu*amuq*amel2^3*x3*x4*xcp1-768*e2e1*ammu*amuq*amel2^3*x3*x4*x6*xcp4-768*e2e1*ammu*amuq*amel2^3*x3*x4*x6*xcp1-768*e2e1*ammu*amuq*amel2^3*x3*x4*x5*xcp3-
768*e2e1*ammu*amuq*amel2^3*x3*x4*x5*xcp2-1536*e2e1*ammu*amuq*amel2^3*x3*x4^2*xcp4-1536*e2e1*ammu*amuq*amel2^3*x3*x4^2*xcp1+576*e2e1*ammu*amuq*amel2^3*x3^2*xcp4+576*e2e1*ammu*amuq*amel2^3*x3^2*xcp3+576*e2e1*ammu*amuq*amel2^3*x3^2*xcp2+576*e2e1*ammu*
amuq*amel2^3*x3^2*xcp1-384*e2e1*ammu*amuq*amel2^3*x3^2*x4*xcp4-384*e2e1*ammu*amuq*amel2^3*x3^2*x4*xcp1+1152*e2e1*ammu*amuq*amel2^3*x1*x6*xcp4+1152*e2e1*ammu*amuq*amel2^3*x1*x6*xcp3+1152*e2e1*ammu*amuq*amel2^3*x1*x6*xcp2+1152*e2e1*ammu*amuq*amel2^3*
x1*x6*xcp1+2688*e2e1*ammu*amuq*amel2^3*x1*x5*xcp4+2688*e2e1*ammu*amuq*amel2^3*x1*x5*xcp3+2688*e2e1*ammu*amuq*amel2^3*x1*x5*xcp2+2688*e2e1*ammu*amuq*amel2^3*x1*x5*xcp1-384*e2e1*ammu*amuq*amel2^3*x1*x4*xcp4+1152*e2e1*ammu*amuq*amel2^3*x1*x4*xcp3+1152
*e2e1*ammu*amuq*amel2^3*x1*x4*xcp2-384*e2e1*ammu*amuq*amel2^3*x1*x4*xcp1-768*e2e1*ammu*amuq*amel2^3*x1*x4*x6*xcp4-768*e2e1*ammu*amuq*amel2^3*x1*x4*x6*xcp1-1536*e2e1*ammu*amuq*amel2^3*x1*x4*x5*xcp4+768*e2e1*ammu*amuq*amel2^3*x1*x4*x5*xcp3+768*e2e1*
ammu*amuq*amel2^3*x1*x4*x5*xcp2-1536*e2e1*ammu*amuq*amel2^3*x1*x4*x5*xcp1+1152*e2e1*ammu*amuq*amel2^3*x1*x3*xcp4+1152*e2e1*ammu*amuq*amel2^3*x1*x3*xcp3+1152*e2e1*ammu*amuq*amel2^3*x1*x3*xcp2+1152*e2e1*ammu*amuq*amel2^3*x1*x3*xcp1-768*e2e1*ammu*amuq
*amel2^3*x1*x3*x4*xcp4-768*e2e1*ammu*amuq*amel2^3*x1*x3*x4*xcp1+576*e2e1*ammu*amuq*amel2^3*x1^2*xcp4+576*e2e1*ammu*amuq*amel2^3*x1^2*xcp3+576*e2e1*ammu*amuq*amel2^3*x1^2*xcp2+576*e2e1*ammu*amuq*amel2^3*x1^2*xcp1-384*e2e1*ammu*amuq*amel2^3*x1^2*x4*
xcp4-384*e2e1*ammu*amuq*amel2^3*x1^2*x4*xcp1-96*e2e1^2*ammu*amuq*x6*xcp4*e2345-192*e2e1^2*ammu*amuq*x6*xcp4*e1345-336*e2e1^2*ammu*amuq*x6*xcp4*e1235-384*e2e1^2*ammu*amuq*x6*xcp4*e1234-48*e2e1^2*ammu*amuq*x6*xcp3*e2345-144*e2e1^2*ammu*amuq*x6*xcp3*
e1345-336*e2e1^2*ammu*amuq*x6*xcp3*e1235+48*e2e1^2*ammu*amuq*x6*xcp2*e2345+144*e2e1^2*ammu*amuq*x6*xcp2*e1345+336*e2e1^2*ammu*amuq*x6*xcp2*e1235+96*e2e1^2*ammu*amuq*x6*xcp1*e2345+192*e2e1^2*ammu*amuq*x6*xcp1*e1345+336*e2e1^2*ammu*amuq*x6*xcp1*e1235
+384*e2e1^2*ammu*amuq*x6*xcp1*e1234+96*e2e1^2*ammu*amuq*x6^2*xcp4*e2345+96*e2e1^2*ammu*amuq*x6^2*xcp4*e1345+336*e2e1^2*ammu*amuq*x6^2*xcp4*e1235+384*e2e1^2*ammu*amuq*x6^2*xcp4*e1234+48*e2e1^2*ammu*amuq*x6^2*xcp3*e2345+336*e2e1^2*ammu*amuq*x6^2*xcp3
*e1235-48*e2e1^2*ammu*amuq*x6^2*xcp2*e2345-336*e2e1^2*ammu*amuq*x6^2*xcp2*e1235-96*e2e1^2*ammu*amuq*x6^2*xcp1*e2345-96*e2e1^2*ammu*amuq*x6^2*xcp1*e1345-336*e2e1^2*ammu*amuq*x6^2*xcp1*e1235-384*e2e1^2*ammu*amuq*x6^2*xcp1*e1234+48*e2e1^2*ammu*amuq*
x6^3*xcp3*e1345-48*e2e1^2*ammu*amuq*x6^3*xcp2*e1345-480*e2e1^2*ammu*amuq*x5*xcp4*e2345-720*e2e1^2*ammu*amuq*x5*xcp4*e1345-384*e2e1^2*ammu*amuq*x5*xcp4*e1245-336*e2e1^2*ammu*amuq*x5*xcp4*e1235-144*e2e1^2*ammu*amuq*x5*xcp4*e1234-432*e2e1^2*ammu*amuq*
x5*xcp3*e2345-480*e2e1^2*ammu*amuq*x5*xcp3*e1345-384*e2e1^2*ammu*amuq*x5*xcp3*e1245-336*e2e1^2*ammu*amuq*x5*xcp3*e1235+288*e2e1^2*ammu*amuq*x5*xcp3*e1234+432*e2e1^2*ammu*amuq*x5*xcp2*e2345+480*e2e1^2*ammu*amuq*x5*xcp2*e1345+384*e2e1^2*ammu*amuq*x5*
xcp2*e1245+336*e2e1^2*ammu*amuq*x5*xcp2*e1235-288*e2e1^2*ammu*amuq*x5*xcp2*e1234+480*e2e1^2*ammu*amuq*x5*xcp1*e2345+720*e2e1^2*ammu*amuq*x5*xcp1*e1345+384*e2e1^2*ammu*amuq*x5*xcp1*e1245+336*e2e1^2*ammu*amuq*x5*xcp1*e1235+144*e2e1^2*ammu*amuq*x5*
xcp1*e1234+192*e2e1^2*ammu*amuq*x5*x6*xcp4*e2345+480*e2e1^2*ammu*amuq*x5*x6*xcp4*e1345+384*e2e1^2*ammu*amuq*x5*x6*xcp4*e1245+672*e2e1^2*ammu*amuq*x5*x6*xcp4*e1235+576*e2e1^2*ammu*amuq*x5*x6*xcp4*e1234+96*e2e1^2*ammu*amuq*x5*x6*xcp3*e2345-96*e2e1^2*
ammu*amuq*x5*x6*xcp3*e1345+384*e2e1^2*ammu*amuq*x5*x6*xcp3*e1245+672*e2e1^2*ammu*amuq*x5*x6*xcp3*e1235-48*e2e1^2*ammu*amuq*x5*x6*xcp3*e1234-96*e2e1^2*ammu*amuq*x5*x6*xcp2*e2345+96*e2e1^2*ammu*amuq*x5*x6*xcp2*e1345-384*e2e1^2*ammu*amuq*x5*x6*xcp2*
e1245-672*e2e1^2*ammu*amuq*x5*x6*xcp2*e1235+48*e2e1^2*ammu*amuq*x5*x6*xcp2*e1234-192*e2e1^2*ammu*amuq*x5*x6*xcp1*e2345-480*e2e1^2*ammu*amuq*x5*x6*xcp1*e1345-384*e2e1^2*ammu*amuq*x5*x6*xcp1*e1245-672*e2e1^2*ammu*amuq*x5*x6*xcp1*e1235-576*e2e1^2*ammu
*amuq*x5*x6*xcp1*e1234-48*e2e1^2*ammu*amuq*x5*x6^2*xcp4*e1345+288*e2e1^2*ammu*amuq*x5*x6^2*xcp3*e1345-240*e2e1^2*ammu*amuq*x5*x6^2*xcp3*e1234-288*e2e1^2*ammu*amuq*x5*x6^2*xcp2*e1345+240*e2e1^2*ammu*amuq*x5*x6^2*xcp2*e1234+48*e2e1^2*ammu*amuq*x5*
x6^2*xcp1*e1345+96*e2e1^2*ammu*amuq*x5^2*xcp4*e2345+384*e2e1^2*ammu*amuq*x5^2*xcp4*e1345+384*e2e1^2*ammu*amuq*x5^2*xcp4*e1245+336*e2e1^2*ammu*amuq*x5^2*xcp4*e1235+336*e2e1^2*ammu*amuq*x5^2*xcp4*e1234+48*e2e1^2*ammu*amuq*x5^2*xcp3*e2345-96*e2e1^2*
ammu*amuq*x5^2*xcp3*e1345+384*e2e1^2*ammu*amuq*x5^2*xcp3*e1245+336*e2e1^2*ammu*amuq*x5^2*xcp3*e1235-96*e2e1^2*ammu*amuq*x5^2*xcp3*e1234-48*e2e1^2*ammu*amuq*x5^2*xcp2*e2345+96*e2e1^2*ammu*amuq*x5^2*xcp2*e1345-384*e2e1^2*ammu*amuq*x5^2*xcp2*e1245-336
*e2e1^2*ammu*amuq*x5^2*xcp2*e1235+96*e2e1^2*ammu*amuq*x5^2*xcp2*e1234-96*e2e1^2*ammu*amuq*x5^2*xcp1*e2345-384*e2e1^2*ammu*amuq*x5^2*xcp1*e1345-384*e2e1^2*ammu*amuq*x5^2*xcp1*e1245-336*e2e1^2*ammu*amuq*x5^2*xcp1*e1235-336*e2e1^2*ammu*amuq*x5^2*xcp1*
e1234-96*e2e1^2*ammu*amuq*x5^2*x6*xcp4*e1345-144*e2e1^2*ammu*amuq*x5^2*x6*xcp4*e1234+432*e2e1^2*ammu*amuq*x5^2*x6*xcp3*e1345-432*e2e1^2*ammu*amuq*x5^2*x6*xcp3*e1234-432*e2e1^2*ammu*amuq*x5^2*x6*xcp2*e1345+432*e2e1^2*ammu*amuq*x5^2*x6*xcp2*e1234+96*
e2e1^2*ammu*amuq*x5^2*x6*xcp1*e1345+144*e2e1^2*ammu*amuq*x5^2*x6*xcp1*e1234-48*e2e1^2*ammu*amuq*x5^3*xcp4*e1345-144*e2e1^2*ammu*amuq*x5^3*xcp4*e1234+192*e2e1^2*ammu*amuq*x5^3*xcp3*e1345-192*e2e1^2*ammu*amuq*x5^3*xcp3*e1234-192*e2e1^2*ammu*amuq*x5^3
*xcp2*e1345+192*e2e1^2*ammu*amuq*x5^3*xcp2*e1234+48*e2e1^2*ammu*amuq*x5^3*xcp1*e1345+144*e2e1^2*ammu*amuq*x5^3*xcp1*e1234-384*e2e1^2*ammu*amuq*x4*xcp4*e2345-336*e2e1^2*ammu*amuq*x4*xcp4*e1345-384*e2e1^2*ammu*amuq*x4*xcp4*e1245-144*e2e1^2*ammu*amuq*
x4*xcp4*e1235-48*e2e1^2*ammu*amuq*x4*xcp3*e1345-288*e2e1^2*ammu*amuq*x4*xcp3*e1235+48*e2e1^2*ammu*amuq*x4*xcp2*e1345+288*e2e1^2*ammu*amuq*x4*xcp2*e1235+384*e2e1^2*ammu*amuq*x4*xcp1*e2345+336*e2e1^2*ammu*amuq*x4*xcp1*e1345+384*e2e1^2*ammu*amuq*x4*
xcp1*e1245+144*e2e1^2*ammu*amuq*x4*xcp1*e1235+144*e2e1^2*ammu*amuq*x4*x6*xcp4*e2345+288*e2e1^2*ammu*amuq*x4*x6*xcp4*e1345+384*e2e1^2*ammu*amuq*x4*x6*xcp4*e1245+720*e2e1^2*ammu*amuq*x4*x6*xcp4*e1235+576*e2e1^2*ammu*amuq*x4*x6*xcp4*e1234+96*e2e1^2*
ammu*amuq*x4*x6*xcp3*e2345+48*e2e1^2*ammu*amuq*x4*x6*xcp3*e1345+288*e2e1^2*ammu*amuq*x4*x6*xcp3*e1235-96*e2e1^2*ammu*amuq*x4*x6*xcp2*e2345-48*e2e1^2*ammu*amuq*x4*x6*xcp2*e1345-288*e2e1^2*ammu*amuq*x4*x6*xcp2*e1235-144*e2e1^2*ammu*amuq*x4*x6*xcp1*
e2345-288*e2e1^2*ammu*amuq*x4*x6*xcp1*e1345-384*e2e1^2*ammu*amuq*x4*x6*xcp1*e1245-720*e2e1^2*ammu*amuq*x4*x6*xcp1*e1235-576*e2e1^2*ammu*amuq*x4*x6*xcp1*e1234-192*e2e1^2*ammu*amuq*x4*x6^2*xcp4*e2345-192*e2e1^2*ammu*amuq*x4*x6^2*xcp4*e1345-192*e2e1^2
*ammu*amuq*x4*x6^2*xcp4*e1235-192*e2e1^2*ammu*amuq*x4*x6^2*xcp4*e1234-144*e2e1^2*ammu*amuq*x4*x6^2*xcp3*e2345+336*e2e1^2*ammu*amuq*x4*x6^2*xcp3*e1235+144*e2e1^2*ammu*amuq*x4*x6^2*xcp2*e2345-336*e2e1^2*ammu*amuq*x4*x6^2*xcp2*e1235+192*e2e1^2*ammu*
amuq*x4*x6^2*xcp1*e2345+192*e2e1^2*ammu*amuq*x4*x6^2*xcp1*e1345+192*e2e1^2*ammu*amuq*x4*x6^2*xcp1*e1235+192*e2e1^2*ammu*amuq*x4*x6^2*xcp1*e1234+528*e2e1^2*ammu*amuq*x4*x5*xcp4*e2345+1008*e2e1^2*ammu*amuq*x4*x5*xcp4*e1345+960*e2e1^2*ammu*amuq*x4*x5*
xcp4*e1245+480*e2e1^2*ammu*amuq*x4*x5*xcp4*e1235-192*e2e1^2*ammu*amuq*x4*x5*xcp3*e2345-144*e2e1^2*ammu*amuq*x4*x5*xcp3*e1345+192*e2e1^2*ammu*amuq*x4*x5*xcp3*e1245+624*e2e1^2*ammu*amuq*x4*x5*xcp3*e1235-144*e2e1^2*ammu*amuq*x4*x5*xcp3*e1234+192*
e2e1^2*ammu*amuq*x4*x5*xcp2*e2345+144*e2e1^2*ammu*amuq*x4*x5*xcp2*e1345-192*e2e1^2*ammu*amuq*x4*x5*xcp2*e1245-624*e2e1^2*ammu*amuq*x4*x5*xcp2*e1235+144*e2e1^2*ammu*amuq*x4*x5*xcp2*e1234-528*e2e1^2*ammu*amuq*x4*x5*xcp1*e2345-1008*e2e1^2*ammu*amuq*x4
*x5*xcp1*e1345-960*e2e1^2*ammu*amuq*x4*x5*xcp1*e1245-480*e2e1^2*ammu*amuq*x4*x5*xcp1*e1235-144*e2e1^2*ammu*amuq*x4*x5*x6*xcp4*e2345-96*e2e1^2*ammu*amuq*x4*x5*x6*xcp4*e1345-192*e2e1^2*ammu*amuq*x4*x5*x6*xcp4*e1245-144*e2e1^2*ammu*amuq*x4*x5*x6*xcp4*
e1235-192*e2e1^2*ammu*amuq*x4*x5*x6*xcp4*e1234-240*e2e1^2*ammu*amuq*x4*x5*x6*xcp3*e2345-144*e2e1^2*ammu*amuq*x4*x5*x6*xcp3*e1345+192*e2e1^2*ammu*amuq*x4*x5*x6*xcp3*e1245+336*e2e1^2*ammu*amuq*x4*x5*x6*xcp3*e1235-384*e2e1^2*ammu*amuq*x4*x5*x6*xcp3*
e1234+240*e2e1^2*ammu*amuq*x4*x5*x6*xcp2*e2345+144*e2e1^2*ammu*amuq*x4*x5*x6*xcp2*e1345-192*e2e1^2*ammu*amuq*x4*x5*x6*xcp2*e1245-336*e2e1^2*ammu*amuq*x4*x5*x6*xcp2*e1235+384*e2e1^2*ammu*amuq*x4*x5*x6*xcp2*e1234+144*e2e1^2*ammu*amuq*x4*x5*x6*xcp1*
e2345+96*e2e1^2*ammu*amuq*x4*x5*x6*xcp1*e1345+192*e2e1^2*ammu*amuq*x4*x5*x6*xcp1*e1245+144*e2e1^2*ammu*amuq*x4*x5*x6*xcp1*e1235+192*e2e1^2*ammu*amuq*x4*x5*x6*xcp1*e1234-48*e2e1^2*ammu*amuq*x4*x5^2*xcp4*e2345-96*e2e1^2*ammu*amuq*x4*x5^2*xcp4*e1345-
192*e2e1^2*ammu*amuq*x4*x5^2*xcp4*e1245+48*e2e1^2*ammu*amuq*x4*x5^2*xcp4*e1235-96*e2e1^2*ammu*amuq*x4*x5^2*xcp4*e1234+192*e2e1^2*ammu*amuq*x4*x5^2*xcp3*e2345+432*e2e1^2*ammu*amuq*x4*x5^2*xcp3*e1345+192*e2e1^2*ammu*amuq*x4*x5^2*xcp3*e1245-432*e2e1^2
*ammu*amuq*x4*x5^2*xcp3*e1234-192*e2e1^2*ammu*amuq*x4*x5^2*xcp2*e2345-432*e2e1^2*ammu*amuq*x4*x5^2*xcp2*e1345-192*e2e1^2*ammu*amuq*x4*x5^2*xcp2*e1245+432*e2e1^2*ammu*amuq*x4*x5^2*xcp2*e1234+48*e2e1^2*ammu*amuq*x4*x5^2*xcp1*e2345+96*e2e1^2*ammu*amuq
*x4*x5^2*xcp1*e1345+192*e2e1^2*ammu*amuq*x4*x5^2*xcp1*e1245-48*e2e1^2*ammu*amuq*x4*x5^2*xcp1*e1235+96*e2e1^2*ammu*amuq*x4*x5^2*xcp1*e1234+288*e2e1^2*ammu*amuq*x4^2*xcp4*e2345+144*e2e1^2*ammu*amuq*x4^2*xcp4*e1345+576*e2e1^2*ammu*amuq*x4^2*xcp4*e1245
+192*e2e1^2*ammu*amuq*x4^2*xcp4*e1235-96*e2e1^2*ammu*amuq*x4^2*xcp3*e2345+48*e2e1^2*ammu*amuq*x4^2*xcp3*e1345+432*e2e1^2*ammu*amuq*x4^2*xcp3*e1235+96*e2e1^2*ammu*amuq*x4^2*xcp2*e2345-48*e2e1^2*ammu*amuq*x4^2*xcp2*e1345-432*e2e1^2*ammu*amuq*x4^2*
xcp2*e1235-288*e2e1^2*ammu*amuq*x4^2*xcp1*e2345-144*e2e1^2*ammu*amuq*x4^2*xcp1*e1345-576*e2e1^2*ammu*amuq*x4^2*xcp1*e1245-192*e2e1^2*ammu*amuq*x4^2*xcp1*e1235+96*e2e1^2*ammu*amuq*x4^2*x6*xcp4*e1345-192*e2e1^2*ammu*amuq*x4^2*x6*xcp4*e1245-384*e2e1^2
*ammu*amuq*x4^2*x6*xcp4*e1235-192*e2e1^2*ammu*amuq*x4^2*x6*xcp4*e1234-96*e2e1^2*ammu*amuq*x4^2*x6*xcp3*e2345-96*e2e1^2*ammu*amuq*x4^2*x6*xcp3*e1345+288*e2e1^2*ammu*amuq*x4^2*x6*xcp3*e1235+96*e2e1^2*ammu*amuq*x4^2*x6*xcp2*e2345+96*e2e1^2*ammu*amuq*
x4^2*x6*xcp2*e1345-288*e2e1^2*ammu*amuq*x4^2*x6*xcp2*e1235-96*e2e1^2*ammu*amuq*x4^2*x6*xcp1*e1345+192*e2e1^2*ammu*amuq*x4^2*x6*xcp1*e1245+384*e2e1^2*ammu*amuq*x4^2*x6*xcp1*e1235+192*e2e1^2*ammu*amuq*x4^2*x6*xcp1*e1234-96*e2e1^2*ammu*amuq*x4^2*x5*
xcp4*e2345-96*e2e1^2*ammu*amuq*x4^2*x5*xcp4*e1345-384*e2e1^2*ammu*amuq*x4^2*x5*xcp4*e1245-96*e2e1^2*ammu*amuq*x4^2*x5*xcp4*e1235+96*e2e1^2*ammu*amuq*x4^2*x5*xcp4*e1234+432*e2e1^2*ammu*amuq*x4^2*x5*xcp3*e2345+96*e2e1^2*ammu*amuq*x4^2*x5*xcp3*e1345+
192*e2e1^2*ammu*amuq*x4^2*x5*xcp3*e1245-240*e2e1^2*ammu*amuq*x4^2*x5*xcp3*e1235-96*e2e1^2*ammu*amuq*x4^2*x5*xcp3*e1234-432*e2e1^2*ammu*amuq*x4^2*x5*xcp2*e2345-96*e2e1^2*ammu*amuq*x4^2*x5*xcp2*e1345-192*e2e1^2*ammu*amuq*x4^2*x5*xcp2*e1245+240*e2e1^2
*ammu*amuq*x4^2*x5*xcp2*e1235+96*e2e1^2*ammu*amuq*x4^2*x5*xcp2*e1234+96*e2e1^2*ammu*amuq*x4^2*x5*xcp1*e2345+96*e2e1^2*ammu*amuq*x4^2*x5*xcp1*e1345+384*e2e1^2*ammu*amuq*x4^2*x5*xcp1*e1245+96*e2e1^2*ammu*amuq*x4^2*x5*xcp1*e1235-96*e2e1^2*ammu*amuq*
x4^2*x5*xcp1*e1234-96*e2e1^2*ammu*amuq*x4^3*xcp4*e2345-192*e2e1^2*ammu*amuq*x4^3*xcp4*e1245-96*e2e1^2*ammu*amuq*x4^3*xcp4*e1235+96*e2e1^2*ammu*amuq*x4^3*xcp3*e2345-96*e2e1^2*ammu*amuq*x4^3*xcp3*e1235-96*e2e1^2*ammu*amuq*x4^3*xcp2*e2345+96*e2e1^2*
ammu*amuq*x4^3*xcp2*e1235+96*e2e1^2*ammu*amuq*x4^3*xcp1*e2345+192*e2e1^2*ammu*amuq*x4^3*xcp1*e1245+96*e2e1^2*ammu*amuq*x4^3*xcp1*e1235+144*e2e1^2*ammu*amuq*x3*x6*xcp4*e2345+384*e2e1^2*ammu*amuq*x3*x6*xcp4*e1345+336*e2e1^2*ammu*amuq*x3*x6*xcp4*e1235
+384*e2e1^2*ammu*amuq*x3*x6*xcp4*e1234+96*e2e1^2*ammu*amuq*x3*x6*xcp3*e2345-48*e2e1^2*ammu*amuq*x3*x6*xcp3*e1345+288*e2e1^2*ammu*amuq*x3*x6*xcp3*e1235-96*e2e1^2*ammu*amuq*x3*x6*xcp2*e2345+48*e2e1^2*ammu*amuq*x3*x6*xcp2*e1345-288*e2e1^2*ammu*amuq*x3
*x6*xcp2*e1235-144*e2e1^2*ammu*amuq*x3*x6*xcp1*e2345-384*e2e1^2*ammu*amuq*x3*x6*xcp1*e1345-336*e2e1^2*ammu*amuq*x3*x6*xcp1*e1235-384*e2e1^2*ammu*amuq*x3*x6*xcp1*e1234-192*e2e1^2*ammu*amuq*x3*x6^2*xcp4*e2345-144*e2e1^2*ammu*amuq*x3*x6^2*xcp4*e1345-
144*e2e1^2*ammu*amuq*x3*x6^2*xcp3*e2345-48*e2e1^2*ammu*amuq*x3*x6^2*xcp3*e1345+144*e2e1^2*ammu*amuq*x3*x6^2*xcp2*e2345+48*e2e1^2*ammu*amuq*x3*x6^2*xcp2*e1345+192*e2e1^2*ammu*amuq*x3*x6^2*xcp1*e2345+144*e2e1^2*ammu*amuq*x3*x6^2*xcp1*e1345-48*e2e1^2*
ammu*amuq*x3*x5*xcp4*e2345+240*e2e1^2*ammu*amuq*x3*x5*xcp4*e1345+384*e2e1^2*ammu*amuq*x3*x5*xcp4*e1245+336*e2e1^2*ammu*amuq*x3*x5*xcp4*e1235+48*e2e1^2*ammu*amuq*x3*x5*xcp4*e1234+96*e2e1^2*ammu*amuq*x3*x5*xcp3*e2345+192*e2e1^2*ammu*amuq*x3*x5*xcp3*
e1345+384*e2e1^2*ammu*amuq*x3*x5*xcp3*e1245+288*e2e1^2*ammu*amuq*x3*x5*xcp3*e1235-384*e2e1^2*ammu*amuq*x3*x5*xcp3*e1234-96*e2e1^2*ammu*amuq*x3*x5*xcp2*e2345-192*e2e1^2*ammu*amuq*x3*x5*xcp2*e1345-384*e2e1^2*ammu*amuq*x3*x5*xcp2*e1245-288*e2e1^2*ammu
*amuq*x3*x5*xcp2*e1235+384*e2e1^2*ammu*amuq*x3*x5*xcp2*e1234+48*e2e1^2*ammu*amuq*x3*x5*xcp1*e2345-240*e2e1^2*ammu*amuq*x3*x5*xcp1*e1345-384*e2e1^2*ammu*amuq*x3*x5*xcp1*e1245-336*e2e1^2*ammu*amuq*x3*x5*xcp1*e1235-48*e2e1^2*ammu*amuq*x3*x5*xcp1*e1234
-336*e2e1^2*ammu*amuq*x3*x5*x6*xcp4*e2345-192*e2e1^2*ammu*amuq*x3*x5*x6*xcp4*e1345-48*e2e1^2*ammu*amuq*x3*x5*x6*xcp4*e1234-432*e2e1^2*ammu*amuq*x3*x5*x6*xcp3*e2345-384*e2e1^2*ammu*amuq*x3*x5*x6*xcp3*e1345-144*e2e1^2*ammu*amuq*x3*x5*x6*xcp3*e1234+
432*e2e1^2*ammu*amuq*x3*x5*x6*xcp2*e2345+384*e2e1^2*ammu*amuq*x3*x5*x6*xcp2*e1345+144*e2e1^2*ammu*amuq*x3*x5*x6*xcp2*e1234+336*e2e1^2*ammu*amuq*x3*x5*x6*xcp1*e2345+192*e2e1^2*ammu*amuq*x3*x5*x6*xcp1*e1345+48*e2e1^2*ammu*amuq*x3*x5*x6*xcp1*e1234-144
*e2e1^2*ammu*amuq*x3*x5^2*xcp4*e2345-48*e2e1^2*ammu*amuq*x3*x5^2*xcp4*e1345-144*e2e1^2*ammu*amuq*x3*x5^2*xcp4*e1234-288*e2e1^2*ammu*amuq*x3*x5^2*xcp3*e2345-336*e2e1^2*ammu*amuq*x3*x5^2*xcp3*e1345-240*e2e1^2*ammu*amuq*x3*x5^2*xcp3*e1234+288*e2e1^2*
ammu*amuq*x3*x5^2*xcp2*e2345+336*e2e1^2*ammu*amuq*x3*x5^2*xcp2*e1345+240*e2e1^2*ammu*amuq*x3*x5^2*xcp2*e1234+144*e2e1^2*ammu*amuq*x3*x5^2*xcp1*e2345+48*e2e1^2*ammu*amuq*x3*x5^2*xcp1*e1345+144*e2e1^2*ammu*amuq*x3*x5^2*xcp1*e1234+96*e2e1^2*ammu*amuq*
x3*x4*xcp4*e2345-48*e2e1^2*ammu*amuq*x3*x4*xcp4*e1345+384*e2e1^2*ammu*amuq*x3*x4*xcp4*e1245+48*e2e1^2*ammu*amuq*x3*x4*xcp4*e1235-96*e2e1^2*ammu*amuq*x3*x4*xcp3*e2345+48*e2e1^2*ammu*amuq*x3*x4*xcp3*e1345+576*e2e1^2*ammu*amuq*x3*x4*xcp3*e1235+96*
e2e1^2*ammu*amuq*x3*x4*xcp2*e2345-48*e2e1^2*ammu*amuq*x3*x4*xcp2*e1345-576*e2e1^2*ammu*amuq*x3*x4*xcp2*e1235-96*e2e1^2*ammu*amuq*x3*x4*xcp1*e2345+48*e2e1^2*ammu*amuq*x3*x4*xcp1*e1345-384*e2e1^2*ammu*amuq*x3*x4*xcp1*e1245-48*e2e1^2*ammu*amuq*x3*x4*
xcp1*e1235-48*e2e1^2*ammu*amuq*x3*x4*x6*xcp4*e2345+96*e2e1^2*ammu*amuq*x3*x4*x6*xcp4*e1345-240*e2e1^2*ammu*amuq*x3*x4*x6*xcp4*e1235-192*e2e1^2*ammu*amuq*x3*x4*x6*xcp4*e1234-144*e2e1^2*ammu*amuq*x3*x4*x6*xcp3*e2345-96*e2e1^2*ammu*amuq*x3*x4*x6*xcp3*
e1345+144*e2e1^2*ammu*amuq*x3*x4*x6*xcp3*e1235+144*e2e1^2*ammu*amuq*x3*x4*x6*xcp2*e2345+96*e2e1^2*ammu*amuq*x3*x4*x6*xcp2*e1345-144*e2e1^2*ammu*amuq*x3*x4*x6*xcp2*e1235+48*e2e1^2*ammu*amuq*x3*x4*x6*xcp1*e2345-96*e2e1^2*ammu*amuq*x3*x4*x6*xcp1*e1345
+240*e2e1^2*ammu*amuq*x3*x4*x6*xcp1*e1235+192*e2e1^2*ammu*amuq*x3*x4*x6*xcp1*e1234-144*e2e1^2*ammu*amuq*x3*x4*x5*xcp4*e2345+96*e2e1^2*ammu*amuq*x3*x4*x5*xcp4*e1345-192*e2e1^2*ammu*amuq*x3*x4*x5*xcp4*e1245+48*e2e1^2*ammu*amuq*x3*x4*x5*xcp4*e1235+96*
e2e1^2*ammu*amuq*x3*x4*x5*xcp4*e1234+576*e2e1^2*ammu*amuq*x3*x4*x5*xcp3*e2345-96*e2e1^2*ammu*amuq*x3*x4*x5*xcp3*e1345+192*e2e1^2*ammu*amuq*x3*x4*x5*xcp3*e1245-336*e2e1^2*ammu*amuq*x3*x4*x5*xcp3*e1235+96*e2e1^2*ammu*amuq*x3*x4*x5*xcp3*e1234-576*
e2e1^2*ammu*amuq*x3*x4*x5*xcp2*e2345+96*e2e1^2*ammu*amuq*x3*x4*x5*xcp2*e1345-192*e2e1^2*ammu*amuq*x3*x4*x5*xcp2*e1245+336*e2e1^2*ammu*amuq*x3*x4*x5*xcp2*e1235-96*e2e1^2*ammu*amuq*x3*x4*x5*xcp2*e1234+144*e2e1^2*ammu*amuq*x3*x4*x5*xcp1*e2345-96*
e2e1^2*ammu*amuq*x3*x4*x5*xcp1*e1345+192*e2e1^2*ammu*amuq*x3*x4*x5*xcp1*e1245-48*e2e1^2*ammu*amuq*x3*x4*x5*xcp1*e1235-96*e2e1^2*ammu*amuq*x3*x4*x5*xcp1*e1234-192*e2e1^2*ammu*amuq*x3*x4^2*xcp4*e2345-192*e2e1^2*ammu*amuq*x3*x4^2*xcp4*e1245-96*e2e1^2*
ammu*amuq*x3*x4^2*xcp4*e1235+192*e2e1^2*ammu*amuq*x3*x4^2*xcp3*e2345-288*e2e1^2*ammu*amuq*x3*x4^2*xcp3*e1235-192*e2e1^2*ammu*amuq*x3*x4^2*xcp2*e2345+288*e2e1^2*ammu*amuq*x3*x4^2*xcp2*e1235+192*e2e1^2*ammu*amuq*x3*x4^2*xcp1*e2345+192*e2e1^2*ammu*
amuq*x3*x4^2*xcp1*e1245+96*e2e1^2*ammu*amuq*x3*x4^2*xcp1*e1235-48*e2e1^2*ammu*amuq*x3^2*x6*xcp4*e2345-48*e2e1^2*ammu*amuq*x3^2*x6*xcp3*e2345+48*e2e1^2*ammu*amuq*x3^2*x6*xcp2*e2345+48*e2e1^2*ammu*amuq*x3^2*x6*xcp1*e2345-144*e2e1^2*ammu*amuq*x3^2*x5*
xcp4*e2345+240*e2e1^2*ammu*amuq*x3^2*x5*xcp3*e2345+192*e2e1^2*ammu*amuq*x3^2*x5*xcp3*e1234-240*e2e1^2*ammu*amuq*x3^2*x5*xcp2*e2345-192*e2e1^2*ammu*amuq*x3^2*x5*xcp2*e1234+144*e2e1^2*ammu*amuq*x3^2*x5*xcp1*e2345-96*e2e1^2*ammu*amuq*x3^2*x4*xcp4*
e2345+96*e2e1^2*ammu*amuq*x3^2*x4*xcp3*e2345-192*e2e1^2*ammu*amuq*x3^2*x4*xcp3*e1235-96*e2e1^2*ammu*amuq*x3^2*x4*xcp2*e2345+192*e2e1^2*ammu*amuq*x3^2*x4*xcp2*e1235+96*e2e1^2*ammu*amuq*x3^2*x4*xcp1*e2345-96*e2e1^2*ammu*amuq*x1*xcp4*e1345-48*e2e1^2*
ammu*amuq*x1*xcp3*e1345+48*e2e1^2*ammu*amuq*x1*xcp2*e1345+96*e2e1^2*ammu*amuq*x1*xcp1*e1345+96*e2e1^2*ammu*amuq*x1*x6*xcp4*e2345+96*e2e1^2*ammu*amuq*x1*x6*xcp4*e1345+336*e2e1^2*ammu*amuq*x1*x6*xcp4*e1235+384*e2e1^2*ammu*amuq*x1*x6*xcp4*e1234+48*
e2e1^2*ammu*amuq*x1*x6*xcp3*e2345-48*e2e1^2*ammu*amuq*x1*x6*xcp3*e1345+336*e2e1^2*ammu*amuq*x1*x6*xcp3*e1235-48*e2e1^2*ammu*amuq*x1*x6*xcp2*e2345+48*e2e1^2*ammu*amuq*x1*x6*xcp2*e1345-336*e2e1^2*ammu*amuq*x1*x6*xcp2*e1235-96*e2e1^2*ammu*amuq*x1*x6*
xcp1*e2345-96*e2e1^2*ammu*amuq*x1*x6*xcp1*e1345-336*e2e1^2*ammu*amuq*x1*x6*xcp1*e1235-384*e2e1^2*ammu*amuq*x1*x6*xcp1*e1234+96*e2e1^2*ammu*amuq*x1*x6^2*xcp3*e1345-96*e2e1^2*ammu*amuq*x1*x6^2*xcp2*e1345+96*e2e1^2*ammu*amuq*x1*x5*xcp4*e2345+384*
e2e1^2*ammu*amuq*x1*x5*xcp4*e1345+384*e2e1^2*ammu*amuq*x1*x5*xcp4*e1245+336*e2e1^2*ammu*amuq*x1*x5*xcp4*e1235+192*e2e1^2*ammu*amuq*x1*x5*xcp4*e1234+48*e2e1^2*ammu*amuq*x1*x5*xcp3*e2345-144*e2e1^2*ammu*amuq*x1*x5*xcp3*e1345+384*e2e1^2*ammu*amuq*x1*
x5*xcp3*e1245+336*e2e1^2*ammu*amuq*x1*x5*xcp3*e1235-96*e2e1^2*ammu*amuq*x1*x5*xcp3*e1234-48*e2e1^2*ammu*amuq*x1*x5*xcp2*e2345+144*e2e1^2*ammu*amuq*x1*x5*xcp2*e1345-384*e2e1^2*ammu*amuq*x1*x5*xcp2*e1245-336*e2e1^2*ammu*amuq*x1*x5*xcp2*e1235+96*
e2e1^2*ammu*amuq*x1*x5*xcp2*e1234-96*e2e1^2*ammu*amuq*x1*x5*xcp1*e2345-384*e2e1^2*ammu*amuq*x1*x5*xcp1*e1345-384*e2e1^2*ammu*amuq*x1*x5*xcp1*e1245-336*e2e1^2*ammu*amuq*x1*x5*xcp1*e1235-192*e2e1^2*ammu*amuq*x1*x5*xcp1*e1234-96*e2e1^2*ammu*amuq*x1*x5
*x6*xcp4*e1345+480*e2e1^2*ammu*amuq*x1*x5*x6*xcp3*e1345-432*e2e1^2*ammu*amuq*x1*x5*x6*xcp3*e1234-480*e2e1^2*ammu*amuq*x1*x5*x6*xcp2*e1345+432*e2e1^2*ammu*amuq*x1*x5*x6*xcp2*e1234+96*e2e1^2*ammu*amuq*x1*x5*x6*xcp1*e1345-96*e2e1^2*ammu*amuq*x1*x5^2*
xcp4*e1345-144*e2e1^2*ammu*amuq*x1*x5^2*xcp4*e1234+384*e2e1^2*ammu*amuq*x1*x5^2*xcp3*e1345-384*e2e1^2*ammu*amuq*x1*x5^2*xcp3*e1234-384*e2e1^2*ammu*amuq*x1*x5^2*xcp2*e1345+384*e2e1^2*ammu*amuq*x1*x5^2*xcp2*e1234+96*e2e1^2*ammu*amuq*x1*x5^2*xcp1*
e1345+144*e2e1^2*ammu*amuq*x1*x5^2*xcp1*e1234+48*e2e1^2*ammu*amuq*x1*x4*xcp4*e2345+192*e2e1^2*ammu*amuq*x1*x4*xcp4*e1345+384*e2e1^2*ammu*amuq*x1*x4*xcp4*e1245+192*e2e1^2*ammu*amuq*x1*x4*xcp4*e1235+96*e2e1^2*ammu*amuq*x1*x4*xcp3*e2345-48*e2e1^2*ammu
*amuq*x1*x4*xcp3*e1345+96*e2e1^2*ammu*amuq*x1*x4*xcp3*e1235-96*e2e1^2*ammu*amuq*x1*x4*xcp2*e2345+48*e2e1^2*ammu*amuq*x1*x4*xcp2*e1345-96*e2e1^2*ammu*amuq*x1*x4*xcp2*e1235-48*e2e1^2*ammu*amuq*x1*x4*xcp1*e2345-192*e2e1^2*ammu*amuq*x1*x4*xcp1*e1345-
384*e2e1^2*ammu*amuq*x1*x4*xcp1*e1245-192*e2e1^2*ammu*amuq*x1*x4*xcp1*e1235-192*e2e1^2*ammu*amuq*x1*x4*x6*xcp4*e2345-192*e2e1^2*ammu*amuq*x1*x4*x6*xcp4*e1345-192*e2e1^2*ammu*amuq*x1*x4*x6*xcp4*e1235-192*e2e1^2*ammu*amuq*x1*x4*x6*xcp4*e1234-144*
e2e1^2*ammu*amuq*x1*x4*x6*xcp3*e2345+144*e2e1^2*ammu*amuq*x1*x4*x6*xcp3*e1345+528*e2e1^2*ammu*amuq*x1*x4*x6*xcp3*e1235+144*e2e1^2*ammu*amuq*x1*x4*x6*xcp2*e2345-144*e2e1^2*ammu*amuq*x1*x4*x6*xcp2*e1345-528*e2e1^2*ammu*amuq*x1*x4*x6*xcp2*e1235+192*
e2e1^2*ammu*amuq*x1*x4*x6*xcp1*e2345+192*e2e1^2*ammu*amuq*x1*x4*x6*xcp1*e1345+192*e2e1^2*ammu*amuq*x1*x4*x6*xcp1*e1235+192*e2e1^2*ammu*amuq*x1*x4*x6*xcp1*e1234-144*e2e1^2*ammu*amuq*x1*x4*x5*xcp4*e2345-96*e2e1^2*ammu*amuq*x1*x4*x5*xcp4*e1345-192*
e2e1^2*ammu*amuq*x1*x4*x5*xcp4*e1245+48*e2e1^2*ammu*amuq*x1*x4*x5*xcp4*e1235-288*e2e1^2*ammu*amuq*x1*x4*x5*xcp3*e2345-192*e2e1^2*ammu*amuq*x1*x4*x5*xcp3*e1345+192*e2e1^2*ammu*amuq*x1*x4*x5*xcp3*e1245+192*e2e1^2*ammu*amuq*x1*x4*x5*xcp3*e1235-336*
e2e1^2*ammu*amuq*x1*x4*x5*xcp3*e1234+288*e2e1^2*ammu*amuq*x1*x4*x5*xcp2*e2345+192*e2e1^2*ammu*amuq*x1*x4*x5*xcp2*e1345-192*e2e1^2*ammu*amuq*x1*x4*x5*xcp2*e1245-192*e2e1^2*ammu*amuq*x1*x4*x5*xcp2*e1235+336*e2e1^2*ammu*amuq*x1*x4*x5*xcp2*e1234+144*
e2e1^2*ammu*amuq*x1*x4*x5*xcp1*e2345+96*e2e1^2*ammu*amuq*x1*x4*x5*xcp1*e1345+192*e2e1^2*ammu*amuq*x1*x4*x5*xcp1*e1245-48*e2e1^2*ammu*amuq*x1*x4*x5*xcp1*e1235+96*e2e1^2*ammu*amuq*x1*x4^2*xcp4*e1345-192*e2e1^2*ammu*amuq*x1*x4^2*xcp4*e1245-192*e2e1^2*
ammu*amuq*x1*x4^2*xcp4*e1235-144*e2e1^2*ammu*amuq*x1*x4^2*xcp3*e2345-96*e2e1^2*ammu*amuq*x1*x4^2*xcp3*e1345+144*e2e1^2*ammu*amuq*x1*x4^2*xcp3*e1235+144*e2e1^2*ammu*amuq*x1*x4^2*xcp2*e2345+96*e2e1^2*ammu*amuq*x1*x4^2*xcp2*e1345-144*e2e1^2*ammu*amuq*
x1*x4^2*xcp2*e1235-96*e2e1^2*ammu*amuq*x1*x4^2*xcp1*e1345+192*e2e1^2*ammu*amuq*x1*x4^2*xcp1*e1245+192*e2e1^2*ammu*amuq*x1*x4^2*xcp1*e1235+48*e2e1^2*ammu*amuq*x1*x3*xcp4*e2345+288*e2e1^2*ammu*amuq*x1*x3*xcp4*e1345+96*e2e1^2*ammu*amuq*x1*x3*xcp3*
e2345-144*e2e1^2*ammu*amuq*x1*x3*xcp3*e1345-48*e2e1^2*ammu*amuq*x1*x3*xcp3*e1235-96*e2e1^2*ammu*amuq*x1*x3*xcp2*e2345+144*e2e1^2*ammu*amuq*x1*x3*xcp2*e1345+48*e2e1^2*ammu*amuq*x1*x3*xcp2*e1235-48*e2e1^2*ammu*amuq*x1*x3*xcp1*e2345-288*e2e1^2*ammu*
amuq*x1*x3*xcp1*e1345-192*e2e1^2*ammu*amuq*x1*x3*x6*xcp4*e2345-96*e2e1^2*ammu*amuq*x1*x3*x6*xcp4*e1345-144*e2e1^2*ammu*amuq*x1*x3*x6*xcp3*e2345+48*e2e1^2*ammu*amuq*x1*x3*x6*xcp3*e1345+144*e2e1^2*ammu*amuq*x1*x3*x6*xcp2*e2345-48*e2e1^2*ammu*amuq*x1*
x3*x6*xcp2*e1345+192*e2e1^2*ammu*amuq*x1*x3*x6*xcp1*e2345+96*e2e1^2*ammu*amuq*x1*x3*x6*xcp1*e1345-144*e2e1^2*ammu*amuq*x1*x3*x5*xcp4*e2345-48*e2e1^2*ammu*amuq*x1*x3*x5*xcp4*e1234-288*e2e1^2*ammu*amuq*x1*x3*x5*xcp3*e2345-240*e2e1^2*ammu*amuq*x1*x3*
x5*xcp3*e1345-96*e2e1^2*ammu*amuq*x1*x3*x5*xcp3*e1234+288*e2e1^2*ammu*amuq*x1*x3*x5*xcp2*e2345+240*e2e1^2*ammu*amuq*x1*x3*x5*xcp2*e1345+96*e2e1^2*ammu*amuq*x1*x3*x5*xcp2*e1234+144*e2e1^2*ammu*amuq*x1*x3*x5*xcp1*e2345+48*e2e1^2*ammu*amuq*x1*x3*x5*
xcp1*e1234-48*e2e1^2*ammu*amuq*x1*x3*x4*xcp4*e2345+96*e2e1^2*ammu*amuq*x1*x3*x4*xcp4*e1345-48*e2e1^2*ammu*amuq*x1*x3*x4*xcp4*e1235-240*e2e1^2*ammu*amuq*x1*x3*x4*xcp3*e2345-96*e2e1^2*ammu*amuq*x1*x3*x4*xcp3*e1345+240*e2e1^2*ammu*amuq*x1*x3*x4*xcp2*
e2345+96*e2e1^2*ammu*amuq*x1*x3*x4*xcp2*e1345+48*e2e1^2*ammu*amuq*x1*x3*x4*xcp1*e2345-96*e2e1^2*ammu*amuq*x1*x3*x4*xcp1*e1345+48*e2e1^2*ammu*amuq*x1*x3*x4*xcp1*e1235-48*e2e1^2*ammu*amuq*x1*x3^2*xcp4*e2345-96*e2e1^2*ammu*amuq*x1*x3^2*xcp3*e2345+96*
e2e1^2*ammu*amuq*x1*x3^2*xcp2*e2345+48*e2e1^2*ammu*amuq*x1*x3^2*xcp1*e2345-48*e2e1^2*ammu*amuq*x1^2*xcp3*e1345+48*e2e1^2*ammu*amuq*x1^2*xcp2*e1345+48*e2e1^2*ammu*amuq*x1^2*x6*xcp3*e1345-48*e2e1^2*ammu*amuq*x1^2*x6*xcp2*e1345-48*e2e1^2*ammu*amuq*
x1^2*x5*xcp4*e1345+192*e2e1^2*ammu*amuq*x1^2*x5*xcp3*e1345-192*e2e1^2*ammu*amuq*x1^2*x5*xcp3*e1234-192*e2e1^2*ammu*amuq*x1^2*x5*xcp2*e1345+192*e2e1^2*ammu*amuq*x1^2*x5*xcp2*e1234+48*e2e1^2*ammu*amuq*x1^2*x5*xcp1*e1345+144*e2e1^2*ammu*amuq*x1^2*x4*
xcp3*e1345+192*e2e1^2*ammu*amuq*x1^2*x4*xcp3*e1235-144*e2e1^2*ammu*amuq*x1^2*x4*xcp2*e1345-192*e2e1^2*ammu*amuq*x1^2*x4*xcp2*e1235+48*e2e1^2*ammu*amuq*x1^2*x3*xcp4*e1345+96*e2e1^2*ammu*amuq*x1^2*x3*xcp3*e1345-96*e2e1^2*ammu*amuq*x1^2*x3*xcp2*e1345-
48*e2e1^2*ammu*amuq*x1^2*x3*xcp1*e1345-192*e2e1^2*ammu*amuq*ammu2*amuq2*x6*xcp4-192*e2e1^2*ammu*amuq*ammu2*amuq2*x6*xcp3-192*e2e1^2*ammu*amuq*ammu2*amuq2*x6*xcp2-192*e2e1^2*ammu*amuq*ammu2*amuq2*x6*xcp1+192*e2e1^2*ammu*amuq*ammu2*amuq2*x6^2*xcp4+
192*e2e1^2*ammu*amuq*ammu2*amuq2*x6^2*xcp3+192*e2e1^2*ammu*amuq*ammu2*amuq2*x6^2*xcp2+192*e2e1^2*ammu*amuq*ammu2*amuq2*x6^2*xcp1+192*e2e1^2*ammu*amuq*ammu2*amuq2*x5*x6*xcp4+192*e2e1^2*ammu*amuq*ammu2*amuq2*x5*x6*xcp3+192*e2e1^2*ammu*amuq*ammu2*
amuq2*x5*x6*xcp2+192*e2e1^2*ammu*amuq*ammu2*amuq2*x5*x6*xcp1-576*e2e1^2*ammu*amuq*ammu2*amuq2*x4*xcp4+192*e2e1^2*ammu*amuq*ammu2*amuq2*x4*xcp3+192*e2e1^2*ammu*amuq*ammu2*amuq2*x4*xcp2-576*e2e1^2*ammu*amuq*ammu2*amuq2*x4*xcp1+192*e2e1^2*ammu*amuq*
ammu2*amuq2*x4*x6*xcp4-960*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x6*xcp3-960*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x6*xcp2+192*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x6*xcp1-192*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x6^2*xcp4+192*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x6^2*xcp3+
192*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x6^2*xcp2-192*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x6^2*xcp1+576*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x5*xcp4-960*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x5*xcp3-960*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x5*xcp2+576*e2e1^2*ammu*amuq*
ammu2*amuq2*x4*x5*xcp1-576*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x5*x6*xcp4+576*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x5*x6*xcp3+576*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x5*x6*xcp2-576*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x5*x6*xcp1-384*e2e1^2*ammu*amuq*ammu2*amuq2*x4*
x5^2*xcp4+384*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x5^2*xcp3+384*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x5^2*xcp2-384*e2e1^2*ammu*amuq*ammu2*amuq2*x4*x5^2*xcp1+768*e2e1^2*ammu*amuq*ammu2*amuq2*x4^2*xcp4+384*e2e1^2*ammu*amuq*ammu2*amuq2*x4^2*xcp3+384*e2e1^2*
ammu*amuq*ammu2*amuq2*x4^2*xcp2+768*e2e1^2*ammu*amuq*ammu2*amuq2*x4^2*xcp1+384*e2e1^2*ammu*amuq*ammu2*amuq2*x4^2*x6*xcp3+384*e2e1^2*ammu*amuq*ammu2*amuq2*x4^2*x6*xcp2-192*e2e1^2*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp4+192*e2e1^2*ammu*amuq*ammu2*amuq2*
x4^2*x5*xcp3+192*e2e1^2*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp2-192*e2e1^2*ammu*amuq*ammu2*amuq2*x4^2*x5*xcp1-192*e2e1^2*ammu*amuq*ammu2*amuq2*x4^3*xcp4-192*e2e1^2*ammu*amuq*ammu2*amuq2*x4^3*xcp3-192*e2e1^2*ammu*amuq*ammu2*amuq2*x4^3*xcp2-192*e2e1^2*
ammu*amuq*ammu2*amuq2*x4^3*xcp1-192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x6*xcp4-192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x6*xcp3-192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x6*xcp2-192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x6*xcp1-192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4*
xcp4+576*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4*xcp3+576*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4*xcp2-192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4*xcp1+192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4*x6*xcp4-192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4*x6*xcp3-192*e2e1^2*ammu*
amuq*ammu2*amuq2*x3*x4*x6*xcp2+192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4*x6*xcp1+384*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4*x5*xcp4-384*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4*x5*xcp3-384*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4*x5*xcp2+384*e2e1^2*ammu*amuq*ammu2*
amuq2*x3*x4*x5*xcp1+192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4^2*xcp4-192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4^2*xcp3-192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4^2*xcp2+192*e2e1^2*ammu*amuq*ammu2*amuq2*x3*x4^2*xcp1+192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x6*xcp4+
192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x6*xcp3+192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x6*xcp2+192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x6*xcp1+192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*xcp4-576*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*xcp3-576*e2e1^2*ammu*amuq*ammu2*
amuq2*x1*x4*xcp2+192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*xcp1-192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*x6*xcp4+192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*x6*xcp3+192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*x6*xcp2-192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*x6*xcp1
-384*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*x5*xcp4+384*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*x5*xcp3+384*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*x5*xcp2-384*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4*x5*xcp1-192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4^2*xcp4+192*e2e1^2*
ammu*amuq*ammu2*amuq2*x1*x4^2*xcp3+192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4^2*xcp2-192*e2e1^2*ammu*amuq*ammu2*amuq2*x1*x4^2*xcp1-3648*e2e1^2*ammu*amuq*ammu2^2*x6*xcp4-960*e2e1^2*ammu*amuq*ammu2^2*x6*xcp3-960*e2e1^2*ammu*amuq*ammu2^2*x6*xcp2-3648*
e2e1^2*ammu*amuq*ammu2^2*x6*xcp1+2880*e2e1^2*ammu*amuq*ammu2^2*x6^2*xcp4+2880*e2e1^2*ammu*amuq*ammu2^2*x6^2*xcp1-384*e2e1^2*ammu*amuq*ammu2^2*x6^3*xcp4+192*e2e1^2*ammu*amuq*ammu2^2*x6^3*xcp3+192*e2e1^2*ammu*amuq*ammu2^2*x6^3*xcp2-384*e2e1^2*ammu*
amuq*ammu2^2*x6^3*xcp1-4224*e2e1^2*ammu*amuq*ammu2^2*x5*xcp4-768*e2e1^2*ammu*amuq*ammu2^2*x5*xcp3-768*e2e1^2*ammu*amuq*ammu2^2*x5*xcp2-4224*e2e1^2*ammu*amuq*ammu2^2*x5*xcp1+7488*e2e1^2*ammu*amuq*ammu2^2*x5*x6*xcp4-960*e2e1^2*ammu*amuq*ammu2^2*x5*x6
*xcp3-960*e2e1^2*ammu*amuq*ammu2^2*x5*x6*xcp2+7488*e2e1^2*ammu*amuq*ammu2^2*x5*x6*xcp1-2304*e2e1^2*ammu*amuq*ammu2^2*x5*x6^2*xcp4+960*e2e1^2*ammu*amuq*ammu2^2*x5*x6^2*xcp3+960*e2e1^2*ammu*amuq*ammu2^2*x5*x6^2*xcp2-2304*e2e1^2*ammu*amuq*ammu2^2*x5*
x6^2*xcp1+5376*e2e1^2*ammu*amuq*ammu2^2*x5^2*xcp4-1152*e2e1^2*ammu*amuq*ammu2^2*x5^2*xcp3-1152*e2e1^2*ammu*amuq*ammu2^2*x5^2*xcp2+5376*e2e1^2*ammu*amuq*ammu2^2*x5^2*xcp1-3456*e2e1^2*ammu*amuq*ammu2^2*x5^2*x6*xcp4+1920*e2e1^2*ammu*amuq*ammu2^2*x5^2*
x6*xcp3+1920*e2e1^2*ammu*amuq*ammu2^2*x5^2*x6*xcp2-3456*e2e1^2*ammu*amuq*ammu2^2*x5^2*x6*xcp1-1920*e2e1^2*ammu*amuq*ammu2^2*x5^3*xcp4+1152*e2e1^2*ammu*amuq*ammu2^2*x5^3*xcp3+1152*e2e1^2*ammu*amuq*ammu2^2*x5^3*xcp2-1920*e2e1^2*ammu*amuq*ammu2^2*x5^3
*xcp1+192*e2e1^2*ammu*amuq*ammu2^2*x4*xcp4+192*e2e1^2*ammu*amuq*ammu2^2*x4*xcp3+192*e2e1^2*ammu*amuq*ammu2^2*x4*xcp2+192*e2e1^2*ammu*amuq*ammu2^2*x4*xcp1+2112*e2e1^2*ammu*amuq*ammu2^2*x4*x6*xcp4+192*e2e1^2*ammu*amuq*ammu2^2*x4*x6*xcp3+192*e2e1^2*
ammu*amuq*ammu2^2*x4*x6*xcp2+2112*e2e1^2*ammu*amuq*ammu2^2*x4*x6*xcp1-192*e2e1^2*ammu*amuq*ammu2^2*x4*x6^2*xcp4-768*e2e1^2*ammu*amuq*ammu2^2*x4*x6^2*xcp3-768*e2e1^2*ammu*amuq*ammu2^2*x4*x6^2*xcp2-192*e2e1^2*ammu*amuq*ammu2^2*x4*x6^2*xcp1+3648*
e2e1^2*ammu*amuq*ammu2^2*x4*x5*xcp4+192*e2e1^2*ammu*amuq*ammu2^2*x4*x5*xcp3+192*e2e1^2*ammu*amuq*ammu2^2*x4*x5*xcp2+3648*e2e1^2*ammu*amuq*ammu2^2*x4*x5*xcp1-1344*e2e1^2*ammu*amuq*ammu2^2*x4*x5*x6*xcp4+192*e2e1^2*ammu*amuq*ammu2^2*x4*x5*x6*xcp3+192*
e2e1^2*ammu*amuq*ammu2^2*x4*x5*x6*xcp2-1344*e2e1^2*ammu*amuq*ammu2^2*x4*x5*x6*xcp1-2304*e2e1^2*ammu*amuq*ammu2^2*x4*x5^2*xcp4+768*e2e1^2*ammu*amuq*ammu2^2*x4*x5^2*xcp3+768*e2e1^2*ammu*amuq*ammu2^2*x4*x5^2*xcp2-2304*e2e1^2*ammu*amuq*ammu2^2*x4*x5^2*
xcp1+384*e2e1^2*ammu*amuq*ammu2^2*x4^2*xcp4-192*e2e1^2*ammu*amuq*ammu2^2*x4^2*xcp3-192*e2e1^2*ammu*amuq*ammu2^2*x4^2*xcp2+384*e2e1^2*ammu*amuq*ammu2^2*x4^2*xcp1-384*e2e1^2*ammu*amuq*ammu2^2*x4^2*x6*xcp4+192*e2e1^2*ammu*amuq*ammu2^2*x4^2*x6*xcp3+192
*e2e1^2*ammu*amuq*ammu2^2*x4^2*x6*xcp2-384*e2e1^2*ammu*amuq*ammu2^2*x4^2*x6*xcp1-1344*e2e1^2*ammu*amuq*ammu2^2*x4^2*x5*xcp4-1344*e2e1^2*ammu*amuq*ammu2^2*x4^2*x5*xcp1-192*e2e1^2*ammu*amuq*ammu2^2*x4^3*xcp4-192*e2e1^2*ammu*amuq*ammu2^2*x4^3*xcp1-
1344*e2e1^2*ammu*amuq*ammu2^2*x3*x6*xcp4-192*e2e1^2*ammu*amuq*ammu2^2*x3*x6*xcp3-192*e2e1^2*ammu*amuq*ammu2^2*x3*x6*xcp2-1344*e2e1^2*ammu*amuq*ammu2^2*x3*x6*xcp1+768*e2e1^2*ammu*amuq*ammu2^2*x3*x6^2*xcp4-192*e2e1^2*ammu*amuq*ammu2^2*x3*x6^2*xcp3-
192*e2e1^2*ammu*amuq*ammu2^2*x3*x6^2*xcp2+768*e2e1^2*ammu*amuq*ammu2^2*x3*x6^2*xcp1-1152*e2e1^2*ammu*amuq*ammu2^2*x3*x5*xcp4-1152*e2e1^2*ammu*amuq*ammu2^2*x3*x5*xcp1+1920*e2e1^2*ammu*amuq*ammu2^2*x3*x5*x6*xcp4-384*e2e1^2*ammu*amuq*ammu2^2*x3*x5*x6*
xcp3-384*e2e1^2*ammu*amuq*ammu2^2*x3*x5*x6*xcp2+1920*e2e1^2*ammu*amuq*ammu2^2*x3*x5*x6*xcp1+1152*e2e1^2*ammu*amuq*ammu2^2*x3*x5^2*xcp4-384*e2e1^2*ammu*amuq*ammu2^2*x3*x5^2*xcp3-384*e2e1^2*ammu*amuq*ammu2^2*x3*x5^2*xcp2+1152*e2e1^2*ammu*amuq*ammu2^2
*x3*x5^2*xcp1+576*e2e1^2*ammu*amuq*ammu2^2*x3*x4*xcp4-192*e2e1^2*ammu*amuq*ammu2^2*x3*x4*xcp3-192*e2e1^2*ammu*amuq*ammu2^2*x3*x4*xcp2+576*e2e1^2*ammu*amuq*ammu2^2*x3*x4*xcp1+192*e2e1^2*ammu*amuq*ammu2^2*x3*x4*x6*xcp4+192*e2e1^2*ammu*amuq*ammu2^2*x3
*x4*x6*xcp3+192*e2e1^2*ammu*amuq*ammu2^2*x3*x4*x6*xcp2+192*e2e1^2*ammu*amuq*ammu2^2*x3*x4*x6*xcp1-192*e2e1^2*ammu*amuq*ammu2^2*x3*x4^2*xcp4-192*e2e1^2*ammu*amuq*ammu2^2*x3*x4^2*xcp1+576*e2e1^2*ammu*amuq*ammu2^2*x1*x6*xcp4+960*e2e1^2*ammu*amuq*
ammu2^2*x1*x6*xcp3+960*e2e1^2*ammu*amuq*ammu2^2*x1*x6*xcp2+576*e2e1^2*ammu*amuq*ammu2^2*x1*x6*xcp1-576*e2e1^2*ammu*amuq*ammu2^2*x1*x6^2*xcp3-576*e2e1^2*ammu*amuq*ammu2^2*x1*x6^2*xcp2+384*e2e1^2*ammu*amuq*ammu2^2*x1*x5*xcp4+768*e2e1^2*ammu*amuq*
ammu2^2*x1*x5*xcp3+768*e2e1^2*ammu*amuq*ammu2^2*x1*x5*xcp2+384*e2e1^2*ammu*amuq*ammu2^2*x1*x5*xcp1-384*e2e1^2*ammu*amuq*ammu2^2*x1*x5*x6*xcp4-1152*e2e1^2*ammu*amuq*ammu2^2*x1*x5*x6*xcp3-1152*e2e1^2*ammu*amuq*ammu2^2*x1*x5*x6*xcp2-384*e2e1^2*ammu*
amuq*ammu2^2*x1*x5*x6*xcp1-384*e2e1^2*ammu*amuq*ammu2^2*x1*x5^2*xcp4-384*e2e1^2*ammu*amuq*ammu2^2*x1*x5^2*xcp3-384*e2e1^2*ammu*amuq*ammu2^2*x1*x5^2*xcp2-384*e2e1^2*ammu*amuq*ammu2^2*x1*x5^2*xcp1-576*e2e1^2*ammu*amuq*ammu2^2*x1*x4*xcp4+192*e2e1^2*
ammu*amuq*ammu2^2*x1*x4*xcp3+192*e2e1^2*ammu*amuq*ammu2^2*x1*x4*xcp2-576*e2e1^2*ammu*amuq*ammu2^2*x1*x4*xcp1+576*e2e1^2*ammu*amuq*ammu2^2*x1*x4*x6*xcp4-960*e2e1^2*ammu*amuq*ammu2^2*x1*x4*x6*xcp3-960*e2e1^2*ammu*amuq*ammu2^2*x1*x4*x6*xcp2+576*e2e1^2
*ammu*amuq*ammu2^2*x1*x4*x6*xcp1+768*e2e1^2*ammu*amuq*ammu2^2*x1*x4*x5*xcp4-768*e2e1^2*ammu*amuq*ammu2^2*x1*x4*x5*xcp3-768*e2e1^2*ammu*amuq*ammu2^2*x1*x4*x5*xcp2+768*e2e1^2*ammu*amuq*ammu2^2*x1*x4*x5*xcp1+192*e2e1^2*ammu*amuq*ammu2^2*x1*x4^2*xcp4+
192*e2e1^2*ammu*amuq*ammu2^2*x1*x4^2*xcp1+768*e2e1^2*ammu*amuq*ammu2^2*x1*x3*x6*xcp4-768*e2e1^2*ammu*amuq*ammu2^2*x1*x3*x6*xcp3-768*e2e1^2*ammu*amuq*ammu2^2*x1*x3*x6*xcp2+768*e2e1^2*ammu*amuq*ammu2^2*x1*x3*x6*xcp1+768*e2e1^2*ammu*amuq*ammu2^2*x1*x3
*x5*xcp4-768*e2e1^2*ammu*amuq*ammu2^2*x1*x3*x5*xcp3-768*e2e1^2*ammu*amuq*ammu2^2*x1*x3*x5*xcp2+768*e2e1^2*ammu*amuq*ammu2^2*x1*x3*x5*xcp1-576*e2e1^2*ammu*amuq*amel2*amuq2*x4*xcp4-576*e2e1^2*ammu*amuq*amel2*amuq2*x4*xcp3-576*e2e1^2*ammu*amuq*amel2*
amuq2*x4*xcp2-576*e2e1^2*ammu*amuq*amel2*amuq2*x4*xcp1+576*e2e1^2*ammu*amuq*amel2*amuq2*x4*x6*xcp4+576*e2e1^2*ammu*amuq*amel2*amuq2*x4*x6*xcp3+576*e2e1^2*ammu*amuq*amel2*amuq2*x4*x6*xcp2+576*e2e1^2*ammu*amuq*amel2*amuq2*x4*x6*xcp1+576*e2e1^2*ammu*
amuq*amel2*amuq2*x4*x5*xcp4+576*e2e1^2*ammu*amuq*amel2*amuq2*x4*x5*xcp3+576*e2e1^2*ammu*amuq*amel2*amuq2*x4*x5*xcp2+576*e2e1^2*ammu*amuq*amel2*amuq2*x4*x5*xcp1+1728*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*xcp4+576*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*xcp3+
576*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*xcp2+1728*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*xcp1-576*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*x6*xcp4+576*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*x6*xcp3+576*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*x6*xcp2-576*e2e1^2*ammu*amuq*
amel2*amuq2*x4^2*x6*xcp1-576*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*x5*xcp4+576*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*x5*xcp3+576*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*x5*xcp2-576*e2e1^2*ammu*amuq*amel2*amuq2*x4^2*x5*xcp1-576*e2e1^2*ammu*amuq*amel2*amuq2*x4^3*
xcp4-576*e2e1^2*ammu*amuq*amel2*amuq2*x4^3*xcp3-576*e2e1^2*ammu*amuq*amel2*amuq2*x4^3*xcp2-576*e2e1^2*ammu*amuq*amel2*amuq2*x4^3*xcp1-576*e2e1^2*ammu*amuq*amel2*amuq2*x3*x4*xcp4-576*e2e1^2*ammu*amuq*amel2*amuq2*x3*x4*xcp3-576*e2e1^2*ammu*amuq*amel2
*amuq2*x3*x4*xcp2-576*e2e1^2*ammu*amuq*amel2*amuq2*x3*x4*xcp1+576*e2e1^2*ammu*amuq*amel2*amuq2*x3*x4^2*xcp4-576*e2e1^2*ammu*amuq*amel2*amuq2*x3*x4^2*xcp3-576*e2e1^2*ammu*amuq*amel2*amuq2*x3*x4^2*xcp2+576*e2e1^2*ammu*amuq*amel2*amuq2*x3*x4^2*xcp1+
576*e2e1^2*ammu*amuq*amel2*amuq2*x1*x4*xcp4+576*e2e1^2*ammu*amuq*amel2*amuq2*x1*x4*xcp3+576*e2e1^2*ammu*amuq*amel2*amuq2*x1*x4*xcp2+576*e2e1^2*ammu*amuq*amel2*amuq2*x1*x4*xcp1-576*e2e1^2*ammu*amuq*amel2*amuq2*x1*x4^2*xcp4+576*e2e1^2*ammu*amuq*amel2
*amuq2*x1*x4^2*xcp3+576*e2e1^2*ammu*amuq*amel2*amuq2*x1*x4^2*xcp2-576*e2e1^2*ammu*amuq*amel2*amuq2*x1*x4^2*xcp1+768*e2e1^2*ammu*amuq*amel2*ammu2*xcp4+768*e2e1^2*ammu*amuq*amel2*ammu2*xcp1-4992*e2e1^2*ammu*amuq*amel2*ammu2*x6*xcp4-3264*e2e1^2*ammu*
amuq*amel2*ammu2*x6*xcp3-3264*e2e1^2*ammu*amuq*amel2*ammu2*x6*xcp2-4992*e2e1^2*ammu*amuq*amel2*ammu2*x6*xcp1+2880*e2e1^2*ammu*amuq*amel2*ammu2*x6^2*xcp4+1344*e2e1^2*ammu*amuq*amel2*ammu2*x6^2*xcp3+1344*e2e1^2*ammu*amuq*amel2*ammu2*x6^2*xcp2+2880*
e2e1^2*ammu*amuq*amel2*ammu2*x6^2*xcp1-384*e2e1^2*ammu*amuq*amel2*ammu2*x6^3*xcp4+192*e2e1^2*ammu*amuq*amel2*ammu2*x6^3*xcp3+192*e2e1^2*ammu*amuq*amel2*ammu2*x6^3*xcp2-384*e2e1^2*ammu*amuq*amel2*ammu2*x6^3*xcp1-7680*e2e1^2*ammu*amuq*amel2*ammu2*x5*
xcp4-4416*e2e1^2*ammu*amuq*amel2*ammu2*x5*xcp3-4416*e2e1^2*ammu*amuq*amel2*ammu2*x5*xcp2-7680*e2e1^2*ammu*amuq*amel2*ammu2*x5*xcp1+6336*e2e1^2*ammu*amuq*amel2*ammu2*x5*x6*xcp4+960*e2e1^2*ammu*amuq*amel2*ammu2*x5*x6*xcp3+960*e2e1^2*ammu*amuq*amel2*
ammu2*x5*x6*xcp2+6336*e2e1^2*ammu*amuq*amel2*ammu2*x5*x6*xcp1-1344*e2e1^2*ammu*amuq*amel2*ammu2*x5*x6^2*xcp4+1152*e2e1^2*ammu*amuq*amel2*ammu2*x5*x6^2*xcp3+1152*e2e1^2*ammu*amuq*amel2*ammu2*x5*x6^2*xcp2-1344*e2e1^2*ammu*amuq*amel2*ammu2*x5*x6^2*
xcp1+5760*e2e1^2*ammu*amuq*amel2*ammu2*x5^2*xcp4+768*e2e1^2*ammu*amuq*amel2*ammu2*x5^2*xcp3+768*e2e1^2*ammu*amuq*amel2*ammu2*x5^2*xcp2+5760*e2e1^2*ammu*amuq*amel2*ammu2*x5^2*xcp1-2112*e2e1^2*ammu*amuq*amel2*ammu2*x5^2*x6*xcp4+2304*e2e1^2*ammu*amuq*
amel2*ammu2*x5^2*x6*xcp3+2304*e2e1^2*ammu*amuq*amel2*ammu2*x5^2*x6*xcp2-2112*e2e1^2*ammu*amuq*amel2*ammu2*x5^2*x6*xcp1-1152*e2e1^2*ammu*amuq*amel2*ammu2*x5^3*xcp4+1344*e2e1^2*ammu*amuq*amel2*ammu2*x5^3*xcp3+1344*e2e1^2*ammu*amuq*amel2*ammu2*x5^3
";

const INPUT_REAL: [f64; 29] = [
    5., 2., 1., 3., 5., 8., 1.2, 1.3, 4.5, 6.7, 2.5, 1.7, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6,
    2.7, 2.8, 2.9, 3.0, 3.1, 3.2, 3.3, 3.4, 3.5,
];
const OUT_REAL: f64 = -543843317.1308352;

const INPUT_COMPLEX: [Complex<f64>; 29] = [
    Complex::new(5., 1.0),
    Complex::new(2.0, 2.0),
    Complex::new(1.0, 3.0),
    Complex::new(3.0, 4.0),
    Complex::new(5.0, 5.0),
    Complex::new(8.0, 6.0),
    Complex::new(1.2, 7.0),
    Complex::new(1.3, 8.0),
    Complex::new(4.5, 9.0),
    Complex::new(6.7, 10.0),
    Complex::new(2.5, 11.0),
    Complex::new(1.7, 12.0),
    Complex::new(1.9, 13.0),
    Complex::new(2.0, 14.0),
    Complex::new(2.1, 15.0),
    Complex::new(2.2, 16.0),
    Complex::new(2.3, 17.0),
    Complex::new(2.4, 18.0),
    Complex::new(2.5, 19.0),
    Complex::new(2.6, 20.0),
    Complex::new(2.7, 21.0),
    Complex::new(2.8, 22.0),
    Complex::new(2.9, 23.0),
    Complex::new(3.0, 24.0),
    Complex::new(3.1, 25.0),
    Complex::new(3.2, 26.0),
    Complex::new(3.3, 27.0),
    Complex::new(3.4, 28.0),
    Complex::new(3.5, 29.0),
];

const OUT_COMPLEX: Complex<f64> = Complex::new(-504703063799979., 19778627601725736.);

fn generate_evaluator() -> ExpressionEvaluator<Complex<Rational>> {
    let params = vec![
        "alpha", "amuq", "ammu", "xcp1", "e1245", "xcp4", "e3e2", "e1234", "e2345", "e1235",
        "e1345", "amel2", "e2e1", "e5e2", "e4e2", "e3e1", "e4e1", "e5e1", "ammu2", "amuq2", "e5e3",
        "e4e3", "x5", "x6", "x1", "x3", "x4", "xcp3", "xcp2",
    ];

    let params = params.iter().map(|s| parse!(s)).collect::<Vec<_>>();

    std::thread::Builder::new()
        .stack_size(16 * 1024 * 1024) // use a larger stack size as in debug mode the default stack size is too small
        .spawn(move || {
            parse!(F13)
                .evaluator(&params)
                .horner_iterations(1)
                .cores(1)
                .verbose(false)
                .build()
                .unwrap()
        })
        .unwrap()
        .join()
        .unwrap()
}

#[test]
fn evaluator_real() {
    let mut evaluator = generate_evaluator().map_coeff(&|x| x.re.to_f64());
    let mut out = vec![0.];
    evaluator.evaluate(&INPUT_REAL, &mut out);
    assert!((out[0] - OUT_REAL).abs() / OUT_REAL < 1e-10);
}

#[test]
fn evaluator_complex() {
    let mut evaluator =
        generate_evaluator().map_coeff(&|x| Complex::new(x.re.to_f64(), x.im.to_f64()));
    let mut out = vec![Complex::new(0., 0.)];
    evaluator.evaluate(&INPUT_COMPLEX, &mut out);
    assert!(
        (out[0] - OUT_COMPLEX).re.abs() / OUT_COMPLEX.re.abs() < 1e-10,
        "{}",
        out[0].re
    );
}

#[test]
fn gcc_compiled_evaluator_real() {
    let evaluator = generate_evaluator().map_coeff(&|x| x.re.to_f64());
    let mut compiled_evaluator = evaluator
        .export_cpp::<f64>(
            "gcc_compiled_evaluator_real.cpp",
            "gcc_compiled_evaluator_real",
            ExportSettings::new()
                .include_header(true)
                .inline_asm(InlineASM::default()),
        )
        .unwrap()
        .compile("gcc_compiled_evaluator_real", CompileOptions::default())
        .unwrap()
        .load()
        .unwrap();
    let mut out = vec![0.];
    compiled_evaluator.evaluate(&INPUT_REAL, &mut out);
    assert!((out[0] - OUT_REAL).abs() / OUT_REAL < 1e-10, "{}", out[0]);
}

#[test]
fn gcc_compiled_evaluator_complex() {
    let evaluator = generate_evaluator().map_coeff(&|x| Complex::new(x.re.to_f64(), x.im.to_f64()));
    let mut compiled_evaluator = evaluator
        .export_cpp::<Complex<f64>>(
            "gcc_compiled_evaluator_complex.cpp",
            "gcc_compiled_evaluator_complex",
            ExportSettings::new()
                .include_header(true)
                .inline_asm(InlineASM::default()),
        )
        .unwrap()
        .compile("gcc_compiled_evaluator_complex", CompileOptions::default())
        .unwrap()
        .load()
        .unwrap();
    let mut out = vec![Complex::new(0., 0.)];
    compiled_evaluator.evaluate(&INPUT_COMPLEX, &mut out);
    assert!(
        (out[0] - OUT_COMPLEX).re.abs() / OUT_COMPLEX.re.abs() < 1e-10,
        "re: {}",
        out[0].re
    );
    assert!(
        (out[0] - OUT_COMPLEX).im.abs() / OUT_COMPLEX.im.abs() < 1e-10,
        "im: {}",
        out[0].im
    );
}

#[test]
fn cuda_compiled_evaluator_real() {
    if std::env::var("CUDA_TEST").is_err() {
        eprintln!("Skipping CUDA tests, set CUDA_TEST environment variable to run them.");
        return;
    }

    let evaluator = generate_evaluator().map_coeff(&|x| x.re.to_f64());
    let mut compiled_evaluator = evaluator
        .export_cpp::<CudaRealf64>(
            "cuda_compiled_evaluator_real.cpp",
            "cuda_compiled_evaluator_real",
            ExportSettings::default(),
        )
        .unwrap()
        .compile("cuda_compiled_evaluator_real", CompileOptions::cuda())
        .unwrap()
        .load_with_settings(CudaLoadSettings::new().number_of_evaluations(1))
        .unwrap();
    let mut out = vec![0.];
    compiled_evaluator.evaluate(&INPUT_REAL, &mut out).unwrap();
    assert!((out[0] - OUT_REAL).abs() / OUT_REAL < 1e-10);
}

#[test]
fn cuda_compiled_evaluator_complex() {
    if std::env::var("CUDA_TEST").is_err() {
        eprintln!("Skipping CUDA tests, set CUDA_TEST environment variable to run them.");
        return;
    }

    let evaluator = generate_evaluator().map_coeff(&|x| Complex::new(x.re.to_f64(), x.im.to_f64()));
    let mut compiled_evaluator = evaluator
        .export_cpp::<CudaComplexf64>(
            "cuda_compiled_evaluator_complex.cpp",
            "cuda_compiled_evaluator_complex",
            ExportSettings::default(),
        )
        .unwrap()
        .compile("cuda_compiled_evaluator_complex", CompileOptions::cuda())
        .unwrap()
        .load_with_settings(CudaLoadSettings::new().number_of_evaluations(1))
        .unwrap();
    let mut out = vec![Complex::new(0., 0.)];
    compiled_evaluator
        .evaluate(&INPUT_COMPLEX, &mut out)
        .unwrap();
    assert!(
        (out[0] - OUT_COMPLEX).re.abs() / OUT_COMPLEX.re.abs() < 1e-10,
        "re: {}",
        out[0].re
    );
}
