use std::{collections::HashMap as StdHashMap, hash::BuildHasher};

use crate::{atom::InlineVar, coefficient::ConvertToRing};

use super::*;

/// Expressions visible in the current direct-linearization scope.
///
/// Branches inherit their parent's entries, but entries produced inside one
/// branch must never escape to its sibling. Journaling updates avoids copying
/// the entire parent map for each branch while retaining that scope rule.
#[derive(Default)]
struct ScopedSubexpressions<'a> {
    entries: HashMap<AtomView<'a>, Slot>,
    changes: Vec<(AtomView<'a>, Option<Slot>)>,
    // Conditions are immutable SSA slots during direct translation. A fact is
    // valid only inside the selected arm, exactly like a branch-local value.
    conditions: HashMap<Slot, bool>,
    condition_changes: Vec<(Slot, Option<bool>)>,
    known_condition_reuses: usize,
    depth: usize,
    branches: usize,
    avoided_copied_entries: usize,
    reverted_entries: usize,
}

impl<'a> ScopedSubexpressions<'a> {
    fn get(&self, expression: &AtomView<'a>) -> Option<&Slot> {
        self.entries.get(expression)
    }

    fn insert(&mut self, expression: AtomView<'a>, slot: Slot) {
        let previous = self.entries.insert(expression, slot);
        if self.depth != 0 {
            self.changes.push((expression, previous));
        }
    }

    fn len(&self) -> usize {
        self.entries.len()
    }

    fn retain(&mut self, keep: impl FnMut(&AtomView<'a>, &mut Slot) -> bool) {
        // This is used only to discard temporary condition instructions. All
        // removed slots were created since the condition started; the journal
        // still safely restores its enclosing branch when that branch ends.
        self.entries.retain(keep);
    }

    fn condition(&self, condition: Slot) -> Option<bool> {
        self.conditions.get(&condition).copied()
    }

    fn assume_condition(&mut self, condition: Slot, nonzero: bool) {
        debug_assert_ne!(self.depth, 0);
        let previous = self.conditions.insert(condition, nonzero);
        self.condition_changes.push((condition, previous));
    }

    fn checkpoint(&mut self) -> (usize, usize) {
        self.depth += 1;
        self.branches += 1;
        self.avoided_copied_entries += self.entries.len();
        (self.changes.len(), self.condition_changes.len())
    }

    fn restore(&mut self, checkpoint: (usize, usize)) {
        while self.condition_changes.len() > checkpoint.1 {
            let (condition, previous) = self.condition_changes.pop().unwrap();
            if let Some(previous) = previous {
                self.conditions.insert(condition, previous);
            } else {
                self.conditions.remove(&condition);
            }
        }
        while self.changes.len() > checkpoint.0 {
            let (expression, previous) = self.changes.pop().unwrap();
            if let Some(previous) = previous {
                self.entries.insert(expression, previous);
            } else {
                self.entries.remove(&expression);
            }
            self.reverted_entries += 1;
        }
        self.depth -= 1;
    }

    fn report(&self, started: std::time::Instant) {
        if std::env::var_os("SYMBOLICA_SCOPE_PROFILE").is_some() {
            eprintln!(
                "symbolica scoped cache: roots_elapsed={:.6}s, branch_scopes={}, parent_entries_not_copied={}, reverted_entries={}, final_entries={}, path_known_conditions_reused={}",
                started.elapsed().as_secs_f64(),
                self.branches,
                self.avoided_copied_entries,
                self.reverted_entries,
                self.entries.len(),
                self.known_condition_reuses,
            );
        }
    }
}

/// Errors that can occur while building or performing numerical expression evaluation.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum EvaluationError {
    /// An expression supplied as a parameter is not a supported indeterminate.
    NotIndeterminate {
        /// The invalid parameter expression.
        atom: Atom,
    },
    /// The number of supplied parameter values does not match the evaluator.
    InvalidParameterCount {
        /// The evaluator's parameter count.
        expected: usize,
        /// The number of supplied values.
        actual: usize,
    },
    /// The output buffer has the wrong length.
    InvalidOutputCount {
        /// The evaluator's output count.
        expected: usize,
        /// The supplied output length.
        actual: usize,
    },
    /// The requested hot-start optimization is unavailable for this evaluation path.
    UnsupportedHotStart,
    /// A coefficient cannot be converted to the evaluation domain.
    UnsupportedCoefficient {
        /// A printable description of the unsupported coefficient.
        coefficient: String,
    },
    /// A variable has neither a parameter value nor a registered evaluator.
    UndefinedVariable {
        /// The unresolved variable.
        symbol: Symbol,
    },
    /// A function call has neither a parameter value nor a registered evaluator.
    UndefinedFunction {
        /// The unresolved function call.
        expression: Atom,
    },
    /// A function call supplies the wrong number of arguments.
    WrongNumberOfArguments {
        /// The called function.
        function: Symbol,
        /// The registered argument count.
        expected: usize,
        /// The number of supplied arguments.
        actual: usize,
    },
    /// A built-in function is called with an unsupported number of arguments.
    UnsupportedBuiltinArity {
        /// The built-in function.
        function: Symbol,
        /// The supported argument count.
        expected: usize,
        /// The number of supplied arguments.
        actual: usize,
    },
    /// A function registration disagrees with the existing number of tag arguments.
    InconsistentFunctionTagCount {
        /// The function being registered.
        function: Symbol,
        /// The previously registered tag count.
        expected: usize,
        /// The new registration's tag count.
        actual: usize,
    },
    /// A function definition conflicts with an existing definition.
    FunctionRedefined {
        /// The function being redefined.
        function: Atom,
    },
    /// The evaluation domain cannot represent the imaginary unit required by the expression.
    NumericalTypeDoesNotSupportImaginaryUnit,
    /// An expression could not be evaluated.
    EvaluationFailed {
        /// The expression being evaluated.
        expression: Atom,
        /// The underlying failure message.
        reason: String,
    },
    /// An evaluation tree could not be constructed.
    EvaluationTreeConstructionFailed {
        /// The expression being converted.
        expression: Atom,
        /// The underlying failure message.
        reason: String,
    },
    /// An evaluator could not be constructed.
    EvaluatorConstructionFailed {
        /// The expression being converted.
        expression: Atom,
        /// The underlying failure message.
        reason: String,
    },
    /// A joint evaluator for several expressions could not be constructed.
    MultiEvaluatorConstructionFailed {
        /// The number of requested expressions.
        expression_count: usize,
        /// The underlying failure message.
        reason: String,
    },
    /// No evaluator is registered for an expression in the requested numerical domain.
    MissingEvaluator {
        /// The expression requiring an evaluator.
        expression: Atom,
        /// The requested evaluator type.
        eval_type: String,
    },
}

impl std::error::Error for EvaluationError {}

impl std::fmt::Display for EvaluationError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            EvaluationError::NotIndeterminate { atom } => {
                write!(f, "atom is not indeterminate: {atom:?}")
            }
            EvaluationError::InvalidParameterCount { expected, actual } => {
                write!(
                    f,
                    "invalid parameter count: expected {expected}, got {actual}"
                )
            }
            EvaluationError::InvalidOutputCount { expected, actual } => {
                write!(f, "invalid output count: expected {expected}, got {actual}")
            }
            EvaluationError::UnsupportedHotStart => {
                f.write_str("hot start is not supported before the deprecation of Expression")
            }
            EvaluationError::UnsupportedCoefficient { coefficient } => {
                write!(
                    f,
                    "{coefficient} coefficients are not supported for evaluation"
                )
            }
            EvaluationError::UndefinedVariable { symbol } => {
                write!(
                    f,
                    "variable {symbol} is not in a parameter map and does not have an evaluator"
                )
            }
            EvaluationError::UndefinedFunction { expression } => {
                write!(
                    f,
                    "function {expression} is not in a parameter map and does not have an evaluator"
                )
            }
            EvaluationError::WrongNumberOfArguments {
                function,
                expected,
                actual,
            } => write!(
                f,
                "function {} called with wrong number of arguments: {actual} vs {expected}",
                function.get_name()
            ),
            EvaluationError::UnsupportedBuiltinArity {
                function,
                expected,
                actual,
            } => write!(
                f,
                "builtin function {} must have exactly {expected} argument(s), got {actual}",
                function.get_name()
            ),
            EvaluationError::InconsistentFunctionTagCount {
                function,
                expected,
                actual,
            } => write!(
                f,
                "function {} cannot be registered with {actual} tag(s); it was already registered with {expected} tag(s)",
                function.get_name()
            ),
            EvaluationError::FunctionRedefined { function } => {
                write!(f, "function {} is redefined", function.to_plain_string())
            }

            EvaluationError::NumericalTypeDoesNotSupportImaginaryUnit => {
                f.write_str("numerical type does not support imaginary unit")
            }
            EvaluationError::EvaluationFailed { expression, reason } => {
                write!(f, "could not evaluate {expression}: {reason}")
            }
            EvaluationError::EvaluationTreeConstructionFailed { expression, reason } => write!(
                f,
                "could not build an evaluation tree for {expression}: {reason}"
            ),
            EvaluationError::EvaluatorConstructionFailed { expression, reason } => {
                write!(f, "could not build an evaluator for {expression}: {reason}")
            }
            EvaluationError::MultiEvaluatorConstructionFailed {
                expression_count,
                reason,
            } => write!(
                f,
                "could not build an evaluator for {expression_count} expressions: {reason}"
            ),
            EvaluationError::MissingEvaluator {
                expression,
                eval_type,
            } => {
                write!(
                    f,
                    "could not find an evaluator of type {eval_type} for {expression}"
                )
            }
        }
    }
}

#[derive(Debug, Clone)]
struct SplitExpression<T> {
    tree: Vec<Expression<T>>,
    subexpressions: Vec<Expression<T>>,
}

/// A tree representation of multiple expressions, including function definitions.
#[derive(Debug, Clone)]
pub struct EvalTree<T> {
    functions: Vec<(String, Vec<Indeterminate>, SplitExpression<T>)>,
    external_functions: Vec<ExternalFunctionContainer<T>>,
    expressions: SplitExpression<T>,
    param_count: usize,
}

fn register_constant_external_container<T>(
    external_functions: &mut Vec<ExternalFunctionContainer<T>>,
    symbol: Symbol,
    tags: Vec<Atom>,
    fixed_args: Vec<Complex<Rational>>,
    constants: &mut Vec<Complex<Rational>>,
) -> usize {
    let index = if let Some(index) = external_functions
        .iter()
        .position(|x| x.symbol == symbol && x.tags == tags && x.fixed_args == fixed_args)
    {
        index
    } else {
        external_functions.push(ExternalFunctionContainer::new(symbol, tags, fixed_args));
        external_functions.len() - 1
    };

    if let Some(constant_index) = external_functions[index].constant_index {
        return constant_index;
    }

    let constant_index = constants.len();
    constants.push(Complex::default());
    external_functions[index].constant_index = Some(constant_index);
    constant_index
}

// Shared by the root and every function compiled in this build.
struct LinearizationContext<'a> {
    external_functions: Vec<ExternalFunctionContainer<Complex<Rational>>>,
    // Hidden global slots for each body; a pending entry detects recursive definitions.
    functions: HashMap<usize, Option<Vec<Slot>>>,
    // None denotes a registered constant whose value is resolved in the numerical domain.
    constants: Vec<Option<Complex<Rational>>>,
    constant_indices: HashMap<Complex<Rational>, usize>,
    // None denotes a callable; Some contains the fixed arguments of a constant.
    external_indices: HashMap<(Symbol, Vec<Atom>, Option<Vec<Complex<Rational>>>), usize>,
    inputs: Vec<AtomView<'a>>,
    expanding_functions: HashSet<usize>,
}

impl LinearizationContext<'_> {
    fn constant_slot(&mut self, constant: Complex<Rational>) -> Slot {
        let index = *self
            .constant_indices
            .entry(constant.clone())
            .or_insert_with(|| {
                self.constants.push(Some(constant));
                self.constants.len() - 1
            });
        Slot::Const(index)
    }

    fn external_constant_slot(
        &mut self,
        symbol: Symbol,
        tags: Vec<Atom>,
        fixed_args: Vec<Complex<Rational>>,
    ) -> Slot {
        let index = *self
            .external_indices
            .entry((symbol, tags.clone(), Some(fixed_args.clone())))
            .or_insert_with(|| {
                let mut external = ExternalFunctionContainer::new(symbol, tags, fixed_args);
                external.constant_index = Some(self.constants.len());
                self.constants.push(None);
                self.external_functions.push(external);
                self.external_functions.len() - 1
            });
        Slot::Const(self.external_functions[index].constant_index.unwrap())
    }
}

impl<'a> AtomView<'a> {
    pub(crate) fn to_evaluator(
        expressions: &[Self],
        fn_map: &FunctionMap,
        params: &[Atom],
        settings: OptimizationSettings,
    ) -> Result<ExpressionEvaluator<Complex<Rational>>, EvaluationError> {
        if settings.verbose {
            let mut cse = HashSet::default();
            let mut count = OperationCount::default();
            for e in expressions {
                count += e.count_operations_with_subexpressions(&mut cse);
            }
            info!("Initial ops: {}", count);
        }

        if settings.horner_iterations == 0 {
            return Self::linearize_multiple(expressions, fn_map, params, settings);
        }

        let v = match &settings.hot_start {
            Some(_) => {
                return Err(EvaluationError::UnsupportedHotStart);
            }
            None => {
                // start with an occurence order Horner scheme
                let mut v = HashMap::default();

                for t in expressions {
                    t.count_indeterminates(true, &mut v);
                }

                let mut v: Vec<_> = v.into_iter().collect();
                v.retain(|(_, vv)| *vv > 1);
                v.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
                v.truncate(settings.max_horner_scheme_variables);
                v.into_iter()
                    .map(|(k, _)| Indeterminate::try_from(k.to_owned()).unwrap())
                    .collect::<Vec<_>>()
            }
        };

        let scheme = if settings.horner_iterations > 1 {
            Self::optimize_horner_scheme_multiple(expressions, &v, &settings)
        } else {
            v
        };

        let hornered_expressions = expressions
            .iter()
            .map(|x| x.horner_scheme(Some(&scheme), true, true))
            .collect::<Vec<_>>();

        if settings.horner_iterations == 1 && settings.verbose {
            let mut cse = HashSet::default();
            let mut count = OperationCount::default();
            for e in &hornered_expressions {
                count += e.as_view().count_operations_with_subexpressions(&mut cse);
            }
            info!("Horner scheme ops: {}", count);
        }

        let mut f = fn_map.clone();
        for Expr { body, .. } in f.tagged_fn_map.values_mut() {
            *body = body.as_view().horner_scheme(Some(&scheme), true, true);
        }

        let mut e = Self::linearize_multiple(&hornered_expressions, &f, params, settings)?;

        drop(f);
        drop(hornered_expressions);

        loop {
            let r = e.remove_common_instructions();

            if r == 0 || e.settings.abort_level > 0 {
                e.settings.abort_level = 0;
                break;
            }

            if e.settings.verbose {
                let count = e.count_operations();
                info!("Removed {} common instructions: {}", r, count);
            }
        }

        for _ in 0..e.settings.cpe_iterations.unwrap_or(usize::MAX) {
            let r = e.remove_common_pairs();
            if r == 0 || e.settings.abort_level > 0 {
                e.settings.abort_level = 0;
                break;
            }

            if e.settings.verbose {
                let count = e.count_operations();
                info!("Removed {} common pairs: {}", r, count);
            }
        }

        e.optimize_stack();
        Ok(e)
    }

    /// Search for a Horner variable order that reduces the combined operation
    /// count of `expressions`. `vars` supplies the initial order; `settings`
    /// controls the search budget and parallelism. Returns the best order found.
    pub fn optimize_horner_scheme_multiple(
        expressions: &[Self],
        vars: &[Indeterminate],
        settings: &OptimizationSettings,
    ) -> Vec<Indeterminate> {
        if vars.is_empty() {
            return vars.to_vec();
        }

        let horner: Vec<_> = expressions
            .iter()
            .map(|x| x.horner_scheme(Some(vars), true, true))
            .collect();
        let mut subexpr = HashSet::default();
        let mut best_ops = OperationCount::default();
        for h in &horner {
            let ops = h
                .as_view()
                .count_operations_with_subexpressions(&mut subexpr);
            best_ops += ops;
        }

        if settings.verbose {
            info!("Initial Horner scheme ops: {}", best_ops);
        }

        let best_mul = Arc::new(AtomicUsize::new(best_ops.multiplications));
        let best_add = Arc::new(AtomicUsize::new(best_ops.additions));
        let best_scheme = Arc::new(Mutex::new(vars.to_vec()));

        let n_iterations = settings.horner_iterations.max(1) - 1;

        let permutations = if vars.len() < 10
            && Integer::factorial(vars.len() as u32) <= settings.horner_iterations.max(1)
        {
            let v: Vec<_> = (0..vars.len()).collect();
            Some(unique_permutations(&v).1)
        } else {
            None
        };
        let p_ref = &permutations;

        let n_cores = LicenseManager::max_threads(settings.n_cores).min(n_iterations);
        let inherited_unlock = crate::license::InheritedLibraryUnlock::capture();

        std::thread::scope(|s| {
            let abort = Arc::new(AtomicBool::new(false));

            for i in 0..n_cores {
                let mut rng = MonteCarloRng::new(0, i);

                let mut cvars = vars.to_vec();
                let best_scheme = best_scheme.clone();
                let best_mul = best_mul.clone();
                let best_add = best_add.clone();
                let mut last_mul = usize::MAX;
                let mut last_add = usize::MAX;
                let abort = abort.clone();

                let mut op = move || {
                    let _unlock = inherited_unlock.activate();
                    for j in 0..n_iterations / n_cores {
                        if abort.load(Ordering::Relaxed) {
                            return;
                        }

                        if i == n_cores - 1
                            && let Some(a) = &settings.abort_check
                            && a()
                        {
                            abort.store(true, Ordering::Relaxed);

                            if settings.verbose {
                                info!(
                                    "Aborting Horner optimization at step {}/{}.",
                                    j,
                                    settings.horner_iterations / n_cores
                                );
                            }

                            return;
                        }

                        // try a random swap
                        let mut t1 = 0;
                        let mut t2 = 0;

                        if let Some(p) = p_ref {
                            if j >= p.len() / n_cores {
                                break;
                            }

                            let perm = &p[i * (p.len() / n_cores) + j];
                            cvars = perm.iter().map(|x| vars[*x].clone()).collect();
                        } else {
                            t1 = rng.random_range(0..cvars.len());
                            t2 = rng.random_range(0..cvars.len() - 1);

                            cvars.swap(t1, t2);
                        }

                        let horner: Vec<_> = expressions
                            .iter()
                            .map(|x| x.horner_scheme(Some(&cvars), true, true))
                            .collect();
                        let mut subexpr = HashSet::default();
                        let mut cur_ops = OperationCount::default();

                        for h in &horner {
                            let ops = h
                                .as_view()
                                .count_operations_with_subexpressions(&mut subexpr);
                            cur_ops += ops;
                        }

                        // prefer fewer multiplications
                        if cur_ops.multiplications <= last_mul
                            || cur_ops.multiplications == last_mul && cur_ops.additions <= last_add
                        {
                            if settings.verbose {
                                info!(
                                    "Accept move at step {}/{}: {}",
                                    j,
                                    settings.horner_iterations / n_cores,
                                    cur_ops
                                );
                            }

                            last_add = cur_ops.additions;
                            last_mul = cur_ops.multiplications;

                            if cur_ops.multiplications <= best_mul.load(Ordering::Relaxed)
                                || cur_ops.multiplications == best_mul.load(Ordering::Relaxed)
                                    && cur_ops.additions <= best_add.load(Ordering::Relaxed)
                            {
                                let mut best_scheme = best_scheme.lock().unwrap();

                                // check again if it is the best now that we have locked
                                let best_mul_l = best_mul.load(Ordering::Relaxed);
                                let best_add_l = best_add.load(Ordering::Relaxed);
                                if cur_ops.multiplications <= best_mul_l
                                    || cur_ops.multiplications == best_mul_l
                                        && cur_ops.additions <= best_add_l
                                {
                                    if cur_ops.additions == best_add_l
                                        && cur_ops.multiplications == best_mul_l
                                    {
                                        if *best_scheme < cvars {
                                            // on a draw, accept the lexicographical minimum
                                            // to get a deterministic scheme
                                            *best_scheme = cvars.clone();
                                        }
                                    } else {
                                        best_mul.store(cur_ops.multiplications, Ordering::Relaxed);
                                        best_add.store(cur_ops.additions, Ordering::Relaxed);
                                        *best_scheme = cvars.clone();
                                    }
                                }
                            }
                        } else {
                            cvars.swap(t1, t2);
                        }
                    }
                };

                if i + 1 < n_cores {
                    s.spawn(op);
                } else {
                    // execute in the main thread and do the abort check on the main thread
                    // this helps with catching ctrl-c
                    op()
                }
            }
        });

        if settings.verbose {
            info!(
                "Final scheme: {} + and {} ×",
                best_add.load(Ordering::Relaxed),
                best_mul.load(Ordering::Relaxed)
            );
        }

        Arc::try_unwrap(best_scheme).unwrap().into_inner().unwrap()
    }

    pub(crate) fn linearize_multiple<T: AtomCore>(
        expressions: &[T],
        fn_map: &FunctionMap,
        params: &[Atom],
        settings: OptimizationSettings,
    ) -> Result<ExpressionEvaluator<Complex<Rational>>, EvaluationError> {
        let expressions = expressions
            .iter()
            .map(|e| e.as_atom_view())
            .collect::<Vec<_>>();
        let params = params.iter().map(|p| p.as_view()).collect::<Vec<_>>();
        let mut context = LinearizationContext {
            external_functions: Vec::new(),
            functions: HashMap::default(),
            constants: Vec::new(),
            constant_indices: HashMap::default(),
            external_indices: HashMap::default(),
            inputs: params.clone(),
            expanding_functions: HashSet::default(),
        };
        let (instr, results) = AtomView::linearize_multiple_impl(
            &expressions,
            fn_map,
            &params,
            &settings,
            &mut context,
        )?;
        let param_count = params.len();
        let reserved_indices = param_count + context.constants.len();
        let mut stack = vec![Complex::default(); reserved_indices + instr.len()];
        let (instructions, result_indices) = AtomView::lower_instructions(
            instr,
            results,
            param_count,
            reserved_indices,
            &mut context,
        )?;
        for (slot, constant) in stack[param_count..reserved_indices]
            .iter_mut()
            .zip(context.constants)
        {
            if let Some(value) = constant {
                *slot = value;
            }
        }
        Ok(ExpressionEvaluator {
            stack,
            param_count,
            reserved_indices,
            instructions,
            result_indices,
            external_fns: context.external_functions,
            settings,
        })
    }

    fn linearize_multiple_impl(
        expressions: &[AtomView<'a>],
        fn_map: &'a FunctionMap,
        params: &[AtomView<'a>],
        settings: &OptimizationSettings,
        context: &mut LinearizationContext<'a>,
    ) -> Result<(Vec<Instruction>, Vec<Slot>), EvaluationError> {
        let mut instr = Vec::new();

        // we can only safely remove entries that don't depend on any of the function arguments
        let started = std::time::Instant::now();
        let mut subexpression = ScopedSubexpressions::default();

        let mut result_indices = vec![];
        let args = params
            .iter()
            .enumerate()
            .map(|(i, p)| (*p, Slot::Param(i)))
            .collect();
        for expr in expressions {
            let res = expr.linearize_impl(
                fn_map,
                context,
                &args,
                settings,
                &mut instr,
                &mut subexpression,
            )?;
            result_indices.push(res);
        }

        subexpression.report(started);
        Ok((instr, result_indices))
    }

    fn lower_instructions(
        instr: Vec<Instruction>,
        results: Vec<Slot>,
        param_count: usize,
        reserved_indices: usize,
        context: &mut LinearizationContext<'a>,
    ) -> Result<(Vec<(Instr, ComplexPhase)>, Vec<usize>), EvaluationError> {
        macro_rules! slot_map {
            ($s: expr) => {
                match $s {
                    Slot::Param(i) => i,
                    Slot::Const(i) => param_count + i,
                    Slot::Temp(i) => reserved_indices + i,
                    Slot::Out(_) => unreachable!(),
                }
            };
        }

        let mut instructions = vec![];
        for i in instr {
            match i {
                Instruction::Add(o, args, _) => {
                    instructions.push((
                        Instr::Add(
                            slot_map!(o),
                            args.into_iter().map(|x| slot_map!(x)).collect(),
                        ),
                        ComplexPhase::default(),
                    ));
                }
                Instruction::Mul(o, args, _) => {
                    instructions.push((
                        Instr::Mul(
                            slot_map!(o),
                            args.into_iter().map(|x| slot_map!(x)).collect(),
                        ),
                        ComplexPhase::default(),
                    ));
                }
                Instruction::Pow(o, base, exp, _) => {
                    instructions.push((
                        Instr::Pow(slot_map!(o), slot_map!(base), exp),
                        ComplexPhase::default(),
                    ));
                }
                Instruction::Powf(o, base, exp, _) => {
                    instructions.push((
                        Instr::Powf(slot_map!(o), slot_map!(base), slot_map!(exp)),
                        ComplexPhase::default(),
                    ));
                }
                Instruction::Fun(o, b, _) => {
                    let (sym, tags, args) = *b;

                    if sym.is_fixed_builtin() {
                        if args.len() != 1 {
                            return Err(EvaluationError::UnsupportedBuiltinArity {
                                function: sym,
                                expected: 1,
                                actual: args.len(),
                            });
                        }
                        instructions.push((
                            Instr::BuiltinFun(slot_map!(o), sym, slot_map!(args[0])),
                            ComplexPhase::default(),
                        ));
                        continue;
                    }

                    let tags = tags.iter().map(|x| crate::parse!(x)).collect::<Vec<_>>();
                    let index = *context
                        .external_indices
                        .entry((sym, tags.clone(), None))
                        .or_insert_with(|| {
                            context
                                .external_functions
                                .push(ExternalFunctionContainer::new(sym, tags, vec![]));
                            context.external_functions.len() - 1
                        });

                    instructions.push((
                        Instr::ExternalFun(
                            slot_map!(o),
                            index,
                            args.into_iter().map(|x| slot_map!(x)).collect(),
                        ),
                        ComplexPhase::default(),
                    ));
                }
                Instruction::Assign(_, _) => {
                    unimplemented!("Assign should not occur in input")
                }
                Instruction::IfElse(cond, l) => {
                    instructions.push((
                        Instr::IfElse(slot_map!(cond), Label(l)),
                        ComplexPhase::default(),
                    ));
                }
                Instruction::Goto(label) => {
                    instructions.push((Instr::Goto(Label(label)), ComplexPhase::default()));
                }
                Instruction::Label(label) => {
                    instructions.push((Instr::Label(Label(label)), ComplexPhase::default()));
                }
                Instruction::Join(o, cond, t, f) => {
                    instructions.push((
                        Instr::Join(slot_map!(o), slot_map!(cond), slot_map!(t), slot_map!(f)),
                        ComplexPhase::default(),
                    ));
                }
            }
        }

        Ok((
            instructions,
            results.into_iter().map(|s| slot_map!(s)).collect(),
        ))
    }

    #[allow(clippy::too_many_arguments)]
    fn linearize_function_call(
        fn_map: &'a FunctionMap,
        context: &mut LinearizationContext<'a>,
        settings: &OptimizationSettings,
        symbol: Symbol,
        tags: Vec<Atom>,
        function: &'a Expr,
        arg_slots: Vec<Slot>,
        instr: &mut Vec<Instruction>,
    ) -> Result<Slot, EvaluationError> {
        if arg_slots.len() != function.args.len() {
            return Err(EvaluationError::WrongNumberOfArguments {
                function: symbol,
                expected: function.args.len() + function.tag_len,
                actual: arg_slots.len() + tags.len(),
            });
        }
        let recursive_call = || EvaluationError::EvaluatorConstructionFailed {
            expression: symbol.call(&tags),
            reason: "recursive function dependency".into(),
        };
        if !context.functions.contains_key(&function.id) {
            // A pending entry detects recursion. No caller bindings enter this compilation:
            // root inputs precede declared arguments, which shadow matching input names.
            context.functions.insert(function.id, None);
            let body_params = context
                .inputs
                .iter()
                .copied()
                .chain(function.args.iter().map(|arg| arg.as_view()))
                .collect::<Vec<_>>();
            let (mut instr, mut result_indices) = Self::linearize_multiple_impl(
                &[function.body.as_view()],
                fn_map,
                &body_params,
                settings,
                context,
            )?;
            // Root inputs and constants stay symbolic during construction. Compact only
            // the surviving references, including globals forwarded to callees, once the
            // body is complete. Declared arguments retain their original positions.
            let mut globals = Vec::new();
            let root_param_count = context.inputs.len();
            let mut param_count = function.args.len();
            let mut indices = HashMap::default();
            let mut lower_global = |slot: &mut Slot| match *slot {
                Slot::Param(index) if index >= root_param_count => {
                    *slot = Slot::Param(index - root_param_count);
                }
                Slot::Param(_) | Slot::Const(_) => {
                    let index = *indices.entry(*slot).or_insert_with(|| {
                        let index = param_count + globals.len();
                        globals.push(*slot);
                        index
                    });
                    *slot = Slot::Param(index);
                }
                Slot::Temp(_) | Slot::Out(_) => {}
            };
            for instruction in &mut instr {
                match instruction {
                    Instruction::Add(_, args, _) | Instruction::Mul(_, args, _) => {
                        args.iter_mut().for_each(&mut lower_global);
                    }
                    Instruction::Pow(_, base, _, _) | Instruction::Assign(_, base) => {
                        lower_global(base);
                    }
                    Instruction::Powf(_, base, exp, _) => {
                        lower_global(base);
                        lower_global(exp);
                    }
                    Instruction::Fun(_, function, _) => {
                        function.2.iter_mut().for_each(&mut lower_global);
                    }
                    Instruction::IfElse(cond, _) => lower_global(cond),
                    Instruction::Join(_, cond, then_value, else_value) => {
                        lower_global(cond);
                        lower_global(then_value);
                        lower_global(else_value);
                    }
                    Instruction::Goto(_) | Instruction::Label(_) => {}
                }
            }
            result_indices.iter_mut().for_each(lower_global);
            param_count += globals.len();

            let stack_size = param_count + instr.len();
            let (instructions, result_indices) =
                Self::lower_instructions(instr, result_indices, param_count, param_count, context)?;
            // This is fresh SSA, just like a newly lowered root evaluator. Reuse
            // its allocator before storing the immutable shared body. Explicit
            // arguments and captured values are reserved inputs; numerical
            // coefficients are unnecessary for this instruction-only pass.
            let mut allocation = ExpressionEvaluator {
                stack: vec![(); stack_size],
                param_count,
                reserved_indices: param_count,
                instructions,
                result_indices,
                external_fns: vec![],
                settings: settings.clone(),
            };
            allocation.optimize_stack();
            let body = FunctionBody {
                instructions: allocation.instructions,
                param_count,
                result_index: allocation.result_indices[0],
                stack_size: allocation.stack.len(),
            };
            // Recursive compilation has already registered every callee.
            context.external_indices.insert(
                (symbol, tags.clone(), None),
                context.external_functions.len(),
            );
            context
                .external_functions
                .push(ExternalFunctionContainer::with_body(
                    symbol,
                    tags.clone(),
                    Arc::new(body),
                ));
            context.functions.insert(function.id, Some(globals));
        }
        let globals = context.functions[&function.id]
            .as_ref()
            .ok_or_else(recursive_call)?;

        // Global slots bypass local name bindings, including shadowing arguments.
        // The caller's final lowering pass will compact them in its own signature.
        let mut call_args = arg_slots;
        call_args.extend_from_slice(globals);

        let result = Slot::Temp(instr.len());
        instr.push(Instruction::Fun(
            result,
            Box::new((
                symbol,
                tags.iter().map(|tag| tag.to_canonical_string()).collect(),
                call_args,
            )),
            false,
        ));
        Ok(result)
    }

    #[allow(clippy::too_many_arguments)]
    fn linearize_inline_function(
        &self,
        function: &'a Expr,
        arg_slots: Vec<Slot>,
        fn_map: &'a FunctionMap,
        context: &mut LinearizationContext<'a>,
        params: &HashMap<AtomView<'a>, Slot>,
        settings: &OptimizationSettings,
        instr: &mut Vec<Instruction>,
        subexpressions: &mut ScopedSubexpressions<'a>,
    ) -> Result<Slot, EvaluationError> {
        if !context.expanding_functions.insert(function.id) {
            return Err(EvaluationError::EvaluatorConstructionFailed {
                expression: self.to_owned(),
                reason: "recursive function or alias dependency".into(),
            });
        }
        let mut body_params = HashMap::default();
        if !function.is_alias {
            body_params.extend(
                context
                    .inputs
                    .iter()
                    .enumerate()
                    .map(|(i, p)| (*p, Slot::Param(i))),
            );
            body_params.extend(
                function
                    .args
                    .iter()
                    .zip(arg_slots)
                    .map(|(arg, slot)| (arg.as_view(), slot)),
            );
        }
        // Aliases inherit the caller's bindings and cache. Ordinary functions, including
        // zero-argument functions, get their own scope and expression cache.
        let mut body_subexpressions = ScopedSubexpressions::default();
        let result = function.body.as_view().linearize_impl(
            fn_map,
            context,
            if function.is_alias {
                params
            } else {
                &body_params
            },
            settings,
            instr,
            if function.is_alias {
                subexpressions
            } else {
                &mut body_subexpressions
            },
        );
        context.expanding_functions.remove(&function.id);
        result
    }

    // Yields the stack index that contains the output.
    fn linearize_impl(
        &self,
        fn_map: &'a FunctionMap,
        context: &mut LinearizationContext<'a>,
        params: &HashMap<AtomView<'a>, Slot>,
        settings: &OptimizationSettings,
        instr: &mut Vec<Instruction>,
        subexpressions: &mut ScopedSubexpressions<'a>,
    ) -> Result<Slot, EvaluationError> {
        if matches!(*self, AtomView::Var(_) | AtomView::Fun(_)) {
            if let Some(slot) = params.get(self) {
                return Ok(*slot);
            }
        }

        if let Some(s) = subexpressions.get(self) {
            return Ok(*s);
        }

        let res = match self {
            AtomView::Num(n) => {
                let c = match n.get_coeff_view() {
                    CoefficientView::Natural(n, d, ni, di) => {
                        Complex::new(Rational::from((n, d)), Rational::from((ni, di)))
                    }
                    CoefficientView::Large(l, i) => Complex::new(l.to_rat(), i.to_rat()),
                    CoefficientView::Float(r, i) => {
                        // TODO: converting back to rational is slow
                        Complex::new(r.to_float().to_rational(), i.to_float().to_rational())
                    }
                    CoefficientView::Indeterminate => {
                        return Err(EvaluationError::UnsupportedCoefficient {
                            coefficient: "indeterminate".to_string(),
                        });
                    }
                    CoefficientView::Infinity(_) => {
                        return Err(EvaluationError::UnsupportedCoefficient {
                            coefficient: "infinity".to_string(),
                        });
                    }
                    CoefficientView::FiniteField(_, _) => {
                        return Err(EvaluationError::UnsupportedCoefficient {
                            coefficient: "finite field".to_string(),
                        });
                    }
                    CoefficientView::RationalPolynomial(_) => {
                        return Err(EvaluationError::UnsupportedCoefficient {
                            coefficient: "rational polynomial".to_string(),
                        });
                    }
                };

                context.constant_slot(c)
            }
            AtomView::Var(v) => {
                let s = v.get_symbol();

                if let Some(expr) = fn_map.get(*self) {
                    if !expr.args.is_empty() {
                        return Err(EvaluationError::WrongNumberOfArguments {
                            function: s,
                            expected: expr.args.len(),
                            actual: 0,
                        });
                    }
                    if expr.is_alias || expr.options.should_inline() {
                        return self.linearize_inline_function(
                            expr,
                            vec![],
                            fn_map,
                            context,
                            params,
                            settings,
                            instr,
                            subexpressions,
                        );
                    }

                    return Self::linearize_function_call(
                        fn_map,
                        context,
                        settings,
                        s,
                        vec![],
                        expr,
                        vec![],
                        instr,
                    );
                }

                if s.get_evaluation_info().is_some() {
                    return Ok(context.external_constant_slot(s, vec![], vec![]));
                }

                return Err(EvaluationError::UndefinedVariable { symbol: s });
            }
            AtomView::Fun(f) => {
                let name = f.get_symbol();
                if [
                    Symbol::LOG_ID,
                    Symbol::SIN_ID,
                    Symbol::COS_ID,
                    Symbol::ABS_ID,
                    Symbol::CONJ_ID,
                ]
                .contains(&name.get_id())
                {
                    if f.get_nargs() != 1 {
                        return Err(EvaluationError::WrongNumberOfArguments {
                            function: name,
                            expected: 1,
                            actual: f.get_nargs(),
                        });
                    }

                    let arg = f.iter().next().unwrap();
                    let arg_eval = arg.linearize_impl(
                        fn_map,
                        context,
                        params,
                        settings,
                        instr,
                        subexpressions,
                    )?;

                    let temp = Slot::Temp(instr.len());
                    let c = Instruction::Fun(temp, Box::new((name, vec![], vec![arg_eval])), false);
                    instr.push(c);

                    subexpressions.insert(*self, temp);
                    return Ok(temp);
                }

                let fun = if name == Symbol::IF {
                    if f.get_nargs() != 3 {
                        return Err(EvaluationError::WrongNumberOfArguments {
                            function: name,
                            expected: 3,
                            actual: f.get_nargs(),
                        });
                    }

                    let mut arg_iter = f.iter();
                    let cond = arg_iter.next().unwrap();
                    let then_branch = arg_iter.next().unwrap();
                    let else_branch = arg_iter.next().unwrap();

                    let instr_len = instr.len();
                    let subexpression_len = subexpressions.len();
                    let cond = cond.linearize_impl(
                        fn_map,
                        context,
                        params,
                        settings,
                        instr,
                        subexpressions,
                    )?;

                    // Reusing the exact SSA condition needs no algebraic test:
                    // its truth is fixed by a dominating branch in this scope.
                    // The checkpoint journal removes this fact before siblings
                    // and fresh ordinary-function scopes never inherit it.
                    if let Some(nonzero) = subexpressions.condition(cond) {
                        subexpressions.known_condition_reuses += 1;
                        let selected = if nonzero { then_branch } else { else_branch };
                        let result = selected.linearize_impl(
                            fn_map,
                            context,
                            params,
                            settings,
                            instr,
                            subexpressions,
                        )?;
                        subexpressions.insert(*self, result);
                        return Ok(result);
                    }

                    // try to resolve the condition if it is fully numeric
                    fn resolve(
                        cond: Slot,
                        instr: &[Instruction],
                        constants: &[Option<Complex<Rational>>],
                    ) -> Option<Complex<Rational>> {
                        let i = match cond {
                            Slot::Param(_) => {
                                return None;
                            }
                            Slot::Const(i) => {
                                return constants[i].clone();
                            }
                            Slot::Temp(t) => t,
                            Slot::Out(_) => {
                                unreachable!()
                            }
                        };

                        match &instr[i] {
                            Instruction::Add(_, args, _) => {
                                let mut res = Complex::default();
                                for x in args {
                                    match resolve(*x, instr, constants) {
                                        Some(v) => res += v,
                                        None => return None,
                                    }
                                }

                                Some(res)
                            }
                            Instruction::Mul(_, args, _) => {
                                let mut res = Complex::new(Rational::one(), Rational::zero());
                                for x in args {
                                    match resolve(*x, instr, constants) {
                                        Some(v) => res *= v,
                                        None => return None,
                                    }
                                }

                                Some(res)
                            }
                            Instruction::Pow(_, base, exp, _) => {
                                if let Some(base_val) = resolve(*base, instr, constants) {
                                    if *exp == -1 {
                                        Some(base_val.inv())
                                    } else if *exp < 0 {
                                        Some(base_val.pow(exp.unsigned_abs()).inv())
                                    } else {
                                        Some(base_val.pow(exp.unsigned_abs()))
                                    }
                                } else {
                                    None
                                }
                            }
                            _ => None,
                        }
                    }

                    if let Some(cond_res) = resolve(cond, instr, &context.constants) {
                        // remove dead code
                        instr.truncate(instr_len);
                        if subexpression_len != subexpressions.len() {
                            // remove subexpressions that are created as part of the conditions
                            subexpressions.retain(|_, &mut v| {
                                if let Slot::Temp(v) = v {
                                    v < instr_len
                                } else {
                                    true
                                }
                            });
                        }

                        let res = if !cond_res.is_zero() {
                            then_branch.linearize_impl(
                                fn_map,
                                context,
                                params,
                                settings,
                                instr,
                                subexpressions,
                            )?
                        } else {
                            else_branch.linearize_impl(
                                fn_map,
                                context,
                                params,
                                settings,
                                instr,
                                subexpressions,
                            )?
                        };

                        subexpressions.insert(*self, res);
                        return Ok(res);
                    }

                    let if_instr_pos = instr.len();
                    instr.push(Instruction::IfElse(cond, 0));

                    let checkpoint = subexpressions.checkpoint();
                    subexpressions.assume_condition(cond, true);
                    let then_branch = then_branch.linearize_impl(
                        fn_map,
                        context,
                        params,
                        settings,
                        instr,
                        subexpressions,
                    );
                    subexpressions.restore(checkpoint);
                    let then_branch = then_branch?;

                    let label_end_pos = instr.len();
                    instr.push(Instruction::Goto(0));
                    instr[if_instr_pos] = Instruction::IfElse(cond, instr.len());
                    instr.push(Instruction::Label(instr.len()));

                    let checkpoint = subexpressions.checkpoint();
                    subexpressions.assume_condition(cond, false);
                    let else_branch = else_branch.linearize_impl(
                        fn_map,
                        context,
                        params,
                        settings,
                        instr,
                        subexpressions,
                    );
                    subexpressions.restore(checkpoint);
                    let else_branch = else_branch?;

                    instr[label_end_pos] = Instruction::Goto(instr.len());
                    instr.push(Instruction::Label(instr.len()));

                    let temp = Slot::Temp(instr.len());
                    instr.push(Instruction::Join(temp, cond, then_branch, else_branch));
                    // The completed result now dominates this scope. Branch-local
                    // values were rolled back, so they never escape into the parent.
                    subexpressions.insert(*self, temp);
                    return Ok(temp);
                } else if let Some(fun) = fn_map.get(*self) {
                    fun
                } else if let Some(eval_info) = name.get_evaluation_info() {
                    let tags = f
                        .iter()
                        .take(eval_info.get_tag_count())
                        .map(|x| x.to_owned())
                        .collect::<Vec<_>>();

                    let mut fixed_args = vec![];
                    for x in f.iter().skip(eval_info.get_tag_count()) {
                        if let Ok(n) = Complex::<Rational>::try_from(x) {
                            fixed_args.push(n);
                        }
                    }

                    // check if it a constant external function
                    if f.get_nargs() == eval_info.get_tag_count() + fixed_args.len() {
                        return Ok(context.external_constant_slot(name, tags, fixed_args));
                    };

                    let eval_args = f
                        .iter()
                        .skip(eval_info.get_tag_count())
                        .map(|arg| {
                            arg.linearize_impl(
                                fn_map,
                                context,
                                params,
                                settings,
                                instr,
                                subexpressions,
                            )
                        })
                        .collect::<Result<_, _>>()?;

                    let temp = Slot::Temp(instr.len());
                    instr.push(Instruction::Fun(
                        temp,
                        Box::new((
                            name,
                            tags.iter().map(|x| x.to_canonical_string()).collect(),
                            eval_args,
                        )),
                        false,
                    ));
                    // Use the same scope-local cache as arithmetic expressions.
                    // This branch returns before the common insertion below.
                    subexpressions.insert(*self, temp);
                    return Ok(temp);
                } else {
                    return Err(EvaluationError::UndefinedFunction {
                        expression: self.to_owned(),
                    });
                };

                {
                    let Expr {
                        tag_len,
                        args: arg_spec,
                        options,
                        ..
                    } = fun;

                    if f.get_nargs() != arg_spec.len() + tag_len {
                        return Err(EvaluationError::WrongNumberOfArguments {
                            function: f.get_symbol(),
                            expected: arg_spec.len() + tag_len,
                            actual: f.get_nargs(),
                        });
                    }

                    let mut arg_slots = Vec::with_capacity(arg_spec.len());
                    for eval_arg in f.iter().skip(*tag_len) {
                        let slot = eval_arg.linearize_impl(
                            fn_map,
                            context,
                            params,
                            settings,
                            instr,
                            subexpressions,
                        )?;

                        arg_slots.push(slot);
                    }

                    if !fun.is_alias && !options.should_inline() {
                        let tags = f.iter().take(*tag_len).map(|tag| tag.to_owned()).collect();
                        return Self::linearize_function_call(
                            fn_map, context, settings, name, tags, fun, arg_slots, instr,
                        );
                    }

                    self.linearize_inline_function(
                        fun,
                        arg_slots,
                        fn_map,
                        context,
                        params,
                        settings,
                        instr,
                        subexpressions,
                    )?
                }
            }
            AtomView::Pow(p) => {
                let (b, e) = p.get_base_exp();

                if b == InlineVar::new(Symbol::E).as_view() {
                    let e_eval =
                        e.linearize_impl(fn_map, context, params, settings, instr, subexpressions)?;

                    let temp = Slot::Temp(instr.len());
                    let c = Instruction::Fun(
                        temp,
                        Box::new((Symbol::EXP, vec![], vec![e_eval])),
                        false,
                    );
                    instr.push(c);

                    subexpressions.insert(*self, temp);
                    return Ok(temp);
                }

                let b_eval =
                    b.linearize_impl(fn_map, context, params, settings, instr, subexpressions)?;

                if let AtomView::Num(n) = e
                    && let CoefficientView::Natural(num, den, num_i, _den_i) = n.get_coeff_view()
                    && den == 1
                    && num_i == 0
                {
                    let new_base = if num.unsigned_abs() > 1 {
                        let temp = Slot::Temp(instr.len());
                        instr.push(Instruction::Mul(
                            temp,
                            vec![b_eval; num.unsigned_abs() as usize],
                            0,
                        ));
                        temp
                    } else {
                        b_eval
                    };

                    let res = if num > 0 {
                        new_base
                    } else {
                        let temp = Slot::Temp(instr.len());
                        instr.push(Instruction::Pow(temp, new_base, -1, false));
                        temp
                    };

                    subexpressions.insert(*self, res);
                    return Ok(res);
                }

                if let Ok(r) = Rational::try_from(e) {
                    // FIXME: support 3,2 etc as well
                    if r == (1, 2) {
                        let temp = Slot::Temp(instr.len());
                        let c = Instruction::Fun(
                            temp,
                            Box::new((Symbol::SQRT, vec![], vec![b_eval])),
                            false,
                        );
                        instr.push(c);

                        subexpressions.insert(*self, temp);
                        return Ok(temp);
                    }
                }

                let e_eval =
                    e.linearize_impl(fn_map, context, params, settings, instr, subexpressions)?;

                let temp = Slot::Temp(instr.len());
                instr.push(Instruction::Powf(temp, b_eval, e_eval, false));
                temp
            }
            AtomView::Mul(m) => {
                let mut muls = vec![];
                for arg in m.iter() {
                    let a = arg.linearize_impl(
                        fn_map,
                        context,
                        params,
                        settings,
                        instr,
                        subexpressions,
                    )?;
                    muls.push(a);
                }

                muls.sort();

                let temp = Slot::Temp(instr.len());
                instr.push(Instruction::Mul(temp, muls, 0));
                temp
            }
            AtomView::Add(a) => {
                let mut adds = vec![];
                for arg in a.iter() {
                    adds.push(arg.linearize_impl(
                        fn_map,
                        context,
                        params,
                        settings,
                        instr,
                        subexpressions,
                    )?);
                }

                adds.sort();

                let temp = Slot::Temp(instr.len());
                instr.push(Instruction::Add(temp, adds, 0));
                temp
            }
        };

        subexpressions.insert(*self, res);
        Ok(res)
    }
}

/// A hash of an expression, used for common subexpression elimination.
pub type ExpressionHash = u64;

/// A tree representation of an expression.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[cfg_attr(feature = "bincode", derive(bincode::Encode, bincode::Decode))]
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Expression<T> {
    /// A cached hash and a numerical constant.
    Const(ExpressionHash, Box<T>),
    /// A cached hash and an index into the evaluator's parameter storage.
    Parameter(ExpressionHash, usize),
    /// A cached hash, an index of a defined function, and its argument trees.
    Eval(ExpressionHash, u32, Vec<Expression<T>>),
    /// A cached hash and the terms of a sum.
    Add(ExpressionHash, Vec<Expression<T>>),
    /// A cached hash and the factors of a product.
    Mul(ExpressionHash, Vec<Expression<T>>),
    /// A cached hash and a base raised to an integer exponent.
    Pow(ExpressionHash, Box<(Expression<T>, i64)>),
    /// A cached hash and a pair of base and exponent expressions.
    Powf(ExpressionHash, Box<(Expression<T>, Expression<T>)>),
    /// A cached hash and a zero-based index of an argument of the current function.
    ReadArg(ExpressionHash, usize), // read nth function argument
    /// A cached hash, a built-in function symbol, and its argument.
    BuiltinFun(ExpressionHash, Symbol, Box<Expression<T>>),
    /// A cached hash, an external function symbol, its symbolic tags, and argument trees.
    Fun(ExpressionHash, Symbol, Vec<String>, Vec<Expression<T>>),
    /// A cached hash and a condition, true branch, and false branch.
    /// A zero condition selects the false branch.
    IfElse(
        ExpressionHash,
        Box<(Expression<T>, Expression<T>, Expression<T>)>,
    ),
    /// A cached hash and an index into the extracted common subexpressions.
    SubExpression(ExpressionHash, usize),
}

impl<T> Expression<T> {
    fn get_hash(&self) -> ExpressionHash {
        match self {
            Expression::Const(h, _) => *h,
            Expression::Parameter(h, _) => *h,
            Expression::Eval(h, _, _) => *h,
            Expression::Add(h, _) => *h,
            Expression::Mul(h, _) => *h,
            Expression::Pow(h, _) => *h,
            Expression::Powf(h, _) => *h,
            Expression::ReadArg(h, _) => *h,
            Expression::BuiltinFun(h, _, _) => *h,
            Expression::SubExpression(h, _) => *h,
            Expression::Fun(h, _, _, _) => *h,
            Expression::IfElse(h, _) => *h,
        }
    }
}

impl<T: Eq + InternalOrdering> PartialOrd for Expression<T> {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<T: Eq + InternalOrdering> Ord for Expression<T> {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        match (self, other) {
            (Expression::Const(_, a), Expression::Const(_, b)) => a.internal_cmp(b),
            (Expression::Parameter(_, a), Expression::Parameter(_, b)) => a.cmp(b),
            (Expression::Eval(_, a, b), Expression::Eval(_, c, d)) => {
                a.cmp(c).then_with(|| b.cmp(d))
            }
            (Expression::Add(_, a), Expression::Add(_, b)) => a.cmp(b),
            (Expression::Mul(_, a), Expression::Mul(_, b)) => a.cmp(b),
            (Expression::Pow(_, p1), Expression::Pow(_, p2)) => p1.cmp(p2),
            (Expression::Powf(_, p1), Expression::Powf(_, p2)) => p1.cmp(p2),
            (Expression::ReadArg(_, r1), Expression::ReadArg(_, r2)) => r1.cmp(r2),
            (Expression::BuiltinFun(_, a, b), Expression::BuiltinFun(_, c, d)) => {
                a.cmp(c).then_with(|| b.cmp(d))
            }
            (Expression::SubExpression(_, s1), Expression::SubExpression(_, s2)) => s1.cmp(s2),
            (Expression::Fun(_, a, b, c), Expression::Fun(_, d, e, f)) => {
                a.cmp(d).then_with(|| b.cmp(e)).then_with(|| c.cmp(f))
            }
            (Expression::IfElse(_, a), Expression::IfElse(_, b)) => a.cmp(b),
            (Expression::Const(_, _), _) => std::cmp::Ordering::Less,
            (_, Expression::Const(_, _)) => std::cmp::Ordering::Greater,
            (Expression::Parameter(_, _), _) => std::cmp::Ordering::Less,
            (_, Expression::Parameter(_, _)) => std::cmp::Ordering::Greater,
            (Expression::Eval(_, _, _), _) => std::cmp::Ordering::Less,
            (_, Expression::Eval(_, _, _)) => std::cmp::Ordering::Greater,
            (Expression::Add(_, _), _) => std::cmp::Ordering::Less,
            (_, Expression::Add(_, _)) => std::cmp::Ordering::Greater,
            (Expression::Mul(_, _), _) => std::cmp::Ordering::Less,
            (_, Expression::Mul(_, _)) => std::cmp::Ordering::Greater,
            (Expression::Pow(_, _), _) => std::cmp::Ordering::Less,
            (_, Expression::Pow(_, _)) => std::cmp::Ordering::Greater,
            (Expression::Powf(_, _), _) => std::cmp::Ordering::Less,
            (_, Expression::Powf(_, _)) => std::cmp::Ordering::Greater,
            (Expression::ReadArg(_, _), _) => std::cmp::Ordering::Less,
            (_, Expression::ReadArg(_, _)) => std::cmp::Ordering::Greater,
            (Expression::BuiltinFun(_, _, _), _) => std::cmp::Ordering::Less,
            (_, Expression::BuiltinFun(_, _, _)) => std::cmp::Ordering::Greater,
            (Expression::Fun(_, _, _, _), _) => std::cmp::Ordering::Less,
            (_, Expression::Fun(_, _, _, _)) => std::cmp::Ordering::Greater,
            (Expression::IfElse(_, _), _) => std::cmp::Ordering::Greater,
            (_, Expression::IfElse(_, _)) => std::cmp::Ordering::Less, // sort last so that parent common subexpressions can be used inside both branches
        }
    }
}

impl<T: Eq + Hash> Hash for Expression<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        state.write_u64(self.get_hash())
    }
}

impl<T: Eq + Hash + Clone + InternalOrdering> Expression<T> {
    fn find_subexpression<'a>(&'a self, subexp: &mut HashMap<&'a Expression<T>, usize>) -> bool {
        if matches!(
            self,
            Expression::Const(_, _) | Expression::Parameter(_, _) | Expression::ReadArg(_, _)
        ) {
            return true;
        }

        if let Some(i) = subexp.get_mut(self) {
            *i += 1;
            return true;
        }

        subexp.insert(self, 1);

        match self {
            Expression::Const(_, _) | Expression::Parameter(_, _) | Expression::ReadArg(_, _) => {}
            Expression::Eval(_, _, ae) => {
                for arg in ae {
                    arg.find_subexpression(subexp);
                }
            }
            Expression::Add(_, a) | Expression::Mul(_, a) | Expression::Fun(_, _, _, a) => {
                for arg in a {
                    arg.find_subexpression(subexp);
                }
            }
            Expression::Pow(_, p) => {
                p.0.find_subexpression(subexp);
            }
            Expression::Powf(_, p) => {
                p.0.find_subexpression(subexp);
                p.1.find_subexpression(subexp);
            }
            Expression::BuiltinFun(_, _, a) => {
                a.find_subexpression(subexp);
            }
            Expression::SubExpression(_, _) => {}
            Expression::IfElse(_, b) => {
                b.0.find_subexpression(subexp);
                b.1.find_subexpression(subexp);
                b.2.find_subexpression(subexp);
            }
        }

        false
    }

    fn replace_subexpression(&mut self, subexp: &HashMap<&Expression<T>, usize>, skip_root: bool) {
        if !skip_root && let Some(i) = subexp.get(self) {
            *self = Expression::SubExpression(self.get_hash(), *i); // TODO: do not recyle hash?
            return;
        }

        match self {
            Expression::Const(_, _) | Expression::Parameter(_, _) | Expression::ReadArg(_, _) => {}
            Expression::Eval(_, _, ae) => {
                for arg in &mut *ae {
                    arg.replace_subexpression(subexp, false);
                }
            }
            Expression::Add(_, a) | Expression::Mul(_, a) | Expression::Fun(_, _, _, a) => {
                for arg in a {
                    arg.replace_subexpression(subexp, false);
                }
            }
            Expression::Pow(_, p) => {
                p.0.replace_subexpression(subexp, false);
            }
            Expression::Powf(_, p) => {
                p.0.replace_subexpression(subexp, false);
                p.1.replace_subexpression(subexp, false);
            }
            Expression::BuiltinFun(_, _, a) => {
                a.replace_subexpression(subexp, false);
            }
            Expression::SubExpression(_, _) => {}
            Expression::IfElse(_, b) => {
                b.0.replace_subexpression(subexp, false);
                b.1.replace_subexpression(subexp, false);
                b.2.replace_subexpression(subexp, false);
            }
        }
    }

    // Count the number of operations in the expression, counting
    // subexpressions only once.
    /// Count arithmetic operations, counting each distinct subexpression once.
    /// `sub_expr` records visited expressions and can be shared across calls to
    /// measure the combined cost of several trees.
    pub fn count_operations_with_subexpression<'a>(
        &'a self,
        sub_expr: &mut HashMap<&'a Self, usize>,
    ) -> OperationCount {
        if matches!(
            self,
            Expression::Const(_, _) | Expression::Parameter(_, _) | Expression::ReadArg(_, _)
        ) {
            return OperationCount::default();
        }

        if sub_expr.contains_key(self) {
            return OperationCount::default();
        }

        sub_expr.insert(self, 1);

        match self {
            Expression::Const(_, _) => OperationCount::default(),
            Expression::Parameter(_, _) => OperationCount::default(),
            Expression::Eval(_, _, args) => {
                let mut count = OperationCount::default();
                for arg in args {
                    count += arg.count_operations_with_subexpression(sub_expr);
                }
                count
            }
            Expression::Add(_, a) => {
                let mut count = OperationCount::default();
                for arg in a {
                    count += arg.count_operations_with_subexpression(sub_expr);
                }
                count.additions += a.len() - 1;
                count
            }
            Expression::Mul(_, m) => {
                let mut count = OperationCount::default();
                for arg in m {
                    count += arg.count_operations_with_subexpression(sub_expr);
                }
                count.multiplications += m.len() - 1;
                count
            }
            Expression::Pow(_, p) => {
                let mut count = p.0.count_operations_with_subexpression(sub_expr);
                count.add_integer_power(p.1);
                count
            }
            Expression::Powf(_, p) => {
                let mut count = p.0.count_operations_with_subexpression(sub_expr)
                    + p.1.count_operations_with_subexpression(sub_expr);
                count.add_function_call();
                count
            }
            Expression::ReadArg(_, _) => OperationCount::default(),
            Expression::BuiltinFun(_, _, b) => {
                let mut count = b.count_operations_with_subexpression(sub_expr);
                count.add_function_call();
                count
            }
            Expression::SubExpression(_, _) => OperationCount::default(),
            Expression::Fun(_, _, _, a) => {
                let mut count = OperationCount::default();
                for arg in a {
                    count += arg.count_operations_with_subexpression(sub_expr);
                }
                count.add_function_call();
                count
            }
            Expression::IfElse(_, b) => {
                b.0.count_operations_with_subexpression(sub_expr)
                    + b.1.count_operations_with_subexpression(sub_expr)
                    + b.2.count_operations_with_subexpression(sub_expr)
            }
        }
    }
}

impl<T: std::hash::Hash + Clone> Expression<T> {
    fn rehashed(mut self, partial: bool) -> Self {
        self.rehash(partial);
        self
    }

    fn rehash(&mut self, partial: bool) -> ExpressionHash {
        match self {
            Expression::Const(h, c) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(0);
                c.hash(&mut hasher);
                *h = hasher.finish();
                *h
            }
            Expression::Parameter(h, p) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(1);
                hasher.write_usize(*p);
                *h = hasher.finish();
                *h
            }
            Expression::Eval(h, i, v) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(2);
                hasher.write_u32(*i);
                for x in v {
                    hasher.write_u64(x.rehash(partial));
                }
                *h = hasher.finish();
                *h
            }
            Expression::Add(h, v) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(3);

                // do an additive hash
                let mut arg_sum = 0u64;
                for x in v {
                    arg_sum = arg_sum.wrapping_add(x.rehash(partial));
                }
                hasher.write_u64(arg_sum);
                *h = hasher.finish();
                *h
            }
            Expression::Mul(h, v) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(4);

                // do an additive hash
                let mut arg_sum = 0u64;
                for x in v {
                    arg_sum = arg_sum.wrapping_add(x.rehash(partial));
                }
                hasher.write_u64(arg_sum);
                *h = hasher.finish();
                *h
            }
            Expression::Pow(h, p) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(5);
                let hb = p.0.rehash(partial);
                hasher.write_u64(hb);
                hasher.write_i64(p.1);
                *h = hasher.finish();
                *h
            }
            Expression::Powf(h, p) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(6);
                let hb = p.0.rehash(partial);
                let he = p.1.rehash(partial);
                hasher.write_u64(hb);
                hasher.write_u64(he);
                *h = hasher.finish();
                *h
            }
            Expression::ReadArg(h, i) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(7);
                hasher.write_usize(*i);
                *h = hasher.finish();
                *h
            }
            Expression::BuiltinFun(h, s, a) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(8);
                s.hash(&mut hasher);
                let ha = a.rehash(partial);
                hasher.write_u64(ha);
                *h = hasher.finish();
                *h
            }
            Expression::SubExpression(h, i) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(9);
                hasher.write_usize(*i);
                *h = hasher.finish();
                *h
            }
            Expression::Fun(h, s, tags, a) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(10);
                s.hash(&mut hasher);
                tags.hash(&mut hasher);
                for x in a {
                    hasher.write_u64(x.rehash(partial));
                }
                *h = hasher.finish();
                *h
            }
            Expression::IfElse(h, b) => {
                if partial && *h != 0 {
                    return *h;
                }

                let mut hasher = AHasher::default();
                hasher.write_u8(11);
                hasher.write_u64(b.0.rehash(partial));
                hasher.write_u64(b.1.rehash(partial));
                hasher.write_u64(b.2.rehash(partial));
                *h = hasher.finish();
                *h
            }
        }
    }
}

impl<T: Clone + PartialEq> SplitExpression<T> {
    pub fn map_coeff<T2, F: Fn(&T) -> T2>(&self, f: &F) -> SplitExpression<T2> {
        SplitExpression {
            tree: self.tree.iter().map(|x| x.map_coeff(f)).collect(),
            subexpressions: self.subexpressions.iter().map(|x| x.map_coeff(f)).collect(),
        }
    }
}

impl<T: Clone + PartialEq> Expression<T> {
    /// Map the coefficients.
    ///
    /// Note that no rehashing is performed.
    pub fn map_coeff<T2, F: Fn(&T) -> T2>(&self, f: &F) -> Expression<T2> {
        match self {
            Expression::Const(h, c) => Expression::Const(*h, Box::new(f(c))),
            Expression::Parameter(h, p) => Expression::Parameter(*h, *p),
            Expression::Eval(h, id, e_args) => {
                Expression::Eval(*h, *id, e_args.iter().map(|x| x.map_coeff(f)).collect())
            }
            Expression::Add(h, a) => {
                let new_args = a.iter().map(|x| x.map_coeff(f)).collect();
                Expression::Add(*h, new_args)
            }
            Expression::Mul(h, m) => {
                let new_args = m.iter().map(|x| x.map_coeff(f)).collect();
                Expression::Mul(*h, new_args)
            }
            Expression::Pow(h, p) => {
                let (b, e) = &**p;
                Expression::Pow(*h, Box::new((b.map_coeff(f), *e)))
            }
            Expression::Powf(h, p) => {
                let (b, e) = &**p;
                Expression::Powf(*h, Box::new((b.map_coeff(f), e.map_coeff(f))))
            }
            Expression::ReadArg(h, s) => Expression::ReadArg(*h, *s),
            Expression::BuiltinFun(h, s, a) => {
                Expression::BuiltinFun(*h, *s, Box::new(a.map_coeff(f)))
            }
            Expression::SubExpression(h, i) => Expression::SubExpression(*h, *i),
            Expression::Fun(h, s, tags, a) => {
                let new_args = a.iter().map(|x| x.map_coeff(f)).collect();
                Expression::Fun(*h, *s, tags.clone(), new_args)
            }
            Expression::IfElse(h, b) => {
                let (cond, then_expr, else_expr) = &**b;
                Expression::IfElse(
                    *h,
                    Box::new((
                        cond.map_coeff(f),
                        then_expr.map_coeff(f),
                        else_expr.map_coeff(f),
                    )),
                )
            }
        }
    }
}

impl Expression<Complex<Rational>> {
    fn strip_constants(
        &mut self,
        constants: &mut Vec<Complex<Rational>>,
        param_count: usize,
        external_functions: &mut Vec<ExternalFunctionContainer<Complex<Rational>>>,
    ) {
        match self {
            Expression::Const(_, t) => {
                if let Some(p) = constants.iter().position(|x| x == &**t) {
                    *self = Expression::Parameter(0, param_count + p);
                } else {
                    constants.push(t.as_ref().clone());
                    *self = Expression::Parameter(0, param_count + constants.len() - 1);
                }
            }
            Expression::Parameter(_, _) => {}
            Expression::Eval(_, _, e_args) => {
                for a in e_args {
                    a.strip_constants(constants, param_count, external_functions);
                }
            }
            Expression::Add(_, a) | Expression::Mul(_, a) => {
                for arg in a {
                    arg.strip_constants(constants, param_count, external_functions);
                }
            }
            Expression::Pow(_, p) => {
                p.0.strip_constants(constants, param_count, external_functions);
            }
            Expression::Powf(_, p) => {
                p.0.strip_constants(constants, param_count, external_functions);
                p.1.strip_constants(constants, param_count, external_functions);
            }
            Expression::ReadArg(_, _) => {}
            Expression::BuiltinFun(_, _, a) => {
                a.strip_constants(constants, param_count, external_functions);
            }
            Expression::SubExpression(_, _) => {}
            Expression::Fun(_, symbol, tags, a) => {
                let fixed_args = a
                    .iter()
                    .map(|arg| match arg {
                        Expression::Const(_, c) => Some(c.as_ref().clone()),
                        _ => None,
                    })
                    .collect::<Option<Vec<_>>>();

                if let Some(fixed_args) = fixed_args {
                    let tags = tags.iter().map(|x| crate::parse!(x)).collect::<Vec<_>>();
                    let i = register_constant_external_container(
                        external_functions,
                        *symbol,
                        tags,
                        fixed_args,
                        constants,
                    );
                    *self = Expression::Parameter(0, param_count + i);
                    return;
                }

                for arg in a {
                    arg.strip_constants(constants, param_count, external_functions);
                }
            }
            Expression::IfElse(_, b) => {
                b.0.strip_constants(constants, param_count, external_functions);
                b.1.strip_constants(constants, param_count, external_functions);
                b.2.strip_constants(constants, param_count, external_functions);
            }
        }
    }
}

impl<T: Clone + PartialEq> EvalTree<T> {
    /// Convert all numerical coefficients with `f`, preserving the expression
    /// structure, parameter order, and function definitions.
    pub fn map_coeff<T2: EvaluationDomain, F: Fn(&T) -> T2>(&self, f: &F) -> EvalTree<T2> {
        EvalTree {
            expressions: SplitExpression {
                tree: self
                    .expressions
                    .tree
                    .iter()
                    .map(|x| x.map_coeff(f))
                    .collect(),
                subexpressions: self
                    .expressions
                    .subexpressions
                    .iter()
                    .map(|x| x.map_coeff(f))
                    .collect(),
            },
            functions: self
                .functions
                .iter()
                .map(|(s, a, e)| (s.clone(), a.clone(), e.map_coeff(f)))
                .collect(),
            external_functions: self.external_functions.iter().map(|x| x.map()).collect(),
            param_count: self.param_count,
        }
    }
}

impl EvalTree<Complex<Rational>> {
    /// Create a linear version of the tree that can be evaluated more efficiently.
    pub fn linearize(
        &mut self,
        settings: &OptimizationSettings,
    ) -> ExpressionEvaluator<Complex<Rational>> {
        // strip every constant and move them into the stack after the params
        let mut constants = vec![];
        self.strip_constants(&mut constants, self.param_count);

        let mut stack = vec![Complex::<Rational>::default(); self.param_count];
        stack.extend(constants);
        let reserved_indices = stack.len();

        let mut sub_expr_pos = HashMap::default();
        let mut instructions = vec![];

        let mut result_indices = vec![];

        for t in &self.expressions.tree {
            let result_index = self.linearize_impl(
                t,
                &self.expressions.subexpressions,
                &mut stack,
                &mut instructions,
                &mut sub_expr_pos,
                &[],
                false,
                reserved_indices,
            );
            result_indices.push(result_index);
        }

        let mut e = ExpressionEvaluator {
            stack,
            param_count: self.param_count,
            reserved_indices,
            instructions,
            result_indices,
            external_fns: self.external_functions.clone(),
            settings: settings.clone(),
        };

        loop {
            let r = e.remove_common_instructions();

            if r == 0 || e.settings.abort_level > 0 {
                e.settings.abort_level = 0;
                break;
            }

            if settings.verbose {
                let count = e.count_operations();
                info!("Removed {} common instructions: {}", r, count);
            }
        }

        for _ in 0..settings.cpe_iterations.unwrap_or(usize::MAX) {
            let r = e.remove_common_pairs();
            if r == 0 || e.settings.abort_level > 0 {
                e.settings.abort_level = 0;
                break;
            }

            if settings.verbose {
                let count = e.count_operations();
                info!("Removed {} common pairs: {}", r, count);
            }
        }

        e.optimize_stack();
        e
    }

    fn strip_constants(&mut self, constants: &mut Vec<Complex<Rational>>, param_count: usize) {
        for t in &mut self.expressions.tree {
            t.strip_constants(constants, param_count, &mut self.external_functions);
        }

        for e in &mut self.expressions.subexpressions {
            e.strip_constants(constants, param_count, &mut self.external_functions);
        }

        for (_, _, e) in &mut self.functions {
            for t in &mut e.tree {
                t.strip_constants(constants, param_count, &mut self.external_functions);
            }

            for e in &mut e.subexpressions {
                e.strip_constants(constants, param_count, &mut self.external_functions);
            }
        }
    }

    // Yields the stack index that contains the output.
    fn linearize_impl(
        &self,
        tree: &Expression<Complex<Rational>>,
        subexpressions: &[Expression<Complex<Rational>>],
        stack: &mut Vec<Complex<Rational>>,
        instr: &mut Vec<(Instr, ComplexPhase)>,
        sub_expr_pos: &mut HashMap<usize, usize>,
        args: &[usize],
        in_branch: bool,
        reserved_indices: usize,
    ) -> usize {
        match tree {
            Expression::Const(_, t) => {
                unreachable!(
                    "Constants should have been stripped from the expression tree. Found constant {}",
                    t
                );
            }
            Expression::Parameter(_, i) => *i,
            Expression::Eval(_, id, e_args) => {
                // inline the function
                let new_args: Vec<_> = e_args
                    .iter()
                    .map(|x| {
                        self.linearize_impl(
                            x,
                            subexpressions,
                            stack,
                            instr,
                            sub_expr_pos,
                            args,
                            in_branch,
                            reserved_indices,
                        )
                    })
                    .collect();

                let mut sub_expr_pos = HashMap::default();
                let func = &self.functions[*id as usize].2;
                self.linearize_impl(
                    &func.tree[0],
                    &func.subexpressions,
                    stack,
                    instr,
                    &mut sub_expr_pos,
                    &new_args,
                    in_branch,
                    reserved_indices,
                )
            }
            Expression::Add(_, a) => {
                let mut args: Vec<_> = a
                    .iter()
                    .map(|x| {
                        self.linearize_impl(
                            x,
                            subexpressions,
                            stack,
                            instr,
                            sub_expr_pos,
                            args,
                            in_branch,
                            reserved_indices,
                        )
                    })
                    .collect();
                args.sort();

                stack.push(Complex::default());
                let res = stack.len() - 1;

                let add = Instr::Add(res, args);
                instr.push((add, ComplexPhase::Any));

                res
            }
            Expression::Mul(_, m) => {
                let mut args: Vec<_> = m
                    .iter()
                    .map(|x| {
                        self.linearize_impl(
                            x,
                            subexpressions,
                            stack,
                            instr,
                            sub_expr_pos,
                            args,
                            in_branch,
                            reserved_indices,
                        )
                    })
                    .collect();
                args.sort();

                stack.push(Complex::default());
                let res = stack.len() - 1;

                let mul = Instr::Mul(res, args);
                instr.push((mul, ComplexPhase::Any));

                res
            }
            Expression::Pow(_, p) => {
                let b = self.linearize_impl(
                    &p.0,
                    subexpressions,
                    stack,
                    instr,
                    sub_expr_pos,
                    args,
                    in_branch,
                    reserved_indices,
                );
                stack.push(Complex::default());
                let mut res = stack.len() - 1;

                if p.1 > 1 {
                    instr.push((Instr::Mul(res, vec![b; p.1 as usize]), ComplexPhase::Any));
                } else if p.1 < -1 {
                    instr.push((Instr::Mul(res, vec![b; -p.1 as usize]), ComplexPhase::Any));
                    stack.push(Complex::default());
                    res += 1;
                    instr.push((Instr::Pow(res, res - 1, -1), ComplexPhase::Any));
                } else {
                    instr.push((Instr::Pow(res, b, p.1), ComplexPhase::Any));
                }
                res
            }
            Expression::Powf(_, p) => {
                let b = self.linearize_impl(
                    &p.0,
                    subexpressions,
                    stack,
                    instr,
                    sub_expr_pos,
                    args,
                    in_branch,
                    reserved_indices,
                );
                let e = self.linearize_impl(
                    &p.1,
                    subexpressions,
                    stack,
                    instr,
                    sub_expr_pos,
                    args,
                    in_branch,
                    reserved_indices,
                );
                stack.push(Complex::default());
                let res = stack.len() - 1;

                instr.push((Instr::Powf(res, b, e), ComplexPhase::Any));
                res
            }
            Expression::ReadArg(_, a) => args[*a],
            Expression::BuiltinFun(_, s, v) => {
                let arg = self.linearize_impl(
                    v,
                    subexpressions,
                    stack,
                    instr,
                    sub_expr_pos,
                    args,
                    in_branch,
                    reserved_indices,
                );
                stack.push(Complex::default());
                let c = Instr::BuiltinFun(stack.len() - 1, *s, arg);
                instr.push((c, ComplexPhase::Any));
                stack.len() - 1
            }
            Expression::SubExpression(_, id) => {
                if sub_expr_pos.contains_key(id) {
                    *sub_expr_pos.get(id).unwrap()
                } else {
                    let res = self.linearize_impl(
                        &subexpressions[*id],
                        subexpressions,
                        stack,
                        instr,
                        sub_expr_pos,
                        args,
                        in_branch,
                        reserved_indices,
                    );

                    // only register the subexpression as computed when it is not
                    // computed in a branch, as the sub expression may not be computed
                    // in the other branch
                    if !in_branch {
                        sub_expr_pos.insert(*id, res);
                    }

                    res
                }
            }
            Expression::Fun(_, s, tags, v) => {
                let args: Vec<_> = v
                    .iter()
                    .map(|x| {
                        self.linearize_impl(
                            x,
                            subexpressions,
                            stack,
                            instr,
                            sub_expr_pos,
                            args,
                            in_branch,
                            reserved_indices,
                        )
                    })
                    .collect();

                stack.push(Complex::default());
                let res = stack.len() - 1;

                let tag_atoms = tags.iter().map(|x| crate::parse!(x)).collect::<Vec<_>>();
                let index = self
                    .external_functions
                    .iter()
                    .position(|x| {
                        x.symbol == *s
                            && x.tags == tag_atoms
                            && x.fixed_args.is_empty()
                            && x.constant_index.is_none()
                    })
                    .expect("missing external function container");

                let f = Instr::ExternalFun(res, index, args);
                instr.push((f, ComplexPhase::Any));

                res
            }
            Expression::IfElse(_, b) => {
                let instr_len = instr.len();
                let stack_len = stack.len();
                let subexpression_len = sub_expr_pos.len();
                let cond = self.linearize_impl(
                    &b.0,
                    subexpressions,
                    stack,
                    instr,
                    sub_expr_pos,
                    args,
                    in_branch,
                    reserved_indices,
                );

                // try to resolve the condition if it is fully numeric
                fn resolve(
                    instr: &[(Instr, ComplexPhase)],
                    stack: &[Complex<Rational>],
                    cond: usize,
                    param_count: usize,
                    reserved_indices: usize,
                ) -> Option<Complex<Rational>> {
                    if cond < param_count {
                        return None;
                    }
                    if cond < reserved_indices {
                        return Some(stack[cond].clone());
                    }

                    match &instr[cond - reserved_indices].0 {
                        Instr::Add(_, args) => {
                            let mut res = Complex::default();
                            for x in args {
                                match resolve(instr, stack, *x, param_count, reserved_indices) {
                                    Some(v) => res += v,
                                    None => return None,
                                }
                            }

                            Some(res)
                        }
                        Instr::Mul(_, args) => {
                            let mut res = Complex::new(Rational::one(), Rational::zero());
                            for x in args {
                                match resolve(instr, stack, *x, param_count, reserved_indices) {
                                    Some(v) => res *= v,
                                    None => return None,
                                }
                            }

                            Some(res)
                        }
                        Instr::Pow(_, base, exp) => {
                            if let Some(base_val) =
                                resolve(instr, stack, *base, param_count, reserved_indices)
                            {
                                if *exp == -1 {
                                    Some(base_val.inv())
                                } else if *exp < 0 {
                                    Some(base_val.pow(exp.unsigned_abs()).inv())
                                } else {
                                    Some(base_val.pow(exp.unsigned_abs()))
                                }
                            } else {
                                None
                            }
                        }
                        _ => None,
                    }
                }

                if let Some(cond_res) =
                    resolve(instr, stack, cond, self.param_count, reserved_indices)
                {
                    // remove dead code
                    instr.truncate(instr_len);
                    stack.truncate(stack_len);
                    if subexpression_len != sub_expr_pos.len() {
                        // remove subexpressions that are created as part of the conditions
                        sub_expr_pos.retain(|_, &mut v| v < reserved_indices + instr_len);
                    }

                    return if !cond_res.is_zero() {
                        self.linearize_impl(
                            &b.1,
                            subexpressions,
                            stack,
                            instr,
                            sub_expr_pos,
                            args,
                            in_branch,
                            reserved_indices,
                        )
                    } else {
                        self.linearize_impl(
                            &b.2,
                            subexpressions,
                            stack,
                            instr,
                            sub_expr_pos,
                            args,
                            in_branch,
                            reserved_indices,
                        )
                    };
                }

                let label_else = Label(instr.len());
                stack.push(Complex::default());
                instr.push((Instr::IfElse(cond, label_else), ComplexPhase::Any));

                let then_branch = self.linearize_impl(
                    &b.1,
                    subexpressions,
                    stack,
                    instr,
                    sub_expr_pos,
                    args,
                    true,
                    reserved_indices,
                );

                let label_end = Label(instr.len());
                stack.push(Complex::default());
                instr.push((Instr::Goto(label_end), ComplexPhase::Any));
                stack.push(Complex::default());
                instr.push((Instr::Label(label_else), ComplexPhase::Any));

                let else_branch = self.linearize_impl(
                    &b.2,
                    subexpressions,
                    stack,
                    instr,
                    sub_expr_pos,
                    args,
                    true,
                    reserved_indices,
                );

                stack.push(Complex::default());
                instr.push((Instr::Label(label_end), ComplexPhase::Any));

                stack.push(Complex::default());
                let res = stack.len() - 1;

                instr.push((
                    Instr::Join(res, cond, then_branch, else_branch),
                    ComplexPhase::Any,
                ));

                res
            }
        }
    }

    /// Find a near-optimal Horner scheme that minimizes the number of multiplications
    /// and additions, using `iterations` iterations of the optimization algorithm
    /// and `n_cores` cores. Optionally, a starting scheme can be provided.
    pub fn optimize(
        mut self,
        settings: &OptimizationSettings,
    ) -> ExpressionEvaluator<Complex<Rational>> {
        if settings.verbose {
            let count = self.count_operations();
            info!("Initial ops: {}", count);
        }

        if settings.horner_iterations > 0 {
            let _ = self.optimize_horner_scheme(settings);
        }

        self.common_subexpression_elimination();
        self.linearize(settings)
    }

    /// Write the expressions in a Horner scheme where the variables
    /// are sorted by their occurrence count.
    pub fn horner_scheme(&mut self) {
        for t in &mut self.expressions.tree {
            t.occurrence_order_horner_scheme();
        }

        for e in &mut self.expressions.subexpressions {
            e.occurrence_order_horner_scheme();
        }

        for (_, _, e) in &mut self.functions {
            for t in &mut e.tree {
                t.occurrence_order_horner_scheme();
            }

            for e in &mut e.subexpressions {
                e.occurrence_order_horner_scheme();
            }
        }
    }

    /// Find a near-optimal Horner scheme that minimizes the number of multiplications
    /// and additions, using `iterations` iterations of the optimization algorithm
    /// and `n_cores` cores. Optionally, a starting scheme can be provided.
    pub fn optimize_horner_scheme(
        &mut self,
        settings: &OptimizationSettings,
    ) -> Vec<Expression<Complex<Rational>>> {
        let v = match &settings.hot_start {
            Some(a) => a.clone(),
            None => {
                let mut v = HashMap::default();

                for t in &mut self.expressions.tree {
                    t.find_all_variables(&mut v);
                }

                for e in &mut self.expressions.subexpressions {
                    e.find_all_variables(&mut v);
                }

                let mut v: Vec<_> = v.into_iter().collect();
                v.retain(|(_, vv)| *vv > 1);
                v.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
                v.truncate(settings.max_horner_scheme_variables);
                v.into_iter().map(|(k, _)| k).collect::<Vec<_>>()
            }
        };

        let scheme =
            Expression::optimize_horner_scheme_multiple(&self.expressions.tree, &v, settings);
        for e in &mut self.expressions.tree {
            e.apply_horner_scheme(&scheme);
        }

        for e in &mut self.expressions.subexpressions {
            e.apply_horner_scheme(&scheme);
        }

        for (name, _, e) in &mut self.functions {
            let mut v = HashMap::default();

            for t in &mut e.tree {
                t.find_all_variables(&mut v);
            }

            for e in &mut e.subexpressions {
                e.find_all_variables(&mut v);
            }

            let mut v: Vec<_> = v.into_iter().collect();
            v.retain(|(_, vv)| *vv > 1);
            v.sort_by_key(|k| Reverse(k.1));
            v.truncate(settings.max_horner_scheme_variables);
            let v = v.into_iter().map(|(k, _)| k).collect::<Vec<_>>();

            if settings.verbose {
                info!(
                    "Optimizing Horner scheme for function {} with {} variables",
                    name,
                    v.len()
                );
            }

            let scheme = Expression::optimize_horner_scheme_multiple(&e.tree, &v, settings);

            for t in &mut e.tree {
                t.apply_horner_scheme(&scheme);
            }

            for e in &mut e.subexpressions {
                e.apply_horner_scheme(&scheme);
            }
        }

        scheme
    }
}

impl Expression<Complex<Rational>> {
    /// Rewrite sums using a Horner scheme in the supplied variable order.
    /// The entries in `scheme` identify the subexpressions to factor out.
    pub fn apply_horner_scheme(&mut self, scheme: &[Expression<Complex<Rational>>]) {
        if scheme.is_empty() {
            return;
        }

        let a = match self {
            Expression::Add(_, a) => a,
            Expression::Eval(_, _, a) => {
                for arg in a {
                    arg.apply_horner_scheme(scheme);
                }
                return;
            }
            Expression::Mul(_, m) => {
                for a in m {
                    a.apply_horner_scheme(scheme);
                }
                return;
            }
            Expression::Pow(_, b) => {
                b.0.apply_horner_scheme(scheme);
                return;
            }
            Expression::Powf(_, b) => {
                b.0.apply_horner_scheme(scheme);
                b.1.apply_horner_scheme(scheme);
                return;
            }
            Expression::BuiltinFun(_, _, b) => {
                b.apply_horner_scheme(scheme);
                return;
            }
            _ => {
                return;
            }
        };

        a.sort();

        let mut max_pow: Option<i64> = None;
        for x in &*a {
            if let Expression::Mul(_, m) = x {
                let mut pow_counter = 0;
                for y in m {
                    if let Expression::Pow(_, p) = y {
                        if p.0 == scheme[0] && p.1 > 0 {
                            pow_counter += p.1;
                        }
                    } else if y == &scheme[0] {
                        pow_counter += 1; // support x*x*x^3 in term
                    }
                }

                if pow_counter > 0 && (max_pow.is_none() || pow_counter < max_pow.unwrap()) {
                    max_pow = Some(pow_counter);
                }
            } else if let Expression::Pow(_, p) = x {
                if p.0 == scheme[0] && p.1 > 0 && (max_pow.is_none() || p.1 < max_pow.unwrap()) {
                    max_pow = Some(p.1);
                }
            } else if x == &scheme[0] {
                max_pow = Some(1);
            }
        }

        // TODO: jump to next variable if the current variable only appears in one factor?
        // this will improve the scheme but may hide common subexpressions?

        let Some(max_pow) = max_pow else {
            return self.apply_horner_scheme(&scheme[1..]);
        };

        // extract GCD and phase of integer coefficients
        // keep rational coefficients untouched to avoid numerical precision issues
        let mut gcd = Complex::new(Rational::zero(), Rational::zero());
        for x in &*a {
            let mut num = None;

            if let Expression::Mul(_, m) = x {
                for y in m {
                    if let Expression::Const(_, c) = y
                        && c.re.is_integer()
                        && c.im.is_integer()
                    {
                        num = Some(c);
                    }
                }
            } else if let Expression::Const(_, c) = x
                && c.re.is_integer()
                && c.im.is_integer()
            {
                num = Some(c);
            }

            if let Some(n) = num {
                if n.im.is_zero() && gcd.im.is_zero() {
                    gcd = Complex::new(gcd.re.gcd(&n.re), Rational::zero());
                } else if n.re.is_zero() && gcd.re.is_zero() {
                    gcd = Complex::new(Rational::zero(), gcd.im.gcd(&n.im));
                } else {
                    gcd = Complex::new_one();
                }
            } else {
                gcd = Complex::new_one();
            }
        }

        if !gcd.is_zero() && !gcd.is_one() {
            for x in &mut *a {
                match x {
                    Expression::Mul(_, m) => {
                        for y in m {
                            if let Expression::Const(_, c) = y {
                                **c /= &gcd;
                                break;
                            }
                        }
                    }
                    Expression::Const(_, c) => {
                        **c /= &gcd;
                    }
                    _ => {
                        unreachable!()
                    }
                }
            }
        }

        let mut contains = vec![];
        let mut rest = vec![];

        for mut x in a.drain(..) {
            let mut found = false;
            if let Expression::Mul(_, m) = &mut x {
                let mut pow_counter = 0;

                m.retain(|y| {
                    if let Expression::Pow(_, p) = y {
                        if p.0 == scheme[0] && p.1 > 0 {
                            pow_counter += p.1;
                            false
                        } else {
                            true
                        }
                    } else if y == &scheme[0] {
                        pow_counter += 1;
                        false
                    } else {
                        true
                    }
                });

                if pow_counter > max_pow {
                    if pow_counter > max_pow + 1 {
                        m.push(
                            Expression::Pow(
                                0,
                                Box::new((scheme[0].clone(), pow_counter - max_pow)),
                            )
                            .rehashed(true),
                        );
                    } else {
                        m.push(scheme[0].clone());
                    }

                    m.sort();
                }

                if m.is_empty() {
                    x = Expression::Const(0, Box::new(Complex::new_one())).rehashed(true);
                } else if m.len() == 1 {
                    x = m.pop().unwrap();
                }

                found = pow_counter > 0;
            } else if let Expression::Pow(_, p) = &mut x {
                if p.0 == scheme[0] && p.1 > 0 {
                    if p.1 > max_pow + 1 {
                        p.1 -= max_pow;
                    } else if p.1 - max_pow == 1 {
                        x = scheme[0].clone();
                    } else {
                        x = Expression::Const(0, Box::new(Complex::new_one())).rehashed(true);
                    }
                    found = true;
                }
            } else if x == scheme[0] {
                found = true;
                x = Expression::Const(0, Box::new(Complex::new_one())).rehashed(true);
            }

            if found {
                contains.push(x);
            } else {
                rest.push(x);
            }
        }

        let extracted = if max_pow == 1 {
            scheme[0].clone()
        } else {
            Expression::Pow(0, Box::new((scheme[0].clone(), max_pow))).rehashed(true)
        };

        let mut contains = if contains.len() == 1 {
            contains.pop().unwrap()
        } else {
            Expression::Add(0, contains).rehashed(true)
        };

        contains.apply_horner_scheme(scheme); // keep trying with same variable

        let mut v = vec![];
        if let Expression::Mul(_, a) = contains {
            v.extend(a);
        } else {
            v.push(contains);
        }

        v.push(extracted);
        v.retain(|x| {
            if let Expression::Const(_, y) = x
                && y.is_one()
            {
                false
            } else {
                true
            }
        });
        v.sort();

        let mut c = if v.len() == 1 {
            v.pop().unwrap()
        } else {
            Expression::Mul(0, v).rehashed(true)
        };

        if rest.is_empty() {
            if !gcd.is_zero() && !gcd.is_one() {
                if let Expression::Mul(_, v) = &mut c {
                    v.push(Expression::Const(0, Box::new(gcd)));
                    v.sort();
                    *self = c.rehashed(true);
                } else {
                    *self = Expression::Mul(0, vec![Expression::Const(0, Box::new(gcd)), c])
                        .rehashed(true);
                }
            } else {
                *self = c.rehashed(true);
            }
        } else {
            let mut r = if rest.len() == 1 {
                rest.pop().unwrap()
            } else {
                Expression::Add(0, rest).rehashed(true)
            };

            r.apply_horner_scheme(&scheme[1..]);

            a.clear();
            a.push(c);

            if let Expression::Add(_, aa) = r {
                a.extend(aa);
            } else {
                a.push(r);
            }

            a.sort();

            if !gcd.is_zero() && !gcd.is_one() {
                *self = Expression::Mul(
                    0,
                    vec![
                        Expression::Const(0, Box::new(gcd)),
                        Expression::Add(0, std::mem::take(a)),
                    ],
                )
                .rehashed(true);
            }
        }
    }

    /// Apply a simple occurrence-order Horner scheme to every addition.
    pub fn occurrence_order_horner_scheme(&mut self) {
        match self {
            Expression::Const(_, _) | Expression::Parameter(_, _) | Expression::ReadArg(_, _) => {}
            Expression::Eval(_, _, ae) => {
                for arg in ae {
                    arg.occurrence_order_horner_scheme();
                }
            }
            Expression::Add(_, a) => {
                for arg in &mut *a {
                    arg.occurrence_order_horner_scheme();
                }

                let mut occurrence = HashMap::default();

                for arg in &*a {
                    match arg {
                        Expression::Mul(_, m) => {
                            for aa in m {
                                if let Expression::Pow(_, p) = aa
                                    && !matches!(p.0, Expression::Const(_, _))
                                {
                                    occurrence
                                        .entry(p.0.clone())
                                        .and_modify(|x| *x += 1)
                                        .or_insert(1);
                                } else if !matches!(aa, Expression::Const(_, _)) {
                                    occurrence
                                        .entry(aa.clone())
                                        .and_modify(|x| *x += 1)
                                        .or_insert(1);
                                }
                            }
                        }
                        x => {
                            if let Expression::Pow(_, p) = x
                                && !matches!(p.0, Expression::Const(_, _))
                            {
                                occurrence
                                    .entry(p.0.clone())
                                    .and_modify(|x| *x += 1)
                                    .or_insert(1);
                            } else if !matches!(x, Expression::Const(_, _)) {
                                occurrence
                                    .entry(x.clone())
                                    .and_modify(|x| *x += 1)
                                    .or_insert(1);
                            }
                        }
                    }
                }

                occurrence.retain(|_, v| *v > 1);
                let mut order: Vec<_> = occurrence.into_iter().collect();
                order.sort_by_key(|k| Reverse(k.1)); // occurrence order
                let scheme = order.into_iter().map(|(k, _)| k).collect::<Vec<_>>();

                self.apply_horner_scheme(&scheme);
            }
            Expression::Mul(_, a) => {
                for arg in a {
                    arg.occurrence_order_horner_scheme();
                }
            }
            Expression::Pow(_, p) => {
                p.0.occurrence_order_horner_scheme();
            }
            Expression::Powf(_, p) => {
                p.0.occurrence_order_horner_scheme();
                p.1.occurrence_order_horner_scheme();
            }
            Expression::BuiltinFun(_, _, a) => {
                a.occurrence_order_horner_scheme();
            }
            Expression::SubExpression(_, _) => {}
            Expression::Fun(_, _, _, a) => {
                for arg in a {
                    arg.occurrence_order_horner_scheme();
                }
            }
            Expression::IfElse(_, b) => {
                b.0.occurrence_order_horner_scheme();
                b.1.occurrence_order_horner_scheme();
                b.2.occurrence_order_horner_scheme();
            }
        }
    }

    /// Search for a Horner variable order that reduces this expression's operation
    /// count. `vars` supplies the initial order and `settings` bounds the search.
    pub fn optimize_horner_scheme(
        &self,
        vars: &[Self],
        settings: &OptimizationSettings,
    ) -> Vec<Self> {
        Self::optimize_horner_scheme_multiple(std::slice::from_ref(self), vars, settings)
    }

    /// Search for a shared Horner variable order that reduces the combined
    /// operation count of `expressions`, accounting for common subexpressions.
    /// `vars` supplies the initial order and `settings` bounds the search.
    pub fn optimize_horner_scheme_multiple(
        expressions: &[Self],
        vars: &[Self],
        settings: &OptimizationSettings,
    ) -> Vec<Self> {
        if vars.is_empty() {
            return vars.to_vec();
        }

        let horner: Vec<_> = expressions
            .iter()
            .map(|x| {
                let mut h = x.clone();
                h.apply_horner_scheme(vars);
                h.rehashed(true)
            })
            .collect();
        let mut subexpr = HashMap::default();
        let mut best_ops = OperationCount::default();
        for h in &horner {
            let ops = h.count_operations_with_subexpression(&mut subexpr);
            best_ops += ops;
        }

        if settings.verbose {
            info!("Initial Horner scheme ops: {}", best_ops);
        }

        let best_mul = Arc::new(AtomicUsize::new(best_ops.multiplications));
        let best_add = Arc::new(AtomicUsize::new(best_ops.additions));
        let best_scheme = Arc::new(Mutex::new(vars.to_vec()));

        let n_iterations = settings.horner_iterations.max(1) - 1;

        let permutations = if vars.len() < 10
            && Integer::factorial(vars.len() as u32) <= settings.horner_iterations.max(1)
        {
            let v: Vec<_> = (0..vars.len()).collect();
            Some(unique_permutations(&v).1)
        } else {
            None
        };
        let p_ref = &permutations;

        let n_cores = LicenseManager::max_threads(settings.n_cores).min(n_iterations);
        let inherited_unlock = crate::license::InheritedLibraryUnlock::capture();

        std::thread::scope(|s| {
            let abort = Arc::new(AtomicBool::new(false));

            for i in 0..n_cores {
                let mut rng = MonteCarloRng::new(0, i);

                let mut cvars = vars.to_vec();
                let best_scheme = best_scheme.clone();
                let best_mul = best_mul.clone();
                let best_add = best_add.clone();
                let mut last_mul = usize::MAX;
                let mut last_add = usize::MAX;
                let abort = abort.clone();

                let mut op = move || {
                    let _unlock = inherited_unlock.activate();
                    for j in 0..n_iterations / n_cores {
                        if abort.load(Ordering::Relaxed) {
                            return;
                        }

                        if i == n_cores - 1
                            && let Some(a) = &settings.abort_check
                            && a()
                        {
                            abort.store(true, Ordering::Relaxed);

                            if settings.verbose {
                                info!(
                                    "Aborting Horner optimization at step {}/{}.",
                                    j,
                                    settings.horner_iterations / n_cores
                                );
                            }

                            return;
                        }

                        // try a random swap
                        let mut t1 = 0;
                        let mut t2 = 0;

                        if let Some(p) = p_ref {
                            if j >= p.len() / n_cores {
                                break;
                            }

                            let perm = &p[i * (p.len() / n_cores) + j];
                            cvars = perm.iter().map(|x| vars[*x].clone()).collect();
                        } else {
                            t1 = rng.random_range(0..cvars.len());
                            t2 = rng.random_range(0..cvars.len() - 1);

                            cvars.swap(t1, t2);
                        }

                        let horner: Vec<_> = expressions
                            .iter()
                            .map(|x| {
                                let mut h = x.clone();
                                h.apply_horner_scheme(&cvars);
                                h.rehash(true);
                                h
                            })
                            .collect();
                        let mut subexpr = HashMap::default();
                        let mut cur_ops = OperationCount::default();

                        for h in &horner {
                            let ops = h.count_operations_with_subexpression(&mut subexpr);
                            cur_ops += ops;
                        }

                        // prefer fewer multiplications
                        if cur_ops.multiplications <= last_mul
                            || cur_ops.multiplications == last_mul && cur_ops.additions <= last_add
                        {
                            if settings.verbose {
                                info!(
                                    "Accept move at step {}/{}: {}",
                                    j,
                                    settings.horner_iterations / n_cores,
                                    cur_ops
                                );
                            }

                            last_add = cur_ops.additions;
                            last_mul = cur_ops.multiplications;

                            if cur_ops.multiplications <= best_mul.load(Ordering::Relaxed)
                                || cur_ops.multiplications == best_mul.load(Ordering::Relaxed)
                                    && cur_ops.additions <= best_add.load(Ordering::Relaxed)
                            {
                                let mut best_scheme = best_scheme.lock().unwrap();

                                // check again if it is the best now that we have locked
                                let best_mul_l = best_mul.load(Ordering::Relaxed);
                                let best_add_l = best_add.load(Ordering::Relaxed);
                                if cur_ops.multiplications <= best_mul_l
                                    || cur_ops.multiplications == best_mul_l
                                        && cur_ops.additions <= best_add_l
                                {
                                    if cur_ops.additions == best_add_l
                                        && cur_ops.multiplications == best_mul_l
                                    {
                                        if *best_scheme < cvars {
                                            // on a draw, accept the lexicographical minimum
                                            // to get a deterministic scheme
                                            *best_scheme = cvars.clone();
                                        }
                                    } else {
                                        best_mul.store(cur_ops.multiplications, Ordering::Relaxed);
                                        best_add.store(cur_ops.additions, Ordering::Relaxed);
                                        *best_scheme = cvars.clone();
                                    }
                                }
                            }
                        } else {
                            cvars.swap(t1, t2);
                        }
                    }
                };

                if i + 1 < n_cores {
                    s.spawn(op);
                } else {
                    // execute in the main thread and do the abort check on the main thread
                    // this helps with catching ctrl-c
                    op()
                }
            }
        });

        if settings.verbose {
            info!(
                "Final scheme: {} + and {} ×",
                best_add.load(Ordering::Relaxed),
                best_mul.load(Ordering::Relaxed)
            );
        }

        Arc::try_unwrap(best_scheme).unwrap().into_inner().unwrap()
    }

    fn find_all_variables(&self, vars: &mut HashMap<Expression<Complex<Rational>>, usize>) {
        match self {
            Expression::Const(_, _) | Expression::Parameter(_, _) | Expression::ReadArg(_, _) => {}
            Expression::Eval(_, _, ae) => {
                for arg in ae {
                    arg.find_all_variables(vars);
                }
            }
            Expression::Add(_, a) => {
                for arg in a {
                    arg.find_all_variables(vars);
                }

                for arg in a {
                    match arg {
                        Expression::Mul(_, m) => {
                            for aa in m {
                                if let Expression::Pow(_, p) = aa
                                    && !matches!(p.0, Expression::Const(_, _))
                                {
                                    vars.entry(p.0.clone()).and_modify(|x| *x += 1).or_insert(1);
                                } else if !matches!(aa, Expression::Const(_, _)) {
                                    vars.entry(aa.clone()).and_modify(|x| *x += 1).or_insert(1);
                                }
                            }
                        }
                        x => {
                            if let Expression::Pow(_, p) = x
                                && !matches!(p.0, Expression::Const(_, _))
                            {
                                vars.entry(p.0.clone()).and_modify(|x| *x += 1).or_insert(1);
                            } else if !matches!(x, Expression::Const(_, _)) {
                                vars.entry(x.clone()).and_modify(|x| *x += 1).or_insert(1);
                            }
                        }
                    }
                }
            }
            Expression::Mul(_, a) => {
                for arg in a {
                    arg.find_all_variables(vars);
                }
            }
            Expression::Pow(_, p) => {
                p.0.find_all_variables(vars);
            }
            Expression::Powf(_, p) => {
                p.0.find_all_variables(vars);
                p.1.find_all_variables(vars);
            }
            Expression::BuiltinFun(_, _, a) => {
                a.find_all_variables(vars);
            }
            Expression::SubExpression(_, _) => {}
            Expression::Fun(_, _, _, a) => {
                for arg in a {
                    arg.find_all_variables(vars);
                }
            }
            Expression::IfElse(_, b) => {
                b.0.find_all_variables(vars);
                b.1.find_all_variables(vars);
                b.2.find_all_variables(vars);
            }
        }
    }
}

impl<T: Clone + Default + std::fmt::Debug + Eq + std::hash::Hash + InternalOrdering> EvalTree<T> {
    /// Extract repeated subexpressions from the outputs and each function body
    /// so that subsequent evaluation can reuse their values.
    pub fn common_subexpression_elimination(&mut self) {
        self.expressions.common_subexpression_elimination();

        for (_, _, e) in &mut self.functions {
            e.common_subexpression_elimination();
        }
    }

    /// Count arithmetic operations in the outputs, extracted subexpressions,
    /// and function definitions, counting each stored tree once.
    pub fn count_operations(&self) -> OperationCount {
        let mut count = OperationCount::default();
        for e in &self.functions {
            count += e.2.count_operations();
        }

        count + self.expressions.count_operations()
    }
}

impl<T: Clone + Default + std::fmt::Debug + Eq + std::hash::Hash + InternalOrdering>
    SplitExpression<T>
{
    /// Eliminate common subexpressions in the expression, also checking for subexpressions
    /// up to length `max_subexpr_len`.
    pub fn common_subexpression_elimination(&mut self) {
        let mut subexpression_count = HashMap::default();

        for t in &mut self.tree {
            t.rehash(true);
            t.find_subexpression(&mut subexpression_count);
        }

        subexpression_count.retain(|_, v| *v > 1);

        let mut v: Vec<_> = subexpression_count
            .iter()
            .map(|(k, v)| (*v, (*k).clone()))
            .collect();
        v.sort_by(|a, b| a.0.cmp(&b.0).then_with(|| a.1.cmp(&b.1)));

        // assign a unique index to every subexpression
        let mut h = HashMap::default();
        for (index, (_, e)) in v.iter().enumerate() {
            h.insert(e, self.subexpressions.len() + index);
        }

        for t in &mut self.tree {
            t.replace_subexpression(&h, false);
        }

        // replace subexpressions in subexpressions and
        // sort them based on their dependencies
        for (_, x) in &v {
            let mut he = x.clone();
            he.replace_subexpression(&h, true);
            self.subexpressions.push(he);
        }

        let mut dep_tree = vec![];
        for (i, s) in self.subexpressions.iter().enumerate() {
            let mut deps = vec![];
            s.get_dependent_subexpressions(&mut deps);
            dep_tree.push((i, deps.clone()));
        }

        let mut rename = HashMap::default();
        let mut new_subs = vec![];
        let mut i = 0;
        while !dep_tree.is_empty() {
            if dep_tree[i].1.iter().all(|x| rename.contains_key(x)) {
                rename.insert(dep_tree[i].0, new_subs.len());
                new_subs.push(self.subexpressions[dep_tree[i].0].clone());
                dep_tree.swap_remove(i);
                if i == dep_tree.len() {
                    i = 0;
                }
            } else {
                i = (i + 1) % dep_tree.len();
            }
        }

        for x in &mut new_subs {
            x.rename_subexpression(&rename);
        }
        for t in &mut self.tree {
            t.rename_subexpression(&rename);
        }

        self.subexpressions = new_subs;
    }
}

impl<T: Clone + Default + std::fmt::Debug + Eq + std::hash::Hash + InternalOrdering> Expression<T> {
    fn rename_subexpression(&mut self, subexp: &HashMap<usize, usize>) {
        match self {
            Expression::Const(_, _) | Expression::Parameter(_, _) | Expression::ReadArg(_, _) => {}
            Expression::Eval(_, _, ae) => {
                for arg in &mut *ae {
                    arg.rename_subexpression(subexp);
                }
            }
            Expression::Add(_, a) | Expression::Mul(_, a) => {
                for arg in &mut *a {
                    arg.rename_subexpression(subexp);
                }

                a.sort();
            }
            Expression::Pow(_, p) => {
                p.0.rename_subexpression(subexp);
            }
            Expression::Powf(_, p) => {
                p.0.rename_subexpression(subexp);
                p.1.rename_subexpression(subexp);
            }
            Expression::BuiltinFun(_, _, a) => {
                a.rename_subexpression(subexp);
            }
            Expression::SubExpression(h, i) => {
                *self = Expression::SubExpression(*h, *subexp.get(i).unwrap());
            }
            Expression::Fun(_, _, _, a) => {
                for arg in a {
                    arg.rename_subexpression(subexp);
                }
            }
            Expression::IfElse(_, b) => {
                b.0.rename_subexpression(subexp);
                b.1.rename_subexpression(subexp);
                b.2.rename_subexpression(subexp);
            }
        }
    }

    fn get_dependent_subexpressions(&self, dep: &mut Vec<usize>) {
        match self {
            Expression::Const(_, _) | Expression::Parameter(_, _) | Expression::ReadArg(_, _) => {}
            Expression::Eval(_, _, ae) => {
                for arg in ae {
                    arg.get_dependent_subexpressions(dep);
                }
            }
            Expression::Add(_, a) | Expression::Mul(_, a) => {
                for arg in a {
                    arg.get_dependent_subexpressions(dep);
                }
            }
            Expression::Pow(_, p) => {
                p.0.get_dependent_subexpressions(dep);
            }
            Expression::Powf(_, p) => {
                p.0.get_dependent_subexpressions(dep);
                p.1.get_dependent_subexpressions(dep);
            }
            Expression::BuiltinFun(_, _, a) => {
                a.get_dependent_subexpressions(dep);
            }
            Expression::SubExpression(_, i) => {
                dep.push(*i);
            }
            Expression::Fun(_, _, _, a) => {
                for arg in a {
                    arg.get_dependent_subexpressions(dep);
                }
            }
            Expression::IfElse(_, b) => {
                b.0.get_dependent_subexpressions(dep);
                b.1.get_dependent_subexpressions(dep);
                b.2.get_dependent_subexpressions(dep);
            }
        }
    }
}

impl<T: Clone + Default + std::fmt::Debug + Eq + std::hash::Hash + InternalOrdering>
    SplitExpression<T>
{
    pub fn count_operations(&self) -> OperationCount {
        let mut count = OperationCount::default();
        for e in &self.subexpressions {
            count += e.count_operations();
        }

        for e in &self.tree {
            count += e.count_operations();
        }

        count
    }
}

impl<T: Clone + Default + std::fmt::Debug + Eq + std::hash::Hash + InternalOrdering> Expression<T> {
    // Count the number of operations in the expression.
    /// Count arithmetic operations recursively, including repeated occurrences
    /// of the same subtree. Use [`Self::count_operations_with_subexpression`]
    /// to count shared subexpressions only once.
    pub fn count_operations(&self) -> OperationCount {
        match self {
            Expression::Const(_, _) => OperationCount::default(),
            Expression::Parameter(_, _) => OperationCount::default(),
            Expression::Eval(_, _, args) => {
                let mut count = OperationCount::default();
                for arg in args {
                    count += arg.count_operations();
                }
                count
            }
            Expression::Add(_, a) => {
                let mut count = OperationCount::default();
                for arg in a {
                    count += arg.count_operations();
                }
                count.additions += a.len() - 1;
                count
            }
            Expression::Mul(_, m) => {
                let mut count = OperationCount::default();
                for arg in m {
                    count += arg.count_operations();
                }
                count.multiplications += m.len() - 1;
                count
            }
            Expression::Pow(_, p) => {
                let mut count = p.0.count_operations();
                count.add_integer_power(p.1);
                count
            }
            Expression::Powf(_, p) => {
                let mut count = p.0.count_operations() + p.1.count_operations();
                count.add_function_call();
                count
            }
            Expression::ReadArg(_, _) => OperationCount::default(),
            Expression::BuiltinFun(_, _, b) => {
                let mut count = b.count_operations();
                count.add_function_call();
                count
            }
            Expression::SubExpression(_, _) => OperationCount::default(),
            Expression::Fun(_, _, _, args) => {
                let mut count = OperationCount::default();
                for arg in args {
                    count += arg.count_operations();
                }
                count.add_function_call();
                count
            }
            Expression::IfElse(_, b) => {
                b.0.count_operations() + b.1.count_operations() + b.2.count_operations()
            }
        }
    }
}

impl<T: Real> EvalTree<T> {
    /// Evaluate the evaluation tree. Consider converting to a linear form for repeated evaluation.
    pub fn evaluate(&mut self, params: &[T], out: &mut [T]) {
        for (o, e) in out.iter_mut().zip(&self.expressions.tree) {
            *o = self.evaluate_impl(e, &self.expressions.subexpressions, params, &[])
        }
    }

    fn evaluate_impl(
        &self,
        expr: &Expression<T>,
        subexpressions: &[Expression<T>],
        params: &[T],
        args: &[T],
    ) -> T {
        match expr {
            Expression::Const(_, c) => c.as_ref().clone(),
            Expression::Parameter(_, p) => params[*p].clone(),
            Expression::Eval(_, f, e_args) => {
                let mut arg_buf = vec![T::new_zero(); e_args.len()];
                for (b, a) in arg_buf.iter_mut().zip(e_args.iter()) {
                    *b = self.evaluate_impl(a, subexpressions, params, args);
                }

                let func = &self.functions[*f as usize].2;
                self.evaluate_impl(&func.tree[0], &func.subexpressions, params, &arg_buf)
            }
            Expression::Add(_, a) => {
                let mut r = self.evaluate_impl(&a[0], subexpressions, params, args);
                for arg in &a[1..] {
                    r += self.evaluate_impl(arg, subexpressions, params, args);
                }
                r
            }
            Expression::Mul(_, m) => {
                let mut r = self.evaluate_impl(&m[0], subexpressions, params, args);
                for arg in &m[1..] {
                    r *= self.evaluate_impl(arg, subexpressions, params, args);
                }
                r
            }
            Expression::Pow(_, p) => {
                let (b, e) = &**p;
                let b_eval = self.evaluate_impl(b, subexpressions, params, args);

                if *e == -1 {
                    b_eval.inv()
                } else if *e >= 0 {
                    b_eval.pow(*e as u64)
                } else {
                    b_eval.pow(e.unsigned_abs()).inv()
                }
            }
            Expression::Powf(_, p) => {
                let (b, e) = &**p;
                let b_eval = self.evaluate_impl(b, subexpressions, params, args);
                let e_eval = self.evaluate_impl(e, subexpressions, params, args);
                b_eval.powf(&e_eval)
            }
            Expression::ReadArg(_, i) => args[*i].clone(),
            Expression::BuiltinFun(_, s, a) => {
                let arg = self.evaluate_impl(a, subexpressions, params, args);
                match s.get_id() {
                    Symbol::EXP_ID => arg.exp(),
                    Symbol::LOG_ID => arg.log(),
                    Symbol::SIN_ID => arg.sin(),
                    Symbol::COS_ID => arg.cos(),
                    Symbol::SQRT_ID => arg.sqrt(),
                    Symbol::ABS_ID => arg.norm(),
                    Symbol::CONJ_ID => arg.conj(),
                    _ => unreachable!(),
                }
            }
            Expression::SubExpression(_, s) => {
                // TODO: cache
                self.evaluate_impl(&subexpressions[*s], subexpressions, params, args)
            }
            Expression::Fun(_, name, _, _args) => {
                unimplemented!(
                    "External function calls not implemented for EvalTree: {}",
                    name
                );
            }
            Expression::IfElse(_, b) => {
                let cond = self.evaluate_impl(&b.0, subexpressions, params, args);
                if !cond.is_fully_zero() {
                    self.evaluate_impl(&b.1, subexpressions, params, args)
                } else {
                    self.evaluate_impl(&b.2, subexpressions, params, args)
                }
            }
        }
    }
}

impl<'a> AtomView<'a> {
    /// Convert nested expressions to a tree.
    pub fn to_evaluation_tree(
        &self,
        fn_map: &FunctionMap,
        params: &[Atom],
    ) -> Result<EvalTree<Complex<Rational>>, EvaluationError> {
        Self::to_eval_tree_multiple(std::slice::from_ref(self), fn_map, params)
    }

    /// Convert nested expressions to a tree.
    pub fn to_eval_tree_multiple<A: AtomCore>(
        exprs: &[A],
        fn_map: &FunctionMap,
        params: &[Atom],
    ) -> Result<EvalTree<Complex<Rational>>, EvaluationError> {
        let mut funcs = vec![];
        let mut func_id_to_index = HashMap::default();
        let mut external_functions = vec![];

        let tree = exprs
            .iter()
            .map(|t| {
                t.as_atom_view()
                    .to_eval_tree_impl(
                        fn_map,
                        params,
                        &[],
                        &mut func_id_to_index,
                        &mut funcs,
                        &mut external_functions,
                    )
                    .map(|x| x.rehashed(true))
            })
            .collect::<Result<_, _>>()?;

        Ok(EvalTree {
            expressions: SplitExpression {
                tree,
                subexpressions: vec![],
            },
            functions: funcs,
            external_functions,
            param_count: params.len(),
        })
    }

    fn to_eval_tree_impl(
        &self,
        fn_map: &FunctionMap,
        params: &[Atom],
        args: &[Indeterminate],
        fn_id_map: &mut HashMap<usize, Option<usize>>,
        funcs: &mut Vec<(
            String,
            Vec<Indeterminate>,
            SplitExpression<Complex<Rational>>,
        )>,
        external_functions: &mut Vec<ExternalFunctionContainer<Complex<Rational>>>,
    ) -> Result<Expression<Complex<Rational>>, EvaluationError> {
        if matches!(self, AtomView::Var(_) | AtomView::Fun(_)) {
            if let Some(p) = args.iter().position(|s| *self == s.as_view()) {
                return Ok(Expression::ReadArg(0, p));
            }

            if let Some(p) = params.iter().position(|a| a.as_view() == *self) {
                return Ok(Expression::Parameter(0, p));
            }
        }

        match self {
            AtomView::Num(n) => match n.get_coeff_view() {
                CoefficientView::Natural(n, d, ni, di) => Ok(Expression::Const(
                    0,
                    Box::new(Complex::new(
                        Rational::from((n, d)),
                        Rational::from((ni, di)),
                    )),
                )),
                CoefficientView::Large(l, i) => Ok(Expression::Const(
                    0,
                    Box::new(Complex::new(l.to_rat(), i.to_rat())),
                )),
                CoefficientView::Float(r, i) => {
                    // TODO: converting back to rational is slow
                    Ok(Expression::Const(
                        0,
                        Box::new(Complex::new(
                            r.to_float().to_rational(),
                            i.to_float().to_rational(),
                        )),
                    ))
                }
                CoefficientView::Indeterminate => Err(EvaluationError::UnsupportedCoefficient {
                    coefficient: "indeterminate".to_owned(),
                }),
                CoefficientView::Infinity(_) => Err(EvaluationError::UnsupportedCoefficient {
                    coefficient: "infinity".to_owned(),
                }),
                CoefficientView::FiniteField(_, _) => {
                    Err(EvaluationError::UnsupportedCoefficient {
                        coefficient: "finite field".to_owned(),
                    })
                }
                CoefficientView::RationalPolynomial(_) => {
                    Err(EvaluationError::UnsupportedCoefficient {
                        coefficient: "rational polynomial".to_owned(),
                    })
                }
            },
            AtomView::Var(v) => {
                let name = v.get_symbol();
                if let Some(expr) = fn_map.get(*self) {
                    if !expr.args.is_empty() {
                        return Err(EvaluationError::WrongNumberOfArguments {
                            function: name,
                            expected: expr.args.len(),
                            actual: 0,
                        });
                    }
                    if fn_id_map.get(&expr.id) == Some(&None) {
                        return Err(EvaluationError::EvaluatorConstructionFailed {
                            expression: self.to_owned(),
                            reason: "recursive function or alias dependency".into(),
                        });
                    }
                    let previous = fn_id_map.insert(expr.id, None);
                    let result = expr.body.as_view().to_eval_tree_impl(
                        fn_map,
                        params,
                        if expr.is_alias { args } else { &[] },
                        fn_id_map,
                        funcs,
                        external_functions,
                    );
                    if let Some(index) = previous {
                        fn_id_map.insert(expr.id, index);
                    } else {
                        fn_id_map.remove(&expr.id);
                    }
                    return result;
                }

                if name.get_evaluation_info().is_some() {
                    if external_functions
                        .iter()
                        .all(|x| x.symbol != name || !x.tags.is_empty())
                    {
                        external_functions.push(ExternalFunctionContainer::new(
                            name,
                            vec![],
                            vec![],
                        ));
                    }

                    return Ok(Expression::Fun(0, name, vec![], vec![]));
                }

                Err(EvaluationError::UndefinedVariable {
                    symbol: v.get_symbol(),
                })
            }
            AtomView::Fun(f) => {
                let name = f.get_symbol();
                if [
                    Symbol::LOG_ID,
                    Symbol::SIN_ID,
                    Symbol::COS_ID,
                    Symbol::ABS_ID,
                    Symbol::CONJ_ID,
                ]
                .contains(&name.get_id())
                {
                    assert!(f.get_nargs() == 1);
                    let arg = f.iter().next().unwrap();
                    let arg_eval = arg.to_eval_tree_impl(
                        fn_map,
                        params,
                        args,
                        fn_id_map,
                        funcs,
                        external_functions,
                    )?;

                    return Ok(Expression::BuiltinFun(
                        0,
                        f.get_symbol(),
                        Box::new(arg_eval),
                    ));
                }

                if name == Symbol::IF {
                    if f.get_nargs() != 3 {
                        return Err(EvaluationError::WrongNumberOfArguments {
                            function: name,
                            expected: 3,
                            actual: f.get_nargs(),
                        });
                    }

                    let mut arg_iter = f.iter();
                    let cond_eval = arg_iter.next().unwrap().to_eval_tree_impl(
                        fn_map,
                        params,
                        args,
                        fn_id_map,
                        funcs,
                        external_functions,
                    )?;

                    if let Expression::Const(0, c) = &cond_eval {
                        if !c.is_zero() {
                            return arg_iter.next().unwrap().to_eval_tree_impl(
                                fn_map,
                                params,
                                args,
                                fn_id_map,
                                funcs,
                                external_functions,
                            );
                        }

                        let _ = arg_iter.next().unwrap();
                        return arg_iter.next().unwrap().to_eval_tree_impl(
                            fn_map,
                            params,
                            args,
                            fn_id_map,
                            funcs,
                            external_functions,
                        );
                    }

                    let t_eval = arg_iter.next().unwrap().to_eval_tree_impl(
                        fn_map,
                        params,
                        args,
                        fn_id_map,
                        funcs,
                        external_functions,
                    )?;
                    let f_eval = arg_iter.next().unwrap().to_eval_tree_impl(
                        fn_map,
                        params,
                        args,
                        fn_id_map,
                        funcs,
                        external_functions,
                    )?;

                    return Ok(Expression::IfElse(0, Box::new((cond_eval, t_eval, f_eval))));
                }

                if let Some(Expr {
                    id,
                    tag_len,
                    is_alias,
                    args: arg_spec,
                    body: e,
                    ..
                }) = fn_map.get(*self)
                {
                    return {
                        if f.get_nargs() != arg_spec.len() + tag_len {
                            return Err(EvaluationError::WrongNumberOfArguments {
                                function: f.get_symbol(),
                                expected: arg_spec.len() + tag_len,
                                actual: f.get_nargs(),
                            });
                        }

                        // Pending entries detect cycles before expanding aliases or bodies.
                        if fn_id_map.get(id) == Some(&None) {
                            return Err(EvaluationError::EvaluatorConstructionFailed {
                                expression: self.to_owned(),
                                reason: "recursive function or alias dependency".into(),
                            });
                        }
                        if *is_alias {
                            fn_id_map.insert(*id, None);
                            let result = e.as_view().to_eval_tree_impl(
                                fn_map,
                                params,
                                args,
                                fn_id_map,
                                funcs,
                                external_functions,
                            );
                            fn_id_map.remove(id);
                            return result;
                        }

                        let eval_args = f
                            .iter()
                            .skip(*tag_len)
                            .map(|arg| {
                                arg.to_eval_tree_impl(
                                    fn_map,
                                    params,
                                    args,
                                    fn_id_map,
                                    funcs,
                                    external_functions,
                                )
                            })
                            .collect::<Result<_, _>>()?;

                        if let Some(Some(pos)) = fn_id_map.get(id) {
                            Ok(Expression::Eval(0, *pos as u32, eval_args))
                        } else {
                            fn_id_map.insert(*id, None);
                            let r = e.as_view().to_eval_tree_impl(
                                fn_map,
                                params,
                                arg_spec,
                                fn_id_map,
                                funcs,
                                external_functions,
                            )?;
                            funcs.push((
                                name.get_name().to_owned(),
                                arg_spec.clone(),
                                SplitExpression {
                                    tree: vec![r.clone()],
                                    subexpressions: vec![],
                                },
                            ));
                            fn_id_map.insert(*id, Some(funcs.len() - 1));
                            Ok(Expression::Eval(0, funcs.len() as u32 - 1, eval_args))
                        }
                    };
                }

                if let Some(eval_info) = name.get_evaluation_info() {
                    let tags = f
                        .iter()
                        .take(eval_info.get_tag_count())
                        .map(|x| x.to_canonical_string())
                        .collect::<Vec<_>>();
                    let tag_atoms = tags.iter().map(|x| crate::parse!(x)).collect::<Vec<_>>();

                    if external_functions
                        .iter()
                        .all(|x| x.symbol != name || x.tags != tag_atoms)
                    {
                        external_functions.push(ExternalFunctionContainer::new(
                            name,
                            tag_atoms,
                            vec![],
                        ));
                    }

                    let eval_args = f
                        .iter()
                        .skip(eval_info.get_tag_count())
                        .map(|arg| {
                            arg.to_eval_tree_impl(
                                fn_map,
                                params,
                                args,
                                fn_id_map,
                                funcs,
                                external_functions,
                            )
                        })
                        .collect::<Result<_, _>>()?;
                    return Ok(Expression::Fun(0, name, tags, eval_args));
                }

                Err(EvaluationError::UndefinedFunction {
                    expression: self.to_owned(),
                })
            }
            AtomView::Pow(p) => {
                let (b, e) = p.get_base_exp();

                if b == InlineVar::new(Symbol::E).as_view() {
                    let e_eval = e.to_eval_tree_impl(
                        fn_map,
                        params,
                        args,
                        fn_id_map,
                        funcs,
                        external_functions,
                    )?;
                    return Ok(Expression::BuiltinFun(0, Symbol::EXP, Box::new(e_eval)));
                }

                let b_eval = b.to_eval_tree_impl(
                    fn_map,
                    params,
                    args,
                    fn_id_map,
                    funcs,
                    external_functions,
                )?;

                if let AtomView::Num(n) = e
                    && let CoefficientView::Natural(num, den, num_i, _den_i) = n.get_coeff_view()
                    && den == 1
                    && num_i == 0
                {
                    return Ok(Expression::Pow(0, Box::new((b_eval.clone(), num))));
                }

                let e_eval = e.to_eval_tree_impl(
                    fn_map,
                    params,
                    args,
                    fn_id_map,
                    funcs,
                    external_functions,
                )?;
                Ok(Expression::Powf(0, Box::new((b_eval, e_eval))))
            }
            AtomView::Mul(m) => {
                let mut muls = vec![];
                for arg in m.iter() {
                    let a = arg.to_eval_tree_impl(
                        fn_map,
                        params,
                        args,
                        fn_id_map,
                        funcs,
                        external_functions,
                    )?;
                    if let Expression::Mul(0, m) = a {
                        muls.extend(m);
                    } else {
                        muls.push(a);
                    }
                }

                muls.sort();

                Ok(Expression::Mul(0, muls))
            }
            AtomView::Add(a) => {
                let mut adds = vec![];
                for arg in a.iter() {
                    adds.push(arg.to_eval_tree_impl(
                        fn_map,
                        params,
                        args,
                        fn_id_map,
                        funcs,
                        external_functions,
                    )?);
                }

                adds.sort();

                Ok(Expression::Add(0, adds))
            }
        }
    }

    pub(crate) fn evaluate<A: AtomCore + KeyLookup, T: Real + EvaluationDomain>(
        &self,
        map: &StdHashMap<A, T, impl BuildHasher>,
        binary_prec: u32,
    ) -> Result<T, EvaluationError> {
        let mut cache = HashMap::default();
        self.evaluate_impl(map, &mut cache, binary_prec)
    }

    fn evaluate_impl<A: AtomCore + KeyLookup, T: Real + EvaluationDomain>(
        &self,
        map: &StdHashMap<A, T, impl BuildHasher>,
        cache: &mut HashMap<AtomView<'a>, T>,
        binary_prec: u32,
    ) -> Result<T, EvaluationError> {
        match self {
            AtomView::Num(n) => {
                let f = n
                    .get_coeff_view()
                    .to_float(binary_prec)
                    .map_err(|e| EvaluationError::UnsupportedCoefficient { coefficient: e })?;
                T::try_from_complex_float(f).map_err(|e| EvaluationError::EvaluationFailed {
                    expression: self.to_owned(),
                    reason: e,
                })
            }
            AtomView::Var(v) => {
                let s = v.get_symbol();

                if let Some(val) = map.get::<[u8]>(self.get_data()) {
                    return Ok(val.clone());
                }

                if let Some(val) = cache.get(self) {
                    return Ok(val.clone());
                }

                if let Some(eval) = s.get_evaluation_info() {
                    if let Ok(val) = T::try_from_complex_float(
                        eval.evaluate_constant(&[], binary_prec).map_err(|e| {
                            EvaluationError::UnsupportedCoefficient { coefficient: e }
                        })?,
                    ) {
                        cache.insert(*self, val.clone());
                        return Ok(val);
                    } else {
                        return Err(EvaluationError::MissingEvaluator {
                            expression: self.to_owned(),
                            eval_type: std::any::type_name::<T>().to_string(),
                        });
                    }
                }

                Err(EvaluationError::UndefinedVariable { symbol: s })
            }
            AtomView::Fun(f) => {
                let name = f.get_symbol();
                if [
                    Symbol::LOG_ID,
                    Symbol::SIN_ID,
                    Symbol::COS_ID,
                    Symbol::ABS_ID,
                    Symbol::CONJ_ID,
                ]
                .contains(&name.get_id())
                {
                    if f.get_nargs() != 1 {
                        return Err(EvaluationError::WrongNumberOfArguments {
                            function: name,
                            expected: 1,
                            actual: f.get_nargs(),
                        });
                    }

                    let arg = f.iter().next().unwrap();
                    let arg_eval = arg.evaluate_impl(map, cache, binary_prec)?;

                    return Ok(match f.get_symbol_id() {
                        Symbol::LOG_ID => arg_eval.log(),
                        Symbol::SIN_ID => arg_eval.sin(),
                        Symbol::COS_ID => arg_eval.cos(),
                        Symbol::ABS_ID => arg_eval.norm(),
                        Symbol::CONJ_ID => arg_eval.conj(),
                        _ => unreachable!(),
                    });
                }

                if name == Symbol::IF {
                    if f.get_nargs() != 3 {
                        return Err(EvaluationError::WrongNumberOfArguments {
                            function: name,
                            expected: 3,
                            actual: f.get_nargs(),
                        });
                    }

                    let mut arg_iter = f.iter();

                    let cond_eval =
                        arg_iter
                            .next()
                            .unwrap()
                            .evaluate_impl(map, cache, binary_prec)?;

                    if !cond_eval.is_fully_zero() {
                        let t_eval =
                            arg_iter
                                .next()
                                .unwrap()
                                .evaluate_impl(map, cache, binary_prec)?;
                        return Ok(t_eval);
                    } else {
                        let _ = arg_iter.next().unwrap();
                        let f_eval =
                            arg_iter
                                .next()
                                .unwrap()
                                .evaluate_impl(map, cache, binary_prec)?;
                        return Ok(f_eval);
                    }
                }

                if let Some(val) = map.get::<[u8]>(self.get_data()) {
                    return Ok(val.clone());
                }

                if let Some(eval) = cache.get(self) {
                    return Ok(eval.clone());
                }

                if let Some(eval) = name.get_evaluation_info() {
                    let tag_count = eval.get_tag_count();
                    let mut iter = f.iter();
                    let mut tags = Vec::with_capacity(tag_count);

                    for i in 0..tag_count {
                        if let Some(tag) = iter.next() {
                            tags.push(tag);
                        } else {
                            return Err(EvaluationError::WrongNumberOfArguments {
                                function: name,
                                expected: tag_count,
                                actual: i,
                            });
                        }
                    }

                    let mut args = Vec::with_capacity(f.get_nargs());
                    for arg in iter {
                        args.push(arg.evaluate_impl(map, cache, binary_prec)?);
                    }

                    if args.is_empty() && eval.has_constant_evaluator() {
                        let val = T::try_from_complex_float(
                            eval.evaluate_constant(&tags, binary_prec).map_err(|e| {
                                EvaluationError::EvaluationFailed {
                                    expression: self.to_owned(),
                                    reason: e,
                                }
                            })?,
                        )
                        .map_err(|_| {
                            EvaluationError::MissingEvaluator {
                                expression: self.to_owned(),
                                eval_type: std::any::type_name::<T>().to_string(),
                            }
                        })?;
                        cache.insert(*self, val.clone());
                        return Ok(val);
                    }

                    if let Some(eval_fun) = T::resolve_function(&tags, eval) {
                        let val = (eval_fun)(&args);
                        cache.insert(*self, val.clone());
                        return Ok(val);
                    } else {
                        return Err(EvaluationError::MissingEvaluator {
                            expression: self.to_owned(),
                            eval_type: std::any::type_name::<T>().to_string(),
                        });
                    }
                }

                Err(EvaluationError::UndefinedFunction {
                    expression: self.to_owned(),
                })
            }
            AtomView::Pow(p) => {
                let (b, e) = p.get_base_exp();

                if b == InlineVar::new(Symbol::E).as_view() {
                    let e_eval = e.evaluate_impl(map, cache, binary_prec)?;
                    return Ok(e_eval.exp());
                }

                let b_eval = b.evaluate_impl(map, cache, binary_prec)?;

                if let AtomView::Num(n) = e
                    && let CoefficientView::Natural(num, den, ni, _di) = n.get_coeff_view()
                    && ni == 0
                {
                    if den == 1 {
                        if num == -1 {
                            return Ok(b_eval.inv());
                        } else if num >= 0 {
                            return Ok(b_eval.pow(num as u64));
                        } else {
                            return Ok(b_eval.pow(num.unsigned_abs()).inv());
                        }
                    } else if den == 2 {
                        if num == -1 {
                            return Ok(b_eval.sqrt().inv());
                        } else if num >= 0 {
                            return Ok(b_eval.sqrt().pow(num as u64));
                        } else {
                            return Ok(b_eval.sqrt().pow(num.unsigned_abs()).inv());
                        }
                    }
                }

                let e_eval = e.evaluate_impl(map, cache, binary_prec)?;
                Ok(b_eval.powf(&e_eval))
            }
            AtomView::Mul(m) => {
                let mut it = m.iter();
                let mut r = it.next().unwrap().evaluate_impl(map, cache, binary_prec)?;
                for arg in it {
                    r *= arg.evaluate_impl(map, cache, binary_prec)?;
                }
                Ok(r)
            }
            AtomView::Add(a) => {
                let mut it = a.iter();
                let mut r = it.next().unwrap().evaluate_impl(map, cache, binary_prec)?;
                for arg in it {
                    r += arg.evaluate_impl(map, cache, binary_prec)?;
                }
                Ok(r)
            }
        }
    }

    pub(crate) fn evaluate_in_ring<A: AtomCore + KeyLookup, R: ConvertToRing>(
        &self,
        map: &StdHashMap<A, R::Element, impl BuildHasher>,
        ring: &R,
    ) -> Result<R::Element, EvaluationError> {
        self.evaluate_in_ring_impl(map, &mut HashMap::new(), ring)
    }

    fn evaluate_in_ring_impl<A: AtomCore + KeyLookup, R: ConvertToRing>(
        &self,
        map: &StdHashMap<A, R::Element, impl BuildHasher>,
        cache: &mut HashMap<AtomView<'a>, R::Element>,
        ring: &R,
    ) -> Result<R::Element, EvaluationError> {
        match self {
            AtomView::Num(n) => ring
                .try_element_from_coefficient_view(n.get_coeff_view())
                .map_err(|e| EvaluationError::UnsupportedCoefficient { coefficient: e }),
            AtomView::Var(v) => {
                let s = v.get_symbol();

                if let Some(val) = map.get::<[u8]>(self.get_data()) {
                    return Ok(val.clone());
                }

                if let Some(val) = cache.get(self) {
                    return Ok(val.clone());
                }

                Err(EvaluationError::UndefinedVariable { symbol: s })
            }
            AtomView::Fun(f) => {
                let name = f.get_symbol();
                if [
                    Symbol::LOG_ID,
                    Symbol::SIN_ID,
                    Symbol::COS_ID,
                    Symbol::ABS_ID,
                    Symbol::CONJ_ID,
                ]
                .contains(&name.get_id())
                {
                    return Err(EvaluationError::UnsupportedBuiltinArity {
                        function: name,
                        expected: 1,
                        actual: f.get_nargs(),
                    });
                }

                if name == Symbol::IF {
                    if f.get_nargs() != 3 {
                        return Err(EvaluationError::WrongNumberOfArguments {
                            function: name,
                            expected: 3,
                            actual: f.get_nargs(),
                        });
                    }

                    let mut arg_iter = f.iter();

                    let cond_eval = arg_iter
                        .next()
                        .unwrap()
                        .evaluate_in_ring_impl(map, cache, ring)?;

                    if !ring.is_zero(&cond_eval) {
                        let t_eval = arg_iter
                            .next()
                            .unwrap()
                            .evaluate_in_ring_impl(map, cache, ring)?;
                        return Ok(t_eval);
                    } else {
                        let _ = arg_iter.next().unwrap();
                        let f_eval = arg_iter
                            .next()
                            .unwrap()
                            .evaluate_in_ring_impl(map, cache, ring)?;
                        return Ok(f_eval);
                    }
                }

                if let Some(val) = map.get::<[u8]>(self.get_data()) {
                    return Ok(val.clone());
                }

                if let Some(eval) = cache.get(self) {
                    return Ok(eval.clone());
                }

                Err(EvaluationError::UndefinedFunction {
                    expression: self.to_owned(),
                })
            }
            AtomView::Pow(p) => {
                let (b, e) = p.get_base_exp();
                let mut b_eval = b.evaluate_in_ring_impl(map, cache, ring)?;

                if let AtomView::Num(n) = e
                    && let CoefficientView::Natural(num, den, ni, _di) = n.get_coeff_view()
                    && den == 1
                    && ni == 0
                {
                    if num < 0 {
                        b_eval = ring.try_inv(&b_eval).ok_or_else(|| {
                            EvaluationError::EvaluationFailed {
                                expression: self.to_owned(),
                                reason: format!("Could not invert {}", ring.printer(&b_eval)),
                            }
                        })?;
                    }

                    let num = num.unsigned_abs();

                    if num != 1 {
                        Ok(ring.pow(&b_eval, num as u64))
                    } else {
                        Ok(b_eval)
                    }
                } else {
                    Err(EvaluationError::EvaluationFailed {
                        expression: self.to_owned(),
                        reason: format!("Cannot evaluate {}", self),
                    })
                }
            }
            AtomView::Mul(m) => {
                let mut it = m.iter();
                let mut r = it.next().unwrap().evaluate_in_ring_impl(map, cache, ring)?;
                for arg in it {
                    ring.mul_assign(&mut r, arg.evaluate_in_ring_impl(map, cache, ring)?);
                }
                Ok(r)
            }
            AtomView::Add(a) => {
                let mut it = a.iter();
                let mut r = it.next().unwrap().evaluate_in_ring_impl(map, cache, ring)?;
                for arg in it {
                    ring.add_assign(&mut r, arg.evaluate_in_ring_impl(map, cache, ring)?);
                }
                Ok(r)
            }
        }
    }
}

#[cfg(test)]
mod scoped_cache_tests {
    use super::*;

    #[test]
    fn journal_restores_nested_overwrites_and_removed_temporaries() {
        let parent = crate::parse!("scoped_cache::parent");
        let child = crate::parse!("scoped_cache::child");
        let temporary = crate::parse!("scoped_cache::temporary");
        let mut cache = ScopedSubexpressions::default();
        cache.insert(parent.as_view(), Slot::Param(0));
        let outer = cache.checkpoint();
        cache.insert(parent.as_view(), Slot::Temp(1));
        cache.insert(child.as_view(), Slot::Temp(2));
        let inner = cache.checkpoint();
        cache.insert(child.as_view(), Slot::Temp(3));
        cache.insert(temporary.as_view(), Slot::Temp(4));
        cache.retain(|_, slot| *slot != Slot::Temp(4));
        cache.restore(inner);
        assert_eq!(cache.get(&parent.as_view()), Some(&Slot::Temp(1)));
        assert_eq!(cache.get(&child.as_view()), Some(&Slot::Temp(2)));
        assert_eq!(cache.get(&temporary.as_view()), None);
        cache.restore(outer);
        assert_eq!(cache.get(&parent.as_view()), Some(&Slot::Param(0)));
        assert_eq!(cache.get(&child.as_view()), None);
        assert!(cache.changes.is_empty());
        assert_eq!(cache.depth, 0);
    }

    #[test]
    fn journal_keeps_parent_aliases_and_lazy_sibling_results_separate() {
        let expressions = [
            crate::parse!("scoped_cache::base"),
            crate::parse!("if(a,if(b,1/x,y+2),if(b,y+3,1/(x+1)))+scoped_cache::base"),
            crate::parse!("if(a,1/(x+1),y+3)+scoped_cache::base"),
            crate::parse!("if(0,1/x,y)+if(1,y+2,1/(x+1))"),
            crate::parse!(
                "if(a,if(scoped_cache::one^2-scoped_cache::one,1/x,y+2),if(scoped_cache::one^2-scoped_cache::one,1/(x+1),y+3))"
            ),
        ];
        let parameters = [
            crate::parse!("a"),
            crate::parse!("b"),
            crate::parse!("x"),
            crate::parse!("y"),
        ];
        let exact = Atom::evaluator_multiple(&expressions, &parameters)
            .add_aliases([
                (crate::parse!("scoped_cache::base"), crate::parse!("y^2+1")),
                (crate::parse!("scoped_cache::one"), Atom::num(1)),
            ])
            .unwrap()
            .direct_translation(true)
            .horner_iterations(0)
            .build()
            .unwrap();
        let mut scalar = exact.map_coeff(&|value| value.re.to_f64());
        let mut batch = scalar.clone().into_batch_evaluator();
        let mut input = Vec::new();
        let mut expected = Vec::new();
        for [a, b, x, y] in [
            [1., 0., 0., 2.],
            [0., 1., -1., 3.],
            [1., 1., 1., 4.],
            [0., 0., 0., -1.],
        ] {
            let base = y * y + 1.;
            let first = if a != 0. {
                if b != 0. { 1. / x } else { y + 2. }
            } else if b != 0. {
                y + 3.
            } else {
                1. / (x + 1.)
            };
            let second = if a != 0. { 1. / (x + 1.) } else { y + 3. };
            let reference = [
                base,
                first + base,
                second + base,
                2. * y + 2.,
                if a != 0. { y + 2. } else { y + 3. },
            ];
            let row = [a, b, x, y];
            let mut actual = [f64::NAN; 5];
            scalar.evaluate(&row, &mut actual);
            assert_eq!(actual, reference);
            input.extend(row);
            expected.extend(reference);
        }
        for rows in [4, 0, 1, 3, 4] {
            let mut output = vec![f64::NAN; rows * 5];
            batch
                .evaluate_batch(&input[..rows * 4], &mut output, rows)
                .unwrap();
            assert_eq!(output, &expected[..rows * 5]);
        }
    }
}

#[cfg(test)]
mod external_cache_tests {
    use crate::{
        atom::{Atom, AtomCore, EvaluationInfo, Symbol},
        domains::float::{Complex, Real},
        evaluate::OptimizationSettings,
        function, symbol,
    };
    use std::sync::{
        Arc,
        atomic::{AtomicUsize, Ordering},
    };

    fn settings() -> OptimizationSettings {
        OptimizationSettings::new()
            .direct_translation(true)
            .horner_iterations(0)
            .cpe_iterations(Some(0))
    }

    fn counted<T: Real>(calls: Arc<AtomicUsize>) -> impl Fn(&[T]) -> T + Clone {
        move |arguments: &[T]| {
            calls.fetch_add(1, Ordering::SeqCst);
            arguments[0].clone() * &arguments[0]
        }
    }

    fn square(name: &str) -> (Symbol, Arc<AtomicUsize>) {
        let calls = Arc::new(AtomicUsize::new(0));
        let f = symbol!(
            name,
            eval = EvaluationInfo::new()
                .register(counted::<f64>(calls.clone()))
                .register(counted::<Complex<f64>>(calls.clone()))
        );
        (f, calls)
    }

    #[test]
    fn direct_external_calls_share_across_vector_outputs_without_optimizer() {
        let (f, calls) = square("direct_external_cache::vector_f");
        let x = Atom::var(symbol!("direct_external_cache::vector_x"));
        let value = function!(f, &x);
        let exact = Atom::evaluator_multiple(
            &[value.clone(), &value + 1, 3 * &value],
            std::slice::from_ref(&x),
        )
        .optimization_settings(settings())
        .build()
        .unwrap();
        let mut real = exact.clone().map_coeff(&|c| c.re.to_f64());
        let mut output = [0.; 3];
        real.evaluate(&[2.], &mut output);
        assert_eq!(output, [4., 5., 12.]);
        assert_eq!(calls.swap(0, Ordering::SeqCst), 1);
        real.evaluate(&[3.], &mut output);
        assert_eq!(output, [9., 10., 27.]);
        assert_eq!(calls.swap(0, Ordering::SeqCst), 1);
        let mut complex = exact.map_coeff(&|c| Complex::new(c.re.to_f64(), c.im.to_f64()));
        let mut output = [Complex::new(0., 0.); 3];
        complex.evaluate(&[Complex::new(2., 1.)], &mut output);
        assert_eq!(output[0], Complex::new(3., 4.));
        assert_eq!(output[1], Complex::new(4., 4.));
        assert_eq!(output[2], Complex::new(9., 12.));
        assert_eq!(calls.load(Ordering::SeqCst), 1);
    }
}

#[cfg(test)]
mod path_condition_tests {
    use super::*;

    fn build(expression: &str, parameters: &[Atom]) -> ExpressionEvaluator<Complex<Rational>> {
        crate::parse!(expression)
            .evaluator(parameters)
            .direct_translation(true)
            .horner_iterations(0)
            .build()
            .unwrap()
    }

    fn branches(exact: &ExpressionEvaluator<Complex<Rational>>) -> usize {
        exact.export_instructions().instructions.iter()
            .filter(|instruction| matches!(instruction, Instruction::IfElse(..))).count()
    }

    #[test]
    fn path_condition_journal_restores_nested_facts() {
        let mut cache = ScopedSubexpressions::default();
        let condition = Slot::Param(0);
        let outer = cache.checkpoint();
        cache.assume_condition(condition, true);
        let inner = cache.checkpoint();
        cache.assume_condition(condition, false);
        cache.assume_condition(Slot::Temp(10), true);
        cache.restore(inner);
        assert_eq!(cache.condition(condition), Some(true));
        assert_eq!(cache.condition(Slot::Temp(10)), None);
        cache.restore(outer);
        assert_eq!(cache.condition(condition), None);
        assert!(cache.condition_changes.is_empty());
        assert_eq!(cache.depth, 0);
    }

    #[test]
    fn repeated_condition_alias_diamond_has_linear_instruction_growth() {
        // Alias DAG, not an expanded expression tree. Both arms recursively
        // refer to the same predecessor and to the same parameter-only test.
        let condition = crate::parse!("path_condition::det");
        let parameters = [crate::parse!("c"), crate::parse!("q"), crate::parse!("x")];
        let mut aliases = vec![(condition.clone(), crate::parse!("c^2+q"))];
        let mut previous = parameters[2].clone();
        let depth = 12;
        for i in 1..=depth {
            let alias = Atom::var(crate::symbol!(format!("path_condition::node_{i}")));
            let body = crate::function!(Symbol::IF, &condition,
                &previous + Atom::num(i), 2 * &previous - Atom::num(i));
            aliases.push((alias.clone(), body));
            previous = alias;
        }
        let exact = previous.evaluator(&parameters).add_aliases(aliases).unwrap()
            .direct_translation(true).horner_iterations(0).build().unwrap();
        assert_eq!(branches(&exact), 1);
        assert!(exact.export_instructions().instructions.len() < 16 * depth as usize + 32);
        let ring = crate::domains::atom::AtomField::new();
        let mut exact = exact.map_to_ring(&ring).unwrap();
        // Pure imaginary c also exercises complex nonzero semantics; c=i,q=1
        // gives exactly zero, whereas c=i,q=0 gives nonzero.
        for (c, q, x) in [
            (Complex::new(0, 0), 0, 3),
            (Complex::new(1, 0), 0, -2),
            (Complex::new(0, 1), 1, 2),
            (Complex::new(0, 1), 0, -3),
        ] {
            let c = Complex::new(Rational::from(c.re), Rational::from(c.im));
            let q = Complex::new(Rational::from(q), Rational::zero());
            let x = Complex::new(Rational::from(x), Rational::zero());
            let active = !(&c * &c + &q).is_zero();
            let mut expected = x.clone();
            for i in 1..=depth {
                let offset = Complex::new(Rational::from(i), Rational::zero());
                expected = if active { expected + offset } else { &expected + &expected - offset };
            }
            let inputs = [Atom::num(c), Atom::num(q), Atom::num(x)];
            assert_eq!(exact.evaluate_single_in_ring(&inputs, &ring), Atom::num(expected));
        }
    }

    #[test]
    fn same_condition_prunes_only_unreachable_poles_and_not_other_roots() {
        let parameters = [crate::parse!("c"), crate::parse!("x"), crate::parse!("y"), crate::parse!("z")];
        let expressions = [
            crate::parse!("if(c,if(c,x,1/z),if(c,1/z,y))"),
            crate::parse!("if(c,y,x)"),
        ];
        let exact = Atom::evaluator_multiple(&expressions, &parameters)
            .direct_translation(true).horner_iterations(0).build().unwrap();
        // An outer fact cannot escape into the next output root.
        assert_eq!(branches(&exact), 2);
        assert!(!exact.export_instructions().instructions.iter()
            .any(|instruction| matches!(instruction, Instruction::Pow(_, _, -1, _))));
        let mut scalar = exact.map_coeff(&|value| value.re.to_f64());
        let mut batch = scalar.clone().into_batch_evaluator();
        let inputs = [1., 2., 3., 0., 0., 5., 7., 0., -1., 11., 13., 0., 0., 17., 19., 0., 1., 23., 29., 0.];
        let expected = [2., 3., 7., 5., 11., 13., 19., 17., 23., 29.];
        for (row, expected) in inputs.chunks_exact(4).zip(expected.chunks_exact(2)) {
            let mut actual = [0.; 2];
            scalar.evaluate(row, &mut actual);
            assert_eq!(actual, expected);
        }
        for rows in [5, 0, 1, 3, 5] {
            let mut actual = vec![f64::NAN; rows * 2];
            batch.evaluate_batch(&inputs[..rows * 4], &mut actual, rows).unwrap();
            assert_eq!(actual, expected[..rows * 2]);
        }
    }

    #[test]
    fn different_conditions_and_sibling_facts_remain_independent() {
        let params = [crate::parse!("c"), crate::parse!("d"), crate::parse!("x"), crate::parse!("y")];
        let exact = build("if(c,if(d,x,y),if(d,y,x))+if(d,3,4)", &params);
        assert_eq!(branches(&exact), 4);
        let mut actual = exact.map_coeff(&|value| value.re.to_f64());
        for (c, d, expected) in [(0., 0., 6.), (0., 1., 8.), (1., 0., 9.), (1., 1., 5.)] {
            assert_eq!(actual.evaluate_single(&[c, d, 2., 5.]), expected);
        }
    }

    #[test]
    fn inline_and_retained_functions_do_not_inherit_caller_truth_by_name() {
        let parameters = [crate::parse!("c"), crate::parse!("d"), crate::parse!("x"), crate::parse!("y")];
        for policy in [InliningPolicy::Always, InliningPolicy::Never] {
            let exact = crate::parse!("if(c,path_condition_scope::f(d),path_condition_scope::f(c))")
                .evaluator(&parameters)
                .add_function_with_options(crate::symbol!("path_condition_scope::f"),
                    vec![crate::symbol!("c")], crate::parse!("if(c,x,y)"),
                    FunctionRegistrationOptions::new().inlining(policy))
                .unwrap().direct_translation(true).horner_iterations(0).build().unwrap();
            assert_eq!(exact.export_instructions().sub_evaluators.len(),
                usize::from(policy == InliningPolicy::Never));
            let mut actual = exact.map_coeff(&|value| value.re.to_f64());
            for (c, d, expected) in [(1., 0., 5.), (1., 1., 2.), (0., 1., 5.), (0., 0., 5.)] {
                assert_eq!(actual.evaluate_single(&[c, d, 2., 5.]), expected);
            }
        }
    }

    #[test]
    fn repeated_conditions_preserve_higher_mixed_duals_and_batch_laziness() {
        let parameters = [crate::parse!("c"), crate::parse!("x"), crate::parse!("y"), crate::parse!("z")];
        let exact = build("if(c,if(c,x^2+x*y,1/z),if(c,1/z,x*y))", &parameters);
        assert_eq!(branches(&exact), 1);
        let shape = crate::domains::dual::HyperDual::<Complex<Rational>>::new(vec![
            vec![0, 0], vec![1, 0], vec![0, 1], vec![2, 0], vec![1, 1],
        ]);
        let mut scalar = exact.vectorize(&Dualizer::new(shape, vec![])).unwrap()
            .map_coeff(&|value| value.re.to_f64());
        let mut batch = scalar.clone().into_batch_evaluator();
        let mut inputs = Vec::new();
        let mut expected = Vec::new();
        for (c, x, y) in [(0., 2., 3.), (1., -2., 5.), (-1., 3., -1.)] {
            // Deliberately nonzero condition derivatives: analytic branches are
            // selected from the primal, and their derivatives remain separate.
            let row = [c, 7., 11., 13., 17., x, 1., 0., 0., 0., y, 0., 1., 0., 0., 0., 0., 0., 0., 0.];
            let reference = if c != 0. { [x*x+x*y, 2.*x+y, x, 1., 1.] } else { [x*y, y, x, 0., 1.] };
            let mut output = [0.; 5];
            scalar.evaluate(&row, &mut output);
            assert_eq!(output, reference);
            inputs.extend(row);
            expected.extend(reference);
        }
        for rows in [3, 0, 1, 3] {
            let mut actual = vec![f64::NAN; rows * 5];
            batch.evaluate_batch(&inputs[..rows * 20], &mut actual, rows).unwrap();
            assert_eq!(actual, expected[..rows * 5]);
        }
    }

    #[test]
    fn pure_imaginary_truth_keeps_the_original_numeric_condition_value() {
        let parameters = [crate::parse!("c"), crate::parse!("x"), crate::parse!("y"), crate::parse!("z")];
        let exact = build("if(c,if(c,c*x,1/z),if(c,1/z,y))", &parameters);
        assert_eq!(branches(&exact), 1);
        let ring = crate::domains::atom::AtomField::new();
        let mut exact = exact.map_to_ring(&ring).unwrap();
        for (condition, expected) in [(Atom::num(Complex::new(Rational::zero(), Rational::one())), Atom::num(Complex::new(Rational::zero(), Rational::from(2)))),
                                      (Atom::num(0), Atom::num(7)),
                                      (Atom::num(Complex::new(Rational::zero(), -Rational::one())), Atom::num(Complex::new(Rational::zero(), Rational::from(-2))))] {
            assert_eq!(exact.evaluate_single_in_ring(&[condition, Atom::num(2), Atom::num(7), Atom::num(0)], &ring), expected);
        }
    }
}
