//! Methods related to series expansion.
//!
//! # Examples
//! ```
//! use symbolica::prelude::*;
//!
//! let x = symbol!("x");
//! let a = parse!("(1-cos(x))/sin(x)");
//!
//! let out = a.series(x, 0, 4).unwrap();
//! println!("{}", out);
//! assert_eq!(out.to_atom(), parse!("1/2*x+1/24*x^3"));
//! ```
use core::panic;
use std::{
    cmp::Ordering,
    ops::{Add, Div, Mul, Neg, Sub},
    sync::Arc,
};

use crate::{
    atom::{Atom, AtomCore, AtomView, FunctionBuilder, Symbol},
    coefficient::CoefficientView,
    domains::{
        EuclideanDomain, InternalOrdering, Ring, SelfRing,
        atom::AtomField,
        integer::Integer,
        rational::{Q, Rational},
    },
    printer::{AtomPrinter, PrintOptions, PrintState},
};

use super::PolyVariable;

/// Errors that can occur during series expansion.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum SeriesError {
    /// The requested relative truncation depth is not positive.
    NonPositiveRelativeDepth {
        /// The rejected truncation depth.
        depth: SeriesDepth,
    },
    /// An `if` expression has a condition that cannot be resolved for expansion.
    NonConstantIf {
        /// The conditional expression.
        expression: Atom,
    },
    /// A function argument has a pole without a suitable series expansion rule.
    FunctionArgumentPole {
        /// The function call requiring an expansion rule.
        expression: Atom,
    },
    /// A power has a non-real exponent that this expansion does not support.
    UnsupportedComplexExponent {
        /// The power expression.
        expression: Atom,
    },
    /// An exponent exceeds the supported size for series expansion.
    UnsupportedLargeExponent {
        /// The power expression.
        expression: Atom,
    },
    /// A power of the expansion variable does not have a rational exponent.
    NonRationalPower {
        /// The expression containing the unsupported power.
        expression: Atom,
    },
    /// Simplifying exponentials and logarithms produced an unsupported form.
    UnexpectedExpLogSimplification {
        /// The expression that could not be converted back to a series.
        expression: Atom,
    },
    /// Applying the function to a pole would produce an essential singularity.
    EssentialSingularity {
        /// The function being expanded.
        function: Symbol,
    },
    /// The logarithm requires a known nonzero leading coefficient.
    MissingLogCoefficient,
    /// A coefficient treated as constant still depends on the expansion variable.
    ConstantTermDependsOnExpansionVariable {
        /// The function being expanded.
        function: Symbol,
        /// The supposedly constant coefficient.
        constant: Atom,
        /// The expansion variable that still occurs in the coefficient.
        variable: PolyVariable,
    },
    /// The requested expansion variable is not an indeterminate.
    NonIndeterminateSeriesVariable {
        /// The rejected expansion variable.
        variable: PolyVariable,
    },
    /// Raising the series to zero would require representing one at infinite precision.
    ZeroPowerRequiresInfinitePrecision,
    /// A series inversion or division has a zero divisor.
    DivisionByZero,
}

impl std::error::Error for SeriesError {}

impl std::fmt::Display for SeriesError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SeriesError::NonPositiveRelativeDepth { depth } => {
                write!(f, "relative series depth must be positive, got {depth:?}")
            }
            SeriesError::NonConstantIf { expression } => {
                write!(
                    f,
                    "cannot series expand non-constant if function {expression}"
                )
            }
            SeriesError::FunctionArgumentPole { expression } => write!(
                f,
                "cannot series expand {expression} since an argument has poles; define a 'series' attribute on the symbol that extracts the principal part"
            ),
            SeriesError::UnsupportedComplexExponent { expression } => {
                write!(
                    f,
                    "cannot series expand {expression} with a complex exponent"
                )
            }
            SeriesError::UnsupportedLargeExponent { expression } => {
                write!(
                    f,
                    "cannot series expand {expression} with a large exponent yet"
                )
            }
            SeriesError::NonRationalPower { expression } => {
                write!(f, "power of variable in {expression} must be rational")
            }
            SeriesError::UnexpectedExpLogSimplification { expression } => write!(
                f,
                "unexpected term {expression} in exp-log series simplification"
            ),
            SeriesError::EssentialSingularity { function } => write!(
                f,
                "cannot series expand {function} of a series with poles; this would create an essential singularity"
            ),
            SeriesError::MissingLogCoefficient => {
                f.write_str("log argument needs to have a coefficient")
            }
            SeriesError::ConstantTermDependsOnExpansionVariable {
                function,
                constant,
                variable,
            } => write!(
                f,
                "cannot compute {function} of a series whose constant term {constant} depends on {variable}"
            ),
            SeriesError::NonIndeterminateSeriesVariable { variable } => {
                write!(f, "series variable {variable} is not an indeterminate")
            }
            SeriesError::ZeroPowerRequiresInfinitePrecision => f.write_str(
                "cannot raise series to the power of zero, as this generates infinite precision 1",
            ),
            SeriesError::DivisionByZero => {
                f.write_str("cannot invert series with a zero constant term")
            }
        }
    }
}

/// The requested truncation depth of a series expansion.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum SeriesDepth {
    /// Truncate at an absolute power of the expansion variable.
    Absolute(Rational),
    /// Truncate relative to the lowest order that appears in the expansion.
    Relative(Rational),
}

impl SeriesDepth {
    /// Truncate at an absolute power of the expansion variable.
    pub fn absolute<T: Into<Rational>>(depth: T) -> Self {
        Self::Absolute(depth.into())
    }

    /// Truncate relative to the lowest order that appears in the expansion.
    pub fn relative<T: Into<Rational>>(depth: T) -> Self {
        Self::Relative(depth.into())
    }

    pub(crate) fn order(&self) -> &Rational {
        match self {
            SeriesDepth::Absolute(depth) | SeriesDepth::Relative(depth) => depth,
        }
    }

    pub(crate) fn is_absolute(&self) -> bool {
        matches!(self, SeriesDepth::Absolute(_))
    }
}

impl<T: Into<Rational>> From<T> for SeriesDepth {
    fn from(depth: T) -> Self {
        Self::absolute(depth.into())
    }
}

/// A Puiseux series. The truncation order is
/// relative to the lowest degree: i.e., a series in `x` with depth `d` is viewed as
/// `a*x^n*(1+bx+.. + O(x^(d+1)))`.
///
/// # Examples
///
/// A series can be constructed from an [Atom]:
/// ```
/// use symbolica::prelude::*;
///
/// let x = symbol!("x");
/// let a = parse!("(1-cos(x))/sin(x)");
///
/// let out = a.series(x, 0, 4).unwrap();
/// println!("{}", out);
/// assert_eq!(out.to_atom(), parse!("1/2*x+1/24*x^3"));
/// ```
#[derive(Clone)]
pub struct Series<F: Ring> {
    coefficients: Vec<F::Element>,
    variable: Arc<PolyVariable>,
    expansion_point: F::Element,
    field: F,
    shift: isize, // a shift in units of the ramification that indicates the starting power of the series
    order: usize, // the order of truncation in units of the ramification
    ramification: usize, // the factor that makes the exponents integer
}

impl<F: Ring + std::fmt::Debug> std::fmt::Debug for Series<F> {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        if self.order == 0 {
            return write!(f, "[]");
        }
        let mut first = true;
        write!(f, "[ ")?;
        for c in self.coefficients.iter() {
            if first {
                first = false;
            } else {
                write!(f, ", ")?;
            }
            write!(f, "{{ {c:?} }}")?;
        }
        write!(f, " ]")
    }
}

impl<F: Ring + std::fmt::Display> std::fmt::Display for Series<F> {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        self.format(&PrintOptions::from_fmt(f), PrintState::from_fmt(f), f)
            .map(|_| ())
    }
}

impl<F: Ring> Series<F> {
    /// Constructs a zero series with fixed order. Instead of using this constructor,
    /// prefer to create new series from existing ones, so that the
    /// variable map and field are inherited.
    #[inline]
    pub fn new(
        field: &F,
        cap: Option<usize>,
        variable: Arc<PolyVariable>,
        expansion_point: F::Element,
        order: Rational,
    ) -> Self {
        if order.is_negative() {
            panic!("The order of the series must be positive.");
        }

        Self {
            coefficients: Vec::with_capacity(cap.unwrap_or(0)),
            expansion_point,
            field: field.clone(),
            variable,
            shift: 0,
            order: order.numerator().to_i64().unwrap() as usize,
            ramification: order.denominator().to_i64().unwrap() as usize,
        }
    }

    /// Constructs a finite-precision zero series, inheriting the field and variable from `self`.
    #[inline]
    pub fn zero(&self) -> Self {
        Self {
            coefficients: vec![],
            field: self.field.clone(),
            variable: self.variable.clone(),
            expansion_point: self.expansion_point.clone(),
            shift: 0,
            order: self.order,
            ramification: self.ramification,
        }
    }

    /// Constructs a finite-precision constant series,
    /// inheriting the field and variable from `self`.
    #[inline]
    pub fn constant(&self, coeff: F::Element) -> Self {
        if self.field.is_zero(&coeff) {
            return self.zero();
        }

        Self {
            coefficients: vec![coeff],
            field: self.field.clone(),
            variable: self.variable.clone(),
            expansion_point: self.expansion_point.clone(),
            shift: 0,
            order: self.order,
            ramification: self.ramification,
        }
    }

    /// Constructs a finite-precision series that is one, inheriting the field and variable from `self`.
    #[inline]
    pub fn one(&self) -> Self {
        Self {
            coefficients: vec![self.field.one()],
            field: self.field.clone(),
            variable: self.variable.clone(),
            expansion_point: self.expansion_point.clone(),
            shift: 0,
            order: self.order,
            ramification: self.ramification,
        }
    }

    /// Constructs a series that is one with infinite digits.
    /// Must be added or multiplied with another finite series.
    #[inline]
    fn one_inf_prec(&self) -> Self {
        Self {
            coefficients: vec![self.field.one()],
            field: self.field.clone(),
            variable: self.variable.clone(),
            expansion_point: self.expansion_point.clone(),
            shift: 0,
            order: i64::MAX as usize, // considered infinity
            ramification: 1,
        }
    }

    /// Constructs a series with a single term.
    #[inline]
    pub fn monomial(&self, coeff: F::Element, exponent: Rational) -> Self {
        if self.field.is_zero(&coeff) {
            return self.zero();
        }

        let n = exponent.numerator().to_i64().unwrap() as isize;
        let d = exponent.denominator().to_i64().unwrap() as usize;

        let ram = Integer::from(self.ramification as i64)
            .lcm(exponent.denominator_ref())
            .to_i64()
            .unwrap() as usize;

        Self {
            coefficients: vec![coeff],
            field: self.field.clone(),
            variable: self.variable.clone(),
            expansion_point: self.expansion_point.clone(),
            shift: n * (ram / d) as isize,
            order: self.order * (ram / self.ramification),
            ramification: ram,
        }
    }

    /// Constructs a series that is `x+a`, where `a` is a constant.
    #[inline]
    pub fn shifted_variable(&self, coeff: F::Element) -> Self {
        if self.field.is_zero(&coeff) {
            return self.monomial(self.field.one(), (1, 1).into());
        }

        self.constant(coeff) + self.monomial(self.field.one(), (1, 1).into())
    }

    /// Get the field of the series coefficients.
    #[inline]
    pub fn get_field(&self) -> &F {
        &self.field
    }

    // Map an index in the coefficient array to its power.
    #[inline]
    fn get_exponent(&self, index: usize) -> Rational {
        Self::get_exponent_from_shift_ram(index, self.shift, self.ramification)
    }

    /// Map an index in the coefficient array to its power, given a shift and ramification.
    fn get_exponent_from_shift_ram(index: usize, shift: isize, ram: usize) -> Rational {
        (Rational::from(index as i64) + Rational::from(shift as i64)) / Rational::from(ram as i64)
    }

    // Map a power to an index in the coefficient array.
    #[inline]
    fn get_index(&self, p: Rational) -> usize {
        let r = p * &Rational::from(self.ramification as i64);
        debug_assert!(r.is_integer());

        let i = r.numerator().to_i64().unwrap() - self.shift as i64;
        debug_assert!(i >= 0);
        i as usize
    }

    /// Get the relative order of the series expansion.
    #[inline]
    pub fn relative_order(&self) -> Rational {
        assert!(self.order < i64::MAX as usize);
        (self.order as i64, self.ramification as i64).into()
    }

    /// Get the absolute order of the series expansion.
    #[inline]
    pub fn absolute_order(&self) -> Rational {
        assert!(self.order < i64::MAX as usize);
        (
            self.order as i64 + self.shift as i64,
            self.ramification as i64,
        )
            .into()
    }

    /// Get the expansion point.
    #[inline]
    pub fn get_expansion_point(&self) -> F::Element {
        self.expansion_point.clone()
    }

    fn change_ramification(&mut self, ram: usize) {
        let ram = Integer::from(self.ramification as i64)
            .lcm(&Integer::from(ram as i64))
            .to_i64()
            .unwrap() as usize;

        if ram == self.ramification {
            return;
        }

        let mut s = Self {
            coefficients: vec![
                self.field.zero();
                self.coefficients.len() * ram / self.ramification
            ],
            field: self.field.clone(),
            variable: self.variable.clone(),
            expansion_point: self.expansion_point.clone(),
            shift: self.shift * (ram / self.ramification) as isize,
            order: self.order * (ram / self.ramification),
            ramification: ram,
        };

        for (i, c) in std::mem::take(&mut self.coefficients)
            .into_iter()
            .enumerate()
        {
            let index = s.get_index(self.get_exponent(i));
            s.coefficients[index] = c;
        }

        *self = s;
    }

    /// Truncate the series to the desired relative order.
    /// If the new order is larger, nothing happens.
    #[inline]
    pub fn truncate_relative_order(&mut self, order: Rational) {
        if self.relative_order() < order {
            return;
        }

        if order.is_negative() {
            panic!("Cannot series expand to negative depth");
        }

        let ram = order.denominator().to_i64().unwrap() as usize;
        self.change_ramification(ram);
        let new_order = (order.numerator().to_i64().unwrap() as usize) * self.ramification / ram;

        self.coefficients.truncate(new_order);
        self.order = new_order;
        self.truncate();
    }

    /// Truncate the series to the desired absolute order.
    /// If the new order is larger, nothing happens.
    /// An empty series retains its known order since no terms need to be removed.
    #[inline]
    pub fn truncate_absolute_order(&mut self, order: Rational) {
        if self.coefficients.is_empty() || self.absolute_order() < order {
            return;
        }

        self.change_ramification(order.denominator().to_i64().unwrap() as usize);

        for i in (0..self.coefficients.len()).rev() {
            if self.get_exponent(i) >= order {
                self.coefficients.pop();
            } else {
                break;
            }
        }

        if self.coefficients.is_empty() {
            self.order = 0;
        } else {
            self.order = self.get_index(order);
        }
    }

    #[inline]
    fn joint_ramification(&self, other: &Self) -> usize {
        Integer::from(self.ramification as i64)
            .lcm(&Integer::from(other.ramification as i64))
            .to_i64()
            .unwrap() as usize
    }

    #[inline]
    /// Return whether no nonzero terms are stored. This tests the known terms,
    /// not whether the unknown remainder is identically zero.
    pub fn is_zero(&self) -> bool {
        self.coefficients.is_empty()
    }

    #[inline]
    /// Return whether the stored terms consist only of the constant one.
    /// The unknown remainder is not tested.
    pub fn is_one(&self) -> bool {
        self.coefficients.len() == 1 && self.field.is_one(&self.coefficients[0]) && self.shift == 0
    }

    /// Returns true if the series is constant.
    #[inline]
    pub fn is_constant(&self) -> bool {
        self.coefficients.len() <= 1 && self.shift == 0
    }

    #[inline]
    /// Return the coefficient of the lowest stored power, or zero when no terms
    /// are stored.
    pub fn get_trailing_coefficient(&self) -> F::Element {
        if self.coefficients.is_empty() {
            self.field.zero()
        } else {
            self.coefficients[0].clone()
        }
    }

    #[inline]
    /// Return the lowest exponent represented by the series storage, including
    /// the shift and ramification.
    pub fn get_trailing_exponent(&self) -> Rational {
        self.get_exponent(0)
    }

    #[inline]
    /// Return the common denominator used to represent fractional exponents.
    /// Adjacent coefficient slots differ in exponent by its reciprocal.
    pub fn get_ramification(&self) -> usize {
        self.ramification
    }

    /// Get a copy of the variable/
    pub fn get_variable(&self) -> Arc<PolyVariable> {
        self.variable.clone()
    }

    /// Get a reference to the variables
    pub fn get_vars_ref(&self) -> &PolyVariable {
        self.variable.as_ref()
    }

    /// Get the leading coefficient.
    pub fn lcoeff(&self) -> F::Element {
        self.coefficients
            .last()
            .unwrap_or(&self.field.zero())
            .clone()
    }

    /// Return the highest stored exponent, or zero when the series has no
    /// known coefficients. This differs from the truncation order.
    pub fn degree(&self) -> Rational {
        if self.order == 0 {
            return 0.into();
        }

        self.get_exponent(self.coefficients.len() - 1)
    }

    /// Compute `self^pow`. `pow` must be a positive integer.
    pub fn npow(&self, mut pow: usize) -> Self {
        if pow == 0 {
            panic!("Cannot create one with infinite precision");
        }

        let mut x = self.clone();
        let mut y = self.one_inf_prec();
        while pow != 1 {
            if pow % 2 == 1 {
                y = &y * &x;
                pow -= 1;
            }

            x = &x * &x;
            pow /= 2;
        }

        x * &y
    }

    /// Multiply the exponents `exp` units of the ramification.
    pub fn mul_exp_units(mut self, exp: isize) -> Self {
        self.shift += exp;
        self
    }

    /// Multiply every stored coefficient by `coeff`, preserving the truncation
    /// information.
    pub fn mul_coeff(mut self, coeff: &F::Element) -> Self {
        for c in &mut self.coefficients {
            if !self.field.is_zero(c) {
                self.field.mul_assign(c, coeff);
            }
        }

        self.truncate(); // zeros may have occurred

        self
    }

    /// Truncate the leading and trailing non-zeroes.
    fn truncate(&mut self) {
        if self.coefficients.is_empty() {
            return;
        }

        let d = self
            .coefficients
            .iter_mut()
            .rev()
            .position(|c| !self.field.is_zero(c))
            .unwrap_or(self.coefficients.len());

        self.coefficients.truncate(self.coefficients.len() - d);

        if self.coefficients.is_empty() {
            self.shift += self.order as isize;
            self.order = 0;
            return;
        }

        let d = self
            .coefficients
            .iter_mut()
            .position(|c| !self.field.is_zero(c))
            .unwrap_or(self.coefficients.len());

        self.shift += d as isize;
        self.order -= d;
        self.coefficients.drain(0..d);
    }

    /// Remove the constant term, if it is first and it exists.
    fn remove_constant(mut self) -> Self {
        if self.order > 0 && self.shift == 0 {
            self.coefficients[0] = self.field.zero();
            self.truncate();
        }

        self
    }

    /// Get the coefficient of `(variable - expansion_point)^exponent`.
    ///
    /// Returns `None` at or above [`Self::absolute_order`], where the remainder
    /// is unknown. Below that order, absent terms (including exponents outside
    /// the ramification grid) have coefficient `Some(0)`.
    pub fn coefficient(&self, exponent: Rational) -> Option<F::Element> {
        if exponent >= self.absolute_order() {
            return None;
        }
        let r = exponent * &Rational::from(self.ramification as i64);
        if !r.is_integer() {
            return Some(self.field.zero());
        }

        let i = r - Rational::from(self.shift as i64);
        if i >= 0 && i < Rational::from(self.coefficients.len() as i64) {
            Some(self.coefficients[i.numerator().to_i64().unwrap() as usize].clone())
        } else {
            Some(self.field.zero())
        }
    }

    /// Iterate over the terms of the series, yielding the exponent and its coefficient.
    pub fn terms(&self) -> impl Iterator<Item = (Rational, &F::Element)> {
        self.coefficients
            .iter()
            .enumerate()
            .map(|(i, c)| (self.get_exponent(i), c))
    }

    /// Map the coefficients of the series using a function `f`.
    pub fn map_coeff<M: Fn(&F::Element) -> F::Element>(&self, f: M) -> Series<F> {
        let mut s = Series {
            coefficients: self.coefficients.iter().map(f).collect(),
            variable: self.variable.clone(),
            expansion_point: self.expansion_point.clone(),
            shift: self.shift,
            ramification: self.ramification,
            field: self.field.clone(),
            order: self.order,
        };

        s.truncate();
        s
    }
}

impl<'a, R: Ring> IntoIterator for Series<R> {
    type Item = (Rational, R::Element);
    type IntoIter = std::vec::IntoIter<(Rational, R::Element)>;

    /// Create an iterator over the terms of the series, yielding the exponent and its coefficient.
    fn into_iter(self) -> Self::IntoIter {
        let shift = self.shift;
        let ram = self.ramification;
        let v: Vec<_> = self
            .coefficients
            .into_iter()
            .enumerate()
            .map(|(i, c)| (Self::get_exponent_from_shift_ram(i, shift, ram), c))
            .collect();

        v.into_iter()
    }
}

impl<'a, R: Ring> IntoIterator for &'a Series<R> {
    type Item = (Rational, &'a R::Element);
    type IntoIter = std::vec::IntoIter<(Rational, &'a R::Element)>;

    /// Create an iterator over the terms of the series, yielding the exponent and its coefficient.
    fn into_iter(self) -> Self::IntoIter {
        let v: Vec<_> = self
            .coefficients
            .iter()
            .enumerate()
            .map(|(i, c)| (self.get_exponent(i), c))
            .collect();

        v.into_iter()
    }
}

impl<F: Ring> SelfRing for Series<F> {
    fn is_zero(&self) -> bool {
        self.is_zero()
    }

    fn is_one(&self) -> bool {
        self.is_one()
    }

    fn format<W: std::fmt::Write>(
        &self,
        opts: &PrintOptions,
        mut state: PrintState,
        f: &mut W,
    ) -> Result<bool, std::fmt::Error> {
        fn format_exponent<W: std::fmt::Write>(
            exponent: &Rational,
            opts: &PrintOptions,
            state: PrintState,
            f: &mut W,
        ) -> std::fmt::Result {
            let superscript =
                opts.mode.is_symbolica() && opts.num_exp_as_superscript && exponent.is_integer();
            if !superscript {
                f.write_char('^')?;
            }
            if opts.mode.is_latex() {
                f.write_char('{')?;
            }

            if superscript {
                if exponent.is_negative() {
                    f.write_char('⁻')?;
                }

                let mut exponent_state = state.step(false, false, true, false);
                exponent_state.superscript = true;
                AtomPrinter::format_digits(
                    exponent.numerator_ref().abs().to_string(),
                    opts,
                    &exponent_state,
                    f,
                )?;
            } else {
                Q.format(exponent, opts, state.step(false, false, true, false), f)?;
            }

            if opts.mode.is_latex() {
                f.write_char('}')?;
            }
            Ok(())
        }

        let v = if self.field.is_zero(&self.expansion_point) {
            self.variable.format_string(
                opts,
                PrintState {
                    in_exp_base: true,
                    ..state
                },
            )
        } else {
            let v = self.variable.format_string(
                opts,
                PrintState {
                    in_sum: true,
                    ..state
                },
            );
            format!("({}-{})", v, self.field.printer(&self.expansion_point))
        };

        if self.coefficients.is_empty() {
            let o = self.absolute_order();
            if opts.mode.is_latex() {
                write!(f, "\\mathcal{{O}}\\left({v}^{{{o}}}\\right)")?;
            } else {
                write!(f, "𝒪({v}")?;
                format_exponent(&o, opts, state, f)?;
                f.write_char(')')?;
            }
            return Ok(false);
        }

        let add_paren = state.in_product || state.in_exp || state.in_exp_base;
        if add_paren {
            if state.in_sum {
                f.write_str("+")?;
                state.in_sum = false;
            }

            state.in_product = false;
            state.in_exp = false;
            state.in_exp_base = false;
            f.write_str("(")?;
        }
        let in_product = state.in_product;

        for (e, c) in self.coefficients.iter().enumerate() {
            if self.field.is_zero(c) {
                continue;
            }

            let e = self.get_exponent(e);

            state.in_product = in_product || !e.is_zero();
            state.suppress_one = !e.is_zero();
            let suppressed_one = self.field.format(
                c,
                opts,
                state.step(state.in_sum, state.in_product, false, false),
                f,
            )?;

            if !suppressed_one && !e.is_zero() {
                f.write_char(opts.multiplication_operator)?;
            }

            if e.is_one() {
                write!(f, "{v}")?;
            } else if !e.is_zero() {
                write!(f, "{v}")?;
                state.suppress_one = false;
                format_exponent(&e, opts, state, f)?;
            }

            state.in_sum = true;
        }

        let o = self.absolute_order();

        if opts.mode.is_latex() {
            write!(f, "+\\mathcal{{O}}\\left({v}^{{{o}}}\\right)")?;
        } else {
            write!(f, "+𝒪({v}")?;
            format_exponent(&o, opts, state, f)?;
            f.write_char(')')?;
        }

        if add_paren {
            f.write_str(")")?;
        }

        Ok(false)
    }
}

impl<F: Ring> InternalOrdering for Series<F> {
    fn internal_cmp(&self, other: &Self) -> Ordering {
        if self.variable != other.variable {
            return self.variable.cmp(&other.variable);
        }

        if self.shift != other.shift {
            return self.shift.cmp(&other.shift);
        }

        if self.ramification != other.ramification {
            return self.ramification.cmp(&other.ramification);
        }

        if self.order != other.order {
            return self.order.cmp(&other.order);
        }

        self.coefficients.internal_cmp(&other.coefficients)
    }
}

impl<F: Ring> PartialEq for Series<F> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        if self.variable != other.variable {
            if self.is_constant() != other.is_constant() {
                return false;
            }

            if self.order != other.order {
                // TODO: compare the common orders?
                return false;
            }

            if self.order == 0 {
                return true;
            }

            if self.is_constant() {
                return self.coefficients[0] == other.coefficients[0];
            }

            // TODO: what is expected here?
            unimplemented!("Cannot compare non-constant series with different variable maps yet");
        }

        if self.degree() != other.degree() {
            return false;
        }
        self.coefficients.eq(&other.coefficients)
    }
}

impl<F: Ring> std::hash::Hash for Series<F> {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        self.coefficients.hash(state);
        self.variable.hash(state);
    }
}

impl<F: Ring> Eq for Series<F> {}

impl<R: Ring> PartialOrd for Series<R> {
    /// An ordering of series that has no intuitive meaning.
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.coefficients.internal_cmp(&other.coefficients))
    }
}

impl<F: Ring> Add for Series<F> {
    type Output = Self;

    fn add(mut self, mut other: Self) -> Self::Output {
        assert_eq!(self.field, other.field);
        assert_eq!(self.variable, other.variable);

        if self.shift == other.shift && self.ramification == other.ramification {
            if self.coefficients.len() < other.coefficients.len() {
                std::mem::swap(&mut self, &mut other);
            }

            self.order = self.order.min(other.order);
            self.coefficients.truncate(self.order);

            for (i, c) in other.coefficients.iter().enumerate() {
                if i < self.coefficients.len() {
                    self.field.add_assign(&mut self.coefficients[i], c);
                }
            }

            self.truncate();
            self
        } else {
            let r = self.joint_ramification(&other);
            let r_d_s = r / self.ramification;
            let r_d_o = r / other.ramification;

            let shift = (self.shift * r_d_s as isize).min(other.shift * r_d_o as isize);
            let order_s = (self.order * r_d_s) as isize + self.shift * r_d_s as isize;
            let order_o = (other.order * r_d_o) as isize + other.shift * r_d_o as isize;

            let mut s = Self {
                coefficients: vec![],
                variable: self.variable.clone(),
                expansion_point: self.expansion_point.clone(),
                field: self.field.clone(),
                shift,
                order: (order_s.min(order_o) - shift) as usize,
                ramification: r,
            };

            s.coefficients =
                vec![self.field.zero(); self.coefficients.len().max(other.coefficients.len())];
            for (i, c) in self.coefficients.iter().enumerate() {
                let index = s.get_index(self.get_exponent(i));
                if index < s.order {
                    if index >= s.coefficients.len() {
                        s.coefficients.resize(index * 2, self.field.zero());
                    }
                    s.coefficients[index] = c.clone(); // TODO: prevent copy
                }
            }
            for (i, c) in other.coefficients.iter().enumerate() {
                let index = s.get_index(other.get_exponent(i));
                if index < s.order {
                    if index >= s.coefficients.len() {
                        s.coefficients.resize(index * 2, self.field.zero());
                    }

                    s.field.add_assign(&mut s.coefficients[index], c);
                }
            }

            s.truncate();
            s
        }
    }
}

impl<'a, F: Ring> Add<&'a Series<F>> for &Series<F> {
    type Output = Series<F>;

    fn add(self, other: &'a Series<F>) -> Self::Output {
        (self.clone()).add(other.clone())
    }
}

impl<F: Ring> Sub for Series<F> {
    type Output = Self;

    fn sub(self, other: Self) -> Self::Output {
        self.add(other.neg())
    }
}

impl<'a, F: Ring> Sub<&'a Series<F>> for &Series<F> {
    type Output = Series<F>;

    fn sub(self, other: &'a Series<F>) -> Self::Output {
        (self.clone()).add(other.clone().neg())
    }
}

impl<F: Ring> Neg for Series<F> {
    type Output = Self;
    fn neg(mut self) -> Self::Output {
        // Negate coefficients of all terms.
        for c in &mut self.coefficients {
            *c = self.field.neg(&*c);
        }
        self
    }
}

impl<'a, F: Ring> Mul<&'a Series<F>> for &Series<F> {
    type Output = Series<F>;

    #[inline]
    fn mul(self, rhs: &'a Series<F>) -> Self::Output {
        assert_eq!(self.field, rhs.field);
        assert_eq!(self.variable, rhs.variable);

        let r = self.joint_ramification(rhs);
        let r_d_s = r / self.ramification;
        let r_d_o = r / rhs.ramification;
        let mut res = Series {
            coefficients: vec![],
            field: self.field.clone(),
            variable: self.variable.clone(),
            expansion_point: self.expansion_point.clone(),
            shift: self.shift * r_d_s as isize + rhs.shift * r_d_o as isize,
            // The infinite-precision identity can overflow when its grid is refined.
            order: self
                .order
                .saturating_mul(r_d_s)
                .min(rhs.order.saturating_mul(r_d_o)),
            ramification: r,
        };

        res.coefficients =
            vec![self.field.zero(); self.coefficients.len().max(rhs.coefficients.len())];

        for (e1, c1) in self.coefficients.iter().enumerate() {
            if self.field.is_zero(c1) {
                continue;
            }

            let p1 = self.get_exponent(e1);

            for (e2, c2) in rhs.coefficients.iter().enumerate() {
                let p = &p1 + &rhs.get_exponent(e2);

                if !self.field.is_zero(c2) {
                    let index = res.get_index(p);
                    if index < res.order {
                        if index >= res.coefficients.len() {
                            res.coefficients.resize(index * 2, self.field.zero());
                        }

                        self.field
                            .add_mul_assign(&mut res.coefficients[index], c1, c2);
                    }
                }
            }
        }

        res.truncate();
        res
    }
}

impl<'a, F: Ring> Mul<&'a Series<F>> for Series<F> {
    type Output = Series<F>;

    #[inline]
    fn mul(self, rhs: &'a Series<F>) -> Self::Output {
        (&self) * rhs
    }
}

impl<'a> Div<&'a Series<AtomField>> for &Series<AtomField> {
    type Output = Series<AtomField>;

    fn div(self, other: &'a Series<AtomField>) -> Self::Output {
        other.rpow((-1, 1).into()).unwrap() * self
    }
}

impl<'a> Div<&'a Series<AtomField>> for Series<AtomField> {
    type Output = Series<AtomField>;

    fn div(self, other: &'a Series<AtomField>) -> Self::Output {
        (&self).div(other)
    }
}

impl<F: EuclideanDomain> Series<F> {
    /// Get the content from the coefficients.
    pub fn content(&self) -> F::Element {
        if self.coefficients.is_empty() {
            return self.field.zero();
        }
        let mut c = self.coefficients.first().unwrap().clone();
        for cc in self.coefficients.iter().skip(1) {
            // early return if possible (not possible for rationals)
            if F::one_is_gcd_unit() && self.field.is_one(&c) {
                break;
            }

            c = self.field.gcd(&c, cc);
        }
        c
    }

    /// Divide every coefficient with `other`.
    pub fn div_coeff(mut self, other: &F::Element) -> Self {
        for c in &mut self.coefficients {
            let (quot, rem) = self.field.quot_rem(c, other);
            debug_assert!(self.field.is_zero(&rem));
            *c = quot;
        }
        self
    }

    /// Make the series primitive by removing the content.
    pub fn make_primitive(self) -> Self {
        let c = self.content();
        self.div_coeff(&c)
    }
}

impl Series<AtomField> {
    /// Remove coefficients at the lowest powers that the zero test proves zero.
    pub(crate) fn normalize_trailing_coefficient(&mut self) {
        let zeros = self
            .coefficients
            .iter()
            .take_while(|c| c.check_zero().is_true())
            .count();
        if zeros == 0 {
            return;
        }

        if zeros == self.coefficients.len() {
            self.coefficients.clear();
            self.shift += self.order as isize;
            self.order = 0;
        } else {
            self.coefficients.drain(..zeros);
            self.shift += zeros as isize;
            self.order -= zeros;
        }
    }

    /// Extract powers of `x` from an expression that comes from simplifying an exponential with logs
    /// i.e.: `exp(c + 3 log(x^5)) = exp(c)*x^15`.
    fn extract_exp_log(&self, e: AtomView, s: AtomView) -> Result<Self, SeriesError> {
        if !e.contains(s) {
            return Ok(self.constant(e.to_owned()));
        }

        match e {
            AtomView::Pow(p) => {
                let (b, exp) = p.get_base_exp();

                if b == s {
                    if let AtomView::Num(n) = exp {
                        if let CoefficientView::Natural(n, d, ni, _di) = n.get_coeff_view() {
                            if ni == 0 {
                                Ok(self.monomial(self.field.one(), (n, d).into()))
                            } else {
                                Err(SeriesError::UnsupportedComplexExponent {
                                    expression: e.to_owned(),
                                })
                            }
                        } else {
                            Err(SeriesError::UnsupportedLargeExponent {
                                expression: e.to_owned(),
                            })
                        }
                    } else {
                        Err(SeriesError::NonRationalPower {
                            expression: e.to_owned(),
                        })
                    }
                } else {
                    Err(SeriesError::UnexpectedExpLogSimplification {
                        expression: e.to_owned(),
                    })
                }
            }
            AtomView::Var(_) => Ok(self.monomial(self.field.one(), (1, 1).into())),
            AtomView::Mul(m) => {
                let mut shift_series = self.one_inf_prec();
                for a in m {
                    shift_series = &shift_series * &self.extract_exp_log(a, s)?;
                }

                Ok(shift_series)
            }
            _ => Err(SeriesError::UnexpectedExpLogSimplification {
                expression: e.to_owned(),
            }),
        }
    }

    /// Expand the exponential of this series to the available order.
    /// Returns an error for a pole that would produce an essential singularity
    /// or an unsupported exponential-logarithmic constant term.
    pub fn exp(&self) -> Result<Self, SeriesError> {
        if self.shift < 0 {
            return Err(SeriesError::EssentialSingularity {
                function: Symbol::EXP,
            });
        }

        if self.order == 0 {
            return Ok(self.one_inf_prec()
                + Series::new(
                    &self.field,
                    Some(1),
                    self.variable.clone(),
                    self.expansion_point.clone(),
                    (self.shift as i64, 1).into(),
                ));
        }

        let c = if self.shift == 0 && self.order > 0 {
            self.coefficients[0].clone()
        } else {
            Atom::new()
        };

        // construct the constant term, log(x) in the argument will be turned into x
        let e = FunctionBuilder::new(Symbol::EXP).add_arg(&c).finish();

        // split the true constant part and the x-dependent part
        let var = self.variable.to_atom() - &self.expansion_point;
        let shift_series = self.extract_exp_log(e.as_view(), var.as_view())?; // FIXME: needs to be inf prec!

        let p = self.clone().remove_constant();

        let mut r = self.one_inf_prec();
        let mut sp = p.clone();
        for i in 1..=self.order {
            let s = sp
                .clone()
                .div_coeff(&Atom::num(Integer::factorial(i as u32)));

            sp = sp * &p;

            r = r + s;
        }

        Ok(r * &shift_series)
    }

    /// Expand the logarithm using the leading monomial and the remaining
    /// positive-order terms. Returns an error if no leading coefficient is known.
    pub fn log(&self) -> Result<Self, SeriesError> {
        if self.order == 0 {
            return Err(SeriesError::MissingLogCoefficient);
        }

        // construct the log argument, which may contain x
        let c = (self.variable.to_atom() - &self.expansion_point).pow(self.get_exponent(0))
            * &self.coefficients[0];
        // normalize the series to 1 + ..
        let p = self
            .clone()
            .div_coeff(&self.coefficients[0])
            .mul_exp_units(-self.shift)
            - self.one();

        let mut e = self.constant(FunctionBuilder::new(Symbol::LOG).add_arg(&c).finish());
        let mut sp = p.clone();
        for i in 1..=self.order {
            let s = sp.clone().div_coeff(&Atom::num(i as i64));

            sp = sp * &p;

            if i % 2 == 0 {
                e = e - s;
            } else {
                e = e + s;
            }
        }

        Ok(e)
    }

    /// Expand the sine of this series to the available order. Returns an error
    /// for poles or a constant coefficient that still depends on the expansion variable.
    pub fn sin(&self) -> Result<Self, SeriesError> {
        if self.shift < 0 {
            return Err(SeriesError::EssentialSingularity {
                function: Symbol::SIN,
            });
        }

        if self.order == 0 {
            return Ok(Series::new(
                &self.field,
                Some(1),
                self.variable.clone(),
                self.expansion_point.clone(),
                (self.shift as i64, 1).into(),
            ));
        }

        let c = if self.shift == 0 {
            self.coefficients[0].clone()
        } else {
            Atom::new()
        };

        if c.contains(self.variable.to_atom()) {
            return Err(SeriesError::ConstantTermDependsOnExpansionVariable {
                function: Symbol::SIN,
                constant: c,
                variable: self.variable.as_ref().clone(),
            });
        }

        let p = self.clone().remove_constant();

        let mut e = self.constant(FunctionBuilder::new(Symbol::SIN).add_arg(&c).finish());
        let mut sp = p.clone();
        for i in 1..=self.order {
            let mut b = if i % 2 == 1 {
                FunctionBuilder::new(Symbol::COS).add_arg(&c).finish()
            } else {
                FunctionBuilder::new(Symbol::SIN).add_arg(&c).finish()
            };

            if i % 4 >= 2 {
                b = b.neg();
            }

            let s = sp
                .clone()
                .mul_coeff(&b)
                .div_coeff(&Atom::num(Integer::factorial(i as u32)));

            sp = sp * &p;

            e = e + s;
        }

        Ok(e)
    }

    /// Expand the cosine of this series to the available order. Returns an error
    /// for poles or a constant coefficient that still depends on the expansion variable.
    pub fn cos(&self) -> Result<Self, SeriesError> {
        if self.shift < 0 {
            return Err(SeriesError::EssentialSingularity {
                function: Symbol::COS,
            });
        }

        if self.order == 0 {
            return Ok(self.one_inf_prec()
                + Series::new(
                    &self.field,
                    Some(1),
                    self.variable.clone(),
                    self.expansion_point.clone(),
                    (self.shift as i64 * 2, 1).into(),
                ));
        }

        let c = if self.shift == 0 {
            self.coefficients[0].clone()
        } else {
            Atom::new()
        };

        if c.contains(self.variable.to_atom()) {
            return Err(SeriesError::ConstantTermDependsOnExpansionVariable {
                function: Symbol::COS,
                constant: c,
                variable: self.variable.as_ref().clone(),
            });
        }

        let p = self.clone().remove_constant();

        let mut e = self.constant(FunctionBuilder::new(Symbol::COS).add_arg(&c).finish());
        let mut sp = p.clone();
        for i in 1..=self.order {
            let mut b = if i % 2 == 1 {
                FunctionBuilder::new(Symbol::SIN).add_arg(&c).finish()
            } else {
                -FunctionBuilder::new(Symbol::COS).add_arg(&c).finish()
            };

            if i % 4 < 2 {
                b = b.neg();
            }

            let s = sp
                .clone()
                .mul_coeff(&b)
                .div_coeff(&Atom::num(Integer::factorial(i as u32)));

            sp = sp * &p;

            e = e + s;
        }

        Ok(e)
    }

    /// Take the series to the power of another series.
    pub fn pow(&self, pow: &Self) -> Result<Self, SeriesError> {
        (self.log()? * pow).exp()
    }

    /// Take the series to the power of a rational number.
    pub fn rpow(&self, pow: Rational) -> Result<Self, SeriesError> {
        if pow.is_zero() {
            return Err(SeriesError::ZeroPowerRequiresInfinitePrecision);
        }

        if pow.is_integer() && !pow.is_negative() {
            return Ok(self.npow(pow.numerator().to_i64().unwrap() as usize));
        }

        let mut base = self.clone();
        base.normalize_trailing_coefficient();
        if base.is_zero() {
            if pow.is_negative() {
                return Err(SeriesError::DivisionByZero);
            }

            base.shift *= pow.numerator().to_i64().unwrap() as isize;
            base.order *= pow.numerator().to_i64().unwrap() as usize;
            base.ramification *= pow.denominator().to_i64().unwrap() as usize;
            return Ok(base);
        }

        let c = base.coefficients[0].clone();
        let order = base.order;
        let shift = base.shift;
        let p = Rational::from((base.shift as i64, base.ramification as i64)) * &pow;
        let mut r = base.one();
        let mut x = base.one();

        // normalize the series to 1 + ...
        let cc = base.div_coeff(&c).mul_exp_units(-shift) - r.one();

        let mut num = Rational::one();

        for i in 1..=order {
            num = &num * &(&pow - &(i as i64 - 1).into());

            x = x * &cc;

            let p = x
                .clone()
                .mul_coeff(&Atom::num(num.clone()))
                .div_coeff(&Atom::num(Integer::factorial(i as u32)));

            r = r + p;
        }

        r.change_ramification(p.denominator().to_i64().unwrap() as usize);

        let shift = p.numerator().to_i64().unwrap() as isize
            * (r.ramification / p.denominator().to_i64().unwrap() as usize) as isize;

        Ok(r.mul_coeff(&c.pow(pow)).mul_exp_units(shift))
    }

    /// Return the stored terms as an expression, discarding the unknown remainder.
    pub fn to_atom(&self) -> Atom {
        let mut a = Atom::new();
        self.to_atom_into(&mut a);
        a
    }

    /// Write the stored terms as an expression into `out`, replacing its previous
    /// contents and discarding the unknown remainder.
    pub fn to_atom_into(&self, out: &mut Atom) {
        out.to_num(0);

        if self.order == 0 {
            return;
        }

        let v = self.variable.to_atom() - &self.expansion_point;
        for (e, c) in self.coefficients.iter().enumerate() {
            let p = self.get_exponent(e);
            if !c.is_zero() {
                *out = &*out + &(v.pow(p) * c);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::{
        atom::{Atom, AtomCore},
        domains::rational::{Q, Rational},
        parse,
        poly::series::{Series, SeriesDepth},
        symbol,
    };
    use std::sync::Arc;

    #[test]
    fn absolute_truncation_preserves_finite_zero_precision() {
        let x = symbol!("absolute_zero_precision_x");
        for known_order in [Rational::from(6), (3, 2).into()] {
            let prototype =
                Series::new(&Q, None, Arc::new(x.into()), 0.into(), known_order.clone());
            for requested in [
                known_order.clone(),
                (1, 3).into(),
                0.into(),
                (-2).into(),
                7.into(),
            ] {
                let mut zero = prototype.zero();
                zero.truncate_absolute_order(requested.clone());
                assert_eq!(zero.absolute_order(), known_order);
                assert_eq!(
                    zero.coefficient(known_order.clone() - Rational::from(1)),
                    Some(0.into())
                );
                assert_eq!(zero.coefficient(known_order.clone()), None);
                zero.truncate_absolute_order(requested);
                assert_eq!(zero.absolute_order(), known_order);
            }
        }
    }

    #[test]
    fn absolute_truncation_keeps_leading_zero_information() {
        let x = symbol!("absolute_last_term_x");
        let prototype = Series::new(&Q, None, Arc::new(x.into()), 0.into(), 6.into());
        for (exponent, order) in [
            (Rational::from(4), Rational::from(2)),
            ((-1).into(), (-2).into()),
            ((1, 2).into(), (1, 3).into()),
        ] {
            let mut series = prototype.monomial(1.into(), exponent.clone());
            series.truncate_absolute_order(order);
            assert!(series.is_zero());
            assert_eq!(series.absolute_order(), exponent);
            assert_eq!(
                series.coefficient(exponent.clone() - Rational::from(1)),
                Some(0.into())
            );
            assert_eq!(series.coefficient(exponent), None);
        }
    }

    #[test]
    fn absolute_truncation_after_cancellation_preserves_known_zeros() {
        let x = symbol!("absolute_cancelled_x");
        let series = parse!("absolute_cancelled_x^2").series(x, 0, 6).unwrap();
        let mut zero = &series - &series;
        let known_order = zero.absolute_order();
        zero.truncate_absolute_order(3.into());
        assert_eq!(zero.absolute_order(), known_order);
        assert_eq!(zero.coefficient(6.into()), Some(Atom::Zero));
        assert_eq!(zero.coefficient(known_order), None);

        let mut nonzero = parse!("1+absolute_cancelled_x^4").series(x, 0, 6).unwrap();
        nonzero.truncate_absolute_order(3.into());
        assert_eq!(nonzero.coefficient(0.into()), Some(Atom::num(1)));
        assert_eq!(nonzero.coefficient(2.into()), Some(Atom::Zero));
        assert_eq!(nonzero.coefficient(3.into()), None);
    }

    #[test]
    fn coefficient_distinguishes_unknown_from_zero() {
        let x = symbol!("coefficient_range_x");
        let s = parse!("exp(coefficient_range_x)").series(x, 0, 2).unwrap();
        assert_eq!(s.coefficient(2.into()), Some(Atom::num((1, 2))));
        assert_eq!(s.coefficient(3.into()), None);
        assert_eq!(s.coefficient((7, 2).into()), None);
        assert_eq!(s.coefficient((-1).into()), Some(Atom::Zero));
        assert_eq!(s.coefficient((1, 2).into()), Some(Atom::Zero));
        let huge: crate::domains::rational::Rational = parse!("1000000000000000000000000000000000")
            .try_into()
            .unwrap();
        assert_eq!(s.coefficient(huge.clone()), None);
        assert_eq!(s.coefficient(-huge), Some(Atom::Zero));

        let sparse = parse!("coefficient_range_x^2").series(x, 0, 4).unwrap();
        assert_eq!(sparse.coefficient(0.into()), Some(Atom::Zero));
        assert_eq!(sparse.coefficient(4.into()), Some(Atom::Zero));
        assert_eq!(sparse.coefficient(5.into()), None);
        let zero = &sparse - &sparse;
        assert_eq!(zero.coefficient(4.into()), Some(Atom::Zero));
        assert_eq!(zero.coefficient(5.into()), None);
    }

    #[test]
    fn coefficient_handles_laurent_and_puiseux_remainders() {
        let x = symbol!("coefficient_fraction_x");
        let s = parse!("1/coefficient_fraction_x+sqrt(coefficient_fraction_x)")
            .series(x, 0, SeriesDepth::absolute((3, 2)))
            .unwrap();
        assert_eq!(s.coefficient((-1).into()), Some(Atom::num(1)));
        assert_eq!(s.coefficient((1, 2).into()), Some(Atom::num(1)));
        assert_eq!(s.coefficient((1, 3).into()), Some(Atom::Zero));
        assert_eq!(s.coefficient((3, 2).into()), Some(Atom::Zero));
        assert_eq!(s.coefficient(s.absolute_order()), None);
        let pole = parse!("1/coefficient_fraction_x^3")
            .series(x, 0, -2)
            .unwrap();
        assert_eq!(pole.coefficient((-3).into()), Some(Atom::num(1)));
        assert_eq!(pole.coefficient((-2).into()), Some(Atom::Zero));
        assert_eq!(pole.coefficient(0.into()), None);
    }

    #[test]
    fn map_coeff() {
        let a = parse!("((v1+1)^2 - (v1^2 + 2v1 + 1))/v2")
            .series(symbol!("v2"), Atom::Zero, SeriesDepth::absolute(0))
            .unwrap();
        assert_eq!(a.get_trailing_exponent(), -1);

        let b = a.map_coeff(|x| x.expand());
        assert_eq!(b.get_trailing_exponent(), 1);
    }

    #[test]
    fn reciprocal_retries_after_exact_coefficient_cancellation() {
        let x = parse!("series_cancellation_x");
        for text in [
            "(a+1)^2-a^2-2*a-1",
            "1/a-1/(a+1)-1/(a*(a+1))",
            "(a+1i*b)^2-a^2-2i*a*b+b^2",
            "sin(a)^2+cos(a)^2-1",
            "sqrt(2)*sqrt(3)-sqrt(6)",
        ] {
            let c = parse!(text);
            assert!(!c.is_zero(), "{text}");
            assert!(c.check_zero().is_true(), "{text}");
            for power in [1, 2, 4, 10] {
                // Start with the original 1/(c+x) regression, then cancel two
                // coefficients and force deeper expansion to find a nonzero one.
                let zeros = if power == 1 { c.clone() } else { &c * (&x + 1) };
                let input = (zeros + x.pow(power)).pow(-1);
                let result = input
                    .series(
                        symbol!("series_cancellation_x"),
                        0,
                        SeriesDepth::absolute(1),
                    )
                    .unwrap();
                assert_eq!(result.to_atom(), x.pow(-power), "{input}");
                assert_eq!(result.get_trailing_exponent(), -power, "{input}");
            }
        }
    }

    #[test]
    fn rational_powers_remove_exact_zero_leading_coefficients() {
        let x = symbol!("series_rpow_cancellation_x");
        let c = parse!("1/a-1/(a+1)-1/(a*(a+1))");
        let vanishing = &c * parse!("1+sqrt(series_rpow_cancellation_x)");
        for text in [
            "series_rpow_cancellation_x^2*(1+series_rpow_cancellation_x)",
            "series_rpow_cancellation_x^(3/2)*(1+sqrt(series_rpow_cancellation_x))",
        ] {
            let clean = parse!(text).series(x, 0, SeriesDepth::absolute(4)).unwrap();
            let base = (parse!(text) + &vanishing)
                .series(x, 0, SeriesDepth::absolute(4))
                .unwrap();
            for power in [(-1, 1), (1, 2), (-1, 2)] {
                let actual = base.rpow(power.into()).unwrap();
                let expected = clean.rpow(power.into()).unwrap();
                assert_eq!(actual.to_atom(), expected.to_atom(), "{text}, {power:?}");
                assert_eq!(actual.absolute_order(), expected.absolute_order());
            }
        }

        let zero = vanishing.series(x, 0, SeriesDepth::absolute(4)).unwrap();
        assert!(matches!(
            zero.rpow((-1, 1).into()),
            Err(super::SeriesError::DivisionByZero)
        ));
        let root = zero.rpow((1, 2).into()).unwrap();
        assert!(root.is_zero());
        assert_eq!(
            root.absolute_order(),
            zero.absolute_order() / super::Rational::from(2)
        );
    }

    #[test]
    fn coefficient_cleanup_preserves_nonzero_and_unresolved_terms() {
        for text in ["(a+1)^2-a^2-2*a-1+1/10^100", "log(2)+log(3)-log(6)"] {
            let coefficient = parse!(text);
            assert!(!coefficient.together().is_zero());
            let mut series = (coefficient.clone() + parse!("series_cleanup_x"))
                .series(symbol!("series_cleanup_x"), 0, SeriesDepth::absolute(2))
                .unwrap();
            let original = series.to_atom();
            let order = series.absolute_order();
            series.normalize_trailing_coefficient();
            assert_eq!(series.get_trailing_coefficient(), coefficient);
            assert_eq!(series.to_atom(), original);
            assert_eq!(series.absolute_order(), order);
        }
    }
}

#[cfg(test)]
mod puiseux_tests {
    use crate::{
        atom::{Atom, AtomCore},
        parse,
        poly::series::SeriesDepth,
        symbol,
    };

    #[test]
    fn fractional_product_and_laurent_series_have_correct_coefficients() {
        let x = symbol!("puiseux_precision::x");
        let s = parse!("puiseux_precision::x^(1/3)*(1+puiseux_precision::x)^(1/2)")
            .series(x, 0, SeriesDepth::absolute((7, 3)))
            .unwrap();
        for (exponent, coefficient) in [((1, 3), (1, 1)), ((4, 3), (1, 2)), ((7, 3), (-1, 8))] {
            assert_eq!(s.coefficient(exponent.into()), Some(Atom::num(coefficient)));
        }
        let square = (&s * &s).map_coeff(|a| a.expand());
        assert_eq!(square.coefficient((2, 3).into()), Some(Atom::num(1)));
        assert_eq!(square.coefficient((5, 3).into()), Some(Atom::num(1)));
        assert_eq!(square.coefficient((8, 3).into()), Some(Atom::Zero));
        let pole = parse!("puiseux_precision::x^(-1/3)*(1+puiseux_precision::x)")
            .series(x, 0, SeriesDepth::absolute((2, 3)))
            .unwrap();
        assert_eq!(pole.coefficient((-1, 3).into()), Some(Atom::num(1)));
        assert_eq!(pole.coefficient((2, 3).into()), Some(Atom::num(1)));
    }

    #[test]
    fn fractional_depth_at_nonzero_centre_and_integer_control() {
        let x = symbol!("puiseux_precision::x");
        for depth in [SeriesDepth::absolute((7, 3)), SeriesDepth::absolute(3)] {
            let s = parse!("puiseux_precision::x^2")
                .series(x, 2, depth)
                .unwrap();
            assert_eq!(s.coefficient(0.into()), Some(Atom::num(4)));
            assert_eq!(s.coefficient(1.into()), Some(Atom::num(4)));
            assert_eq!(s.coefficient(2.into()), Some(Atom::num(1)));
            assert_eq!(s.coefficient((1, 3).into()), Some(Atom::Zero));
        }
    }
}
