use std::{
    ops::Deref,
    sync::{Arc, OnceLock},
};

mod cpp;

use crate::{
    atom::{Atom, AtomCore, AtomOrView, AtomView, EvaluationInfo, FunctionBuilder, Symbol},
    coefficient::{Coefficient, CoefficientView},
    domains::{
        algebraic::{AlgebraicExtension, AlgebraicNumber, Root},
        backend::float::Constant,
        float::{
            Complex, ErrorPropagatingFloat, Float, FloatField, FloatLike, Real, RealLike,
            SingleFloat,
        },
        integer::{Integer, IntegerRing},
        rational::{Q, Rational, RationalField},
        rational_polynomial::RationalPolynomialField,
    },
    function, get_symbol,
    poly::{
        PolyVariable,
        univariate::{RootLocation, UnivariatePolynomial},
    },
    state::{State, StateInitializer},
    symbol,
    utils::Settable,
};

// State initialization runs dependent crates' callbacks, which may themselves
// request a transcendental symbol. Enter State BEFORE acquiring this cache's
// initialization lock; the opposite order would re-enter the same pending
// LazyLock/OnceLock from such a callback.
struct SymbolCache<T> {
    value: OnceLock<T>,
    initialize: fn() -> T,
}

impl<T> SymbolCache<T> {
    const fn new(initialize: fn() -> T) -> Self {
        Self {
            value: OnceLock::new(),
            initialize,
        }
    }
}

impl<T> Deref for SymbolCache<T> {
    type Target = T;

    fn deref(&self) -> &Self::Target {
        if let Some(value) = self.value.get() {
            return value;
        }
        let _ = State::get_global_state();
        self.value.get_or_init(self.initialize)
    }
}

static SPECIALS: SymbolCache<SpecialSymbols> = SymbolCache::new(|| SpecialSymbols {
    euler_gamma: get_symbol!("euler_gamma").expect("Euler gamma not defined"),
    gamma: get_symbol!("gamma").expect("gamma not defined"),
    erf: get_symbol!("erf").expect("erf not defined"),
    polygamma: get_symbol!("polygamma").expect("polygamma not defined"),
    polylog: get_symbol!("polylog").expect("polylog not defined"),
    root: get_symbol!("root").expect("root not defined"),
    root_var: get_symbol!("root_var").expect("root_var not defined"),
    zeta: get_symbol!("zeta").expect("zeta not defined"),
});
static GEOMETRICS: SymbolCache<GeometricSymbols> = SymbolCache::new(|| GeometricSymbols {
    tan: get_symbol!("tan").expect("tan not defined"),
    cot: get_symbol!("cot").expect("cot not defined"),
    sec: get_symbol!("sec").expect("sec not defined"),
    csc: get_symbol!("csc").expect("csc not defined"),
    asin: get_symbol!("asin").expect("asin not defined"),
    acos: get_symbol!("acos").expect("acos not defined"),
    atan: get_symbol!("atan").expect("atan not defined"),
    acot: get_symbol!("acot").expect("acot not defined"),
    asec: get_symbol!("asec").expect("asec not defined"),
    acsc: get_symbol!("acsc").expect("acsc not defined"),
    sinh: get_symbol!("sinh").expect("sinh not defined"),
    cosh: get_symbol!("cosh").expect("cosh not defined"),
    tanh: get_symbol!("tanh").expect("tanh not defined"),
    coth: get_symbol!("coth").expect("coth not defined"),
    sech: get_symbol!("sech").expect("sech not defined"),
    csch: get_symbol!("csch").expect("csch not defined"),
    asinh: get_symbol!("asinh").expect("asinh not defined"),
    acosh: get_symbol!("acosh").expect("acosh not defined"),
    atanh: get_symbol!("atanh").expect("atanh not defined"),
    acoth: get_symbol!("acoth").expect("acoth not defined"),
    asech: get_symbol!("asech").expect("asech not defined"),
    acsch: get_symbol!("acsch").expect("acsch not defined"),
});
static BESSELS: SymbolCache<BesselSymbols> = SymbolCache::new(|| BesselSymbols {
    bessel_j: get_symbol!("bessel_j").expect("bessel_j not defined"),
    bessel_y: get_symbol!("bessel_y").expect("bessel_y not defined"),
    bessel_i: get_symbol!("bessel_i").expect("bessel_i not defined"),
    bessel_k: get_symbol!("bessel_k").expect("bessel_k not defined"),
});

struct SpecialSymbols {
    euler_gamma: Symbol,
    gamma: Symbol,
    erf: Symbol,
    polygamma: Symbol,
    polylog: Symbol,
    root: Symbol,
    root_var: Symbol,
    zeta: Symbol,
}

struct GeometricSymbols {
    tan: Symbol,
    cot: Symbol,
    sec: Symbol,
    csc: Symbol,
    asin: Symbol,
    acos: Symbol,
    atan: Symbol,
    acot: Symbol,
    asec: Symbol,
    acsc: Symbol,
    sinh: Symbol,
    cosh: Symbol,
    tanh: Symbol,
    coth: Symbol,
    sech: Symbol,
    csch: Symbol,
    asinh: Symbol,
    acosh: Symbol,
    atanh: Symbol,
    acoth: Symbol,
    asech: Symbol,
    acsch: Symbol,
}

struct BesselSymbols {
    bessel_j: Symbol,
    bessel_y: Symbol,
    bessel_i: Symbol,
    bessel_k: Symbol,
}

fn canonical_root_polynomial(polynomial: AtomView<'_>, variable: &PolyVariable) -> Option<Atom> {
    if variable == &PolyVariable::Symbol(root_var()) {
        return None;
    }

    let variable = match variable {
        PolyVariable::Temporary(_) => return None,
        _ => Atom::from(variable.clone()),
    };
    Some(polynomial.replace(variable).with(Atom::var(root_var())))
}

impl SpecialSymbols {
    fn new() -> Self {
        let root_var = symbol!("ξ", aliases = ["root_var"]);

        let root = symbol!(
            "root",
            norm = move |x, out| {
                let (poly_tag, explicit_variable, index_tag) = if let Some([poly_tag, index_tag]) =
                    function_arguments::<2>(x)
                {
                    (poly_tag, None, index_tag)
                } else if let Some([poly_tag, variable_tag, index_tag]) = function_arguments::<3>(x)
                {
                    let AtomView::Var(variable) = variable_tag else {
                        return;
                    };
                    (
                        poly_tag,
                        Some(PolyVariable::from(variable.get_symbol())),
                        index_tag,
                    )
                } else {
                    return;
                };

                let Ok(index) = usize::try_from(index_tag) else {
                    return;
                };

                let rational_root = if let Some(variable) = &explicit_variable {
                    Root::<Q>::from_atom_with_variable(poly_tag, variable.clone(), index)
                } else {
                    Root::<Q>::from_atom(poly_tag, index)
                };
                if let Ok(root) = rational_root {
                    match root.simplify() {
                        Ok(simplified)
                            if simplified != root || simplified.polynomial().degree(0) <= 2 =>
                        {
                            **out = simplified.to_atom();
                        }
                        _ if root.polynomial().get_vars_ref()[0]
                            != PolyVariable::Symbol(root_var) =>
                        {
                            **out = root.to_atom();
                        }
                        _ => {}
                    }
                    return;
                }

                let algebraic_root = if let Some(variable) = &explicit_variable {
                    Root::<AlgebraicExtension<Q>>::from_atom_with_variable(
                        poly_tag,
                        variable.clone(),
                        index,
                    )
                } else {
                    Root::<AlgebraicExtension<Q>>::from_atom(poly_tag, index)
                };
                if let Ok(Some(root)) = algebraic_root {
                    if let Ok(Some(simplified)) = root.simplify() {
                        **out = simplified.to_atom();
                    } else if let Some(polynomial) =
                        canonical_root_polynomial(poly_tag, &root.polynomial().get_vars_ref()[0])
                    {
                        **out = polynomial.root(index);
                    }
                    return;
                }

                let parametric_root = if let Some(variable) = &explicit_variable {
                    Root::<RationalPolynomialField<IntegerRing, u16>>::from_atom_with_variable(
                        poly_tag,
                        variable.clone(),
                        index,
                    )
                } else {
                    Root::<RationalPolynomialField<IntegerRing, u16>>::from_atom(poly_tag, index)
                };
                if let Ok(root) = parametric_root {
                    if let Some(simplified) = root.simplify() {
                        **out = simplified;
                    } else if root.polynomial().get_vars_ref()[0] != PolyVariable::Symbol(root_var)
                    {
                        **out = root.to_atom();
                    }
                    return;
                }

                // Canonicalize the polynomial variable even when the selected
                // root index is invalid. Use index zero only to recover the
                // same variable selection and degree without weakening Root's index
                // validation.
                let rational_root = if let Some(variable) = &explicit_variable {
                    Root::<Q>::from_atom_with_variable(poly_tag, variable.clone(), 0)
                } else {
                    Root::<Q>::from_atom(poly_tag, 0)
                };
                let mut root_metadata = rational_root.ok().map(|root| {
                    (
                        root.polynomial().get_vars_ref()[0].clone(),
                        root.polynomial().degree(0) as usize,
                    )
                });

                if root_metadata.is_none() {
                    let algebraic_root = if let Some(variable) = &explicit_variable {
                        Root::<AlgebraicExtension<Q>>::from_atom_with_variable(
                            poly_tag,
                            variable.clone(),
                            0,
                        )
                    } else {
                        Root::<AlgebraicExtension<Q>>::from_atom(poly_tag, 0)
                    };
                    root_metadata = algebraic_root.ok().flatten().map(|root| {
                        (
                            root.polynomial().get_vars_ref()[0].clone(),
                            root.polynomial().degree(0) as usize,
                        )
                    });
                }

                if root_metadata.is_none() {
                    let parametric_root = if let Some(variable) = explicit_variable {
                        Root::<RationalPolynomialField<IntegerRing, u16>>::from_atom_with_variable(
                            poly_tag, variable, 0,
                        )
                    } else {
                        Root::<RationalPolynomialField<IntegerRing, u16>>::from_atom(poly_tag, 0)
                    };
                    root_metadata = parametric_root.ok().map(|root| {
                        (
                            root.polynomial().get_vars_ref()[0].clone(),
                            root.polynomial().degree(0) as usize,
                        )
                    });
                }

                if let Some((variable, degree)) = root_metadata {
                    if let Some(polynomial) = canonical_root_polynomial(poly_tag, &variable) {
                        // The canonical root emits the warning during normalization.
                        **out = polynomial.root(index);
                    } else if index >= degree {
                        crate::warn!(
                            "root index {index} is out of bounds for polynomial of degree {degree}"
                        );
                    }
                }
            },
            der = |_x, _i, out| {
                out.to_num(Coefficient::zero());
            },
            eval = EvaluationInfo::constant(root_numeric_eval).with_tags(2)
        );

        let euler_gamma = symbol!(
            "γ",
            aliases = ["euler_gamma"],
            der = |_x, _i, out| {
                out.to_num(Coefficient::zero());
            },
            print = |_view, opt, _state| {
                if opt.mode.is_latex() {
                    Some("\\gamma".to_string())
                } else if opt.mode.is_typst() {
                    Some("gamma".to_string())
                } else {
                    None
                }
            },
            eval = EvaluationInfo::constant(|_tags, prec| {
                Ok(Complex::new(
                    Float::with_val(prec, Constant::Euler),
                    Float::new(prec),
                ))
            })
        );

        let mut symbols = crate::symbol_group!(
            "gamma";;
            |symbols, b| {
                let gamma_symbol = symbols[0];
                let polygamma_symbol = symbols[1];

                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if maybe_eval_unary_float_in_norm(arg, out, gamma_numeric_eval) {
                            return;
                        }

                        if let Ok(rat) = Rational::try_from(arg)
                            && let Some(exact) = gamma_exact_rational(&rat)
                        {
                            **out = exact;
                        }
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0
                        && let Some([arg]) = function_arguments::<1>(x)
                    {
                        **out = function!(gamma_symbol, arg) * function!(polygamma_symbol, 0, arg);
                    }
                })
                .with_print_function(|view, opt, state| {
                    if let AtomView::Fun(f) = view {
                        if opt.mode.is_latex() {
                            let mut str = String::new();
                            let _ = f.format(Some("\\Gamma"), &mut str, opt, *state);
                            return Some(str);
                        } else if opt.mode.is_typst() {
                            let mut str = String::new();
                            let _ = f.format(Some("Gamma"), &mut str, opt, *state);
                            return Some(str);
                        }
                    }

                    None
                })
                .with_series_function(
                    move |args| {
                        let [arg] = args else { return None; };
                        let point = arg.coefficient(0.into())?;
                        let Ok(pole) = Integer::try_from(&point) else {
                            return None;
                        };

                        if pole > 0 {
                            return None;
                        }

                        let arg = arg.to_atom();
                        let shift = (-pole).to_i64().unwrap();
                        let mut regularized = function!(gamma_symbol, arg.to_owned() + shift + 1);
                        for k in 0..shift {
                            regularized /= arg.to_owned() + k;
                        }

                        Some((Atom::num(1) / (arg + shift), regularized))
                    },
                )
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("gamma", "tgamma", "x", false))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, gamma_numeric_eval)
                    })
                    .register(|args: &[Float]| {
                        let prec = args.first().map(|x| x.prec()).unwrap_or(53);
                        let [arg] = args else {
                            return Float::with_val(53, f64::NAN);
                        };
                        gamma_numeric_eval(&Complex::new(arg.clone(), Float::new(prec)), prec).re
                    })
                    .register(|args: &[f64]| unary_eval_f64(args, gamma_numeric_eval))
                    .register(|args: &[Complex<f64>]| {
                        unary_eval_complex_f64(args, gamma_numeric_eval)
                    }),
                )
            },
            "polygamma";;
            |symbols, b| {
                let polygamma_symbol = symbols[1];

                b.with_normalization_function(move |x, out| {
                    if let Some([n, z]) = function_arguments::<2>(x)
                        && let Ok(order) = u32::try_from(n) {
                            if maybe_eval_polygamma_float_in_norm(order, z, out) {
                                return;
                            }

                            if let Ok(rat) = Rational::try_from(z)
                                && let Some(exact) = polygamma_exact_rational(order, &rat)
                            {
                                **out = exact;
                                return;
                            }

                            if let Ok(rat) = Rational::try_from(z)
                                && rat.denominator() == 1
                                && rat.numerator() <= 0
                            {
                                out.to_num(Coefficient::complex_infinity());
                            }
                        }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 1
                        && let Some([n, z]) = function_arguments::<2>(x)
                        && let Ok(order) = u32::try_from(n)
                    {
                        **out = function!(polygamma_symbol, Atom::num(order + 1), z);
                    }
                })
                .with_series_function(move |args| {
                    let [n, arg] = args else { return None; };
                    let order = u32::try_from(n.coefficient(0.into())?).ok()?;
                    let point = arg.coefficient(0.into())?;
                    let Ok(pole) = Integer::try_from(&point) else {
                        return None;
                    };

                    if pole > 0 {
                        return None;
                    }

                    let arg = arg.to_atom();
                    let shift = (-pole).to_i64().unwrap();
                    let pole = arg.to_owned() + shift;
                    let pole_power = pole.pow(Atom::num(order + 1));

                    let sign = if order % 2 == 0 {
                        Atom::num(Integer::factorial(order))
                    } else {
                        -Atom::num(Integer::factorial(order))
                    };

                    let mut recurrence_sum = Atom::new();
                    for k in 0..=shift {
                        recurrence_sum +=
                            Atom::num(1) / (arg.to_owned() + k).pow(Atom::num(order + 1));
                    }

                    let regularized = pole_power.clone()
                        * (function!(polygamma_symbol, Atom::num(order), arg + shift + 1)
                            - sign * recurrence_sum);

                    Some((Atom::num(1) / pole_power, regularized))
                })
                .with_evaluation_info(
                    EvaluationInfo::new().with_tags(1)
                    .register_tagged(|tags| {
                        let order = nonnegative_integer_tag("polygamma", tags).ok();
                        Box::new(move |args: &[Complex<Float>]| {
                            let Some(order) = order else {
                                return Complex::new(
                                    Float::with_val(53, f64::NAN),
                                    Float::with_val(53, f64::NAN),
                                );
                            };
                            unary_eval_complex_float(args, |arg, prec| {
                                polygamma_numeric_eval(order, arg, prec)
                            })
                        })
                    })
                    .register_tagged(|tags| {
                        let order = nonnegative_integer_tag("polygamma", tags).ok();
                        Box::new(move |args: &[Float]| {
                            let Some(order) = order else {
                                return Float::with_val(53, f64::NAN);
                            };
                            let prec = args.first().map(|x| x.prec()).unwrap_or(53);
                            let [arg] = args else {
                                return Float::with_val(53, f64::NAN);
                            };
                            polygamma_numeric_eval(
                                order,
                                &Complex::new(arg.clone(), Float::new(prec)),
                                prec,
                            )
                            .re
                        })
                    })
                    .register_tagged(|tags| {
                        let order = nonnegative_integer_tag("polygamma", tags).ok();
                        Box::new(move |args: &[f64]| polygamma_eval_f64(order, args))
                    })
                    .register_tagged(|tags| {
                        let order = nonnegative_integer_tag("polygamma", tags).ok();
                        Box::new(move |args: &[Complex<f64>]| {
                            polygamma_eval_complex_f64(order, args)
                        })
                    }),
                )
            },
            "polylog";;
            |symbols, b| {
                let polylog_symbol = symbols[2];

                b.with_normalization_function(|x, out| {
                    if let Some([s, z]) = function_arguments::<2>(x) {
                        if let Some(exact) = polylog_exact(s, z) {
                            **out = exact;
                            return;
                        }

                        if maybe_eval_binary_float_in_norm(s, z, out, polylog_numeric_eval) {
                        }
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 1
                        && let Some([s, z]) = function_arguments::<2>(x)
                    {
                        **out = function!(polylog_symbol, s.to_owned() - 1, z) / z;
                    }
                })
                .with_series_function(|args| {
                    let [n, z] = args else { return None; };
                    let order = u32::try_from(n.to_atom()).ok()?;
                    if order < 2 || z.get_trailing_exponent() <= 0 {
                        return None;
                    }

                    // At zero, substitution into the derivative Li_{n-1}(z)/z
                    // loses the removable limit. Compose the defining series
                    // instead, as in polylog_series_integer. Positive valuation
                    // ensures that only finitely many powers survive truncation.
                    let depth = z.absolute_order();
                    let mut sum = z.clone();
                    let mut power = z.clone();
                    let mut k = Integer::from(2);
                    loop {
                        power = &power * z;
                        power.truncate_absolute_order(depth.clone());
                        if power.is_zero() {
                            break;
                        }
                        sum = &sum + &power.clone().div_coeff(&Atom::num(k.clone()).pow(order));
                        k += 1;
                    }
                    Some((Atom::num(1), sum.to_atom()))
                })
                .with_evaluation_info(
                    EvaluationInfo::new().with_tags(1)
                    .register_tagged(|tags| {
                        let tags = tags.iter().map(|x| x.to_owned()).collect::<Vec<_>>();
                        Box::new(move |args: &[Complex<Float>]| {
                            let prec = args
                                .first()
                                .map(|x| x.re.prec().max(x.im.prec()))
                                .unwrap_or(53);
                            let tag_views = tags.iter().map(|x| x.as_view()).collect::<Vec<_>>();
                            let Ok(order) = complex_float_tag("polylog", &tag_views, prec) else {
                                return Complex::new(
                                    Float::with_val(53, f64::NAN),
                                    Float::with_val(53, f64::NAN),
                                );
                            };
                            let [arg] = args else {
                                return Complex::new(
                                    Float::with_val(53, f64::NAN),
                                    Float::with_val(53, f64::NAN),
                                );
                            };
                            polylog_numeric_eval(&order, arg, prec).unwrap_or_else(|| {
                                Complex::new(
                                    Float::with_val(53, f64::NAN),
                                    Float::with_val(53, f64::NAN),
                                )
                            })
                        })
                    })
                    .register_tagged(|tags| {
                        let tags = tags.iter().map(|x| x.to_owned()).collect::<Vec<_>>();
                        Box::new(move |args: &[Float]| {
                            let prec = args.first().map(|x| x.prec()).unwrap_or(53);
                            let tag_views = tags.iter().map(|x| x.as_view()).collect::<Vec<_>>();
                            let Ok(order) = complex_float_tag("polylog", &tag_views, prec) else {
                                return Float::with_val(53, f64::NAN);
                            };
                            let [arg] = args else {
                                return Float::with_val(53, f64::NAN);
                            };
                            polylog_numeric_eval(
                                &order,
                                &Complex::new(arg.clone(), Float::new(prec)),
                                prec,
                            )
                            .map(|z| z.re)
                            .unwrap_or_else(|| Float::with_val(53, f64::NAN))
                        })
                    })
                    .register_tagged(|tags| {
                        let order = complex_float_tag("polylog", tags, 53).ok();
                        let dilogarithm = order.as_ref().is_some_and(is_dilogarithm_order);
                        Box::new(move |args: &[f64]| {
                            polylog_eval_f64(order.as_ref(), dilogarithm, args)
                        })
                    })
                    .register_tagged(|tags| {
                        let order = complex_float_tag("polylog", tags, 53).ok();
                        let dilogarithm = order.as_ref().is_some_and(is_dilogarithm_order);
                        Box::new(move |args: &[Complex<f64>]| {
                            polylog_eval_complex_f64(order.as_ref(), dilogarithm, args)
                        })
                    }),
                )
            },
            "dzeta";;
            |symbols, b| {
                let dzeta = symbols[3];
                let zeta = symbols[4];
                b.with_normalization_function(move |x, out| {
                    if let Some([depth, arg]) = function_arguments::<2>(x) {
                        if depth == 0 {
                            **out = function!(zeta, arg);
                            return;
                        }

                        // TODO: add Stieltjes constants
                        if depth == 1 && arg == 0 {
                            **out = -(Atom::var(Symbol::PI) * 2).log() / 2;
                        }
                    }
                })
                .with_derivative_function(move |x, _, out| {
                    if let Some([depth, arg]) = function_arguments::<2>(x)
                    {
                        **out = function!(dzeta, depth.to_owned() + 1, arg);
                    }
                })
            }
            ,
            "zeta";;
            |symbols, b| {
                let gamma = symbols[0];
                let dzeta = symbols[3];
                let zeta_symbol = symbols[4];

                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if maybe_eval_unary_float_in_norm(arg, out, zeta_numeric_eval) {
                            return;
                        }

                        if let Ok(rat) = Rational::try_from(arg)
                            && let Some(exact) = zeta_exact_rational(&rat)
                        {
                            **out = exact;
                        }
                    }
                })
                .with_derivative_function(move |x, _, out| {
                    if let Some([arg]) = function_arguments::<1>(x)
                    {

                        **out = function!(dzeta, 1, arg);
                    }
                })
                .with_series_function(move |args| {
                    let [arg] = args else { return None; };
                    let point = arg.coefficient(0.into())?;
                    if point != Coefficient::one() {
                        return None;
                    }

                    let arg = arg.to_atom();
                    let pole = arg.to_owned() - 1;
                    let regularized = (Symbol::PI.to_atom() * 2).pow(&pole) * -2 * (pole.clone() * Symbol::PI / 2).cos() * function!(gamma, -&pole + 1) * function!(zeta_symbol, -&pole);

                    Some((Atom::num(1) / pole, regularized))
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("zeta", "riemann_zeta", "x", false))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, zeta_numeric_eval)
                    })
                    .register(|args: &[Float]| {
                        let prec = args.first().map(|x| x.prec()).unwrap_or(53);
                        let [arg] = args else {
                            return Float::with_val(53, f64::NAN);
                        };
                        zeta_numeric_eval(&Complex::new(arg.clone(), Float::new(prec)), prec).re
                    })
                    .register(|args: &[f64]| zeta_eval_f64(args))
                    .register(|args: &[Complex<f64>]| zeta_eval_complex_f64(args)),
                )
            }
            ,
            "erf";;
            |symbols, b| {
                let erf_symbol = symbols[5];

                b.with_normalization_function(move |x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::zero());
                            return;
                        }

                        if maybe_eval_unary_float_in_norm(arg, out, erf_numeric_eval) {
                            return;
                        }

                        if is_negative_atom(arg) {
                            **out = -function!(erf_symbol, -arg.to_owned());
                        }
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0
                        && let Some([arg]) = function_arguments::<1>(x)
                    {
                        **out = Atom::num(2)
                            * (-arg.to_owned().pow(Atom::num(2))).exp()
                            / Atom::from(State::PI).sqrt();
                    }
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("erf", "erf", "x", false))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, erf_numeric_eval)
                    })
                    .register(|args: &[Float]| {
                        let prec = args.first().map(|x| x.prec()).unwrap_or(53);
                        let [arg] = args else {
                            return Float::with_val(53, f64::NAN);
                        };
                        erf_numeric_eval(&Complex::new(arg.clone(), Float::new(prec)), prec).re
                    })
                    .register(|args: &[f64]| unary_eval_f64(args, erf_numeric_eval))
                    .register(|args: &[Complex<f64>]| {
                        unary_eval_complex_f64(args, erf_numeric_eval)
                    }),
                )
            }
        );

        let erf = symbols.pop().unwrap();
        let zeta = symbols.pop().unwrap();
        let _dzeta = symbols.pop().unwrap();
        let polylog = symbols.pop().unwrap();
        let polygamma = symbols.pop().unwrap();
        let gamma = symbols.pop().unwrap();

        Self {
            euler_gamma,
            gamma,
            erf,
            polygamma,
            polylog,
            root,
            root_var,
            zeta,
        }
    }
}

fn root_numeric_eval(tags: &[AtomView], prec: u32) -> Result<Complex<Float>, String> {
    let [poly_tag, index_tag] = tags else {
        return Err(format!("root expects 2 tags, got {}", tags.len()));
    };

    let index = usize::try_from(*index_tag).map_err(|_| {
        format!(
            "root index {} is not a non-negative integer",
            index_tag.printer(numerica::printer::PrintOptions::file())
        )
    })?;

    let poly = polynomial_tag_to_univariate_complex(poly_tag)?;
    if poly.degree() == 0 {
        return Err(format!(
            "root polynomial {} has no roots",
            poly_tag.printer(numerica::printer::PrintOptions::file())
        ));
    }

    let Some(mut root) = poly.root(index) else {
        return Err(format!(
            "root index {index} is out of bounds for polynomial of degree {}",
            poly.degree()
        ));
    };
    let location = root.classify_location();

    let mut value = root.to_float_center(prec);
    if matches!(location, RootLocation::Imaginary | RootLocation::Zero) {
        value.re = Float::new(prec);
    }
    if matches!(location, RootLocation::Real | RootLocation::Zero) {
        value.im = Float::new(prec);
    }
    Ok(value)
}

fn algebraic_complex_to_complex_rational(c: &AlgebraicNumber<RationalField>) -> Complex<Rational> {
    Complex::new(
        c.poly().coefficient(&[0]).unwrap_or_else(Rational::zero),
        c.poly().coefficient(&[1]).unwrap_or_else(Rational::zero),
    )
}

fn polynomial_tag_to_univariate_complex(
    poly_tag: &AtomView,
) -> Result<UnivariatePolynomial<FloatField<Complex<Rational>>>, String> {
    let algebraic_field = AlgebraicExtension::complex(Q);
    let poly = poly_tag
        .try_to_polynomial::<_, u16>(&algebraic_field, None)
        .map_err(|e| {
            format!("could not convert root polynomial tag to a complex polynomial: {e}")
        })?;
    let complex_field = FloatField::from_rep(Complex::from(Rational::one()));

    match poly.nvars() {
        0 => {
            let mut univariate = UnivariatePolynomial::new(
                &complex_field,
                None,
                Arc::new(PolyVariable::Temporary(0)),
            );
            univariate.coefficients = poly
                .coefficients
                .iter()
                .map(algebraic_complex_to_complex_rational)
                .collect();
            univariate.truncate();
            Ok(univariate)
        }
        1 => Ok(poly
            .to_univariate_from_univariate(0)
            .map_coeff(algebraic_complex_to_complex_rational, complex_field)),
        n => Err(format!(
            "root expects a univariate polynomial, got {n} variables"
        )),
    }
}

impl GeometricSymbols {
    fn new() -> Self {
        let mut symbols = crate::symbol_group!(
            "tan";;
            |symbols, b| {
                let tan = symbols[0];
                let sec = symbols[2];
                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::zero());
                            return;
                        }
                        let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.tan());
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0 && let Some([arg]) = function_arguments::<1>(x) {
                        **out = function!(sec, arg).pow(Atom::num(2));
                    }
                })
                .with_series_function(move |args| {
                    let [arg] = args else { return None; };
                    let point = arg.coefficient(0.into())?;
                    if !is_tan_pole(point.as_view()) {
                        return None;
                    }
                    let delta = arg.to_atom() - &point;
                    Some((Atom::num(1) / &delta, -&delta / function!(tan, delta)))
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("tan", "tan", "x", false))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, |z, _| z.tan())
                    })
                    .register(|args: &[Float]| unary_eval_real(args, |x| x.tan()))
                    .register(|args: &[f64]| unary_eval_real_f64(args, f64::tan))
                    .register(|args: &[Complex<f64>]| unary_eval_complex_real_f64(args, |z| z.tan()))
                    .register(|args: &[ErrorPropagatingFloat<f64>]| {
                        unary_eval_real(args, |x| x.tan())
                    })
                    .register(|args: &[ErrorPropagatingFloat<Float>]| {
                        unary_eval_real(args, |x| x.tan())
                    }),
                )
            },
            "cot";;
            |symbols, b| {
                let tan = symbols[0];
                let csc = symbols[3];
                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::complex_infinity());
                            return;
                        }
                        let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.tan().inv());
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0 && let Some([arg]) = function_arguments::<1>(x) {
                        **out = -function!(csc, arg).pow(Atom::num(2));
                    }
                })
                .with_series_function(move |args| {
                    let [arg] = args else { return None; };
                    let point = arg.coefficient(0.into())?;
                    if !is_cot_csc_pole(point.as_view()) {
                        return None;
                    }
                    let delta = arg.to_atom() - &point;
                    Some((Atom::num(1) / &delta, &delta / function!(tan, delta)))
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("cot", "tan", "x", true))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, |z, _| z.tan().inv())
                    })
                    .register(|args: &[Float]| unary_eval_real(args, |x| x.tan().inv()))
                    .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.tan().recip()))
                    .register(|args: &[Complex<f64>]| unary_eval_complex_real_f64(args, |z| z.tan().inv()))
                    .register(|args: &[ErrorPropagatingFloat<f64>]| {
                        unary_eval_real(args, |x| x.tan().inv())
                    })
                    .register(|args: &[ErrorPropagatingFloat<Float>]| {
                        unary_eval_real(args, |x| x.tan().inv())
                    }),
                )
            },
            "sec";;
            |symbols, b| {
                let tan = symbols[0];
                let sec = symbols[2];
                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::one());
                            return;
                        }
                        let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.cos().inv());
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0 && let Some([arg]) = function_arguments::<1>(x) {
                        **out = function!(sec, arg) * function!(tan, arg);
                    }
                })
                .with_series_function(move |args| {
                    let [arg] = args else { return None; };
                    let point = arg.coefficient(0.into())?;
                    let residue = sec_residue(point.as_view())?;
                    let delta = arg.to_atom() - &point;
                    Some((
                        Atom::num(1) / &delta,
                        residue * &delta / function!(State::SIN, delta),
                    ))
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("sec", "cos", "x", true))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, |z, _| z.cos().inv())
                    })
                    .register(|args: &[Float]| unary_eval_real(args, |x| x.cos().inv()))
                    .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.cos().recip()))
                    .register(|args: &[Complex<f64>]| unary_eval_complex_real_f64(args, |z| z.cos().inv()))
                    .register(|args: &[ErrorPropagatingFloat<f64>]| {
                        unary_eval_real(args, |x| x.cos().inv())
                    })
                    .register(|args: &[ErrorPropagatingFloat<Float>]| {
                        unary_eval_real(args, |x| x.cos().inv())
                    }),
                )
            },
            "csc";;
            |symbols, b| {
                let cot = symbols[1];
                let csc = symbols[3];
                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::complex_infinity());
                            return;
                        }
                        let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.sin().inv());
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0 && let Some([arg]) = function_arguments::<1>(x) {
                        **out = -function!(csc, arg) * function!(cot, arg);
                    }
                })
                .with_series_function(move |args| {
                    let [arg] = args else { return None; };
                    let point = arg.coefficient(0.into())?;
                    let residue = csc_residue(point.as_view())?;
                    let delta = arg.to_atom() - &point;
                    Some((
                        Atom::num(1) / &delta,
                        residue * &delta / function!(State::SIN, delta),
                    ))
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("csc", "sin", "x", true))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, |z, _| z.sin().inv())
                    })
                    .register(|args: &[Float]| unary_eval_real(args, |x| x.sin().inv()))
                    .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.sin().recip()))
                    .register(|args: &[Complex<f64>]| unary_eval_complex_real_f64(args, |z| z.sin().inv()))
                    .register(|args: &[ErrorPropagatingFloat<f64>]| {
                        unary_eval_real(args, |x| x.sin().inv())
                    })
                    .register(|args: &[ErrorPropagatingFloat<Float>]| {
                        unary_eval_real(args, |x| x.sin().inv())
                    }),
                )
            },
            "sinh";;
            |symbols, b| {
                let cosh = symbols[5];
                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::zero());
                            return;
                        }
                        let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.sinh());
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0 && let Some([arg]) = function_arguments::<1>(x) {
                        **out = function!(cosh, arg);
                    }
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("sinh", "sinh", "x", false))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, |z, _| z.sinh())
                    })
                    .register(|args: &[Float]| unary_eval_real(args, |x| x.sinh()))
                    .register(|args: &[f64]| unary_eval_real_f64(args, f64::sinh))
                    .register(|args: &[Complex<f64>]| unary_eval_complex_real_f64(args, |z| z.sinh()))
                    .register(|args: &[ErrorPropagatingFloat<f64>]| {
                        unary_eval_real(args, |x| x.sinh())
                    })
                    .register(|args: &[ErrorPropagatingFloat<Float>]| {
                        unary_eval_real(args, |x| x.sinh())
                    }),
                )
            },
            "cosh";;
            |symbols, b| {
                let sinh = symbols[4];
                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::one());
                            return;
                        }
                        let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.cosh());
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0 && let Some([arg]) = function_arguments::<1>(x) {
                        **out = function!(sinh, arg);
                    }
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("cosh", "cosh", "x", false))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, |z, _| z.cosh())
                    })
                    .register(|args: &[Float]| unary_eval_real(args, |x| x.cosh()))
                    .register(|args: &[f64]| unary_eval_real_f64(args, f64::cosh))
                    .register(|args: &[Complex<f64>]| unary_eval_complex_real_f64(args, |z| z.cosh()))
                    .register(|args: &[ErrorPropagatingFloat<f64>]| {
                        unary_eval_real(args, |x| x.cosh())
                    })
                    .register(|args: &[ErrorPropagatingFloat<Float>]| {
                        unary_eval_real(args, |x| x.cosh())
                    }),
                )
            },
            "tanh";;
            |symbols, b| {
                let tanh = symbols[6];
                let sech = symbols[8];
                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::zero());
                            return;
                        }
                        let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.tanh());
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0 && let Some([arg]) = function_arguments::<1>(x) {
                        **out = function!(sech, arg).pow(Atom::num(2));
                    }
                })
                .with_series_function(move |args| {
                    let [arg] = args else { return None; };
                    let point = arg.coefficient(0.into())?;
                    if !is_tanh_sech_pole(point.as_view()) {
                        return None;
                    }
                    let delta = arg.to_atom() - &point;
                    Some((Atom::num(1) / &delta, &delta / function!(tanh, delta)))
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("tanh", "tanh", "x", false))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, |z, _| z.tanh())
                    })
                    .register(|args: &[Float]| unary_eval_real(args, |x| x.tanh()))
                    .register(|args: &[f64]| unary_eval_real_f64(args, f64::tanh))
                    .register(|args: &[Complex<f64>]| unary_eval_complex_real_f64(args, |z| z.tanh()))
                    .register(|args: &[ErrorPropagatingFloat<f64>]| {
                        unary_eval_real(args, |x| x.tanh())
                    })
                    .register(|args: &[ErrorPropagatingFloat<Float>]| {
                        unary_eval_real(args, |x| x.tanh())
                    }),
                )
            },
            "coth";;
            |symbols, b| {
                let tanh = symbols[6];
                let csch = symbols[9];
                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::complex_infinity());
                            return;
                        }
                        let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.tanh().inv());
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0 && let Some([arg]) = function_arguments::<1>(x) {
                        **out = -function!(csch, arg).pow(Atom::num(2));
                    }
                })
                .with_series_function(move |args| {
                    let [arg] = args else { return None; };
                    let point = arg.coefficient(0.into())?;
                    if !is_coth_csch_pole(point.as_view()) {
                        return None;
                    }
                    let delta = arg.to_atom() - &point;
                    Some((Atom::num(1) / &delta, &delta / function!(tanh, delta)))
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("coth", "tanh", "x", true))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, |z, _| z.tanh().inv())
                    })
                    .register(|args: &[Float]| unary_eval_real(args, |x| x.tanh().inv()))
                    .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.tanh().recip()))
                    .register(|args: &[Complex<f64>]| unary_eval_complex_real_f64(args, |z| z.tanh().inv()))
                    .register(|args: &[ErrorPropagatingFloat<f64>]| {
                        unary_eval_real(args, |x| x.tanh().inv())
                    })
                    .register(|args: &[ErrorPropagatingFloat<Float>]| {
                        unary_eval_real(args, |x| x.tanh().inv())
                    }),
                )
            },
            "sech";;
            |symbols, b| {
                let sinh = symbols[4];
                let sech = symbols[8];
                let tanh = symbols[6];
                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::one());
                            return;
                        }
                        let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.sech());
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0 && let Some([arg]) = function_arguments::<1>(x) {
                        **out = -function!(sech, arg) * function!(tanh, arg);
                    }
                })
                .with_series_function(move |args| {
                    let [arg] = args else { return None; };
                    let point = arg.coefficient(0.into())?;
                    let residue = sech_residue(point.as_view())?;
                    let delta = arg.to_atom() - &point;
                    Some((Atom::num(1) / &delta, residue * &delta / function!(sinh, delta)))
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("sech", "cosh", "x", true))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, |z, _| z.sech())
                    })
                    .register(|args: &[Float]| unary_eval_real(args, |x| x.sech()))
                    .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.sech()))
                    .register(|args: &[Complex<f64>]| unary_eval_complex_real_f64(args, |z| z.sech()))
                    .register(|args: &[ErrorPropagatingFloat<f64>]| {
                        unary_eval_real(args, |x| x.sech())
                    })
                    .register(|args: &[ErrorPropagatingFloat<Float>]| {
                        unary_eval_real(args, |x| x.sech())
                    }),
                )
            },
            "csch";;
            |symbols, b| {
                let sinh = symbols[4];
                let csch = symbols[9];
                let coth = symbols[7];
                b.with_normalization_function(|x, out| {
                    if let Some([arg]) = function_arguments::<1>(x) {
                        if arg.is_zero() {
                            out.to_num(Coefficient::complex_infinity());
                            return;
                        }
                        let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.csch());
                    }
                })
                .with_derivative_function(move |x, i, out| {
                    if i == 0 && let Some([arg]) = function_arguments::<1>(x) {
                        **out = -function!(csch, arg) * function!(coth, arg);
                    }
                })
                .with_series_function(move |args| {
                    let [arg] = args else { return None; };
                    let point = arg.coefficient(0.into())?;
                    let residue = csch_residue(point.as_view())?;
                    let delta = arg.to_atom() - &point;
                    Some((Atom::num(1) / &delta, residue * &delta / function!(sinh, delta)))
                })
                .with_evaluation_info(
                    EvaluationInfo::new()
                    .with_cpp(cpp::unary("csch", "sinh", "x", true))
                    .register(|args: &[Complex<Float>]| {
                        unary_eval_complex_float(args, |z, _| z.csch())
                    })
                    .register(|args: &[Float]| unary_eval_real(args, |x| x.csch()))
                    .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.csch()))
                    .register(|args: &[Complex<f64>]| unary_eval_complex_real_f64(args, |z| z.csch()))
                    .register(|args: &[ErrorPropagatingFloat<f64>]| {
                        unary_eval_real(args, |x| x.csch())
                    })
                    .register(|args: &[ErrorPropagatingFloat<Float>]| {
                        unary_eval_real(args, |x| x.csch())
                    }),
                )
            }
        );

        let csch = symbols.pop().unwrap();
        let sech = symbols.pop().unwrap();
        let coth = symbols.pop().unwrap();
        let tanh = symbols.pop().unwrap();
        let cosh = symbols.pop().unwrap();
        let sinh = symbols.pop().unwrap();
        let csc = symbols.pop().unwrap();
        let sec = symbols.pop().unwrap();
        let cot = symbols.pop().unwrap();
        let tan = symbols.pop().unwrap();

        let asin = symbol!(
            "asin",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    if arg.is_zero() {
                        out.to_num(Coefficient::zero());
                        return;
                    }
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.asin());
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let arg = arg.to_owned();
                    **out =
                        Atom::num(1) / function!(State::SQRT, Atom::num(1) - arg.pow(Atom::num(2)));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("asin", "asin", "x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, _| z.asin())
                })
                .register(|args: &[Float]| unary_eval_real(args, |x| x.asin()))
                .register(|args: &[f64]| unary_eval_real_f64(args, f64::asin))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| z.asin())
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| x.asin())
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| x.asin())
                })
        );

        let acos = symbol!(
            "acos",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    if arg.is_one() {
                        out.to_num(Coefficient::zero());
                        return;
                    }
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.acos());
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let arg = arg.to_owned();
                    **out = -Atom::num(1)
                        / function!(State::SQRT, Atom::num(1) - arg.pow(Atom::num(2)));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("acos", "acos", "x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, _| z.acos())
                })
                .register(|args: &[Float]| unary_eval_real(args, |x| x.acos()))
                .register(|args: &[f64]| unary_eval_real_f64(args, f64::acos))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| z.acos())
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| x.acos())
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| x.acos())
                })
        );

        let atan = symbol!(
            "atan",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    if arg.is_zero() {
                        out.to_num(Coefficient::zero());
                        return;
                    }
                    let _ = maybe_eval_unary_float_in_norm(arg, out, atan_numeric_eval);
                }
                if let Some([x, y]) = function_arguments::<2>(x)
                    && maybe_eval_binary_float_in_norm(x, y, out, |x, y, prec| {
                        Some(atan2_numeric_eval(x, y, prec))
                    })
                {}
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let arg = arg.to_owned();
                    **out = Atom::num(1) / (Atom::num(1) + arg.pow(Atom::num(2)));
                }
                if let Some([x, y]) = function_arguments::<2>(x) {
                    let x = x.to_owned();
                    let y = y.to_owned();
                    let denom = x.clone().pow(Atom::num(2)) + y.clone().pow(Atom::num(2));
                    if i == 0 {
                        **out = -y / denom;
                    } else if i == 1 {
                        **out = x / denom;
                    }
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::atan())
                .register(|args: &[Complex<Float>]| match args {
                    [z] => atan_numeric_eval(z, z.re.prec().max(z.im.prec())),
                    [x, y] => atan2_numeric_eval(
                        x,
                        y,
                        y.re.prec()
                            .max(y.im.prec())
                            .max(x.re.prec().max(x.im.prec())),
                    ),
                    _ =>
                        Complex::new(Float::with_val(53, f64::NAN), Float::with_val(53, f64::NAN),),
                })
                .register(|args: &[Float]| atan_eval_real(args))
                .register(|args: &[f64]| match args {
                    [z] => z.atan(),
                    [x, y] => (*y).atan2(*x),
                    _ => f64::NAN,
                })
                .register(|args: &[Complex<f64>]| match args {
                    [z] => atan_eval_complex_f64(*z),
                    [x, y] => {
                        if y.im == 0.0 && x.im == 0.0 {
                            Complex::new(y.re.atan2(x.re), 0.0)
                        } else {
                            y.atan2(x)
                        }
                    }
                    _ => Complex::new(f64::NAN, f64::NAN),
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| atan_eval_real(args))
                .register(|args: &[ErrorPropagatingFloat<Float>]| atan_eval_real(args))
        );

        let acot = symbol!(
            "acot",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, prec| {
                        atan_numeric_eval(&z.inv(), prec)
                    });
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let arg = arg.to_owned();
                    **out = -Atom::num(1) / (Atom::num(1) + arg.pow(Atom::num(2)));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("acot", "atan", "T(1) / x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, prec| atan_numeric_eval(&z.inv(), prec))
                })
                .register(|args: &[Float]| {
                    unary_eval_real(args, |x| {
                        let inv = x.inv();
                        inv.atan2(&inv.one())
                    })
                })
                .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.recip().atan()))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| atan_eval_complex_f64(z.inv()))
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| {
                        let inv = x.inv();
                        inv.atan2(&inv.one())
                    })
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| {
                        let inv = x.inv();
                        inv.atan2(&inv.one())
                    })
                })
        );

        let asec = symbol!(
            "asec",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    if arg.is_one() {
                        out.to_num(Coefficient::zero());
                        return;
                    }
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.inv().acos());
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let inv = Atom::num(1) / arg;
                    **out = Atom::num(1)
                        / (arg.pow(Atom::num(2))
                            * function!(State::SQRT, Atom::num(1) - inv.pow(Atom::num(2))));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("asec", "acos", "T(1) / x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, _| z.inv().acos())
                })
                .register(|args: &[Float]| unary_eval_real(args, |x| x.inv().acos()))
                .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.recip().acos()))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| z.inv().acos())
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| x.inv().acos())
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| x.inv().acos())
                })
        );

        let acsc = symbol!(
            "acsc",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.inv().asin());
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let inv = Atom::num(1) / arg;
                    **out = -Atom::num(1)
                        / (arg.pow(Atom::num(2))
                            * function!(State::SQRT, Atom::num(1) - inv.pow(Atom::num(2))));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("acsc", "asin", "T(1) / x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, _| z.inv().asin())
                })
                .register(|args: &[Float]| unary_eval_real(args, |x| x.inv().asin()))
                .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.recip().asin()))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| z.inv().asin())
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| x.inv().asin())
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| x.inv().asin())
                })
        );

        let asinh = symbol!(
            "asinh",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    if arg.is_zero() {
                        out.to_num(Coefficient::zero());
                        return;
                    }
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.asinh());
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let arg = arg.to_owned();
                    **out =
                        Atom::num(1) / function!(State::SQRT, Atom::num(1) + arg.pow(Atom::num(2)));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("asinh", "asinh", "x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, _| z.asinh())
                })
                .register(|args: &[Float]| unary_eval_real(args, |x| x.asinh()))
                .register(|args: &[f64]| unary_eval_real_f64(args, f64::asinh))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| z.asinh())
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| x.asinh())
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| x.asinh())
                })
        );

        let acosh = symbol!(
            "acosh",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    if arg.is_one() {
                        out.to_num(Coefficient::zero());
                        return;
                    }
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.acosh());
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let arg = arg.to_owned();
                    **out = Atom::num(1)
                        / (function!(State::SQRT, &arg - Atom::num(1))
                            * function!(State::SQRT, arg + Atom::num(1)));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("acosh", "acosh", "x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, _| z.acosh())
                })
                .register(|args: &[Float]| unary_eval_real(args, |x| x.acosh()))
                .register(|args: &[f64]| unary_eval_real_f64(args, f64::acosh))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| z.acosh())
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| x.acosh())
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| x.acosh())
                })
        );

        let atanh = symbol!(
            "atanh",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    if arg.is_zero() {
                        out.to_num(Coefficient::zero());
                        return;
                    }
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.atanh());
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let arg = arg.to_owned();
                    **out = Atom::num(1) / (Atom::num(1) - arg.pow(Atom::num(2)));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("atanh", "atanh", "x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, _| z.atanh())
                })
                .register(|args: &[Float]| unary_eval_real(args, |x| x.atanh()))
                .register(|args: &[f64]| unary_eval_real_f64(args, f64::atanh))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| z.atanh())
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| x.atanh())
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| x.atanh())
                })
        );

        let acoth = symbol!(
            "acoth",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.inv().atanh());
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let arg = arg.to_owned();
                    **out = Atom::num(1) / (Atom::num(1) - arg.pow(Atom::num(2)));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("acoth", "atanh", "T(1) / x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, _| z.inv().atanh())
                })
                .register(|args: &[Float]| unary_eval_real(args, |x| x.inv().atanh()))
                .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.recip().atanh()))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| z.inv().atanh())
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| x.inv().atanh())
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| x.inv().atanh())
                })
        );

        let asech = symbol!(
            "asech",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    if arg.is_one() {
                        out.to_num(Coefficient::zero());
                        return;
                    }
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.inv().acosh());
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let arg = arg.to_owned();
                    let inv = Atom::num(1) / &arg;
                    **out = -Atom::num(1)
                        / (arg.pow(Atom::num(2))
                            * function!(State::SQRT, &inv - Atom::num(1))
                            * function!(State::SQRT, inv + Atom::num(1)));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("asech", "acosh", "T(1) / x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, _| z.inv().acosh())
                })
                .register(|args: &[Float]| unary_eval_real(args, |x| x.inv().acosh()))
                .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.recip().acosh()))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| z.inv().acosh())
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| x.inv().acosh())
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| x.inv().acosh())
                })
        );

        let acsch = symbol!(
            "acsch",
            norm = |x, out| {
                if let Some([arg]) = function_arguments::<1>(x) {
                    let _ = maybe_eval_unary_float_in_norm(arg, out, |z, _| z.inv().asinh());
                }
            },
            der = move |x, i, out| {
                if i == 0
                    && let Some([arg]) = function_arguments::<1>(x)
                {
                    let arg = arg.to_owned();
                    let inv = Atom::num(1) / &arg;
                    **out = -Atom::num(1)
                        / (arg.pow(Atom::num(2))
                            * function!(State::SQRT, Atom::num(1) + inv.pow(Atom::num(2))));
                }
            },
            eval = EvaluationInfo::new()
                .with_cpp(cpp::unary("acsch", "asinh", "T(1) / x", false))
                .register(|args: &[Complex<Float>]| {
                    unary_eval_complex_float(args, |z, _| z.inv().asinh())
                })
                .register(|args: &[Float]| unary_eval_real(args, |x| x.inv().asinh()))
                .register(|args: &[f64]| unary_eval_real_f64(args, |x| x.recip().asinh()))
                .register(|args: &[Complex<f64>]| {
                    unary_eval_complex_real_f64(args, |z| z.inv().asinh())
                })
                .register(|args: &[ErrorPropagatingFloat<f64>]| {
                    unary_eval_real(args, |x| x.inv().asinh())
                })
                .register(|args: &[ErrorPropagatingFloat<Float>]| {
                    unary_eval_real(args, |x| x.inv().asinh())
                })
        );

        Self {
            tan,
            cot,
            sec,
            csc,
            asin,
            acos,
            atan,
            acot,
            asec,
            acsc,
            sinh,
            cosh,
            tanh,
            coth,
            sech,
            csch,
            asinh,
            acosh,
            atanh,
            acoth,
            asech,
            acsch,
        }
    }
}

impl BesselSymbols {
    fn new() -> Self {
        let bessel_j = symbol!(
            "bessel_j",
            norm = |x, out| {
                if let Some([nu, z]) = function_arguments::<2>(x) {
                    if z.is_zero()
                        && let Some(n) = atom_to_integer(nu)
                    {
                        if n == 0 {
                            out.to_num(Coefficient::one());
                        } else {
                            out.to_num(Coefficient::zero());
                        }
                        return;
                    }
                    let _ = maybe_eval_binary_float_in_norm(nu, z, out, bessel_j_numeric_eval);
                }
            },
            der = move |x, i, out| {
                if i == 1
                    && let Some([nu, z]) = function_arguments::<2>(x)
                {
                    let symbol = x.as_fun_view().unwrap().get_symbol();
                    let nu = nu.to_owned();
                    **out = (function!(symbol, nu.clone() - Atom::num(1), z)
                        - function!(symbol, nu + Atom::num(1), z))
                        / Atom::num(2);
                }
            },
            eval = EvaluationInfo::new()
                .with_tags(1)
                .with_cpp_generator(|name, tags| cpp::bessel("cyl_bessel_j", name, tags))
                .register_tagged(|tags| {
                    let tags = tags.iter().map(|x| x.to_owned()).collect::<Vec<_>>();
                    Box::new(move |args: &[Complex<Float>]| {
                        tagged_unary_eval_complex_float(
                            "bessel_j",
                            &tags,
                            args,
                            bessel_j_numeric_eval,
                        )
                    })
                })
                .register_tagged(|tags| {
                    let tags = tags.iter().map(|x| x.to_owned()).collect::<Vec<_>>();
                    Box::new(move |args: &[Float]| {
                        let prec = args.first().map(|x| x.prec()).unwrap_or(53);
                        let tag_views = tags.iter().map(|x| x.as_view()).collect::<Vec<_>>();
                        let Ok(order) = complex_float_tag("bessel_j", &tag_views, prec) else {
                            return Float::with_val(53, f64::NAN);
                        };
                        let [arg] = args else {
                            return Float::with_val(53, f64::NAN);
                        };
                        bessel_j_numeric_eval(
                            &order,
                            &Complex::new(arg.clone(), Float::new(prec)),
                            prec,
                        )
                        .map(|z| z.re)
                        .unwrap_or_else(|| Float::with_val(53, f64::NAN))
                    })
                })
                .register_tagged(|tags| {
                    let order = complex_float_tag("bessel_j", tags, 53).ok();
                    Box::new(move |args: &[f64]| {
                        tagged_unary_eval_real_f64(order.clone(), args, bessel_j_numeric_eval)
                    })
                })
                .register_tagged(|tags| {
                    let order = complex_float_tag("bessel_j", tags, 53).ok();
                    Box::new(move |args: &[Complex<f64>]| {
                        tagged_unary_eval_complex_f64(order.clone(), args, bessel_j_numeric_eval)
                    })
                })
        );

        let bessel_y = symbol!(
            "bessel_y",
            norm = |x, out| {
                if let Some([nu, z]) = function_arguments::<2>(x) {
                    if z.is_zero() {
                        out.to_num(Coefficient::complex_infinity());
                        return;
                    }
                    let _ = maybe_eval_binary_float_in_norm(nu, z, out, bessel_y_numeric_eval);
                }
            },
            der = move |x, i, out| {
                if i == 1
                    && let Some([nu, z]) = function_arguments::<2>(x)
                {
                    let symbol = x.as_fun_view().unwrap().get_symbol();
                    let nu = nu.to_owned();
                    **out = (function!(symbol, nu.clone() - Atom::num(1), z)
                        - function!(symbol, nu + Atom::num(1), z))
                        / Atom::num(2);
                }
            },
            eval = EvaluationInfo::new()
                .with_tags(1)
                .with_cpp_generator(|name, tags| cpp::bessel("cyl_neumann", name, tags))
                .register_tagged(|tags| {
                    let tags = tags.iter().map(|x| x.to_owned()).collect::<Vec<_>>();
                    Box::new(move |args: &[Complex<Float>]| {
                        tagged_unary_eval_complex_float(
                            "bessel_y",
                            &tags,
                            args,
                            bessel_y_numeric_eval,
                        )
                    })
                })
                .register_tagged(|tags| {
                    let tags = tags.iter().map(|x| x.to_owned()).collect::<Vec<_>>();
                    Box::new(move |args: &[Float]| {
                        let prec = args.first().map(|x| x.prec()).unwrap_or(53);
                        let tag_views = tags.iter().map(|x| x.as_view()).collect::<Vec<_>>();
                        let Ok(order) = complex_float_tag("bessel_y", &tag_views, prec) else {
                            return Float::with_val(53, f64::NAN);
                        };
                        let [arg] = args else {
                            return Float::with_val(53, f64::NAN);
                        };
                        bessel_y_numeric_eval(
                            &order,
                            &Complex::new(arg.clone(), Float::new(prec)),
                            prec,
                        )
                        .map(|z| z.re)
                        .unwrap_or_else(|| Float::with_val(53, f64::NAN))
                    })
                })
                .register_tagged(|tags| {
                    let order = complex_float_tag("bessel_y", tags, 53).ok();
                    Box::new(move |args: &[f64]| {
                        tagged_unary_eval_real_f64(order.clone(), args, bessel_y_numeric_eval)
                    })
                })
                .register_tagged(|tags| {
                    let order = complex_float_tag("bessel_y", tags, 53).ok();
                    Box::new(move |args: &[Complex<f64>]| {
                        tagged_unary_eval_complex_f64(order.clone(), args, bessel_y_numeric_eval)
                    })
                })
        );

        let bessel_i = symbol!(
            "bessel_i",
            norm = |x, out| {
                if let Some([nu, z]) = function_arguments::<2>(x) {
                    if z.is_zero()
                        && let Some(n) = atom_to_integer(nu)
                        && n >= 0
                    {
                        if n == 0 {
                            out.to_num(Coefficient::one());
                        } else {
                            out.to_num(Coefficient::zero());
                        }
                        return;
                    }
                    let _ = maybe_eval_binary_float_in_norm(nu, z, out, bessel_i_numeric_eval);
                }
            },
            der = move |x, i, out| {
                if i == 1
                    && let Some([nu, z]) = function_arguments::<2>(x)
                {
                    let symbol = x.as_fun_view().unwrap().get_symbol();
                    let nu = nu.to_owned();
                    **out = (function!(symbol, nu.clone() - Atom::num(1), z)
                        + function!(symbol, nu + Atom::num(1), z))
                        / Atom::num(2);
                }
            },
            eval = EvaluationInfo::new()
                .with_tags(1)
                .with_cpp_generator(|name, tags| cpp::bessel("cyl_bessel_i", name, tags))
                .register_tagged(|tags| {
                    let tags = tags.iter().map(|x| x.to_owned()).collect::<Vec<_>>();
                    Box::new(move |args: &[Complex<Float>]| {
                        tagged_unary_eval_complex_float(
                            "bessel_i",
                            &tags,
                            args,
                            bessel_i_numeric_eval,
                        )
                    })
                })
                .register_tagged(|tags| {
                    let tags = tags.iter().map(|x| x.to_owned()).collect::<Vec<_>>();
                    Box::new(move |args: &[Float]| {
                        let prec = args.first().map(|x| x.prec()).unwrap_or(53);
                        let tag_views = tags.iter().map(|x| x.as_view()).collect::<Vec<_>>();
                        let Ok(order) = complex_float_tag("bessel_i", &tag_views, prec) else {
                            return Float::with_val(53, f64::NAN);
                        };
                        let [arg] = args else {
                            return Float::with_val(53, f64::NAN);
                        };
                        bessel_i_numeric_eval(
                            &order,
                            &Complex::new(arg.clone(), Float::new(prec)),
                            prec,
                        )
                        .map(|z| z.re)
                        .unwrap_or_else(|| Float::with_val(53, f64::NAN))
                    })
                })
                .register_tagged(|tags| {
                    let order = complex_float_tag("bessel_i", tags, 53).ok();
                    Box::new(move |args: &[f64]| {
                        tagged_unary_eval_real_f64(order.clone(), args, bessel_i_numeric_eval)
                    })
                })
                .register_tagged(|tags| {
                    let order = complex_float_tag("bessel_i", tags, 53).ok();
                    Box::new(move |args: &[Complex<f64>]| {
                        tagged_unary_eval_complex_f64(order.clone(), args, bessel_i_numeric_eval)
                    })
                })
        );

        let bessel_k = symbol!(
            "bessel_k",
            norm = |x, out| {
                if let Some([nu, z]) = function_arguments::<2>(x) {
                    if z.is_zero() {
                        out.to_num(Coefficient::complex_infinity());
                        return;
                    }
                    let _ = maybe_eval_binary_float_in_norm(nu, z, out, bessel_k_numeric_eval);
                }
            },
            der = move |x, i, out| {
                if i == 1
                    && let Some([nu, z]) = function_arguments::<2>(x)
                {
                    let symbol = x.as_fun_view().unwrap().get_symbol();
                    let nu = nu.to_owned();
                    **out = -(function!(symbol, nu.clone() - Atom::num(1), z)
                        + function!(symbol, nu + Atom::num(1), z))
                        / Atom::num(2);
                }
            },
            eval = EvaluationInfo::new()
                .with_tags(1)
                .with_cpp_generator(|name, tags| cpp::bessel("cyl_bessel_k", name, tags))
                .register_tagged(|tags| {
                    let tags = tags.iter().map(|x| x.to_owned()).collect::<Vec<_>>();
                    Box::new(move |args: &[Complex<Float>]| {
                        tagged_unary_eval_complex_float(
                            "bessel_k",
                            &tags,
                            args,
                            bessel_k_numeric_eval,
                        )
                    })
                })
                .register_tagged(|tags| {
                    let tags = tags.iter().map(|x| x.to_owned()).collect::<Vec<_>>();
                    Box::new(move |args: &[Float]| {
                        let prec = args.first().map(|x| x.prec()).unwrap_or(53);
                        let tag_views = tags.iter().map(|x| x.as_view()).collect::<Vec<_>>();
                        let Ok(order) = complex_float_tag("bessel_k", &tag_views, prec) else {
                            return Float::with_val(53, f64::NAN);
                        };
                        let [arg] = args else {
                            return Float::with_val(53, f64::NAN);
                        };
                        bessel_k_numeric_eval(
                            &order,
                            &Complex::new(arg.clone(), Float::new(prec)),
                            prec,
                        )
                        .map(|z| z.re)
                        .unwrap_or_else(|| Float::with_val(53, f64::NAN))
                    })
                })
                .register_tagged(|tags| {
                    let order = complex_float_tag("bessel_k", tags, 53).ok();
                    Box::new(move |args: &[f64]| {
                        tagged_unary_eval_real_f64(order.clone(), args, bessel_k_numeric_eval)
                    })
                })
                .register_tagged(|tags| {
                    let order = complex_float_tag("bessel_k", tags, 53).ok();
                    Box::new(move |args: &[Complex<f64>]| {
                        tagged_unary_eval_complex_f64(order.clone(), args, bessel_k_numeric_eval)
                    })
                })
        );

        Self {
            bessel_j,
            bessel_y,
            bessel_i,
            bessel_k,
        }
    }
}

#[cfg(not(doctest))]
crate::_inventory::submit! {
    StateInitializer::new("symbolica::special_functions", || {
        let _ = GeometricSymbols::new();
        let _ = SpecialSymbols::new();
        let _ = BesselSymbols::new();
    }, &["symbolica"])
}

/// Return the built-in Euler gamma function symbol `gamma`.
///
/// `gamma(z)` is meromorphic with simple poles at the non-positive integers and no branch cuts.
pub fn gamma() -> Symbol {
    SPECIALS.gamma
}

/// Return the built-in error function symbol `erf`.
///
/// `erf(z)` is entire and odd, with derivative `2 exp(-z^2) / sqrt(pi)`.
pub fn erf() -> Symbol {
    SPECIALS.erf
}

/// Return the built-in Euler-Mascheroni constant symbol `euler_gamma`.
///
/// This is the constant `gamma_E`, approximately `0.57721`, used in expansions of `gamma`,
/// `polygamma`, and related special functions.
pub fn euler_gamma() -> Symbol {
    SPECIALS.euler_gamma
}

/// Return the built-in polygamma function symbol `polygamma`.
///
/// The first argument is the non-negative integer order. For fixed order, `polygamma(n, z)` is
/// meromorphic in `z` with poles at the non-positive integers and no branch cuts.
pub fn polygamma() -> Symbol {
    SPECIALS.polygamma
}

/// Return the built-in polylogarithm symbol `polylog`.
///
/// `polylog(s, z)` uses the principal branch in `z`; for generic `s` it has the standard branch cut
/// along the real interval `[1, +infinity)`.
pub fn polylog() -> Symbol {
    SPECIALS.polylog
}

/// Return the built-in algebraic root symbol `root`.
///
/// `root(poly, n)` represents the zero-based `n`-th root of a univariate
/// polynomial with exact algebraic coefficients, counting multiplicity.
/// Real roots come first in increasing order; nonreal roots follow, ordered
/// lexicographically by `(re, im)`.
/// The three-argument form `root(poly, x, n)` explicitly selects the symbol
/// `x` as the polynomial variable; all other symbols in `poly` are treated as
/// parameters. For example, `root(x^2-a-1, x, 0)` represents the first root in
/// `x`.
/// The index selects a root after parameter specialization, rather than an
/// analytic branch continued across parameter values. Over a CAD cell where
/// the polynomial is delineable, each distinct real-root position identifies
/// a continuous section. Sections count distinct roots, not multiplicities.
/// Parametric radical simplifications are made only when they preserve the
/// specialized root selection.
///
/// In the two-argument form the polynomial variable is inferred only when
/// there is a single indeterminate, or when `root_var` (or conventional `z`)
/// occurs. An expression such as `root(x^2-a, 0)` is left unchanged because
/// either symbol could be the polynomial variable; use `root(x^2-a, x, 0)` to
/// resolve the ambiguity.
///
/// Algebraic coefficient fields are collapsed to a simple extension over `Q`
/// when the root is normalized.
pub fn root() -> Symbol {
    SPECIALS.root
}

/// Return the built-in variable used as the polynomial variable in `root`.
pub fn root_var() -> Symbol {
    SPECIALS.root_var
}

/// Return the built-in Riemann zeta function symbol `zeta`.
///
/// `zeta(s)` is meromorphic with a simple pole at `s = 1` and no branch cuts.
pub fn zeta() -> Symbol {
    SPECIALS.zeta
}

/// Return the built-in tangent function symbol `tan`.
///
/// `tan(z)` is meromorphic with simple poles at `pi/2 + k pi`.
pub fn tan() -> Symbol {
    GEOMETRICS.tan
}

/// Return the built-in cotangent function symbol `cot`.
///
/// `cot(z)` is meromorphic with simple poles at `k pi`.
pub fn cot() -> Symbol {
    GEOMETRICS.cot
}

/// Return the built-in secant function symbol `sec`.
///
/// `sec(z)` is meromorphic with simple poles at `pi/2 + k pi`.
pub fn sec() -> Symbol {
    GEOMETRICS.sec
}

/// Return the built-in cosecant function symbol `csc`.
///
/// `csc(z)` is meromorphic with simple poles at `k pi`.
pub fn csc() -> Symbol {
    GEOMETRICS.csc
}

/// Return the built-in inverse sine symbol `asin`.
///
/// `asin(z)` uses the principal branch with branch cuts on `(-infinity, -1]` and `[1, +infinity)`.
pub fn asin() -> Symbol {
    GEOMETRICS.asin
}

/// Return the built-in inverse cosine symbol `acos`.
///
/// `acos(z)` uses the principal branch with branch cuts on `(-infinity, -1]` and `[1, +infinity)`.
pub fn acos() -> Symbol {
    GEOMETRICS.acos
}

/// Return the built-in inverse tangent symbol `atan`.
///
/// `atan(z)` uses the principal branch with branch cuts on the imaginary axis:
/// `(-i infinity, -i]` and `[i, i infinity)`.
///
/// `atan(x, y)` is the quadrant-aware inverse tangent for real numeric inputs,
/// equivalent to `atan2(y, x)`.
pub fn atan() -> Symbol {
    GEOMETRICS.atan
}

/// Return the built-in inverse cotangent symbol `acot`.
///
/// `acot(z)` uses the principal branch with branch cuts on the imaginary axis:
/// `(-i infinity, -i]` and `[i, i infinity)`.
pub fn acot() -> Symbol {
    GEOMETRICS.acot
}

/// Return the built-in inverse secant symbol `asec`.
///
/// `asec(z)` uses the principal branch with branch cuts on `[-1, 1]`.
pub fn asec() -> Symbol {
    GEOMETRICS.asec
}

/// Return the built-in inverse cosecant symbol `acsc`.
///
/// `acsc(z)` uses the principal branch with branch cuts on `[-1, 1]`.
pub fn acsc() -> Symbol {
    GEOMETRICS.acsc
}

/// Return the built-in hyperbolic sine symbol `sinh`.
///
/// `sinh(z)` is entire.
pub fn sinh() -> Symbol {
    GEOMETRICS.sinh
}

/// Return the built-in hyperbolic cosine symbol `cosh`.
///
/// `cosh(z)` is entire.
pub fn cosh() -> Symbol {
    GEOMETRICS.cosh
}

/// Return the built-in hyperbolic tangent symbol `tanh`.
///
/// `tanh(z)` is meromorphic with simple poles at `i (pi/2 + k pi)`.
pub fn tanh() -> Symbol {
    GEOMETRICS.tanh
}

/// Return the built-in hyperbolic cotangent symbol `coth`.
///
/// `coth(z)` is meromorphic with simple poles at `i k pi`.
pub fn coth() -> Symbol {
    GEOMETRICS.coth
}

/// Return the built-in hyperbolic secant symbol `sech`.
///
/// `sech(z)` is meromorphic with simple poles at `i (pi/2 + k pi)`.
pub fn sech() -> Symbol {
    GEOMETRICS.sech
}

/// Return the built-in hyperbolic cosecant symbol `csch`.
///
/// `csch(z)` is meromorphic with simple poles at `i k pi`.
pub fn csch() -> Symbol {
    GEOMETRICS.csch
}

/// Return the built-in inverse hyperbolic sine symbol `asinh`.
///
/// `asinh(z)` uses the principal branch with branch cuts on the imaginary axis:
/// `(-i infinity, -i]` and `[i, i infinity)`.
pub fn asinh() -> Symbol {
    GEOMETRICS.asinh
}

/// Return the built-in inverse hyperbolic cosine symbol `acosh`.
///
/// `acosh(z)` uses the principal branch with branch cut `(-infinity, 1]`.
pub fn acosh() -> Symbol {
    GEOMETRICS.acosh
}

/// Return the built-in inverse hyperbolic tangent symbol `atanh`.
///
/// `atanh(z)` uses the principal branch with branch cuts on `(-infinity, -1]` and `[1, +infinity)`.
pub fn atanh() -> Symbol {
    GEOMETRICS.atanh
}

/// Return the built-in inverse hyperbolic cotangent symbol `acoth`.
///
/// `acoth(z)` uses the principal branch with branch cut `[-1, 1]`.
pub fn acoth() -> Symbol {
    GEOMETRICS.acoth
}

/// Return the built-in inverse hyperbolic secant symbol `asech`.
///
/// `asech(z)` uses the principal branch with branch cuts on `(-infinity, 0]` and `[1, +infinity)`.
pub fn asech() -> Symbol {
    GEOMETRICS.asech
}

/// Return the built-in inverse hyperbolic cosecant symbol `acsch`.
///
/// `acsch(z)` uses the principal branch with branch cuts on the imaginary interval `[-i, i]`.
pub fn acsch() -> Symbol {
    GEOMETRICS.acsch
}

/// Return the built-in cylindrical Bessel function of the first kind symbol `bessel_j`.
///
/// For fixed order `nu`, `bessel_j(nu, z)` is entire in `z`.
pub fn bessel_j() -> Symbol {
    BESSELS.bessel_j
}

/// Return the built-in cylindrical Bessel function of the second kind symbol `bessel_y`.
///
/// For fixed order `nu`, `bessel_y(nu, z)` uses the principal branch in `z` with branch cut
/// on `(-infinity, 0]`.
pub fn bessel_y() -> Symbol {
    BESSELS.bessel_y
}

/// Return the built-in modified Bessel function of the first kind symbol `bessel_i`.
///
/// For fixed order `nu`, `bessel_i(nu, z)` is entire in `z`.
pub fn bessel_i() -> Symbol {
    BESSELS.bessel_i
}

/// Return the built-in modified Bessel function of the second kind symbol `bessel_k`.
///
/// For fixed order `nu`, `bessel_k(nu, z)` uses the principal branch in `z` with branch cut
/// on `(-infinity, 0]`.
pub fn bessel_k() -> Symbol {
    BESSELS.bessel_k
}

macro_rules! unary_transcendental_methods {
    ($(
        $(#[$meta:meta])*
        $method:ident => $symbol:ident;
    )*) => {
        $(
            $(#[$meta])*
            fn $method(&self) -> Self::Output {
                unary_transcendental_function(self, crate::transcendental::$symbol())
            }
        )*
    };
}

/// Convenience methods for transcendental functions on expressions.
///
/// This extension trait is implemented for every type that implements [`AtomCore`].
/// Import it to write `x.atan()`, `x.gamma()`, `x.polylog(2)`, and similar method
/// calls without constructing the function symbols manually.
///
/// Functions already provided by [`AtomCore`] itself, such as `exp`, `log`, `sin`,
/// `cos`, and `sqrt`, are not repeated here to avoid method-resolution ambiguity.
pub trait TranscendentalFunctions: AtomCore {
    unary_transcendental_methods! {
        /// Take the tangent.
        tan => tan;
        /// Take the cotangent.
        cot => cot;
        /// Take the secant.
        sec => sec;
        /// Take the cosecant.
        csc => csc;
        /// Take the inverse sine.
        asin => asin;
        /// Take the inverse cosine.
        acos => acos;
        /// Take the inverse tangent.
        atan => atan;
        /// Take the inverse cotangent.
        acot => acot;
        /// Take the inverse secant.
        asec => asec;
        /// Take the inverse cosecant.
        acsc => acsc;
        /// Take the hyperbolic sine.
        sinh => sinh;
        /// Take the hyperbolic cosine.
        cosh => cosh;
        /// Take the hyperbolic tangent.
        tanh => tanh;
        /// Take the hyperbolic cotangent.
        coth => coth;
        /// Take the hyperbolic secant.
        sech => sech;
        /// Take the hyperbolic cosecant.
        csch => csch;
        /// Take the inverse hyperbolic sine.
        asinh => asinh;
        /// Take the inverse hyperbolic cosine.
        acosh => acosh;
        /// Take the inverse hyperbolic tangent.
        atanh => atanh;
        /// Take the inverse hyperbolic cotangent.
        acoth => acoth;
        /// Take the inverse hyperbolic secant.
        asech => asech;
        /// Take the inverse hyperbolic cosecant.
        acsch => acsch;
        /// Apply the gamma function.
        gamma => gamma;
        /// Apply the error function.
        erf => erf;
        /// Apply the Riemann zeta function.
        zeta => zeta;
    }

    /// Compute the quadrant-aware inverse tangent `atan(self, y)`.
    ///
    /// For real numeric inputs, this is equivalent to `atan2(y, self)`.
    fn atan2<'a, T: Into<AtomOrView<'a>>>(&self, y: T) -> Self::Output {
        receiver_first_transcendental_function(self, crate::transcendental::atan(), y)
    }

    /// Compute the polygamma function of order `n` at `self`.
    fn polygamma<'a, T: Into<AtomOrView<'a>>>(&self, n: T) -> Self::Output {
        receiver_last_transcendental_function(self, crate::transcendental::polygamma(), n)
    }

    /// Compute the polylogarithm of order `s` at `self`.
    fn polylog<'a, T: Into<AtomOrView<'a>>>(&self, s: T) -> Self::Output {
        receiver_last_transcendental_function(self, crate::transcendental::polylog(), s)
    }

    /// Compute the cylindrical Bessel function of the first kind of order `nu` at `self`.
    fn bessel_j<'a, T: Into<AtomOrView<'a>>>(&self, nu: T) -> Self::Output {
        receiver_last_transcendental_function(self, crate::transcendental::bessel_j(), nu)
    }

    /// Compute the cylindrical Bessel function of the second kind of order `nu` at `self`.
    fn bessel_y<'a, T: Into<AtomOrView<'a>>>(&self, nu: T) -> Self::Output {
        receiver_last_transcendental_function(self, crate::transcendental::bessel_y(), nu)
    }

    /// Compute the modified Bessel function of the first kind of order `nu` at `self`.
    fn bessel_i<'a, T: Into<AtomOrView<'a>>>(&self, nu: T) -> Self::Output {
        receiver_last_transcendental_function(self, crate::transcendental::bessel_i(), nu)
    }

    /// Compute the modified Bessel function of the second kind of order `nu` at `self`.
    fn bessel_k<'a, T: Into<AtomOrView<'a>>>(&self, nu: T) -> Self::Output {
        receiver_last_transcendental_function(self, crate::transcendental::bessel_k(), nu)
    }

    /// Construct the root function of `self` with index `index`.
    /// If the polynomial is not univariate, use [Self::root_in] to specify the main variable.
    fn root(&self, index: usize) -> Self::Output {
        self.atom_to_output(root().call((self.as_atom_view(), index)))
    }

    /// Construct the root function of `self` in variable `var` with index `index`.
    fn root_in(&self, var: Symbol, index: usize) -> Self::Output {
        self.atom_to_output(root().call((self.as_atom_view(), var, index)))
    }
}

impl<T: AtomCore> TranscendentalFunctions for T {}

fn unary_transcendental_function<T: AtomCore>(arg: &T, symbol: Symbol) -> T::Output {
    arg.atom_to_output(
        FunctionBuilder::new(symbol)
            .add_arg(arg.as_atom_view())
            .finish(),
    )
}

fn receiver_last_transcendental_function<'a, T, U>(
    arg: &T,
    symbol: Symbol,
    first_arg: U,
) -> T::Output
where
    T: AtomCore,
    U: Into<AtomOrView<'a>>,
{
    arg.atom_to_output(
        FunctionBuilder::new(symbol)
            .add_arg(first_arg)
            .add_arg(arg.as_atom_view())
            .finish(),
    )
}

fn receiver_first_transcendental_function<'a, T, U>(
    arg: &T,
    symbol: Symbol,
    second_arg: U,
) -> T::Output
where
    T: AtomCore,
    U: Into<AtomOrView<'a>>,
{
    arg.atom_to_output(
        FunctionBuilder::new(symbol)
            .add_arg(arg.as_atom_view())
            .add_arg(second_arg)
            .finish(),
    )
}

fn unary_eval_complex_float<F>(args: &[Complex<Float>], evaluator: F) -> Complex<Float>
where
    F: FnOnce(&Complex<Float>, u32) -> Complex<Float>,
{
    let prec = args
        .first()
        .map(|x| x.re.prec().max(x.im.prec()))
        .unwrap_or(53);
    let [arg] = args else {
        return Complex::new(Float::with_val(53, f64::NAN), Float::with_val(53, f64::NAN));
    };
    evaluator(arg, prec)
}

fn tagged_unary_eval_to_float(
    name: &str,
    tags: &[AtomView],
    args: &[Complex<Float>],
    prec: u32,
    evaluator: fn(&Complex<Float>, &Complex<Float>, u32) -> Option<Complex<Float>>,
) -> Result<Complex<Float>, String> {
    let order = complex_float_tag(name, tags, prec)?;
    let [arg] = args else {
        return Err(format!(
            "{name} expects exactly one argument after its order tag, got {}",
            args.len()
        ));
    };
    evaluator(&order, arg, prec).ok_or_else(|| format!("{name} numeric evaluation failed"))
}

fn tagged_unary_eval_complex_float(
    name: &str,
    tags: &[Atom],
    args: &[Complex<Float>],
    evaluator: fn(&Complex<Float>, &Complex<Float>, u32) -> Option<Complex<Float>>,
) -> Complex<Float> {
    let prec = args
        .first()
        .map(|x| x.re.prec().max(x.im.prec()))
        .unwrap_or(53);
    let tag_views = tags.iter().map(|x| x.as_view()).collect::<Vec<_>>();
    tagged_unary_eval_to_float(name, &tag_views, args, prec, evaluator).unwrap_or_else(|_| {
        Complex::new(Float::with_val(53, f64::NAN), Float::with_val(53, f64::NAN))
    })
}

fn nonnegative_integer_tag(name: &str, tags: &[AtomView]) -> Result<u32, String> {
    let [tag] = tags else {
        return Err(format!(
            "{name} expects exactly one order tag, got {}",
            tags.len()
        ));
    };

    let Some(order) = atom_to_integer(*tag) else {
        return Err(format!("{name} order tag must be an integer"));
    };

    if order < 0 || order > u32::MAX as i64 {
        return Err(format!("{name} order tag must be a nonnegative integer"));
    }

    Ok(order as u32)
}

fn complex_float_tag(name: &str, tags: &[AtomView], prec: u32) -> Result<Complex<Float>, String> {
    let [tag] = tags else {
        return Err(format!(
            "{name} expects exactly one order tag, got {}",
            tags.len()
        ));
    };

    if let Ok(value) = Complex::<Float>::try_from(*tag) {
        return Ok(value);
    }

    if let Ok(value) = Complex::<Rational>::try_from(*tag) {
        return Ok(Complex::new(
            value.re.to_multi_prec_float(prec),
            value.im.to_multi_prec_float(prec),
        ));
    }

    Err(format!("{name} order tag must be numeric"))
}

fn unary_eval_real_f64(args: &[f64], evaluator: fn(f64) -> f64) -> f64 {
    let [arg] = args else {
        return f64::NAN;
    };
    evaluator(*arg)
}

fn unary_eval_real<T: Real, F: FnOnce(&T) -> T>(args: &[T], evaluator: F) -> T {
    let [arg] = args else {
        panic!(
            "Wrong number of arguments for unary function: {}",
            args.len()
        );
    };
    evaluator(arg)
}

fn atan_eval_real<T: Real>(args: &[T]) -> T {
    match args {
        [z] => z.atan2(&z.one()),
        [x, y] => y.atan2(x),
        _ => panic!("Wrong number of arguments for atan: {}", args.len()),
    }
}

fn unary_eval_f64(args: &[f64], evaluator: fn(&Complex<Float>, u32) -> Complex<Float>) -> f64 {
    let [arg] = args else {
        return f64::NAN;
    };
    evaluator(&Complex::new(Float::with_val(53, *arg), Float::new(53)), 53)
        .re
        .to_f64()
}

fn unary_eval_complex_f64(
    args: &[Complex<f64>],
    evaluator: fn(&Complex<Float>, u32) -> Complex<Float>,
) -> Complex<f64> {
    let [arg] = args else {
        return Complex::new(f64::NAN, f64::NAN);
    };
    evaluator(&complex_f64_to_float(arg, 53), 53).to_f64()
}

fn unary_eval_complex_real_f64<F>(args: &[Complex<f64>], evaluator: F) -> Complex<f64>
where
    F: FnOnce(Complex<f64>) -> Complex<f64>,
{
    let [arg] = args else {
        return Complex::new(f64::NAN, f64::NAN);
    };
    evaluator(*arg)
}

fn tagged_unary_eval_real_f64(
    order: Option<Complex<Float>>,
    args: &[f64],
    evaluator: fn(&Complex<Float>, &Complex<Float>, u32) -> Option<Complex<Float>>,
) -> f64 {
    let Some(order) = order else {
        return f64::NAN;
    };
    let [arg] = args else {
        return f64::NAN;
    };
    evaluator(
        &order,
        &Complex::new(Float::with_val(53, *arg), Float::new(53)),
        53,
    )
    .map(|z| z.re.to_f64())
    .unwrap_or(f64::NAN)
}

fn tagged_unary_eval_complex_f64(
    order: Option<Complex<Float>>,
    args: &[Complex<f64>],
    evaluator: fn(&Complex<Float>, &Complex<Float>, u32) -> Option<Complex<Float>>,
) -> Complex<f64> {
    let Some(order) = order else {
        return Complex::new(f64::NAN, f64::NAN);
    };
    let [arg] = args else {
        return Complex::new(f64::NAN, f64::NAN);
    };
    evaluator(&order, &complex_f64_to_float(arg, 53), 53)
        .map(|z| z.to_f64())
        .unwrap_or_else(|| Complex::new(f64::NAN, f64::NAN))
}

fn atan_numeric_eval(z: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    let i = z.i();
    let one = complex_one(binary_prec);
    let two = Complex::new(Float::with_val(binary_prec, 2), Float::new(binary_prec));
    let iz = i.clone() * z;

    (i / two) * ((one.clone() - &iz).log() - (one + iz).log())
}

fn atan2_numeric_eval(x: &Complex<Float>, y: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    if y.im.is_zero() && x.im.is_zero() {
        Complex::new(y.re.atan2(&x.re), Float::new(binary_prec))
    } else {
        y.atan2(x)
    }
}

fn complex_one(prec: u32) -> Complex<Float> {
    Complex::new(Float::with_val(prec, 1), Float::new(prec))
}

fn atan_eval_complex_f64(z: Complex<f64>) -> Complex<f64> {
    let i = z.i();
    let one = Complex::new(1.0, 0.0);
    let two = Complex::new(2.0, 0.0);
    let iz = i * z;
    (i / two) * ((one - iz).log() - (one + iz).log())
}

fn bessel_j_numeric_eval(
    order: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
) -> Option<Complex<Float>> {
    bessel_checked("bessel_j", order, z, binary_prec, bessel_j_numeric_work)
}

fn bessel_i_numeric_eval(
    order: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
) -> Option<Complex<Float>> {
    bessel_checked("bessel_i", order, z, binary_prec, bessel_i_numeric_work)
}

fn bessel_y_numeric_eval(
    order: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
) -> Option<Complex<Float>> {
    bessel_checked("bessel_y", order, z, binary_prec, bessel_y_numeric_work)
}

fn bessel_k_numeric_eval(
    order: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
) -> Option<Complex<Float>> {
    bessel_checked("bessel_k", order, z, binary_prec, bessel_k_numeric_work)
}

fn bessel_j_numeric_work(
    order: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
) -> Option<Complex<Float>> {
    if z.is_zero()
        && let Some(n) = complex_float_to_integer(order)
        && n >= 0
    {
        return Some(if n == 0 {
            complex_one(binary_prec)
        } else {
            Complex::new(Float::new(binary_prec), Float::new(binary_prec))
        });
    }

    if let Some(n) = complex_float_to_integer(order)
        && n < 0
    {
        let positive = Complex::new(
            Float::with_val(binary_prec, n.checked_neg()?),
            Float::new(binary_prec),
        );
        let value = bessel_j_numeric_work(&positive, z, binary_prec)?;
        return Some(if n % 2 == 0 { value } else { -value });
    }

    bessel_series_eval(order, z, binary_prec, true)
}

fn bessel_i_numeric_work(
    order: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
) -> Option<Complex<Float>> {
    if z.is_zero()
        && let Some(n) = complex_float_to_integer(order)
        && n >= 0
    {
        return Some(if n == 0 {
            complex_one(binary_prec)
        } else {
            Complex::new(Float::new(binary_prec), Float::new(binary_prec))
        });
    }

    if let Some(n) = complex_float_to_integer(order)
        && n < 0
    {
        let positive = Complex::new(
            Float::with_val(binary_prec, n.checked_neg()?),
            Float::new(binary_prec),
        );
        return bessel_i_numeric_work(&positive, z, binary_prec);
    }

    bessel_series_eval(order, z, binary_prec, false)
}

fn bessel_y_numeric_work(
    order: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
) -> Option<Complex<Float>> {
    if z.is_zero() {
        return Some(Complex::new(
            Float::with_val(binary_prec, f64::INFINITY),
            Float::new(binary_prec),
        ));
    }

    if let Some(n) = complex_float_to_integer(order)
        && n < 0
    {
        let positive = Complex::new(
            Float::with_val(binary_prec, n.checked_neg()?),
            Float::new(binary_prec),
        );
        let value = bessel_y_numeric_work(&positive, z, binary_prec)?;
        return Some(if n % 2 == 0 { value } else { -value });
    }

    if complex_float_to_integer(order).is_some() {
        return bessel_integer_order_limit(order, z, binary_prec, bessel_y_numeric_work);
    }
    let pi_order = complex_pi(binary_prec) * order.clone();
    let j_pos = bessel_j_numeric_work(order, z, binary_prec)?;
    let j_neg = bessel_j_numeric_work(&(-order.clone()), z, binary_prec)?;
    Some((j_pos * pi_order.clone().cos() - j_neg) / pi_order.sin())
}

fn bessel_k_numeric_work(
    order: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
) -> Option<Complex<Float>> {
    if z.is_zero() {
        return Some(Complex::new(
            Float::with_val(binary_prec, f64::INFINITY),
            Float::new(binary_prec),
        ));
    }

    if let Some(n) = complex_float_to_integer(order) {
        return bessel_k_integer_series(u32::try_from(n.unsigned_abs()).ok()?, z, binary_prec);
    }
    let pi_order = complex_pi(binary_prec) * order.clone();
    let i_neg = bessel_i_numeric_work(&(-order.clone()), z, binary_prec)?;
    let i_pos = bessel_i_numeric_work(order, z, binary_prec)?;
    let pref = Complex::new(
        Float::with_val(binary_prec, Constant::Pi) / Float::with_val(binary_prec, 2),
        Float::new(binary_prec),
    );
    Some(pref * (i_neg - i_pos) / pi_order.sin())
}

fn bessel_series_eval(
    order: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
    alternating: bool,
) -> Option<Complex<Float>> {
    let zero = Float::new(binary_prec);
    let z_half = z.clone() / Complex::new(Float::with_val(binary_prec, 2), zero.clone());
    let one = complex_one(binary_prec);
    let gamma = gamma_numeric_eval(&(order.clone() + one), binary_prec);
    let mut term = z_half.clone().powf(order) / gamma;
    let mut sum = term.clone();
    let z_half_sq = z_half.clone() * z_half;
    let threshold = Float::with_val(binary_prec, 0.5).pow(u64::from(binary_prec));

    let radius_squared = z_half_sq.norm().re;
    for k in 1..(16 * binary_prec.max(16)) {
        let kf = Float::with_val(binary_prec, k);
        let denom = Complex::new(kf.clone(), zero.clone())
            * (order.clone() + Complex::new(kf, zero.clone()));
        let factor = if alternating {
            -z_half_sq.clone()
        } else {
            z_half_sq.clone()
        };
        term = term * factor / denom;
        let term_size = term.norm().re;
        sum += term.clone();
        // Once k > |nu|, (k+1)*(k+1-|nu|) bounds the next
        // denominator from below and increases for every following term.
        let next = Float::with_val(binary_prec, k + 1);
        let order_size = order.norm().re;
        if k > 16 && next > order_size {
            let ratio = radius_squared.clone() / (next.clone() * (next - order_size));
            if ratio < Float::with_val(binary_prec, 0.5)
                && term_size * ratio.clone() * 2
                    <= complex_l1_norm(&sum)
                        * &threshold
                        * (Float::with_val(binary_prec, 1) - ratio)
            {
                return Some(sum);
            }
        }
    }

    None
}

fn bessel_integer_order_limit(
    order: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
    evaluator: fn(&Complex<Float>, &Complex<Float>, u32) -> Option<Complex<Float>>,
) -> Option<Complex<Float>> {
    // Y has a removable 0/0 singularity in its order formula.
    // Keep the O(epsilon) perturbation below the requested rounding error,
    // and supply extra working bits for cancellation both in the Bessel
    // series near gamma poles and in the numerator of the order formula.
    let work_prec = binary_prec.saturating_mul(3).saturating_add(96);
    let epsilon = Float::with_val(work_prec, 0.5).pow(u64::from(binary_prec) + 16);
    let mut order = order.clone();
    order.re.set_prec(work_prec);
    order.im.set_prec(work_prec);
    order.re += epsilon;
    let mut z = z.clone();
    z.re.set_prec(work_prec);
    z.im.set_prec(work_prec);
    let mut result = evaluator(&order, &z, work_prec)?;
    result.re.set_prec(binary_prec);
    result.im.set_prec(binary_prec);
    Some(result)
}

fn complex_pi(prec: u32) -> Complex<Float> {
    Complex::new(Float::with_val(prec, Constant::Pi), Float::new(prec))
}

fn polygamma_eval_f64(order: Option<u32>, args: &[f64]) -> f64 {
    let Some(order) = order else {
        return f64::NAN;
    };
    let [arg] = args else {
        return f64::NAN;
    };
    polygamma_numeric_eval(
        order,
        &Complex::new(Float::with_val(53, *arg), Float::new(53)),
        53,
    )
    .re
    .to_f64()
}

fn polygamma_eval_complex_f64(order: Option<u32>, args: &[Complex<f64>]) -> Complex<f64> {
    let Some(order) = order else {
        return Complex::new(f64::NAN, f64::NAN);
    };
    let [arg] = args else {
        return Complex::new(f64::NAN, f64::NAN);
    };
    polygamma_numeric_eval(order, &complex_f64_to_float(arg, 53), 53).to_f64()
}

fn polylog_eval_f64(order: Option<&Complex<Float>>, dilogarithm: bool, args: &[f64]) -> f64 {
    let Some(order) = order else {
        return f64::NAN;
    };
    let [arg] = args else {
        return f64::NAN;
    };
    if dilogarithm && arg.is_finite() {
        return dilog_f64(*arg);
    }
    let arg = Complex::new(Float::with_val(53, *arg), Float::new(53));
    polylog_numeric_eval(order, &arg, 53)
        .map(|x| x.re.to_f64())
        .unwrap_or(f64::NAN)
}

fn polylog_eval_complex_f64(
    order: Option<&Complex<Float>>,
    dilogarithm: bool,
    args: &[Complex<f64>],
) -> Complex<f64> {
    let Some(order) = order else {
        return Complex::new(f64::NAN, f64::NAN);
    };
    let [arg] = args else {
        return Complex::new(f64::NAN, f64::NAN);
    };
    if dilogarithm && arg.re.is_finite() && arg.im.is_finite() {
        return dilog_complex_f64(*arg);
    }
    polylog_numeric_eval(order, &complex_f64_to_float(arg, 53), 53)
        .map(|x| x.to_f64())
        .unwrap_or_else(|| Complex::new(f64::NAN, f64::NAN))
}

/// Whether a numeric polylogarithm order tag is exactly two.
fn is_dilogarithm_order(order: &Complex<Float>) -> bool {
    order.im.is_zero() && order.re == Float::with_val(order.re.prec(), 2)
}

/// `pi^2/6` and `pi^2/3`, correctly rounded to binary64.
const PI_SQUARED_OVER_SIX: f64 = 1.644_934_066_848_226_4;
const PI_SQUARED_OVER_THREE: f64 = 3.289_868_133_696_452_9;

/// `B_(2k)/(2k+1)!` for `k = 1..=10`: with `u = -log(1-z)`,
/// `Li2(z) = u - u^2/4 + sum_k B_(2k)/(2k+1)! u^(2k+1)` for `|u| < 2 pi`.
const DILOG_BERNOULLI: [f64; 10] = [
    1.0 / 36.0,
    -1.0 / 3600.0,
    1.0 / 211680.0,
    -1.0 / 10886400.0,
    1.0 / 526901760.0,
    -4.064_761_645_144_225_5e-11,
    8.921_691_020_456_452_6e-13,
    -1.993_929_586_072_107_6e-14,
    4.518_980_029_619_918_2e-16,
    -1.035_651_761_218_124_7e-17,
];

/// The Bernoulli series of `Li2(w)` in `u = -log(1-w)`.
///
/// Callers keep `|u| <= pi/3`, where the omitted `k = 11` term is below
/// `1e-18` relative to the result.
#[inline]
fn dilog_bernoulli_series_f64(u: f64) -> f64 {
    let v = u * u;
    // Estrin's scheme, as in the complex series. No mul_add: without a target
    // FMA feature it becomes a libm call.
    let b = &DILOG_BERNOULLI;
    let (v2, linear) = (v * v, |c0: f64, c1: f64| c0 + c1 * v);
    let v4 = v2 * v2;
    let low = linear(b[0], b[1]) + v2 * linear(b[2], b[3]);
    let high = linear(b[4], b[5]) + v2 * linear(b[6], b[7]);
    let sum = low + v4 * high + v4 * v4 * linear(b[8], b[9]);
    u - v / 4.0 + u * v * sum
}

#[inline]
fn dilog_bernoulli_series_complex_f64(u: Complex<f64>) -> Complex<f64> {
    let v = mul_complex_f64(u, u);
    // Estrin's scheme in v: short dependency chains instead of nine
    // dependent complex multiply-adds.
    let b = &DILOG_BERNOULLI;
    let linear = |c0: f64, c1: f64| Complex::new(c0 + c1 * v.re, c1 * v.im);
    let add = |a: Complex<f64>, b: Complex<f64>| Complex::new(a.re + b.re, a.im + b.im);
    let v2 = mul_complex_f64(v, v);
    let v4 = mul_complex_f64(v2, v2);
    let v8 = mul_complex_f64(v4, v4);
    let low = add(linear(b[0], b[1]), mul_complex_f64(v2, linear(b[2], b[3])));
    let high = add(linear(b[4], b[5]), mul_complex_f64(v2, linear(b[6], b[7])));
    let sum = add(
        add(low, mul_complex_f64(v4, high)),
        mul_complex_f64(v8, linear(b[8], b[9])),
    );
    let uv = Complex::new(u.re * v.re - u.im * v.im, u.re * v.im + u.im * v.re);
    Complex::new(
        u.re - v.re / 4.0 + (uv.re * sum.re - uv.im * sum.im),
        u.im - v.im / 4.0 + (uv.re * sum.im + uv.im * sum.re),
    )
}

/// Principal `log(1 + w)` without losing the relative precision of small `w`.
#[inline]
fn log_one_plus_complex_f64(w: Complex<f64>) -> Complex<f64> {
    let real = 1.0 + w.re;
    let modulus_log = if w.re.abs() < 0.5 && w.im.abs() < 0.5 {
        // |1+w|^2 - 1 = w.re (2 + w.re) + w.im^2, without forming |1+w|^2.
        0.5 * (w.re * (2.0 + w.re) + w.im * w.im).ln_1p()
    } else {
        log_modulus_f64(real, w.im)
    };
    Complex::new(modulus_log, w.im.atan2(real))
}

/// `log(|x + i y|)` for finite, not both zero, components.
#[inline]
fn log_modulus_f64(x: f64, y: f64) -> f64 {
    let squared = x * x + y * y;
    if squared.is_normal() && squared.is_finite() {
        0.5 * squared.ln()
    } else {
        x.hypot(y).ln()
    }
}

#[inline]
fn log_complex_f64(z: Complex<f64>) -> Complex<f64> {
    Complex::new(log_modulus_f64(z.re, z.im), z.im.atan2(z.re))
}

/// `1/z` without overflowing or underflowing `|z|^2` (Smith's algorithm).
#[inline]
fn inverse_complex_f64(z: Complex<f64>) -> Complex<f64> {
    if z.re.abs() >= z.im.abs() {
        let ratio = z.im / z.re;
        let denominator = z.re + z.im * ratio;
        Complex::new(1.0 / denominator, -ratio / denominator)
    } else {
        let ratio = z.re / z.im;
        let denominator = z.re * ratio + z.im;
        Complex::new(ratio / denominator, -1.0 / denominator)
    }
}

#[inline]
fn mul_complex_f64(a: Complex<f64>, b: Complex<f64>) -> Complex<f64> {
    Complex::new(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re)
}

/// The real dilogarithm `Li2(x)` in binary64, for real `x`.
///
/// For `x > 1` this returns the real part of the continuation, which is the
/// same on both sides of the cut. It agrees with the numerical value of
/// `polylog(2, x)` to a few ulps away from the zero of `Re Li2(x)` near
/// `x = 12.6`, where only absolute accuracy is retained. Non-finite input
/// gives `NaN`.
pub fn dilog_f64(x: f64) -> f64 {
    if !x.is_finite() {
        return f64::NAN;
    }
    if x == 0.0 {
        // Like polylog(2, 0), including for a negative zero.
        return 0.0;
    }
    if x < -1.0 {
        // Li2(x) = -Li2(1/x) - pi^2/6 - log(-x)^2/2.
        let log = (-x).ln();
        let series = dilog_bernoulli_series_f64(-(-1.0 / x).ln_1p());
        -series - PI_SQUARED_OVER_SIX - 0.5 * log * log
    } else if x <= 0.5 {
        dilog_bernoulli_series_f64(-(-x).ln_1p())
    } else if x < 1.0 {
        // Li2(x) = -Li2(1-x) + pi^2/6 - log(x) log(1-x); 1-x is exact.
        let log = x.ln();
        -dilog_bernoulli_series_f64(-log) + PI_SQUARED_OVER_SIX - log * (1.0 - x).ln()
    } else if x == 1.0 {
        PI_SQUARED_OVER_SIX
    } else if x <= 2.0 {
        // The real part of the reflection on the cut, with exact 1-x.
        let log = x.ln();
        -dilog_bernoulli_series_f64(-log) + PI_SQUARED_OVER_SIX - log * (x - 1.0).ln()
    } else {
        // Re Li2(x) = -Li2(1/x) + pi^2/3 - log(x)^2/2.
        let log = x.ln();
        -dilog_bernoulli_series_f64(-(-1.0 / x).ln_1p()) + PI_SQUARED_OVER_THREE - 0.5 * log * log
    }
}

/// The principal-branch complex dilogarithm `Li2(z)` in binary64.
///
/// Exactly real arguments follow `polylog(2, x)`: for `x > 1` the result is the
/// lower lip `Li2(x - i0)`, `Im Li2(x) = -pi log(x)`, independent of the sign of
/// the zero imaginary part; for `x <= 1` the imaginary part is zero, with the
/// same sign as before (`-0` only at `x = -1`). A nonzero
/// imaginary part, however small, selects its own side of the cut. The relative
/// error is a few ulps of `|Li2(z)|`. Non-finite input gives `NaN` components.
pub fn dilog_complex_f64(z: Complex<f64>) -> Complex<f64> {
    if !z.re.is_finite() || !z.im.is_finite() {
        return Complex::new(f64::NAN, f64::NAN);
    }
    if z.im == 0.0 {
        let imaginary = if z.re > 1.0 {
            -std::f64::consts::PI * z.re.ln()
        } else if z.re == -1.0 {
            // polylog(2, -1) = -(1-2^(-1)) zeta(2) carries a negative zero.
            -0.0
        } else {
            0.0
        };
        return Complex::new(dilog_f64(z.re), imaginary);
    }

    let one_minus_re = 1.0 - z.re;
    if z.re > 0.5 && one_minus_re * one_minus_re + z.im * z.im <= 1.0 {
        // |1-z| <= 1: Li2(z) = -Li2(1-z) + pi^2/6 - log(z) log(1-z), where the
        // series variable of Li2(1-z) is -log(z). Here 1/2 < Re z < 2, so z-1
        // is exact and log(z) keeps its relative precision near z = 1.
        let log_z = log_one_plus_complex_f64(Complex::new(-one_minus_re, z.im));
        let log_one_minus_z = log_complex_f64(Complex::new(one_minus_re, -z.im));
        let series = dilog_bernoulli_series_complex_f64(Complex::new(-log_z.re, -log_z.im));
        let product = mul_complex_f64(log_z, log_one_minus_z);
        return Complex::new(
            -series.re + PI_SQUARED_OVER_SIX - product.re,
            -series.im - product.im,
        );
    }

    let squared_modulus = z.re * z.re + z.im * z.im;
    if squared_modulus <= 1.0 {
        // |z| <= 1 and Re z <= 1/2, so |log(1-z)| <= pi/3.
        let log = log_one_plus_complex_f64(Complex::new(-z.re, -z.im));
        return dilog_bernoulli_series_complex_f64(Complex::new(-log.re, -log.im));
    }

    // |z| > 1 and |1-z| > 1, so Re(1/z) < 1/2 and |1/z| < 1:
    // Li2(z) = -Li2(1/z) - pi^2/6 - log(-z)^2/2.
    let inverse = inverse_complex_f64(z);
    let log = log_one_plus_complex_f64(Complex::new(-inverse.re, -inverse.im));
    let series = dilog_bernoulli_series_complex_f64(Complex::new(-log.re, -log.im));
    let log_minus_z = log_complex_f64(Complex::new(-z.re, -z.im));
    let square = mul_complex_f64(log_minus_z, log_minus_z);
    Complex::new(
        -series.re - PI_SQUARED_OVER_SIX - 0.5 * square.re,
        -series.im - 0.5 * square.im,
    )
}

fn zeta_eval_f64(args: &[f64]) -> f64 {
    let [arg] = args else {
        return f64::NAN;
    };
    zeta_numeric_eval(&Complex::new(Float::with_val(53, *arg), Float::new(53)), 53)
        .re
        .to_f64()
}

fn zeta_eval_complex_f64(args: &[Complex<f64>]) -> Complex<f64> {
    let [arg] = args else {
        return Complex::new(f64::NAN, f64::NAN);
    };
    zeta_numeric_eval(&complex_f64_to_float(arg, 53), 53).to_f64()
}

fn complex_f64_to_float(value: &Complex<f64>, prec: u32) -> Complex<Float> {
    Complex::new(
        Float::with_val(prec, value.re),
        Float::with_val(prec, value.im),
    )
}

fn complex_float_to_integer(value: &Complex<Float>) -> Option<i64> {
    if !value.im.is_zero() {
        return None;
    }
    let re = value.re.try_to_rational()?;
    if !re.is_integer() {
        return None;
    }
    re.numerator().to_i64()
}

fn function_arguments<'a, const N: usize>(view: AtomView<'a>) -> Option<[AtomView<'a>; N]> {
    let AtomView::Fun(fun) = view else {
        return None;
    };

    fun.iter().try_into().ok()
}

fn gamma_exact_rational(rat: &Rational) -> Option<Atom> {
    let denominator = rat.denominator();

    if denominator == 1 {
        let numerator = rat.numerator();
        if numerator <= 0 {
            return Some(Atom::num(Coefficient::complex_infinity()));
        }

        let n = numerator.to_i64()?;
        if n > u32::MAX as i64 {
            return None;
        }

        return Some(Atom::num(Integer::factorial((n - 1) as u32)));
    }

    if denominator == 2 {
        let numerator = rat.numerator().to_i64()?;
        if numerator % 2 == 0 {
            return None;
        }

        let prefactor = gamma_half_integer_prefactor(numerator);
        return Some(Atom::num(prefactor) * Atom::from(State::PI).pow(Atom::num((1, 2))));
    }

    None
}

fn zeta_exact_rational(rat: &Rational) -> Option<Atom> {
    if rat.denominator() != 1 {
        return None;
    }

    let n = rat.numerator().to_i64()?;
    match n {
        0 => return Some(Atom::num((-1, 2))),
        1 => return Some(Atom::num(Coefficient::complex_infinity())),
        -1 => return Some(Atom::num((-1, 12))),
        _ => {}
    }

    if n < 0 {
        let Some(bernoulli_index) = n.checked_neg().and_then(|x| x.checked_add(1)) else {
            return None;
        };
        if bernoulli_index > u32::MAX as i64 {
            return None;
        }

        let bernoulli_index = bernoulli_index as u32;
        let value = bernoulli_number(bernoulli_index) / Rational::from((n - 1, 1));
        if value.is_zero() {
            return Some(Atom::new());
        }

        return Some(Atom::num(value));
    }

    if n % 2 != 0 {
        return None;
    }
    if n > u32::MAX as i64 {
        return None;
    }

    let half_order = n as u32 / 2;
    let mut bernoulli = bernoulli_number(n as u32);
    if half_order.is_multiple_of(2) {
        bernoulli = -bernoulli;
    }

    let pi_power = (Atom::num(2) * Atom::from(State::PI)).pow(Atom::num(n));
    Some(Atom::num(bernoulli) * pi_power / (Atom::num(2) * Atom::num(Integer::factorial(n as u32))))
}

fn bernoulli_number(n: u32) -> Rational {
    let mut a = vec![Rational::zero(); n as usize + 1];

    for m in 0..=n as usize {
        a[m] = Rational::from((1, m as i64 + 1));

        for j in (1..=m).rev() {
            a[j - 1] = (a[j - 1].clone() - a[j].clone()) * Rational::from((j as i64, 1));
        }
    }

    a[0].clone()
}

fn polygamma_order_zero_exact_rational(rat: &Rational) -> Option<Atom> {
    let denominator = rat.denominator();

    if denominator == 1 {
        let numerator = rat.numerator();
        if numerator <= 0 {
            return Some(Atom::num(Coefficient::complex_infinity()));
        }

        let n = numerator.to_i64()?;
        if n > u32::MAX as i64 {
            return None;
        }

        return Some(Atom::num(harmonic_rational((n - 1) as u32)) - Atom::from(euler_gamma()));
    }

    if denominator == 2 {
        let numerator = rat.numerator().to_i64()?;
        if numerator % 2 == 0 {
            return None;
        }

        return Some(
            polygamma_order_zero_half_integer_base()
                + Atom::num(polygamma_order_zero_half_integer_shift(numerator)),
        );
    }

    None
}

fn polygamma_exact_rational(order: u32, rat: &Rational) -> Option<Atom> {
    if order == 0 {
        return polygamma_order_zero_exact_rational(rat);
    }

    if rat.denominator() != 1 {
        return None;
    }

    let argument = rat.numerator().to_i64()?;
    if argument < 1 {
        return None;
    }
    let zeta_order = order.checked_add(1)?;

    // DLMF 5.15.2 and 5.15.5: psi^(n)(m) = (-1)^(n+1) n!
    // * (zeta(n+1) - sum_{k=1}^{m-1} k^(-n-1)), for n,m >= 1.
    let mut shift = Rational::zero();
    for k in 1..argument {
        shift += &(Rational::one() / Rational::from(k).pow(u64::from(zeta_order)));
    }
    let mut factor = Integer::factorial(order);
    if order.is_multiple_of(2) {
        factor = -factor;
    }
    Some(
        Atom::num(factor.clone()) * function!(SPECIALS.zeta, Atom::num(zeta_order))
            - Atom::num(Rational::from(factor) * shift),
    )
}

fn gamma_half_integer_prefactor(numerator: i64) -> Rational {
    let one = Rational::from((1, 1));
    let target = Rational::from((numerator, 2));
    let mut current = Rational::from((1, 2));
    let mut prefactor = Rational::from((1, 1));

    while current < target {
        prefactor *= &current;
        current += &one;
    }

    while current > target {
        current -= &one;
        prefactor /= &current;
    }

    prefactor
}

fn harmonic_rational(n: u32) -> Rational {
    let mut sum = Rational::from((0, 1));
    let one = Rational::from((1, 1));

    for k in 1..=n {
        sum += &(one.clone() / Rational::from((k as i64, 1)));
    }

    sum
}

fn polygamma_order_zero_half_integer_base() -> Atom {
    -Atom::from(euler_gamma()) - Atom::num(2) * function!(State::LOG, Atom::num(2))
}

fn polygamma_order_zero_half_integer_shift(numerator: i64) -> Rational {
    let one = Rational::from((1, 1));
    let target = Rational::from((numerator, 2));
    let mut current = Rational::from((1, 2));
    let mut correction = Rational::from((0, 1));

    while current < target {
        correction += &(one.clone() / current.clone());
        current += &one;
    }

    while current > target {
        current -= &one;
        correction -= &(one.clone() / current.clone());
    }

    correction
}

fn is_tan_pole(point: AtomView) -> bool {
    let Some(ratio) = rational_multiple_of_pi(point) else {
        return false;
    };

    ratio.denominator() == 2
}

fn is_cot_csc_pole(point: AtomView) -> bool {
    rational_multiple_of_pi(point).is_some_and(|r| r.denominator() == 1)
}

fn is_tanh_sech_pole(point: AtomView) -> bool {
    let Some(ratio) = rational_multiple_of_i_pi(point) else {
        return false;
    };

    ratio.denominator() == 2
}

fn is_coth_csch_pole(point: AtomView) -> bool {
    rational_multiple_of_i_pi(point).is_some_and(|r| r.denominator() == 1)
}

fn sec_residue(point: AtomView) -> Option<Atom> {
    let ratio = rational_multiple_of_pi(point)?;
    let sin = half_integer_sin_sign(&ratio)?;
    Some(Atom::num(-sin))
}

fn csc_residue(point: AtomView) -> Option<Atom> {
    let ratio = rational_multiple_of_pi(point)?;
    let cos = integer_cos_sign(&ratio)?;
    Some(Atom::num(cos))
}

fn sech_residue(point: AtomView) -> Option<Atom> {
    let ratio = rational_multiple_of_i_pi(point)?;
    let sin = half_integer_sin_sign(&ratio)?;
    Some(Atom::num(-sin) * Atom::i())
}

fn csch_residue(point: AtomView) -> Option<Atom> {
    let ratio = rational_multiple_of_i_pi(point)?;
    let cos = integer_cos_sign(&ratio)?;
    Some(Atom::num(cos))
}

fn half_integer_sin_sign(ratio: &Rational) -> Option<i64> {
    if ratio.denominator() != 2 {
        return None;
    }

    let rem = ratio.numerator() % 4;
    if rem == 1 {
        Some(1)
    } else if rem == 3 {
        Some(-1)
    } else {
        None
    }
}

fn integer_cos_sign(ratio: &Rational) -> Option<i64> {
    if ratio.denominator() != 1 {
        return None;
    }

    if ratio.numerator() % 2 == 0 {
        Some(1)
    } else {
        Some(-1)
    }
}

fn rational_multiple_of_i_pi(point: AtomView) -> Option<Rational> {
    let ratio = complex_rational_multiple_of_pi(point)?;
    if ratio.re.is_zero() {
        Some(ratio.im)
    } else {
        None
    }
}

fn rational_multiple_of_pi(point: AtomView) -> Option<Rational> {
    let ratio = complex_rational_multiple_of_pi(point)?;
    if ratio.im.is_zero() {
        Some(ratio.re)
    } else {
        None
    }
}

fn complex_rational_multiple_of_pi(point: AtomView) -> Option<Complex<Rational>> {
    match point {
        AtomView::Num(_) => {
            let r = Complex::<Rational>::try_from(point).ok()?;
            if r.re.is_zero() && r.im.is_zero() {
                Some(Complex::new(Rational::zero(), Rational::zero()))
            } else {
                None
            }
        }
        AtomView::Var(v) => {
            if v.get_symbol() == State::PI {
                Some(Complex::new(Rational::one(), Rational::zero()))
            } else {
                None
            }
        }
        AtomView::Mul(m) => {
            let mut coeff = Complex::new(Rational::one(), Rational::zero());
            let mut has_pi = false;

            for factor in m {
                if let Ok(r) = Complex::<Rational>::try_from(factor) {
                    coeff *= &r;
                    continue;
                }

                if let AtomView::Var(v) = factor
                    && v.get_symbol() == State::PI
                    && !has_pi
                {
                    has_pi = true;
                    continue;
                }

                return None;
            }

            if has_pi { Some(coeff) } else { None }
        }
        AtomView::Add(a) => {
            let mut sum = Complex::new(Rational::zero(), Rational::zero());
            for term in a {
                sum += &complex_rational_multiple_of_pi(term)?;
            }
            Some(sum)
        }
        _ => None,
    }
}

fn is_negative_atom(arg: AtomView) -> bool {
    match arg {
        AtomView::Num(n) => n.get_coeff_view().to_owned().is_negative(),
        AtomView::Mul(m) => m.into_iter().any(is_negative_atom),
        _ => false,
    }
}

fn atom_float_precision(value: AtomView) -> Option<u32> {
    let AtomView::Num(number) = value else {
        return None;
    };

    match number.get_coeff_view() {
        CoefficientView::Float(r, i) => Some(r.to_float().prec().max(i.to_float().prec())),
        _ => None,
    }
}

fn atom_to_integer(value: AtomView) -> Option<i64> {
    let rat = Rational::try_from(value).ok()?;
    if !rat.is_integer() {
        return None;
    }
    rat.numerator().to_i64()
}

fn maybe_eval_unary_float_in_norm(
    arg: AtomView,
    out: &mut Settable<Atom>,
    evaluator: fn(&Complex<Float>, u32) -> Complex<Float>,
) -> bool {
    let Some(prec) = atom_float_precision(arg) else {
        return false;
    };
    let Some(z) = atom_to_complex_float(arg, prec) else {
        return false;
    };

    out.to_num(evaluator(&z, prec));
    true
}

fn maybe_eval_polygamma_float_in_norm(order: u32, arg: AtomView, out: &mut Settable<Atom>) -> bool {
    let Some(prec) = atom_float_precision(arg) else {
        return false;
    };
    let Some(z) = atom_to_complex_float(arg, prec) else {
        return false;
    };

    out.to_num(polygamma_numeric_eval(order, &z, prec));
    true
}

fn maybe_eval_binary_float_in_norm(
    lhs: AtomView,
    rhs: AtomView,
    out: &mut Settable<Atom>,
    evaluator: fn(&Complex<Float>, &Complex<Float>, u32) -> Option<Complex<Float>>,
) -> bool {
    let precision = atom_float_precision(lhs).or_else(|| atom_float_precision(rhs));
    let Some(prec) = precision else {
        return false;
    };
    let Some(lhs_float) = atom_to_complex_float(lhs, prec) else {
        return false;
    };
    let Some(rhs_float) = atom_to_complex_float(rhs, prec) else {
        return false;
    };
    let Some(value) = evaluator(&lhs_float, &rhs_float, prec) else {
        return false;
    };
    out.to_num(value);
    true
}

fn atom_to_complex_float(value: AtomView, binary_prec: u32) -> Option<Complex<Float>> {
    let AtomView::Num(number) = value else {
        return None;
    };

    match number.get_coeff_view() {
        CoefficientView::Natural(nr, dr, ni, di) => Some(Complex::new(
            Float::with_val(binary_prec, nr) / Float::with_val(binary_prec, dr),
            Float::with_val(binary_prec, ni) / Float::with_val(binary_prec, di),
        )),
        CoefficientView::Large(r, i) => Some(Complex::new(
            r.to_rat().to_multi_prec_float(binary_prec),
            i.to_rat().to_multi_prec_float(binary_prec),
        )),
        CoefficientView::Float(r, i) => {
            let mut re = r.to_float();
            let mut im = i.to_float();
            if re.prec() > binary_prec {
                re.set_prec(binary_prec);
            }
            if im.prec() > binary_prec {
                im.set_prec(binary_prec);
            }
            Some(Complex::new(re, im))
        }
        _ => None,
    }
}

fn gamma_numeric_eval(z: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    #[cfg(feature = "float-mpfr")]
    {
        if z.im.is_fully_zero() {
            return Complex::new(
                z.re.clone().into_raw().gamma().into(),
                Float::new(binary_prec),
            );
        }
    }

    if z.im.is_fully_zero()
        && z.re <= Float::new(binary_prec)
        && z.re.try_to_rational().is_some_and(|r| r.is_integer())
    {
        return Complex::new(
            Float::with_val(binary_prec, f64::NAN),
            Float::new(binary_prec),
        );
    }

    if let Some(n) = complex_float_to_integer(z)
        && n > 0
        && n <= 4096
    {
        return Complex::new(
            factorial_float(n as u32 - 1, binary_prec),
            Float::new(binary_prec),
        );
    }
    gamma_complex_spouge(z, binary_prec)
}

fn erf_numeric_eval(z: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    #[cfg(feature = "float-mpfr")]
    if z.im.is_fully_zero() {
        return Complex::new(
            z.re.clone().into_raw().erf().into(),
            Float::new(binary_prec),
        );
    }
    erf_checked(z, binary_prec)
}

fn polygamma_order_zero_numeric_eval(z: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    #[cfg(feature = "float-mpfr")]
    {
        if z.im.is_fully_zero() {
            return Complex::new(
                z.re.clone().into_raw().digamma().into(),
                Float::new(binary_prec),
            );
        }
    }

    polygamma_order_zero_complex(z, binary_prec)
}

fn polygamma_numeric_eval(order: u32, z: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    if order == 0 {
        return polygamma_order_zero_numeric_eval(z, binary_prec);
    }
    polygamma_checked(order, z, binary_prec)
}

fn polylog_exact(s: AtomView, z: AtomView) -> Option<Atom> {
    if z.is_zero() {
        return Some(Atom::new());
    }

    if let Some(order) = atom_to_integer(s) {
        if order < 0 {
            return polylog_negative_integer_exact(order, z);
        }

        if order == 0 {
            return Some(z.to_owned() / (Atom::num(1) - z));
        }

        if order == 1 {
            return Some(-function!(State::LOG, Atom::num(1) - z));
        }
    }

    if z.is_one() {
        if let Some(order) = atom_to_integer(s)
            && order == 1
        {
            return Some(Atom::num(Coefficient::complex_infinity()));
        }

        if let Ok(rat) = Rational::try_from(s)
            && let Some(exact) = zeta_exact_rational(&rat)
        {
            return Some(exact);
        }

        return Some(function!(SPECIALS.zeta, s.to_owned()));
    }

    if let Ok(rat) = Rational::try_from(z)
        && rat == (-1, 1)
    {
        if let Some(order) = atom_to_integer(s)
            && order == 1
        {
            return Some(-function!(State::LOG, Atom::num(2)));
        }

        if let Ok(s_rat) = Rational::try_from(s)
            && let Some(exact) = polylog_minus_one_exact_rational(&s_rat)
        {
            return Some(exact);
        }

        return Some(
            -(Atom::num(1) - Atom::num(2).pow(Atom::num(1) - s.to_owned()))
                * function!(SPECIALS.zeta, s.to_owned()),
        );
    }

    None
}

fn polylog_numeric_eval(
    s: &Complex<Float>,
    z: &Complex<Float>,
    binary_prec: u32,
) -> Option<Complex<Float>> {
    if binary_prec == 0 {
        return None;
    }
    let max_terms = 64u32.checked_mul(binary_prec.max(16))?;
    let zero = Float::new(binary_prec);
    let one = Float::with_val(binary_prec, 1);

    if z.is_fully_zero() {
        return Some(Complex::new(zero.clone(), zero.clone()));
    }

    if s.is_fully_zero() {
        return Some(z.clone() / (Complex::new(one.clone(), zero.clone()) - z.clone()));
    }

    if s.im.is_fully_zero() && s.re == one {
        return Some(-(Complex::new(one.clone(), zero.clone()) - z.clone()).log());
    }

    if let Some(order) = complex_float_to_integer(s) {
        let result = polylog_integer_numeric_eval(order, z, binary_prec, 0);
        if result.is_none() {
            tracing::warn!(
                order,
                binary_precision = binary_prec,
                "polylog: convergence or precision budget exceeded; numerical evaluation declined"
            );
        }
        return result;
    }

    let radius = z.norm().re;
    if radius >= Float::with_val(binary_prec, 19) / Float::with_val(binary_prec, 20) {
        tracing::warn!(
            "polylog: noninteger-order continuation outside |z| < 0.95 is not implemented; numerical evaluation declined"
        );
        return None;
    }

    let threshold = binary_series_threshold(binary_prec);
    let mut z_pow = z.clone();
    let mut sum = Complex::new(zero.clone(), zero.clone());

    for k in 1..max_terms {
        let base = Complex::new(Float::with_val(binary_prec, k), zero.clone());
        let denom = base.powf(s);
        let term = z_pow.clone() / denom;
        let term_size = complex_l1_norm(&term);
        sum += term;
        if k > 16 && term_size <= complex_l1_norm(&sum) * &threshold {
            // |t_(k+1)/t_k| = |z| * ((k+1)/k)^(-Re(s)).
            // For negative Re(s), this decreases with k; otherwise |z|
            // bounds every later ratio. Require a decreasing geometric tail.
            let ratio = if s.re < zero {
                radius.clone()
                    * (Float::with_val(binary_prec, k + 1) / Float::with_val(binary_prec, k))
                        .powf(&(-s.re.clone()))
            } else {
                radius.clone()
            };
            if ratio < one
                && term_size * ratio.clone() * Float::with_val(binary_prec, 2)
                    <= complex_l1_norm(&sum) * &threshold * (one.clone() - ratio)
            {
                return Some(sum);
            }
        }
        z_pow *= z.clone();
    }

    // Do not silently return an unconverged partial sum for difficult orders.
    tracing::warn!("polylog: series did not converge; numerical evaluation declined");
    None
}

fn binary_series_threshold(binary_prec: u32) -> Float {
    Float::with_val(binary_prec, 0.5).pow(u64::from(binary_prec))
}

fn complex_l1_norm(value: &Complex<Float>) -> Float {
    value.re.norm() + value.im.norm()
}

fn polylog_minus_one_exact_rational(s: &Rational) -> Option<Atom> {
    if *s == Rational::one() {
        return Some(-function!(State::LOG, Atom::num(2)));
    }

    let zeta_term = if let Some(exact) = zeta_exact_rational(s) {
        exact
    } else {
        function!(SPECIALS.zeta, Atom::num(s.clone()))
    };

    Some(-(Atom::num(1) - Atom::num(2).pow(Atom::num(1) - Atom::num(s.clone()))) * zeta_term)
}

fn polylog_negative_integer_exact(order: i64, z: AtomView) -> Option<Atom> {
    let n = order.checked_neg()? as u32;
    let coeffs = eulerian_row(n);
    let mut numerator = Atom::new();

    for (k, coeff) in coeffs.into_iter().enumerate() {
        numerator += Atom::num(coeff) * z.to_owned().pow(Atom::num((k + 1) as i64));
    }

    Some(numerator / (Atom::num(1) - z).pow(Atom::num((n + 1) as i64)))
}

fn eulerian_row(n: u32) -> Vec<Integer> {
    if n == 0 {
        return vec![Integer::from(1)];
    }

    let mut row = vec![Integer::from(1)];
    for m in 2..=n {
        let mut next = vec![Integer::from(0); m as usize];
        for k in 0..m as usize {
            let mut value = Integer::from(0);
            if k > 0 {
                value += Integer::from(m - k as u32) * row[k - 1].clone();
            }
            if k < row.len() {
                value += Integer::from(k as u32 + 1) * row[k].clone();
            }
            next[k] = value;
        }
        row = next;
    }

    row
}

fn polylog_integer_numeric_eval(
    order: i64,
    z: &Complex<Float>,
    binary_prec: u32,
    depth: u32,
) -> Option<Complex<Float>> {
    // Guard summation/continuation cancellation before rounding once to the
    // requested precision. A tiny nonzero imaginary component near the real
    // axis can be recovered as a difference of O(1) Jonquiere terms; preserve
    // its exponent gap as well. This uses backend exponents, never binary64.
    let component_gap = match (z.re.as_raw().get_exp(), z.im.as_raw().get_exp()) {
        (Some(re), Some(im)) => re.abs_diff(im),
        _ => 0,
    };
    let guard = 64u32.checked_add(binary_prec.max(1).ilog2())?;
    let work_prec = binary_prec.checked_add(guard)?.checked_add(component_gap)?;
    let mut argument = z.clone();
    argument.re.set_prec(work_prec);
    argument.im.set_prec(work_prec);
    let mut result = polylog_integer_numeric_work(order, &argument, work_prec, depth)?;
    if result.re.prec() > binary_prec {
        result.re.set_prec(binary_prec);
    }
    if result.im.prec() > binary_prec {
        result.im.set_prec(binary_prec);
    }
    Some(result)
}

fn polylog_integer_numeric_work(
    order: i64,
    z: &Complex<Float>,
    binary_prec: u32,
    depth: u32,
) -> Option<Complex<Float>> {
    if depth > 8 {
        return None;
    }

    let zero = Float::new(binary_prec);
    if order <= 0 {
        u32::try_from(order.checked_neg()?).ok()?;
        return Some(polylog_negative_integer_numeric_eval(order, z, binary_prec));
    }
    let positive_order = u32::try_from(order).ok()?;

    // Endpoint and branch predicates must preserve the input precision. Nearby
    // arbitrary-precision values can round to exactly +/-1 when cast to f64.
    if z.im.is_fully_zero() && z.re == Float::with_val(binary_prec, 1) {
        return Some(zeta_integer_numeric_eval(order, binary_prec));
    }

    if z.im.is_fully_zero() && z.re == Float::with_val(binary_prec, -1) {
        let zeta = zeta_integer_numeric_eval(order, binary_prec);
        let exponent = Complex::new(Float::with_val(binary_prec, 1 - order), zero.clone());
        let factor = complex_one(binary_prec)
            - Complex::new(Float::with_val(binary_prec, 2), zero.clone()).powf(&exponent);
        return Some(-factor * zeta);
    }

    if order == 1 {
        return Some(-(complex_one(binary_prec) - z.clone()).log());
    }

    #[cfg(feature = "float-mpfr")]
    if order == 2 && z.im.is_fully_zero() && z.re <= Float::with_val(binary_prec, 1) {
        return Some(Complex::new(
            z.re.clone().into_raw().li2().into(),
            zero.clone(),
        ));
    }

    let abs_z = z.norm().re;
    if abs_z < Float::with_val(binary_prec, 19) / Float::with_val(binary_prec, 20) {
        return polylog_series_integer(positive_order, z, binary_prec, 64);
    }

    let log_z = z.log();
    // The logarithmic expansion converges for |log(z)| < 2*pi (DLMF 25.12.12).
    // Cover the unit circle, where the direct power series converges too slowly
    // to reach the requested precision before its iteration cap.
    if log_z.norm().re < Float::with_val(binary_prec, 4) {
        return Some(polylog_real_branch_fix(
            z,
            polylog_jonquiere_integer(positive_order, &log_z, binary_prec)?,
        ));
    }

    if abs_z <= Float::with_val(binary_prec, 1) {
        return polylog_series_integer(positive_order, z, binary_prec, 64);
    }

    let inv = z.inv();
    if order == 2 {
        let continued = polylog_integer_numeric_work(order, &inv, binary_prec, depth + 1)?;
        let log_minus_z = polylog_log_minus(z, binary_prec);
        let pi_sq_over_six = Complex::new(
            Float::with_val(binary_prec, Constant::Pi).pow(2) / Float::with_val(binary_prec, 6),
            zero.clone(),
        );
        return Some(polylog_real_branch_fix(
            z,
            -continued
                - pi_sq_over_six
                - log_minus_z.clone() * log_minus_z
                    / Complex::new(Float::with_val(binary_prec, 2), zero.clone()),
        ));
    }

    let continued = polylog_integer_numeric_work(order, &inv, binary_prec, depth + 1)?;
    let log_minus_z = polylog_log_minus(z, binary_prec);
    let i = log_minus_z.i();
    let bernoulli = bernoulli_polynomial(
        order as u32,
        &(Complex::new(Float::with_val(binary_prec, 1), zero.clone())
            / Complex::new(Float::with_val(binary_prec, 2), zero.clone())
            + log_minus_z.clone()
                / (Complex::new(Float::with_val(binary_prec, 2), zero.clone())
                    * Complex::new(Float::with_val(binary_prec, Constant::Pi), zero.clone())
                    * i.clone())),
        binary_prec,
    );
    let two_pi_i = Complex::new(
        Float::with_val(binary_prec, 2) * Float::with_val(binary_prec, Constant::Pi),
        zero.clone(),
    ) * i;
    let prefactor = -pow_complex_u32(&two_pi_i, order as u32)
        / Complex::new(factorial_float(order as u32, binary_prec), zero.clone());

    if order % 2 == 0 {
        Some(polylog_real_branch_fix(
            z,
            prefactor * bernoulli - continued,
        ))
    } else {
        Some(polylog_real_branch_fix(
            z,
            prefactor * bernoulli + continued,
        ))
    }
}

fn polylog_negative_integer_numeric_eval(
    order: i64,
    z: &Complex<Float>,
    binary_prec: u32,
) -> Complex<Float> {
    let n = order.checked_neg().unwrap_or_default() as u32;
    let coeffs = eulerian_row(n);
    let mut poly = Complex::new(Float::new(binary_prec), Float::new(binary_prec));

    for coeff in coeffs.iter().rev() {
        poly = z.clone()
            * (poly
                + Complex::new(
                    Float::with_integer(binary_prec, coeff.clone().to_multi_prec()),
                    Float::new(binary_prec),
                ));
    }

    poly / pow_complex_u32(&(complex_one(binary_prec) - z.clone()), n + 1)
}

fn polylog_series_integer(
    order: u32,
    z: &Complex<Float>,
    binary_prec: u32,
    max_terms_factor: u32,
) -> Option<Complex<Float>> {
    let zero = Float::new(binary_prec);
    let radius = z.norm().re;
    if radius >= Float::with_val(binary_prec, 1) {
        return None;
    }
    // For positive integer order, the remaining tail is bounded by the
    // current term's magnitude divided by (1-|z|). The extra factor two
    // covers conversion between componentwise and Euclidean norms.
    let threshold = binary_series_threshold(binary_prec)
        * (Float::with_val(binary_prec, 1) - radius)
        / Float::with_val(binary_prec, 2);
    let mut z_pow = z.clone();
    let mut sum = Complex::new(zero.clone(), zero.clone());

    for k in 1..max_terms_factor.checked_mul(binary_prec.max(16))? {
        let denom = Float::with_val(binary_prec, k).pow(order as u64);
        let term = z_pow.clone() / Complex::new(denom, zero.clone());
        let term_size = complex_l1_norm(&term);
        sum += term;
        if k > 16 && term_size <= complex_l1_norm(&sum) * &threshold {
            return Some(sum);
        }
        z_pow *= z.clone();
    }

    None
}

fn polylog_jonquiere_integer(
    order: u32,
    mu: &Complex<Float>,
    binary_prec: u32,
) -> Option<Complex<Float>> {
    if order == 2 {
        return dilog_jonquiere(mu, binary_prec);
    }
    let zero = Float::new(binary_prec);
    let ratio = mu.norm().re
        / (Float::with_val(binary_prec, 2) * Float::with_val(binary_prec, Constant::Pi));
    if ratio >= Float::with_val(binary_prec, 1) {
        return None;
    }
    // Beyond the exceptional logarithmic term, successive nonzero terms
    // have magnitude ratio at most (|mu|/(2*pi))^2. Structural zeta zeros
    // must not terminate the series. See DLMF 25.12.12 and 25.6.3.
    let threshold = binary_series_threshold(binary_prec)
        * (Float::with_val(binary_prec, 1) - ratio.pow(2))
        / Float::with_val(binary_prec, 2);
    let mut sum = Complex::new(zero.clone(), zero.clone());
    let mut mu_pow = Complex::new(Float::with_val(binary_prec, 1), zero.clone());
    let mut factorial = Float::with_val(binary_prec, 1);

    let first_convergence_check = order.checked_add(8)?;
    let max_terms = 32u32.checked_mul(binary_prec.max(16))?.checked_add(order)?;
    for k in 0u32..max_terms {
        let term = if k + 1 == order {
            mu_pow.clone() / Complex::new(factorial.clone(), zero.clone())
                * Complex::new(
                    harmonic_rational(order - 1).to_multi_prec_float(binary_prec),
                    zero.clone(),
                )
                - mu_pow.clone() / Complex::new(factorial.clone(), zero.clone())
                    * (-mu.clone()).log()
        } else {
            mu_pow.clone() / Complex::new(factorial.clone(), zero.clone())
                * zeta_integer_numeric_eval(order as i64 - k as i64, binary_prec)
        };

        let term_size = complex_l1_norm(&term);
        sum += term;
        // Zeta(-2n) vanishes identically. A structural zero is not a
        // convergence estimate for the following nonzero term.
        let trivial_zeta_zero = k > order && (k - order) % 2 == 0;
        if k > first_convergence_check
            && !trivial_zeta_zero
            && term_size <= complex_l1_norm(&sum) * &threshold
        {
            return Some(sum);
        }

        mu_pow *= mu.clone();
        factorial *= Float::with_val(binary_prec, k + 1);
    }

    None
}

fn dilog_jonquiere(mu: &Complex<Float>, binary_prec: u32) -> Option<Complex<Float>> {
    let zero = Float::new(binary_prec);
    let one = Float::with_val(binary_prec, 1);
    let two = Float::with_val(binary_prec, 2);
    let pi = Float::with_val(binary_prec, Constant::Pi);
    let scaled_mu = mu.clone() / (two.clone() * &pi);
    let ratio_squared = scaled_mu.norm_squared();
    if ratio_squared >= one {
        return None;
    }
    let threshold = binary_series_threshold(binary_prec) * (one.clone() - ratio_squared) / &two;
    let mut sum = Complex::new(pi.pow(2) / Float::with_val(binary_prec, 6), zero.clone())
        + mu.clone() * (Complex::new(one, zero.clone()) - (-mu.clone()).log())
        - mu.clone() * mu.clone() / Float::with_val(binary_prec, 4);

    // Reflect the negative-integer zeta coefficients analytically rather than
    // repeatedly evaluating MPFR zeta at large negative integers:
    // zeta(2-k)/k! = (-1)^((k-1)/2) * 2*zeta(k-1)
    //                 / (k*(k-1)*(2*pi)^(k-1)), odd k >= 3.
    // This is the SAME Jonquiere series (DLMF 25.12.12, 25.6.2--25.6.3).
    // Recurrent powers also avoid separately growing factorials and zeta
    // values which cancel in their quotient. Even k>2 terms vanish exactly.
    let step = -scaled_mu.clone() * scaled_mu;
    let mut power = mu.clone() * step.clone();
    let max_terms = 16u32.checked_mul(binary_prec.max(16))?;
    for n in 1..max_terms {
        let k = n.checked_mul(2)?.checked_add(1)?;
        let coefficient = zeta_integer_numeric_eval(i64::from(k - 1), binary_prec).re * &two
            / (Float::with_val(binary_prec, k) * Float::with_val(binary_prec, k - 1));
        let term = power.clone() * coefficient;
        let term_size = complex_l1_norm(&term);
        sum += term;
        if n > 8 && term_size <= complex_l1_norm(&sum) * &threshold {
            return Some(sum);
        }
        power *= step.clone();
    }
    None
}

fn zeta_integer_numeric_eval(order: i64, binary_prec: u32) -> Complex<Float> {
    #[cfg(feature = "float-mpfr")]
    if let Ok(order) = u32::try_from(order) {
        use crate::domains::backend::float::MultiPrecisionFloat;
        // MPFR has a specialized integer-order algorithm; constructing a
        // floating-order argument instead invokes its general zeta routine.
        return Complex::new(
            MultiPrecisionFloat::with_val(binary_prec, MultiPrecisionFloat::zeta_u(order)).into(),
            Float::new(binary_prec),
        );
    }
    #[cfg(not(feature = "float-mpfr"))]
    {
        // The logarithmic polylog series asks for many integer zeta values.
        // In particular, running Hasse's double sum at negative integers is
        // both expensive and subject to severe cancellation. Use the exact
        // Bernoulli formulas (DLMF 25.6.1--25.6.3) instead.
        let zero = Float::new(binary_prec);
        if order == 0 {
            return Complex::new(Float::with_val(binary_prec, -0.5), zero);
        }
        // For n >= p+2, 0 < zeta(n)-1 < 2^(1-n), below half an ulp.
        // Avoid constructing large Bernoulli numbers for a result rounding to 1.
        if order >= i64::from(binary_prec) + 2 {
            return complex_one(binary_prec);
        }
        if order < 0 {
            if order % 2 == 0 {
                return Complex::new(zero.clone(), zero);
            }
            if let Some(n) = order
                .checked_neg()
                .and_then(|n| n.checked_add(1))
                .and_then(|n| u32::try_from(n).ok())
            {
                let value = -bernoulli_number(n) / Rational::from(n);
                return Complex::new(value.to_multi_prec_float(binary_prec), zero);
            }
        } else if order % 2 == 0
            && let Ok(n) = u32::try_from(order)
        {
            let coefficient = bernoulli_number(n) / Rational::from(Integer::factorial(n) * 2);
            let mut value = coefficient.to_multi_prec_float(binary_prec)
                * (Float::with_val(binary_prec, Constant::Pi) * 2).pow(u64::from(n));
            if n.is_multiple_of(4) {
                value = -value;
            }
            return Complex::new(value, zero);
        }
    }
    zeta_numeric_eval(
        &Complex::new(Float::with_val(binary_prec, order), Float::new(binary_prec)),
        binary_prec,
    )
}

fn bernoulli_polynomial(n: u32, x: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    let zero = Float::new(binary_prec);
    let mut sum = Complex::new(zero.clone(), zero.clone());

    for k in 0..=n {
        let coeff = Float::with_integer(
            binary_prec,
            Integer::binom(n.into(), k.into()).to_multi_prec(),
        ) * bernoulli_number(n - k).to_multi_prec_float(binary_prec);
        sum += Complex::new(coeff, zero.clone()) * pow_complex_u32(x, k);
    }

    sum
}

fn polylog_log_minus(z: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    if z.im.is_fully_zero() && z.re > Float::new(binary_prec) {
        return z.log()
            + Complex::new(
                Float::new(binary_prec),
                Float::with_val(binary_prec, Constant::Pi),
            );
    }

    (-z.clone()).log()
}

fn polylog_real_branch_fix(z: &Complex<Float>, value: Complex<Float>) -> Complex<Float> {
    if z.im.is_fully_zero()
        && z.re > Float::with_val(z.re.prec(), 1)
        && value.im > Float::new(value.im.prec())
    {
        return Complex::new(value.re, -value.im);
    }

    value
}

fn pow_complex_u32(z: &Complex<Float>, n: u32) -> Complex<Float> {
    if n == 0 {
        return complex_one(z.re.prec().max(z.im.prec()));
    }

    let prec = z.re.prec().max(z.im.prec());
    let mut base = z.clone();
    let mut exp = n;
    let mut out = complex_one(prec);
    while exp > 0 {
        if exp % 2 == 1 {
            out *= base.clone();
        }
        exp /= 2;
        if exp > 0 {
            base *= base.clone();
        }
    }
    out
}

fn factorial_float(n: u32, binary_prec: u32) -> Float {
    Float::with_integer(binary_prec, Integer::factorial(n).to_multi_prec())
}

fn zeta_numeric_eval(s: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    let zero = Float::new(binary_prec);

    if s.im.is_fully_zero() {
        if s.re == Float::with_val(binary_prec, 1) {
            return Complex::new(Float::with_val(binary_prec, f64::INFINITY), zero);
        }

        #[cfg(feature = "float-mpfr")]
        {
            // Retain the existing integer-order owner for exactly represented
            // nonnegative integers. Its MPFR zeta_u route is substantially
            // faster at high precision than the general floating-order call.
            if finite(s)
                && let Some(order) = complex_float_to_integer(s)
                && u32::try_from(order).is_ok()
            {
                return zeta_integer_numeric_eval(order, binary_prec);
            }
            return Complex::new(s.re.clone().into_raw().zeta().into(), zero);
        }

        #[cfg(not(feature = "float-mpfr"))]
        if let Some(n) = complex_float_to_integer(s) {
            if (-4096..=0).contains(&n)
                || (n > 0 && n % 2 == 0 && n <= 4096)
                || n >= i64::from(binary_prec) + 2
            {
                return zeta_integer_numeric_eval(n, binary_prec);
            }
            if n < 0 && n % 2 == 0 {
                return Complex::new(zero.clone(), zero);
            }
        }
    }

    if !s.re.is_finite() || !s.im.is_finite() || binary_prec > 16_384 {
        tracing::warn!("zeta: unsupported argument or precision; numerical evaluation declined");
        return Complex::new(
            Float::with_val(binary_prec.clamp(1, 16_384), f64::NAN),
            zero,
        );
    }

    // Forming 1-2^(1-s) loses bits close to the pole. Preserve those
    // bits internally; only the exact pole above should return infinity.
    let distance = (s.re.clone() - 1).norm() + s.im.norm();
    let pole_guard = distance
        .as_raw()
        .get_exp()
        .map_or(0, |e| e.saturating_neg().max(0) as u32);
    if pole_guard > 16_384 {
        tracing::warn!("zeta: argument too close to the pole; numerical evaluation declined");
        return Complex::new(Float::with_val(binary_prec, f64::NAN), zero);
    }
    let work_prec = binary_prec
        .saturating_mul(4)
        .max(binary_prec.saturating_add(64))
        .saturating_add(pole_guard);
    let mut s_re = s.re.clone();
    let mut s_im = s.im.clone();
    s_re.set_prec(work_prec);
    s_im.set_prec(work_prec);
    let s = Complex::new(s_re, s_im);

    let result = if s.re.to_f64() < 0.0 {
        zeta_complex_reflection(&s, work_prec)
    } else {
        zeta_complex_hasse(&s, work_prec)
    };

    let mut re = result.re;
    let mut im = result.im;
    re.set_prec(binary_prec);
    im.set_prec(binary_prec);
    Complex::new(re, im)
}

fn zeta_complex_reflection(s: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    let zero = Float::new(binary_prec);
    let one = Float::with_val(binary_prec, 1);
    let two = Float::with_val(binary_prec, 2);
    let pi = Float::with_val(binary_prec, Constant::Pi);

    let one_c = Complex::new(one.clone(), zero.clone());
    let two_c = Complex::new(two, zero.clone());
    let pi_c = Complex::new(pi.clone(), zero.clone());
    let reflected = one_c.clone() - s.clone();

    let two_power = two_c.powf(s);
    let pi_power = pi_c.clone().powf(&(s.clone() - one_c));
    let sine =
        (pi_c * s.clone() / Complex::new(Float::with_val(binary_prec, 2), zero.clone())).sin();
    let gamma = gamma_numeric_eval(&reflected, binary_prec);
    #[cfg(feature = "float-mpfr")]
    let zeta = if reflected.im.is_fully_zero() {
        Complex::new(reflected.re.clone().into_raw().zeta().into(), zero.clone())
    } else {
        zeta_complex_hasse(&reflected, binary_prec)
    };

    #[cfg(not(feature = "float-mpfr"))]
    let zeta = zeta_complex_hasse(&reflected, binary_prec);

    two_power * pi_power * sine * gamma * zeta
}

fn zeta_complex_hasse(s: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    let zero = Float::new(binary_prec);
    let one = Float::with_val(binary_prec, 1);
    let two = Float::with_val(binary_prec, 2);
    let one_c = Complex::new(one.clone(), zero.clone());
    let two_c = Complex::new(two.clone(), zero.clone());

    let denominator = one_c.clone() - two_c.powf(&(one_c - s.clone()));
    // The caller supplies at least twice the required output precision.
    // Keep convergence tests in arbitrary precision, including beyond the
    // f64 exponent range, and reserve half the bits for cancellation.
    let threshold = binary_series_threshold(binary_prec / 2);
    if complex_l1_norm(&denominator) < threshold {
        tracing::warn!("zeta: Hasse denominator is ill-conditioned; numerical evaluation declined");
        return Complex::new(Float::with_val(binary_prec, f64::NAN), zero);
    }
    let mut outer = Complex::new(zero.clone(), zero.clone());
    let mut small_terms = 0;
    let mut two_power = Float::with_val(binary_prec, 2);
    let mut inverse_powers = Vec::new();
    let integer_order = complex_float_to_integer(s);

    for n in 0..(8 * binary_prec.max(16)) {
        // Each (k+1)^(-s) occurs in every subsequent row. Computing it once
        // removes the quadratic number of arbitrary-precision log/exp calls,
        // especially costly in the portable/WASM backend.
        let base = Float::with_val(binary_prec, n + 1);
        let inverse_power = if let Some(order) = integer_order {
            let power = base.pow(order.unsigned_abs());
            Complex::new(
                if order < 0 {
                    power
                } else {
                    one.clone() / power
                },
                zero.clone(),
            )
        } else if s.im.is_fully_zero() {
            Complex::new(base.powf(&(-s.re.clone())), zero.clone())
        } else {
            Complex::new(base, zero.clone()).powf(&(-s.clone()))
        };
        inverse_powers.push(inverse_power);
        let mut inner = Complex::new(zero.clone(), zero.clone());
        let mut binom = Float::with_val(binary_prec, 1);

        for k in 0..=n {
            let mut term = inverse_powers[k as usize].clone() * binom.clone();
            if k % 2 == 1 {
                term = -term;
            }
            inner += term;

            if k < n {
                binom *= Float::with_val(binary_prec, n - k);
                binom /= Float::with_val(binary_prec, k + 1);
            }
        }

        let term = inner / Complex::new(two_power.clone(), zero.clone());
        let term_size = complex_l1_norm(&term);
        outer += term;
        if n > 16 && term_size < complex_l1_norm(&outer) * &threshold {
            small_terms += 1;
        } else {
            small_terms = 0;
        }
        if small_terms == 4 {
            return outer / denominator;
        }

        two_power *= Float::with_val(binary_prec, 2);
    }

    tracing::warn!(
        binary_precision = binary_prec,
        "zeta: series did not converge; numerical evaluation declined"
    );
    Complex::new(
        Float::with_val(binary_prec, f64::NAN),
        Float::with_val(binary_prec, f64::NAN),
    )
}

fn gamma_complex_spouge(z: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    // Coefficient cancellation needs guard bits. Complex gamma can be
    // exponentially small in |Im(z)|; increase the approximation order too.
    let imaginary = z.im.to_f64().abs();
    let gap = match (z.re.as_raw().get_exp(), z.im.as_raw().get_exp()) {
        (Some(a), Some(b)) => a.abs_diff(b),
        _ => 0,
    };
    let adjusted = binary_prec
        .checked_add(gap)
        .and_then(|p| p.checked_add((3.0 * imaginary).ceil() as u32));
    let work = adjusted
        .and_then(|p| p.checked_mul(2))
        .and_then(|p| p.checked_add(64));
    if binary_prec == 0
        || !z.re.is_finite()
        || !imaginary.is_finite()
        || work.is_none_or(|p| p > 65_536)
    {
        tracing::warn!(
            "gamma: unsupported argument or working precision; numerical evaluation declined"
        );
        return Complex::new(Float::with_val(53, f64::NAN), Float::with_val(53, f64::NAN));
    }
    let work_prec = work.unwrap();
    let mut argument = z.clone();
    argument.re.set_prec(work_prec);
    argument.im.set_prec(work_prec);
    let a = spouge_parameter(adjusted.unwrap() + 32);
    let mut value = gamma_complex_spouge_work(&argument, work_prec, a);
    if !value.re.is_finite() || !value.im.is_finite() || value.is_fully_zero() {
        tracing::warn!("gamma: result exceeds the numerical range; numerical evaluation declined");
        return Complex::new(
            Float::with_val(binary_prec, f64::NAN),
            Float::with_val(binary_prec, f64::NAN),
        );
    }
    value.re.set_prec(binary_prec);
    value.im.set_prec(binary_prec);
    value
}

fn gamma_complex_spouge_work(z: &Complex<Float>, binary_prec: u32, a: u32) -> Complex<Float> {
    let zero = Float::new(binary_prec);
    let one = Float::with_val(binary_prec, 1);
    let half = Float::with_val(binary_prec, 1) / Float::with_val(binary_prec, 2);
    let pi = Float::with_val(binary_prec, Constant::Pi);

    if z.re.to_f64() < 0.5 {
        let numerator = Complex::new(pi.clone(), zero.clone());
        let pi_z = Complex::new(pi, zero.clone()) * z.clone();
        let reflected = Complex::new(one.clone(), zero.clone()) - z.clone();
        return numerator / (pi_z.sin() * gamma_complex_spouge_work(&reflected, binary_prec, a));
    }

    let mut sum = Complex::new(
        (Float::with_val(binary_prec, 2) * Float::with_val(binary_prec, Constant::Pi)).sqrt(),
        zero.clone(),
    );

    for k in 1..a {
        let coeff = spouge_coefficient(a, k, binary_prec);
        let denom = z.clone() + Complex::new(Float::with_val(binary_prec, k - 1), zero.clone());
        sum += Complex::new(coeff, zero.clone()) / denom;
    }

    let t = z.clone() + Complex::new(Float::with_val(binary_prec, a - 1), zero.clone());
    let exponent = z.clone() - Complex::new(half, zero);
    t.powf(&exponent) * (-t).exp() * sum
}

fn polygamma_order_zero_complex(z: &Complex<Float>, binary_prec: u32) -> Complex<Float> {
    polygamma_checked(0, z, binary_prec)
}

fn spouge_parameter(binary_prec: u32) -> u32 {
    ((binary_prec as f64 / (2.0 * std::f64::consts::PI).log2()).ceil() as u32).max(12) + 2
}

fn spouge_coefficient(a: u32, k: u32, binary_prec: u32) -> Float {
    let half = Float::with_val(binary_prec, 1) / Float::with_val(binary_prec, 2);
    let a_minus_k = Float::with_val(binary_prec, a - k);
    let exponent = Float::with_val(binary_prec, k) - half;
    let factorial = Float::with_integer(binary_prec, Integer::factorial(k - 1).to_multi_prec());
    let mut coeff = a_minus_k.powf(&exponent) * a_minus_k.exp() / factorial;

    if k.is_multiple_of(2) {
        coeff = -coeff;
    }

    coeff
}

// Numerical fallbacks with explicit convergence and precision checks.

const MAX_WORK_BITS: u32 = 65_536;

fn finite(z: &Complex<Float>) -> bool {
    z.re.is_finite() && z.im.is_finite()
}

fn at_precision(z: &Complex<Float>, bits: u32) -> Complex<Float> {
    let mut z = z.clone();
    z.re.set_prec(bits);
    z.im.set_prec(bits);
    z
}

fn failure(name: &str, bits: u32, reason: &str) -> Complex<Float> {
    tracing::warn!(
        function = name,
        binary_precision = bits,
        "{reason}; numerical evaluation declined"
    );
    Complex::new(
        Float::with_val(bits.clamp(1, MAX_WORK_BITS), f64::NAN),
        Float::with_val(bits.clamp(1, MAX_WORK_BITS), f64::NAN),
    )
}

fn polygamma_checked(order: u32, z: &Complex<Float>, bits: u32) -> Complex<Float> {
    let Some(work) = bits.checked_add(64).filter(|&p| p <= MAX_WORK_BITS) else {
        return failure(
            "polygamma",
            bits,
            "working precision exceeds the supported budget",
        );
    };
    if bits == 0 || !finite(z) || order > 4096 {
        return failure(
            "polygamma",
            bits,
            "unsupported argument, order, or precision",
        );
    }
    let z = at_precision(z, work);
    if z.im.is_fully_zero() && z.re <= Float::new(work) && complex_float_to_integer(&z).is_some() {
        return Complex::new(Float::with_val(bits, f64::INFINITY), Float::new(bits));
    }

    // Recurrence to the right half-plane, followed by DLMF 5.11.2/5.15.9.
    // The Euler--Maclaurin remainder after B_(2k) is bounded by the
    // magnitude of that term with z replaced by Re(z)>0. This also works
    // for complex z; checking the actual next complex term alone does not.
    let cutoff = Float::with_val(work, (bits + order) / 2 + 16);
    let mut shifted = z;
    let mut correction = Complex::new(Float::new(work), Float::new(work));
    let mut magnitude = Float::new(work);
    let max_shifts = 8 * work + 1024;
    if cutoff.clone() - &shifted.re > Float::with_val(work, max_shifts) {
        return failure(
            "polygamma",
            bits,
            "argument recurrence exceeds the supported budget",
        );
    }
    let mut shifts = 0;
    while shifted.re < cutoff {
        if shifts == max_shifts {
            return failure(
                "polygamma",
                bits,
                "argument recurrence exceeds the supported budget",
            );
        }
        let inv = shifted.inv();
        let term = if order == 0 {
            -inv
        } else {
            pow_complex_u32(&inv, order + 1)
        };
        magnitude += complex_l1_norm(&term);
        correction += term;
        shifted += complex_one(work);
        shifts += 1;
    }

    let inv = shifted.inv();
    let inv_sq = inv.clone() * inv.clone();
    let inv_re = Float::with_val(work, 1) / shifted.re.clone();
    let inv_re_sq = inv_re.clone() * inv_re.clone();
    let mut power = if order == 0 {
        inv_sq.clone()
    } else {
        pow_complex_u32(&inv, order) * inv_sq.clone()
    };
    let mut bound_power = inv_re.pow(u64::from(order) + 2);
    let mut sum = if order == 0 {
        shifted.log() - inv.clone() / Float::with_val(work, 2)
    } else {
        pow_complex_u32(&inv, order) / Float::with_val(work, order)
            + pow_complex_u32(&inv, order + 1) / Float::with_val(work, 2)
    };
    magnitude += complex_l1_norm(&sum);
    let mut rising = Float::with_val(work, order + 1);
    let mut factorial = Float::with_val(work, 2);
    let tolerance = binary_series_threshold(bits + 8);
    let round_unit = binary_series_threshold(work - 8);

    for k in 1..=bits + 32 {
        let bernoulli = bernoulli_number(2 * k).to_multi_prec_float(work);
        let coefficient = if order == 0 {
            -bernoulli / Float::with_val(work, 2 * k)
        } else {
            bernoulli * &rising / &factorial
        };
        let term = power.clone() * coefficient.clone();
        magnitude += complex_l1_norm(&term);
        sum += term;
        let total = sum.clone() + correction.clone();
        let remainder = coefficient.norm() * bound_power.clone();
        let roundoff = magnitude.clone() * &round_unit * Float::with_val(work, shifts + k + 1);
        if remainder + roundoff <= complex_l1_norm(&total) * &tolerance {
            let result = if order == 0 {
                total
            } else {
                let factor = factorial_float(order, work);
                total * if order % 2 == 0 { -factor } else { factor }
            };
            if finite(&result) {
                return at_precision(&result, bits);
            }
            break;
        }
        power *= inv_sq.clone();
        bound_power *= &inv_re_sq;
        rising *= Float::with_val(work, order + 2 * k) * Float::with_val(work, order + 2 * k + 1);
        factorial *= Float::with_val(work, 2 * k + 1) * Float::with_val(work, 2 * k + 2);
    }
    failure(
        "polygamma",
        bits,
        "remainder or roundoff exceeds the requested accuracy",
    )
}

fn bessel_checked(
    name: &str,
    order: &Complex<Float>,
    z: &Complex<Float>,
    bits: u32,
    evaluator: fn(&Complex<Float>, &Complex<Float>, u32) -> Option<Complex<Float>>,
) -> Option<Complex<Float>> {
    let fail = |reason| {
        failure(name, bits, reason);
        None
    };
    if bits == 0 || bits > MAX_WORK_BITS / 4 || !finite(order) || !finite(z) {
        return fail("unsupported argument, order, or precision");
    }
    if z.is_fully_zero() {
        return evaluator(order, z, bits);
    }
    // On the positive real axis the K expansion has a first-omitted-term
    // bound. Use it only if that bound achieves the requested accuracy.
    if name == "bessel_k"
        && let Some(value) = bessel_k_asymptotic(order, z, bits)
    {
        return Some(value);
    }
    let radius = z.re.to_f64().abs() + z.im.to_f64().abs();
    let order_size = order.re.to_f64().abs() + order.im.to_f64().abs();
    if !radius.is_finite() || !order_size.is_finite() || radius > 8192.0 || order_size > 4096.0 {
        return fail("series would require excessive cancellation guard bits");
    }
    // K's I_-nu - I_nu formula loses about 2*|Re(z)|/ln(2) bits;
    // J's alternating power series can also have exponentially large terms.
    let gap = |z: &Complex<Float>| match (z.re.as_raw().get_exp(), z.im.as_raw().get_exp()) {
        (Some(a), Some(b)) => a.abs_diff(b),
        _ => 0,
    };
    let Some(mut work) = bits
        .checked_add(64 + (4.0 * radius + 2.0 * order_size).ceil() as u32)
        .and_then(|p| p.checked_add(gap(z).max(gap(order))))
        .filter(|&p| p < MAX_WORK_BITS / 4)
    else {
        return fail("working precision exceeds the supported budget");
    };
    let mut previous = None;
    for _ in 0..4 {
        let value = evaluator(&at_precision(order, work), &at_precision(z, work), work);
        if let Some(value) = value.filter(finite) {
            if let Some(old) = previous {
                let error = complex_l1_norm(&(value.clone() - old));
                let scale = complex_l1_norm(&value);
                if !scale.is_fully_zero() && error <= scale * binary_series_threshold(bits + 8) {
                    return Some(at_precision(&value, bits));
                }
            }
            previous = Some(value);
        }
        work = work.checked_add((work / 2).max(64))?;
        if work >= MAX_WORK_BITS / 4 {
            break;
        }
    }
    fail("series did not converge to a stable result at the requested precision")
}

fn bessel_k_asymptotic(
    order: &Complex<Float>,
    z: &Complex<Float>,
    bits: u32,
) -> Option<Complex<Float>> {
    if !order.im.is_fully_zero() || !z.im.is_fully_zero() || z.re <= Float::with_val(bits, 32) {
        return None;
    }
    let work = bits + 64;
    let nu = at_precision(order, work).re;
    let x = at_precision(z, work).re;
    let mu = nu.clone() * nu.clone() * 4;
    let mut term = Float::with_val(work, 1);
    let mut sum = term.clone();
    let mut previous_size = term.clone();
    let tolerance = binary_series_threshold(bits + 16);
    for k in 1..=2 * bits + 64 {
        let odd = Float::with_val(work, 2 * k - 1);
        term *= (mu.clone() - odd.clone() * odd) / (x.clone() * Float::with_val(work, 8 * k));
        let size = term.norm();
        // DLMF 10.40(ii): for real nu and x>0, after k>|nu|-1/2
        // the remainder is bounded by the first omitted term.
        if Float::with_val(work, k) > nu.norm() + 1 && size <= sum.norm() * &tolerance {
            let prefactor =
                (Float::with_val(work, Constant::Pi) / (x.clone() * 2)).sqrt() * (-x).exp();
            let result = sum * prefactor;
            if !result.is_finite() || result <= Float::new(work) {
                return None;
            }
            return Some(at_precision(&Complex::new(result, Float::new(work)), bits));
        }
        if k > 1 && size > previous_size {
            return None;
        }
        previous_size = size;
        sum += term.clone();
    }
    None
}

fn bessel_k_integer_series(n: u32, z: &Complex<Float>, bits: u32) -> Option<Complex<Float>> {
    // DLMF 10.31.1. Avoid a finite difference in the order at integer nu.
    // The caller supplies cancellation guard bits and checks stability.
    let half = z.clone() / Float::with_val(bits, 2);
    let half_sq = half.clone() * half.clone();
    let mut sum = Complex::new(Float::new(bits), Float::new(bits));
    if n > 0 {
        let mut term = pow_complex_u32(&half.inv(), n)
            * (factorial_float(n - 1, bits) / Float::with_val(bits, 2));
        sum += term.clone();
        for k in 1..n {
            term *= -half_sq.clone() / (Float::with_val(bits, k) * Float::with_val(bits, n - k));
            sum += term.clone();
        }
    }
    let log = half.log() + Complex::new(Float::with_val(bits, Constant::Euler), Float::new(bits));
    let mut power = pow_complex_u32(&half, n) / factorial_float(n, bits);
    if n % 2 == 1 {
        power = -power;
    }
    let mut h_k = Float::new(bits);
    let mut h_nk = harmonic_rational(n).to_multi_prec_float(bits);
    let tolerance = binary_series_threshold(bits);
    let radius_sq = half.norm_squared();
    let mut small_terms = 0;
    for k in 0..16 * bits.max(16) {
        let coefficient = Complex::new(
            (h_k.clone() + &h_nk) / Float::with_val(bits, 2),
            Float::new(bits),
        ) - log.clone();
        let term = power.clone() * coefficient;
        let size = complex_l1_norm(&term);
        sum += term;
        let denominator = Float::with_val(bits, k + 1) * Float::with_val(bits, n + k + 1);
        if radius_sq.clone() * 2 < denominator && size <= complex_l1_norm(&sum) * &tolerance {
            small_terms += 1;
            if small_terms >= 2 {
                return Some(sum);
            }
        } else {
            small_terms = 0;
        }
        power *= half_sq.clone() / denominator;
        h_k += Float::with_val(bits, 1) / Float::with_val(bits, k + 1);
        h_nk += Float::with_val(bits, 1) / Float::with_val(bits, n + k + 1);
    }
    None
}

fn erf_checked(z: &Complex<Float>, bits: u32) -> Complex<Float> {
    if bits == 0 || bits > MAX_WORK_BITS / 2 || !finite(z) {
        return failure("erf", bits, "unsupported argument or precision");
    }
    if z.is_fully_zero() {
        return z.clone();
    }
    if z.re < Float::new(bits) {
        return -erf_checked(&(-z.clone()), bits);
    }
    let preliminary = bits + 64;
    let argument = at_precision(z, preliminary);
    // For real x>0, erfc(x) < exp(-x^2)/(x*sqrt(pi)). If this
    // is below half an output ulp, erf(x) rounds to one directly.
    if z.im.is_fully_zero() && z.re > Float::with_val(bits, 1) {
        let x = argument.re.clone();
        let bound =
            (-(x.clone() * &x)).exp() / (x * Float::with_val(preliminary, Constant::Pi).sqrt());
        if bound < binary_series_threshold(bits + 8) {
            return complex_one(bits);
        }
    }
    let radius = z.re.to_f64().abs() + z.im.to_f64().abs();
    let guard = (2.0 * radius * radius).ceil();
    if !guard.is_finite() || guard > f64::from(MAX_WORK_BITS / 2) {
        return failure(
            "erf",
            bits,
            "series would require excessive cancellation guard bits",
        );
    }
    let work = bits + 64 + guard as u32;
    let z = at_precision(z, work);
    let square = z.clone() * z.clone();
    let radius_squared = square.norm().re;
    let mut term = z;
    let mut sum = term.clone();
    let mut magnitude = complex_l1_norm(&term);
    let tolerance = binary_series_threshold(bits + 8);
    let round_unit = binary_series_threshold(work - 8);
    for n in 0..16 * work {
        term = -term * square.clone() * Float::with_val(work, 2 * n + 1)
            / (Float::with_val(work, n + 1) * Float::with_val(work, 2 * n + 3));
        let size = complex_l1_norm(&term);
        magnitude += &size;
        sum += term.clone();
        let ratio = radius_squared.clone() / Float::with_val(work, n + 2);
        if ratio < Float::with_val(work, 0.5) {
            let tail = size * ratio.clone() / (Float::with_val(work, 1) - ratio);
            let rounding = magnitude.clone() * &round_unit * Float::with_val(work, n + 2);
            if tail + rounding < complex_l1_norm(&sum) * &tolerance {
                let result =
                    sum * (Float::with_val(work, 2) / Float::with_val(work, Constant::Pi).sqrt());
                if finite(&result) {
                    return at_precision(&result, bits);
                }
                break;
            }
        }
    }
    failure(
        "erf",
        bits,
        "remainder or roundoff exceeds the requested accuracy",
    )
}

#[cfg(test)]
mod tests {
    #[cfg(feature = "float-mpfr")]
    use super::{
        Constant, complex_one, complex_pi, polylog_integer_numeric_eval, polylog_numeric_eval,
        polylog_series_integer,
    };
    use crate::domains::float::FloatLike;

    use ahash::HashMap;

    use std::{
        io::Write,
        process::{Command, Stdio},
    };

    use crate::{
        atom::{Atom, AtomCore},
        coefficient::Coefficient,
        domains::float::{Complex, Float, Real, RealLike},
        parse, symbol,
    };

    #[test]
    fn root_factor() {
        let mut roots = vec![];
        for x in 0..7 {
            let p = parse!(format!("root((x^3+3)(x^4+4), {x})"));
            roots.push(p);
        }

        let mut last = -1.5;
        for root in &roots {
            let v = Complex::<f64>::try_from(root.to_float(16)).unwrap();
            assert!(last <= v.re);
            last = v.re;
        }

        assert_eq!(roots[0], parse!("root(3+x^3,0)"));
        assert_eq!(roots[1], parse!("-1-1i"));
        assert_eq!(roots[2], parse!("-1+1i"));
        assert_eq!(roots[3], parse!("root(3+x^3,1)"));
        assert_eq!(roots[4], parse!("root(3+x^3,2)"));
        assert_eq!(roots[5], parse!("1-1i"));
        assert_eq!(roots[6], parse!("1+1i"));

        assert_eq!(parse!("root((1+x)^2*(2+x),1)"), parse!("-1"));
        assert_eq!(parse!("root((1+x)^2*(2+x),2)"), parse!("-1"));
    }

    #[test]
    fn root_factor_preserves_canonical_conjugate_indices() {
        let roots = (0..4)
            .map(|index| parse!(format!("root(((x-1)^2+100)*((x-1)^2+81),{index})")))
            .collect::<Vec<_>>();

        assert_eq!(
            roots,
            vec![
                parse!("1-10i"),
                parse!("1-9i"),
                parse!("1+9i"),
                parse!("1+10i"),
            ]
        );
    }

    #[test]
    fn gamma_exact_normalization() {
        assert_eq!(parse!("gamma(5)"), Atom::num(24));
        assert_eq!(parse!("gamma(1/2)"), parse!("pi^(1/2)"));
        assert_eq!(parse!("gamma(-5/2)"), parse!("-8/15*pi^(1/2)"));
        // The backends round the decimal input at different storage widths.
        // Compare accuracy at the input precision, not bitwise identity to a
        // rounded decimal reference.
        let value = Complex::<Float>::try_from(parse!("gamma(0.3)")).unwrap();
        assert!((value.re.to_f64() - 2.991568987687591).abs() < 1e-15);
        assert!(value.im.is_fully_zero());
        assert_eq!(
            parse!("gamma(0)"),
            Atom::num(Coefficient::complex_infinity())
        );
    }

    #[test]
    fn gamma_derivative() {
        assert_eq!(
            parse!("gamma(x)").derivative(symbol!("x")),
            parse!("gamma(x)*polygamma(0,x)")
        );
    }

    #[test]
    fn root_derivative_is_zero() {
        assert_eq!(parse!("root(x^2-2,1)").derivative(symbol!("x")), Atom::Zero);
    }

    #[test]
    fn root_evaluator_uses_complex_root_isolation() {
        let direct_value = parse!("root(x^2-2,1)")
            .evaluate_with_prec(&HashMap::<Atom, Float>::default(), 128)
            .unwrap();
        assert!((direct_value.to_f64() - 2f64.sqrt()).abs() < 1e-12);

        let params: Vec<Atom> = vec![];
        let mut real_root = parse!("root(x^2-2,1)")
            .evaluator(&params)
            .build()
            .unwrap()
            .map_coeff(&|x| x.re.to_f64());
        let real_value = real_root.evaluate_single(&[]);
        assert!((real_value - 2f64.sqrt()).abs() < 1e-12);

        let mut complex_root = parse!("root(x^2+1,1)")
            .evaluator(&params)
            .build()
            .unwrap()
            .map_coeff(&|x| Complex::new(x.re.to_f64(), x.im.to_f64()));
        let complex_value = complex_root.evaluate_single(&[]);
        assert!(complex_value.re.abs() < 1e-12);
        assert!((complex_value.im - 1.).abs() < 1e-12);

        let imaginary_value =
            Complex::<Float>::try_from(parse!("root(x^2+1,1)").to_float(53)).unwrap();
        assert_eq!(imaginary_value.re, Float::new(53));
        assert!((imaginary_value.im.to_f64() - 1.).abs() < 1e-12);

        let complex_coefficient_value =
            Complex::<Float>::try_from(parse!("root(x-(1+1i),0)").to_float(80)).unwrap();
        assert!((complex_coefficient_value.re.to_f64() - 1.).abs() < 1e-12);
        assert!((complex_coefficient_value.im.to_f64() - 1.).abs() < 1e-12);
    }

    #[test]
    fn root_evaluator_refines_to_requested_precision() {
        let value = parse!("root(x^2-2,1)")
            .evaluate_with_prec(&HashMap::<Atom, Float>::default(), 192)
            .unwrap();
        assert!(value.prec() >= 192);
        let mut residual = value.clone() * value - Float::with_val(192, 2);
        if residual.is_negative() {
            residual = -residual;
        }

        // Cancellation reduces the residual's tracked significant precision;
        // the requested precision applies to the root, checked above.
        assert!(residual.to_f64() < 2f64.powi(-150));
    }

    #[test]
    fn root_simplifies_algebraic_coefficients() {
        assert_eq!(
            parse!("root(1-1/2*12^(1/2)+z^3,0)"),
            parse!("root(root_var^6+2*root_var^3-2,1)")
        );
        assert_eq!(
            parse!("root(1-1/2*12^(1/2)+z^3,1)"),
            parse!("root(root_var^6+2*root_var^3-2,2)")
        );
        assert_eq!(
            parse!("root(1-1/2*12^(1/2)+z^3,2)"),
            parse!("root(root_var^6+2*root_var^3-2,3)")
        );
        assert_eq!(parse!("root((z-2^(1/2))^2,0)"), parse!("1/2*8^(1/2)"));
        assert_eq!(parse!("root((z-2^(1/2))^2,1)"), parse!("1/2*8^(1/2)"));
        assert_eq!(parse!("root((z-2^(1/2))*(z-1),0)"), parse!("1"));
        assert_eq!(parse!("root((z-2^(1/2))*(z-1),1)"), parse!("1/2*8^(1/2)"));
        assert_eq!(
            parse!("root(z^2-2^(1/2),0)"),
            parse!("root(-2+root_var^4,0)")
        );
        assert_eq!(
            parse!("root(z^2-2^(1/2),1)"),
            parse!("root(-2+root_var^4,1)")
        );
        assert_eq!(
            parse!("root(z-2^(1/2)-3^(1/2),0)"),
            parse!("root(1-10*root_var^2+root_var^4,3)")
        );
        assert_eq!(parse!("root(z-(1+1i),0)"), parse!("1+1i"));
        assert_eq!(
            parse!("root((1+x)^2*(2^(1/2)+x^4),3)"),
            parse!("root(-2+root_var^8,3)")
        );
    }

    #[test]
    fn root_simplifies_parametric_quadratic() {
        assert_eq!(parse!("root(-a+z^2,0)"), parse!("-a^(1/2)"));
        assert_eq!(parse!("root(-a+z^2,1)"), parse!("a^(1/2)"));
        assert_eq!(parse!("root(x^2-a-1,x,0)"), parse!("-(1+a)^(1/2)"));
        assert_eq!(parse!("root(x^2-a^3-1,x,0)"), parse!("-(1+a^3)^(1/2)"));
    }

    #[test]
    fn root_does_not_guess_between_multiple_symbols() {
        for ambiguous in [parse!("root(x^2-a,0)"), parse!("root(x^2-a,2)")] {
            assert!(ambiguous.contains_symbol(symbol!("x")));
            assert!(ambiguous.contains_symbol(symbol!("a")));
            assert!(!ambiguous.contains_symbol(super::root_var()));
        }
    }

    #[test]
    fn parametric_cubic_selects_real_root_after_specialization() {
        for index in 0..3 {
            let root = parse!(format!("root(x^3-a,x,{index})"));
            assert_eq!(root, parse!(format!("root(root_var^3-a,{index})")));
            for value in [-8, 0, 8] {
                assert_eq!(
                    root.replace(symbol!("a")).with(Atom::num(value)),
                    parse!(format!("root(x^3-({value}),{index})"))
                );
            }
        }
        let real_root = parse!("root(x^3-a,x,0)");
        assert_eq!(
            real_root.replace(symbol!("a")).with(Atom::num(-8)),
            Atom::num(-2)
        );
        assert_eq!(
            real_root.replace(symbol!("a")).with(Atom::num(8)),
            Atom::num(2)
        );
        assert_eq!(
            parse!("root(x^2-a^3-1,a,2)"),
            parse!("root(x^2-root_var^3-1,2)")
        );
    }

    #[test]
    fn parametric_quadratic_preserves_specialized_order() {
        // The branches x=a and x=-a exchange ranks at a=0.
        let root = parse!("root(x^2-a^2,x,0)");
        for value in [-2, 2] {
            assert_eq!(
                root.replace(symbol!("a")).with(Atom::num(value)),
                Atom::num(-2)
            );
        }

        // A complex shift can make either quadratic branch the real root.
        // An unconditional minus-discriminant formula would choose -i here.
        let root = parse!("root(x^2+a*x-1,x,0)");
        assert_eq!(root, parse!("root(root_var^2+a*root_var-1,0)"));
        assert_eq!(root.replace(symbol!("a")).with(Atom::num(0)), Atom::num(-1));
        let shifted = parse!("root(x^2+a*x+b,x,0)");
        let specialized = shifted
            .replace(symbol!("a"))
            .with(parse!("-1+1i"))
            .replace(symbol!("b"))
            .with(parse!("-1i"));
        assert_eq!(specialized, Atom::num(1));
    }

    #[test]
    fn parametric_quadratic_simplifies_with_real_midpoint() {
        let _ = symbol!("root_real_linear"; Real);
        let root = parse!("root(x^2-root_real_linear*x-a,x,0)");
        assert_eq!(
            root,
            parse!("(root_real_linear-sqrt(root_real_linear^2+4*a))/2").expand()
        );
        // Normalize the leading coefficient before taking the square root.
        assert_eq!(parse!("root(-x^2+root_real_linear*x+a,x,0)"), root);
        for value in [-3, 0, 3] {
            for constant in [-2, 0, 2] {
                let specialized = root
                    .replace(symbol!("root_real_linear"))
                    .with(Atom::num(value))
                    .replace(symbol!("a"))
                    .with(Atom::num(constant));
                assert_eq!(
                    specialized,
                    parse!(format!("root(x^2-({value})*x-({constant}),0)"))
                );
            }
        }
    }

    #[test]
    fn parametric_real_root_rank_ignores_complex_real_parts() {
        let root = parse!("root((x-a)*((x+1)^2+1),x,0)");
        for value in [-2, -1, 0, 2] {
            assert_eq!(
                root.replace(symbol!("a")).with(Atom::num(value)),
                Atom::num(value)
            );
        }
    }

    #[test]
    fn root_accepts_an_explicit_polynomial_variable() {
        assert_eq!(parse!("root(x^5-2,x,0)"), parse!("root(root_var^5-2,0)"));
        assert_eq!(parse!("root(x^5-a,x,0)"), parse!("root(root_var^5-a,0)"));
        assert_eq!(
            parse!("root(x^5-a,x,0)")
                .replace(symbol!("a"))
                .with(Atom::num(2)),
            parse!("root(x^5-2,0)")
        );
    }

    #[test]
    fn root_canonicalizes_the_variable_with_an_invalid_index() {
        assert_eq!(parse!("root(-4+x^3,3)"), parse!("root(-4+root_var^3,3)"));
    }

    #[test]
    fn root_to_float_degree_ten_regression() {
        let root = parse!("root(x^10+x^7-3,3)").to_float(53);
        let value = Complex::<Float>::try_from(root).unwrap();

        assert!(value.re.is_finite());
        assert!(value.im.is_finite());
    }

    #[test]
    fn root_to_float_degree_ten_complex_coefficients_regression() {
        let root = parse!("root(x^10+(2+1i)*x^7-3,3)").to_float(100);
        let value = Complex::<Float>::try_from(root).unwrap();

        assert!(value.re.is_finite());
        assert!(value.im.is_finite());
    }

    #[test]
    fn root_to_float_degree_ten_conjugate_sort_regression() {
        let root = parse!("root(x^10+3*x^7-3,1)").to_float(100);
        let value = Complex::<Float>::try_from(root).unwrap();

        assert!(value.re.is_finite());
        assert!(value.im.is_finite());
    }

    #[test]
    fn erf_basic_normalization() {
        assert_eq!(parse!("erf(0)"), Atom::new());
        assert_eq!(parse!("erf(-x)"), parse!("-erf(x)"));

        let actual = Complex::<Float>::try_from(parse!("erf(1)").to_float(80)).unwrap();
        let expected = Complex::new(
            Float::parse("0.84270079294971486934", Some(80)).unwrap(),
            Float::new(80),
        );
        assert_close_complex(&actual, &expected, "1e-20");
    }

    #[test]
    fn erf_derivative() {
        assert_eq!(
            parse!("erf(x)").derivative(symbol!("x")),
            parse!("2*exp(-x^2)/sqrt(pi)")
        );
    }

    #[test]
    fn gamma_laurent_series() {
        let x = symbol!("x");
        assert_eq!(
            parse!("gamma(x)").series(x, 0, 3).unwrap().to_atom(),
            parse!(
                "-euler_gamma+1/2*x*(euler_gamma^2+1/6*𝜋^2)+1/6*x^2*(-euler_gamma*(euler_gamma^2+1/6*𝜋^2)+polygamma(2,1)-1/3*𝜋^2*euler_gamma)+1/24*x^3*(-2*euler_gamma*polygamma(2,1)-euler_gamma*(polygamma(2,1)-1/3*𝜋^2*euler_gamma)-euler_gamma*(-euler_gamma*(euler_gamma^2+1/6*𝜋^2)+polygamma(2,1)-1/3*𝜋^2*euler_gamma)+1/6*𝜋^2*(euler_gamma^2+1/6*𝜋^2)+11/90*𝜋^4)+1/x"
            )
        );
        assert_eq!(
            parse!("gamma(x)").series(x, 0, 0).unwrap().to_atom(),
            parse!("x^-1-euler_gamma")
        );

        assert_eq!(
            parse!("gamma(x-1)").series(x, 1, 0).unwrap().to_atom(),
            parse!("(x-1)^-1-euler_gamma")
        );
    }

    #[test]
    fn gamma_complex_matches_ginac() {
        if Command::new("ginsh").arg("--help").output().is_err() {
            return;
        }

        let complex_expected = ginsh_gamma("0.5+0.25*I", 50);
        let complex_actual =
            Complex::<Float>::try_from(parse!("gamma(1/2+1i/4)").to_float(50)).unwrap();
        assert_close_complex(&complex_actual, &complex_expected, "1e-36");
    }

    #[test]
    fn polygamma_order_zero_exact_normalization() {
        assert_eq!(parse!("polygamma(0,1)"), parse!("-euler_gamma"));
        assert_eq!(parse!("polygamma(0,1/2)"), parse!("-euler_gamma-2*log(2)"));
        assert_eq!(
            parse!("polygamma(0,5/2)"),
            parse!("8/3-euler_gamma-2*log(2)")
        );
        assert_eq!(
            parse!("polygamma(0,0)"),
            Atom::num(Coefficient::complex_infinity())
        );
    }

    #[test]
    fn polygamma_positive_integer_exact_normalization() {
        for (input, expected) in [
            ("polygamma(1,1)", "pi^2/6"),
            ("polygamma(2,1)", "-2*zeta(3)"),
            ("polygamma(3,1)", "pi^4/15"),
            ("polygamma(4,1)", "-24*zeta(5)"),
            ("polygamma(5,1)", "8*pi^6/63"),
            ("polygamma(6,1)", "-720*zeta(7)"),
            ("polygamma(1,2)", "pi^2/6-1"),
            ("polygamma(2,2)", "2-2*zeta(3)"),
            ("polygamma(3,3)", "pi^4/15-51/8"),
            ("polygamma(65,1)", "gamma(66)*zeta(66)"),
            ("polygamma(66,1)", "-gamma(67)*zeta(67)"),
        ] {
            assert_eq!(parse!(input), parse!(expected));
        }
        for order in 1..=8 {
            for argument in [1, 2, 3, 4, 5, 65, 100] {
                let difference = parse!(format!(
                    "polygamma({order},{})-polygamma({order},{argument})",
                    argument + 1
                ));
                let recurrence = parse!(format!(
                    "(-1)^{order}*gamma({})/{argument}^{}",
                    order + 1,
                    order + 1
                ));
                assert!((difference - recurrence).expand().is_zero());
            }
        }
    }

    #[test]
    fn polygamma_exact_normalization_respects_domain_and_integer_ranges() {
        let native = super::polygamma();
        for input in [
            "polygamma(64,64)",
            "polygamma(65,1)",
            "polygamma(1,65)",
            "polygamma(2,100)",
        ] {
            assert!(!parse!(input).contains_symbol(native), "{input}");
        }
        for input in [
            "polygamma(4294967295,1)",
            "polygamma(1,1000000000000000000000000000000)",
            "polygamma(-1,1)",
            "polygamma(1/2,1)",
            "polygamma(2,1/2)",
            "polygamma(2,1+1i)",
            "polygamma(2,x)",
        ] {
            assert!(parse!(input).contains_symbol(native), "{input}");
        }
        for input in ["polygamma(2,0)", "polygamma(2,-1)"] {
            assert_eq!(parse!(input), Atom::num(Coefficient::complex_infinity()));
        }
        assert_eq!(parse!("polygamma(0,1/2)"), parse!("-euler_gamma-2*log(2)"));
    }

    #[test]
    fn gamma_series_uses_native_zeta_after_integer_normalization() {
        let x = symbol!("x");
        let series = parse!("log(gamma(1+x))").series(x, 0, 5).unwrap();
        assert_eq!(
            series.coefficient(3.into()).unwrap().expand(),
            parse!("-zeta(3)/3")
        );
        assert_eq!(
            series.coefficient(5.into()).unwrap().expand(),
            parse!("-zeta(5)/5")
        );
        assert!(!series.to_atom().contains_symbol(super::polygamma()));
    }

    #[test]
    #[cfg(feature = "float-mpfr")]
    fn integer_zeta_dispatch_preserves_special_values_and_precision() {
        use crate::domains::backend::float::MultiPrecisionFloat;

        for bits in [128, 512, 66_705] {
            for order in [0_u32, 1, 2, 3, 5, 97] {
                let input = Complex::new(Float::with_val(bits, order), Float::new(bits));
                let actual = super::zeta_numeric_eval(&input, bits);
                let expected: Float =
                    MultiPrecisionFloat::with_val(bits, MultiPrecisionFloat::zeta_u(order)).into();
                assert_eq!(actual.re, expected);
                assert!(actual.im.is_fully_zero());
                if order != 1 {
                    assert!(actual.re.is_finite());
                    assert!(actual.re.prec() >= bits);
                }
            }
        }
    }

    #[test]
    #[cfg(feature = "float-mpfr")]
    fn zeta_near_integers_and_negative_reals_retain_general_evaluation() {
        let bits = 512;
        let delta = Float::with_val(bits, 2).pow(120).inv();
        for value in [
            Float::with_val(bits, 3) + &delta,
            Float::with_val(bits, 3) - &delta,
            Float::with_val(bits, -1),
            Float::with_val(bits, -2),
            Float::with_val(bits, -3),
        ] {
            let input = Complex::new(value.clone(), Float::new(bits));
            let actual = super::zeta_numeric_eval(&input, bits);
            let expected: Float = value.into_raw().zeta().into();
            assert_eq!(actual.re, expected);
            assert!(actual.im.is_fully_zero());
            if input.re > Float::new(bits) {
                let integer = super::zeta_integer_numeric_eval(3, bits);
                assert_ne!(actual.re, integer.re);
            }
        }
    }

    #[test]
    fn polygamma_order_zero_numeric_recurrence() {
        let lhs = Complex::<Float>::try_from(
            (parse!("polygamma(0,3/2+1i/4)") - parse!("polygamma(0,1/2+1i/4)")).to_float(50),
        )
        .unwrap();
        let rhs = Complex::<Float>::try_from(parse!("1/(1/2+1i/4)").to_float(50)).unwrap();

        assert_close_complex(&lhs, &rhs, "1e-30");
    }

    #[test]
    fn special_float_inputs_normalize_immediately() {
        assert!(Complex::<Float>::try_from(parse!("gamma(1.25)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("erf(1.25)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("polygamma(0,1.25)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("polygamma(1,1.25)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("zeta(1.25)")).is_ok());
    }

    #[test]
    fn polygamma_basic_normalization() {
        assert_eq!(
            parse!("polygamma(1,0)"),
            Atom::num(Coefficient::complex_infinity())
        );
        assert_eq!(
            parse!("polygamma(0,x)").derivative(symbol!("x")),
            parse!("polygamma(1,x)")
        );
        assert_eq!(
            parse!("polygamma(3,x)").derivative(symbol!("x")),
            parse!("polygamma(4,x)")
        );
    }

    #[test]
    fn polygamma_numeric_recurrence() {
        let lhs = Complex::<Float>::try_from(
            (parse!("polygamma(1,3/2+1i/4)") - parse!("polygamma(1,1/2+1i/4)")).to_float(50),
        )
        .unwrap();
        let rhs = Complex::<Float>::try_from(parse!("-1/(1/2+1i/4)^2").to_float(50)).unwrap();

        assert_close_complex(&lhs, &rhs, "1e-28");
    }

    #[test]
    fn polygamma_laurent_series() {
        let x = symbol!("x");
        assert_eq!(
            parse!("polygamma(0,x)").series(x, 0, 2).unwrap().to_atom(),
            parse!("-x^-1-euler_gamma+1/6*pi^2*x+1/2*polygamma(2,1)*x^2")
        );
        assert_eq!(
            parse!("polygamma(1,x)").series(x, 0, 2).unwrap().to_atom(),
            parse!("x^-2+1/6*pi^2+polygamma(2,1)*x+1/30*pi^4*x^2")
        );
    }

    #[test]
    fn polylog_basic_normalization() {
        assert_eq!(parse!("polylog(s,0)"), Atom::new());
        assert_eq!(parse!("polylog(0,x)"), parse!("x/(1-x)"));
        assert_eq!(parse!("polylog(-1,x)"), parse!("x/(1-x)^2"));
        assert_eq!(parse!("polylog(-2,x)"), parse!("(x+x^2)/(1-x)^3"));
        assert_eq!(parse!("polylog(1,x)"), parse!("-log(1-x)"));
        assert_eq!(parse!("polylog(2,1)"), parse!("1/6*pi^2"));
        assert_eq!(parse!("polylog(3,1)"), parse!("zeta(3)"));
        assert_eq!(parse!("polylog(1,-1)"), parse!("-log(2)"));
        assert_eq!(parse!("polylog(2,-1)"), parse!("-1/12*pi^2"));
        assert_eq!(
            parse!("polylog(3,x)").derivative(symbol!("x")),
            parse!("polylog(2,x)/x")
        );
    }

    #[test]
    fn polylog_float_normalization() {
        assert!(Complex::<Float>::try_from(parse!("polylog(2,0.5)")).is_ok());
    }

    #[test]
    fn polylog_series_at_zero() {
        let x = symbol!("x");
        assert_eq!(
            parse!("polylog(2,x)").series(x, 0, 8).unwrap().to_atom(),
            parse!("x+x^2/4+x^3/9+x^4/16+x^5/25+x^6/36+x^7/49+x^8/64")
        );
        assert_eq!(
            parse!("polylog(3,x)").series(x, 0, 5).unwrap().to_atom(),
            parse!("x+x^2/8+x^3/27+x^4/64+x^5/125")
        );
        assert_eq!(
            parse!("polylog(2,x^5)").series(x, 0, 2).unwrap().to_atom(),
            Atom::new()
        );
        assert_eq!(
            parse!("polylog(2,x)/x").series(x, 0, 4).unwrap().to_atom(),
            parse!("1+x/4+x^2/9+x^3/16+x^4/25")
        );
    }

    #[test]
    fn polylog_series_at_zero_composes_and_shifts() {
        let x = symbol!("x");
        assert_eq!(
            parse!("polylog(2,1-x)")
                .series(x, 1, 5)
                .unwrap()
                .to_atom()
                .expand(),
            parse!("-(x-1)+(x-1)^2/4-(x-1)^3/9+(x-1)^4/16-(x-1)^5/25").expand()
        );
        assert_eq!(
            parse!("polylog(2,x+x^2)")
                .series(x, 0, 4)
                .unwrap()
                .to_atom(),
            parse!("x+5*x^2/4+11*x^3/18+31*x^4/48")
        );
        assert_eq!(
            parse!("polylog(2,x^(1/2))")
                .series(x, 0, (5, 2))
                .unwrap()
                .to_atom(),
            parse!("x^(1/2)+x/4+x^(3/2)/9+x^2/16+x^(5/2)/25")
        );
    }

    #[test]
    fn polylog_series_away_from_zero_is_unchanged() {
        let x = symbol!("x");
        assert_eq!(
            parse!("polylog(2,-1+x)")
                .series(x, 0, 2)
                .unwrap()
                .to_atom()
                .expand(),
            parse!("-pi^2/12+log(2)*x+(log(2)/2-1/4)*x^2").expand()
        );
    }

    #[test]
    fn polylog_matches_ginac_off_series_region() {
        if Command::new("ginsh").arg("--help").output().is_err() {
            return;
        }

        let expected = ginsh_polylog("2", "2", 50);
        let actual = Complex::<Float>::try_from(parse!("polylog(2,2)").to_float(50)).unwrap();
        assert_close_complex(&actual, &expected, "1e-12");

        let expected = ginsh_polylog("3", "11/10", 50);
        let actual = Complex::<Float>::try_from(parse!("polylog(3,11/10)").to_float(50)).unwrap();
        assert_close_complex(&actual, &expected, "1e-24");
    }

    #[cfg(feature = "float-mpfr")]
    fn complex_l1_norm(value: &Complex<Float>) -> Float {
        value.re.norm() + value.im.norm()
    }

    #[cfg(feature = "float-mpfr")]
    fn li2(z: &Complex<Float>, bits: u32) -> Option<Complex<Float>> {
        polylog_numeric_eval(
            &Complex::new(Float::with_val(bits, 2), Float::new(bits)),
            z,
            bits,
        )
    }

    #[cfg(feature = "float-mpfr")]
    fn assert_precision_complex(
        actual: &Complex<Float>,
        expected: &Complex<Float>,
        bits: u32,
        label: &str,
    ) {
        let error = complex_l1_norm(&(actual.clone() - expected.clone()));
        let scale = if expected.is_fully_zero() {
            Float::with_val(bits, 1)
        } else {
            complex_l1_norm(expected)
        };
        let bound = scale * Float::with_val(bits, 0.5).pow(u64::from(bits - 16));
        assert!(
            error <= bound,
            "{label}: error exponent {:?}, bound exponent {:?}",
            error.as_raw().get_exp(),
            bound.as_raw().get_exp()
        );
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn polylog_thousand_digit_continuation_identities() {
        // 3456 bits exceed 1000 decimal digits; all comparisons remain MPFR.
        const BITS: u32 = 3456;
        let zero = Float::new(BITS);
        let one = Float::with_val(BITS, 1);
        let pi = Float::with_val(BITS, Constant::Pi);
        let li2 = |z: &Complex<Float>| li2(z, BITS).expect("convergent Li2");
        let i = Complex::new(zero.clone(), one.clone());
        let expected_i = Complex::new(
            -pi.clone().pow(2) / Float::with_val(BITS, 48),
            Float::with_val(BITS, Constant::Catalan),
        );
        assert_precision_complex(&li2(&i), &expected_i, BITS, "Li2(i)");
        let z = Complex::new(
            one.clone() / Float::with_val(BITS, 2),
            one.clone() / Float::with_val(BITS, 3),
        );
        let complement = complex_one(BITS) - z.clone();
        let expected = complex_pi(BITS).pow(2) / Float::with_val(BITS, 6)
            - z.clone().log() * complement.clone().log();
        assert_precision_complex(
            &(li2(&z) + li2(&complement)),
            &expected,
            BITS,
            "complex reflection",
        );
        // Exercise the inversion path, outside the Jonquiere disk.
        let large = Complex::new(Float::with_val(BITS, 100), Float::with_val(BITS, 7));
        let logarithm = (-large.clone()).log();
        let expected = -complex_pi(BITS).pow(2) / Float::with_val(BITS, 6)
            - logarithm.clone() * logarithm / Float::with_val(BITS, 2);
        assert_precision_complex(
            &(li2(&large) + li2(&large.inv())),
            &expected,
            BITS,
            "complex inversion",
        );
        // Independent precision refinement on both series/continuation paths.
        for argument in [z, i, large] {
            let actual = li2(&argument);
            let mut refined = argument;
            refined.re.set_prec(BITS + 384);
            refined.im.set_prec(BITS + 384);
            let expected = polylog_integer_numeric_eval(2, &refined, BITS + 384, 0).unwrap();
            assert_eq!(actual.re.prec(), BITS);
            assert_eq!(actual.im.prec(), BITS);
            assert_precision_complex(&actual, &expected, BITS, "precision refinement");
        }
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn polylog_thousand_digit_tiny_inputs_and_cut_sides() {
        const BITS: u32 = 3456;
        let tiny = Float::parse("1e-1000", Some(BITS)).unwrap();
        let z = Complex::new(tiny.clone(), tiny.clone() * Float::with_val(BITS, 2));
        let order = Complex::new(Float::with_val(BITS, 2), Float::new(BITS));
        let actual = polylog_numeric_eval(&order, &z, BITS).unwrap();
        // The omitted z^3/9 is far below a 3456-bit relative error here.
        let expected = z.clone() + z.clone() * z / Float::with_val(BITS, 4);
        assert!(!actual.is_fully_zero());
        assert_precision_complex(&actual, &expected, BITS, "tiny nonzero argument");

        let pi = Float::with_val(BITS, Constant::Pi);
        let log_two = Float::with_val(BITS, 2).log();
        for sign in [-1, 1] {
            let width = tiny.clone() * Float::with_val(BITS, sign);
            let negative_axis = Complex::new(Float::with_val(BITS, -1), width.clone());
            let value = polylog_integer_numeric_eval(2, &negative_axis, BITS, 0).unwrap();
            // Im Li2(-1+iy)=log(2)*y+O(y^3); unlike a normwise comparison,
            // this verifies the tiny component itself to 1000 digits.
            assert_precision_complex(
                &Complex::new(value.im, Float::new(BITS)),
                &Complex::new(log_two.clone() * &width, Float::new(BITS)),
                BITS,
                "tiny imaginary continuation",
            );
            let cut = Complex::new(Float::with_val(BITS, 2), width);
            let value = polylog_integer_numeric_eval(2, &cut, BITS, 0).unwrap();
            let expected = Complex::new(
                pi.clone().pow(2) / Float::with_val(BITS, 4)
                    - pi.clone() * &tiny / Float::with_val(BITS, 2),
                pi.clone() * &log_two * Float::with_val(BITS, sign),
            );
            assert_precision_complex(&value, &expected, BITS, "nonzero cut side");
        }
        for zero in [0.0, -0.0] {
            let axis = Complex::new(Float::with_val(BITS, 2), Float::with_val(BITS, zero));
            let value = polylog_integer_numeric_eval(2, &axis, BITS, 0).unwrap();
            assert_precision_complex(
                &value,
                &Complex::new(
                    pi.clone().pow(2) / Float::with_val(BITS, 4),
                    -pi.clone() * &log_two,
                ),
                BITS,
                "exact-real cut convention",
            );
        }
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn polylog_real_near_endpoints_matches_mpfr() {
        const BITS: u32 = 3456;
        let tiny = Float::parse("1e-1000", Some(BITS)).unwrap();
        for re in [
            Float::with_val(BITS, 1) - &tiny,
            Float::with_val(BITS, -1) + &tiny,
            Float::with_val(BITS, -1) - &tiny,
        ] {
            let expected = Complex::new(re.as_raw().clone().li2().into(), Float::new(BITS));
            let actual = li2(&Complex::new(re, Float::new(BITS)), BITS).unwrap();
            assert_precision_complex(
                &actual,
                &expected,
                BITS,
                "near endpoint, not exact endpoint",
            );
        }
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn polylog_trilog_unit_circle_skips_structural_zeros() {
        for bits in [128, 1200] {
            let pi = Float::with_val(bits, Constant::Pi);
            let zeta3: Float = crate::domains::backend::float::MultiPrecisionFloat::with_val(
                bits,
                crate::domains::backend::float::MultiPrecisionFloat::zeta_u(3),
            )
            .into();
            let expected = Complex::new(-zeta3 * 3 / 32, pi.pow(3) / 32);
            for sign in [-1, 1] {
                let argument = Complex::new(Float::new(bits), Float::with_val(bits, sign));
                let actual = polylog_integer_numeric_eval(3, &argument, bits, 0).unwrap();
                let expected = Complex::new(expected.re.clone(), expected.im.clone() * sign);
                assert_precision_complex(&actual, &expected, bits, "Li3(+/-i)");
            }
        }
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn polylog_iteration_limits_do_not_return_partial_sums() {
        let z = Complex::new(Float::with_val(128, 0.5), Float::with_val(128, 0.25));
        assert!(polylog_series_integer(2, &z, 128, 0).is_none());
        assert!(polylog_series_integer(2, &z, 128, u32::MAX).is_none());
        assert!(polylog_integer_numeric_eval(i64::MIN, &z, 128, 0).is_none());
        assert!(polylog_integer_numeric_eval(2, &z, u32::MAX, 0).is_none());
        assert!(polylog_numeric_eval(&z, &z, 0).is_none());
        assert!(polylog_numeric_eval(&z, &z, u32::MAX).is_none());
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn polylog_public_expression_thousand_digits() {
        use std::collections::HashMap;
        let expression = crate::parse!("polylog(2, polylog_precision_argument)");
        let argument = crate::parse!("polylog_precision_argument");
        const BITS: u32 = 3456;
        let input = Complex::new(Float::new(BITS), Float::with_val(BITS, 1));
        let values = HashMap::from([(argument, input)]);
        let actual: Complex<Float> = expression.evaluate_with_prec(&values, BITS).unwrap();
        let expected = Complex::new(
            -Float::with_val(BITS, Constant::Pi).pow(2) / 48,
            Float::with_val(BITS, Constant::Catalan),
        );
        assert_precision_complex(&actual, &expected, BITS, "public polylog expression");
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn polylog_fractional_order_duplication_identity() {
        // Li_s(z) + Li_s(-z) = 2^(1-s) Li_s(z^2), from the defining series.
        // Complex, nonintegral orders also exercise the geometric tail estimate.
        const BITS: u32 = 1200;
        let z = Complex::new(Float::with_val(BITS, 0.5), Float::with_val(BITS, 0.25));
        for real_order in [-2.5, 1.5] {
            let order = Complex::new(
                Float::with_val(BITS, real_order),
                Float::with_val(BITS, 0.25),
            );
            let left = polylog_numeric_eval(&order, &z, BITS).unwrap()
                + polylog_numeric_eval(&order, &(-z.clone()), BITS).unwrap();
            let factor = Complex::new(Float::with_val(BITS, 2), Float::new(BITS))
                .powf(&(complex_one(BITS) - order.clone()));
            let right =
                factor * polylog_numeric_eval(&order, &(z.clone() * z.clone()), BITS).unwrap();
            assert_precision_complex(&left, &right, BITS, "fractional-order duplication");
        }
    }

    /// Arguments covering every continuation region of the binary64 dilogarithm,
    /// its region boundaries, both sides of the cut, and extreme magnitudes.
    #[cfg(feature = "float-mpfr")]
    fn dilog_f64_sample_arguments() -> Vec<Complex<f64>> {
        let mut points = Vec::new();
        for i in -30..=30 {
            for j in -30..=30 {
                points.push(Complex::new(f64::from(i) * 0.137, f64::from(j) * 0.093));
            }
        }
        let third = std::f64::consts::FRAC_PI_3;
        let angles = (0..48).map(|k| f64::from(k) * std::f64::consts::PI / 24.0 + 1e-3);
        for angle in angles.chain([third, -third, 1e-12, -1e-12, std::f64::consts::PI]) {
            for radius in [
                1e-300, 1e-200, 1e-20, 1e-8, 1e-3, 0.3, 0.999, 1.0, 1.001, 3.0, 1e3, 1e8, 1e20,
                1e200, 1e300,
            ] {
                points.push(Complex::new(radius * angle.cos(), radius * angle.sin()));
            }
            for distance in [1e-14, 1e-8, 1e-3, 0.5, 0.999_999, 1.0, 1.000_001] {
                points.push(Complex::new(
                    1.0 + distance * angle.cos(),
                    distance * angle.sin(),
                ));
            }
        }
        for x in [
            -1e300,
            -1e10,
            -3.0,
            -1.0 - 1e-15,
            -1.0,
            -0.5,
            -1e-12,
            1e-300,
            0.25,
            0.5,
            0.75,
            1.0 - f64::EPSILON / 2.0,
            1.0,
            1.0 + f64::EPSILON,
            1.5,
            2.0,
            3.0,
            100.0,
            1e10,
            1e300,
        ] {
            for y in [1e-300, -1e-300, 1e-14, -1e-14] {
                points.push(Complex::new(x, y));
            }
        }
        // Deterministic pseudo-random arguments with scattered magnitudes.
        let mut state = 0x2545_f491_4f6c_dd1d_u64;
        let mut next = || {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            (state >> 11) as f64 / (1u64 << 53) as f64
        };
        for _ in 0..4000 {
            let radius = 10f64.powf(16.0 * next() - 8.0);
            let angle = 2.0 * std::f64::consts::PI * next();
            points.push(Complex::new(radius * angle.cos(), radius * angle.sin()));
        }
        points
    }

    #[cfg(feature = "float-mpfr")]
    fn reference_dilog(z: Complex<f64>) -> Complex<Float> {
        const BITS: u32 = 256;
        let argument = Complex::new(Float::with_val(BITS, z.re), Float::with_val(BITS, z.im));
        polylog_integer_numeric_eval(2, &argument, BITS, 0).unwrap()
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn dilog_complex_f64_matches_multiprecision() {
        let mut worst = (0.0, Complex::new(0.0, 0.0));
        for z in dilog_f64_sample_arguments() {
            let actual = super::dilog_complex_f64(z);
            let expected = reference_dilog(z);
            let difference = Complex::new(
                Float::with_val(256, actual.re) - &expected.re,
                Float::with_val(256, actual.im) - &expected.im,
            );
            let error = (difference.norm().re / expected.norm().re).to_f64();
            if error > worst.0 {
                worst = (error, z);
            }
        }
        // About four ulps; the old route rounded the same reference once.
        eprintln!(
            "binary64 Li2: worst relative error {:e} at {:?}",
            worst.0, worst.1
        );
        assert!(
            worst.0 < 1e-15,
            "worst relative error {:e} at {:?}",
            worst.0,
            worst.1
        );
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn dilog_f64_matches_multiprecision() {
        let mut arguments: Vec<f64> = (-400..=400).map(|i| f64::from(i) * 0.0371).collect();
        arguments.extend([
            -1e300,
            -1e10,
            -3.0,
            -1.0,
            -1e-300,
            1e-300,
            1e-20,
            1e-8,
            0.5,
            1.0 - 1e-15,
            1.0,
            1.0 + 1e-15,
            2.0,
            2.0 + 1e-15,
            12.0,
            13.0,
            1e10,
            1e300,
        ]);
        for x in arguments {
            let actual = super::dilog_f64(x);
            let expected = reference_dilog(Complex::new(x, 0.0)).re;
            let error = (Float::with_val(256, actual) - &expected).norm().to_f64();
            // Re Li2(x) changes sign near x = 12.6, so for x > 1 the cut's
            // pi^2/3 term, not the result, sets the attainable absolute error.
            let scale = expected.norm().to_f64() + if x > 1.0 { 3.3 } else { 0.0 };
            assert!(
                error <= 1e-15 * scale,
                "x={x:e}: {actual:e} vs {expected}, error {error:e}"
            );
        }
    }

    #[test]
    fn dilog_f64_preserves_cut_conventions() {
        let pi_log_two = std::f64::consts::PI * std::f64::consts::LN_2;
        for imaginary in [0.0, -0.0] {
            // Exactly real arguments use the lower lip, as polylog(2, x) does.
            let value = super::dilog_complex_f64(Complex::new(2.0, imaginary));
            assert!((value.re - std::f64::consts::PI.powi(2) / 4.0).abs() < 1e-15);
            assert!((value.im + pi_log_two).abs() < 1e-15);
            for x in [-3.0, -0.5, 0.0, 0.5, 1.0] {
                let value = super::dilog_complex_f64(Complex::new(x, imaginary));
                assert!(value.im == 0.0 && value.im.is_sign_positive(), "{x}");
                assert_eq!(value.re, super::dilog_f64(x));
            }
        }
        // A nonzero imaginary part selects its own side, however small.
        for sign in [-1.0, 1.0] {
            let value = super::dilog_complex_f64(Complex::new(2.0, sign * 1e-300));
            assert!((value.im - sign * pi_log_two).abs() < 1e-15);
        }
        let zero = super::dilog_complex_f64(Complex::new(-0.0, -0.0));
        assert!(zero.re == 0.0 && zero.re.is_sign_positive());
        assert!(zero.im == 0.0 && zero.im.is_sign_positive());
        assert_eq!(super::dilog_f64(1.0), std::f64::consts::PI.powi(2) / 6.0);
        assert_eq!(super::dilog_f64(-1.0), -std::f64::consts::PI.powi(2) / 12.0);
        assert!(super::dilog_f64(f64::NAN).is_nan());
        assert!(
            super::dilog_complex_f64(Complex::new(f64::INFINITY, 0.0))
                .re
                .is_nan()
        );
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn dilog_f64_keeps_previous_signed_zeros() {
        // The previous binary64 route evaluated polylog(2, z) with MPFR at 53
        // bits. Exact zero components of the result keep their signs.
        let order = Complex::new(Float::with_val(53, 2), Float::new(53));
        for x in [-1e10, -3.0, -1.0, -0.5, 0.0, 0.25, 0.5, 1.0, 2.0, 1e10] {
            for y in [0.0, -0.0] {
                let z = Complex::new(x, y);
                let argument = Complex::new(Float::with_val(53, x), Float::with_val(53, y));
                let previous = polylog_numeric_eval(&order, &argument, 53).unwrap();
                let previous = Complex::new(previous.re.to_f64(), previous.im.to_f64());
                let value = super::dilog_complex_f64(z);
                for (new, old) in [(value.re, previous.re), (value.im, previous.im)] {
                    if old == 0.0 {
                        assert_eq!(new.to_bits(), old.to_bits(), "{z:?}");
                    }
                }
            }
        }
    }

    #[test]
    fn binary64_polylog_evaluators_use_dilog_kernel() {
        let evaluator = parse!("polylog(2,x)")
            .evaluator(&[parse!("x")])
            .build()
            .unwrap();
        let mut complex = evaluator
            .clone()
            .map_coeff(&|x| Complex::new(x.re.to_f64(), x.im.to_f64()));
        let mut real = evaluator.map_coeff(&|x| x.re.to_f64());
        for z in [
            Complex::new(0.3, 0.1),
            Complex::new(-2.5, 0.7),
            Complex::new(5.0, -1e-3),
            Complex::new(5.0, 0.0),
            Complex::new(0.5, -0.0),
        ] {
            let value = complex.evaluate_single(&[z]);
            let expected = super::dilog_complex_f64(z);
            assert_eq!(value.re.to_bits(), expected.re.to_bits());
            assert_eq!(value.im.to_bits(), expected.im.to_bits());
        }
        for x in [-2.5, 0.3, 5.0] {
            assert_eq!(real.evaluate_single(&[x]), super::dilog_f64(x));
        }

        // Other orders keep the multiprecision route.
        let mut trilog = parse!("polylog(3,x)")
            .evaluator(&[parse!("x")])
            .build()
            .unwrap()
            .map_coeff(&|x| Complex::new(x.re.to_f64(), x.im.to_f64()));
        let value = trilog.evaluate_single(&[Complex::new(0.5, 0.0)]);
        assert!((value.re - 0.537_213_193_608_040_2).abs() < 1e-15);
    }

    #[test]
    fn zeta_exact_normalization() {
        assert_eq!(parse!("zeta(0)"), parse!("-1/2"));
        assert_eq!(parse!("zeta(-1)"), parse!("-1/12"));
        assert_eq!(parse!("zeta(-2)"), Atom::new());
        assert_eq!(parse!("zeta(2)"), parse!("1/6*pi^2"));
        assert_eq!(parse!("zeta(4)"), parse!("1/90*pi^4"));
        assert_eq!(
            parse!("zeta(1)"),
            Atom::num(Coefficient::complex_infinity())
        );
    }

    #[test]
    fn zeta_float_normalization() {
        assert!(Complex::<Float>::try_from(parse!("zeta(1.25)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("zeta(1/2+1i/4)").to_float(50)).is_ok());
    }

    #[test]
    fn special_functions_register_eval_info() {
        let mut evaluator = parse!(
            "gamma(x)+erf(x)+polygamma(0,x)+polygamma(1,x)+polylog(2,x)+zeta(x)+euler_gamma"
        )
        .evaluator(&[parse!("x")])
        .build()
        .unwrap()
        .map_coeff(&|x| x.re.to_f64());

        let mut out = [0.0];
        evaluator.evaluate(&[0.25], &mut out);

        assert!(out[0].is_finite());
    }

    #[test]
    fn geometric_float_inputs_normalize_immediately() {
        assert!(Complex::<Float>::try_from(parse!("tan(0.25)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("atan(0.25)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("atan(-1.0,1.0)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("sinh(0.25)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("atanh(0.25)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("sec(0.25)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("coth(1.25)")).is_ok());
    }

    #[test]
    fn atan_two_argument_form_uses_quadrant() {
        let actual = Complex::<Float>::try_from(parse!("atan(-1.0,1.0)")).unwrap();
        let expected = Complex::new(Float::with_val(53, 1.0_f64.atan2(-1.0)), Float::new(53));
        assert_close_complex(&actual, &expected, "1e-15");

        let exact_actual = Complex::<Float>::try_from(parse!("atan(-1,1)").to_float(80)).unwrap();
        let one = Float::with_val(80, 1);
        let minus_one = Float::with_val(80, -1);
        let exact_expected = Complex::new(one.atan2(&minus_one), Float::new(80));
        assert_close_complex(&exact_actual, &exact_expected, "1e-23");
    }

    #[test]
    fn transcendental_functions_extension_trait() {
        use super::TranscendentalFunctions;

        let x = parse!("x");
        assert_eq!(x.atan(), parse!("atan(x)"));
        assert_eq!(x.atan2(parse!("y")), parse!("atan(x,y)"));
        assert_eq!(x.gamma(), parse!("gamma(x)"));
        assert_eq!(x.erf(), parse!("erf(x)"));
        assert_eq!(x.zeta(), parse!("zeta(x)"));
        assert_eq!(x.polylog(2), parse!("polylog(2,x)"));
        assert_eq!(x.polygamma(1), parse!("polygamma(1,x)"));
        assert_eq!(x.bessel_j(parse!("nu")), parse!("bessel_j(nu,x)"));
    }

    #[test]
    fn geometric_derivatives() {
        assert_eq!(
            parse!("tan(x)").derivative(symbol!("x")),
            parse!("sec(x)^2")
        );
        assert_eq!(
            parse!("atan(x)").derivative(symbol!("x")),
            parse!("1/(1+x^2)")
        );
        assert_eq!(
            parse!("atan(x,y)").derivative(symbol!("x")),
            parse!("-y/(x^2+y^2)")
        );
        assert_eq!(
            parse!("atan(x,y)").derivative(symbol!("y")),
            parse!("x/(x^2+y^2)")
        );
        assert_eq!(
            parse!("atan(y,x)").derivative(symbol!("x")),
            parse!("y/(x^2+y^2)")
        );
        assert_eq!(
            parse!("sech(x)").derivative(symbol!("x")),
            parse!("-sech(x)*tanh(x)")
        );
        assert_eq!(
            parse!("atanh(x)").derivative(symbol!("x")),
            parse!("1/(1-x^2)")
        );
    }

    #[test]
    fn tan_laurent_series() {
        let x = symbol!("x");
        assert_eq!(
            parse!("tan(x)")
                .series(x, parse!("pi/2"), 0)
                .unwrap()
                .to_atom(),
            parse!("-(x-pi/2)^-1")
        );
        assert_eq!(
            parse!("sec(x)")
                .series(x, parse!("pi/2"), 0)
                .unwrap()
                .to_atom(),
            parse!("-(x-pi/2)^-1")
        );
        assert_eq!(
            parse!("sec(x)")
                .series(x, parse!("3*pi/2"), 0)
                .unwrap()
                .to_atom(),
            parse!("(x-3/2*pi)^-1")
        );
        assert_eq!(
            parse!("cot(x)").series(x, 0, 0).unwrap().to_atom(),
            parse!("x^-1")
        );
        assert_eq!(
            parse!("csc(x)").series(x, 0, 0).unwrap().to_atom(),
            parse!("x^-1")
        );
        assert_eq!(
            parse!("csc(x)")
                .series(x, parse!("pi"), 0)
                .unwrap()
                .to_atom(),
            parse!("-(x-pi)^-1")
        );
    }

    #[test]
    fn hyperbolic_laurent_series() {
        let x = symbol!("x");
        assert_eq!(
            parse!("tanh(x)")
                .series(x, parse!("1i*pi/2"), 0)
                .unwrap()
                .to_atom(),
            parse!("(x-1i*pi/2)^-1")
        );
        assert_eq!(
            parse!("coth(x)").series(x, 0, 0).unwrap().to_atom(),
            parse!("x^-1")
        );
        assert_eq!(
            parse!("sech(x)")
                .series(x, parse!("1i*pi/2"), 0)
                .unwrap()
                .to_atom(),
            parse!("-1i*(x-1i*pi/2)^-1")
        );
        assert_eq!(
            parse!("sech(x)")
                .series(x, parse!("3i*pi/2"), 0)
                .unwrap()
                .to_atom(),
            parse!("1i*(x-3i*pi/2)^-1")
        );
        assert_eq!(
            parse!("csch(x)").series(x, 0, 0).unwrap().to_atom(),
            parse!("x^-1")
        );
        assert_eq!(
            parse!("csch(x)")
                .series(x, parse!("1i*pi"), 0)
                .unwrap()
                .to_atom(),
            parse!("-(x-1i*pi)^-1")
        );
    }

    #[test]
    fn geometric_functions_register_eval_info() {
        let mut evaluator = parse!("tan(x)+atan(x)+atan(x,-1)+sinh(x)+atanh(x/2)+sec(x)+coth(x+2)")
            .evaluator(&[parse!("x")])
            .build()
            .unwrap()
            .map_coeff(&|x| x.re.to_f64());

        let mut out = [0.0];
        evaluator.evaluate(&[0.25], &mut out);

        assert!(out[0].is_finite());
    }

    #[test]
    fn reciprocal_hyperbolic_evaluators_avoid_overflow() {
        for name in ["sech", "csch"] {
            let evaluator = parse!(format!("{name}(x)"))
                .evaluator(&[parse!("x")])
                .build()
                .unwrap();
            let mut complex = evaluator
                .clone()
                .map_coeff(&|x| Complex::new(x.re.to_f64(), x.im.to_f64()));
            let mut real = evaluator.map_coeff(&|x| x.re.to_f64());
            for point in [1e13, -1e13, 711.0, -711.0, 745.5, -745.5] {
                let value = complex.evaluate_single(&[Complex::new(point, 0.0)]);
                let expected = if name == "sech" {
                    point.sech()
                } else {
                    point.csch()
                };
                assert_eq!(value.re, expected, "{name}({point})");
                assert_eq!(value.im, 0.0, "{name}({point})");
                assert_eq!(real.evaluate_single(&[point]), expected);
                if point.abs() < 1e13 {
                    assert_ne!(value.re, 0.0);
                }
            }
        }
    }

    #[test]
    fn bessel_float_inputs_normalize_immediately() {
        assert!(Complex::<Float>::try_from(parse!("bessel_j(1/2,2.0)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("bessel_y(1/2,2.0)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("bessel_i(1/2,2.0)")).is_ok());
        assert!(Complex::<Float>::try_from(parse!("bessel_k(1/2,2.0)")).is_ok());
    }

    #[test]
    fn bessel_known_half_integer_values() {
        let j = Complex::<Float>::try_from(parse!("bessel_j(1/2,2)").to_float(80)).unwrap();
        let y = Complex::<Float>::try_from(parse!("bessel_y(1/2,2)").to_float(80)).unwrap();
        let i = Complex::<Float>::try_from(parse!("bessel_i(1/2,2)").to_float(80)).unwrap();
        let k = Complex::<Float>::try_from(parse!("bessel_k(1/2,2)").to_float(80)).unwrap();

        let j_expected =
            Complex::<Float>::try_from(parse!("pi^(-1/2)*sin(2)").to_float(80)).unwrap();
        let y_expected =
            Complex::<Float>::try_from(parse!("-pi^(-1/2)*cos(2)").to_float(80)).unwrap();
        let i_expected =
            Complex::<Float>::try_from(parse!("pi^(-1/2)*sinh(2)").to_float(80)).unwrap();
        let k_expected =
            Complex::<Float>::try_from(parse!("1/2*pi^(1/2)*exp(-2)").to_float(80)).unwrap();

        assert_close_complex(&j, &j_expected, "1e-20");
        assert_close_complex(&y, &y_expected, "1e-20");
        assert_close_complex(&i, &i_expected, "1e-20");
        assert_close_complex(&k, &k_expected, "1e-18");
    }

    #[test]
    fn bessel_integer_order_limits_preserve_precision() {
        use super::{
            bessel_i_numeric_eval, bessel_j_numeric_eval, bessel_k_numeric_eval,
            bessel_y_numeric_eval, complex_one, complex_pi,
        };

        for prec in [53, 128, 256, 512] {
            for imaginary in [0., 0.5] {
                let z = Complex::new(
                    Float::with_val(prec, 1.25),
                    Float::with_val(prec, imaginary),
                );
                for n in [0, 1, 2] {
                    let order = Complex::new(Float::with_val(prec, n), Float::new(prec));
                    let next = Complex::new(Float::with_val(prec, n + 1), Float::new(prec));
                    let j = bessel_j_numeric_eval(&order, &z, prec).unwrap();
                    let j_next = bessel_j_numeric_eval(&next, &z, prec).unwrap();
                    let y = bessel_y_numeric_eval(&order, &z, prec).unwrap();
                    let y_next = bessel_y_numeric_eval(&next, &z, prec).unwrap();
                    let i = bessel_i_numeric_eval(&order, &z, prec).unwrap();
                    let i_next = bessel_i_numeric_eval(&next, &z, prec).unwrap();
                    let k = bessel_k_numeric_eval(&order, &z, prec).unwrap();
                    let k_next = bessel_k_numeric_eval(&next, &z, prec).unwrap();

                    // Independent Wronskian identities exercise both integer
                    // limits without comparing two perturbed approximations.
                    let one = complex_one(prec);
                    let y_residual = j_next * y
                        - j * y_next
                        - (one.clone() + one.clone()) / (complex_pi(prec) * z.clone());
                    let k_residual = i * k_next + i_next * k - one / z.clone();
                    for residual in [y_residual, k_residual] {
                        assert!(
                            residual.norm().re.to_f64().abs() < 2f64.powi(-(prec as i32) + 12),
                            "n={n}, z={z}, precision={prec}: residual {residual}"
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn bessel_order_integer_detection_is_exact() {
        use super::complex_float_to_integer;
        use crate::domains::float::FloatLike;

        let one = Float::with_val(128, 1);
        let epsilon = Float::with_val(128, 0.5).pow(80);
        assert_eq!(
            complex_float_to_integer(&Complex::new(one.clone(), Float::new(128))),
            Some(1)
        );
        assert_eq!(
            complex_float_to_integer(&Complex::new(one.clone() + &epsilon, Float::new(128))),
            None
        );
        assert_eq!(complex_float_to_integer(&Complex::new(one, epsilon)), None);
    }

    #[test]
    fn bessel_derivatives() {
        assert_eq!(
            parse!("bessel_j(nu,x)").derivative(symbol!("x")),
            parse!("(bessel_j(nu-1,x)-bessel_j(nu+1,x))/2")
        );
        assert_eq!(
            parse!("bessel_i(nu,x)").derivative(symbol!("x")),
            parse!("(bessel_i(nu-1,x)+bessel_i(nu+1,x))/2")
        );
    }

    #[test]
    fn bessel_functions_register_eval_info() {
        let mut evaluator =
            parse!("bessel_j(1/2,x)+bessel_y(1/2,x)+bessel_i(1/2,x)+bessel_k(1/2,x)")
                .evaluator(&[parse!("x")])
                .build()
                .unwrap()
                .map_coeff(&|x| x.re.to_f64());

        let mut out = [0.0];
        evaluator.evaluate(&[2.0], &mut out);

        assert!(out[0].is_finite());
    }

    fn ginsh_gamma(argument: &str, digits: u32) -> Complex<Float> {
        let script = format!("Digits={digits}:\nevalf(tgamma({argument}));\nquit;\n");

        let mut child = Command::new("ginsh")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .spawn()
            .expect("ginsh must be available");
        child
            .stdin
            .as_mut()
            .unwrap()
            .write_all(script.as_bytes())
            .expect("ginsh stdin must be writable");

        let output = child.wait_with_output().expect("ginsh must complete");
        assert!(
            output.status.success(),
            "ginsh failed: {}",
            String::from_utf8_lossy(&output.stderr)
        );

        let stdout = String::from_utf8(output.stdout).unwrap();
        let value = stdout
            .lines()
            .map(str::trim)
            .find(|line| !line.is_empty())
            .unwrap();

        parse_ginsh_complex(value)
    }

    fn ginsh_polylog(order: &str, argument: &str, digits: u32) -> Complex<Float> {
        let script = format!("Digits={digits}:\nevalf(Li({order},{argument}));\nquit;\n");

        let mut child = Command::new("ginsh")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .spawn()
            .expect("ginsh must be available");
        child
            .stdin
            .as_mut()
            .unwrap()
            .write_all(script.as_bytes())
            .expect("ginsh stdin must be writable");

        let output = child.wait_with_output().expect("ginsh must complete");
        assert!(
            output.status.success(),
            "ginsh failed: {}",
            String::from_utf8_lossy(&output.stderr)
        );

        let stdout = String::from_utf8(output.stdout).unwrap();
        let value = stdout
            .lines()
            .map(str::trim)
            .find(|line| !line.is_empty())
            .unwrap();

        parse_ginsh_complex(value)
    }

    fn assert_close_complex(actual: &Complex<Float>, expected: &Complex<Float>, tolerance: &str) {
        let tol = Float::parse(tolerance, Some(256)).unwrap();
        let diff = (actual.clone() - expected.clone()).norm().re;
        let scale = expected.norm().re;
        let limit = if scale.to_f64() == 0.0 {
            tol
        } else {
            tol * scale
        };

        assert!(
            diff <= limit,
            "difference too large: actual={}, expected={}, diff={}, limit={}",
            actual,
            expected,
            diff,
            limit
        );
    }

    fn parse_ginsh_complex(value: &str) -> Complex<Float> {
        let value = value.trim();

        if !value.contains("*I") {
            return Complex::new(Float::parse(value, Some(256)).unwrap(), Float::new(256));
        }

        let imag_marker = value
            .rfind("*I")
            .expect("GiNaC complex output must contain *I");
        let core = &value[..imag_marker];
        let split = core
            .char_indices()
            .skip(1)
            .filter(|(_, ch)| *ch == '+' || *ch == '-')
            .filter(|(idx, _)| !matches!(core.as_bytes()[idx - 1], b'e' | b'E'))
            .map(|(idx, _)| idx)
            .last()
            .expect("GiNaC complex output must contain a real and imaginary part");

        let re = Float::parse(&core[..split], Some(256)).unwrap();
        let im = Float::parse(&core[split..], Some(256)).unwrap();
        Complex::new(re, im)
    }
}
