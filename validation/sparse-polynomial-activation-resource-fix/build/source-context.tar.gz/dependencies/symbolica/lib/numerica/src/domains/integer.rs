//! Arbitrary precision integers.

mod polynomial_kernels;

use std::{
    cmp::Ordering,
    fmt::{Display, Error, Formatter},
    ops::{
        Add, AddAssign, BitAnd, BitAndAssign, Div, DivAssign, Mul, MulAssign, Neg, Rem, Shl,
        ShlAssign, Shr, ShrAssign, Sub, SubAssign,
    },
    str::FromStr,
};

use rand::Rng;

use crate::{
    domains::{RingOps, Set},
    kernels::RingKernels,
    printer::{PrintOptions, PrintState},
    tensors::matrix::Matrix,
};

use super::{
    EuclideanDomain, Field, InternalOrdering, OrderedRing, Ring, SampleableRing, SelfRing,
    finite_field::{
        FiniteField, FiniteFieldCore, FiniteFieldElement, FiniteFieldWorkspace, Mersenne32,
        Mersenne64, PrimeIteratorU64, ToFiniteField, Two, Z2, Zp, Zp64,
    },
    float::{FloatField, FloatLike, Real, RealLike, SingleFloat},
    rational::Rational,
};

pub(crate) use super::backend::integer::Complete;
#[allow(unused_imports)]
use super::backend::integer::RemRounding as _;
use super::backend::integer::pow_ref_u32 as mp_pow_ref_u32;
pub use super::backend::integer::{
    MultiPrecisionInteger, ParseMultiPrecisionIntegerError, RawMultiPrecisionInteger,
};
#[cfg(feature = "bincode")]
use super::backend::integer::{from_be_bytes as mp_from_be_bytes, to_be_bytes as mp_to_be_bytes};

fn mp_try_div_exact(
    a: &MultiPrecisionInteger,
    b: &MultiPrecisionInteger,
) -> Option<MultiPrecisionInteger> {
    if b.is_zero() {
        return None;
    }

    let (q, r) = a.div_rem_ref(b).complete();
    if r.is_zero() { Some(q) } else { None }
}

/// The first 100 primes.
pub const SMALL_PRIMES: [i64; 100] = [
    2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97,
    101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193,
    197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307,
    311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421,
    431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541,
];

/// The integer ring.
pub type Z = IntegerRing;
/// The integer ring.
pub const Z: IntegerRing = IntegerRing::new();

/// The integer ring.
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub struct IntegerRing;

impl Default for IntegerRing {
    fn default() -> Self {
        Self::new()
    }
}

impl IntegerRing {
    pub const fn new() -> IntegerRing {
        IntegerRing
    }
}

/// An arbitrary-precision integer that automatically upgrades and downgrades to the most efficient
/// representation.
#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]
#[derive(Clone, PartialEq, Eq, Hash)]
pub enum Integer {
    /// Single machine-width integer (`i64`), hardware-accelerated on most platforms.
    Single(i64),
    /// Double machine-width integer (`i128`), partially hardware accelerated on some platforms.
    Double(DoubleInteger),
    /// Multi-precision integer using the selected arbitrary-precision backend.
    Large(MultiPrecisionInteger),
}

/// An `i128` stored as two 64-bit limbs so that [`Integer`] only requires
/// 8-byte alignment on 64-bit targets.
///
/// Convert this value to an ordinary `i128` with [`DoubleInteger::get`].
#[repr(C)]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct DoubleInteger {
    low: u64,
    high: i64,
}

impl DoubleInteger {
    #[inline(always)]
    pub const fn new(value: i128) -> Self {
        Self {
            low: value as u64,
            high: (value >> 64) as i64,
        }
    }

    #[inline(always)]
    pub const fn get(self) -> i128 {
        ((self.high as i128) << 64) | self.low as i128
    }
}

impl From<i128> for DoubleInteger {
    #[inline(always)]
    fn from(value: i128) -> Self {
        Self::new(value)
    }
}

impl From<DoubleInteger> for i128 {
    #[inline(always)]
    fn from(value: DoubleInteger) -> Self {
        value.get()
    }
}

impl From<&DoubleInteger> for i128 {
    #[inline(always)]
    fn from(value: &DoubleInteger) -> Self {
        value.get()
    }
}

impl std::fmt::Display for DoubleInteger {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        std::fmt::Display::fmt(&self.get(), f)
    }
}

impl std::fmt::Debug for DoubleInteger {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        std::fmt::Debug::fmt(&self.get(), f)
    }
}

#[cfg(feature = "serde")]
impl serde::Serialize for DoubleInteger {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        serializer.serialize_i128(self.get())
    }
}

#[cfg(feature = "serde")]
impl<'de> serde::Deserialize<'de> for DoubleInteger {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        <i128 as serde::Deserialize>::deserialize(deserializer).map(Self::new)
    }
}

#[derive(Clone)]
struct EcmMontgomeryPoint {
    x: FiniteFieldElement<MultiPrecisionInteger>,
    z: FiniteFieldElement<MultiPrecisionInteger>,
}

impl InternalOrdering for Integer {
    fn internal_cmp(&self, other: &Self) -> std::cmp::Ordering {
        Ord::cmp(self, other)
    }
}

#[cfg(feature = "python")]
use pyo3::{
    Borrowed, Bound, FromPyObject, IntoPyObject, PyErr, PyResult, Python, exceptions,
    types::{PyAnyMethods, PyInt},
};

#[cfg(feature = "python_stubgen")]
pyo3_stub_gen::impl_stub_type!(Integer = PyInt);

#[cfg(feature = "python")]
impl<'py> FromPyObject<'_, 'py> for Integer {
    type Error = PyErr;

    fn extract(ob: Borrowed<'_, 'py, pyo3::PyAny>) -> PyResult<Self> {
        if let Ok(num) = ob.extract::<i64>() {
            Ok(num.into())
        } else if let Ok(num) = ob.cast::<PyInt>() {
            let text = num.str()?;
            let value = text
                .extract::<String>()?
                .parse::<MultiPrecisionInteger>()
                .map_err(|error| exceptions::PyValueError::new_err(error.to_string()))?;
            Ok(Integer::from(value))
        } else {
            Err(exceptions::PyValueError::new_err("Not a valid integer"))
        }
    }
}

#[cfg(feature = "python")]
impl<'py> IntoPyObject<'py> for Integer {
    type Target = PyInt;
    type Output = Bound<'py, Self::Target>;
    type Error = PyErr;

    fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
        match self {
            Integer::Single(n) => Ok(n.into_pyobject(py)?),
            Integer::Double(d) => Ok(d.get().into_pyobject(py)?),
            Integer::Large(l) => Ok(py
                .get_type::<PyInt>()
                .call1((format!("{:x}", l.as_raw()), 16))?
                .cast_into::<PyInt>()?),
        }
    }
}

#[cfg(feature = "bincode")]
impl bincode::Encode for Integer {
    fn encode<E: bincode::enc::Encoder>(
        &self,
        encoder: &mut E,
    ) -> Result<(), bincode::error::EncodeError> {
        match self {
            Integer::Single(val) => {
                0u8.encode(encoder)?;
                val.encode(encoder)
            }
            Integer::Double(val) => {
                1u8.encode(encoder)?;
                val.get().encode(encoder)
            }
            Integer::Large(val) => {
                let bytes = if val.is_negative() {
                    3u8.encode(encoder)?;
                    mp_to_be_bytes(&val.as_abs())
                } else {
                    2u8.encode(encoder)?;
                    mp_to_be_bytes(val)
                };
                bytes.encode(encoder)
            }
        }
    }
}

#[cfg(feature = "bincode")]
bincode::impl_borrow_decode!(Integer);
#[cfg(feature = "bincode")]
impl<Context> bincode::Decode<Context> for Integer {
    fn decode<D: bincode::de::Decoder<Context = Context>>(
        decoder: &mut D,
    ) -> Result<Self, bincode::error::DecodeError> {
        let variant = u8::decode(decoder)?;
        match variant {
            0 => {
                let val = i64::decode(decoder)?;
                Ok(Integer::Single(val))
            }
            1 => {
                let val = i128::decode(decoder)?;
                Ok(Integer::from_double(val))
            }
            2 | 3 => {
                let b = Vec::<u8>::decode(decoder)?;
                let val =
                    mp_from_be_bytes(&b).map_err(|e| bincode::error::DecodeError::Other(e))?;
                Ok(Integer::Large(if variant == 3 { -val } else { val }))
            }
            _ => Err(bincode::error::DecodeError::OtherString(format!(
                "Invalid variant for Integer: {}",
                variant
            ))),
        }
    }
}

/// An error that can occur when performing integer-reconstruction operations.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum IntegerRelationError {
    PrecisionLimit,
    IterationLimit(Vec<Integer>),
    CoefficientLimit,
}

impl std::error::Error for IntegerRelationError {}

impl std::fmt::Display for IntegerRelationError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            IntegerRelationError::PrecisionLimit => {
                f.write_str("precision limit reached during integer relation reconstruction")
            }
            IntegerRelationError::IterationLimit(relation) => write!(
                f,
                "iteration limit reached during integer relation reconstruction: {relation:?}"
            ),
            IntegerRelationError::CoefficientLimit => {
                f.write_str("coefficient limit reached during integer relation reconstruction")
            }
        }
    }
}

macro_rules! from_with_i64_cast {
    ($base: ty) => {
        impl From<$base> for Integer {
            #[inline]
            fn from(value: $base) -> Self {
                Integer::Single(value as i64)
            }
        }

        impl PartialEq<$base> for Integer {
            #[inline]
            fn eq(&self, other: &$base) -> bool {
                match self {
                    Integer::Single(n) => *n == *other as i64,
                    _ => false,
                }
            }
        }

        impl PartialEq<Integer> for $base {
            #[inline]
            fn eq(&self, other: &Integer) -> bool {
                other == self
            }
        }

        impl PartialOrd<$base> for Integer {
            #[inline]
            fn partial_cmp(&self, other: &$base) -> Option<Ordering> {
                match self {
                    Integer::Single(n) => n.partial_cmp(&(*other as i64)),
                    x => {
                        if x.is_negative() {
                            Some(Ordering::Less)
                        } else {
                            Some(Ordering::Greater)
                        }
                    }
                }
            }
        }

        impl PartialOrd<Integer> for $base {
            #[inline]
            fn partial_cmp(&self, other: &Integer) -> Option<Ordering> {
                other.partial_cmp(self).map(|x| x.reverse())
            }
        }
    };
}

from_with_i64_cast!(i8);
from_with_i64_cast!(i16);
from_with_i64_cast!(i32);
from_with_i64_cast!(i64);
from_with_i64_cast!(u8);
from_with_i64_cast!(u16);
from_with_i64_cast!(u32);

macro_rules! cmp_with_conv {
    ($base: ty) => {
        impl PartialEq<$base> for Integer {
            #[inline]
            fn eq(&self, other: &$base) -> bool {
                self == &Integer::from(*other)
            }
        }

        impl PartialOrd<$base> for Integer {
            #[inline]
            fn partial_cmp(&self, other: &$base) -> Option<Ordering> {
                self.partial_cmp(&Integer::from(*other))
            }
        }

        impl PartialEq<Integer> for $base {
            #[inline]
            fn eq(&self, other: &Integer) -> bool {
                other == self
            }
        }

        impl PartialOrd<Integer> for $base {
            #[inline]
            fn partial_cmp(&self, other: &Integer) -> Option<Ordering> {
                other.partial_cmp(self).map(|x| x.reverse())
            }
        }
    };
}

impl TryFrom<Integer> for i64 {
    type Error = &'static str;

    #[inline]
    fn try_from(value: Integer) -> Result<Self, Self::Error> {
        match value {
            Integer::Single(n) => Ok(n),
            _ => Err("Could not convert to i64 as it is too large"),
        }
    }
}

impl TryFrom<Integer> for i128 {
    type Error = &'static str;

    #[inline]
    fn try_from(value: Integer) -> Result<Self, Self::Error> {
        match value {
            Integer::Single(n) => Ok(n as i128),
            Integer::Double(n) => Ok(n.get()),
            _ => Err("Could not convert to i64 as it is too large"),
        }
    }
}

macro_rules! try_from_int_smaller_i64 {
    ($base: ty) => {
        impl TryFrom<Integer> for $base {
            type Error = &'static str;

            #[inline]
            fn try_from(value: Integer) -> Result<Self, Self::Error> {
                match value {
                    Integer::Single(n) => {
                        if n >= <$base>::MIN as i64 && n <= <$base>::MAX as i64 {
                            Ok(n as $base)
                        } else {
                            Err(concat!(
                                "Could not convert to ",
                                stringify!($base),
                                " as the integer is out of range"
                            ))
                        }
                    }
                    _ => Err(concat!(
                        "Could not convert to ",
                        stringify!($base),
                        " as the integer is too large"
                    )),
                }
            }
        }
    };
}

try_from_int_smaller_i64!(i8);
try_from_int_smaller_i64!(i16);
try_from_int_smaller_i64!(i32);
try_from_int_smaller_i64!(u8);
try_from_int_smaller_i64!(u16);
try_from_int_smaller_i64!(u32);

impl TryFrom<Integer> for isize {
    type Error = &'static str;

    #[inline]
    fn try_from(value: Integer) -> Result<Self, Self::Error> {
        if isize::BITS == 32 {
            i32::try_from(value).map(|x| x as isize)
        } else if usize::BITS == 64 {
            i64::try_from(value).map(|x| x as isize)
        } else if usize::BITS == 128 {
            i128::try_from(value).map(|x| x as isize)
        } else {
            Err("Could not convert to isize on this platform")
        }
    }
}

impl TryFrom<Integer> for usize {
    type Error = &'static str;

    #[inline]
    fn try_from(value: Integer) -> Result<Self, Self::Error> {
        if isize::BITS == 32 {
            u32::try_from(value).map(|x| x as usize)
        } else if usize::BITS == 64 {
            u64::try_from(value).map(|x| x as usize)
        } else if usize::BITS == 128 {
            u128::try_from(value).map(|x| x as usize)
        } else {
            Err("Could not convert to isize on this platform")
        }
    }
}

impl TryFrom<Integer> for u64 {
    type Error = &'static str;

    #[inline]
    fn try_from(value: Integer) -> Result<Self, Self::Error> {
        match value {
            Integer::Single(n) => {
                if n >= 0 {
                    Ok(n as u64)
                } else {
                    Err("Could not convert to u64 as it is negative")
                }
            }
            Integer::Double(n) => {
                let n = n.get();
                if n >= 0 {
                    if n <= u64::MAX as i128 {
                        Ok(n as u64)
                    } else {
                        Err("Could not convert to u64 as it is too large")
                    }
                } else {
                    Err("Could not convert to u64 as it is negative")
                }
            }
            Integer::Large(_) => Err("Could not convert to u64 as it is too large"),
        }
    }
}

impl TryFrom<Integer> for u128 {
    type Error = &'static str;

    #[inline]
    fn try_from(value: Integer) -> Result<Self, Self::Error> {
        match value {
            Integer::Single(n) => {
                if n >= 0 {
                    Ok(n as u128)
                } else {
                    Err("Could not convert to u128 as it is negative")
                }
            }
            Integer::Double(n) => {
                let n = n.get();
                if n >= 0 {
                    Ok(n as u128)
                } else {
                    Err("Could not convert to u128 as it is negative")
                }
            }
            Integer::Large(l) => l
                .to_u128()
                .ok_or("Could not convert to u128 as it is too large"),
        }
    }
}

impl From<i128> for Integer {
    #[inline]
    fn from(value: i128) -> Self {
        Integer::from_double(value)
    }
}

impl From<isize> for Integer {
    #[inline]
    fn from(value: isize) -> Self {
        if usize::BITS == 32 {
            Integer::Single(value as i64)
        } else if usize::BITS == 64 {
            Integer::Single(value as i64)
        } else if usize::BITS == 128 {
            Integer::from(value as i128)
        } else {
            Integer::from(MultiPrecisionInteger::from(value))
        }
    }
}

impl From<u64> for Integer {
    #[inline]
    fn from(value: u64) -> Self {
        if value <= i64::MAX as u64 {
            Integer::Single(value as i64)
        } else {
            Integer::from_double(value as i128)
        }
    }
}

impl From<u128> for Integer {
    #[inline]
    fn from(value: u128) -> Self {
        if value <= i128::MAX as u128 {
            Integer::from_double(value as i128)
        } else {
            Integer::Large(value.into())
        }
    }
}

impl From<usize> for Integer {
    #[inline]
    fn from(value: usize) -> Self {
        if usize::BITS == 32 {
            Integer::Single(value as i64)
        } else if usize::BITS == 64 {
            Integer::from(value as u64)
        } else if usize::BITS == 128 {
            Integer::from(value as u128)
        } else {
            Integer::from(MultiPrecisionInteger::from(value))
        }
    }
}

impl From<MultiPrecisionInteger> for Integer {
    /// Convert from a multi-precision integer to an Integer, potentially
    /// downcasting the number.
    #[inline]
    fn from(n: MultiPrecisionInteger) -> Self {
        if let Some(n) = n.to_i64() {
            Integer::Single(n)
        } else if let Some(n) = n.to_i128() {
            Integer::from_double(n)
        } else {
            Integer::Large(n)
        }
    }
}

cmp_with_conv!(i128);
cmp_with_conv!(isize);
cmp_with_conv!(u64);
cmp_with_conv!(u128);
cmp_with_conv!(usize);

impl FromStr for Integer {
    type Err = &'static str;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        if s.len() <= 20
            && let Ok(n) = s.parse::<i64>()
        {
            return Ok(Integer::Single(n));
        }

        if s.len() <= 40
            && let Ok(n) = s.parse::<i128>()
        {
            return Ok(Integer::from_double(n));
        }

        if let Ok(n) = s.parse::<MultiPrecisionInteger>() {
            Ok(Integer::Large(n))
        } else {
            Err("Could not parse integer")
        }
    }
}

impl std::fmt::Debug for Integer {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Single(n) => std::fmt::Display::fmt(n, f),
            Self::Double(n) => std::fmt::Display::fmt(n, f),
            Self::Large(n) => std::fmt::Display::fmt(n, f),
        }
    }
}

impl ToFiniteField<u32> for Integer {
    fn to_finite_field(&self, field: &Zp) -> <Zp as Set>::Element {
        match self {
            Integer::Single(n) => field.to_element(n.rem_euclid(field.get_prime() as i64) as u32),
            Integer::Double(n) => {
                field.to_element(n.get().rem_euclid(field.get_prime() as i128) as u32)
            }
            Integer::Large(r) => field.to_element(r.mod_u(field.get_prime())),
        }
    }
}

impl ToFiniteField<u64> for Integer {
    fn to_finite_field(&self, field: &Zp64) -> <Zp64 as Set>::Element {
        match self {
            &Integer::Single(n) => {
                if field.get_prime() > i64::MAX as u64 {
                    field.to_element((n as i128).rem_euclid(field.get_prime() as i128) as u64)
                } else {
                    field.to_element(n.rem_euclid(field.get_prime() as i64) as u64)
                }
            }
            &Integer::Double(n) => {
                field.to_element(n.get().rem_euclid(field.get_prime() as i128) as u64)
            }
            Integer::Large(r) => field.to_element(r.mod_u64(field.get_prime())),
        }
    }
}

impl ToFiniteField<Two> for Integer {
    fn to_finite_field(&self, field: &Z2) -> <Z2 as Set>::Element {
        match self {
            &Integer::Single(n) => field.to_element(Two(n.rem_euclid(2) as u8)),
            &Integer::Double(n) => field.to_element(Two(n.get().rem_euclid(2) as u8)),
            Integer::Large(r) => field.to_element(Two(r.mod_u(2) as u8)),
        }
    }
}

impl ToFiniteField<Integer> for Integer {
    fn to_finite_field(
        &self,
        field: &FiniteField<Integer>,
    ) -> <FiniteField<Integer> as Set>::Element {
        field.to_element(self.clone())
    }
}

impl ToFiniteField<Mersenne32> for Integer {
    fn to_finite_field(
        &self,
        _field: &FiniteField<Mersenne32>,
    ) -> <FiniteField<Mersenne32> as Set>::Element {
        match self {
            &Integer::Single(n) => n.rem_euclid(Mersenne32::PRIME as i64) as u32,
            &Integer::Double(n) => n.get().rem_euclid(Mersenne32::PRIME as i128) as u32,
            Integer::Large(r) => r.rem_euc(Mersenne32::PRIME).complete().to_u64().unwrap() as u32,
        }
    }
}

impl ToFiniteField<Mersenne64> for Integer {
    fn to_finite_field(
        &self,
        _field: &FiniteField<Mersenne64>,
    ) -> <FiniteField<Mersenne64> as Set>::Element {
        match self {
            &Integer::Single(n) => n.rem_euclid(Mersenne64::PRIME as i64) as u64,
            &Integer::Double(n) => n.get().rem_euclid(Mersenne64::PRIME as i128) as u64,
            Integer::Large(r) => r.rem_euc(Mersenne64::PRIME).complete().to_u64().unwrap(),
        }
    }
}

pub trait FromFiniteField<UField: FiniteFieldWorkspace>
where
    FiniteField<UField>: FiniteFieldCore<UField>,
{
    fn from_finite_field(
        field: &FiniteField<UField>,
        element: <FiniteField<UField> as Set>::Element,
    ) -> Self;
    fn from_prime(field: &FiniteField<UField>) -> Self;
}

impl FromFiniteField<u32> for Integer {
    fn from_finite_field(field: &Zp, element: <Zp as Set>::Element) -> Self {
        Integer::Single(field.from_element(&element) as i64)
    }

    fn from_prime(field: &Zp) -> Self {
        Integer::Single(field.get_prime() as i64)
    }
}

impl FromFiniteField<u64> for Integer {
    fn from_finite_field(field: &Zp64, element: <Zp64 as Set>::Element) -> Self {
        let r = field.from_element(&element);
        if r <= i64::MAX as u64 {
            Integer::Single(r as i64)
        } else {
            Integer::from_double(r as i128)
        }
    }

    fn from_prime(field: &Zp64) -> Self {
        let r = field.get_prime();
        if r <= i64::MAX as u64 {
            Integer::Single(r as i64)
        } else {
            Integer::from_double(r as i128)
        }
    }
}

impl FromFiniteField<Mersenne32> for Integer {
    fn from_finite_field(_field: &FiniteField<Mersenne32>, element: u32) -> Self {
        Integer::Single(element as i64)
    }

    fn from_prime(_field: &FiniteField<Mersenne32>) -> Self {
        Integer::Single(Mersenne32::PRIME as i64)
    }
}

impl FromFiniteField<Mersenne64> for Integer {
    fn from_finite_field(_field: &FiniteField<Mersenne64>, element: u64) -> Self {
        Integer::Single(element as i64)
    }

    fn from_prime(_field: &FiniteField<Mersenne64>) -> Self {
        Integer::Single(Mersenne64::PRIME as i64)
    }
}

impl Integer {
    pub fn new(num: i64) -> Integer {
        Integer::Single(num)
    }

    #[inline]
    fn simplify(&mut self) -> &mut Self {
        match self {
            Integer::Double(n) => {
                *self = Integer::from_double(n.get());
            }
            Integer::Large(l) => {
                if let Some(n) = l.to_i64() {
                    *self = Integer::Single(n);
                } else if let Some(n) = l.to_i128() {
                    *self = Integer::from_double(n);
                }
            }
            _ => {}
        }
        self
    }

    /// Add or subtract a coefficient product without constructing a temporary large product.
    /// The accumulator is promoted only when one of the operands already needs the
    /// multiprecision backend.
    #[inline(always)]
    fn fused_mul_assign(&mut self, b: &Integer, c: &Integer, subtract: bool) {
        if let (Integer::Single(left), Integer::Single(right)) = (b, c)
            && !matches!(self, Integer::Large(_))
        {
            let accumulator = match self {
                Integer::Single(value) => *value as i128,
                Integer::Double(value) => value.get(),
                Integer::Large(_) => unreachable!(),
            };
            let product = (*left as i128) * (*right as i128);
            if let Some(value) = if subtract {
                accumulator.checked_sub(product)
            } else {
                accumulator.checked_add(product)
            } {
                *self = Integer::from_double(value);
                return;
            }
        }

        if !matches!(self, Integer::Large(_))
            && !matches!(b, Integer::Large(_))
            && !matches!(c, Integer::Large(_))
        {
            let accumulator = match self {
                Integer::Single(value) => *value as i128,
                Integer::Double(value) => value.get(),
                Integer::Large(_) => unreachable!(),
            };
            let left = match b {
                Integer::Single(value) => *value as i128,
                Integer::Double(value) => value.get(),
                Integer::Large(_) => unreachable!(),
            };
            let right = match c {
                Integer::Single(value) => *value as i128,
                Integer::Double(value) => value.get(),
                Integer::Large(_) => unreachable!(),
            };
            if let Some(product) = left.checked_mul(right)
                && let Some(value) = if subtract {
                    accumulator.checked_sub(product)
                } else {
                    accumulator.checked_add(product)
                }
            {
                *self = Integer::from_double(value);
                return;
            }
        }

        if !matches!(self, Integer::Large(_)) {
            let accumulator = match std::mem::replace(self, Integer::Single(0)) {
                Integer::Single(n) => MultiPrecisionInteger::from(n),
                Integer::Double(n) => MultiPrecisionInteger::from(n.get()),
                Integer::Large(_) => unreachable!(),
            };
            *self = Integer::Large(accumulator);
        }

        let Integer::Large(accumulator) = self else {
            unreachable!()
        };

        macro_rules! apply {
            ($add:ident, $sub:ident, $($arg:expr),+ $(,)?) => {
                if subtract {
                    accumulator.$sub($($arg),+);
                } else {
                    accumulator.$add($($arg),+);
                }
            };
        }

        match (b, c) {
            (Integer::Single(b), Integer::Single(c)) => {
                let product = (*b as i128) * (*c as i128);
                if subtract {
                    *accumulator -= product;
                } else {
                    *accumulator += product;
                }
            }
            (Integer::Single(b), Integer::Double(c)) | (Integer::Double(c), Integer::Single(b)) => {
                if let Some(product) = (*b as i128).checked_mul(c.get()) {
                    if subtract {
                        *accumulator -= product;
                    } else {
                        *accumulator += product;
                    }
                } else {
                    let c = MultiPrecisionInteger::from(c.get());
                    apply!(add_i64_mul_assign, sub_i64_mul_assign, *b, &c);
                }
            }
            (Integer::Double(b), Integer::Double(c)) => {
                if let Some(product) = b.get().checked_mul(c.get()) {
                    if subtract {
                        *accumulator -= product;
                    } else {
                        *accumulator += product;
                    }
                } else {
                    let c = MultiPrecisionInteger::from(c.get());
                    apply!(add_i128_mul_assign, sub_i128_mul_assign, b.get(), &c);
                }
            }
            (Integer::Single(b), Integer::Large(c)) | (Integer::Large(c), Integer::Single(b)) => {
                apply!(add_i64_mul_assign, sub_i64_mul_assign, *b, c);
            }
            (Integer::Double(b), Integer::Large(c)) | (Integer::Large(c), Integer::Double(b)) => {
                apply!(add_i128_mul_assign, sub_i128_mul_assign, b.get(), c);
            }
            (Integer::Large(b), Integer::Large(c)) => {
                apply!(add_mul_assign, sub_mul_assign, b, c);
            }
        }

        self.simplify();
    }

    #[inline]
    fn shl_usize(&self, rhs: usize) -> Integer {
        // checked_shl only checks the shift distance. Recovering the original
        // value with an arithmetic right shift also checks signed overflow.
        match self {
            Integer::Single(n) => {
                if rhs < i64::BITS as usize
                    && let Some(shifted) = n.checked_shl(rhs as u32)
                    && shifted >> rhs == *n
                {
                    Integer::Single(shifted)
                } else if rhs < i128::BITS as usize
                    && let Some(shifted) = (*n as i128).checked_shl(rhs as u32)
                    && shifted >> rhs == *n as i128
                {
                    Integer::from_double(shifted)
                } else {
                    Integer::from(MultiPrecisionInteger::from(*n) << rhs)
                }
            }
            Integer::Double(n) => {
                if rhs < i128::BITS as usize
                    && let Some(shifted) = n.get().checked_shl(rhs as u32)
                    && shifted >> rhs == n.get()
                {
                    Integer::from_double(shifted)
                } else {
                    Integer::from(MultiPrecisionInteger::from(n.get()) << rhs)
                }
            }
            Integer::Large(n) => Integer::from((n << rhs).complete()),
        }
    }

    #[inline]
    fn shr_usize(&self, rhs: usize) -> Integer {
        match self {
            Integer::Single(n) => {
                if rhs < i64::BITS as usize {
                    Integer::Single(n >> rhs)
                } else {
                    Integer::from(MultiPrecisionInteger::from(*n) >> rhs)
                }
            }
            Integer::Double(n) => {
                if rhs < i128::BITS as usize {
                    Integer::from_double(n.get() >> rhs)
                } else {
                    Integer::from(MultiPrecisionInteger::from(n.get()) >> rhs)
                }
            }
            Integer::Large(n) => Integer::from((n >> rhs).complete()),
        }
    }

    #[inline]
    pub fn from_double(n: i128) -> Integer {
        if n >= i64::MIN as i128 && n <= i64::MAX as i128 {
            Integer::Single(n as i64)
        } else {
            Integer::Double(DoubleInteger::new(n))
        }
    }

    #[inline]
    pub fn from_f64(f: f64) -> Integer {
        Self::from(MultiPrecisionInteger::from_f64(f).unwrap())
    }

    pub fn to_rational(&self) -> Rational {
        self.into()
    }

    pub fn to_multi_prec(self) -> MultiPrecisionInteger {
        match self {
            Integer::Single(n) => n.into(),
            Integer::Double(d) => d.get().into(),
            Integer::Large(l) => l,
        }
    }

    #[inline]
    pub fn is_zero(&self) -> bool {
        match self {
            Integer::Single(n) => *n == 0,
            _ => false,
        }
    }

    #[inline]
    pub fn is_one(&self) -> bool {
        match self {
            Integer::Single(n) => *n == 1,
            _ => false,
        }
    }

    #[inline]
    pub fn is_negative(&self) -> bool {
        match self {
            Integer::Single(n) => *n < 0,
            Integer::Double(n) => n.get() < 0,
            Integer::Large(r) => r.is_negative(),
        }
    }

    #[inline]
    pub fn zero() -> Integer {
        Integer::Single(0)
    }

    #[inline]
    pub fn one() -> Integer {
        Integer::Single(1)
    }

    #[inline]
    pub fn to_i64(&self) -> Option<i64> {
        match self {
            Integer::Single(n) => Some(*n),
            _ => None,
        }
    }

    /// Return the number of bits needed for the absolute value.
    #[inline]
    pub fn significant_bits(&self) -> u64 {
        match self {
            Integer::Single(value) => u64::from(i64::BITS - value.unsigned_abs().leading_zeros()),
            Integer::Double(value) => {
                u64::from(i128::BITS - value.get().unsigned_abs().leading_zeros())
            }
            Integer::Large(value) => value.significant_bits(),
        }
    }

    pub fn abs(&self) -> Integer {
        match self {
            Integer::Single(n) => {
                if *n == i64::MIN {
                    Integer::from_double((*n as i128).abs())
                } else {
                    Integer::Single(n.abs())
                }
            }
            Integer::Double(n) => {
                if n.get() == i128::MIN {
                    Integer::Large(MultiPrecisionInteger::from(n.get()).abs())
                } else {
                    Integer::from_double(n.get().abs())
                }
            }
            Integer::Large(n) => Integer::Large(n.clone().abs()),
        }
    }

    pub fn abs_cmp(&self, other: &Self) -> Ordering {
        match (self, other) {
            (Integer::Large(n1), Integer::Large(n2)) => n1.as_abs().cmp(&n2.as_abs()),
            (Integer::Single(n1), Integer::Large(n2)) => n2
                .as_abs()
                .partial_cmp(&n1.unsigned_abs())
                .unwrap_or(Ordering::Equal)
                .reverse(),
            (Integer::Double(n1), Integer::Large(n2)) => n2
                .as_abs()
                .partial_cmp(&n1.get().unsigned_abs())
                .unwrap_or(Ordering::Equal)
                .reverse(),
            (Integer::Large(n1), Integer::Single(n2)) => n1
                .as_abs()
                .partial_cmp(&n2.unsigned_abs())
                .unwrap_or(Ordering::Equal),
            (Integer::Large(n1), Integer::Double(n2)) => n1
                .as_abs()
                .partial_cmp(&n2.get().unsigned_abs())
                .unwrap_or(Ordering::Equal),
            (_, _) => Ord::cmp(&self.abs(), &other.abs()),
        }
    }

    fn get_single_factor(&self) -> Integer {
        for &prime in &SMALL_PRIMES {
            if self % prime == 0 {
                return prime.into();
            }
        }

        if self.is_prime(24) {
            return self.clone();
        }

        // Pollard-Brent is substantially cheaper than setting up ECM for
        // machine-sized integers. `is_prime` above is deterministic for u64,
        // so the composite-modulus requirement is guaranteed here.
        if let Some(c) = self.to_u64() {
            return Zp64::new_non_prime(c).pollard_brent_rho().into();
        }

        if matches!(self, Integer::Double(_)) {
            if let Some(f) =
                FiniteField::<Integer>::new_non_prime(self.clone()).try_pollard_brent_rho(50_000)
            {
                return f;
            }

            if let Some(f) = self.ecm_factor(15, 2_000, 100_000) {
                return f;
            }
        }

        if let Some(f) = self.ecm_factor(50, 10_000, 1_000_000) {
            return f;
        }

        FiniteField::<Integer>::new_non_prime(self.clone()).pollard_brent_rho()
    }

    fn ecm_montgomery_double(
        p: &EcmMontgomeryPoint,
        a24: &FiniteFieldElement<MultiPrecisionInteger>,
        field: &FiniteField<MultiPrecisionInteger>,
    ) -> EcmMontgomeryPoint {
        let x_plus_z = field.add(&p.x, &p.z);
        let x_minus_z = field.sub(&p.x, &p.z);
        let u = field.mul(&x_plus_z, &x_plus_z);
        let v = field.mul(&x_minus_z, &x_minus_z);
        let diff = field.sub(&u, &v);

        EcmMontgomeryPoint {
            x: field.mul(&u, &v),
            z: field.mul(&diff, &field.add(&v, &field.mul(a24, &diff))),
        }
    }

    fn ecm_montgomery_add(
        p: &EcmMontgomeryPoint,
        q: &EcmMontgomeryPoint,
        diff: &EcmMontgomeryPoint,
        field: &FiniteField<MultiPrecisionInteger>,
    ) -> EcmMontgomeryPoint {
        let u = field.mul(&field.sub(&p.x, &p.z), &field.add(&q.x, &q.z));
        let v = field.mul(&field.add(&p.x, &p.z), &field.sub(&q.x, &q.z));
        let add = field.add(&u, &v);
        let sub = field.sub(&u, &v);

        EcmMontgomeryPoint {
            x: field.mul(&diff.z, &field.mul(&add, &add)),
            z: field.mul(&diff.x, &field.mul(&sub, &sub)),
        }
    }

    fn ecm_montgomery_mul(
        p: &EcmMontgomeryPoint,
        k: u64,
        a24: &FiniteFieldElement<MultiPrecisionInteger>,
        field: &FiniteField<MultiPrecisionInteger>,
    ) -> EcmMontgomeryPoint {
        if k == 0 {
            return EcmMontgomeryPoint {
                x: field.one(),
                z: field.zero(),
            };
        }

        if k == 1 {
            return p.clone();
        }

        let mut r0 = p.clone();
        let mut r1 = Self::ecm_montgomery_double(p, a24, field);

        let bit = 63 - k.leading_zeros();
        for i in (0..bit).rev() {
            if (k >> i) & 1 == 0 {
                r1 = Self::ecm_montgomery_add(&r0, &r1, p, field);
                r0 = Self::ecm_montgomery_double(&r0, a24, field);
            } else {
                r0 = Self::ecm_montgomery_add(&r0, &r1, p, field);
                r1 = Self::ecm_montgomery_double(&r1, a24, field);
            }
        }

        r0
    }

    fn ecm_montgomery_stage2(
        q: &EcmMontgomeryPoint,
        primes: &[u64],
        stage1_bound: u64,
        stage2_bound: u64,
        a24: &FiniteFieldElement<MultiPrecisionInteger>,
        field: &FiniteField<MultiPrecisionInteger>,
        n: &Integer,
    ) -> Option<Integer> {
        let d = Self::ecm_montgomery_stage2_window(stage1_bound, stage2_bound)?;
        let q2 = Self::ecm_montgomery_double(q, a24, field);

        let mut baby = Vec::with_capacity(d as usize);
        let mut beta = Vec::with_capacity(d as usize);
        baby.push(q.clone());
        beta.push(field.mul(&q.x, &q.z));

        if d > 1 {
            baby.push(Self::ecm_montgomery_add(&q2, q, q, field));
            beta.push(field.mul(&baby[1].x, &baby[1].z));
        }

        for i in 2..d as usize {
            baby.push(Self::ecm_montgomery_add(
                &baby[i - 1],
                &q2,
                &baby[i - 2],
                field,
            ));
            beta.push(field.mul(&baby[i].x, &baby[i].z));
        }

        let step = Self::ecm_montgomery_mul(q, 4 * d, a24, field);
        let mut previous = Self::ecm_montgomery_mul(q, stage1_bound - 2 * d, a24, field);
        let mut giant = Self::ecm_montgomery_mul(q, stage1_bound + 2 * d, a24, field);
        let mut prime_index = primes.partition_point(|p| *p < stage1_bound);
        let mut product = field.one();
        let step_width = usize::try_from(4 * d).ok()?;

        for center in ((stage1_bound + 2 * d)..(stage2_bound + 2 * d)).step_by(step_width) {
            let window_end = center + 2 * d;
            let block_prime_start = prime_index;
            let alpha = field.mul(&giant.x, &giant.z);

            while prime_index < primes.len() && primes[prime_index] < window_end {
                let prime = primes[prime_index];
                if prime > stage1_bound {
                    let delta = prime.abs_diff(center) >> 1;
                    if delta < d {
                        let delta = delta as usize;
                        let f = field.add(
                            &field.sub(
                                &field.mul(
                                    &field.sub(&giant.x, &baby[delta].x),
                                    &field.add(&giant.z, &baby[delta].z),
                                ),
                                &alpha,
                            ),
                            &beta[delta],
                        );
                        field.mul_assign(&mut product, &f);
                    }
                }

                prime_index += 1;
            }

            let g = field.to_integer(&product).gcd(n);
            if g > 1 && g < *n {
                return Some(g);
            }
            if g == *n {
                for prime in &primes[block_prime_start..prime_index] {
                    if *prime > stage1_bound {
                        let delta = prime.abs_diff(center) >> 1;
                        if delta < d {
                            let delta = delta as usize;
                            let f = field.add(
                                &field.sub(
                                    &field.mul(
                                        &field.sub(&giant.x, &baby[delta].x),
                                        &field.add(&giant.z, &baby[delta].z),
                                    ),
                                    &alpha,
                                ),
                                &beta[delta],
                            );
                            let g = field.to_integer(&f).gcd(n);
                            if g > 1 && g < *n {
                                return Some(g);
                            }
                        }
                    }
                }
                return None;
            }

            let next = Self::ecm_montgomery_add(&giant, &step, &previous, field);
            previous = giant;
            giant = next;
        }

        None
    }

    fn ecm_montgomery_stage2_window(stage1_bound: u64, stage2_bound: u64) -> Option<u64> {
        if stage2_bound <= stage1_bound || stage1_bound < 6 {
            return None;
        }

        let sqrt_b2 = (stage2_bound as f64).sqrt() as u64;
        Some(sqrt_b2.min(stage1_bound / 2 - 1).max(1))
    }

    fn ecm_montgomery_curve(
        sigma: Integer,
        field: &FiniteField<MultiPrecisionInteger>,
        n: &Integer,
    ) -> Result<
        (
            EcmMontgomeryPoint,
            FiniteFieldElement<MultiPrecisionInteger>,
        ),
        Integer,
    > {
        let sigma = field.to_element(sigma.to_multi_prec());
        let u = field.sub(
            &field.mul(&sigma, &sigma),
            &field.to_element(MultiPrecisionInteger::from(5)),
        );
        let v = field.mul(&field.to_element(MultiPrecisionInteger::from(4)), &sigma);
        let u3 = field.mul(&u, &field.mul(&u, &u));
        let v3 = field.mul(&v, &field.mul(&v, &v));

        let v_minus_u = field.sub(&v, &u);
        let numerator = field.mul(
            &field.mul(&v_minus_u, &field.mul(&v_minus_u, &v_minus_u)),
            &field.add(
                &field.mul(&field.to_element(MultiPrecisionInteger::from(3)), &u),
                &v,
            ),
        );
        let denominator = field.mul(
            &field.to_element(MultiPrecisionInteger::from(16)),
            &field.mul(&u3, &v),
        );
        let g = field.to_integer(&denominator).gcd(n);
        if g > 1 {
            return Err(g);
        }

        Ok((
            EcmMontgomeryPoint { x: u3, z: v3 },
            field.mul(&numerator, &field.inv(&denominator)),
        ))
    }

    /// Try to find a nontrivial factor using Lenstra ECM with Montgomery stage 1 and stage 2.
    pub fn ecm_factor(
        &self,
        curves: usize,
        stage1_bound: u64,
        stage2_bound: u64,
    ) -> Option<Integer> {
        if self <= &Integer::from(3) || self.is_prime(24) {
            return None;
        }

        if self % 2 == 0 {
            return Some(Integer::from(2));
        }

        let field = FiniteField::<MultiPrecisionInteger>::new(self.clone().to_multi_prec());
        let stage2_prime_bound =
            if let Some(d) = Self::ecm_montgomery_stage2_window(stage1_bound, stage2_bound) {
                stage2_bound + 2 * d
            } else {
                stage2_bound
            };
        let mut primes = vec![2];
        primes.extend(PrimeIteratorU64::new(2).take_while(|p| *p <= stage2_prime_bound));
        let mut stage1_primes = vec![2];
        stage1_primes.extend(PrimeIteratorU64::new(2).take_while(|p| *p <= stage1_bound));

        for curve in 0..curves {
            let sigma = Integer::from(curve as u64 + 6);
            let (mut point, a24) = match Self::ecm_montgomery_curve(sigma, &field, self) {
                Ok(curve) => curve,
                Err(g) if g > 1 && g < *self => return Some(g),
                Err(_) => continue,
            };

            let mut failed_curve = false;
            for p in &stage1_primes {
                let mut q = *p;
                while q <= stage1_bound / *p {
                    q *= *p;
                }

                point = Self::ecm_montgomery_mul(&point, q, &a24, &field);
                let g = field.to_integer(&point.z).gcd(self);
                if g > 1 && g < *self {
                    return Some(g);
                }
                if g == *self {
                    failed_curve = true;
                    break;
                }
            }

            if failed_curve {
                continue;
            }

            if let Some(g) = Self::ecm_montgomery_stage2(
                &point,
                &primes,
                stage1_bound,
                stage2_bound,
                &a24,
                &field,
                self,
            ) {
                return Some(g);
            }
        }

        None
    }

    /// Factor the integer, yielding unsorted and unmerged `(factor, exponent)` pairs in `factors`.
    fn factor_into(&self, factors: &mut Vec<(Integer, Integer)>) {
        let mut n = self.clone();

        if n < 2 {
            if factors.is_empty() {
                factors.push((n, Integer::one()));
            }
            return;
        }

        let mut fac_count = Integer::zero();
        while &n % 2 == 0 {
            n /= 2;
            fac_count += 1;
        }

        if fac_count > 0 {
            factors.push((Integer::Single(2), fac_count));
        }

        while n > 1 {
            let f = n.get_single_factor();

            if n == f {
                factors.push((f, Integer::one()));
                break;
            }

            let factor_len = factors.len();
            f.factor_into(factors);

            fac_count = Integer::zero();
            loop {
                let (q, r) = n.quot_rem(&f);
                if !r.is_zero() {
                    break;
                }

                fac_count += 1;
                n = q;
            }

            for x in &mut factors[factor_len..] {
                x.1 *= &fac_count;
            }
        }
    }

    /// Factor the integer, returning a sorted vector of `(factor, exponent)` pairs.
    pub fn factor(&self) -> Vec<(Integer, Integer)> {
        let mut factors = vec![];
        self.factor_into(&mut factors);

        factors.sort_unstable();

        let mut merged = 0;
        for i in 0..factors.len() {
            if merged > 0 && factors[merged - 1].0 == factors[i].0 {
                let exponent = factors[i].1.clone();
                factors[merged - 1].1 += exponent;
            } else {
                if merged != i {
                    factors[merged] = factors[i].clone();
                }
                merged += 1;
            }
        }
        factors.truncate(merged);

        factors
    }

    /// Compute the Euler totient function.
    pub fn totient(&self) -> Integer {
        if self.is_prime(24) {
            return self.clone() - 1;
        }

        let factors = self.factor();

        let mut t = self.clone();
        for (f, _) in factors {
            t = &t - &t / f;
        }

        t
    }

    /// Compute `n` factorial (`n!`).
    pub fn factorial(n: u32) -> Integer {
        if n <= 20 {
            let mut f: i64 = 1;
            for x in 2..=n as i64 {
                f *= x;
            }
            Integer::Single(f)
        } else {
            Integer::Large(MultiPrecisionInteger::factorial(n).complete())
        }
    }

    /// Compute the binomial coefficient `(n k) = n!/(k!(n-k)!)`.
    ///
    /// The implementation does not to overflow.
    pub fn binom(n: i64, mut k: i64) -> Integer {
        if n < 0 || k < 0 || k > n {
            return Integer::zero();
        }
        if k > n / 2 {
            k = n - k
        }
        let mut res = Integer::one();
        for i in 1..=k {
            res *= n - k + i;
            res /= i;
        }
        res
    }

    /// Compute the multinomial coefficient `(k_1+...+k_n)!/(k_1!*...*k_n!)`
    ///
    /// The implementation does not to overflow.
    pub fn multinom(k: &[u32]) -> Integer {
        let mut mcr = Integer::one();
        let mut accum = 0i64;
        for v in k {
            if let Some(res) = accum.checked_add(*v as i64) {
                accum = res;
            } else {
                panic!("Sum of occurrences exceeds i64: {k:?}");
            }

            mcr *= &Self::binom(accum, *v as i64);
        }
        mcr
    }

    /// Compute the truncated `e`-th root of this integer.
    pub fn root(&self, e: u32) -> Integer {
        if e == 0 {
            panic!("Non-positive root is undefined");
        }
        if self.is_negative() {
            panic!("Root of negative integer is not an integer");
        }
        if e == 1 || self <= &Integer::one() {
            return self.clone();
        }

        if let Integer::Large(n) = self {
            return n.root_ref(e).complete().into();
        }

        match self {
            Integer::Single(n) => {
                // Initial guess overestimates to ensure monotonic sequence decrementing
                let mut r = 1u64 << (n.ilog2() / e + 1);
                let k = e as u64;
                loop {
                    let div = r
                        .checked_pow(e - 1)
                        .map(|p| n.unsigned_abs() / p)
                        .unwrap_or(0);
                    let r_new = ((k - 1) * r + div) / k; // Newton iteration

                    if r_new >= r {
                        return r.into();
                    }
                    r = r_new;
                }
            }
            Integer::Double(n) => {
                let n = n.get();
                let mut r = 1u128 << (n.ilog2() / e + 1);
                let k = e as u128;
                loop {
                    let div = r
                        .checked_pow(e - 1)
                        .map(|p| n.unsigned_abs() / p)
                        .unwrap_or(0);
                    let r_new = ((k - 1) * r + div) / k;

                    if r_new >= r {
                        return r.into();
                    }
                    r = r_new;
                }
            }
            Integer::Large(n) => n.root_ref(e).complete().into(),
        }
    }

    /// Test if `self` is a prime number using the Miller-Rabin primality test.
    /// If the test passes `k` times, `self` is prime with a probability of `1-4^(-k)`.
    /// If the test fails, `self` is proven composite.
    ///
    /// For 64-bit numbers, the test is deterministic and `k` is ignored.
    pub fn is_prime(&self, k: usize) -> bool {
        if self <= &Integer::one() {
            return false;
        }
        if self == &Integer::from(2) {
            return true;
        }
        if self % 2 == 0 {
            return false;
        }
        if *self <= u64::MAX {
            Zp64::new(self.to_u64().unwrap()).is_prime_field(k)
        } else {
            FiniteField::<Integer>::new(self.clone()).is_prime_field(k)
        }
    }

    /// Raise `self` to the power of `e`, using binary exponentiation.
    pub fn pow_i(&self, mut e: Integer) -> Integer {
        let mut x = self.clone();
        let mut y = Integer::one();
        while e != 1 {
            if &e % 2 == 1 {
                y *= &x;
            }

            x = &x * &x;
            e /= 2;
        }

        x * y
    }

    /// Raise `self` to the power of `e`.
    pub fn pow(&self, e: u64) -> Integer {
        if e > u32::MAX as u64 {
            panic!("Power of exponentiation is larger than 2^32: {e}");
        }
        let e = e as u32;

        if e == 0 {
            return Integer::one();
        }

        match self {
            Integer::Single(n1) => {
                if let Some(pn) = n1.checked_pow(e) {
                    Integer::Single(pn)
                } else if let Some(pn) = (*n1 as i128).checked_pow(e) {
                    Integer::from_double(pn)
                } else {
                    Integer::Large(mp_pow_ref_u32(&MultiPrecisionInteger::from(*n1), e))
                }
            }
            Integer::Double(n1) => {
                if let Some(pn) = n1.get().checked_pow(e) {
                    Integer::from_double(pn)
                } else {
                    Integer::Large(mp_pow_ref_u32(&MultiPrecisionInteger::from(n1.get()), e))
                }
            }
            Integer::Large(r) => Integer::Large(mp_pow_ref_u32(r, e)),
        }
    }

    pub fn quot_rem(&self, b: &Integer) -> (Integer, Integer) {
        if b.is_zero() {
            panic!("Cannot divide by zero");
        }

        match (self, b) {
            (Integer::Single(aa), Integer::Single(bb)) => {
                if let Some(q) = aa.checked_div_euclid(*bb) {
                    (Integer::Single(q), self - &(b * &Integer::Single(q)))
                } else {
                    (Integer::from_double(-(i64::MIN as i128)), Integer::zero())
                }
            }
            (Integer::Single(a), Integer::Double(b)) => {
                // we always have |a| <= |b|
                if *a < 0 {
                    if b.get() > 0 {
                        (
                            Integer::Single(-1),
                            Integer::from_double(*a as i128 + b.get()),
                        )
                    } else {
                        (
                            Integer::Single(1),
                            Integer::from_double(*a as i128 - b.get()),
                        )
                    }
                } else {
                    (Integer::zero(), Integer::Single(*a))
                }
            }
            (Integer::Double(aa), Integer::Single(bb)) => {
                if let Some(q) = aa.get().checked_div_euclid(*bb as i128) {
                    let q = Integer::from_double(q);
                    (q.clone(), self - &(b * &q))
                } else {
                    (
                        Integer::Large(MultiPrecisionInteger::from(i128::MIN).neg()),
                        Integer::zero(),
                    )
                }
            }
            (Integer::Double(aa), Integer::Double(bb)) => {
                let q = Integer::from_double(aa.get().div_euclid(bb.get())); // b != -1
                (q.clone(), self - &(b * &q))
            }
            (Integer::Single(a), Integer::Large(b)) => {
                if *a < 0 {
                    if *b > 0 {
                        (Integer::Single(-1), Integer::from((a + b).complete()))
                    } else {
                        (Integer::Single(1), Integer::from((a - b).complete()))
                    }
                } else {
                    (Integer::zero(), Integer::Single(*a))
                }
            }
            (Integer::Large(a), Integer::Single(b)) => {
                let r = a.clone().div_rem_euc(MultiPrecisionInteger::from(*b));
                (Integer::from(r.0), Integer::from(r.1))
            }
            (Integer::Large(a), Integer::Large(b)) => {
                let r = a.clone().div_rem_euc(b.clone());
                (Integer::from(r.0), Integer::from(r.1))
            }

            (Integer::Double(a), Integer::Large(b)) => {
                if a.get() < 0 {
                    if *b > 0 {
                        (Integer::Single(-1), Integer::from((a.get() + b).complete()))
                    } else {
                        (Integer::Single(1), Integer::from((a.get() - b).complete()))
                    }
                } else {
                    (Integer::zero(), Integer::Double(*a))
                }
            }
            (Integer::Large(a), Integer::Double(b)) => {
                let r = a.clone().div_rem_euc(MultiPrecisionInteger::from(b.get()));
                (Integer::from(r.0), Integer::from(r.1))
            }
        }
    }

    pub fn gcd(&self, b: &Integer) -> Integer {
        match (self, b) {
            (Integer::Single(n1), Integer::Single(n2)) => {
                let gcd = gcd_signed(*n1, *n2);
                if gcd == i64::MAX as u64 + 1 {
                    // n1 == n2 == u64::MIN
                    Integer::from_double(gcd as i128)
                } else {
                    Integer::Single(gcd as i64)
                }
            }
            (Integer::Single(n1), Integer::Large(r2))
            | (Integer::Large(r2), Integer::Single(n1)) => {
                let r1 = MultiPrecisionInteger::from(*n1);
                Integer::from(r1.gcd(r2))
            }
            (Integer::Large(r1), Integer::Large(r2)) => Integer::from(r1.clone().gcd(r2)),
            (Integer::Single(r1), Integer::Double(r2))
            | (Integer::Double(r2), Integer::Single(r1)) => {
                Integer::from_double(gcd_signed_i128(*r1 as i128, r2.get()) as i128)
            }
            (Integer::Double(r1), Integer::Double(r2)) => {
                let gcd = gcd_signed_i128(r1.get(), r2.get());
                if gcd == i128::MAX as u128 + 1 {
                    Integer::Large(MultiPrecisionInteger::from(gcd))
                } else {
                    Integer::from_double(gcd as i128)
                }
            }
            (Integer::Double(r1), Integer::Large(r2)) => {
                Integer::from(MultiPrecisionInteger::from(r1.get()).gcd(r2))
            }
            (Integer::Large(r1), Integer::Double(r2)) => {
                Integer::from(r1.clone().gcd(&MultiPrecisionInteger::from(r2.get())))
            }
        }
    }

    pub fn extended_gcd(&self, b: &Integer) -> (Integer, Integer, Integer) {
        match (self, b) {
            (Integer::Single(n1), Integer::Single(n2)) => {
                let (gcd, t, s) = extended_gcd(*n1, *n2);
                if gcd == i64::MAX as u64 + 1 {
                    (
                        Integer::from_double(gcd as i128),
                        Integer::Single(t),
                        Integer::Single(s),
                    )
                } else {
                    (
                        Integer::Single(gcd as i64),
                        Integer::Single(t),
                        Integer::Single(s),
                    )
                }
            }
            (Integer::Single(n1), Integer::Large(r2))
            | (Integer::Large(r2), Integer::Single(n1)) => {
                let r1 = MultiPrecisionInteger::from(*n1);
                let (g, s, t) = r1.extended_gcd(r2.clone(), MultiPrecisionInteger::default());
                (Integer::from(g), Integer::from(s), Integer::from(t))
            }
            (Integer::Large(r1), Integer::Large(r2)) => {
                let (g, s, t) = r1
                    .clone()
                    .extended_gcd(r2.clone(), MultiPrecisionInteger::default());
                (Integer::from(g), Integer::from(s), Integer::from(t))
            }
            (Integer::Single(r1), Integer::Double(r2))
            | (Integer::Double(r2), Integer::Single(r1)) => {
                let (gcd, t, s) = extended_gcd_i128(*r1 as i128, r2.get());
                (
                    Integer::from_double(gcd as i128),
                    Integer::from_double(t),
                    Integer::from_double(s),
                )
            }
            (Integer::Double(r1), Integer::Double(r2)) => {
                let (g, t, s) = extended_gcd_i128(r1.get(), r2.get());
                if g == i128::MAX as u128 + 1 {
                    (
                        Integer::Large(MultiPrecisionInteger::from(g)),
                        Integer::from_double(t),
                        Integer::from_double(s),
                    )
                } else {
                    (
                        Integer::from_double(g as i128),
                        Integer::from_double(t),
                        Integer::from_double(s),
                    )
                }
            }
            (Integer::Double(r1), Integer::Large(r2)) => {
                let (g, s, t) = MultiPrecisionInteger::from(r1.get())
                    .extended_gcd(r2.clone(), MultiPrecisionInteger::default());
                (Integer::from(g), Integer::from(s), Integer::from(t))
            }
            (Integer::Large(r1), Integer::Double(r2)) => {
                let (g, s, t) = r1.clone().extended_gcd(
                    MultiPrecisionInteger::from(r2.get()),
                    MultiPrecisionInteger::default(),
                );
                (Integer::from(g), Integer::from(s), Integer::from(t))
            }
        }
    }

    /// Compute the least common multiple of two integers.
    pub fn lcm(&self, b: &Integer) -> Integer {
        let g = self.gcd(b);
        if g.is_zero() {
            Integer::zero()
        } else {
            (self / &g) * b
        }
    }

    /// Use Garner's algorithm for the Chinese remainder theorem
    /// to reconstruct an `x` that satisfies `n1 = x % p1` and `n2 = x % p2`.
    /// The `x` will be in the range `[-p1*p2/2,p1*p2/2]`.
    pub fn chinese_remainder(
        mut n1: Integer,
        mut n2: Integer,
        p1: Integer,
        p2: Integer,
    ) -> Integer {
        if n1 < 0 {
            n1 += &p1;
        }
        if n2 < 0 {
            n2 += &p2;
        }

        // make sure n1 < n2
        if match (&n1, &n2) {
            (Integer::Single(n1), Integer::Single(n2)) => n1 > n2,
            (Integer::Single(_), Integer::Large(_)) => false,
            (Integer::Single(_), Integer::Double(_)) => false,
            (Integer::Double(_), Integer::Single(_)) => true,
            (Integer::Double(_), Integer::Large(_)) => false,
            (Integer::Large(_), Integer::Single(_)) => true,
            (Integer::Large(_), Integer::Double(_)) => true,
            (Integer::Double(n1), Integer::Double(n2)) => n1.get() > n2.get(),
            (Integer::Large(r1), Integer::Large(r2)) => r1 > r2,
        } {
            return Self::chinese_remainder(n2, n1, p2, p1);
        }

        let p1 = match p1 {
            Integer::Single(n) => MultiPrecisionInteger::from(n),
            Integer::Double(n) => MultiPrecisionInteger::from(n.get()),
            Integer::Large(r) => r,
        };
        let p2 = match p2 {
            Integer::Single(n) => MultiPrecisionInteger::from(n),
            Integer::Double(n) => MultiPrecisionInteger::from(n.get()),
            Integer::Large(r) => r,
        };

        let n1 = match n1 {
            Integer::Single(n) => MultiPrecisionInteger::from(n),
            Integer::Double(n) => MultiPrecisionInteger::from(n.get()),
            Integer::Large(r) => r,
        };
        let n2 = match n2 {
            Integer::Single(n) => MultiPrecisionInteger::from(n),
            Integer::Double(n) => MultiPrecisionInteger::from(n.get()),
            Integer::Large(r) => r,
        };

        // convert to mixed-radix notation
        let gamma1 = (p1.clone() % p2.clone())
            .invert(&p2)
            .unwrap_or_else(|_| panic!("Could not invert {p1} in {p2}"));

        let v1 = ((n2 - n1.clone()) * gamma1) % p2.clone();

        // convert to standard representation
        let r = v1 * p1.clone() + n1;

        let res = if r.clone() * MultiPrecisionInteger::from(2) > p1.clone() * p2.clone() {
            r - p1 * p2
        } else {
            r
        };

        Integer::from(res)
    }

    /// Perform the symmetric mod `p` on `self`.
    #[inline]
    pub fn symmetric_mod(self, p: &Integer) -> Integer {
        let c = self % p;

        if &c + &c > *p { c - p } else { c }
    }

    /// Compute the modular inverse of any signed representative `self` in the ring with size `n`.
    /// `self` and `n` must be coprime.
    pub fn mod_inverse(&self, n: &Integer) -> Integer {
        let mut t0 = Integer::zero();
        let mut r0 = n.clone();
        let (mut t1, mut r1) = if self.is_negative() {
            (-Integer::one(), -self.clone())
        } else {
            (Integer::one(), self.clone())
        };

        while !r1.is_zero() {
            let (q, r) = Z.quot_rem(&r0, &r1);
            (t1, t0) = (&t0 - &(&q * &t1), t1);
            (r1, r0) = (r, r1);
        }

        if r0 > Integer::one() {
            panic!("{self} is not invertible in ring {n}");
        }
        if t0.is_negative() {
            t0 += n;
        }

        t0
    }

    /// Use the PSLQ algorithm to find a vector of integers `a` that satisfies `a.x = 0`,
    /// where every element of `a` is less than `max_coeff`, using a specified tolerance and number
    /// of iterations. The parameter `gamma` must be more than or equal to `2/sqrt(3)`.
    ///
    /// If the procedure runs out of iterations, the current best solution is returned.
    pub fn solve_integer_relation<
        T: FloatLike
            + RealLike
            + Real
            + SingleFloat
            + std::hash::Hash
            + Eq
            + InternalOrdering
            + PartialOrd,
    >(
        x: &[T],
        tolerance: T,
        max_iter: usize,
        max_coeff: Option<Integer>,
        gamma: Option<T>,
    ) -> Result<Vec<Integer>, IntegerRelationError> {
        let gamma = gamma.unwrap_or_else(|| x[0].from_usize(2) / x[0].from_usize(3).sqrt());
        let field = FloatField::from_rep(x[0].clone());
        let n = x.len();

        let mut s = Vec::with_capacity(n);
        let mut sum = x[0].zero();
        for xx in x.iter().rev() {
            sum += xx.clone() * xx;
            s.push(sum.sqrt());
        }
        s.reverse();

        // normalize the input
        let t = s[0].clone();
        let mut y = x
            .iter()
            .map(|xx| xx.clone() / t.clone())
            .collect::<Vec<_>>();
        for ss in &mut s {
            *ss /= &t;
        }

        // construct orthogonal matrix h
        let mut h = Matrix::new(n as u32, n as u32 - 1, field.clone());
        for i in 0..n {
            if i < n - 1 {
                h[(i as u32, i as u32)] = s[i + 1].clone() / &s[i];
            }

            for j in 0..i {
                h[(i as u32, j as u32)] = -y[i].clone() * &y[j] / (s[j].clone() * &s[j + 1]);
            }
        }

        let mut b = Matrix::identity(n as u32, IntegerRing);

        macro_rules! hermite_reduction {
            ($i: expr, $j: expr) => {
                if h[($j, $j)].is_zero() {
                    return Err(IntegerRelationError::PrecisionLimit);
                }

                let t = (h[($i, $j)].clone() / &h[($j, $j)]).round_to_nearest_integer();

                if t.is_zero() {
                    continue;
                }

                let t_f = x[0].from_rational(&(t.clone(), Integer::one()).into());
                let r = t_f.clone() * &y[$i as usize];
                y[$j as usize] += r;

                for k in 0..$j + 1 {
                    let r = t_f.clone() * &h[($j, k)];
                    h[($i, k)] -= r;
                }
                for k in 0..n as u32 {
                    let r = t.clone() * &b[(k, $i)];
                    b[(k, $j)] += r;
                }
            };
        }

        // Hermite reduction
        for i in 1..n as u32 {
            for j in (0..i).rev() {
                hermite_reduction!(i, j);
            }
        }

        for i in 0..max_iter {
            let mut gamma_max = gamma.clone();
            let ms: Vec<_> = (0..n as u32 - 1)
                .map(|i| {
                    if !h[(i, i)].is_finite() {
                        return Err(IntegerRelationError::PrecisionLimit);
                    }

                    let r = h[(i, i)].norm() * &gamma_max;
                    gamma_max *= &gamma;
                    Ok((i, r))
                })
                .collect::<Result<_, _>>()?;
            let m = ms
                .iter()
                .max_by(|(_, x), (_, y)| x.partial_cmp(y).unwrap())
                .unwrap()
                .0;

            y.swap(m as usize, m as usize + 1);
            h.swap_rows(m, m + 1, 0);
            b.swap_cols(m, m + 1);

            // make h lower trapezoidal
            if m < n as u32 - 2 {
                let t0 = (h[(m, m)].clone() * &h[(m, m)] + h[(m, m + 1)].clone() * &h[(m, m + 1)])
                    .sqrt();

                if t0.is_zero() {
                    return Err(IntegerRelationError::PrecisionLimit);
                }

                let t1 = h[(m, m)].clone() / &t0;
                let t2 = h[(m, m + 1)].clone() / &t0;
                for i in m..n as u32 {
                    let t3 = h[(i, m)].clone();
                    let t4 = h[(i, m + 1)].clone();
                    h[(i, m)] = t1.clone() * t3.clone() + t2.clone() * t4.clone();
                    h[(i, m + 1)] = -t2.clone() * t3.clone() + t1.clone() * t4.clone();
                }
            }

            for i in (m + 1)..n as u32 {
                for j in (0..i.min(m + 2)).rev() {
                    hermite_reduction!(i, j);
                }
            }

            if let Some(i) = y.iter().position(|yy| yy.norm() < tolerance) {
                let res = (0..n as u32)
                    .map(|j| b[(j, i as u32)].clone())
                    .collect::<Vec<_>>();

                if let Some(max_coeff) = &max_coeff {
                    if res.iter().all(|r| &r.abs() <= max_coeff) {
                        return Ok(res);
                    }
                } else {
                    return Ok(res);
                }
            }

            // check the norm of the largest element once in a while
            if let Some(max_coeff) = &max_coeff
                && i % 20 == 0
            {
                let mut norm = x[0].zero();
                for i in 0..n as u32 {
                    let mut row_norm_sq = x[0].zero();
                    for j in 0..n as u32 - 1 {
                        row_norm_sq += h[(i, j)].clone() * &h[(i, j)];
                    }

                    if row_norm_sq > norm {
                        norm = row_norm_sq;
                    }
                }

                if &norm.sqrt().inv().round_to_nearest_integer() > max_coeff {
                    return Err(IntegerRelationError::CoefficientLimit);
                }
            }
        }

        // return the best estimate
        let min = y
            .iter()
            .enumerate()
            .min_by(|(_, xx), (_, yy)| {
                xx.norm()
                    .partial_cmp(&yy.norm())
                    .unwrap_or(std::cmp::Ordering::Equal)
            })
            .unwrap()
            .0;
        let res = (0..n as u32)
            .map(|j| b[(j, min as u32)].clone())
            .collect::<Vec<_>>();

        Err(IntegerRelationError::IterationLimit(res))
    }
}

impl Display for Integer {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Integer::Single(n) => n.fmt(f),
            Integer::Double(n) => n.fmt(f),
            Integer::Large(r) => r.fmt(f),
        }
    }
}

impl Display for IntegerRing {
    fn fmt(&self, _: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        Ok(())
    }
}

impl PartialOrd for Integer {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        match (self, other) {
            (Integer::Single(n1), Integer::Single(n2)) => n1.partial_cmp(n2),
            (Integer::Single(n1), Integer::Large(n2)) => n1.partial_cmp(n2),
            (Integer::Large(n1), Integer::Single(n2)) => n1.partial_cmp(n2),
            (Integer::Large(n1), Integer::Large(n2)) => n1.partial_cmp(n2),
            (Integer::Single(n1), Integer::Double(n2)) => (*n1 as i128).partial_cmp(&n2.get()),
            (Integer::Double(n1), Integer::Single(n2)) => n1.get().partial_cmp(&(*n2 as i128)),
            (Integer::Double(n1), Integer::Double(n2)) => n1.get().partial_cmp(&n2.get()),
            (Integer::Double(n1), Integer::Large(n2)) => n1.get().partial_cmp(n2),
            (Integer::Large(n1), Integer::Double(n2)) => n1.partial_cmp(&n2.get()),
        }
    }
}

impl Ord for Integer {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.partial_cmp(other).unwrap()
    }
}

impl Set for IntegerRing {
    type Element = Integer;

    fn size(&self) -> Option<Integer> {
        None
    }
}

impl RingOps<<Self as Set>::Element> for IntegerRing {
    #[inline]
    fn add(&self, a: Self::Element, b: Self::Element) -> Self::Element {
        a + b
    }

    #[inline]
    fn sub(&self, a: Self::Element, b: Self::Element) -> Self::Element {
        a - b
    }

    #[inline]
    fn mul(&self, a: Self::Element, b: Self::Element) -> Self::Element {
        a * b
    }

    #[inline]
    fn add_assign(&self, a: &mut Self::Element, b: Self::Element) {
        *a += b;
    }

    #[inline]
    fn sub_assign(&self, a: &mut Self::Element, b: Self::Element) {
        *a -= b;
    }

    #[inline]
    fn mul_assign(&self, a: &mut Self::Element, b: Self::Element) {
        *a *= b;
    }

    #[inline(always)]
    fn add_mul_assign(&self, a: &mut Self::Element, b: Self::Element, c: Self::Element) {
        a.fused_mul_assign(&b, &c, false)
    }

    #[inline(always)]
    fn sub_mul_assign(&self, a: &mut Self::Element, b: Self::Element, c: Self::Element) {
        a.fused_mul_assign(&b, &c, true)
    }

    #[inline]
    fn neg(&self, a: Self::Element) -> Self::Element {
        a.neg()
    }
}

impl RingOps<&<Self as Set>::Element> for IntegerRing {
    #[inline]
    fn add(&self, a: &Self::Element, b: &Self::Element) -> Self::Element {
        a.clone() + b
    }

    #[inline]
    fn sub(&self, a: &Self::Element, b: &Self::Element) -> Self::Element {
        a.clone() - b
    }

    #[inline]
    fn mul(&self, a: &Self::Element, b: &Self::Element) -> Self::Element {
        a.clone() * b
    }

    #[inline]
    fn add_assign(&self, a: &mut Self::Element, b: &Self::Element) {
        *a += b;
    }

    #[inline]
    fn sub_assign(&self, a: &mut Self::Element, b: &Self::Element) {
        *a -= b;
    }

    #[inline]
    fn mul_assign(&self, a: &mut Self::Element, b: &Self::Element) {
        *a *= b;
    }

    #[inline(always)]
    fn add_mul_assign(&self, a: &mut Self::Element, b: &Self::Element, c: &Self::Element) {
        a.fused_mul_assign(b, c, false)
    }

    #[inline(always)]
    fn sub_mul_assign(&self, a: &mut Self::Element, b: &Self::Element, c: &Self::Element) {
        a.fused_mul_assign(b, c, true)
    }

    #[inline]
    fn neg(&self, a: &Self::Element) -> Self::Element {
        a.clone().neg()
    }
}

impl Ring for IntegerRing {
    #[inline]
    fn zero(&self) -> Self::Element {
        Integer::zero()
    }

    #[inline]
    fn one(&self) -> Self::Element {
        Integer::one()
    }

    #[inline]
    fn nth(&self, n: Integer) -> Self::Element {
        n
    }

    #[inline]
    fn pow(&self, b: &Self::Element, e: u64) -> Self::Element {
        b.pow(e)
    }

    #[inline]
    fn is_zero(&self, a: &Self::Element) -> bool {
        match a {
            Integer::Single(r) => *r == 0,
            Integer::Double(_) => false,
            Integer::Large(_) => false,
        }
    }

    #[inline]
    fn is_one(&self, a: &Self::Element) -> bool {
        match a {
            Integer::Single(r) => *r == 1,
            Integer::Double(_) => false,
            Integer::Large(_) => false,
        }
    }

    fn one_is_gcd_unit() -> bool {
        true
    }

    fn characteristic(&self) -> Integer {
        0.into()
    }

    fn try_inv(&self, a: &Self::Element) -> Option<Self::Element> {
        match a {
            Integer::Single(1) | Integer::Single(-1) => Some(a.clone()),
            _ => None,
        }
    }

    fn try_div(&self, a: &Self::Element, b: &Self::Element) -> Option<Self::Element> {
        if b.is_zero() {
            return None;
        }

        let r = a / b;
        if *a == &r * b { Some(r) } else { None }
    }

    #[inline]
    fn exact_div_owned(&self, a: Self::Element, b: &Self::Element) -> Self::Element {
        debug_assert!(!b.is_zero());
        match a {
            Integer::Large(value) => {
                let quotient = match b {
                    Integer::Single(divisor) => {
                        value.div_exact_owned(&MultiPrecisionInteger::from(*divisor))
                    }
                    Integer::Double(divisor) => {
                        value.div_exact_owned(&MultiPrecisionInteger::from(divisor.get()))
                    }
                    Integer::Large(divisor) => value.div_exact_owned(divisor),
                };
                Integer::from(quotient)
            }
            value => value / b,
        }
    }

    #[inline]
    fn kernels(&self) -> RingKernels<'_, Self::Element> {
        let kernels = RingKernels::empty().with_polynomial(self);
        #[cfg(feature = "integer-gmp")]
        {
            kernels.with_preferred_total_degree_mul_density(5)
        }
        #[cfg(feature = "integer-malachite")]
        {
            kernels
        }
    }

    #[inline]
    fn sub_mul_assign_many<'a, I>(&self, accumulator: &mut Self::Element, products: I)
    where
        Self::Element: 'a,
        I: IntoIterator<Item = (&'a Self::Element, &'a Self::Element)>,
    {
        #[inline(always)]
        fn sub_product(accumulator: &mut MultiPrecisionInteger, left: &Integer, right: &Integer) {
            match (left, right) {
                (Integer::Single(left), Integer::Single(right)) => {
                    *accumulator -= i128::from(*left) * i128::from(*right);
                }
                (Integer::Single(left), Integer::Double(right))
                | (Integer::Double(right), Integer::Single(left)) => {
                    if let Some(product) = i128::from(*left).checked_mul(right.get()) {
                        *accumulator -= product;
                    } else {
                        let right = MultiPrecisionInteger::from(right.get());
                        accumulator.sub_i64_mul_assign(*left, &right);
                    }
                }
                (Integer::Double(left), Integer::Double(right)) => {
                    if let Some(product) = left.get().checked_mul(right.get()) {
                        *accumulator -= product;
                    } else {
                        let right = MultiPrecisionInteger::from(right.get());
                        accumulator.sub_i128_mul_assign(left.get(), &right);
                    }
                }
                (Integer::Single(left), Integer::Large(right))
                | (Integer::Large(right), Integer::Single(left)) => {
                    accumulator.sub_i64_mul_assign(*left, right);
                }
                (Integer::Double(left), Integer::Large(right))
                | (Integer::Large(right), Integer::Double(left)) => {
                    accumulator.sub_i128_mul_assign(left.get(), right);
                }
                (Integer::Large(left), Integer::Large(right)) => {
                    accumulator.sub_mul_assign(left, right);
                }
            }
        }

        let mut products = products.into_iter();
        if matches!(accumulator, Integer::Large(_)) {
            let Integer::Large(mut large) = std::mem::replace(accumulator, Integer::zero()) else {
                unreachable!()
            };
            for (left, right) in products {
                sub_product(&mut large, left, right);
            }
            *accumulator = Integer::from(large);
            return;
        }

        let mut small = match accumulator {
            Integer::Single(value) => i128::from(*value),
            Integer::Double(value) => value.get(),
            Integer::Large(_) => unreachable!(),
        };
        while let Some((left, right)) = products.next() {
            let product = match (left, right) {
                (Integer::Single(left), Integer::Single(right)) => {
                    Some(i128::from(*left) * i128::from(*right))
                }
                (Integer::Single(left), Integer::Double(right))
                | (Integer::Double(right), Integer::Single(left)) => {
                    i128::from(*left).checked_mul(right.get())
                }
                (Integer::Double(left), Integer::Double(right)) => {
                    left.get().checked_mul(right.get())
                }
                _ => None,
            };

            if let Some(next) = product.and_then(|product| small.checked_sub(product)) {
                small = next;
                continue;
            }

            let mut large = MultiPrecisionInteger::from(small);
            sub_product(&mut large, left, right);
            for (left, right) in products {
                sub_product(&mut large, left, right);
            }
            *accumulator = Integer::from(large);
            return;
        }

        *accumulator = Integer::from_double(small);
    }

    fn format<W: std::fmt::Write>(
        &self,
        element: &Self::Element,
        opts: &PrintOptions,
        state: PrintState,
        f: &mut W,
    ) -> Result<bool, Error> {
        element.format(opts, state, f)
    }

    fn has_independent_elements(&self) -> bool {
        true
    }
}

impl SampleableRing for IntegerRing {
    type SamplingPolicy = std::ops::RangeInclusive<Integer>;

    fn sample<R: rand::RngCore + ?Sized>(
        &self,
        rng: &mut R,
        policy: &Self::SamplingPolicy,
    ) -> Self::Element {
        let lower = policy.start();
        let upper = policy.end();
        assert!(lower <= upper, "cannot sample from an empty integer range");

        if let (Some(lower), Some(upper)) = (lower.to_i64(), upper.to_i64()) {
            return rng.random_range(lower..=upper).into();
        }

        let width = upper - lower + Integer::one();
        let bits = (&width - &Integer::one()).significant_bits();
        loop {
            let partial_bits = bits % u64::BITS as u64;
            let mut candidate = if partial_bits == 0 {
                MultiPrecisionInteger::from(0)
            } else {
                MultiPrecisionInteger::from(rng.next_u64() >> (u64::BITS as u64 - partial_bits))
            };

            for _ in 0..bits / u64::BITS as u64 {
                candidate = (candidate << u64::BITS) + rng.next_u64();
            }

            let candidate = Integer::from(candidate);
            if candidate < width {
                return lower + candidate;
            }
        }
    }
}

impl OrderedRing for IntegerRing {
    #[inline]
    fn cmp(&self, a: &Self::Element, b: &Self::Element) -> std::cmp::Ordering {
        Ord::cmp(a, b)
    }
}

impl SelfRing for Integer {
    fn is_zero(&self) -> bool {
        self.is_zero()
    }

    fn is_one(&self) -> bool {
        self.is_one()
    }

    fn format<W: std::fmt::Write>(
        &self,
        opts: &PrintOptions,
        state: PrintState,
        f: &mut W,
    ) -> Result<bool, Error> {
        match self {
            Integer::Single(n) => {
                if state.suppress_one {
                    if *n == 1 {
                        if state.in_sum {
                            write!(f, "+")?;
                            return Ok(true);
                        } else {
                            write!(f, "")?;
                            return Ok(true);
                        }
                    } else if *n == -1 {
                        write!(f, "-")?;
                        return Ok(true);
                    }
                }

                if state.in_sum {
                    write!(f, "{n:+}")?
                } else {
                    write!(f, "{n}")?
                }
            }
            Integer::Double(n) => {
                if state.in_sum {
                    write!(f, "{n:+}")?
                } else {
                    write!(f, "{n}")?
                }
            }
            Integer::Large(r) => {
                if opts.explicit_rational_polynomial {
                    // write the GMP number in hexadecimal representation,
                    // since the conversion is much faster than for the decimal representation
                    if r.is_negative() {
                        write!(f, "-#{:X}", r.as_abs())?
                    } else if state.in_sum {
                        write!(f, "+#{r:X}")?
                    } else {
                        write!(f, "#{r:X}")?
                    }
                } else if state.in_sum {
                    write!(f, "{r:+}")?
                } else {
                    write!(f, "{r}")?
                }
            }
        }

        Ok(false)
    }
}

impl EuclideanDomain for IntegerRing {
    fn rem(&self, a: &Self::Element, b: &Self::Element) -> Self::Element {
        a % b
    }

    fn quot_rem(&self, a: &Self::Element, b: &Self::Element) -> (Self::Element, Self::Element) {
        a.quot_rem(b)
    }

    fn gcd(&self, a: &Self::Element, b: &Self::Element) -> Self::Element {
        a.gcd(b)
    }
}

impl<'b> Add<&'b Integer> for Integer {
    type Output = Integer;

    #[inline(always)]
    fn add(self, rhs: &'b Integer) -> Integer {
        if let Integer::Large(r) = self {
            match rhs {
                Integer::Single(n) => Integer::from(*n + r),
                Integer::Double(n) => Integer::from(n.get() + r),
                Integer::Large(n) => Integer::from(n + r),
            }
        } else {
            &self + rhs
        }
    }
}

impl Add<Integer> for Integer {
    type Output = Integer;

    #[inline(always)]
    fn add(self, rhs: Integer) -> Integer {
        if let Integer::Large(r) = self {
            match rhs {
                Integer::Single(n) => Integer::from(n + r),
                Integer::Double(n) => Integer::from(n.get() + r),
                Integer::Large(n) => Integer::from(n + r),
            }
        } else if let Integer::Large(r) = rhs {
            match self {
                Integer::Single(n) => Integer::from(n + r),
                Integer::Double(n) => Integer::from(n.get() + r),
                Integer::Large(n) => Integer::from(n + r),
            }
        } else {
            self + &rhs
        }
    }
}

impl Add<Integer> for &Integer {
    type Output = Integer;

    #[inline(always)]
    fn add(self, rhs: Integer) -> Integer {
        rhs + self
    }
}

impl<'b> Add<&'b Integer> for &Integer {
    type Output = Integer;

    #[inline(always)]
    fn add(self, rhs: &'b Integer) -> Integer {
        match (self, rhs) {
            (Integer::Single(n1), Integer::Single(n2)) => {
                if let Some(num) = n1.checked_add(*n2) {
                    Integer::Single(num)
                } else {
                    Integer::from_double(*n1 as i128 + *n2 as i128)
                }
            }
            (Integer::Single(n1), Integer::Double(r2))
            | (Integer::Double(r2), Integer::Single(n1)) => {
                if let Some(num) = (*n1 as i128).checked_add(r2.get()) {
                    Integer::from_double(num)
                } else {
                    Integer::Large(MultiPrecisionInteger::from(r2.get()) + *n1)
                }
            }
            (Integer::Double(r1), Integer::Double(r2)) => {
                if let Some(num) = r1.get().checked_add(r2.get()) {
                    Integer::from_double(num)
                } else {
                    Integer::Large(MultiPrecisionInteger::from(r1.get()) + r2.get())
                }
            }
            (Integer::Single(n1), Integer::Large(r2))
            | (Integer::Large(r2), Integer::Single(n1)) => Integer::from((n1 + r2).complete()),
            (Integer::Double(n1), Integer::Large(r2))
            | (Integer::Large(r2), Integer::Double(n1)) => {
                Integer::from((n1.get() + r2).complete())
            }
            (Integer::Large(r1), Integer::Large(r2)) => Integer::from((r1 + r2).complete()),
        }
    }
}

impl Sub<&Integer> for Integer {
    type Output = Integer;

    #[inline(always)]
    fn sub(self, rhs: &Integer) -> Integer {
        if let Integer::Large(s) = self {
            match rhs {
                Integer::Single(r) => Integer::from(s - r),
                Integer::Double(r) => Integer::from(s - r.get()),
                Integer::Large(r) => Integer::from(s - r),
            }
        } else {
            &self - rhs
        }
    }
}

impl Sub<Integer> for &Integer {
    type Output = Integer;

    #[inline(always)]
    fn sub(self, rhs: Integer) -> Integer {
        if let Integer::Large(r) = rhs {
            match self {
                Integer::Single(s) => Integer::from(*s - r),
                Integer::Double(s) => Integer::from(s.get() - r),
                Integer::Large(s) => Integer::from(s - r),
            }
        } else {
            self - &rhs
        }
    }
}

impl Sub<Integer> for Integer {
    type Output = Integer;

    #[inline(always)]
    fn sub(self, rhs: Integer) -> Integer {
        if let Integer::Large(s) = self {
            match rhs {
                Integer::Single(r) => Integer::from(s - r),
                Integer::Double(r) => Integer::from(s - r.get()),
                Integer::Large(r) => Integer::from(s - r),
            }
        } else if let Integer::Large(r) = rhs {
            match self {
                Integer::Single(s) => Integer::from(s - r),
                Integer::Double(s) => Integer::from(s.get() - r),
                Integer::Large(s) => Integer::from(s - r),
            }
        } else {
            self - &rhs
        }
    }
}

impl<'b> Sub<&'b Integer> for &Integer {
    type Output = Integer;

    #[inline(always)]
    fn sub(self, rhs: &'b Integer) -> Integer {
        match (self, rhs) {
            (Integer::Single(n1), Integer::Single(n2)) => {
                if let Some(num) = n1.checked_sub(*n2) {
                    Integer::Single(num)
                } else {
                    Integer::from_double(*n1 as i128 - *n2 as i128)
                }
            }
            (Integer::Single(n1), Integer::Double(r2)) => {
                if let Some(num) = (*n1 as i128).checked_sub(r2.get()) {
                    Integer::from_double(num)
                } else {
                    Integer::Large(MultiPrecisionInteger::from(*n1) - r2.get())
                }
            }
            (Integer::Double(r1), Integer::Single(r2)) => {
                if let Some(num) = r1.get().checked_sub(*r2 as i128) {
                    Integer::from_double(num)
                } else {
                    Integer::Large(MultiPrecisionInteger::from(r1.get()) - *r2)
                }
            }
            (Integer::Double(r1), Integer::Double(r2)) => {
                if let Some(num) = r1.get().checked_sub(r2.get()) {
                    Integer::from_double(num)
                } else {
                    Integer::Large(MultiPrecisionInteger::from(r1.get()) - r2.get())
                }
            }
            (Integer::Single(n1), Integer::Large(r2)) => Integer::from((n1 - r2).complete()),
            (Integer::Large(r1), Integer::Single(n2)) => Integer::from((r1 - *n2).complete()),
            (Integer::Double(n1), Integer::Large(r2)) => Integer::from((n1.get() - r2).complete()),
            (Integer::Large(r1), Integer::Double(n2)) => Integer::from((r1 - n2.get()).complete()),
            (Integer::Large(r1), Integer::Large(r2)) => Integer::from((r1 - r2).complete()),
        }
    }
}

impl<'a> Mul<&'a Integer> for Integer {
    type Output = Integer;

    #[inline(always)]
    fn mul(self, rhs: &'a Integer) -> Integer {
        if let Integer::Large(r) = self {
            match rhs {
                Integer::Single(n) => Integer::from(*n * r),
                Integer::Double(n) => Integer::from(n.get() * r),
                Integer::Large(n) => Integer::from(n * r),
            }
        } else {
            &self * rhs
        }
    }
}

impl Mul<Integer> for &Integer {
    type Output = Integer;

    #[inline(always)]
    fn mul(self, rhs: Integer) -> Integer {
        rhs * self
    }
}

impl Mul<Integer> for Integer {
    type Output = Integer;

    #[inline(always)]
    fn mul(self, rhs: Integer) -> Integer {
        if let Integer::Large(r) = self {
            match rhs {
                Integer::Single(n) => Integer::from(n * r),
                Integer::Double(n) => Integer::from(n.get() * r),
                Integer::Large(n) => Integer::from(n * r),
            }
        } else if let Integer::Large(r) = rhs {
            match self {
                Integer::Single(n) => Integer::from(n * r),
                Integer::Double(n) => Integer::from(n.get() * r),
                Integer::Large(n) => Integer::from(n * r),
            }
        } else {
            self * &rhs
        }
    }
}

impl<'b> Mul<&'b Integer> for &Integer {
    type Output = Integer;

    #[inline(always)]
    fn mul(self, rhs: &'b Integer) -> Integer {
        match (self, rhs) {
            (Integer::Single(n1), Integer::Single(n2)) => {
                if let Some(num) = n1.checked_mul(*n2) {
                    Integer::Single(num)
                } else {
                    Integer::from_double(*n1 as i128 * *n2 as i128)
                }
            }
            (Integer::Single(n1), Integer::Double(r2))
            | (Integer::Double(r2), Integer::Single(n1)) => {
                if let Some(num) = (*n1 as i128).checked_mul(r2.get()) {
                    Integer::from_double(num)
                } else {
                    Integer::Large(
                        MultiPrecisionInteger::from(r2.get()) * MultiPrecisionInteger::from(*n1),
                    )
                }
            }
            (Integer::Double(r1), Integer::Double(r2)) => {
                if let Some(num) = r1.get().checked_mul(r2.get()) {
                    Integer::from_double(num)
                } else {
                    Integer::Large(
                        MultiPrecisionInteger::from(r1.get())
                            * MultiPrecisionInteger::from(r2.get()),
                    )
                }
            }
            (Integer::Single(n1), Integer::Large(r2))
            | (Integer::Large(r2), Integer::Single(n1)) => Integer::from((n1 * r2).complete()),
            (Integer::Double(n1), Integer::Large(r2))
            | (Integer::Large(r2), Integer::Double(n1)) => {
                Integer::from((n1.get() * r2).complete())
            }
            (Integer::Large(r1), Integer::Large(r2)) => Integer::from((r1 * r2).complete()),
        }
    }
}

impl Div<&Integer> for Integer {
    type Output = Integer;

    #[inline(always)]
    fn div(self, rhs: &Integer) -> Integer {
        if let Integer::Large(s) = self {
            match rhs {
                Integer::Single(r) => Integer::from(s / r),
                Integer::Double(r) => Integer::from(s / r.get()),
                Integer::Large(r) => Integer::from(s / r),
            }
        } else {
            &self / rhs
        }
    }
}

impl Div<Integer> for &Integer {
    type Output = Integer;

    #[inline(always)]
    fn div(self, rhs: Integer) -> Integer {
        if let Integer::Large(r) = rhs {
            match self {
                Integer::Single(s) => Integer::from(*s / r),
                Integer::Double(s) => Integer::from(s.get() / r),
                Integer::Large(s) => Integer::from(s / r),
            }
        } else {
            self / &rhs
        }
    }
}

impl Div<Integer> for Integer {
    type Output = Integer;

    #[inline(always)]
    fn div(self, rhs: Integer) -> Integer {
        if let Integer::Large(s) = self {
            match rhs {
                Integer::Single(r) => Integer::from(s / r),
                Integer::Double(r) => Integer::from(s / r.get()),
                Integer::Large(r) => Integer::from(s / r),
            }
        } else if let Integer::Large(r) = rhs {
            match self {
                Integer::Single(s) => Integer::from(s / r),
                Integer::Double(s) => Integer::from(s.get() / r),
                Integer::Large(s) => Integer::from(s / r),
            }
        } else {
            self / &rhs
        }
    }
}

impl<'b> Div<&'b Integer> for &Integer {
    type Output = Integer;

    #[inline(always)]
    fn div(self, rhs: &'b Integer) -> Integer {
        match (self, rhs) {
            (Integer::Single(n1), Integer::Single(n2)) => {
                if let Some(num) = n1.checked_div(*n2) {
                    Integer::Single(num)
                } else {
                    Integer::from_double(*n1 as i128 / *n2 as i128)
                }
            }
            (Integer::Single(n1), Integer::Double(r2)) => {
                if let Some(num) = (*n1 as i128).checked_div(r2.get()) {
                    Integer::from_double(num)
                } else {
                    Integer::Large(MultiPrecisionInteger::from(*n1) / r2.get())
                }
            }
            (Integer::Double(r1), Integer::Single(r2)) => {
                if let Some(num) = r1.get().checked_div(*r2 as i128) {
                    Integer::from_double(num)
                } else {
                    Integer::Large(MultiPrecisionInteger::from(r1.get()) / *r2)
                }
            }
            (Integer::Double(r1), Integer::Double(r2)) => {
                if let Some(num) = r1.get().checked_div(r2.get()) {
                    Integer::from_double(num)
                } else {
                    Integer::Large(MultiPrecisionInteger::from(r1.get()) / r2.get())
                }
            }
            (Integer::Single(n1), Integer::Large(r2)) => Integer::from((n1 / r2).complete()),
            (Integer::Large(r1), Integer::Single(n2)) => Integer::from((r1 / *n2).complete()),
            (Integer::Double(n1), Integer::Large(r2)) => Integer::from((n1.get() / r2).complete()),
            (Integer::Large(r1), Integer::Double(n2)) => Integer::from((r1 / n2.get()).complete()),
            (Integer::Large(r1), Integer::Large(r2)) => Integer::from((r1 / r2).complete()),
        }
    }
}

macro_rules! bin_op_int {
    ($base: ty) => {
        impl Add<$base> for Integer {
            type Output = Integer;

            #[inline(always)]
            fn add(self, rhs: $base) -> Integer {
                self + Integer::from(rhs)
            }
        }

        impl<'a> Add<$base> for &'a Integer {
            type Output = Integer;

            #[inline(always)]
            fn add(self, rhs: $base) -> Integer {
                self + Integer::from(rhs)
            }
        }

        impl<'a> Add<Integer> for $base {
            type Output = Integer;

            #[inline(always)]
            fn add(self, rhs: Integer) -> Integer {
                rhs + self
            }
        }

        impl<'a> Add<&'a Integer> for $base {
            type Output = Integer;

            #[inline(always)]
            fn add(self, rhs: &'a Integer) -> Integer {
                rhs + self
            }
        }

        impl Sub<$base> for Integer {
            type Output = Integer;

            #[inline(always)]
            fn sub(self, rhs: $base) -> Integer {
                self - Integer::from(rhs)
            }
        }

        impl<'a> Sub<$base> for &'a Integer {
            type Output = Integer;

            #[inline(always)]
            fn sub(self, rhs: $base) -> Integer {
                self - Integer::from(rhs)
            }
        }

        impl<'a> Sub<Integer> for $base {
            type Output = Integer;

            #[inline(always)]
            fn sub(self, rhs: Integer) -> Integer {
                (-rhs) + self
            }
        }

        impl<'a> Sub<&'a Integer> for $base {
            type Output = Integer;

            #[inline(always)]
            fn sub(self, rhs: &'a Integer) -> Integer {
                -(rhs + -(self as i64))
            }
        }

        impl Mul<$base> for Integer {
            type Output = Integer;

            #[inline(always)]
            fn mul(self, rhs: $base) -> Integer {
                self * Integer::from(rhs)
            }
        }

        impl<'a> Mul<$base> for &'a Integer {
            type Output = Integer;

            #[inline(always)]
            fn mul(self, rhs: $base) -> Integer {
                self * Integer::from(rhs)
            }
        }

        impl<'a> Mul<Integer> for $base {
            type Output = Integer;

            #[inline(always)]
            fn mul(self, rhs: Integer) -> Integer {
                rhs * self
            }
        }

        impl<'a> Mul<&'a Integer> for $base {
            type Output = Integer;

            #[inline(always)]
            fn mul(self, rhs: &'a Integer) -> Integer {
                rhs * self
            }
        }

        impl Div<$base> for Integer {
            type Output = Integer;

            #[inline(always)]
            fn div(self, rhs: $base) -> Integer {
                &self / rhs
            }
        }

        impl<'a> Div<$base> for &'a Integer {
            type Output = Integer;

            #[inline(always)]
            fn div(self, rhs: $base) -> Integer {
                self / Integer::from(rhs)
            }
        }

        impl Rem<$base> for Integer {
            type Output = Integer;

            #[inline(always)]
            fn rem(self, rhs: $base) -> Integer {
                &self % rhs
            }
        }

        impl<'a> Rem<$base> for &'a Integer {
            type Output = Integer;

            #[inline(always)]
            fn rem(self, rhs: $base) -> Integer {
                self % Integer::from(rhs)
            }
        }

        impl AddAssign<$base> for Integer {
            #[inline]
            fn add_assign(&mut self, rhs: $base) {
                *self += Integer::from(rhs);
            }
        }

        impl SubAssign<$base> for Integer {
            #[inline]
            fn sub_assign(&mut self, rhs: $base) {
                *self -= Integer::from(rhs);
            }
        }

        impl MulAssign<$base> for Integer {
            #[inline]
            fn mul_assign(&mut self, rhs: $base) {
                *self *= Integer::from(rhs);
            }
        }

        impl DivAssign<$base> for Integer {
            #[inline]
            fn div_assign(&mut self, rhs: $base) {
                *self /= Integer::from(rhs);
            }
        }
    };
}

bin_op_int!(i8);
bin_op_int!(i16);
bin_op_int!(i32);
bin_op_int!(i64);
bin_op_int!(i128);
bin_op_int!(u8);
bin_op_int!(u16);
bin_op_int!(u32);
bin_op_int!(u64);
bin_op_int!(u128);

impl AddAssign<Integer> for Integer {
    #[inline(always)]
    fn add_assign(&mut self, rhs: Integer) {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => l.add_assign(r),
                Integer::Double(r) => l.add_assign(r.get()),
                Integer::Large(r) => l.add_assign(r),
            }

            self.simplify();
        } else {
            *self = rhs + &*self;
        }
    }
}

impl<'a> AddAssign<&'a Integer> for Integer {
    #[inline(always)]
    fn add_assign(&mut self, rhs: &'a Integer) {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => l.add_assign(*r),
                Integer::Double(r) => l.add_assign(r.get()),
                Integer::Large(r) => l.add_assign(r),
            }

            self.simplify();
        } else {
            *self = &*self + rhs;
        }
    }
}

impl SubAssign<Integer> for Integer {
    #[inline(always)]
    fn sub_assign(&mut self, rhs: Integer) {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => l.sub_assign(r),
                Integer::Double(r) => l.sub_assign(r.get()),
                Integer::Large(r) => l.sub_assign(r),
            }

            self.simplify();
        } else {
            *self = &*self - rhs;
        }
    }
}

impl<'a> SubAssign<&'a Integer> for Integer {
    #[inline(always)]
    fn sub_assign(&mut self, rhs: &'a Integer) {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => l.sub_assign(*r),
                Integer::Double(r) => l.sub_assign(r.get()),
                Integer::Large(r) => l.sub_assign(r),
            }

            self.simplify();
        } else {
            *self = &*self - rhs;
        }
    }
}

impl MulAssign<Integer> for Integer {
    #[inline(always)]
    fn mul_assign(&mut self, rhs: Integer) {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => l.mul_assign(r),
                Integer::Double(r) => l.mul_assign(r.get()),
                Integer::Large(r) => l.mul_assign(r),
            }

            self.simplify();
        } else {
            *self = &*self * rhs;
        }
    }
}

impl<'a> MulAssign<&'a Integer> for Integer {
    #[inline(always)]
    fn mul_assign(&mut self, rhs: &'a Integer) {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => l.mul_assign(*r),
                Integer::Double(r) => l.mul_assign(r.get()),
                Integer::Large(r) => l.mul_assign(r),
            }

            self.simplify();
        } else {
            *self = &*self * rhs;
        }
    }
}

impl DivAssign<Integer> for Integer {
    #[inline(always)]
    fn div_assign(&mut self, rhs: Integer) {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => l.div_assign(r),
                Integer::Double(r) => l.div_assign(r.get()),
                Integer::Large(r) => l.div_assign(r),
            }

            self.simplify();
        } else {
            *self = &*self / rhs;
        }
    }
}

impl<'a> DivAssign<&'a Integer> for Integer {
    #[inline(always)]
    fn div_assign(&mut self, rhs: &'a Integer) {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => l.div_assign(*r),
                Integer::Double(r) => l.div_assign(r.get()),
                Integer::Large(r) => l.div_assign(r),
            }

            self.simplify();
        } else {
            *self = &*self / rhs;
        }
    }
}

macro_rules! shift_integer {
    ($base: ty) => {
        impl Shl<$base> for Integer {
            type Output = Integer;

            #[inline(always)]
            fn shl(self, rhs: $base) -> Integer {
                (&self).shl(rhs)
            }
        }

        impl Shl<$base> for &Integer {
            type Output = Integer;

            #[inline(always)]
            fn shl(self, rhs: $base) -> Integer {
                self.shl_usize(usize::try_from(rhs).expect("Shift amount does not fit in usize"))
            }
        }

        impl ShlAssign<$base> for Integer {
            #[inline(always)]
            fn shl_assign(&mut self, rhs: $base) {
                *self = (&*self).shl(rhs);
            }
        }

        impl Shr<$base> for Integer {
            type Output = Integer;

            #[inline(always)]
            fn shr(self, rhs: $base) -> Integer {
                (&self).shr(rhs)
            }
        }

        impl Shr<$base> for &Integer {
            type Output = Integer;

            #[inline(always)]
            fn shr(self, rhs: $base) -> Integer {
                self.shr_usize(usize::try_from(rhs).expect("Shift amount does not fit in usize"))
            }
        }

        impl ShrAssign<$base> for Integer {
            #[inline(always)]
            fn shr_assign(&mut self, rhs: $base) {
                *self = (&*self).shr(rhs);
            }
        }
    };
}

shift_integer!(u8);
shift_integer!(u16);
shift_integer!(u32);
shift_integer!(u64);
shift_integer!(u128);
shift_integer!(usize);

impl<'b> BitAnd<&'b Integer> for Integer {
    type Output = Integer;

    #[inline(always)]
    fn bitand(self, rhs: &'b Integer) -> Integer {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => Integer::from(l & *r),
                Integer::Double(r) => Integer::from(l & r.get()),
                Integer::Large(r) => Integer::from(l & r),
            }
        } else {
            &self & rhs
        }
    }
}

impl BitAnd<Integer> for Integer {
    type Output = Integer;

    #[inline(always)]
    fn bitand(self, rhs: Integer) -> Integer {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => Integer::from(l & r),
                Integer::Double(r) => Integer::from(l & r.get()),
                Integer::Large(r) => Integer::from(l & r),
            }
        } else if let Integer::Large(r) = rhs {
            match self {
                Integer::Single(l) => Integer::from(r & l),
                Integer::Double(l) => Integer::from(r & l.get()),
                Integer::Large(l) => Integer::from(l & r),
            }
        } else {
            &self & &rhs
        }
    }
}

impl BitAnd<Integer> for &Integer {
    type Output = Integer;

    #[inline(always)]
    fn bitand(self, rhs: Integer) -> Integer {
        rhs & self
    }
}

impl<'b> BitAnd<&'b Integer> for &Integer {
    type Output = Integer;

    #[inline(always)]
    fn bitand(self, rhs: &'b Integer) -> Integer {
        match (self, rhs) {
            (Integer::Single(l), Integer::Single(r)) => Integer::Single(l & r),
            (Integer::Single(l), Integer::Double(r)) | (Integer::Double(r), Integer::Single(l)) => {
                Integer::from_double((*l as i128) & r.get())
            }
            (Integer::Double(l), Integer::Double(r)) => Integer::from_double(l.get() & r.get()),
            (Integer::Single(l), Integer::Large(r)) | (Integer::Large(r), Integer::Single(l)) => {
                Integer::from((r & *l).complete())
            }
            (Integer::Double(l), Integer::Large(r)) | (Integer::Large(r), Integer::Double(l)) => {
                Integer::from((r & l.get()).complete())
            }
            (Integer::Large(l), Integer::Large(r)) => Integer::from((l & r).complete()),
        }
    }
}

impl BitAndAssign<Integer> for Integer {
    #[inline(always)]
    fn bitand_assign(&mut self, rhs: Integer) {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => l.bitand_assign(r),
                Integer::Double(r) => l.bitand_assign(r.get()),
                Integer::Large(r) => l.bitand_assign(r),
            }
            self.simplify();
        } else {
            *self = &*self & rhs;
        }
    }
}

impl<'a> BitAndAssign<&'a Integer> for Integer {
    #[inline(always)]
    fn bitand_assign(&mut self, rhs: &'a Integer) {
        if let Integer::Large(l) = self {
            match rhs {
                Integer::Single(r) => l.bitand_assign(*r),
                Integer::Double(r) => l.bitand_assign(r.get()),
                Integer::Large(r) => l.bitand_assign(r),
            }
            self.simplify();
        } else {
            *self = &*self & rhs;
        }
    }
}

impl Neg for Integer {
    type Output = Integer;

    #[inline]
    fn neg(self) -> Self::Output {
        match self {
            Integer::Single(n) => {
                if let Some(neg) = n.checked_neg() {
                    Integer::Single(neg)
                } else {
                    Integer::from_double((n as i128).neg())
                }
            }
            Integer::Double(n) => {
                if let Some(neg) = n.get().checked_neg() {
                    Integer::from_double(neg)
                } else {
                    Integer::Large(MultiPrecisionInteger::from(n.get()).neg())
                }
            }
            Integer::Large(r) => Integer::from(-r),
        }
    }
}

impl Neg for &Integer {
    type Output = Integer;

    #[inline]
    fn neg(self) -> Self::Output {
        match self {
            Integer::Single(n) => {
                if let Some(neg) = n.checked_neg() {
                    Integer::Single(neg)
                } else {
                    Integer::from_double((*n as i128).neg())
                }
            }
            Integer::Double(n) => {
                if let Some(neg) = n.get().checked_neg() {
                    Integer::from_double(neg)
                } else {
                    Integer::Large(MultiPrecisionInteger::from(n.get()).neg())
                }
            }
            Integer::Large(r) => Integer::from(r.clone().neg()),
        }
    }
}

impl Rem<Integer> for Integer {
    type Output = Integer;

    fn rem(self, rhs: Self) -> Self::Output {
        self % &rhs
    }
}

impl<'a> Rem<&'a Integer> for Integer {
    type Output = Integer;

    fn rem(self, rhs: &'a Self) -> Self::Output {
        if rhs.is_zero() {
            panic!("Cannot divide by zero");
        }

        if !self.is_negative() && self < *rhs {
            return self;
        }

        match (self, rhs) {
            (Integer::Large(a), Integer::Single(b)) => Integer::from(a.rem_euc(*b)),
            (Integer::Large(a), Integer::Double(b)) => Integer::from(a.rem_euc(b.get())),
            (Integer::Large(a), Integer::Large(b)) => Integer::from(a.rem_euc_owned_ref(b)),
            (x, _) => (&x).rem(rhs),
        }
    }
}

impl Rem<Integer> for &Integer {
    type Output = Integer;

    fn rem(self, rhs: Integer) -> Self::Output {
        self % &rhs
    }
}

impl Rem for &Integer {
    type Output = Integer;

    fn rem(self, rhs: Self) -> Self::Output {
        if rhs.is_zero() {
            panic!("Cannot divide by zero");
        }

        if !self.is_negative() && self < rhs {
            return self.clone();
        }

        match (self, rhs) {
            (Integer::Single(a), Integer::Single(b)) => {
                if let Some(r) = a.checked_rem_euclid(*b) {
                    Integer::Single(r)
                } else {
                    Integer::zero()
                }
            }
            (Integer::Single(a), Integer::Double(b)) => {
                // b must be larger than a, so division is never needed
                if *a < 0 {
                    if b.get() > 0 {
                        Integer::from_double(*a as i128 + b.get())
                    } else {
                        Integer::from_double(*a as i128 - b.get())
                    }
                } else {
                    Integer::Single(*a)
                }
            }
            (Integer::Single(a), Integer::Large(b)) => {
                if *a < 0 {
                    if *b > 0 {
                        Integer::from((a + b).complete())
                    } else {
                        Integer::from((a - b).complete())
                    }
                } else {
                    Integer::Single(*a)
                }
            }
            (Integer::Double(a), Integer::Large(b)) => {
                if a.get() < 0 {
                    if *b > 0 {
                        Integer::from((a.get() + b).complete())
                    } else {
                        Integer::from((a.get() - b).complete())
                    }
                } else {
                    Integer::Double(*a)
                }
            }
            (Integer::Double(a), Integer::Single(b)) => {
                if let Some(r) = a.get().checked_rem_euclid(*b as i128) {
                    Integer::from_double(r)
                } else {
                    Integer::zero()
                }
            }
            (Integer::Double(a), Integer::Double(b)) => {
                if let Some(r) = a.get().checked_rem_euclid(b.get()) {
                    Integer::from_double(r)
                } else {
                    Integer::zero()
                }
            }
            (Integer::Large(a), Integer::Single(b)) => Integer::from(a.rem_euc(*b).complete()),
            (Integer::Large(a), Integer::Double(b)) => Integer::from(a.rem_euc(b.get()).complete()),
            (Integer::Large(a), Integer::Large(b)) => Integer::from(a.rem_euc(b.clone())),
        }
    }
}

/// A ring for multi-precision integers.
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub struct MultiPrecisionIntegerRing;

impl Display for MultiPrecisionIntegerRing {
    fn fmt(&self, _: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        Ok(())
    }
}

impl Default for MultiPrecisionIntegerRing {
    fn default() -> Self {
        Self::new()
    }
}

impl MultiPrecisionIntegerRing {
    pub fn new() -> MultiPrecisionIntegerRing {
        MultiPrecisionIntegerRing
    }
}

impl InternalOrdering for MultiPrecisionInteger {
    fn internal_cmp(&self, other: &Self) -> std::cmp::Ordering {
        Ord::cmp(self, other)
    }
}

impl Set for MultiPrecisionIntegerRing {
    type Element = MultiPrecisionInteger;

    fn size(&self) -> Option<Integer> {
        None
    }
}

impl RingOps<<Self as Set>::Element> for MultiPrecisionIntegerRing {
    #[inline]
    fn add(&self, a: Self::Element, b: Self::Element) -> Self::Element {
        a + b
    }

    #[inline]
    fn sub(&self, a: Self::Element, b: Self::Element) -> Self::Element {
        a - b
    }

    #[inline]
    fn mul(&self, a: Self::Element, b: Self::Element) -> Self::Element {
        a * b
    }

    #[inline]
    fn add_assign(&self, a: &mut Self::Element, b: Self::Element) {
        *a += b;
    }

    #[inline]
    fn sub_assign(&self, a: &mut Self::Element, b: Self::Element) {
        *a -= b;
    }

    #[inline]
    fn mul_assign(&self, a: &mut Self::Element, b: Self::Element) {
        *a *= b;
    }

    #[inline(always)]
    fn add_mul_assign(&self, a: &mut Self::Element, b: Self::Element, c: Self::Element) {
        a.add_mul_assign(&b, &c)
    }

    #[inline(always)]
    fn sub_mul_assign(&self, a: &mut Self::Element, b: Self::Element, c: Self::Element) {
        a.sub_mul_assign(&b, &c)
    }

    #[inline]
    fn neg(&self, a: Self::Element) -> Self::Element {
        a.neg()
    }
}

impl RingOps<&<Self as Set>::Element> for MultiPrecisionIntegerRing {
    #[inline]
    fn add(&self, a: &Self::Element, b: &Self::Element) -> Self::Element {
        a.clone() + b
    }

    #[inline]
    fn sub(&self, a: &Self::Element, b: &Self::Element) -> Self::Element {
        a.clone() - b
    }

    #[inline]
    fn mul(&self, a: &Self::Element, b: &Self::Element) -> Self::Element {
        a.clone() * b
    }

    #[inline]
    fn add_assign(&self, a: &mut Self::Element, b: &Self::Element) {
        *a += b;
    }

    #[inline]
    fn sub_assign(&self, a: &mut Self::Element, b: &Self::Element) {
        *a -= b;
    }

    #[inline]
    fn mul_assign(&self, a: &mut Self::Element, b: &Self::Element) {
        *a *= b;
    }

    #[inline(always)]
    fn add_mul_assign(&self, a: &mut Self::Element, b: &Self::Element, c: &Self::Element) {
        a.add_mul_assign(b, c)
    }

    #[inline(always)]
    fn sub_mul_assign(&self, a: &mut Self::Element, b: &Self::Element, c: &Self::Element) {
        a.sub_mul_assign(b, c)
    }

    #[inline]
    fn neg(&self, a: &Self::Element) -> Self::Element {
        a.clone().neg()
    }
}

impl Ring for MultiPrecisionIntegerRing {
    #[inline]
    fn zero(&self) -> Self::Element {
        MultiPrecisionInteger::default()
    }

    #[inline]
    fn one(&self) -> Self::Element {
        MultiPrecisionInteger::from(1)
    }

    #[inline]
    fn nth(&self, n: Integer) -> Self::Element {
        n.to_multi_prec()
    }

    #[inline]
    fn pow(&self, b: &Self::Element, e: u64) -> Self::Element {
        if e > u32::MAX as u64 {
            panic!("Power of exponentiation is larger than 2^32: {e}");
        }
        mp_pow_ref_u32(b, e as u32)
    }

    #[inline]
    fn is_zero(&self, a: &Self::Element) -> bool {
        a.is_zero()
    }

    #[inline]
    fn is_one(&self, a: &Self::Element) -> bool {
        *a == self.one()
    }

    fn one_is_gcd_unit() -> bool {
        true
    }

    fn characteristic(&self) -> Integer {
        0.into()
    }

    fn try_inv(&self, a: &Self::Element) -> Option<Self::Element> {
        if *a == 1 || *a == -1 {
            Some(a.clone())
        } else {
            None
        }
    }

    fn try_div(&self, a: &Self::Element, b: &Self::Element) -> Option<Self::Element> {
        mp_try_div_exact(a, b)
    }

    fn format<W: std::fmt::Write>(
        &self,
        element: &Self::Element,
        _opts: &PrintOptions,
        state: PrintState,
        f: &mut W,
    ) -> Result<bool, Error> {
        if state.in_sum {
            write!(f, "{element:+}")?
        } else {
            write!(f, "{element}")?
        }

        Ok(false)
    }

    fn has_independent_elements(&self) -> bool {
        true
    }
}

impl SampleableRing for MultiPrecisionIntegerRing {
    type SamplingPolicy = std::ops::RangeInclusive<Integer>;

    #[inline]
    fn sample<R: rand::RngCore + ?Sized>(
        &self,
        rng: &mut R,
        policy: &Self::SamplingPolicy,
    ) -> Self::Element {
        Z.sample(rng, policy).to_multi_prec()
    }
}

impl OrderedRing for MultiPrecisionIntegerRing {
    #[inline]
    fn cmp(&self, a: &Self::Element, b: &Self::Element) -> std::cmp::Ordering {
        Ord::cmp(a, b)
    }
}

impl EuclideanDomain for MultiPrecisionIntegerRing {
    fn rem(&self, a: &Self::Element, b: &Self::Element) -> Self::Element {
        a.clone() % b
    }

    fn quot_rem(&self, a: &Self::Element, b: &Self::Element) -> (Self::Element, Self::Element) {
        a.clone().div_rem_euc(b.clone())
    }

    fn gcd(&self, a: &Self::Element, b: &Self::Element) -> Self::Element {
        a.clone().gcd(b)
    }
}

/// Compute the GCD of two `u64` numbers.
pub fn gcd_unsigned(mut a: u64, mut b: u64) -> u64 {
    let mut c;
    while a != 0 {
        c = a;
        a = b % a;
        b = c;
    }
    b
}

/// Compute the extended GCD of two `i64` numbers.
pub fn extended_gcd(mut a: i64, mut b: i64) -> (u64, i64, i64) {
    if a.unsigned_abs() < b.unsigned_abs() {
        let (g, s, t) = extended_gcd(b, a);
        return (g, t, s);
    }

    if a == i64::MIN {
        if b == -1 {
            return (1, 0, -1);
        } else if b == i64::MAX {
            return (1, -1, -1);
        }
    }

    let mut s0 = 1;
    let mut s1 = 0;
    let mut t0 = 0;
    let mut t1 = 1;

    while b != 0 {
        let q = a / b;
        (a, b) = (b, a - q * b);
        (s0, s1) = (s1, s0 - q * s1);
        (t0, t1) = (t1, t0 - q * t1);
    }

    (a.unsigned_abs(), s0, t0)
}

/// Compute the extended GCD of two `i128` numbers.
pub fn extended_gcd_i128(mut a: i128, mut b: i128) -> (u128, i128, i128) {
    if a.unsigned_abs() < b.unsigned_abs() {
        let (g, s, t) = extended_gcd_i128(b, a);
        return (g, t, s);
    }

    if a == i128::MIN {
        if b == -1 {
            return (1, 0, -1);
        } else if b == i128::MAX {
            return (1, -1, -1);
        }
    }

    let mut s0 = 1;
    let mut s1 = 0;
    let mut t0 = 0;
    let mut t1 = 1;

    while b != 0 {
        let q = a / b;
        (a, b) = (b, a - q * b);
        (s0, s1) = (s1, s0 - q * s1);
        (t0, t1) = (t1, t0 - q * t1);
    }

    (a.unsigned_abs(), s0, t0)
}

/// Compute the signed GCD of two `i64` numbers.
pub fn gcd_signed(a: i64, b: i64) -> u64 {
    gcd_unsigned(a.unsigned_abs(), b.unsigned_abs())
}

/// Compute the signed GCD of two `i128` numbers.
pub fn gcd_signed_i128(a: i128, b: i128) -> u128 {
    // Computing on magnitudes also handles MIN without a signed overflow case.
    // In particular, no iteration needs signed remainder or its overflow check.
    let (mut a, mut b) = (a.unsigned_abs(), b.unsigned_abs());
    while a != 0 {
        (a, b) = (b % a, a);
    }
    b
}

#[cfg(test)]
mod test {
    use std::{
        mem::{align_of, size_of},
        ops::{Add, Div, Mul, Rem, Sub},
        str::FromStr,
    };

    #[cfg(feature = "float-mpfr")]
    use crate::domains::float::{Float, Real};
    use crate::domains::{
        Ring,
        finite_field::FiniteFieldWorkspace,
        float::F64,
        integer::{IntegerRing, extended_gcd, extended_gcd_i128},
    };
    use crate::kernels::{
        ChunkedDensePolynomialMulRequest, DensePolynomialExactDivisionRequest,
        DensePolynomialMulRequest,
    };

    use super::{DoubleInteger, Integer, MultiPrecisionInteger};

    fn chunked_dense_mul(
        output_len: usize,
        inner_len: usize,
        left_coefficients: &[Integer],
        left_indices: &[u32],
        right_coefficients: &[Integer],
        right_indices: &[u32],
    ) -> Option<Vec<(u32, Integer)>> {
        super::polynomial_kernels::try_chunked_dense_mul_for_test(
            ChunkedDensePolynomialMulRequest {
                dense: DensePolynomialMulRequest {
                    output_len,
                    left_coefficients,
                    left_indices,
                    right_coefficients,
                    right_indices,
                },
                inner_len,
            },
        )
    }

    #[test]
    fn chunked_dense_integer_multiplication() {
        let left_coefficients = [
            Integer::from(1_000_000_000i64),
            Integer::from(-2_000_000_000i64),
            Integer::from(1_000_000_000i64),
            Integer::from(-1_000_000_000i64),
        ];
        let right_coefficients = [
            Integer::from(-1_000_000_000i64),
            Integer::from(2_000_000_000i64),
            Integer::from(1_000_000_000i64),
            Integer::from(-3_000_000_000i64),
        ];
        let actual = chunked_dense_mul(
            32,
            8,
            &left_coefficients,
            &[0, 2, 8, 11],
            &right_coefficients,
            &[0, 1, 8, 10],
        )
        .unwrap();
        let expected = [
            (0, -1),
            (1, 2),
            (2, 2),
            (3, -4),
            (9, 2),
            (10, -5),
            (11, 1),
            (12, 4),
            (16, 1),
            (18, -3),
            (19, -1),
            (21, 3),
        ]
        .map(|(index, coefficient)| {
            (
                index,
                Integer::from_double(coefficient * 1_000_000_000_000_000_000i128),
            )
        });
        assert_eq!(actual, expected);

        let small_left = [1, -2, 1, -1].map(Integer::from);
        let small_right = [-1, 2, 1, -3].map(Integer::from);
        let small_actual = chunked_dense_mul(
            32,
            8,
            &small_left,
            &[0, 2, 8, 11],
            &small_right,
            &[0, 1, 8, 10],
        )
        .unwrap();
        let small_expected = [
            (0, -1),
            (1, 2),
            (2, 2),
            (3, -4),
            (9, 2),
            (10, -5),
            (11, 1),
            (12, 4),
            (16, 1),
            (18, -3),
            (19, -1),
            (21, 3),
        ]
        .map(|(index, coefficient)| (index, Integer::from(coefficient)));
        assert_eq!(small_actual, small_expected);
    }

    #[test]
    fn chunked_dense_integer_multiplication_uses_large_blocked_accumulator() {
        let coefficient = Integer::from(1_000_000_000i64);
        let coefficients = (0..150).map(|_| coefficient.clone()).collect::<Vec<_>>();
        let indices = (0..150).collect::<Vec<_>>();
        let actual =
            chunked_dense_mul(600, 300, &coefficients, &indices, &coefficients, &indices).unwrap();
        let scale = 1_000_000_000_000_000_000i128;
        let expected = (0..299)
            .map(|index| {
                let collisions = if index < 150 { index + 1 } else { 299 - index };
                (
                    index as u32,
                    Integer::from_double(collisions as i128 * scale),
                )
            })
            .collect::<Vec<_>>();
        assert_eq!(actual, expected);
    }

    #[test]
    fn chunked_dense_integer_multiplication_validates_layout_and_work_bounds() {
        let large = [Integer::from(4_000_000_000i64)];
        assert!(chunked_dense_mul(8, 0, &large, &[0], &large, &[0]).is_none());
        assert!(chunked_dense_mul(32, 6, &large, &[0], &large, &[0]).is_none());
        assert!(chunked_dense_mul(16, 8, &large, &[7], &large, &[1]).is_none());
        assert!(
            chunked_dense_mul(
                16,
                8,
                &[large[0].clone(), large[0].clone()],
                &[2, 1],
                &large,
                &[0],
            )
            .is_none()
        );
        assert!(
            chunked_dense_mul(
                16,
                8,
                &[large[0].clone(), large[0].clone()],
                &[1, 1],
                &large,
                &[0],
            )
            .is_none()
        );
        assert!(chunked_dense_mul(257, 1, &large, &[0], &large, &[0]).is_none());

        let small = [Integer::from(3)];
        assert_eq!(
            chunked_dense_mul(8, 8, &small, &[0], &small, &[0]).unwrap(),
            [(0, Integer::from(9))]
        );

        let dense_indices = (0..8).collect::<Vec<_>>();
        let dense_coefficients = (0..8).map(|_| Integer::one()).collect::<Vec<_>>();
        assert!(
            chunked_dense_mul(8, 8, &dense_coefficients, &dense_indices, &small, &[0],).is_none()
        );

        let minimums = [
            Integer::from(i64::MIN),
            Integer::from(i64::MIN),
            Integer::from(i64::MIN),
            Integer::from(i64::MIN),
        ];
        assert!(
            chunked_dense_mul(8, 8, &minimums, &[0, 1, 2, 3], &minimums, &[0, 1, 2, 3]).is_none()
        );
    }

    #[test]
    fn multi_precision_integer_raw_roundtrip_and_common_bit_count() {
        let value = (MultiPrecisionInteger::from(1u32) << 130u32) + 7u32;
        let bits: u64 = value.significant_bits();
        assert_eq!(bits, 131);

        let borrowed = MultiPrecisionInteger::from_raw(value.as_raw().clone());
        assert_eq!(borrowed, value);

        let copied = MultiPrecisionInteger::from_raw(value.to_raw());
        assert_eq!(copied, value);

        let consumed = MultiPrecisionInteger::from_raw(value.clone().into_raw());
        assert_eq!(consumed, value);
    }

    #[test]
    fn fused_large_integer_products() {
        let large_b = Integer::from_str("123456789012345678901234567890123456789").unwrap();
        let large_c = Integer::from_str("987654321098765432109876543210987654321").unwrap();
        let initial = Integer::from(17);
        let expected = &initial + &large_b * &large_c;

        let mut actual = initial.clone();
        actual.fused_mul_assign(&large_b, &large_c, false);
        assert_eq!(actual, expected);

        actual.fused_mul_assign(&large_b, &large_c, true);
        assert_eq!(actual, initial);

        let double = Integer::from(i128::MAX - 17);
        let expected = &large_b + &double * &large_c;
        let mut actual = large_b.clone();
        actual.fused_mul_assign(&double, &large_c, false);
        assert_eq!(actual, expected);

        let single = Integer::from(i64::MIN + 19);
        let expected = &large_c - &single * &large_b;
        let mut actual = large_c;
        actual.fused_mul_assign(&single, &large_b, true);
        assert_eq!(actual, expected);
    }

    #[test]
    fn dense_i128_polynomial_multiplication() {
        let left = vec![3_000_000_000i64.into(), (-5).into(), 7.into()];
        let right = vec![11.into(), 3_000_000_000i64.into(), (-17).into()];
        let indices = [0, 2, 5];
        let actual_sparse = IntegerRing
            .kernels()
            .polynomial()
            .unwrap()
            .try_dense_mul(DensePolynomialMulRequest {
                output_len: 11,
                left_coefficients: &left,
                left_indices: &indices,
                right_coefficients: &right,
                right_indices: &indices,
            })
            .unwrap();
        let mut actual = vec![Integer::zero(); 11];
        for (index, coefficient) in actual_sparse {
            actual[index as usize] = coefficient;
        }

        let mut expected = vec![Integer::zero(); 11];
        for (i, left) in left.iter().enumerate() {
            for (j, right) in right.iter().enumerate() {
                expected[indices[i] as usize + indices[j] as usize] += left * right;
            }
        }
        assert_eq!(actual, expected);
    }

    #[test]
    fn fixed_dense_multiplication_rejects_sparse_coefficient_boxes() {
        let coefficients = [Integer::from(2), Integer::from(3)];
        let indices = [0, 1000];
        assert!(
            IntegerRing
                .kernels()
                .polynomial()
                .unwrap()
                .try_dense_mul(DensePolynomialMulRequest {
                    output_len: 2001,
                    left_coefficients: &coefficients,
                    left_indices: &indices,
                    right_coefficients: &coefficients,
                    right_indices: &indices,
                })
                .is_none()
        );
    }

    #[test]
    fn declined_exact_division_preserves_dividend() {
        let mut dividend = vec![Integer::from(3), Integer::from(5)];
        let before = dividend.clone();
        let divisor = [Integer::from(1), Integer::from(1)];
        let indices = [0, 1];
        let result = IntegerRing
            .kernels()
            .polynomial()
            .unwrap()
            .try_dense_exact_division(DensePolynomialExactDivisionRequest {
                total: 2,
                dividend_coefficients: &mut dividend,
                dividend_indices: &indices,
                divisor_coefficients: &divisor,
                divisor_indices: &indices,
            });
        assert!(result.is_none());
        assert_eq!(dividend, before);
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn simplex_kronecker_layout_is_additive() {
        let left_degree = 4usize;
        let right_degree = 3usize;
        let total_degree = left_degree + right_degree;
        let radix = total_degree + 1;
        let encode_standard = |high: usize, middle: usize, low: usize| {
            u32::try_from((high * radix + middle) * radix + low).unwrap()
        };
        let simplex_indices = |degree: usize| {
            let mut indices = Vec::new();
            for high in 0..=degree {
                for middle in 0..=degree - high {
                    for low in 0..=degree - high - middle {
                        indices.push(encode_standard(high, middle, low));
                    }
                }
            }
            indices.sort_unstable();
            indices
        };
        let left = simplex_indices(left_degree);
        let right = simplex_indices(right_degree);
        let layout = crate::domains::polynomial_layouts::try_simplex_kronecker_layout(
            radix.pow(3),
            left.as_slice(),
            right.as_slice(),
        )
        .unwrap();

        for (&left_standard, &left_compact) in left.iter().zip(&layout.left_indices) {
            for (&right_standard, &right_compact) in right.iter().zip(&layout.right_indices) {
                assert_eq!(
                    layout.decode_indices[(left_compact + right_compact) as usize],
                    left_standard + right_standard,
                );
            }
        }
        assert!(layout.output_len < radix.pow(3));
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn simplex_kronecker_polynomial_multiplication() {
        let left_degree = 24usize;
        let right_degree = 23usize;
        let total_degree = left_degree + right_degree;
        let radix = total_degree + 1;
        let simplex = |degree: usize| {
            let mut terms = Vec::new();
            for high in 0..=degree {
                for middle in 0..=degree - high {
                    for low in 0..=degree - high - middle {
                        let index = ((high * radix + middle) * radix + low) as u32;
                        let coefficient = if (high + 2 * middle + 3 * low) % 5 == 0 {
                            -1
                        } else {
                            1
                        };
                        terms.push((index, Integer::from(coefficient)));
                    }
                }
            }
            terms.sort_unstable_by_key(|term| term.0);
            terms
        };
        let left = simplex(left_degree);
        let right = simplex(right_degree);
        let left_indices = left.iter().map(|term| term.0).collect::<Vec<_>>();
        let right_indices = right.iter().map(|term| term.0).collect::<Vec<_>>();
        let left_coefficients = left.into_iter().map(|term| term.1).collect::<Vec<_>>();
        let right_coefficients = right.into_iter().map(|term| term.1).collect::<Vec<_>>();
        let output_len = radix.pow(3);

        let actual_sparse = super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
            output_len,
            &left_coefficients,
            &left_indices,
            &right_coefficients,
            &right_indices,
        )
        .unwrap();
        assert!(
            actual_sparse
                .windows(2)
                .all(|terms| terms[0].0 < terms[1].0)
        );
        let mut actual = vec![Integer::zero(); output_len];
        for (index, coefficient) in actual_sparse {
            actual[index as usize] = coefficient;
        }

        let mut expected = vec![0i64; output_len];
        for (&left_index, left_coefficient) in left_indices.iter().zip(&left_coefficients) {
            for (&right_index, right_coefficient) in right_indices.iter().zip(&right_coefficients) {
                expected[left_index as usize + right_index as usize] +=
                    left_coefficient.to_i64().unwrap() * right_coefficient.to_i64().unwrap();
            }
        }
        assert_eq!(
            actual,
            expected.into_iter().map(Integer::from).collect::<Vec<_>>()
        );
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn u128_product_bit_length_matches_multiprecision() {
        let values = [
            0,
            1,
            2,
            1u128 << 63,
            1u128 << 64,
            1u128 << 127,
            u128::MAX - 1,
            u128::MAX,
        ];
        for left in values {
            for right in values {
                let expected = (&MultiPrecisionInteger::from(left)
                    * &MultiPrecisionInteger::from(right))
                    .significant_bits();
                assert_eq!(
                    super::polynomial_kernels::u128_product_significant_bits(left, right),
                    expected,
                    "bit length of {left} * {right}",
                );
            }
        }

        let mut state = 0xd1b5_4a32_d192_ed03u64;
        for _ in 0..512 {
            let mut next = || {
                state = state
                    .wrapping_mul(6_364_136_223_846_793_005)
                    .wrapping_add(1_442_695_040_888_963_407);
                state
            };
            let left = (u128::from(next()) << 64) | u128::from(next());
            let right = (u128::from(next()) << 64) | u128::from(next());
            let expected = (&MultiPrecisionInteger::from(left)
                * &MultiPrecisionInteger::from(right))
                .significant_bits();
            assert_eq!(
                super::polynomial_kernels::u128_product_significant_bits(left, right),
                expected,
            );
        }
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn factor_fixture_kronecker_polynomial_multiplication() {
        fn linear_power_coefficients(power: u32, scale: i128) -> Vec<Integer> {
            let mut coefficient = 1i128;
            let mut coefficients = vec![Integer::one()];
            for exponent in 1..=power {
                coefficient = coefficient
                    .checked_mul(i128::from(power - exponent + 1))
                    .and_then(|value| value.checked_mul(scale))
                    .unwrap()
                    / i128::from(exponent);
                coefficients.push(Integer::from(coefficient));
            }
            coefficients
        }

        let left = linear_power_coefficients(32, 3)
            .into_iter()
            .skip(1)
            .collect::<Vec<_>>();
        let mut right = linear_power_coefficients(31, -5);
        right[0] += Integer::one();
        let left_indices = (1..=32).collect::<Vec<u32>>();
        let right_indices = (0..32).collect::<Vec<u32>>();
        let output_len = 64;

        let actual_sparse = super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
            output_len,
            &left,
            &left_indices,
            &right,
            &right_indices,
        )
        .unwrap();
        let mut actual = vec![Integer::zero(); output_len];
        for (index, coefficient) in actual_sparse {
            actual[index as usize] = coefficient;
        }

        let mut expected = vec![Integer::zero(); output_len];
        for (left_coefficient, &left_index) in left.iter().zip(&left_indices) {
            for (right_coefficient, &right_index) in right.iter().zip(&right_indices) {
                expected[left_index as usize + right_index as usize] +=
                    left_coefficient * right_coefficient;
            }
        }
        assert_eq!(actual, expected);
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn contiguous_kronecker_selector_accepts_31_terms() {
        let make_coefficients = |length: usize, offset: i128| {
            (0..length)
                .map(|index| {
                    let value = (1i128 << 70) + offset + index as i128;
                    Integer::from_double(if index % 3 == 0 { -value } else { value })
                })
                .collect::<Vec<_>>()
        };
        let left = make_coefficients(31, 7);
        let right = make_coefficients(34, 101);
        let left_indices = (0..31).collect::<Vec<u32>>();
        let right_indices = (0..34).collect::<Vec<u32>>();

        let actual_sparse = super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
            64,
            &left,
            &left_indices,
            &right,
            &right_indices,
        )
        .expect("a contiguous 31-by-34 product must use Kronecker substitution");
        let mut actual = vec![Integer::zero(); 64];
        for (index, coefficient) in actual_sparse {
            actual[index as usize] = coefficient;
        }

        let mut expected = vec![Integer::zero(); 64];
        for (left_degree, left_coefficient) in left.iter().enumerate() {
            for (right_degree, right_coefficient) in right.iter().enumerate() {
                expected[left_degree + right_degree] += left_coefficient * right_coefficient;
            }
        }
        assert_eq!(actual, expected);

        assert!(
            super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
                63,
                &left[..30],
                &left_indices[..30],
                &right,
                &right_indices,
            )
            .is_none(),
            "the contiguous shortcut must retain its 31-term lower bound"
        );
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn primitive_kronecker_packing_matches_direct_convolution_at_boundaries() {
        let magnitude = 1i128 << 100;
        let values = [
            i128::MIN,
            i128::MAX,
            -magnitude - 3,
            magnitude + 5,
            i128::from(i64::MIN),
            i128::from(i64::MAX),
            -17,
            19,
        ];
        let left = (0..32)
            .map(|index| Integer::from_double(values[index % values.len()]))
            .collect::<Vec<_>>();
        let right = (0..32)
            .map(|index| Integer::from_double(values[(5 * index + 3) % values.len()]))
            .collect::<Vec<_>>();
        let indices = (0..32).collect::<Vec<u32>>();
        let output_len = 63;

        let actual_sparse = super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
            output_len, &left, &indices, &right, &indices,
        )
        .unwrap();
        let mut actual = vec![Integer::zero(); output_len];
        for (index, coefficient) in actual_sparse {
            actual[index as usize] = coefficient;
        }

        let mut expected = vec![Integer::zero(); output_len];
        for (left_coefficient, &left_index) in left.iter().zip(&indices) {
            for (right_coefficient, &right_index) in right.iter().zip(&indices) {
                expected[left_index as usize + right_index as usize] +=
                    left_coefficient * right_coefficient;
            }
        }
        assert_eq!(actual, expected);
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn kronecker_native_decode_handles_radix_limb_boundaries() {
        let indices = (0..32).collect::<Vec<u32>>();
        let output_len = 63;

        for digit_bits in [63usize, 64, 65, 127, 128, 129] {
            // The alternating right-hand side makes the exact convolution coefficients only zero
            // or `scale`, while the signed coefficient bound is exactly `digit_bits` wide.
            let scale = 1i128 << (digit_bits - 7);
            let coefficient_bound = 32 * scale.unsigned_abs();
            assert_eq!(coefficient_bound.ilog2() as usize + 2, digit_bits);
            let left = vec![Integer::from_double(scale); 32];
            let right = (0..32)
                .map(|index| Integer::from(if index % 2 == 0 { 1 } else { -1 }))
                .collect::<Vec<_>>();

            let actual_sparse = super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
                output_len, &left, &indices, &right, &indices,
            );
            let actual_sparse = actual_sparse.unwrap();
            let mut actual = vec![Integer::zero(); output_len];
            for (index, coefficient) in actual_sparse {
                actual[index as usize] = coefficient;
            }

            let mut expected = vec![Integer::zero(); output_len];
            for (left_coefficient, &left_index) in left.iter().zip(&indices) {
                for (right_coefficient, &right_index) in right.iter().zip(&indices) {
                    expected[left_index as usize + right_index as usize] +=
                        left_coefficient * right_coefficient;
                }
            }
            assert_eq!(actual, expected, "failed for {digit_bits}-bit radix");
        }

        // The constant coefficient of this product is exactly i128::MIN. The remaining terms
        // keep the coefficient bound at a 129-bit signed radix while staying inside i128.
        let mut left = vec![Integer::one(); 32];
        left[0] = Integer::from_double(i128::MIN);
        let right = vec![Integer::one(); 32];
        let actual_sparse = super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
            output_len, &left, &indices, &right, &indices,
        )
        .unwrap();
        let mut actual = vec![Integer::zero(); output_len];
        for (index, coefficient) in actual_sparse {
            actual[index as usize] = coefficient;
        }

        let mut expected = vec![Integer::zero(); output_len];
        for (left_coefficient, &left_index) in left.iter().zip(&indices) {
            for (right_coefficient, &right_index) in right.iter().zip(&indices) {
                expected[left_index as usize + right_index as usize] +=
                    left_coefficient * right_coefficient;
            }
        }
        assert_eq!(actual, expected);
        assert_eq!(actual[0], Integer::from_double(i128::MIN));
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn kronecker_decode_keeps_two_to_127_coefficients_canonical() {
        if gmp_mpfr_sys::gmp::NUMB_BITS != 64 || gmp_mpfr_sys::gmp::NAIL_BITS != 0 {
            return;
        }
        let indices = (0..32).collect::<Vec<u32>>();
        let scale = 1i128 << 123;
        let left = vec![Integer::from_double(scale); 32];
        let right = (0..32)
            .map(|index| Integer::from(if index < 16 { 1 } else { -1 }))
            .collect::<Vec<_>>();

        let actual_sparse = super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
            63, &left, &indices, &right, &indices,
        )
        .unwrap();
        let mut actual = vec![Integer::zero(); 63];
        for (index, coefficient) in actual_sparse {
            actual[index as usize] = coefficient;
        }

        let mut expected = vec![Integer::zero(); 63];
        for (left_coefficient, &left_index) in left.iter().zip(&indices) {
            for (right_coefficient, &right_index) in right.iter().zip(&indices) {
                expected[left_index as usize + right_index as usize] +=
                    left_coefficient * right_coefficient;
            }
        }
        assert_eq!(actual, expected);

        let positive_boundary = Integer::from(MultiPrecisionInteger::from(1u32) << 127u32);
        assert_eq!(actual[15], positive_boundary);
        assert!(matches!(&actual[15], Integer::Large(_)));
        assert_eq!(actual[47], Integer::from_double(i128::MIN));
        assert!(matches!(&actual[47], Integer::Double(_)));
        assert_eq!(actual[31], Integer::zero());
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn contiguous_kronecker_limb_pipeline_matches_direct_convolution() {
        if gmp_mpfr_sys::gmp::NUMB_BITS != 64 || gmp_mpfr_sys::gmp::NAIL_BITS != 0 {
            return;
        }
        let left_indices = (0..31).collect::<Vec<u32>>();
        let right_indices = (0..37).collect::<Vec<u32>>();
        let output_len = left_indices.len() + right_indices.len() - 1;

        for coefficient_bits in [0u32, 32, 64, 96, 128, 160, 192, 224] {
            let scale = Integer::one() << coefficient_bits;
            let left = (0..left_indices.len())
                .map(|index| {
                    let value = &scale + Integer::from(2 * index + 1);
                    if index % 3 == 0 { -value } else { value }
                })
                .collect::<Vec<_>>();
            let right = (0..right_indices.len())
                .map(|index| {
                    let value = &scale + Integer::from(3 * index + 2);
                    if index % 4 == 1 { -value } else { value }
                })
                .collect::<Vec<_>>();

            let actual_sparse = super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
                output_len,
                &left,
                &left_indices,
                &right,
                &right_indices,
            )
            .unwrap();
            let mut actual = vec![Integer::zero(); output_len];
            for (index, coefficient) in actual_sparse {
                actual[index as usize] = coefficient;
            }

            let mut expected = vec![Integer::zero(); output_len];
            for (left_coefficient, &left_index) in left.iter().zip(&left_indices) {
                for (right_coefficient, &right_index) in right.iter().zip(&right_indices) {
                    expected[left_index as usize + right_index as usize] +=
                        left_coefficient * right_coefficient;
                }
            }
            assert_eq!(actual, expected, "failed at {coefficient_bits} input bits");
        }
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn contiguous_kronecker_selector_rejects_sparse_or_shifted_support() {
        let scale = Integer::from(1) << 180u32;
        let coefficients = (0..32)
            .map(|index| &scale + Integer::from(index + 1))
            .collect::<Vec<_>>();

        let shifted_indices = (1000..1032).collect::<Vec<u32>>();
        assert!(
            super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
                2063,
                &coefficients,
                &shifted_indices,
                &coefficients,
                &shifted_indices,
            )
            .is_none()
        );

        let sparse_indices = (0..32).map(|index| 2 * index).collect::<Vec<u32>>();
        assert!(
            super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
                125,
                &coefficients,
                &sparse_indices,
                &coefficients,
                &sparse_indices,
            )
            .is_none()
        );
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn dense_kronecker_polynomial_multiplication() {
        let scale = Integer::from(1) << 180u32;
        let left = (0..300)
            .map(|i| {
                if i % 3 == 2 {
                    -(&scale + Integer::from(i + 1))
                } else {
                    &scale + Integer::from(i + 1)
                }
            })
            .collect::<Vec<_>>();
        let right = (0..300)
            .map(|i| {
                if i % 4 == 3 {
                    -(&scale + Integer::from(2 * i + 1))
                } else {
                    &scale + Integer::from(2 * i + 1)
                }
            })
            .collect::<Vec<_>>();
        let indices = (0..300).map(|i| i + i / 100).collect::<Vec<u32>>();
        let output_len = 2 * *indices.last().unwrap() as usize + 1;
        let actual_sparse = super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
            output_len, &left, &indices, &right, &indices,
        )
        .unwrap();
        let mut actual = vec![Integer::zero(); output_len];
        for (index, coefficient) in actual_sparse {
            actual[index as usize] = coefficient;
        }

        let mut expected = vec![Integer::zero(); output_len];
        for (i, left) in left.iter().enumerate() {
            for (j, right) in right.iter().enumerate() {
                expected[indices[i] as usize + indices[j] as usize] += left * right;
            }
        }
        assert_eq!(actual, expected);

        let left = left.iter().map(Integer::abs).collect::<Vec<_>>();
        let right = right.iter().map(Integer::abs).collect::<Vec<_>>();
        let actual_sparse = super::polynomial_kernels::DenseIntegerMul::try_kronecker_for_test(
            output_len, &left, &indices, &right, &indices,
        )
        .unwrap();
        let mut actual = vec![Integer::zero(); output_len];
        for (index, coefficient) in actual_sparse {
            actual[index as usize] = coefficient;
        }

        let mut expected = vec![Integer::zero(); output_len];
        for (i, left) in left.iter().enumerate() {
            for (j, right) in right.iter().enumerate() {
                expected[indices[i] as usize + indices[j] as usize] += left * right;
            }
        }
        assert_eq!(actual, expected);
    }

    #[cfg(feature = "integer-gmp")]
    #[test]
    fn dense_large_array_polynomial_multiplication() {
        let scale = Integer::from(1) << 180u32;
        let left = (0..8)
            .map(|i| &scale + Integer::from(i + 1))
            .collect::<Vec<_>>();
        let right = (0..8)
            .map(|i| {
                if i % 2 == 0 {
                    -(&scale + Integer::from(i + 3))
                } else {
                    &scale + Integer::from(i + 3)
                }
            })
            .collect::<Vec<_>>();
        let indices = (0..8).collect::<Vec<u32>>();
        let actual_sparse = IntegerRing
            .kernels()
            .polynomial()
            .unwrap()
            .try_dense_mul(DensePolynomialMulRequest {
                output_len: 15,
                left_coefficients: &left,
                left_indices: &indices,
                right_coefficients: &right,
                right_indices: &indices,
            })
            .unwrap();
        let mut actual = vec![Integer::zero(); 15];
        for (index, coefficient) in actual_sparse {
            actual[index as usize] = coefficient;
        }

        let mut expected = vec![Integer::zero(); 15];
        for (i, left) in left.iter().enumerate() {
            for (j, right) in right.iter().enumerate() {
                expected[i + j] += left * right;
            }
        }
        assert_eq!(actual, expected);
    }

    #[test]
    fn double_integer_roundtrip() {
        for value in [
            i128::MIN,
            i64::MIN as i128 - 1,
            i64::MIN as i128,
            -1,
            0,
            1,
            i64::MAX as i128,
            i64::MAX as i128 + 1,
            i128::MAX,
        ] {
            assert_eq!(DoubleInteger::from(value).get(), value);
        }
    }

    #[cfg(target_pointer_width = "64")]
    #[test]
    fn integer_layout() {
        use crate::domains::{
            finite_field::FiniteFieldElement, float::Complex, rational::Rational,
        };

        assert_eq!(size_of::<DoubleInteger>(), 16);
        assert_eq!(align_of::<DoubleInteger>(), 8);
        #[cfg(feature = "integer-gmp")]
        {
            assert_eq!(size_of::<Integer>(), 24);
            assert_eq!(align_of::<Integer>(), 8);
            assert_eq!(size_of::<Rational>(), 48);
            assert_eq!(align_of::<Rational>(), 8);
            assert_eq!(size_of::<FiniteFieldElement<Integer>>(), 24);
            assert_eq!(size_of::<Complex<Integer>>(), 48);
        }
        // Malachite's larger inline integer storage keeps this enum at 32 bytes.
        #[cfg(feature = "integer-malachite")]
        {
            assert_eq!(size_of::<Integer>(), 32);
            assert_eq!(align_of::<Integer>(), 8);
            assert_eq!(size_of::<Rational>(), 64);
            assert_eq!(align_of::<Rational>(), 8);
            assert_eq!(size_of::<FiniteFieldElement<Integer>>(), 32);
            assert_eq!(size_of::<Complex<Integer>>(), 64);
        }
    }

    #[test]
    fn double_integer_arithmetic_boundaries() {
        let max = Integer::from(i128::MAX);
        let min = Integer::from(i128::MIN);

        assert_eq!(&max - 1, Integer::from(i128::MAX - 1));
        assert_eq!(&min + 1, Integer::from(i128::MIN + 1));
        let beyond_i128 = Integer::from_str("170141183460469231731687303715884105728").unwrap();
        assert_eq!(&max + 1, beyond_i128);
        assert_eq!(-&min, beyond_i128);

        let a = Integer::from(i64::MAX as i128 + 1);
        let b = Integer::from(i64::MIN as i128 - 1);
        assert_eq!(&a + &b, Integer::from(-1));
        assert_eq!(&a * 3, Integer::from((i64::MAX as i128 + 1) * 3));
        assert_eq!(&b / 3, Integer::from((i64::MIN as i128 - 1) / 3));
        assert_eq!(&b % 3, Integer::from((i64::MIN as i128 - 1).rem_euclid(3)));
    }

    #[test]
    fn owned_large_remainder_by_borrowed_large_divisor() {
        let modulus: Integer = (Integer::one() << 200u32) + 123;
        let numerator: Integer = &modulus * 7 + 45;
        let negative_numerator = -&numerator;
        let negative_modulus = -&modulus;
        let negative_remainder = &modulus - 45;

        for divisor in [&modulus, &negative_modulus] {
            assert_eq!(numerator.clone() % divisor, Integer::from(45));
            assert_eq!(negative_numerator.clone() % divisor, negative_remainder);
            assert_eq!(numerator.clone() % divisor, &numerator % divisor);
            assert_eq!(
                negative_numerator.clone() % divisor,
                &negative_numerator % divisor
            );
        }

        assert_eq!(numerator.symmetric_mod(&modulus), Integer::from(45));
        assert_eq!(
            negative_numerator.symmetric_mod(&modulus),
            Integer::from(-45)
        );
    }

    #[test]
    fn binary_ops() {
        let a = Integer::from(5);
        let b: Integer = 7.into();

        assert!(a >= 5);
        assert!(5 <= a);
        assert!(a >= -891273892173892178922i128);

        let c = 2u32;

        assert_eq!(c + b.clone(), 9);
        assert_eq!(c + &b, 9);
        assert_eq!(c * b.clone(), 14);
        assert_eq!(c * &b, 14);
        assert_eq!(b.clone() + c, 9);
        assert_eq!(&b + c, 9);
        assert_eq!(b.clone() * c, 14);
        assert_eq!(&b * c, 14);
        assert_eq!(b.clone() / c, 3);
        assert_eq!(&b / c, 3);
        assert_eq!(&b % c, 1);
        assert_eq!(b.clone() % c, 1);

        macro_rules! try_variants {
            ($a: expr, $b: expr, $res: expr, $op: tt) => {
                assert_eq!($a.clone().$op(&$b), $res);
                assert_eq!($a.clone().$op($b.clone()), $res);
                assert_eq!((&$a).$op($b.clone()), $res);
                assert_eq!((&$a).$op(&$b), $res);
            };
        }

        try_variants!(a, b, 12, add);
        try_variants!(a, b, -2, sub);
        try_variants!(a, b, 35, mul);
        try_variants!(a, b, 0, div);
        try_variants!(a, b, 5, rem);

        let a = Integer::from(5123123132i64).pow(5);
        let b: Integer = Integer::from(-312223132i64).pow(5);

        try_variants!(
            a,
            b,
            Integer::from_str("3529178341193418202448766865967598093745792000000").unwrap(),
            add
        );
        try_variants!(
            a,
            b,
            Integer::from_str("3529184275300451286008027827753913822719081764864").unwrap(),
            sub
        );
        try_variants!(
            a,
            b,
            Integer::from_str(
                "-10471269811147586074167526453409671971439869211545667023340431153576356451994427981246234624"
            )
            .unwrap(),
            mul
        );
        try_variants!(a, b, -1189456, div);
        try_variants!(
            a,
            b,
            Integer::from_str("1700675215712075116094879895131557158845440").unwrap(),
            rem
        );
    }

    #[test]
    fn modular_inverse_accepts_negative_representatives() {
        let modulus = Integer::from(3);
        for value in [Integer::from(-1), Integer::from(-4)] {
            let inverse = value.mod_inverse(&modulus);
            assert_eq!(inverse, Integer::from(2));
            assert_eq!((value * inverse) % &modulus, Integer::one());
        }

        let modulus = (Integer::one() << 130u32) + Integer::from(5);
        let value = -(&modulus * Integer::from(7)) - Integer::from(2);
        let inverse = value.mod_inverse(&modulus);
        assert_eq!((value * inverse) % &modulus, Integer::one());
    }

    #[test]
    fn factor() {
        let mut start = Integer::from_str("180234718923712803489014621").unwrap();

        for _ in 0..40 {
            let factors = start.factor();

            let mut res = Integer::one();
            for (base, exp) in factors {
                res *= base.pow_i(exp);
            }

            assert_eq!(res, start);
            start += 1;
        }
    }

    #[test]
    fn factor_machine_sized_composites() {
        assert_eq!(
            Integer::from(166_659_413).factor(),
            vec![
                (Integer::from(547), Integer::from(2)),
                (Integer::from(557), Integer::from(1)),
            ]
        );

        let p = Integer::from(4_294_967_291_u64);
        let q = Integer::from(4_294_967_279_u64);
        assert!(p.is_prime(24));
        assert!(q.is_prime(24));

        let semiprime = &p * &q;
        assert!(semiprime.to_u64().is_some());
        assert_eq!(
            semiprime.factor(),
            vec![(q, Integer::from(1)), (p, Integer::from(1))]
        );

        assert_eq!(
            Integer::from_str("226136264309038487395159182893727571875")
                .unwrap()
                .factor(),
            vec![
                (Integer::from(3), Integer::from(1)),
                (Integer::from(5), Integer::from(5)),
                (Integer::from(5101), Integer::from(1)),
                (
                    Integer::from_str("4728720158066543551359271941841").unwrap(),
                    Integer::from(1),
                ),
            ]
        );
    }

    #[test]
    fn ecm_factor() {
        let n = Integer::from_str("114479981755147433175506682142130410682442983").unwrap();
        let factor = n.ecm_factor(50, 10_000, 1_000_000).unwrap();
        assert!(factor > 1 && factor < n);
        assert_eq!(n % factor, Integer::zero());
    }

    #[test]
    fn integer_roots() {
        assert_eq!(Integer::from(0).root(7), 0);
        assert_eq!(Integer::from(2).root(2), 1);
        assert_eq!(Integer::from(81).root(4), 3);

        let base = Integer::from(123456789i64);
        let exact = base.pow(5);
        assert_eq!(exact.root(5), base);
    }

    #[test]
    fn integer_shifts() {
        assert_eq!(Integer::from(3) << 4u32, Integer::from(48));
        assert_eq!(&Integer::from(-9) >> 1usize, Integer::from(-5));

        let promoted = Integer::from(1) << 100u32;
        assert_eq!(promoted, Integer::from(1u128 << 100));

        let large = Integer::from(1) << 200u32;
        assert_eq!(&large >> 200u32, Integer::one());

        let mut assigned = Integer::from(7);
        assigned <<= 130u32;
        assigned >>= 130u32;
        assert_eq!(assigned, Integer::from(7));
    }

    #[test]
    fn integer_left_shifts_preserve_value() {
        let values = [
            Integer::from(0),
            Integer::from(1),
            Integer::from(-1),
            Integer::from(3),
            Integer::from(-3),
            Integer::from(i64::MAX),
            Integer::from(i64::MIN),
            Integer::from(i64::MAX as i128 + 1),
            Integer::from(i64::MIN as i128 - 1),
            Integer::from(i128::MAX),
            Integer::from(i128::MIN),
            Integer::from(MultiPrecisionInteger::from(1) << 200usize),
            Integer::from(-(MultiPrecisionInteger::from(1) << 200usize)),
        ];
        for value in values {
            for shift in [
                0usize, 1, 2, 31, 62, 63, 64, 65, 100, 126, 127, 128, 129, 255,
            ] {
                let expected = Integer::from(value.clone().to_multi_prec() << shift);
                assert_eq!(&value << shift, expected, "borrowed {value} << {shift}");
                assert_eq!(value.clone() << shift, expected, "owned {value} << {shift}");
                let mut assigned = value.clone();
                assigned <<= shift;
                assert_eq!(assigned, expected, "assigned {value} << {shift}");
            }
        }
    }

    #[test]
    fn integer_bitand() {
        assert_eq!(
            Integer::from(0b1101) & Integer::from(0b1011),
            Integer::from(0b1001)
        );
        assert_eq!(
            &Integer::from(-1) & &Integer::from(0xff),
            Integer::from(0xff)
        );

        let large = (Integer::one() << 200u32) + Integer::from(0b1011);
        let mask = (Integer::one() << 128u32) - Integer::one();
        assert_eq!(&large & &mask, Integer::from(0b1011));

        let mut assigned = large;
        assigned &= mask;
        assert_eq!(assigned, Integer::from(0b1011));
    }

    #[test]
    fn pslq_small() {
        let result = Integer::solve_integer_relation(
            &[F64::from(-32.0177), F64::from(3.1416), F64::from(2.7183)],
            F64::from(1e-4),
            1,
            Some(Integer::from(100000u64)),
            None,
        )
        .unwrap();

        assert_eq!(result, &[1, 5, 6]);
    }

    #[cfg(feature = "float-mpfr")]
    #[test]
    fn pslq_medium() {
        let f = Float::new(300);
        let pi = f.pi();
        let e = f.e();
        let log2 = Float::with_val(300, 2).log();
        let r = pi.clone() * 178236781263123i64
            + e.clone() * -712365671253675i64
            + log2.clone() * 712637812361762786i64;

        let result = Integer::solve_integer_relation(
            &[pi, e, log2, -r],
            Float::with_val(300, 1e-90),
            400,
            Some(Integer::from(1000000000000000000000000000000u128)),
            None,
        )
        .unwrap();

        assert_eq!(result.iter().last().unwrap().abs(), 1);
    }

    #[test]
    fn extended_gcds() {
        let (g, s, t) = extended_gcd(123, 456);
        assert_eq!(g, 3);
        assert_eq!(s, -63);
        assert_eq!(t, 17);

        let (g2, s2, t2) = extended_gcd(48, 18);
        assert_eq!(g2, 6);
        assert_eq!(s2, -1);
        assert_eq!(t2, 3);

        let (g3, s3, t3) = extended_gcd_i128(101, 147);
        assert_eq!(g3, 1);
        assert_eq!(s3, -16);
        assert_eq!(t3, 11);
    }

    #[cfg(feature = "bincode")]
    #[test]
    fn bincode_export() {
        let a = Integer::factorial(150);
        let encoded = bincode::encode_to_vec(&a, bincode::config::standard()).unwrap();
        let b: Integer = bincode::decode_from_slice(&encoded, bincode::config::standard())
            .unwrap()
            .0;
        assert_eq!(a, b);
    }
}
