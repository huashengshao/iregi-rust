use symbolica::prelude::*;

fn main() {
    let expr: Atom = parse!("f(z)*f(f(x),z)*f(y)");

    println!("> Tree walk of {expr}:");

    for (loc, view) in AtomTreeIterator::new(
        expr.as_view(),
        MatchSettings::new()
            .min_level(1)
            .max_level(2)
            .level_is_tree_depth(false),
    ) {
        println!("\tAtom at location {loc:?}: {view}");
    }
}
