use brotli::CompressorWriter;
use symbolica::prelude::*;

fn main() {
    let input = parse!("x+ f(x) + 2*f(y) + 7*f(z)");
    let pattern = parse!("f(x_)").to_pattern();
    let rhs = parse!("f(x) + x").to_pattern();

    let mut stream = TermStreamer::<CompressorWriter<_>>::new(
        TermStreamerConfig::new()
            .cores(4)
            .path(".")
            .max_mem_bytes(40),
    );
    stream.push(input);

    // map every term in the expression
    stream = stream.map(|x| x.replace(&pattern).with(&rhs).expand());

    let res = stream.to_expression();
    println!("\t+ {res}");
}
