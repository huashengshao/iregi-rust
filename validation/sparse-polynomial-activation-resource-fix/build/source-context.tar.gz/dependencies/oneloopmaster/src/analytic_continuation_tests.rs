//! Directional Taylor controls built by Symbolica's own differentiation API.
//! Independent derivatives of log(z) and sqrt(z) specify each analytic germ;
//! the helper under test supplies only the continued primal branch.
use super::*;
use symbolica::{
    domains::{dual::HyperDual, float::Complex, rational::Rational},
    evaluate::Dualizer,
};

const SHAPE: [[usize; 2]; 7] = [[0, 0], [1, 0], [0, 1], [2, 0], [1, 1], [3, 0], [2, 1]];

fn close(actual: Complex<f64>, expected: Complex<f64>) {
    assert!(
        (actual.re - expected.re).abs() < 2e-12 * (1. + expected.re.abs())
            && (actual.im - expected.im).abs() < 2e-12 * (1. + expected.im.abs()),
        "{actual} != {expected}"
    );
}

pub(crate) fn check_complex_axis_germs(helper: fn(&Atom) -> Atom, logarithm: bool, lower: bool) {
    let z = symbolica::symbol!("continuation_test_z").to_atom();
    let t = symbolica::symbol!("continuation_test_t");
    let u = symbolica::symbol!("continuation_test_u");
    let mut map = FunctionMap::new();
    sheet_exact::register(&mut map);
    let exact = helper(&z)
        .evaluator(std::slice::from_ref(&z))
        .function_map(map.into())
        .cores(1)
        .build()
        .unwrap();
    let shape = SHAPE.map(Vec::from).to_vec();
    let mut actual = exact
        .clone()
        .vectorize(&Dualizer::new(
            HyperDual::<Complex<Rational>>::new(shape),
            vec![],
        ))
        .unwrap()
        .map_coeff(&|c| Complex::new(c.re.to_f64(), c.im.to_f64()));
    let mut scalar = exact.map_coeff(&|c| Complex::new(c.re.to_f64(), c.im.to_f64()));
    for primal in [4, -4] {
        // Complex first, second, third and mixed input coefficients. The first
        // seed is purely imaginary and specifically detects real-axis clipping.
        let coefficients = [
            (primal, 0),
            (0, 1),
            (2, -1),
            (0, 3),
            (-2, 1),
            (1, 1),
            (-1, -2),
        ];
        let polynomial =
            coefficients
                .iter()
                .zip(SHAPE)
                .fold(Atom::num(0), |sum, (&(re, im), power)| {
                    sum + (Atom::num(re) + sheet_exact::i() * im)
                        * t.to_atom().pow(power[0] as i64)
                        * u.to_atom().pow(power[1] as i64)
                });
        let base = if logarithm {
            polynomial.log()
        } else {
            polynomial.sqrt()
        };
        let expected: Vec<_> = SHAPE
            .iter()
            .map(|power| {
                let mut coefficient = base.clone();
                for _ in 0..power[0] {
                    coefficient = coefficient.derivative(t);
                }
                for _ in 0..power[1] {
                    coefficient = coefficient.derivative(u);
                }
                // Symbolica Dual stores Taylor coefficients, including factorials.
                let factorial =
                    (1..=power[0]).product::<usize>() * (1..=power[1]).product::<usize>();
                coefficient / Atom::num(factorial)
            })
            .collect();
        let mut expected = Atom::evaluator_multiple(&expected, &[t.to_atom(), u.to_atom()])
            .cores(1)
            .build()
            .unwrap()
            .map_coeff(&|c| Complex::new(c.re.to_f64(), c.im.to_f64()));
        let zero = Complex::new(0., 0.);
        let mut oracle = [zero; SHAPE.len()];
        expected.evaluate(&[zero, zero], &mut oracle);
        if primal < 0 && lower {
            if logarithm {
                oracle[0].im = -std::f64::consts::PI;
            } else {
                for value in &mut oracle {
                    *value = -*value;
                }
            }
        }
        let input = coefficients.map(|(re, im)| Complex::new(f64::from(re), f64::from(im)));
        let mut output = [zero; SHAPE.len()];
        actual.evaluate(&input, &mut output);
        for (&value, &expected) in output.iter().zip(&oracle) {
            close(value, expected);
        }
        let mut scalar_output = [zero];
        scalar.evaluate(&input[..1], &mut scalar_output);
        close(scalar_output[0], oracle[0]);
    }
    // Away from the axis all four helpers retain the principal branch. These
    // 3-4-5 triangles provide elementary values independent of the helper graph.
    for re in [3_f64, -3.] {
        for im in [4_f64, -4.] {
            let expected = if logarithm {
                Complex::new(5_f64.ln(), im.atan2(re))
            } else {
                Complex::new(
                    if re > 0. { 2. } else { 1. },
                    im.signum() * if re > 0. { 1. } else { 2. },
                )
            };
            let mut output = [Complex::new(0., 0.)];
            scalar.evaluate(&[Complex::new(re, im)], &mut output);
            close(output[0], expected);
        }
    }
    if !logarithm {
        let zero = Complex::new(0., 0.);
        let mut output = [Complex::new(77., 77.)];
        scalar.evaluate(&[zero], &mut output);
        close(output[0], zero);
    }
}

#[test]
fn lower_log_complex_axis_derivatives() {
    check_complex_axis_germs(physical_log, true, true);
}

#[test]
fn upper_log_complex_axis_derivatives() {
    check_complex_axis_germs(upper_log, true, false);
}

#[test]
fn lower_sqrt_complex_axis_derivatives() {
    check_complex_axis_germs(physical_sqrt, false, true);
}
