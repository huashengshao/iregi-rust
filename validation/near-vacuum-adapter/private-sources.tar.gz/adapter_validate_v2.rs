#[path = "source/near_vacuum.rs"]
mod candidate;

use candidate::{Exact, NearVacuumPlan, pow2_minus, zero};
use iregi_masters_certified::{
    MasterEvaluator, NativeFloat, ScalarIntegral,
    certified::{AccuracyMasterEvaluator, CertificatePolicy, Formula, MasterAccuracyContext},
};
use serde_json::{Value, json};
use std::error::Error;
use symbolica::{
    domains::{
        dual::HyperDual,
        float::{Complex, DoubleFloat, Float},
        rational::Rational,
    },
    evaluate::EvaluationDomain,
};

fn fixture(eta: Rational, mass: Exact, c: usize) -> Vec<Exact> {
    let mut result = Vec::new();
    for coefficient in [0, -2, -2, 0, 0, -2] {
        let mut values = vec![zero(); c];
        values[0].re = &eta * &Rational::from(coefficient);
        values[2].re = Rational::from(coefficient);
        result.extend(values);
    }
    for _ in 0..4 {
        let mut values = vec![zero(); c];
        values[0] = mass.clone();
        values[1].re = Rational::from(1);
        result.extend(values);
    }
    let mut scale = vec![zero(); c];
    scale[0].re = Rational::from(1);
    result.extend(scale);
    result
}

fn run<T: NativeFloat>(kind: &str, prototype: T, requested: u32) -> Result<Value, Box<dyn Error>>
where
    Complex<T>: EvaluationDomain,
{
    let shape = vec![vec![0, 0], vec![1, 0], vec![0, 1], vec![1, 1], vec![2, 0], vec![0, 2]];
    let c = shape.len();
    let width = 11 * c;
    let mass = Complex::new(Rational::from(2), Rational::from(-1));
    let tiny = fixture(pow2_minus(64), mass.clone(), c);
    let mut rows = vec![
        tiny.clone(),
        fixture(pow2_minus(12), mass.clone(), c),
        fixture(Rational::from(0), mass.clone(), c),
        fixture(pow2_minus(64), Complex::new(Rational::from(2), Rational::from(1)), c),
        tiny.clone(),
        tiny.clone(),
        fixture(pow2_minus(64), Complex::new(Rational::from(3), Rational::from((-1, 2))), c),
    ];
    rows[4][10 * c].re = Rational::from(0);
    for arguments in rows[5].chunks_exact_mut(c) {
        arguments[1..].fill(zero());
    }
    rows[5][10 * c + 1].re = Rational::from(1);
    let map = |rows: &[Vec<Exact>]| -> Vec<Complex<T>> {
        rows.iter().flatten().map(|x| Complex::new(prototype.from_rational(&x.re), prototype.from_rational(&x.im))).collect()
    };
    let input = map(&rows);
    for (exact, value) in rows.iter().flatten().zip(&input) {
        assert_eq!(Some(&exact.re), value.re.exact_rational().as_ref());
        assert_eq!(Some(&exact.im), value.im.exact_rational().as_ref());
    }
    let ordinary = MasterEvaluator::new_dual(ScalarIntegral::D0, prototype.clone(), HyperDual::<Rational>::new(shape.clone()))?;
    let mut adapter = AccuracyMasterEvaluator::new(ordinary.clone());
    let context = MasterAccuracyContext::binary(requested, c);
    assert_eq!(adapter.evaluate_batch_with_accuracy(&[], 0, &context, CertificatePolicy::RequireFiniteCertificate)?.row_count(), 0);
    let strict = adapter.evaluate_batch_with_accuracy(&input, rows.len(), &context, CertificatePolicy::RequireFiniteCertificate)?;
    assert_eq!(strict.ordinary_rows, 0);
    let mut selected = std::collections::BTreeMap::new();
    for order in [2, 4] {
        let mut direct = NearVacuumPlan::new(order, shape.clone())?.instantiate(prototype.clone());
        let direct_input: Vec<_> = input.chunks_exact(width).flat_map(|point| point[..10*c].iter().cloned()).collect();
        selected.insert(order, direct.evaluate_batch(&direct_input, rows.len(), &candidate::AccuracyContext::binary(requested, c))?);
    }
    let mut records = Vec::new();
    let mut checked = 0;
    for lane in 0..rows.len() {
        let diagnostic = &strict.diagnostics()[lane];
        let value = match strict.lane(lane) {
            Ok(value) => {
                let Formula::NearVacuum{order} = diagnostic.formula else {panic!("required certificate used ordinary output")};
                let reference = &selected[&order][lane];
                let certificate = diagnostic.finite.as_ref().unwrap();
                assert_eq!(value.finite, reference.values.as_ref().unwrap());
                assert_eq!(certificate.len(), c);
                for (actual, expected) in certificate.iter().zip(&reference.bounds) {
                    assert_eq!(actual.real_lower, expected.real_lower);
                    assert_eq!(actual.real_upper, expected.real_upper);
                    assert_eq!(actual.imaginary_lower, expected.imaginary_lower);
                    assert_eq!(actual.imaginary_upper, expected.imaginary_upper);
                    assert_eq!(actual.maximum_error_squared, expected.maximum_error_squared);
                    assert_eq!(actual.allowed_error_squared, expected.allowed_error_squared);
                    assert!(actual.maximum_error_squared <= actual.allowed_error_squared);
                    checked += 1;
                }
                assert!(value.uv.iter().chain(value.ir).chain(value.ir2).chain(value.total_single).all(|x| x.re.is_zero() && x.im.is_zero()));
                if lane == 5 {
                    assert!(value.finite[1..].iter().all(|x| x.re.is_zero() && x.im.is_zero()));
                }
                Some(value.finite.iter().map(|x| json!([x.re.exact_rational().unwrap().to_string(),x.im.exact_rational().unwrap().to_string()])).collect::<Vec<_>>())
            }
            Err(_) => {assert!(diagnostic.finite.is_none()); None}
        };
        records.push(json!({"lane":lane,"error":strict.errors()[lane].as_ref().map(ToString::to_string),"formula":format!("{:?}",diagnostic.formula),"attempts":diagnostic.attempts.iter().map(|attempt|json!({"order":attempt.order,"status":format!("{:?}",attempt.status),"rho":attempt.rho.as_ref().map(ToString::to_string)})).collect::<Vec<_>>(),"values":value}));
    }
    for lane in [0, 2, 5, 6] { assert!(strict.lane(lane).is_ok()); }
    for lane in [3, 4] { assert!(strict.lane(lane).is_err()); }
    let ordinary_allowed = adapter.evaluate_batch_with_accuracy(&input, rows.len(), &context, CertificatePolicy::AllowOrdinaryUncertified)?;
    let mut legacy = ordinary;
    let ordinary_reference = legacy.evaluate_batch(&input[width..2*width],1)?;
    if strict.lane(1).is_err() {
        assert_eq!(ordinary_allowed.errors()[1], ordinary_reference.errors()[0]);
        match ordinary_allowed.lane(1) {
            Ok(value) => {
                assert_eq!(ordinary_allowed.diagnostics()[1].formula, Formula::OrdinaryUncertified);
                assert!(ordinary_allowed.diagnostics()[1].finite.is_none());
                assert_eq!(value.finite, ordinary_reference.lane(0).unwrap().finite);
            }
            Err(_) => assert!(ordinary_allowed.diagnostics()[1].finite.is_none()),
        }
    }
    let mut reversed_rows = rows.clone(); reversed_rows.reverse();
    let reverse = adapter.evaluate_batch_with_accuracy(&map(&reversed_rows), rows.len(), &context, CertificatePolicy::RequireFiniteCertificate)?;
    for lane in 0..rows.len() {
        let other = rows.len()-1-lane;
        assert_eq!(strict.errors()[lane], reverse.errors()[other]);
        if let Ok(value) = strict.lane(lane) {assert_eq!(value.finite, reverse.lane(other).unwrap().finite);}
    }
    // A safe primal row outside the series radius verifies that an explicitly
    // permitted ordinary result remains labeled uncertified. The seeded
    // overlap above may retain its existing derivative-domain rejection.
    let primal_exact=fixture(Rational::from(2),mass, c).chunks_exact(c).map(|argument|argument[0].clone()).collect::<Vec<_>>();
    let primal_input=map(&[primal_exact]);
    let mut primal_ordinary=MasterEvaluator::new(ScalarIntegral::D0,prototype.clone())?;
    let ordinary_primal_reference=primal_ordinary.evaluate_batch(&primal_input,1)?;
    let mut primal_adapter=AccuracyMasterEvaluator::new(primal_ordinary);
    let primal_context=MasterAccuracyContext::binary(requested,1);
    let primal_required=primal_adapter.evaluate_batch_with_accuracy(&primal_input,1,&primal_context,CertificatePolicy::RequireFiniteCertificate)?;
    assert!(primal_required.lane(0).is_err());
    let primal_allowed=primal_adapter.evaluate_batch_with_accuracy(&primal_input,1,&primal_context,CertificatePolicy::AllowOrdinaryUncertified)?;
    assert_eq!(primal_allowed.diagnostics()[0].formula,Formula::OrdinaryUncertified);
    assert!(primal_allowed.diagnostics()[0].finite.is_none());
    assert_eq!(primal_allowed.lane(0).unwrap().finite,ordinary_primal_reference.lane(0).unwrap().finite);
    let impossible = MasterAccuracyContext::binary(prototype.get_precision()+100,c);
    let refused = adapter.evaluate_batch_with_accuracy(&input, rows.len(), &impossible, CertificatePolicy::RequireFiniteCertificate)?;
    assert!((0..rows.len()).all(|lane|refused.lane(lane).is_err()));
    assert!(refused.diagnostics().iter().all(|x|x.finite.is_none()));
    Ok(json!({"status":"isolated_adapter_checks_passed","numeric":kind,"working_bits":prototype.get_precision(),"requested_bits":requested,"primary_components_matching_qualified_candidate":checked,"shape":shape,"rows":records,"ordinary_rows":ordinary_allowed.ordinary_rows,"ordinary_overlap_error":ordinary_allowed.errors()[1].as_ref().map(ToString::to_string),"series_execution":strict.series_execution.iter().map(|(order,execution)|json!({"order":order,"input_rows":execution.input_rows,"active_rows":execution.active_rows,"numeric_batch_calls":execution.numeric_batch_calls,"enclosure_batch_calls":execution.enclosure_batch_calls,"tail_batch_calls":execution.tail_batch_calls})).collect::<Vec<_>>(),"safe_primal_ordinary_uncertified_success":true,"empty_reverse_scale_only_impossible_accuracy_checks":true,"scope":"Private adapter copy only; exact equality with independently qualified candidate certificates, unchanged physical guards, explicit uncertified ordinary fallback. No production or E6 certificate claim."}))
}

fn main() -> Result<(), Box<dyn Error>> {
    let mut args=std::env::args().skip(1);
    let kind=args.next().ok_or("expected f64, dd, float128 or float256")?;
    let output=args.next().ok_or("expected output path")?;
    if args.next().is_some(){return Err("unexpected argument".into())}
    let data=match kind.as_str(){
        "f64"=>run(&kind,0f64,40)?,
        "dd"=>run(&kind,DoubleFloat::from(Rational::from(0)),80)?,
        "float128"=>run(&kind,Float::new(128),100)?,
        "float256"=>run(&kind,Float::new(256),128)?,
        _=>return Err("unknown numeric type".into()),
    };
    std::fs::write(output,serde_json::to_string_pretty(&data)?+"\n")?;
    Ok(())
}
