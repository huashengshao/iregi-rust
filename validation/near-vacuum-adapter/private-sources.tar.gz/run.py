import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path.cwd()
HERE=ROOT/'target/near-vacuum-adapter'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

kind=sys.argv[1]
assert kind in ['f64','dd','float128','float256']
paths=sorted((HERE/'source').glob('*.rs'))+[HERE/'adapter_validate.rs',HERE/'adapter_validate',HERE/'libiregi_masters_certified.rlib',HERE/'deps/liboneloop.rlib',ROOT/'target/d0-node-probe/deps/libsymbolica-5cca42ee48491872.rlib',ROOT/'target/d0-node-probe/deps/libserde_json-6ed7d47d62d32cd7.rlib',Path(__file__)]
before={str(p.relative_to(ROOT)):sha(p) for p in paths}
output=HERE/f'{kind}.json';log=HERE/f'{kind}.log';record=HERE/f'{kind}-run.json'
assert not output.exists() and not log.exists() and not record.exists()
command=['taskset','-c','4',str(HERE/'adapter_validate'),kind,str(output)]
started=time.monotonic();timeout=False
with log.open('w') as stream:
    process=subprocess.Popen(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    try: code=process.wait(timeout=60)
    except subprocess.TimeoutExpired:
        timeout=True;os.killpg(process.pid,signal.SIGKILL);code=process.wait()
elapsed=time.monotonic()-started
after={str(p.relative_to(ROOT)):sha(p) for p in paths}
data={'command':command,'timeout_seconds':60,'timed_out':timeout,'exit_code':code,'diagnostic_wall_seconds':elapsed,'sha256_before':before,'sha256_after':after,'inputs_unchanged':before==after,'output_sha256':sha(output) if output.exists() else None,'log_sha256':sha(log),'scope':'Private proposed master adapter, current copied master source, retained pre-default-stack Symbolica and rust-codegen oneloop archive; production unchanged. Diagnostic timing only.'}
record.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'run':str(record.relative_to(ROOT)),'exit_code':code,'timed_out':timeout,'wall_seconds':elapsed,'inputs_unchanged':before==after}))
