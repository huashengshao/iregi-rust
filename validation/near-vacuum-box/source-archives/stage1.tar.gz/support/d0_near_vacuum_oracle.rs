//! Independent exact parameter-series oracle for the equal-mass pinch-zero box.
//!
//! This optional validation module calls neither reduction nor scalar masters.
//! Symbolica constructs and integrates the parameter series, differentiates its
//! exact mass dependence, and supplies the Taylor factorial normalization. The
//! reference expands only in eta/M; a candidate that expands all deviations
//! around a frozen auxiliary mass therefore has a different truncation.

use serde_json::json;
use std::{collections::HashSet, sync::Arc};
use symbolica::{
    atom::{Atom, AtomCore, Symbol},
    domains::{
        atom::AtomField,
        float::Complex,
        integer::{Integer, Z},
        rational::{Q, Rational},
    },
    id::Replacement,
    poly::PolyVariable,
    tensors::matrix::Matrix,
};

/// Exact centers and absolute complex remainder bounds in the requested order.
pub struct NearVacuumOracle {
    pub centers: Vec<Complex<Rational>>,
    pub radii: Vec<Rational>,
    pub metadata: serde_json::Value,
}

// These are limits on this validation helper's symbolic preparation, not on the
// production reduction API. Reject before constructing any symbolic expression.
const MAX_SERIES_ORDER: usize = 8;
const MAX_TAYLOR_DEGREE: usize = 4;
const MAX_COMPONENTS: usize = 15;

fn exact_field() -> AtomField {
    AtomField {
        statistical_zero_test: false,
        cancel_check_on_division: false,
        custom_normalization: None,
    }
}

fn validate_shape(shape: &[Vec<usize>]) -> Result<(), String> {
    if shape.is_empty() || shape.len() > MAX_COMPONENTS {
        return Err(format!(
            "oracle shape must contain 1..={MAX_COMPONENTS} components"
        ));
    }
    if shape[0].as_slice() != [0, 0] {
        return Err("oracle shape must start with the two-coordinate primal [0,0]".into());
    }
    let mut seen = HashSet::with_capacity(shape.len());
    for component in shape {
        if component.len() != 2
            || component
                .iter()
                .try_fold(0usize, |sum, degree| sum.checked_add(*degree))
                .is_none_or(|degree| degree > MAX_TAYLOR_DEGREE)
        {
            return Err(format!(
                "oracle components need two coordinates and total degree <= {MAX_TAYLOR_DEGREE}"
            ));
        }
        if !seen.insert(component.as_slice()) {
            return Err("oracle shape contains a duplicate component".into());
        }
    }
    for component in shape {
        for axis in 0..2 {
            if component[axis] > 0 {
                let mut ancestor = component.clone();
                ancestor[axis] -= 1;
                if !seen.contains(ancestor.as_slice()) {
                    return Err(format!(
                        "oracle shape is not ancestor-closed: missing {ancestor:?}"
                    ));
                }
            }
        }
    }
    Ok(())
}

/// Differentiate with Symbolica, then apply its native Taylor normalization.
fn taylor_derivative(expression: &Atom, symbols: [Symbol; 2], alpha: &[usize]) -> Atom {
    let mut coefficient = expression.clone();
    for (symbol, degree) in symbols.into_iter().zip(alpha) {
        for _ in 0..*degree {
            coefficient = coefficient.derivative(symbol);
        }
        coefficient /= Atom::num(Integer::factorial(*degree as u32));
    }
    coefficient
}

/// Let Symbolica convert and evaluate both exact rational-polynomial parts.
fn evaluate_exact(
    expression: &Atom,
    variables: &Arc<Vec<PolyVariable>>,
    point: &[Complex<Rational>],
) -> Result<Complex<Rational>, String> {
    let rational = expression
        .try_to_rational_polynomial::<_, _, u16>(&Q, &Z, Some(variables.clone()))
        .map_err(|error| format!("exact rational-polynomial conversion: {error}"))?;
    if rational.numerator.get_vars_ref() != variables.as_slice()
        || rational.denominator.get_vars_ref() != variables.as_slice()
        || point.len() != variables.len()
    {
        return Err("unexpected variables in oracle rational expression".into());
    }
    let map = |value: &Integer| Complex::new(Rational::from(value), Rational::from(0));
    let numerator = rational.numerator.evaluate(map, point);
    let denominator = rational.denominator.evaluate(map, point);
    if denominator.re == Rational::from(0) && denominator.im == Rational::from(0) {
        return Err("zero exact denominator in oracle evaluation".into());
    }
    Ok(numerator / denominator)
}

/// Build a bounded exact oracle for p=eta*[0,-2,-2,0,0,-2], equal squared masses M.
///
/// Coordinates are `(t_mass,t_eta)`: all four squared masses are `M+t_mass`
/// and every occurrence of eta is `eta+t_eta`. Each output is the coefficient
/// of `t_mass^alpha[0] * t_eta^alpha[1]`, already divided by `alpha!`, in native
/// Symbolica Dual ordering. A typical shape is `[00,10,01,11,20,02]`.
///
/// The reference series retains orders 0 through `series_order` inclusive;
/// callers normally request 8. Every retained component has its own exact
/// remainder bound, even if its order exceeds the eta-series order. The
/// initial validation helper permits series order <=8 and Taylor degree <=4.
///
/// Domain: Re(M)>0, Im(M)<=0, eta real, and |eta|<L, where
/// L=max(|Re(M)|,|Im(M)|). These exact conditions imply the uniform convergence
/// used in the proof. No floating-point arithmetic or scalar-master evaluation
/// is used. Calling this function initializes Symbolica and needs its runtime.
pub fn build_oracle(
    mass: &Complex<Rational>,
    eta: &Rational,
    shape: &[Vec<usize>],
    series_order: usize,
) -> Result<NearVacuumOracle, String> {
    validate_shape(shape)?;
    if series_order > MAX_SERIES_ORDER {
        return Err(format!(
            "oracle series order exceeds validation limit {MAX_SERIES_ORDER}"
        ));
    }
    if mass.re <= Rational::from(0) || mass.im > Rational::from(0) {
        return Err("oracle requires Re(M)>0 and Im(M)<=0".into());
    }
    let lower_norm = mass.re.abs().max(mass.im.abs());
    let eta_abs = eta.abs();
    if eta_abs >= lower_norm {
        return Err("oracle requires |eta|<max(|Re(M)|,|Im(M)|)".into());
    }

    let z_symbol = symbolica::symbol!("iregi_d0_near_vacuum_oracle::z");
    let z = Atom::var(z_symbol);
    let x: Vec<_> = (0..4)
        .map(|i| Atom::var(symbolica::symbol!(format!("iregi_d0_near_vacuum_oracle::x{i}"))))
        .collect();
    let u_symbols: Vec<_> = (0..3)
        .map(|i| symbolica::symbol!(format!("iregi_d0_near_vacuum_oracle::u{i}")))
        .collect();
    let u: Vec<_> = u_symbols.iter().copied().map(Atom::var).collect();

    // Derive the Symanzik polynomial from the four unit routing vectors with
    // metric (+---). This is independent of the candidate's ten-argument box
    // expression and avoids importing its invariant-to-parameter mapping.
    let routing: Vec<[Atom; 4]> = (0..4)
        .map(|i| std::array::from_fn(|mu| Atom::num(i64::from(i == mu))))
        .collect();
    let metric = [1, -1, -1, -1];
    let mut p = Atom::num(0);
    for i in 0..4 {
        for j in i + 1..4 {
            let distance: Atom = (0..4)
                .map(|mu| Atom::num(metric[mu]) * (&routing[i][mu] - &routing[j][mu]).pow(2))
                .sum();
            p -= &x[i] * &x[j] * distance;
        }
    }
    let expected = Atom::num(2) * (&x[1] * &x[2] + &x[1] * &x[3] + &x[2] * &x[3]);
    if !(&p - expected).expand().is_zero() {
        return Err("routing-derived Symanzik polynomial failed its identity".into());
    }
    // P=(x1+x2+x3)^2-(x1^2+x2^2+x3^2), so 0<=P<=1 on the simplex.
    let spatial_sum: Atom = x[1..].iter().cloned().sum();
    let spatial_squares: Atom = x[1..].iter().map(|value| value.pow(2)).sum();
    if !(&p - spatial_sum.pow(2) + spatial_squares)
        .expand()
        .is_zero()
    {
        return Err("uniform parameter bound identity failed".into());
    }

    let mut remaining = Atom::num(1);
    let mut simplex = Vec::with_capacity(4);
    for coordinate in &u {
        simplex.push(&remaining * coordinate);
        remaining *= Atom::num(1) - coordinate;
    }
    simplex.push(remaining);
    let jacobian = Matrix::from_nested_vec(
        simplex[..3]
            .iter()
            .map(|coordinate| {
                u_symbols
                    .iter()
                    .map(|&symbol| coordinate.derivative(symbol))
                    .collect()
            })
            .collect(),
        exact_field(),
    )
    .map_err(|error| format!("oracle Jacobian matrix: {error:?}"))?
    .det()
    .map_err(|error| format!("oracle Jacobian determinant: {error:?}"))?;
    let expected_jacobian = (Atom::num(1) - &u[0]).pow(2) * (Atom::num(1) - &u[1]);
    if !(&jacobian - expected_jacobian).expand().is_zero() {
        return Err("stick-breaking Jacobian identity failed".into());
    }
    let substitutions: Vec<_> = x
        .iter()
        .zip(&simplex)
        .map(|(parameter, value)| Replacement::new(parameter.clone(), value.clone()))
        .collect();
    let p_cube = p.replace_multiple(substitutions.iter());
    let series = (Atom::num(1) / (Atom::num(1) + &z * p_cube).pow(2))
        .series(z_symbol, 0, series_order as u32)
        .map_err(|error| format!("oracle parameter series: {error}"))?
        .to_atom();
    let cube_variables = Arc::new(
        std::iter::once(z.clone())
            .chain(u)
            .map(PolyVariable::try_from)
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| format!("oracle integration variables: {error}"))?,
    );
    let mut integrated = (jacobian * series)
        .expand()
        .try_to_polynomial::<_, u16>(&Q, Some(cube_variables))
        .map_err(|error| format!("oracle parameter polynomial: {error}"))?;
    let expanded_parameter_terms = integrated.nterms();
    for variable in 1..4 {
        let antiderivative = integrated.integrate(variable);
        integrated = &antiderivative.replace(variable, &Rational::from(1))
            - &antiderivative.replace(variable, &Rational::from(0));
    }
    if !(1..4).all(|variable| integrated.degree(variable) == 0)
        || integrated.get_constant() != Rational::from((1, 6))
        || (series_order >= 1
            && integrated.coefficient(&[1, 0, 0, 0]) != Some(Rational::from((-1, 10))))
    {
        return Err("oracle integration failed volume/first-moment checks".into());
    }
    let integrated_expression = integrated.to_expression();

    let m_symbol = symbolica::symbol!("iregi_d0_near_vacuum_oracle::m");
    let eta_symbol = symbolica::symbol!("iregi_d0_near_vacuum_oracle::eta");
    let m = Atom::var(m_symbol);
    let eta_atom = Atom::var(eta_symbol);
    let symbols = [m_symbol, eta_symbol];
    let variables = Arc::new(vec![PolyVariable::from(m_symbol), PolyVariable::from(eta_symbol)]);
    let approximation = integrated_expression.replace_multiple(
        [Replacement::new(z.clone(), &eta_atom / &m)].iter(),
    ) / m.pow(2);

    // H_N(z)=sum_{k>N}(k+1)z^k. The positive form makes the derivative-tail
    // proof transparent, including N smaller than a requested eta degree.
    let generating = Atom::num(1) / (Atom::num(1) - &z).pow(2);
    let tail_closed = z.pow((series_order + 1) as i64)
        * (Atom::num(series_order + 1) / (Atom::num(1) - &z)
            + Atom::num(1) / (Atom::num(1) - &z).pow(2));
    let tail_from_series = &generating
        - generating
            .series(z_symbol, 0, series_order as u32)
            .map_err(|error| format!("oracle remainder series: {error}"))?
            .to_atom();
    if !(tail_from_series - &tail_closed).together().is_zero() {
        return Err("positive generating-function tail identity failed".into());
    }
    // R(m,e)=H_N(e/m)/(6m^2). The bound generator is R(L-t_mass,|eta|+t_eta).
    // Its components equal (-1)^a/(a!b!) d_m^a d_e^b R at (L,|eta|).
    // Each omitted term is bounded because |M|>=L and 0<=P<=1; integration
    // contributes simplex volume 1/6. All products and derivatives remain in
    // Symbolica; there is no independently implemented polynomial/jet engine.
    let remainder = tail_closed
        .replace_multiple([Replacement::new(z, &eta_atom / &m)].iter())
        / (Atom::num(6) * m.pow(2));
    let point = [mass.clone(), Complex::new(eta.clone(), Rational::from(0))];
    let bound_point = [
        Complex::new(lower_norm.clone(), Rational::from(0)),
        Complex::new(eta_abs.clone(), Rational::from(0)),
    ];
    let mut centers = Vec::with_capacity(shape.len());
    let mut radii = Vec::with_capacity(shape.len());
    let mut component_metadata = Vec::with_capacity(shape.len());
    for alpha in shape {
        let center = evaluate_exact(
            &taylor_derivative(&approximation, symbols, alpha),
            &variables,
            &point,
        )?;
        let mut radius_expression = taylor_derivative(&remainder, symbols, alpha);
        if alpha[0] % 2 != 0 {
            radius_expression = -radius_expression;
        }
        let radius_value = evaluate_exact(&radius_expression, &variables, &bound_point)?;
        if radius_value.im != Rational::from(0) || radius_value.re < Rational::from(0) {
            return Err(format!("nonpositive-real remainder certificate for {alpha:?}"));
        }
        let radius = radius_value.re;
        component_metadata.push(json!({
            "multi_index_mass_eta": alpha,
            "center_real_exact_rational": center.re.to_string(),
            "center_imaginary_exact_rational": center.im.to_string(),
            "absolute_complex_remainder_bound_exact_rational": radius.to_string(),
        }));
        centers.push(center);
        radii.push(radius);
    }
    let metadata = json!({
        "method": "Independent routing-derived Symanzik parameter series; exact Symbolica polynomial integration and normalized derivatives",
        "series_order_inclusive": series_order,
        "expansion_variable": "z=eta/M; mass dependence retained exactly before differentiation",
        "integrated_series_in_z": integrated_expression.to_string(),
        "expanded_parameter_polynomial_terms": expanded_parameter_terms,
        "coordinates": ["common squared mass: M+t_mass", "invariant scale: eta+t_eta"],
        "shape": shape,
        "coefficient_convention": "[t_mass^a t_eta^b], equal to partial derivatives divided by a! b!",
        "squared_mass_real_exact_rational": mass.re.to_string(),
        "squared_mass_imaginary_exact_rational": mass.im.to_string(),
        "eta_exact_rational": eta.to_string(),
        "invariant_multipliers": [0, -2, -2, 0, 0, -2],
        "mass_modulus_lower_bound_exact_rational": lower_norm.to_string(),
        "rho_exact_rational": (&eta_abs / &lower_norm).to_string(),
        "normalization": "D0=integral_Delta3 (M+eta*P)^(-2) dx, volume(Delta3)=1/6; all pole components zero",
        "parameter_bound": "P=2*(x1*x2+x1*x3+x2*x3)=(x1+x2+x3)^2-(x1^2+x2^2+x3^2), hence 0<=P<=1",
        "remainder_generator": "H_N((abs(eta)+t_eta)/(L-t_mass))/(6*(L-t_mass)^2)",
        "positive_tail": "H_N(z)=z^(N+1)*((N+1)/(1-z)+1/(1-z)^2)",
        "remainder_proof": "Coefficientwise absolute values of every omitted eta-series term and all normalized mass/eta derivatives are majorized by the positive generator; |M|>=L and 0<=P<=1 uniformly, then integrate with volume 1/6",
        "components": component_metadata,
        "resource_limits": {"series_order": MAX_SERIES_ORDER, "total_taylor_degree": MAX_TAYLOR_DEGREE, "components": MAX_COMPONENTS},
        "rounding": "Exact Complex<Rational> centers and Rational bounds; no floating-point evaluation",
    });
    Ok(NearVacuumOracle { centers, radii, metadata })
}
