"""Closed source/build/runtime validation. Importing launches no process."""
from pathlib import Path
import hashlib
import json
import math
import sys

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
CORE = HERE / 'core/crates/iregi-rust'
BUILD = HERE / 'build-001'
PROTOCOL = HERE / 'protocol.json'
FIXTURE = ROOT / 'validation/public-highpoint/fixture-conditioned_masses.json'
REFERENCE = ROOT / 'validation/public-highpoint/reference-conditioned_masses.json'
BASELINE = ROOT / 'validation/highpoint-six-point-api/qualified-v2/public-rank3-256-001/result.json'
DEPS = ROOT / 'target/e6-direct-n2/deps'
NATIVE = ROOT / 'target/e6-direct-n2/native'
SUPPLEMENTAL = ROOT / 'target/core-fused-cse-census/supplemental-deps'
DOMAINS = ['f64', 'DoubleFloat', 'Float128Dual', 'Float256Dual']
RUNS = {name: 'run-' + name + '-001' for name in DOMAINS}
OUTPUTS = ['libcandidate.rlib', 'typed_n6']
ENVIRONMENT = {'RAYON_NUM_THREADS': '1', 'RUST_TEST_THREADS': '1',
               'IREGI_PREPARATION_PROFILE': '1', 'IREGI_PV_PREPARATION_PROFILE': '1'}
EXTERNS = {
    'iregi_masters': DEPS / 'libiregi_masters-f07797f04e91954e.rlib',
    'symbolica': DEPS / 'libsymbolica-06e42762cabb77d9.rlib',
    'serde': DEPS / 'libserde-b04ba25115fa19f8.rlib',
    'serde_json': DEPS / 'libserde_json-d657c5438f354a41.rlib',
    'thiserror': SUPPLEMENTAL / 'libthiserror-0527e2191ec3561c.rlib',
}
HELPER_SHA = 'c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def key(path):
    path = Path(path).resolve()
    try:
        return str(path.relative_to(ROOT))
    except ValueError:
        return str(path)


def absolute(name):
    return Path(name) if Path(name).is_absolute() else ROOT / name


def bind(path, inputs, expected=None):
    name = key(path)
    digest = sha(absolute(name))
    require(expected is None or digest == expected, 'changed input: ' + name)
    require(name not in inputs or inputs[name] == digest, 'conflicting binding: ' + name)
    inputs[name] = digest
    return digest


def final_verify(inputs):
    for name, digest in inputs.items():
        require(sha(absolute(name)) == digest, 'changed input: ' + name)


def save(path, record):
    Path(path).write_text(json.dumps(record, indent=2, default=str) + '\n')


def closure_bindings():
    result = {}
    for manifest in [ROOT / 'target/e6-direct-n2/preparation.json',
                     ROOT / 'target/core-fused-cse-census/supplemental-deps.json']:
        bind(manifest, result)
        for entry in load(manifest)['files']:
            bind(ROOT / entry['frozen'], result, entry['sha256'])
    for folder, suffixes in [(DEPS, {'.rlib', '.so'}), (SUPPLEMENTAL, {'.rlib', '.so'}),
                             (NATIVE, {'.a', '.so'})]:
        actual = {key(path) for path in folder.rglob('*') if path.is_file() and path.suffix in suffixes}
        expected = {name for name in result if absolute(name).is_relative_to(folder)
                    and absolute(name).suffix in suffixes}
        require(actual == expected, 'dependency/native inventory differs: ' + str(folder))
    return result


def validate_protocol():
    p = load(PROTOCOL)
    require(Path.cwd().resolve() == ROOT, 'all commands must run from the project directory')
    require(p.get('status') == 'approved_source_only' and '/root' in p.get('reviewers', []),
            'this exact protocol has no ROOT source approval')
    require(p['revision'] == 1 and p['domains'] == DOMAINS, 'protocol domain/revision mismatch')
    require(p['build_bound_seconds'] == 90 and p['runtime_bound_seconds'] == 180,
            'protocol bounds mismatch')
    require(p['postwork_reserve_seconds'] == {'build': 25, 'run': 20}, 'reserve mismatch')
    require(p['domain_prerequisites'] == {name: ['qualified_build'] for name in DOMAINS},
            'numeric type stages are not independent')
    source = load(HERE / 'source.json')
    actual = {str(path.relative_to(HERE / 'core')): sha(path)
              for path in (HERE / 'core').rglob('*') if path.is_file()}
    require(actual == source['candidate_files'] and len(actual) == 61, 'private source inventory changed')
    for name, digest in actual.items():
        require(p['inputs'].get(key(HERE / 'core' / name)) == digest, 'source omitted from protocol')
    declaration = source['full_byte_restoration']['removed_only'].encode()
    for name, digest in source['full_byte_restoration']['restored_original_files'].items():
        content = (HERE / 'core' / name).read_bytes()
        if name == 'crates/iregi-rust/src/lib.rs':
            require(content.endswith(declaration), 'capture declaration changed')
            content = content[:-len(declaration)]
        require(hashlib.sha256(content).hexdigest() == digest, 'core behavior changed: ' + name)
    for name, digest in closure_bindings().items():
        require(p['inputs'].get(name) == digest, 'native/extern binding omitted: ' + name)
    for path in EXTERNS.values():
        require(key(path) in p['inputs'], 'explicit extern omitted')
    for name in ['common.py', 'build.py', 'run.py', 'compare_saved.py', 'prepare_protocol.py',
                 'lifecycle.py', 'source.json', 'protocol-proposal.json', 'source-review-addendum.json']:
        require(p['inputs'].get(key(HERE / name)) == sha(HERE / name), 'harness/source input omitted: ' + name)
    require(sha(HERE / 'lifecycle.py') == HELPER_SHA, 'owned-group lifecycle helper changed')
    for name in ['compiler_path', 'python_path', 'taskset_path']:
        require(p['inputs'].get(key(Path(p[name]))) == sha(p[name]), 'tool omitted: ' + name)
    require(Path(sys.executable).resolve() == Path(p['python_path']), 'Python interpreter differs')
    review = load(HERE / 'runner-comparator-source-review.json')
    require(review.get('status') == 'passed' and review.get('findings') == []
            and review.get('reviewer') in p.get('reviewers', []),
            'final harness has no independent source review')
    require(review.get('protocol_draft_sha256') == sha(HERE / 'protocol-draft.json')
            and p['inputs'].get(key(HERE / 'protocol-draft.json')) == sha(HERE / 'protocol-draft.json'),
            'independent review draft is not bound')
    require(p['inputs'].get(key(HERE / 'runner-comparator-source-review.json'))
            == sha(HERE / 'runner-comparator-source-review.json'), 'independent source review omitted')
    for name in ['common.py', 'build.py', 'run.py', 'compare_saved.py', 'prepare_protocol.py', 'lifecycle.py']:
        require(review.get('subject_sha256', {}).get(name) == sha(HERE / name),
                'independent review does not bind current harness: ' + name)
    for path in [FIXTURE, REFERENCE, BASELINE]:
        require(p['inputs'].get(key(path)) == sha(path), 'fixture/reference/baseline omitted')
    final_verify(p['inputs'])
    return p


def grant_path(operation):
    return HERE / ('grant-' + operation + '.json')


def validate_grant(operation, protocol, inputs):
    require(operation == 'build' or operation in DOMAINS, 'unknown grant operation')
    path = grant_path(operation)
    grant = load(path)
    require(grant.get('status') == 'granted' and grant.get('grantor') == '/root', 'missing root grant')
    require(grant.get('operation') == operation and grant.get('protocol_sha256') == sha(PROTOCOL),
            'grant is for different operation/protocol')
    bound, reserve = (90, 25) if operation == 'build' else (180, 20)
    require(grant.get('bound_seconds') == bound and grant.get('postwork_reserve_seconds') == reserve,
            'grant bound/reserve mismatch')
    require(grant.get('cpu_affinity') == ([14, 15] if operation == 'build' else [14]), 'grant affinity mismatch')
    if operation != 'build':
        require(grant.get('previous_numerical_lease_released') is True, 'previous numerical lease remains active')
    bind(path, inputs)
    return grant


def build_commands(protocol):
    common = [protocol['taskset_path'], '-c', '14,15', protocol['compiler_path'], '--edition=2024',
              '-C', 'opt-level=0', '-C', 'debuginfo=0', '-C', 'strip=debuginfo',
              '-L', f'dependency={DEPS}', '-L', f'dependency={SUPPLEMENTAL}', '-L', f'native={NATIVE}']
    externs = [arg for name, path in EXTERNS.items() for arg in ['--extern', f'{name}={path}']]
    return [
        ('core', common + ['--crate-name', 'iregi_rust', '--crate-type', 'rlib', '-C',
                           'metadata=typed_n6_sourceonly_v1', str(CORE / 'src/lib.rs'),
                           '-o', str(BUILD / 'libcandidate.rlib')] + externs, CORE),
        ('driver', common + ['--crate-name', 'typed_n6', str(HERE / 'source/main.rs'),
                             '--extern', f'candidate={BUILD / "libcandidate.rlib"}',
                             '-o', str(BUILD / 'typed_n6')], CORE),
    ]


def validate_steps(record, bound, reserve, expected_count, success):
    require(record.get('cleanup_errors') == [], 'owned-group cleanup failed')
    require(record.get('postwork_reserve_seconds') == reserve, 'terminal reserve mismatch')
    require(type(record.get('elapsed_seconds')) in [int, float]
            and math.isfinite(record['elapsed_seconds']) and 0 <= record['elapsed_seconds'] <= bound,
            'stage exceeded declared aggregate bound')
    steps = record['steps']
    require(len(steps) == expected_count, 'incomplete process sequence')
    groups = []
    for step in steps:
        require(step.get('status') in ['exited', 'failed'], 'child has no terminal state')
        group = step.get('owned_process_group')
        require(type(group) is int and group > 0 and step.get('owned_group_gone') is True,
                'owned group was not verified gone')
        groups.append(group)
        require(type(step.get('group_existed_at_cleanup')) is bool, 'owned-group cleanup check missing')
        cap = step.get('timeout_seconds')
        require(type(cap) in [int, float] and math.isfinite(cap) and 0 < cap <= bound - reserve,
                'child cap consumed cleanup/postguard reserve')
        elapsed = step.get('elapsed_seconds')
        require(type(elapsed) in [int, float] and math.isfinite(elapsed) and 0 <= elapsed <= bound,
                'invalid child elapsed time')
        if success:
            require(step['status'] == 'exited' and step.get('returncode') == 0
                    and not any(step.get(k) for k in ['timeout', 'error', 'cancellation']), 'child did not succeed')
    require(len(groups) == len(set(groups)), 'repeated owned group identity')
    if success:
        require(not any(record.get(k) for k in ['error', 'cancellation', 'postguard_error', 'postguard_cancellation']),
                'successful stage contains a failure')


def validate_build():
    protocol = validate_protocol()
    inputs = dict(protocol['inputs'])
    bind(PROTOCOL, inputs)
    validate_grant('build', protocol, inputs)
    record = load(BUILD / 'build.json')
    require(record['inputs'] == inputs and record.get('inputs_unchanged') is True, 'build inputs differ')
    require(record.get('status') == 'passed' and record.get('bound_seconds') == 90, 'build did not qualify')
    expected = [(name, cmd, str(manifest)) for name, cmd, manifest in build_commands(protocol)]
    require([(s['name'], s['command'], s['manifest_dir']) for s in record['steps']] == expected,
            'build command/source changed')
    validate_steps(record, 90, 25, 2, True)
    bind(BUILD / 'build.json', inputs)
    require(set(record['outputs']) == set(OUTPUTS), 'build output set differs')
    for name, digest in record['outputs'].items():
        bind(BUILD / name, inputs, digest)
    for step in record['steps']:
        bind(BUILD / (step['name'] + '.log'), inputs, step['log_sha256'])
    return {'protocol': protocol, 'run': record, 'input_sha256': inputs}


def run_command(domain, protocol):
    require(domain in DOMAINS, 'unknown domain')
    return [protocol['taskset_path'], '-c', '14', str(BUILD / 'typed_n6'), domain,
            key(FIXTURE), str(HERE / RUNS[domain] / 'result.json')]


def run_inputs(domain, build):
    # Deliberately no other domain's numerical result is a prerequisite.
    inputs = dict(build['input_sha256'])
    validate_grant(domain, build['protocol'], inputs)
    return inputs


def validate_run(domain):
    require(domain in DOMAINS, 'unknown domain')
    build = validate_build()
    expected = run_inputs(domain, build)
    folder = HERE / RUNS[domain]
    record = load(folder / 'run.json')
    require(record['operation'] == domain and record['inputs'] == expected, 'runtime input/operation mismatch')
    require(record.get('status') in ['passed', 'failed'] and record.get('inputs_unchanged') is True,
            'runtime lacks final immutable provenance')
    require(record['bound_seconds'] == 180 and record['environment_additions'] == ENVIRONMENT,
            'runtime bounds/environment mismatch')
    require([step['command'] for step in record['steps']] == [run_command(domain, build['protocol'])],
            'runtime command mismatch')
    validate_steps(record, 180, 20, 1, record['status'] == 'passed')
    inputs = dict(expected)
    bind(folder / 'run.json', inputs)
    require('step-0.log' in record['outputs'] and set(record['outputs']) <= {'step-0.log', 'result.json'},
            'runtime artifact inventory mismatch')
    for name, digest in record['outputs'].items():
        bind(folder / name, inputs, digest)
    data = load(folder / 'result.json') if 'result.json' in record['outputs'] else None
    complete = record['status'] == 'passed' and data is not None and data.get('status') == 'capture_complete_not_yet_qualified'
    return {'record': data, 'run': record, 'input_sha256': inputs, 'protocol': build['protocol'],
            'capture_completed': complete}
