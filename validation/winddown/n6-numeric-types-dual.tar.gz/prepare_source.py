"""Freeze a capture-only copy; this script never compiles or executes numerics."""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
ORIGINAL = ROOT / 'target/public-highpoint/six-point-integration/input-validation-v2'
DECLARATION = b'\n// Private qualification capture only; no production API change.\n#[doc(hidden)]\npub mod highpoint_numeric_probe;\n'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    manifest_path = ORIGINAL / 'source.json'
    assert sha(manifest_path) == '96a5a02990da0cc57014d7d339b8de9189198dbcd8959188bb4fc4946b843038'
    original = json.loads(manifest_path.read_text())['candidate_files']
    assert len(original) == 59
    destination = HERE / 'core'
    assert not destination.exists(), 'refusing to overwrite a source snapshot'
    # Validate every original before writing any candidate file.
    for name, digest in original.items():
        assert sha(ORIGINAL / 'core' / name) == digest, name
    expected_helpers = {
        'capture.rs': '2acc0befe6e0b43f8a83c20e9390cb68bb2975475251932bebf7cdeb4cb763b5',
        'jet_inputs.rs': '7b35954da337f1bb2191faa5ae05cec7e7f2ce1d6f4b88e90a64b104b350041f',
        'main.rs': 'ac748501bd8188902ea14deb006a6ed18be8158cf166fe834d123a6612c05f47',
    }
    for name, digest in expected_helpers.items():
        assert sha(HERE / 'source' / name) == digest, name
    for name in original:
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ORIGINAL / 'core' / name, target)
    library = destination / 'crates/iregi-rust/src/lib.rs'
    library.write_bytes(library.read_bytes() + DECLARATION)
    for source, name in [('capture.rs', 'highpoint_numeric_probe.rs'), ('jet_inputs.rs', 'jet_inputs.rs')]:
        shutil.copyfile(HERE / 'source' / source, library.parent / name)
    actual = {str(path.relative_to(destination)): sha(path)
              for path in sorted(destination.rglob('*')) if path.is_file()}
    assert len(actual) == 61
    proof = {}
    for name, digest in original.items():
        candidate = (destination / name).read_bytes()
        if name == 'crates/iregi-rust/src/lib.rs':
            assert candidate.endswith(DECLARATION)
            candidate = candidate[:-len(DECLARATION)]
        assert hashlib.sha256(candidate).hexdigest() == digest, name
        proof[name] = digest
    record = {
        'schema_version': 1,
        'status': 'source_snapshot_only_not_built',
        'base_manifest': str(manifest_path.relative_to(ROOT)),
        'base_manifest_sha256': sha(manifest_path),
        'base_qualification': 'validation/highpoint-six-point-api/qualification.json',
        'base_qualification_sha256': '97ff1fc6866115d64d2b21c46e20ad25449e39392b06c7913e076e5b19abe428',
        'candidate_files': actual,
        'full_byte_restoration': {
            'removed_only': DECLARATION.decode(),
            'restored_original_files': proof,
            'original_file_count': 59,
            'unchanged_whole_files': 58,
            'core_mathematics_unchanged': True,
        },
        'capture_helpers': expected_helpers,
        'preparation_script_sha256': sha(__file__),
        'compiler_tests_numerics_executed': False,
        'production_edits': False,
        'public_dual_qualified': False,
        'derivative_uncertainty_transport_qualified': False,
    }
    (HERE / 'source.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'status': record['status'], 'candidate_files': len(actual),
                      'source_sha256': sha(HERE / 'source.json')}))


if __name__ == '__main__':
    main()
