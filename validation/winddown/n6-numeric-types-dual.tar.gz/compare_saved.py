#!/usr/bin/env python3
"""Saved-data gates only; no compiler, Symbolica, reference or kernel execution.

The runtime validator owns process/source/binary/native provenance. This module
uses captured, separately symbolically differentiated multipliers; it does not
implement a Taylor algebra or regenerate the dilation polynomial.
"""
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import math
import sys

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
FIXTURE = ROOT / "validation/public-highpoint/fixture-conditioned_masses.json"
REFERENCE = ROOT / "validation/public-highpoint/reference-conditioned_masses.json"
ORIGINAL_EXE = ROOT / "target/reference/iregi-reference-original"
CAPSULE = ROOT / "validation/highpoint-six-point-api"
BASELINE = CAPSULE / "qualified-v2/public-rank3-256-001/result.json"
DOMAINS = {
    "f64": ("f64", 53, 1),
    "DoubleFloat": ("DoubleFloat", 106, 1),
    "Float128Dual": ("Float128", 128, 6),
    "Float256Dual": ("Float256", 256, 6),
}
SHAPE = [[0, 0], [1, 0], [0, 1], [2, 0], [1, 1], [0, 2]]
SCHEDULE = [
    ("singleton_affine", [0]), ("mixed", [0, 3, 1, 2, 0]),
    ("reordered", [2, 1, 0, 3, 0]), ("empty", []),
    ("singleton_again", [0]),
]
SETTINGS = dict(propagators=6, rank=0, powers=[1] * 6, dimension_shift=0,
                algorithm="PassarinoVeltman", convention="IregiNative",
                tensor_weights="Components", invariants="FromShifts", input_policy="Preserve")
STATS = {"input_rows", "argument_rows", "master_family_batches", "master_rows",
         "pentagon_box_rows", "reduction_rows", "fallback_rows", "fallback_successes", "analytic_rows"}
CERTIFICATES = {"input_rows", "evaluated_rows", "passes", "reduction_batches"}
PACKING = {"parent_input_rows", "child_batch_calls", "packed_child_rows",
           "parent_batch_calls", "packed_parent_rows"}
OPERAND = {"rational", "precision", "negative_sign", "finite"}
SCALE = Fraction(1, 256)
TOLERANCE = Fraction(1, 10_000_000_000)
CONVERGENCE = Fraction(1, 2**80)
PINS = {
    HERE / "protocol-proposal.json": "7ee9f6d6017cd2ab154a32c7db3e8476c8519328862a98fac27566d396143855",
    HERE / "source.json": "5acb0c7b6e7b9e522aca025fcf0320c5bf6024c3a1ec7f44b4c8598078bf12e4",
    HERE / "source-review-addendum.json": "6f12a994693de7521f6809905161ecbdd80cc187021910f6ea4da1a406d68f80",
    HERE / "design/dilation-math-source-review.json": "14da099580d7bd5e53f4fba3dcbf6221f365c017160189615b2ea3430d3fe7ae",
    HERE / "design/capture-source-review-final.json": "dea974abc05d44780e99fb6bc6a1e85702ab80af89343e83b60ecc6b1b5bc829",
    HERE / "source/capture.rs": "2acc0befe6e0b43f8a83c20e9390cb68bb2975475251932bebf7cdeb4cb763b5",
    HERE / "source/jet_inputs.rs": "7b35954da337f1bb2191faa5ae05cec7e7f2ce1d6f4b88e90a64b104b350041f",
    HERE / "source/main.rs": "ac748501bd8188902ea14deb006a6ed18be8158cf166fe834d123a6612c05f47",
    HERE / "core/crates/iregi-rust/src/highpoint_numeric_probe.rs": "2acc0befe6e0b43f8a83c20e9390cb68bb2975475251932bebf7cdeb4cb763b5",
    HERE / "core/crates/iregi-rust/src/jet_inputs.rs": "7b35954da337f1bb2191faa5ae05cec7e7f2ce1d6f4b88e90a64b104b350041f",
    FIXTURE: "ec27f2c5774a18d3d84d2d733e634dae93e9bd4c74523d6f77e8784d13421ada",
    REFERENCE: "9bc3f10ad27615f23ddb3c2f62169575378d32e6c35c9d2a9dd51223f9b39ec4",
    ORIGINAL_EXE: "8ee49ae42cb6994f4bd42ed3a3920152e767407ecdafd8986577d5496370a379",
    ROOT / "validation/public-highpoint/qualification.json": "b1d907c08cd73708404a8ee18a239f2863316b4d4fbe110ee48aa3863acd8ca1",
    CAPSULE / "qualification.json": "97ff1fc6866115d64d2b21c46e20ad25449e39392b06c7913e076e5b19abe428",
    BASELINE: "ccd00416b640f7c59a3fd8c18255ed28d8a8507b88ae4d38d9a4e031bab39d28",
    CAPSULE / "qualified-v2/comparison-128-256.json": "48c7478ecd25721aa4c13e735f489dce18e4810eb633181d5d360e595d9b5441",
    CAPSULE / "qualified-v2/public-paired-independent-audit.json": "ed18c0fe016c474dd9efae1d1a1736c0868a05f2761c2224ed4dd89155bd2b81",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def key(path):
    path = Path(path).resolve()
    return str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)


def normalize_bindings(bindings):
    require(isinstance(bindings, dict) and bindings, "missing validated binding inventory")
    result = {}
    for name, digest in bindings.items():
        path = Path(name) if Path(name).is_absolute() else ROOT / name
        normalized = key(path)
        require(normalized not in result or result[normalized] == digest, "conflicting path aliases")
        result[normalized] = digest
    return result


def failure(report, category, message, **location):
    report["failures"].append(dict(category=category, message=message, **location))


def check(report, condition, category, message, **location):
    if not condition:
        failure(report, category, message, **location)
    return condition


def number(value):
    require(isinstance(value, dict) and set(value) == OPERAND, "incomplete native operand metadata")
    require(value["finite"] is True and isinstance(value["rational"], str), "nonfinite/missing native value")
    exact = Fraction(value["rational"])
    bits, negative = value["precision"], value["negative_sign"]
    require(type(bits) is int and bits >= 0 and (exact == 0 or bits > 0), "invalid native precision")
    require(type(negative) is bool and (exact == 0 or negative == (exact < 0)), "invalid native sign")
    return exact


def complex_value(value):
    require(isinstance(value, list) and len(value) == 2, "expected a complete native complex value")
    return tuple(number(part) for part in value)


def squared_error(actual, expected):
    difference = sum((a - b) ** 2 for a, b in zip(actual, expected))
    return difference / max(SCALE**2, sum(x*x for x in expected))


def error_text(squared):
    with localcontext() as context:
        context.prec = 220
        return str((Decimal(squared.numerator) / Decimal(squared.denominator)).sqrt())


def differences(actual, previous, components, **location):
    """Every represented-value/precision/sign difference, including signed zero."""
    result = []
    require(len(actual) == len(previous) == 4 * components, "difference arrays are incomplete")
    for index, (a, b) in enumerate(zip(actual, previous)):
        for part, (x, y) in enumerate(zip(a, b)):
            if x != y:
                result.append(dict(**location, laurent_slot=index // components,
                    component=index % components, part="real" if part == 0 else "imaginary",
                    same_exact_value=number(x) == number(y),
                    same_rational_text=x["rational"] == y["rational"],
                    same_precision=x["precision"] == y["precision"],
                    same_sign_bit=x["negative_sign"] == y["negative_sign"], current=x, previous=y))
    return result


def expected_inputs(fixture):
    sample = fixture["samples"][0]
    require(sample["id"] == "base", "wrong retained sample")
    ps = sample["propagators"][:6]
    require(len(ps) == 6 and all(p["power"] == 1 for p in ps), "wrong retained propagators")
    require(all(len(p["shift"]) == 4 and len(p["mass_squared"]) == 2
                and Fraction(p["mass_squared"][1]) == 0 for p in ps), "wrong real-input fixture")
    base = [Fraction(x) for p in ps for x in p["shift"]]
    base += [Fraction(p["mass_squared"][0]) for p in ps] + [Fraction(sample["mu"])]
    q2 = max([Fraction(1)] + [abs(Fraction(p["mass_squared"][0])) for p in ps]
             + [abs(sum((1 if k == 0 else -1) * (Fraction(a["shift"][k])
                  - Fraction(b["shift"][k]))**2 for k in range(4)))
                for i, a in enumerate(ps) for b in ps[:i]])
    require(len(base) == 31 and q2 == 4, "wrong retained dimensional scale")
    return sample, ps, base


def validate_anchors(validated, bindings):
    """Every anchor must already belong to this producer's validated guards."""
    mandatory = set(PINS) | {Path(__file__).resolve(), HERE / "common.py"}
    require({key(p) for p in mandatory} <= set(bindings), "runtime omitted comparator/reference/helper anchors")
    for path, digest in PINS.items():
        require(bindings[key(path)] == digest and sha(path) == digest, "changed pinned anchor: " + key(path))
    source = read(HERE / "source.json")
    require(len(source["candidate_files"]) == 61, "wrong candidate source inventory")
    for name, digest in source["candidate_files"].items():
        require(bindings.get(key(HERE / "core" / name)) == digest, "compiled source is not guarded")
    require(read(HERE / "design/dilation-math-source-review.json")["source_math_review_passed"] is True,
            "symbolic helper has no matching mathematical source review")
    require(validated["protocol"]["domain_prerequisites"] == {d: ["qualified_build"] for d in DOMAINS},
            "domain success was made dependent on another domain")
    fixture, reference = read(FIXTURE), read(REFERENCE)
    sample, ps, base = expected_inputs(fixture)
    require(reference["status"] == "complete" and reference["reference"] == "untouched original IREGI"
            and reference["fixture_sha256"] == PINS[FIXTURE]
            and reference["executable_sha256"] == PINS[ORIGINAL_EXE], "original capture provenance mismatch")
    historical = read(ROOT / "validation/public-highpoint/qualification.json")
    require(all(historical["artifacts"][p.name] == PINS[p] for p in [FIXTURE, REFERENCE]),
            "original capture ledger mismatch")
    cases = [c for c in reference["cases"] if c["id"] == "n6_base_mode0"]
    require(len(cases) == 1, "original IBP scalar reference is ambiguous")
    case = cases[0]
    require(case["status"] == "captured" and case["exit_code"] == 0 and case["mode"] == 0
            and case["propagators"] == 6 and case["rank"] == 7 and case["sample"] == "base",
            "wrong original capture")
    lines = case["request"].splitlines()
    require(len(lines) == 8 and lines[-1] == "QUIT", "original request layout mismatch")
    header = lines[0].split()
    require(header[:7] == ["EVAL", "n6_base_mode0", "tensor", "0", "6", "7", "0"]
            and len(header) == 10 and Fraction(header[7]) == Fraction(sample["mu"])
            and Fraction(header[8]) == 0 and Fraction(header[9]) == Fraction("1e-6"), "original request differs")
    for line, p in zip(lines[1:-1], ps):
        require(list(map(Fraction, line.split())) == list(map(Fraction, p["shift"] + p["mass_squared"] + [1])),
                "original request uses different kinematics")
    response = case["response"]
    require([json.loads(line[7:], parse_float=str) for line in case["stdout"].splitlines()
             if line.startswith("RESULT ")] == [response], "original response differs from stdout")
    require(response["stable"] is True and response["id"] == case["id"]
            and response["poles"] == ["uv1", "ir1", "ir2", "finite"]
            and len(response["moments"]) == 330, "unstable or incomplete original reference")
    for slots in response["moments"]:
        require(len(slots) == 4 and all(len(z) == 2 for z in slots), "original Laurent array incomplete")
        for z in slots:
            tuple(Fraction(v) for v in z)
    capsule, baseline = read(CAPSULE / "qualification.json"), read(BASELINE)
    for p in [BASELINE, CAPSULE / "qualified-v2/comparison-128-256.json",
              CAPSULE / "qualified-v2/public-paired-independent-audit.json"]:
        require(capsule["payloads"][str(p.relative_to(CAPSULE))]["sha256"] == PINS[p], "baseline capsule mismatch")
    gate = read(CAPSULE / "qualified-v2/comparison-128-256.json")
    audit = read(CAPSULE / "qualified-v2/public-paired-independent-audit.json")
    require(gate["passed"] is True and gate["precision_convergence_qualified"] is True
            and audit["status"] == "passed_independent_saved_public_rank3_paired_audit"
            and audit["public_retained_base_rank3_numerical_qualification"] is True, "baseline scalar is unqualified")
    require(baseline["settings"] == dict(SETTINGS, rank=3) and baseline["working_bits"] == 256
            and baseline["requested_bits"] == 53 and baseline["status"] == "all_lanes_success"
            and baseline["rows"] == baseline["components"] == 1 and baseline["lane_statuses"] == ["Success"]
            and baseline["basis"][0] == [0, 0, 0, 0] and len(baseline["basis"]) == 35
            and baseline["input_exact_rational"] == [[[str(x), "0"] for x in base]], "baseline input/layout mismatch")
    scalar = baseline["lanes"][0]["moments"][0]
    require(len(scalar) == 4, "qualified scalar prefix incomplete")
    scalar = [tuple(Fraction(z[part]) for part in ["real", "imaginary"]) for z in scalar]
    require(all(z == (0, 0) for z in scalar[:3]), "qualified scalar has nonzero poles")
    return base, [tuple(Fraction(x) for x in z) for z in response["moments"][0]], scalar


def validate_inputs(record, components, base):
    require(record["profiles"] == ["affine", "product", "constant", "invalid_mu_zero"], "wrong profiles")
    multipliers = record["exact_homogeneity_multipliers"]
    require(len(multipliers) == 3 and all(len(row) == 6 for row in multipliers), "incomplete symbolic multipliers")
    require(all(isinstance(v, str) for row in multipliers for v in row), "multipliers must be exact rational strings")
    multipliers = [list(map(Fraction, row)) for row in multipliers]
    require(all(row[0] == 1 for row in multipliers) and multipliers[2] == [1, 0, 0, 0, 0, 0],
            "symbolic multiplier primal/constant contract differs")
    rows = record["represented_input_rows"]
    require(len(rows) == 4 and all(len(row) == 31 * components for row in rows), "incomplete input jets")
    decoded = [[complex_value(value) for value in row] for row in rows]
    for row in decoded:
        require(all(z[1] == 0 for z in row), "input jet is not real")
    for profile in range(3):
        require([decoded[profile][p * components][0] for p in range(31)] == base, "fixture primal changed")
    if components == 1:
        require(decoded[0] == decoded[1] == decoded[2], "ordinary profiles are not the retained common primal")
    else:
        require(all(decoded[2][p * components + c] == (0, 0) for p in range(31) for c in range(1, 6)),
                "constant input profile has nonzero Taylor components")
    require(decoded[3][:30 * components] == decoded[0][:30 * components]
            and all(z == (0, 0) for z in decoded[3][30 * components:]), "invalid-mu control changed")
    return multipliers


def validate_work(call, indices, successes):
    work = call["execution"]
    require(set(work) == PACKING | {"child_execution", "parent_execution", "child_certificate_execution",
                                    "parent_certificate_execution"}, "work counter inventory differs")
    require(all(type(work[k]) is int and work[k] >= 0 for k in PACKING), "invalid packing counter")
    for name in ["child_execution", "parent_execution"]:
        require(set(work[name]) == STATS and all(type(v) is int and v >= 0 for v in work[name].values()),
                "invalid execution counters")
    for name in ["child_certificate_execution", "parent_certificate_execution"]:
        value = work[name]
        require(set(value) == CERTIFICATES and all(type(v) is int and v >= 0 for v in value.values()),
                "invalid certificate counters")
        require(value["passes"] <= value["evaluated_rows"] and value["reduction_batches"] <= value["input_rows"]
                and (value["input_rows"] != 0 or not any(value.values())), "inconsistent certificate work")
    active = sum(p != 3 for p in indices)
    child, parent = work["child_execution"], work["parent_execution"]
    require(work["parent_input_rows"] == len(indices) and work["child_batch_calls"] == int(active > 0)
            and work["packed_child_rows"] == child["input_rows"] == 6 * active, "child packing/invalid-row exclusion differs")
    packed = work["packed_parent_rows"]
    require(successes <= packed <= active and work["parent_batch_calls"] == int(packed > 0)
            and parent["input_rows"] == packed and 0 <= parent["reduction_rows"] <= packed,
            "parent success/packing counters differ")
    require(not any(parent[k] for k in STATS - {"input_rows", "argument_rows", "reduction_rows"})
            and not any(work["parent_certificate_execution"].values()), "parent unexpectedly used masters/rerouting")
    require(work["child_certificate_execution"]["input_rows"] <= child["fallback_rows"], "unaccounted child certificates")
    if successes == active:
        require(parent["argument_rows"] == packed and child["argument_rows"] >= 6 * active,
                "successful work counters omit rows")
    if not indices:
        require(not any(work[k] for k in PACKING) and all(not any(work[k].values()) for k in
                ["child_execution", "parent_execution", "child_certificate_execution", "parent_certificate_execution"])
                and call["diagnostics"] == [], "empty call retained work or diagnostics")


def compare_slot(report, actual, expected, target, tolerance=TOLERANCE, **location):
    squared = squared_error(actual, expected)
    entry = dict(target=target, **location, actual=[str(x) for x in actual],
                 expected=[str(x) for x in expected], normalized_error=error_text(squared),
                 within_tolerance=squared <= tolerance**2)
    report["comparisons"].append(entry)
    if not entry["within_tolerance"]:
        failure(report, "numerical", "normalized tolerance exceeded", target=target, **location,
                normalized_error=entry["normalized_error"])


def validate_capture(report, record, domain, base, original, scalar):
    expected_domain, bits, components = DOMAINS[domain]
    require(isinstance(record, dict), "no retained capture JSON")
    require(record.get("schema_version") == 1 and record.get("domain") == expected_domain
            and record.get("working_bits") == bits and record.get("requested_bits") == 53
            and record.get("settings") == SETTINGS and record.get("fixture") == key(FIXTURE), "capture settings/input differ")
    require(record.get("interface") == "private exact-qualified ThinSix; capture-only helper module"
            and record.get("mode") == ("ordinary_primal" if components == 1 else "dynamic_mixed_second_dual"),
            "capture interface/domain differs")
    require(record.get("components") == components and record.get("ordered_shape") == (None if components == 1 else SHAPE)
            and record.get("basis") == [[0, 0, 0, 0]], "scalar/Taylor basis differs")
    multipliers = validate_inputs(record, components, base)
    calls = record.get("calls")
    require(isinstance(calls, list), "missing call ledger")
    check(report, len(calls) == 5, "coverage", "incomplete call schedule", observed=len(calls))
    success_count = invalid_count = actual_available = actual_rejected = slots_count = 0
    unexpected, baselines, flag_baselines = [], {}, {}
    for call_index, call in enumerate(calls):
        if call_index >= len(SCHEDULE):
            failure(report, "structure", "unexpected extra call", call_index=call_index)
            continue
        name, indices = SCHEDULE[call_index]
        location = dict(call=name, call_index=call_index)
        try:
            require(call.get("name") == name and call.get("profile_indices") == indices, "call order/profiles changed")
            require(call.get("input_preserved_exactly") is True, "input values or native metadata mutated")
            require(call.get("status") == "captured", "batch failed: " + str(call.get("error")))
            require(call.get("components") == components and call.get("basis") == [[0, 0, 0, 0]]
                    and call.get("metadata") == dict(convention="IregiNative", tensor_weights="Components",
                    dual_shape=None if components == 1 else SHAPE), "returned complete metadata differs")
            require(isinstance(call.get("diagnostics"), list) and len(call["diagnostics"]) == len(indices)
                    and all(isinstance(x, list) and all(isinstance(n, str) for n in x) for x in call["diagnostics"]),
                    "diagnostic lane inventory differs")
            require(isinstance(call.get("lanes"), list) and len(call["lanes"]) == len(indices), "incomplete lane ledger")
            call_successes = 0
            for row, (profile, lane) in enumerate(zip(indices, call["lanes"])):
                loc = dict(**location, row=row, profile=profile)
                try:
                    require(lane.get("row") == row and lane.get("profile") == profile
                            and isinstance(lane.get("status"), str), "lane identity/status differs")
                    require(all(type(lane.get(k)) is bool for k in ["fallback_used", "analytic_used"]), "missing actual-route flags")
                    values = lane.get("values")
                    actual_available += int(values is not None)
                    actual_rejected += int(values is None)
                    expected_outcome = (values is None and lane["status"].startswith("InvalidInput(")) if profile == 3 else (
                        values is not None and lane["status"] == "Success")
                    if not expected_outcome:
                        unexpected.append(dict(call=name, row=row, profile=profile, status=lane["status"]))
                    if profile == 3:
                        check(report, expected_outcome, "outcome", "invalid-mu lane was not an InvalidInput rejection", **loc)
                        require(values is None and not lane["fallback_used"] and not lane["analytic_used"]
                                and call["diagnostics"][row] == [], "invalid input exposed values or stale work")
                        invalid_count += int(expected_outcome)
                        continue
                    if not check(report, expected_outcome, "outcome", "intended positive lane unavailable", **loc,
                                 observed_status=lane["status"]):
                        continue
                    call_successes += 1
                    require(isinstance(values, list) and len(values) == 4 * components, "successful Laurent/Taylor array incomplete")
                    decoded = [complex_value(value) for value in values]
                    flags = (lane["fallback_used"], lane["analytic_used"])
                    if profile in flag_baselines:
                        check(report, flags == flag_baselines[profile], "flags", "profile rerouting flags changed across calls", **loc)
                    else:
                        flag_baselines[profile] = flags
                    previous = baselines.setdefault(profile, values)
                    report["repeated_representation_differences"].extend(differences(values, previous, components, **loc))
                    for index, value in enumerate(decoded):
                        pole, component = divmod(index, components)
                        slotloc = dict(**loc, laurent_slot=pole, component=component,
                                       multi_index=SHAPE[component] if components == 6 else [0, 0])
                        check(report, pole == 3 or value == (0, 0), "exact_zero", "nonzero pole component", **slotloc)
                        check(report, profile != 2 or component == 0 or value == (0, 0),
                              "exact_zero", "constant profile has a nonzero higher component", **slotloc)
                        if component == 0:
                            compare_slot(report, value, original[pole], "untouched_original_IBP_primal", **slotloc)
                        multiplier = multipliers[profile][component] if components == 6 else Fraction(1)
                        target = tuple(multiplier * x for x in scalar[pole])
                        compare_slot(report, value, target, "qualified_Float256_scalar_times_symbolic_multiplier", **slotloc)
                        compare_slot(report, value, complex_value(previous[index]), "same_profile_first_available", **slotloc)
                    success_count += 1
                    slots_count += len(values)
                except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError) as error:
                    failure(report, "lane_structure", str(error), **loc)
            validate_work(call, indices, call_successes)
        except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError) as error:
            failure(report, "call_structure", str(error), **location)
    check(report, record.get("status") == "capture_complete_not_yet_qualified"
          and record.get("active_call") == "singleton_again", "completion", "capture did not complete its fixed schedule")
    check(report, record.get("successful_lanes") == actual_available and record.get("rejected_lanes") == actual_rejected
          and record.get("unexpected_outcomes") == unexpected, "ledger", "captured outcome inventory differs")
    check(report, record.get("intended_successes_available") is True
          and record.get("expected_invalid_rejections_confirmed") is True, "outcome", "positive/invalid producer flags failed")
    check(report, success_count == 10 and invalid_count == 2 and slots_count == 40 * components,
          "coverage", "ten complete successes and two invalid controls are required",
          successful_lanes=success_count, invalid_rejections=invalid_count, complex_slots=slots_count)
    check(report, type(record.get("elapsed_seconds")) in (int, float)
          and math.isfinite(record["elapsed_seconds"]) and 0 <= record["elapsed_seconds"] <= 180,
          "completion", "invalid capture elapsed time")
    report["coverage"] = dict(calls=len(calls), expected_calls=5, successful_lanes=success_count,
        invalid_rejections=invalid_count, empty_calls=sum(c.get("profile_indices") == [] for c in calls),
        complex_slots=slots_count, expected_complex_slots=40 * components,
        original_primal_comparisons=sum(x["target"] == "untouched_original_IBP_primal" for x in report["comparisons"]),
        symbolic_identity_comparisons=sum(x["target"] == "qualified_Float256_scalar_times_symbolic_multiplier" for x in report["comparisons"]))


def qualify_domain(domain):
    require(domain in DOMAINS, "unsupported fixed domain")
    import common
    report = dict(schema_version=1, operation=domain, status="failed", passed=False,
        provenance_valid=False, provenance_errors=[], failures=[], comparisons=[],
        repeated_representation_differences=[], input_sha256={}, captured_record=None,
        public_dual_qualified=False, derivative_uncertainty_transport_qualified=False,
        precision_convergence_qualified=False, performance_qualified=False,
        normalization="|actual-expected|/max(2^-8,|expected|)", tolerance="1e-10",
        expected_multiplier_origin="Captured independent Symbolica derivative evaluator in the pinned helper; no handwritten Taylor algebra.",
        scope="One retained scalar N6 physical point, one coherent dilation under two formal parameterizations. No achieved derivative-error enclosure.")
    try:
        require(Path(common.ROOT).resolve() == ROOT and Path(common.HERE).resolve() == HERE, "wrong runtime validator")
        validated = common.validate_run(domain)
        require(isinstance(validated, dict) and type(validated.get("capture_completed")) is bool, "invalid runtime validator response")
        report["captured_record"] = validated["record"]
        report["runtime_outcome"] = {k: v for k, v in validated["run"].items() if k != "inputs"}
        bindings = normalize_bindings(validated["input_sha256"])
        report["input_sha256"] = bindings
        folder = HERE / ("run-" + domain + "-001")
        require({key(folder / "run.json"), key(folder / "step-0.log")} <= set(bindings), "terminal outputs unbound")
        if validated["record"] is not None:
            require(key(folder / "result.json") in bindings and read(folder / "result.json") == validated["record"],
                    "validated record is not the bound capture")
        base, original, scalar = validate_anchors(validated, bindings)
        report["provenance_valid"] = True
        check(report, validated["capture_completed"], "runtime", "capture ended unsuccessfully or remains partial")
        try:
            validate_capture(report, validated["record"], domain, base, original, scalar)
        except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError) as error:
            failure(report, "capture_structure", str(error))
        common.final_verify(bindings)
    except Exception as error:
        report["provenance_valid"] = False
        report["provenance_errors"].append(f"{type(error).__name__}: {error}")
    report["passed"] = report["provenance_valid"] and not report["failures"] and not report["provenance_errors"]
    report["status"] = "passed" if report["passed"] else "failed"
    report["private_dilation_identity_qualified"] = report["passed"] and DOMAINS[domain][2] == 6
    return report


def qualify_pair():
    import common
    low, high = [qualify_domain(d) for d in ["Float128Dual", "Float256Dual"]]
    report = dict(schema_version=1, operation="paired", status="failed", passed=False,
        domain_reports={"Float128Dual": low, "Float256Dual": high}, failures=[], comparisons=[],
        paired_representation_differences=[], input_representation_differences=[], input_sha256={},
        provenance_errors=[], public_dual_qualified=False, derivative_uncertainty_transport_qualified=False,
        precision_convergence_qualified=False, performance_qualified=False, tolerance="2^-80",
        normalization="|Float128-Float256|/max(2^-8,|Float256|)",
        scope="Both independently qualified private dilation captures only; f64/DoubleFloat are not prerequisites.")
    check(report, low["passed"] and high["passed"], "domain_gate", "both complete positive Dual gates must pass")
    try:
        for member in [low, high]:
            for name, digest in member["input_sha256"].items():
                require(name not in report["input_sha256"] or report["input_sha256"][name] == digest, "paired provenance conflict")
                report["input_sha256"][name] = digest
        a, b = low["captured_record"], high["captured_record"]
        require(isinstance(a, dict) and isinstance(b, dict), "one Dual capture is unavailable")
        require(a["settings"] == b["settings"] == SETTINGS and a["components"] == b["components"] == 6
                and a["ordered_shape"] == b["ordered_shape"] == SHAPE, "paired layouts differ")
        require([[Fraction(v) for v in row] for row in a["exact_homogeneity_multipliers"]]
                == [[Fraction(v) for v in row] for row in b["exact_homogeneity_multipliers"]], "symbolic multipliers differ")
        for profile, (x, y) in enumerate(zip(a["represented_input_rows"], b["represented_input_rows"])):
            require(len(x) == len(y) == 186 and all(complex_value(v) == complex_value(w) for v, w in zip(x, y)),
                    "exact paired helper input jets differ")
            for argument_component, (v, w) in enumerate(zip(x, y)):
                if v != w:
                    report["input_representation_differences"].append(dict(profile=profile,
                        parameter=argument_component // 6, component=argument_component % 6, low=v, high=w))
        require(len(a["represented_input_rows"]) == len(b["represented_input_rows"]) == 4, "paired input row inventory differs")
        require(len(a["calls"]) == len(b["calls"]) == 5, "paired schedule incomplete")
        for call_index, (name, indices) in enumerate(SCHEDULE):
            ca, cb = a["calls"][call_index], b["calls"][call_index]
            require(ca["name"] == cb["name"] == name and ca["profile_indices"] == cb["profile_indices"] == indices,
                    "paired schedule ordering differs")
            require(len(ca["lanes"]) == len(cb["lanes"]) == len(indices), "paired lane ledger incomplete")
            for row, profile in enumerate(indices):
                x, y = ca["lanes"][row], cb["lanes"][row]
                if profile == 3:
                    continue
                loc = dict(call=name, row=row, profile=profile)
                if x.get("status") != "Success" or y.get("status") != "Success" or x.get("values") is None or y.get("values") is None:
                    failure(report, "outcome", "matching rejections are not convergence", **loc)
                    continue
                require(len(x["values"]) == len(y["values"]) == 24, "paired successful array incomplete")
                report["paired_representation_differences"].extend(differences(x["values"], y["values"], 6, **loc))
                for index, (v, w) in enumerate(zip(x["values"], y["values"])):
                    compare_slot(report, complex_value(v), complex_value(w), "Float128_vs_Float256", CONVERGENCE,
                                 **loc, laurent_slot=index // 6, component=index % 6, multi_index=SHAPE[index % 6])
        check(report, len(report["comparisons"]) == 240, "coverage", "full paired240-slot convergence unavailable")
        common.final_verify(report["input_sha256"])
    except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError) as error:
        failure(report, "paired_structure_or_guard", str(error))
    report["passed"] = low["passed"] and high["passed"] and not report["failures"]
    report["precision_convergence_qualified"] = report["passed"]
    report["status"] = "passed" if report["passed"] else "failed"
    return report


def main(operation):
    require(operation in set(DOMAINS) | {"paired"}, "unknown comparator operation")
    destination = HERE / ("comparison-" + operation + ".json")
    require(not destination.exists(), "existing comparison is immutable")
    report = qualify_pair() if operation == "paired" else qualify_domain(operation)
    with destination.open("x") as stream:
        stream.write(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(dict(operation=operation, status=report["status"], output=str(destination))))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    require(len(sys.argv) == 2, "usage: compare_saved.py DOMAIN|paired")
    sys.exit(main(sys.argv[1]))
