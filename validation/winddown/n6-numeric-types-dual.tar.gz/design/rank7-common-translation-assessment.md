# Predeclared common-translation assessment for retained N6 rank seven

Source-only proposal, 2026-10-24. No build, Symbolica evaluation, reference execution, new fixture or numerical result was produced. The existing **90 failed original comparisons remain failed permanently**; their evidence is untouched. No proposed shift is claimed to succeed.

Predeclare exactly one alternative: take sample `base`, its **first six** propagators, and add the exact four-vector **t=(4,4,4,4)** to every shift. The resulting shifts are `(4,4,4,4)`, `(4,5,4,4)`, `(4,4,5,4)`, `(4,4,4,5)`, `(9/2,4,4,4)`, `(4,5,5,4)`. Keep squared masses `(1,2,3,4,2,3)`, mu=3, unit powers, h=0, native raw Components and cumulative rank seven. All coordinates are exactly binary-representable. This is a predeclared routing diagnostic, not a search over shifts until one passes.

For the convention D_i(q;p)=(q+p_i)^2−m_i² and M_alpha(p)=integral(q^alpha/product D_i), put k=q+t. Then

`M_alpha(p+t) = integral[ product_mu (k_mu−t_mu)^alpha_mu / product_i D_i(k;p) ]`.

Thus `M_alpha(p+t)=sum_beta C_alpha,beta(t) M_beta(p)`, where C is the exact coefficient of k^beta in that displayed polynomial. The sign is **minus t**; for example M_e_mu(p+t)=M_e_mu(p)−t_mu M_0(p). This is a Cartesian translation, without an extra spatial metric sign. Apply the same real transformation independently to all four Laurent slots, retaining complete complex values. Its inverse is C(−t); its diagonal is one.

Use the existing `tensor_basis(7)` ordering for all **330** rows. Construct each product as a Symbolica Atom expression, then use `iregi_prepare::polynomial_from_expression`, which calls Symbolica expansion and `to_polynomial_in_vars_with_field`, with statistical zero testing disabled. Map its exact exponent tuples into the existing basis. Evaluate the resulting 330×4 linear forms through Symbolica evaluators or the existing contraction adapter. Do not implement binomial/multinomial expansion, factorial weights or polynomial arithmetic separately. Existing preparation tests demonstrate exact coefficient retention; FeynKit routing already feeds this same extraction path. These APIs were inspected, not executed here.

Original `ti_reduce.f90:95–134` subtracts the first input shift (the last for CTMODE=2) before reduction, sets TSTABLE from STABLE_IREGI, then, **only if stable**, negates that saved shift and calls SHIFT_MOM. `funlib.f90:577–698` expands `(q+MOM)` into all four Laurent arrays; with MOM=−t this agrees with the formula above. Keep the raw-component/ML5 convention. The stability flag is not recomputed after the shift. An unstable reference result must remain an unstable case; the source does not promise that its output was translated.

For this exact t, the original recentered inputs are the same retained base inputs. Pairwise distances, scalar-master kinematics and physical thresholds are unchanged. The comparator's scale uses masses and pairwise differences, so **Q remains 2**, rather than increasing with the coordinate offset. Powers of −4 multiply lower-rank moments, including a scalar term of degree |alpha| in t. They may make shifted high moments dominated by lower ranks and reduce relative discrepancies. This is an output-conditioning hypothesis, not a measured improvement. Lower-rank errors are also multiplied, sums may cancel, and the candidate's absolute-coordinate assembly/guards can become worse. No translation removes the underlying highest-rank residual: C_alpha,alpha=1. Inverting a large shift can amplify cancellation.

Any later, separately authorized protocol should retain all 1,320 complex slots, original stability flags, unchanged 1e−10 mixed tolerance and Q^(rank−8) normalization. Compare direct shifted candidate and original results, and separately check Symbolica translation identities against each code's own base array. The latter are routing consistency checks, not an independent accuracy oracle. Keep the original 90 failures and report every shifted failure. Also retain an absolute, dimensionally normalized real-zero residual; a large imaginary denominator must not hide real contamination.

The saved base comparison has maximum normalized original disagreement about 2.538e−9. Its 128/256 diagnostic agreement, exact/near-zero real parts, and saved quadrature witnesses for only the scalar and moment321 do **not** establish all imaginary components. A shifted pass would qualify only this additional routing fixture; it cannot upgrade the original rank-seven gate, assign all disagreement to either implementation, certify the highest-rank contribution, or establish general rank-seven accuracy/performance.

Inspected source/evidence bindings (SHA256):

| File | SHA256 |
|---|---|
| [validation/highpoint-thin-n6-rank7-phase/reference/fixture-conditioned_masses.json](/shared/external/iregi/iregi-rust/validation/highpoint-thin-n6-rank7-phase/reference/fixture-conditioned_masses.json) | `ec27f2c5774a18d3d84d2d733e634dae93e9bd4c74523d6f77e8784d13421ada` |
| [validation/highpoint-thin-n6-rank7-phase/reference/reference-conditioned_masses.json](/shared/external/iregi/iregi-rust/validation/highpoint-thin-n6-rank7-phase/reference/reference-conditioned_masses.json) | `9bc3f10ad27615f23ddb3c2f62169575378d32e6c35c9d2a9dd51223f9b39ec4` |
| [validation/highpoint-thin-n6-rank7-phase/qualification.json](/shared/external/iregi/iregi-rust/validation/highpoint-thin-n6-rank7-phase/qualification.json) | `e7901c824d8e32c1c9baa7664c381c02f94dc0214ddeb90f75cfc14ef3b8e917` |
| [validation/highpoint-thin-n6-rank7-phase/independent256audit/audit.json](/shared/external/iregi/iregi-rust/validation/highpoint-thin-n6-rank7-phase/independent256audit/audit.json) | `91b28c5e547d30a51bf6c34cb02defd98322f9c9653f85675d489ec991d03b39` |
| [validation/highpoint-thin-n6-rank7-phase/reference/compare_public.py](/shared/external/iregi/iregi-rust/validation/highpoint-thin-n6-rank7-phase/reference/compare_public.py) | `bd7139b6f846b69706a89c6c72e426605aebd5fa4ffbb75dcf1bcfb83c04da9d` |
| [/shared/external/iregi/references/madgraph/vendor/IREGI/src/ti_reduce.f90](/shared/external/iregi/references/madgraph/vendor/IREGI/src/ti_reduce.f90) | `17d9a0f5e14b84f46667f532a1463a5734cd46c885467cfb6230e862d2ceb49a` |
| [/shared/external/iregi/references/madgraph/vendor/IREGI/src/funlib.f90](/shared/external/iregi/references/madgraph/vendor/IREGI/src/funlib.f90) | `1eebe2910debc482fa3976c0bc9a73553bf7cefe03dbf6b52786f0ce7979bf95` |
| [crates/iregi-prepare/src/lib.rs](/shared/external/iregi/iregi-rust/crates/iregi-prepare/src/lib.rs) | `ae0d9710b7baf4196bf8083a7ccff70b0181c6671ffeca15aed53d72b81c01cc` |
| [crates/iregi-prepare/tests/preparation.rs](/shared/external/iregi/iregi-rust/crates/iregi-prepare/tests/preparation.rs) | `a2f9565e26741aa22419454436f59741f3a1eb0d5a8a586a304f9cbea08dfe7d` |
| [crates/iregi-rust/src/basis.rs](/shared/external/iregi/iregi-rust/crates/iregi-rust/src/basis.rs) | `5d245fd11b81bd59105d554d9a33cd7441e3d5c7954621b998057c328a667178` |
| [crates/iregi-rust/src/pv.rs](/shared/external/iregi/iregi-rust/crates/iregi-rust/src/pv.rs) | `e490efbb9f8072bf7f9f81c72cce1c06f9e0baa35ee7300a656c45ec6906254d` |
