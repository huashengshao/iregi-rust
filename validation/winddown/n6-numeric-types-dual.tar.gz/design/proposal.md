# Retained scalar N6 numeric-type and dilation-jet probe

This is a source-only proposal. It adds a capture module to a private copy of the
qualified restricted six-point implementation; no production source, public
domain, numerical threshold, or guard policy changes. The original 59 source and
fixture files must be restored byte-for-byte after removing the single new
module declaration. No compiler or numerical producer has been launched.

## Scope and independent identities

Use row zero of `validation/public-highpoint/fixture-conditioned_masses.json`,
with all six propagators, unit powers, zero dimension shift, preserved absolute
shifts, PV mode, native component tensors, and rank zero. Compare all four native
Laurent slots, including each exact zero pole. The first two domains are ordinary
`f64` and Symbolica `DoubleFloat`. The next two are the internal dynamic Dual
executor with `Float` working precision 128 and 256 bits, requested precision 53.
The public six-point Dual API stays deferred.

For each physical momentum shift and the renormalization scale use a common
factor lambda; for each squared mass use lambda squared. The retained scalar
hexagon has no UV or IR poles and mass dimension -8, hence its finite part scales
as lambda to the power -8. Co-scaling mu keeps its dimensionless logarithmic
arguments fixed before the finite limit. Branch choices and exact planarity are
unchanged in a neighborhood of the real positive primal lambda=1.

There are two formal variables but only **one physical scaling direction**:

- affine lambda = 1 + a*x + b*y;
- product lambda = (1+a*x)*(1+b*y);
- constant lambda = 1;
- a copied affine row with every mu component zero, expected `InvalidInput`.

Here a=(2^60+1)/2^60 and b=3/2. The ordered Taylor shape is
`[00,10,01,20,11,02]`. Symbolica's Dualizer generates the complete input jets over
exact rationals. A separate ordinary Symbolica differentiation evaluator obtains
the six response coefficients; second pure derivatives are divided by two and
the mixed derivative is not. No Taylor-product or coefficient-extraction algebra
is reimplemented. The nonzero mixed input of the product profile is essential:
it distinguishes nonlinear input propagation from merely two independent first
derivative seeds. Input conversion must preserve each exact rational, including
information beyond 53 bits in the high-precision modes.

The captured child sensitivity is primal-only. Successful numerical scale-jet
identities do **not** certify requested-53 derivative-error propagation through
child cancellations, independent mass derivatives, arbitrary mixed directions,
or the public Dual API. This probe does not claim a rigorous error enclosure,
static Dual support, generalized N6 powers, rank-seven accuracy, or performance.

## Fixed batch schedule and complete results

With profile IDs `[affine,product,constant,invalid_mu_zero]`, reuse one workspace
for five calls: `[0]`, `[0,3,1,2,0]`, `[2,1,0,3,0]`, `[]`, `[0]`.
Each positive profile must produce `Success` and a complete array; both invalid
neighbors must produce `InvalidInput` with no returned array. Thus each domain
requires ten successful lanes, two rejected controls and one empty call.
Matching guard failures never count as numerical agreements. The ordinary modes
capture forty successful complex Laurent slots each; each Dual mode captures
240. Capture actual basis, convention, tensor weights, complete ordered shape,
precision/sign/rational data, all flags and diagnostics, input preservation,
child/parent batch counters, and per-call certificate counters. Empty calls must
reset counters; repeated/reordered profiles must remain independently matched.

## Proposed gates and bounded execution

Before any build, freeze and independently review the helper/source manifest,
complete explicit Rust/native dependency closure, compiler and scripts. Reuse
the existing native debug closure and its recorded profile; do not mix it with
the newer Cargo build context or search live dependency directories. The
qualified lifecycle helper is exactly SHA256
`c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824`.
Retain owned-process-group cleanup, deferred interruption handling, terminal
records written before artifact hashing, and explicit cleanup/postguard reserves.

Proposed bounds are one core-plus-driver build of 90 seconds including a
25-second reserve, and one capture per domain of 180 seconds including a
20-second reserve. These bounds are **not a runtime grant**. Start with ordinary
f64 and DD, preserving any preparation or guard rejection as an unsuccessful
domain. A rejected ordinary domain cannot become a claimed success by comparing
two failures. Later higher-precision diagnostic domains need separate root
coordination if a predecessor fails; there is no automatic retry or extension.

Saved-data admission checks all successful slots against the untouched stable
original IBP scalar result at the unchanged mixed normalized tolerance 1e-10.
Use Q=2 from the physical masses and shift differences, excluding mu, and the
native rank-zero scale Q^-8. Compare against the independently qualified old
Float256 scalar prefix as well; explicitly distinguish this implementation
consistency check from the original-reference comparison. No slots are excluded.

For jets, compare the finite Taylor components against the independently
symbolically differentiated multipliers times the qualified Float256 scalar
prefix. Normalize a component by `max(Q^-8, |expected component|)` at the same
1e-10 numerical threshold. All pole components and constant-profile non-primal
components must be exactly zero. Compare all 240 matching successful slots
between 128 and 256 bits at the unchanged 2^-80 convergence threshold, with
complete value/precision/sign differences inventoried. Convergence and identity
agreement remain empirical observations, not achieved-error certificates.

The next concrete deliverable after source approval is one frozen private
core/driver build and the first bounded primal capture. The complete comparator
and bounded-runner source must be reviewed before any numerical launch.
