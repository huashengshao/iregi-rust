"""Prepare source-only draft/final protocol. Never compile or launch numerics."""
from pathlib import Path
import shutil
import sys
import common as h


def draft():
    target = h.HERE / 'protocol-draft.json'
    h.require(not target.exists(), 'refusing to overwrite the protocol draft')
    proposal = h.load(h.HERE / 'protocol-proposal.json')
    h.require(h.sha(h.HERE / 'protocol-proposal.json') ==
              '7ee9f6d6017cd2ab154a32c7db3e8476c8519328862a98fac27566d396143855', 'proposal changed')
    inputs = dict(proposal['source_inputs_verified_during_source_preparation'])
    h.final_verify(inputs)
    for name, digest in proposal['future_native_toolchain_inputs_from_qualified_protocol'].items():
        h.bind(h.absolute(name), inputs, digest)
    for name, digest in h.closure_bindings().items():
        h.require(inputs.get(name) == digest, 'inherited native closure differs')
    original = h.load(h.ROOT / proposal['qualified_protocol_source'])
    h.bind(h.ROOT / proposal['qualified_protocol_source'], inputs, proposal['qualified_protocol_sha256'])
    compiler = original['compiler_path']
    python = str(Path(sys.executable).resolve())
    taskset_found = shutil.which('taskset')
    h.require(taskset_found is not None, 'taskset is unavailable')
    taskset = str(Path(taskset_found).resolve())
    for path in [Path(compiler), Path(python), Path(taskset), h.ROOT / 'scripts/env.sh']:
        h.bind(path, inputs)
    names = ['common.py', 'build.py', 'run.py', 'compare_saved.py', 'prepare_protocol.py', 'lifecycle.py', 'README.md',
             'protocol-proposal.json', 'source-review-addendum.json',
             'design/dilation-math-source-review.json', 'design/capture-source-review-supplement.json']
    for name in names:
        h.bind(h.HERE / name, inputs)
    h.require(h.sha(h.HERE / 'lifecycle.py') == h.HELPER_SHA, 'lifecycle helper changed')
    source = h.load(h.HERE / 'source.json')
    actual = {str(path.relative_to(h.HERE / 'core')): h.sha(path)
              for path in (h.HERE / 'core').rglob('*') if path.is_file()}
    h.require(actual == source['candidate_files'] and len(actual) == 61, 'source inventory changed')
    record = {
        'schema_version': 1, 'revision': 1, 'status': 'pending_independent_and_root_source_review',
        'reviewers': [], 'domains': h.DOMAINS,
        'source_manifest_sha256': h.sha(h.HERE / 'source.json'),
        'source_proposal_sha256': h.sha(h.HERE / 'protocol-proposal.json'),
        'math_review_sha256': h.sha(h.HERE / 'design/dilation-math-source-review.json'),
        'compiler_path': compiler, 'python_path': python, 'taskset_path': taskset,
        'compile_profile': 'Same qualified private native-object closure; opt0/debuginfo0/stripdebuginfo; no dependency build or live -L fallback.',
        'required_build_products': h.OUTPUTS,
        'build_bound_seconds': 90, 'runtime_bound_seconds': 180,
        'postwork_reserve_seconds': {'build': 25, 'run': 20},
        'owned_group_helper_sha256': h.HELPER_SHA,
        'cpu_affinity': {'build': [14, 15], 'runtime': [14]},
        'environment_additions': h.ENVIRONMENT,
        'domain_prerequisites': {name: ['qualified_build'] for name in h.DOMAINS},
        'stage_independence': 'Each type has its own fixed single attempt and grant. No other type numerical gate is a prerequisite. Failures remain visible; paired convergence requires both full Dual positive gates.',
        'fixed_case': {name: proposal[name] for name in ['settings', 'fixture_row', 'ordered_dual_shape',
            'profile_schedule', 'physical_direction', 'positive_lanes_per_domain',
            'invalid_mu_zero_rejections_per_domain', 'empty_calls_per_domain',
            'successful_complex_laurent_taylor_slots', 'normalization', 'tolerances', 'exact_zero_requirements']},
        'root_grant_requirements': {
            'filename': 'grant-<operation>.json, operation build or exact domain string',
            'status': 'granted', 'grantor': '/root', 'protocol_sha256': 'exact final protocol file hash',
            'bound_seconds': '90 for build;180 for capture',
            'postwork_reserve_seconds': '25 for build;20 for capture',
            'cpu_affinity': '[14,15] for build;[14] for capture',
            'previous_numerical_lease_released': 'must be true for every capture',
        },
        'commands': {
            'build': [python, str(h.HERE / 'build.py')],
            'capture': {name: [python, str(h.HERE / 'run.py'), name] for name in h.DOMAINS},
            'saved_gate': {name: [python, str(h.HERE / 'compare_saved.py'), name]
                           for name in h.DOMAINS + ['paired']},
        },
        'dependency_scope': 'All explicit frozen Rust/native archives and compiler/Python/taskset executables are hashed. No claim of hashing every transitive operating-system or Nix sysroot input.',
        'capture_failures': 'Preserve terminal/log/partial JSON. A complete captured guard rejection fails that type numerical gate; an incomplete or timed-out capture cannot qualify. Missing/changed provenance fails admission separately.',
        'limits': proposal['remaining_limits'] + [
            'All positive profile primals are one retained physical point.',
            'The public Float-only rank<=3 scope remains unchanged; no public Dual constructor.',
            'No retries, bound extensions, new reference executions, quadrature, production edits, or performance gate.',
            'Source approval does not grant any process execution; each stage requires its own root grant.',
        ],
        'build_qualified': False, 'numerical_qualified': False, 'public_dual_qualified': False,
        'derivative_uncertainty_transport_qualified': False, 'performance_qualified': False,
        'inputs': inputs,
    }
    h.save(target, record)
    print({'status': record['status'], 'inputs': len(inputs), 'sha256': h.sha(target)})


def finalize():
    h.require(not h.PROTOCOL.exists(), 'refusing to overwrite final protocol')
    path = h.HERE / 'protocol-draft.json'
    record = h.load(path)
    h.require(record['status'] == 'pending_independent_and_root_source_review', 'unexpected draft status')
    h.final_verify(record['inputs'])
    review_path = h.HERE / 'runner-comparator-source-review.json'
    review = h.load(review_path)
    h.require(review.get('status') == 'passed' and review.get('findings') == [], 'peer review is not clear')
    h.require(review.get('protocol_draft_sha256') == h.sha(path), 'reviewed draft differs')
    for name in ['common.py', 'build.py', 'run.py', 'compare_saved.py', 'prepare_protocol.py', 'lifecycle.py']:
        h.require(review.get('subject_sha256', {}).get(name) == h.sha(h.HERE / name),
                  'reviewed harness differs: ' + name)
    h.bind(path, record['inputs'])
    h.bind(review_path, record['inputs'])
    record['status'] = 'pending_root_source_approval'
    record['reviewers'] = [review['reviewer']]
    record['independent_review_sha256'] = h.sha(review_path)
    h.save(h.PROTOCOL, record)
    print({'status': record['status'], 'inputs': len(record['inputs']), 'sha256': h.sha(h.PROTOCOL)})


if __name__ == '__main__':
    h.require(len(sys.argv) == 2 and sys.argv[1] in ['draft', 'finalize'], 'use draft or finalize')
    {'draft': draft, 'finalize': finalize}[sys.argv[1]]()
