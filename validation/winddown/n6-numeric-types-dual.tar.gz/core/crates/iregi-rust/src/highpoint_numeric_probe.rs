//! Capture-only private module. No production API or reduction mathematics changes.
#[path = "jet_inputs.rs"]
mod jet_inputs;

use crate::{Algorithm, CertificateExecutionStats, ExecutionStats, KinematicsBatch, LaneStatus, ReductionSettings};
use crate::thin_n6::{ThinSixReductionPlan, ThinSixWorkspace};
use iregi_masters::NativeFloat;
use jet_inputs::{PreparedJets, ScaleProfile};
use serde_json::{Value, json};
use std::{error::Error, path::Path, time::Instant};
use symbolica::{
    domains::{dual::HyperDual, float::{Complex, DoubleFloat, Float, FloatLike},
              integer::Integer, rational::Rational},
    evaluate::EvaluationDomain,
};

fn rational(value: &Value) -> Result<Rational, Box<dyn Error>> {
    let text = value.as_str().ok_or("fixture rational must be a string")?;
    let (n, d) = text.split_once('/').unwrap_or((text, "1"));
    let denominator = d.parse::<Integer>()?;
    if denominator == Integer::from(0) { return Err("zero rational denominator".into()); }
    Ok(Rational::from((n.parse::<Integer>()?, denominator)))
}

fn base_input(path: &Path) -> Result<Vec<Rational>, Box<dyn Error>> {
    let fixture: Value = serde_json::from_str(&std::fs::read_to_string(path)?)?;
    let propagators = fixture["samples"][0]["propagators"].as_array().ok_or("missing propagators")?;
    if propagators.len() < 6 { return Err("N6 fixture missing propagators".into()); }
    let mut values = Vec::with_capacity(31);
    for propagator in &propagators[..6] {
        let shift = propagator["shift"].as_array().ok_or("missing shift")?;
        if shift.len() != 4 { return Err("invalid Cartesian shift width".into()); }
        for value in shift { values.push(rational(value)?); }
    }
    for propagator in &propagators[..6] {
        let mass = propagator["mass_squared"].as_array().ok_or("missing squared mass")?;
        if mass.len() != 2 || propagator["power"] != 1 || rational(&mass[1])? != Rational::from(0) {
            return Err("this retained probe requires real squared masses and unit powers".into());
        }
        values.push(rational(&mass[0])?);
    }
    values.push(rational(&fixture["samples"][0]["mu"])?);
    Ok(values)
}

fn operand<T: NativeFloat>(value: &T) -> Value {
    json!({"rational": value.exact_rational().map(|x| x.to_string()),
           "precision": value.get_precision(), "negative_sign": value.negative_sign(),
           "finite": value.is_finite()})
}

fn represented<T: NativeFloat>(values: &[Complex<T>]) -> Value {
    json!(values.iter().map(|z| json!([operand(&z.re), operand(&z.im)])).collect::<Vec<_>>())
}

fn write(path: &Path, record: &Value) -> Result<(), Box<dyn Error>> {
    std::fs::write(path, serde_json::to_string_pretty(record)? + "\n")?;
    Ok(())
}

// Same read-only counter serialization as the qualified public lifecycle driver.
fn execution(stats: ExecutionStats) -> Value {
    json!({"input_rows": stats.input_rows, "argument_rows": stats.argument_rows,
        "master_family_batches": stats.master_family_batches, "master_rows": stats.master_rows,
        "pentagon_box_rows": stats.pentagon_box_rows, "reduction_rows": stats.reduction_rows,
        "fallback_rows": stats.fallback_rows, "fallback_successes": stats.fallback_successes,
        "analytic_rows": stats.analytic_rows})
}

fn certificate(stats: CertificateExecutionStats) -> Value {
    json!({"input_rows": stats.input_rows, "evaluated_rows": stats.evaluated_rows,
        "passes": stats.passes, "reduction_batches": stats.reduction_batches})
}

fn capture<T: NativeFloat>(domain: &str, prototype: T, dual: bool, fixture: &Path,
                          output: &Path) -> Result<u8, Box<dyn Error>>
where Complex<T>: EvaluationDomain {
    let started = Instant::now();
    let base = base_input(fixture)?;
    let mut settings = ReductionSettings::new(6, 0);
    settings.algorithm = Algorithm::PassarinoVeltman;
    let mut record = json!({
        "schema_version": 1, "status": "preparing_exact_input_jets", "domain": domain,
        "interface": "private exact-qualified ThinSix; capture-only helper module",
        "settings": settings, "working_bits": prototype.get_precision(), "requested_bits": 53,
        "mode": if dual { "dynamic_mixed_second_dual" } else { "ordinary_primal" },
        "fixture": fixture.to_string_lossy(), "calls": [],
        "limits": "Retained scalar N6 only; two formal variables sample one coherent physical dilation, not arbitrary independent mass/invariant derivatives. Child sensitivity imports remain primal-only; successful scale-jet identities do not certify requested-53 derivative error propagation. Public new_dual stays deferred. No achieved-error enclosure or performance claim.",
    });
    write(output, &record)?;
    let profiles = [ScaleProfile::Affine, ScaleProfile::Product, ScaleProfile::Constant];
    let jets: Vec<PreparedJets> = profiles.into_iter().map(|profile| jet_inputs::prepare(&base, profile))
        .collect::<Result<_, _>>().map_err(|error| format!("exact input preparation: {error}"))?;
    let shape = jets[0].shape.clone();
    if jets.iter().any(|row| row.shape != shape || row.input.len() != 31 * shape.len()
                      || row.expected.len() != shape.len()) {
        return Err("exact jet helper returned inconsistent layout".into());
    }
    let components = if dual { shape.len() } else { 1 };
    let mut rows = Vec::new();
    for jet in &jets {
        let exact: Vec<_> = if dual { jet.input.clone() }
            else { jet.input.chunks_exact(shape.len()).map(|x| x[0].clone()).collect() };
        let mut row = Vec::with_capacity(exact.len());
        for x in &exact {
            let converted = prototype.from_rational(x);
            if converted.exact_rational().as_ref() != Some(x) {
                return Err("probe input is not exactly represented at the selected precision".into());
            }
            row.push(Complex::new(converted, prototype.zero()));
        }
        rows.push(row);
    }
    let mut invalid = rows[0].clone();
    for value in &mut invalid[30 * components..31 * components] {
        *value = Complex::new(prototype.zero(), prototype.zero());
    }
    rows.push(invalid);
    record["components"] = json!(components);
    record["ordered_shape"] = if dual { json!(shape) } else { Value::Null };
    record["profiles"] = json!(["affine", "product", "constant", "invalid_mu_zero"]);
    record["exact_homogeneity_multipliers"] = json!(jets.iter().map(|row|
        row.expected.iter().map(ToString::to_string).collect::<Vec<_>>()).collect::<Vec<_>>());
    record["represented_input_rows"] = json!(rows.iter().map(|row| represented(row)).collect::<Vec<_>>());
    record["status"] = json!("preparing_structural_plan");
    write(output, &record)?;
    let plan = match ThinSixReductionPlan::new(settings) {
        Ok(plan) => plan,
        Err(error) => { record["status"] = json!("plan_preparation_failed"); record["error"] = json!(error.to_string());
            record["elapsed_seconds"] = json!(started.elapsed().as_secs_f64()); write(output, &record)?; return Ok(2); }
    };
    record["basis"] = json!(plan.basis().iter().map(|m| m.0).collect::<Vec<_>>());
    record["status"] = json!("preparing_workspace");
    write(output, &record)?;
    let workspace = if dual {
        ThinSixWorkspace::new_dual(&plan, prototype.clone(), HyperDual::<u8>::new(shape.clone()))
    } else { ThinSixWorkspace::new(&plan, prototype.clone()) };
    let mut workspace = match workspace {
        Ok(workspace) => workspace,
        Err(error) => { record["status"] = json!("workspace_preparation_failed"); record["error"] = json!(error.to_string());
            record["elapsed_seconds"] = json!(started.elapsed().as_secs_f64()); write(output, &record)?; return Ok(2); }
    };
    workspace.set_accuracy_precision(53)?;
    let schedule: [(&str, &[usize]); 5] = [
        ("singleton_affine", &[0]), ("mixed", &[0, 3, 1, 2, 0]),
        ("reordered", &[2, 1, 0, 3, 0]), ("empty", &[]), ("singleton_again", &[0]),
    ];
    let mut successful = 0usize;
    let mut rejected = 0usize;
    let mut intended_successes = 0usize;
    let mut invalid_rejections = 0usize;
    let mut unexpected_outcomes = Vec::new();
    for (name, indices) in schedule {
        record["status"] = json!("evaluating_batch"); record["active_call"] = json!(name);
        write(output, &record)?;
        let input = KinematicsBatch { rows: indices.len(), components,
            values: indices.iter().flat_map(|&index| rows[index].iter().cloned()).collect() };
        let before = represented(&input.values);
        let result = workspace.reduce_batch(&input);
        let stats = workspace.last_execution();
        let work = json!({"parent_input_rows": stats.parent_input_rows,
            "child_batch_calls": stats.child_batch_calls, "packed_child_rows": stats.packed_child_rows,
            "parent_batch_calls": stats.parent_batch_calls, "packed_parent_rows": stats.packed_parent_rows,
            "child_execution": execution(stats.child_execution),
            "parent_execution": execution(stats.parent_execution),
            "child_certificate_execution": certificate(stats.child_certificate_execution),
            "parent_certificate_execution": certificate(stats.parent_certificate_execution)});
        let mut call = json!({"name": name, "profile_indices": indices,
                             "execution": work, "diagnostics": workspace.last_diagnostics(),
                             "input_preserved_exactly": before == represented(&input.values)});
        match result {
            Ok(result) => {
                let mut lanes = Vec::new();
                for row in 0..indices.len() {
                    let values = match result.lane(row) {
                        Ok(values) => { successful += 1; Some(represented(values)) },
                        Err(_) => { rejected += 1; None },
                    };
                    let expected_outcome = if indices[row] == 3 {
                        let correct = values.is_none() && matches!(result.statuses[row], LaneStatus::InvalidInput(_));
                        if correct { invalid_rejections += 1; }
                        correct
                    } else {
                        let correct = values.is_some() && matches!(result.statuses[row], LaneStatus::Success);
                        if correct { intended_successes += 1; }
                        correct
                    };
                    if !expected_outcome {
                        unexpected_outcomes.push(json!({"call": name, "row": row,
                            "profile": indices[row], "status": format!("{:?}", result.statuses[row])}));
                    }
                    lanes.push(json!({"row": row, "profile": indices[row],
                        "status": format!("{:?}", result.statuses[row]), "values": values,
                        "fallback_used": result.fallback_used[row], "analytic_used": result.analytic_used[row]}));
                }
                call["status"] = json!("captured"); call["lanes"] = json!(lanes);
                call["components"] = json!(result.components);
                call["basis"] = json!(result.basis.iter().map(|m| m.0).collect::<Vec<_>>());
                call["metadata"] = json!({"convention": result.metadata().convention(),
                    "tensor_weights": result.metadata().tensor_weights(), "dual_shape": result.metadata().dual_shape()});
            }
            Err(error) => {
                call["status"] = json!("batch_error"); call["error"] = json!(error.to_string());
                record["calls"].as_array_mut().unwrap().push(call);
                record["status"] = json!("batch_error"); record["elapsed_seconds"] = json!(started.elapsed().as_secs_f64());
                write(output, &record)?; return Ok(2);
            }
        }
        record["calls"].as_array_mut().unwrap().push(call);
        write(output, &record)?;
    }
    record["status"] = json!("capture_complete_not_yet_qualified");
    record["successful_lanes"] = json!(successful); record["rejected_lanes"] = json!(rejected);
    record["intended_successes_available"] = json!(intended_successes == 10);
    record["expected_invalid_rejections_confirmed"] = json!(invalid_rejections == 2);
    record["unexpected_outcomes"] = json!(unexpected_outcomes);
    record["elapsed_seconds"] = json!(started.elapsed().as_secs_f64());
    write(output, &record)?;
    Ok(0)
}

pub fn run() -> Result<u8, Box<dyn Error>> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() != 4 { return Err("probe domain fixture.json output.json".into()); }
    let fixture = Path::new(&args[2]); let output = Path::new(&args[3]);
    if output.exists() { return Err("refusing to overwrite a capture".into()); }
    match args[1].as_str() {
        "f64" => capture("f64", 0f64, false, fixture, output),
        "DoubleFloat" => capture("DoubleFloat", DoubleFloat::from(0f64), false, fixture, output),
        "Float128Dual" => capture("Float128", Float::new(128), true, fixture, output),
        "Float256Dual" => capture("Float256", Float::new(256), true, fixture, output),
        _ => Err("unsupported fixed probe domain".into()),
    }
}
