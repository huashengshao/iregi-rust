//! Exact input jets for one physical N6 scalar dilation with two formal
//! variables. This does not sample arbitrary independent mass derivatives.
//!
//! Parameter order is 24 Cartesian shift components, six real squared masses,
//! and the scale mu. Shifts and mu scale by lambda; squared masses scale by
//! lambda^2. The retained UV/IR-finite D=4 scalar hexagon has mass dimension -8, so its
//! expected finite-part Taylor coefficients are the base value times lambda^-8.
//! Input generation and the independent expected-coefficient calculation use
//! separate Symbolica routes. No floating-point conversion occurs in this file.

use symbolica::{
    atom::{Atom, AtomCore},
    domains::{
        dual::{DualNumberStructure, HyperDual},
        float::Complex,
        integer::Integer,
        rational::{Rational, Q},
    },
    evaluate::{Dualizer, ExpressionEvaluator},
};

pub const PARAMETERS: usize = 31;
pub const COMPONENTS: usize = 6;
pub const SHAPE: [[usize; 2]; COMPONENTS] = [
    [0, 0], [1, 0], [0, 1], [2, 0], [1, 1], [0, 2],
];
pub const X_ALIAS: &str = "iregi_validation::numeric_types_dilation_x";
pub const Y_ALIAS: &str = "iregi_validation::numeric_types_dilation_y";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ScaleProfile {
    /// lambda = 1 + a*x + b*y.
    Affine,
    /// lambda = (1 + a*x)*(1 + b*y).
    Product,
    /// lambda = 1; all non-primal input and expected components vanish.
    Constant,
}

#[derive(Clone, Debug)]
pub struct PreparedJets {
    /// Parameter-major, then the six ordered Taylor components. Length 186.
    pub input: Vec<Rational>,
    /// Six ordered Taylor coefficients of lambda^-8, before multiplying by
    /// an independently evaluated base hexagon finite value.
    pub expected: Vec<Rational>,
    /// Complete ordered Taylor shape, distinct from batch lanes.
    pub shape: Vec<Vec<usize>>,
}

pub fn prepare(base: &[Rational], profile: ScaleProfile) -> Result<PreparedJets, String> {
    if base.len() != PARAMETERS {
        return Err(format!("expected {PARAMETERS} exact real parameters, received {}", base.len()));
    }
    let x_symbol = symbolica::symbol!(X_ALIAS);
    let y_symbol = symbolica::symbol!(Y_ALIAS);
    let x = Atom::var(x_symbol);
    let y = Atom::var(y_symbol);
    // a=(2^60+1)/2^60 is deliberately distinguishable from one beyond 53 bits.
    let a = Rational::from((
        Integer::from(1_152_921_504_606_846_977_i64),
        Integer::from(1_152_921_504_606_846_976_i64),
    ));
    let b = Rational::from((3, 2));
    let ax = Atom::num(a) * &x;
    let by = Atom::num(b) * &y;
    let lambda = match profile {
        ScaleProfile::Affine => Atom::num(1) + &ax + &by,
        ScaleProfile::Product => (Atom::num(1) + &ax) * (Atom::num(1) + &by),
        ScaleProfile::Constant => Atom::num(1),
    };
    let lambda_squared = lambda.pow(2);
    let expressions: Vec<_> = base.iter().enumerate().map(|(parameter, value)| {
        let scale = if (24..30).contains(&parameter) { &lambda_squared } else { &lambda };
        Atom::num(value.clone()) * scale
    }).collect();
    let variables = [x, y];
    let shape: Vec<Vec<usize>> = SHAPE.iter().map(|component| component.to_vec()).collect();
    let dual = HyperDual::<Complex<Rational>>::new(shape.clone());
    let reported_shape: Vec<Vec<usize>> = dual.get_shape().iter().map(|component| component.to_vec()).collect();
    if reported_shape != shape || dual.get_len() != COMPONENTS {
        return Err("Symbolica did not preserve the complete ordered Taylor shape".into());
    }
    let exact: ExpressionEvaluator<Complex<Rational>> = Atom::evaluator_multiple(&expressions, &variables)
        .direct_translation(true).cores(1).horner_iterations(0).build()
        .map_err(|error| format!("input evaluator preparation: {error}"))?;
    let mut evaluator = exact.vectorize(&Dualizer::new(dual, vec![]))
        .map_err(|error| format!("input Dualizer preparation: {error}"))?
        .map_to_ring(&Q).map_err(|error| format!("input rational evaluator preparation: {error}"))?;
    let mut seeds = vec![Rational::from(0); 2 * COMPONENTS];
    seeds[1] = Rational::from(1);              // x, component [1,0].
    seeds[COMPONENTS + 2] = Rational::from(1); // y, component [0,1].
    let mut input = vec![Rational::from(0); PARAMETERS * COMPONENTS];
    evaluator.evaluate_in_ring(&seeds, &mut input, &Q);
    if input.chunks_exact(COMPONENTS).zip(base).any(|(jet, value)| &jet[0] != value) {
        return Err("input dilation changed a primal base parameter".into());
    }

    // Independent route: ordinary symbolic differentiation, followed by one
    // non-Dual evaluation at x=y=0. These are Taylor coefficients, so only the
    // pure second derivatives carry 1/2; the [1,1] component carries no factor.
    let response = lambda.pow(-8);
    let dx = response.derivative(x_symbol);
    let dy = response.derivative(y_symbol);
    let derivative_roots = [
        response,
        dx.clone(),
        dy.clone(),
        dx.derivative(x_symbol) / Atom::num(2),
        dx.derivative(y_symbol),
        dy.derivative(y_symbol) / Atom::num(2),
    ];
    let exact_expected: ExpressionEvaluator<Complex<Rational>> =
        Atom::evaluator_multiple(&derivative_roots, &variables)
            .direct_translation(true).cores(1).horner_iterations(0).build()
            .map_err(|error| format!("expected derivative evaluator preparation: {error}"))?;
    let mut expected_evaluator = exact_expected.map_to_ring(&Q)
        .map_err(|error| format!("expected rational evaluator preparation: {error}"))?;
    let mut expected = vec![Rational::from(0); COMPONENTS];
    expected_evaluator.evaluate_in_ring(
        &[Rational::from(0), Rational::from(0)], &mut expected, &Q,
    );
    if expected[0] != Rational::from(1) {
        return Err("dilation response does not have unit primal".into());
    }
    if profile == ScaleProfile::Constant {
        if input.chunks_exact(COMPONENTS).any(|jet| jet[1..].iter().any(|value| *value != Rational::from(0)))
            || expected[1..].iter().any(|value| *value != Rational::from(0)) {
            return Err("constant dilation produced a nonzero derivative component".into());
        }
    }
    Ok(PreparedJets { input, expected, shape })
}
