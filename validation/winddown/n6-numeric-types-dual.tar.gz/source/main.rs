fn main() {
    match candidate::highpoint_numeric_probe::run() {
        Ok(code) => std::process::exit(i32::from(code)),
        Err(error) => { eprintln!("capture error: {error}"); std::process::exit(2); }
    }
}
