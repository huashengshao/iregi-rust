"""Freeze a separate four-step codegen proposal without launching rustc."""
from pathlib import Path
import datetime
import json
import build_codegen as build

PROJECT = Path.cwd()
HERE = PROJECT / "target/native-f64-sixpoint-port/qualification"

def save_new(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")

def main():
    prep_path = HERE / "preparation.json"
    receipt_path = HERE / "metadata-build-001/build.json"
    audit_path = HERE / "reviews/metadata-build-001-independent-evidence-review.json"
    original = build.read(prep_path)
    receipt = build.read(receipt_path)
    audit = build.read(audit_path)
    assert build.sha(prep_path) == "b235130e0c74f558ebacf808ba6836bb4b16a72a272abf49e43a9dc85282a412"
    assert build.sha(receipt_path) == "29d1fe874e3644c2435acf5020357426d1be1a3052baae44a9a1dca92f73cdc8"
    assert receipt["status"] == "passed" and receipt["inputs_unchanged"] is True
    assert receipt["cleanup_errors"] == [] and receipt["deadline_exceeded"] is False
    assert len(receipt["steps"]) == 8 and all(step["status"] == "passed" for step in receipt["steps"])
    assert build.sha(audit_path) == "cc494cca16a30f787a47d32c7d80983664db07c7bada255032a6ab8574737ab7"
    assert audit["status"] == "saved-evidence-audit-passed", "independent metadata audit required"
    inputs = dict(receipt["input_sha256"])
    for step in receipt["steps"]:
        assert step["returncode"] == 0 and step["owned_group_gone"] is True
        inputs[step["output"]] = step["output_sha256"]
    for path, digest in receipt["compiler_logs_sha256"].items():
        inputs[path] = digest
    for path in [prep_path, receipt_path, audit_path, HERE / "build_codegen.py", HERE / "codegen-protocol.md",
                 HERE / "codegen-runner-vs-metadata.patch", Path(__file__).resolve()]:
        digest = build.sha(path)
        assert str(path) not in inputs or inputs[str(path)] == digest
        inputs[str(path)] = digest
    for path, digest in inputs.items():
        assert build.sha(path) == digest, path
    manifest = {key: original[key] for key in ("tools", "dependency_directory", "supplemental_directory", "native_directory", "externs", "dependency_scope", "compiled_source_mapping", "fixtures", "reused_masters", "reuse_caveat")}
    manifest.update(status="codegen-source-and-commands-frozen-no-compiler-invoked",
                    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    scope={"metadata_only": False, "configurations": ["default", "selective"],
                           "expected_invocations": 4, "per_invocation_seconds": 90, "aggregate_seconds": 180,
                           "cleanup_reserve_seconds": 8, "compile_cpus": [6, 7], "runtime": False,
                           "cargo": False, "dependency_or_master_rebuild": False, "production_mutations": False,
                           "stop_on_first_failure": True, "later_stages_separately_granted": True})
    steps = build.recipe(HERE / "codegen-build-001", manifest)
    assert [step["label"] for step in steps] == ["default-core", "default-core-tests", "selective-core", "selective-core-tests"]
    for step in steps:
        command = step["command"]
        assert "--emit" not in command and command[command.index("-c") + 1] == "6,7"
        assert step["timeout_seconds"] == 90
        assert step["reused_masters_sha256"] == original["reused_masters"][step["configuration"]]["sha256"]
    save_new(HERE / "codegen-command-plan.json", {"status": "commands-only-not-executed", "scope": manifest["scope"], "steps": steps})
    inputs[str(HERE / "codegen-command-plan.json")] = build.sha(HERE / "codegen-command-plan.json")
    manifest["input_sha256"] = inputs
    save_new(HERE / "codegen-preparation.json", manifest)
    print(json.dumps({"status": manifest["status"], "bound_inputs": len(inputs),
                      "preparation_sha256": build.sha(HERE / "codegen-preparation.json"),
                      "command_plan_sha256": build.sha(HERE / "codegen-command-plan.json"),
                      "runner_sha256": build.sha(HERE / "build_codegen.py")}))

if __name__ == "__main__":
    main()
