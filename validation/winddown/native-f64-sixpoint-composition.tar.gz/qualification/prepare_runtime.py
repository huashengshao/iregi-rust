"""Freeze the 27-test inventory and two proposed cohorts; execute no binary."""
from pathlib import Path
import datetime
import json
import re
from build_metadata import read, sha
import runtime_inventory as inventory

HERE = Path.cwd() / "target/native-f64-sixpoint-port/qualification"

def save_new(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")

def main():
    prep_path = HERE / "codegen-preparation.json"
    build_path = HERE / "codegen-build-001/build.json"
    audit_path = HERE / "reviews/codegen-build-001-independent-evidence-review.json"
    assert sha(prep_path) == "288289e99d45416e9a1e98c1d54928ea3d4126094277f109c5ed4705614bf1fb"
    assert sha(build_path) == "d7a6d201da1cc3237b15eebb92c170782a4f73a82832869a87fd6943f2e91e32"
    assert sha(audit_path) == "ea8dc9aed0b615747f15e86dfe97d6686d4435b32ac62444465afbe25fe7b807"
    original = read(prep_path)
    build = read(build_path)
    audit = read(audit_path)
    assert build["status"] == "passed" and build["inputs_unchanged"] is True
    assert build["cleanup_errors"] == [] and build["deadline_exceeded"] is False
    assert audit["status"] == "saved-evidence-audit-passed"
    assert len(build["steps"]) == 4 and all(step["status"] == "passed" for step in build["steps"])
    all_cases = inventory.cases()
    for case in all_cases:
        source = HERE / "public-source" / case["source"]
        short = case["name"].rsplit("::", 1)[-1]
        assert len(re.findall(r"\bfn\s+" + re.escape(short) + r"\s*\(", source.read_text())) == 1, case["name"]
    save_new(HERE / "runtime-inventory.json", {
        "status": "source-inventory-not-executed", "total_cases": 27, "groups": inventory.GROUPS,
        "cases": all_cases, "module_cfg_review": "Static source inventory; compiled listings must independently match before any selected test runs.",
        "inventory_source_sha256": sha(HERE / "runtime_inventory.py"),
    })
    bindings = dict(build["input_sha256"])
    for artifact in build["outputs"].values():
        bindings[artifact["path"]] = artifact["sha256"]
    for path, digest in build["compiler_logs_sha256"].items():
        bindings[path] = digest
    for path in [prep_path, build_path, audit_path, HERE / "runtime_inventory.py", HERE / "runtime-inventory.json",
                 HERE / "runtime-protocol.md", HERE / "run_policy_tests.py", Path(__file__).resolve()]:
        digest = sha(path)
        assert str(path) not in bindings or bindings[str(path)] == digest
        bindings[str(path)] = digest
    for path, digest in bindings.items():
        assert sha(path) == digest, path
    manifest = {key: original[key] for key in ("tools", "compiled_source_mapping", "fixtures", "reused_masters", "reuse_caveat")}
    manifest.update(status="test-inventory-and-commands-frozen-no-executable-invoked",
                    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    groups=inventory.GROUPS, runtime_cpu=22, cleanup_reserve_seconds=8,
                    scope={"test_cases": 27, "groups_separately_granted": True, "builds": False,
                           "cargo": False, "production_mutations": False, "performance": False,
                           "stop_on_first_failure": True, "retry_or_extension": False},
                    test_binaries={configuration: build["outputs"][configuration + "-core-tests"]
                                   for configuration in ("default", "selective")})
    plans = {group: inventory.plan(group, HERE / (group + "-tests-001"), manifest) for group in inventory.GROUPS}
    assert sum(len(plan["cases"]) for plan in plans.values()) == 27
    assert all(len(plan["listings"]) == 2 for plan in plans.values())
    save_new(HERE / "runtime-command-plan.json", plans)
    bindings[str(HERE / "runtime-command-plan.json")] = sha(HERE / "runtime-command-plan.json")
    manifest["input_sha256"] = bindings
    save_new(HERE / "runtime-preparation.json", manifest)
    print(json.dumps({"status": manifest["status"], "bound_inputs": len(bindings),
                      "preparation_sha256": sha(HERE / "runtime-preparation.json"),
                      "command_plan_sha256": sha(HERE / "runtime-command-plan.json"),
                      "inventory_sha256": sha(HERE / "runtime-inventory.json"),
                      "runner_sha256": sha(HERE / "run_policy_tests.py")}))

if __name__ == "__main__":
    main()
