"""Freeze source copies, artifact reuse proof and commands; launch no compiler."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil

PROJECT = Path.cwd()
HERE = PROJECT / "target/native-f64-sixpoint-port/qualification"
PORT = HERE.parent
PRIOR = PROJECT / "target/native-f64-opt-in/qualification"
LIFECYCLE = "c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824"

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def save_new(path, value):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")

def main():
    assert not (HERE / "preparation.json").exists()
    assert not (HERE / "command-plan.json").exists()
    assert sha(PRIOR / "lifecycle.py") == LIFECYCLE
    if not (HERE / "lifecycle.py").exists():
        shutil.copy2(PRIOR / "lifecycle.py", HERE / "lifecycle.py")
    assert sha(HERE / "lifecycle.py") == LIFECYCLE
    import build_metadata as builder

    source = read(PORT / "source-inventory.json")
    assert source["status"] == "source-only-not-compiled-or-executed"
    assert sha(PORT / "source-inventory.json") == "afa2b63a2cf335f19ba91173b2ca9a39c04f8e52dc56ea96995310e2aa7b7ece"
    assert sha(PORT / "combined.patch") == source["combined_patch_sha256"]
    original = read(PRIOR / "preparation.json")
    public = read(PRIOR / "public-build-001/build.json")
    compatibility = read(PRIOR / "compatibility-preparation.json")
    compatibility_build = read(PRIOR / "compatibility-build-001/build.json")
    completion = read(PRIOR / "compatibility-completion-preparation.json")
    completion_build = read(PRIOR / "compatibility-completion-build-001/build.json")
    assert public["status"] == "passed" and public["inputs_unchanged"] is True
    assert compatibility_build["status"] == "failed" and compatibility_build["inputs_unchanged"] is False
    assert completion_build["status"] == "passed" and completion_build["inputs_unchanged"] is True
    bindings = {}
    for manifest in (original, compatibility, completion):
        for path, digest in manifest["input_sha256"].items():
            assert path not in bindings or bindings[path] == digest, path
            bindings[path] = digest

    copied = HERE / "public-source"
    copied.mkdir(exist_ok=False)
    for directory, mapping in [(PORT / "base", source["base"]), (PORT / "proposed", source["proposed"])]:
        for relative, digest in mapping.items():
            path = directory / relative
            assert sha(path) == digest, str(path)
            bindings[str(path)] = digest
    for relative, digest in source["proposed"].items():
        path = copied / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(PORT / "proposed" / relative, path)
        assert sha(path) == digest
        bindings[str(path)] = digest
    for relative, digest in original["fixtures"].items():
        path = copied / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        old = PRIOR / "public-source" / relative
        assert sha(old) == digest
        shutil.copy2(old, path)
        bindings[str(path)] = digest

    masters = {path: digest for path, digest in source["proposed"].items() if path.startswith("crates/iregi-masters/")}
    assert len(masters) == 30
    reused = {}
    for configuration, receipt, prep, flags in [
        ("default", public, original, ['feature="default"']),
        ("selective", public, original, ['feature="default"', 'feature="native-f64-abc"']),
        ("broad", compatibility_build, compatibility, ['feature="default"', 'feature="native-batch"']),
        ("both", compatibility_build, compatibility, ['feature="default"', 'feature="native-batch"', 'feature="native-f64-abc"']),
    ]:
        for path, digest in masters.items():
            assert prep["compiled_source_mapping"][path] == digest, (configuration, path)
            assert sha(PRIOR / "public-source" / path) == digest
        step = next(step for step in receipt["steps"] if step["label"] == configuration + "-masters")
        assert step["status"] == "passed" and step["returncode"] == 0 and step["owned_group_gone"] is True
        command = step["command"]
        assert [command[i + 1] for i, token in enumerate(command) if token == "--cfg"] == flags
        assert str(PRIOR / "public-source/crates/iregi-masters/src/lib.rs") in command
        assert original["tools"]["rustc"]["path"] in command
        assert "opt-level=0" in command
        assert f'linker={original["tools"]["cc"]["path"]}' in command
        assert step["environment"]["CARGO_MANIFEST_DIR"] == str(PRIOR / "public-source/crates/iregi-masters")
        artifact = Path(step["output"])
        assert sha(artifact) == step["output_sha256"]
        bindings[str(artifact)] = step["output_sha256"]
        reused[configuration] = {"path": str(artifact), "sha256": step["output_sha256"],
                                 "cfg": flags, "original_step": step["label"],
                                 "original_command": command, "original_environment": step["environment"],
                                 "source_files": masters, "original_aggregate_status": receipt["status"],
                                 "original_final_guard": receipt["inputs_unchanged"]}

    records = [
        PRIOR / "preparation.json", PRIOR / "public-command-plan.json", PRIOR / "public-build-001/build.json",
        PRIOR / "compatibility-preparation.json", PRIOR / "compatibility-command-plan.json",
        PRIOR / "compatibility-build-001/build.json", PRIOR / "reviews/compatibility-build-001-independent-audit.json",
        PRIOR / "compatibility-completion-preparation.json", PRIOR / "compatibility-completion-build-001/build.json",
        PRIOR / "reviews/compatibility-completion-build-001-independent-audit.json",
        PROJECT / "validation/native-f64-opt-in/compatibility-v1/qualification.json",
        PROJECT / "validation/native-f64-opt-in/compatibility-v1/manifest.json",
        PROJECT / "validation/native-f64-opt-in/compatibility-completion-v1/qualification.json",
        PROJECT / "validation/native-f64-opt-in/compatibility-completion-v1/manifest.json",
        PORT / "source-inventory.json", PORT / "mechanical-checks.json", PORT / "base-manifest.json",
        PORT / "combined.patch", PORT / "doc-refresh.json", PORT / "patch-check.json",
        PORT / "preparation-attempt-001.json", PORT / "qualification-proposal.md",
        PORT / "reviews/independent-source-review.json", PORT / "reviews/qualification-proposal-source-review.json",
        HERE / "build_metadata.py", HERE / "lifecycle.py", HERE / "protocol.md", Path(__file__).resolve(),
    ]
    for path in records:
        digest = sha(path)
        assert str(path) not in bindings or bindings[str(path)] == digest, str(path)
        bindings[str(path)] = digest
    for path, digest in bindings.items():
        assert sha(path) == digest, path

    manifest = {key: original[key] for key in ("tools", "dependency_directory", "supplemental_directory", "native_directory", "externs", "dependency_scope")}
    manifest.update(
        status="source-and-commands-frozen-no-compiler-invoked",
        created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope={"metadata_only": True, "configurations": ["default", "selective", "broad", "both"],
               "expected_invocations": 8, "per_invocation_seconds": 60, "aggregate_seconds": 180,
               "cleanup_reserve_seconds": 8, "compile_cpus": [6, 7], "runtime": False,
               "cargo": False, "dependency_or_master_rebuild": False, "production_mutations": False,
               "stop_on_first_failure": True, "later_stages_separately_granted": True},
        compiled_source_mapping=source["proposed"], fixtures=original["fixtures"], reused_masters=reused,
        reuse_caveat="Broad/combined masters steps individually passed; their original aggregate final guard is false and remains false. Separate independent rehash and completion are bound, plus fresh artifact/source/context verification here.",
    )
    steps = builder.recipe(HERE / "metadata-build-001", manifest)
    assert [step["label"] for step in steps] == [configuration + suffix for configuration in ("default", "selective", "broad", "both") for suffix in ("-core", "-core-tests")]
    for step in steps:
        command = step["command"]
        assert command[command.index("--emit") + 1] == "metadata"
        assert command[command.index("-c") + 1] == "6,7"
        assert step["timeout_seconds"] == 60 and Path(step["output"]).suffix == ".rmeta"
        assert not any("iregi-masters/src/lib.rs" in item for item in command)
    save_new(HERE / "command-plan.json", {"status": "commands-only-not-executed", "scope": manifest["scope"], "steps": steps})
    bindings[str(HERE / "command-plan.json")] = sha(HERE / "command-plan.json")
    manifest["input_sha256"] = bindings
    save_new(HERE / "preparation.json", manifest)
    print(json.dumps({"status": manifest["status"], "bound_inputs": len(bindings),
                      "preparation_sha256": sha(HERE / "preparation.json"),
                      "command_plan_sha256": sha(HERE / "command-plan.json"),
                      "runner_sha256": sha(HERE / "build_metadata.py"),
                      "lifecycle_sha256": sha(HERE / "lifecycle.py")}))

if __name__ == "__main__":
    main()
