"""Source-only mechanical inventory; no compiler, Cargo, kernel, or live write."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent.parent
BASE = ROOT / "base"
PROPOSED = ROOT / "proposed"
PRIOR = PROJECT / "target/native-f64-opt-in/proposed"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inventory(directory):
    return {str(path.relative_to(directory)): sha(path)
            for path in sorted(directory.rglob("*")) if path.is_file()}

def text(directory, path):
    return (directory / path).read_text()

def section(source, start, end=None):
    value = source[source.index(start):]
    return value if end is None else value[:value.index(end)]

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

base = inventory(BASE)
candidate = inventory(PROPOSED)
assert len(base) == 80
assert set(base) <= set(candidate)
lineage = json.loads((ROOT / "base-manifest.json").read_text())
refresh = json.loads((ROOT / "doc-refresh.json").read_text())
assert sha(ROOT / "base-manifest.json") == refresh["original_base_manifest_sha256"]
assert refresh["original_base_manifest_sha256"] == "c1fbd724590b4ff6914a9f26923cd6078a2d6c85a0854aca7b1dc75e447a7952"
assert base[refresh["path"]] == refresh["after_sha256"]
assert sha(ROOT / "lineage/six_point-before-doc-refresh.rs") == refresh["before_sha256"]
base_live_matches = {path: sha(PROJECT / path) == value for path, value in base.items()}
assert all(base_live_matches.values()), "live source differs from refreshed snapshot; do not overwrite"

exact_prior = [entry["path"] for entry in lineage["initial_merge"]
               if entry["status"] in ("exact-qualified-file", "new-exact-qualified-file")]
for path in exact_prior:
    assert (PROPOSED / path).read_bytes() == (PRIOR / path).read_bytes(), path
masters_prior = {path: value for path, value in candidate.items() if path.startswith("crates/iregi-masters/")}
assert all((PROPOSED / path).read_bytes() == (PRIOR / path).read_bytes() for path in masters_prior)

execution = "crates/iregi-rust/src/execution.rs"
b = text(BASE, execution)
p = text(PROPOSED, execution)
policy_start = "/// Immutable execution-only options."
policy_end = "/// Work performed by the last batch"
assert section(b, policy_start, policy_end) == section(p, policy_start, policy_end)
tail = section(p, "    pub fn component_count(&self)")
old_call = "Self::prepare(&plan, self.prototype.clone(), layout.as_ref(), self.policy)"
new_call = "Self::prepare(&plan, self.prototype.clone(), layout.as_ref(), self.policy, self.master_policy)"
assert tail.count(new_call) == 1
assert tail.replace(new_call, old_call) == section(b, "    pub fn component_count(&self)")

planar = "crates/iregi-rust/src/certified_planar.rs"
b = section(text(BASE, planar), "    pub fn component_count(&self)")
p = section(text(PROPOSED, planar), "    pub fn component_count(&self)")
p = p.replace("Workspace::new_with_policies(&plan, self.prototype.clone(), self.policy, self.master_policy)",
              "Workspace::new_with_policy(&plan, self.prototype.clone(), self.policy)")
p = p.replace("Workspace::new_dual_with_policies(", "Workspace::new_dual_with_policy(")
p = p.replace("                self.policy,\n                self.master_policy,\n", "                self.policy,\n")
assert b == p

fallback = "crates/iregi-rust/src/execution/planar_fallback.rs"
marker = "impl<T: NativeFloat> Workspace<T>"
assert section(text(BASE, fallback), marker) == section(text(PROPOSED, fallback), marker)
thin = "crates/iregi-rust/src/thin_n6.rs"
marker = "    pub fn set_accuracy_precision(&mut self,bits:u32)"
assert section(text(BASE, thin), marker) == section(text(PROPOSED, thin), marker)
assert text(PROPOSED, thin).count("WorkspacePolicy::SIX_POINT_CHILD,MasterExecutionPolicy::Symbolica") == 2
assert text(PROPOSED, thin).count("WorkspacePolicy::RETAIN_ENVELOPES,MasterExecutionPolicy::Symbolica") == 2

unchanged_sixpoint = [
    "crates/iregi-rust/src/six_point.rs",
    "crates/iregi-rust/src/execution/policy_tests.rs",
    "crates/iregi-rust/src/certified_planar/mask_tests.rs",
    "crates/iregi-rust/src/thin_n6/generic_tests.rs",
]
assert all(base[path] == candidate[path] for path in unchanged_sixpoint)

changes = []
patch = []
for path, value in candidate.items():
    if base.get(path) == value:
        continue
    exists = path in base
    category = ("exact-prior-qualified" if path in exact_prior else
                "new-composition-tests" if not exists else "combined-core-policy-plumbing")
    changes.append({"path": path, "base_sha256": base.get(path), "proposed_sha256": value, "category": category})
    before = (BASE / path).read_text().splitlines(True) if exists else []
    after = (PROPOSED / path).read_text().splitlines(True)
    patch.append(f"diff --git a/{path} b/{path}\n")
    if not exists:
        patch.append("new file mode 100644\n")
    patch.extend(difflib.unified_diff(before, after, fromfile=f"a/{path}" if exists else "/dev/null", tofile=f"b/{path}"))
(ROOT / "combined.patch").write_text("".join(patch))

tests = []
for path in candidate:
    if "policy_composition_tests.rs" not in path and path != fallback:
        continue
    for line in text(PROPOSED, path).splitlines():
        if line.strip().startswith("fn composition_"):
            tests.append({"path": path, "test": line.strip().split("(")[0][3:]})
assert len(tests) == 7
for path in candidate:
    if path.endswith(".rs"):
        data = text(PROPOSED, path)
        assert not any(line.startswith(("<<<<<<<", "=======", ">>>>>>>")) for line in data.splitlines()), path

save("source-inventory.json", {
    "status": "source-only-not-compiled-or-executed",
    "original_base_manifest_sha256": refresh["original_base_manifest_sha256"],
    "doc_refresh_sha256": sha(ROOT / "doc-refresh.json"),
    "original_preparation_failure_sha256": sha(ROOT / "preparation-attempt-001.json"),
    "base": base, "proposed": candidate, "changed": changes,
    "base_live_matches_at_freeze": base_live_matches,
    "combined_patch_sha256": sha(ROOT / "combined.patch"),
    "freeze_source_sha256": sha(Path(__file__)),
    "new_composition_test_inventory": tests,
    "production_mutations": False, "build_runtime_or_cargo": False,
})
save("mechanical-checks.json", {
    "status": "passed-source-byte-comparisons-only",
    "source_inventory_sha256": sha(ROOT / "source-inventory.json"),
    "exact_prior_qualified_files": {path: candidate[path] for path in exact_prior},
    "entire_masters_crate_byte_identical_to_prior_qualified_candidate": masters_prior,
    "workspace_policy_struct_and_constants_byte_identical": True,
    "execution_evaluation_suffix_identical_except_lazy_master_policy_argument": True,
    "certified_planar_evaluation_suffix_identical_except_constructor_policy_arguments": True,
    "planar_retry_evaluation_stats_diagnostics_suffix_byte_identical": True,
    "thin_six_accuracy_evaluation_stats_diagnostics_suffix_byte_identical": True,
    "four_thin_six_constructor_calls_explicit_symbolica": True,
    "existing_sixpoint_and_policy_tests_byte_identical": unchanged_sixpoint,
    "limitations": ["Not a Rust parse/typecheck", "Not numerical or performance qualification", "Broad feature ThinSix now explicitly selects Symbolica as intended"],
})
print(json.dumps({"base_files": len(base), "candidate_files": len(candidate), "changed_files": len(changes),
                  "exact_prior_files": len(exact_prior), "new_tests": len(tests),
                  "patch_sha256": sha(ROOT / "combined.patch"),
                  "inventory_sha256": sha(ROOT / "source-inventory.json"),
                  "mechanical_sha256": sha(ROOT / "mechanical-checks.json")}, indent=2))
