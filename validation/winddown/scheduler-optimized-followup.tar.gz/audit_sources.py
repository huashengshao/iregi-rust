"""Read-only current/frozen source comparison; no build or numerical work."""
from pathlib import Path
import difflib,hashlib,json,subprocess
ROOT=Path('/shared/external/iregi/iregi-rust');OUT=ROOT/'target/guard-performance-review/optimized-performance-proposal'
assert Path.cwd()==ROOT
S=ROOT/'target/guard-performance-review/dependent-relink-qualification';H=ROOT/'target/guard-performance-review/dependent-chain-proposal'
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert HEAD=='007ca9f7b1f3cd2005e0d4df1fcfb24f55aaecc7'
result={'scope':'Source-only frozen-vs-current audit; no compilers/numerics/timing/live edits','current_git_revision':HEAD,'frozen_source_changes':{},'current_only_rs':{},'current_sha256':{},'frozen_sha256':{}}
for variant in ['baseline','candidate']:
 folder=S/'source'/variant/'symbolica';mapping=read(S/'source-inventory.json')['source_sha256'][variant];changes=[]
 for relative,expected in mapping.items():
  old=folder/relative;new=ROOT/'dependencies/symbolica'/relative;assert sha(old)==expected
  result['current_sha256'][str(new.relative_to(ROOT))]=sha(new);result['frozen_sha256'][str(old.relative_to(ROOT))]=expected
  if sha(new)!=expected:
   changes.append({'path':relative,'frozen_sha256':expected,'current_sha256':sha(new)})
   (OUT/(variant+'-symbolica-'+relative.replace('/','_')+'.patch')).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old.relative_to(ROOT)),tofile=str(new.relative_to(ROOT)))))
 result['frozen_source_changes']['symbolica-'+variant]=changes
 result['current_only_rs']['symbolica-'+variant]=sorted(str(p.relative_to(ROOT/'dependencies/symbolica'))for p in(ROOT/'dependencies/symbolica/src').rglob('*.rs')if str(p.relative_to(ROOT/'dependencies/symbolica'))not in mapping)
inv=read(H/'source-inventory.json');changes=[]
for relative,expected in inv['live_source_sha256'].items():
 old=H/'source'/relative;new=ROOT/relative
 result['current_sha256'][relative]=sha(new);result['frozen_sha256'][str(old.relative_to(ROOT))]=sha(old)
 # private capture hooks are intentionally included in the actual linked source.
 if sha(old)!=sha(new):
  changes.append({'path':relative,'private_sha256':sha(old),'original_live_sha256':expected,'current_sha256':sha(new),'current_matches_original':sha(new)==expected})
  if new.suffix=='.rs':(OUT/('core-'+relative.replace('/','_')+'.patch')).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old.relative_to(ROOT)),tofile=str(new.relative_to(ROOT)))))
result['frozen_source_changes']['oneloop-masters-core']=changes
for root in ['dependencies/oneloopmaster','crates/iregi-masters','crates/iregi-rust']:
 result['current_only_rs'][root]=sorted(str(p.relative_to(ROOT))for p in(ROOT/root/'src').rglob('*.rs')if str(p.relative_to(ROOT))not in inv['live_source_sha256'])
for raw in ['Cargo.toml','Cargo.lock','AGENTS.md','PLAN.md','dependencies/symbolica/IREGI_PROVENANCE.json']:
 result['current_sha256'][raw]=sha(ROOT/raw)
save(OUT/'source-differences.json',result)
print(json.dumps({'current_git_revision':HEAD,'changes':result['frozen_source_changes'],'current_only_rs':result['current_only_rs']}))
