"""Freeze a same-binary exact continuation; no subprocess/Symbolica work."""
import ast
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import common as h


def main():
    h.require(Path.cwd().resolve() == h.ROOT, 'run from project root')
    h.require(not h.PROTOCOL.exists(), 'immutable protocol already exists')
    old_path = h.BUNDLE / 'protocol-env-v3/protocol.json'
    old = h.load(old_path)
    h.require(h.sha(old_path) == '69faa595de7a10af64a98ac0b522d4d1933c26926a69f8282951ce8f6f2b381e',
              'retained reviewed protocol differs')
    build = h.load(h.BUNDLE / 'runs-env-v3/build-001/result.json')
    prior = h.load(h.BUNDLE / 'runs-env-v3/exact-001/result.json')
    h.require(build['status'] == 'passed' and prior['status'] == 'failed'
              and prior['errors'] == ["RuntimeError('cancelled by signal 15')"]
              and prior['all_owned_groups_gone'], 'retained terminal classification differs')
    h.require(prior['completed_cases'] == old['selected_tests'][:9]
              and prior['unrun_cases'] == old['selected_tests'][9:],
              'retained complete/remaining test inventory differs')
    h.require(len(prior['commands']) == 11
              and all(event['status'] == 'exited' and event['returncode'] == 0
                      and event['owned_group_gone'] for event in prior['commands']),
              'previous listing/ten child terminals differ')
    h.require(h.sha(h.BUNDLE / 'runs-env-v3/build-001/tests') == build['binary_sha256']
              == '83a78ded64b7b606ef09dcfcffa60b2b4b058d9263d768e40c6498ac5f60c8ba',
              'retained successful test product differs')
    inputs = dict(old['inputs'])
    h.verify(inputs)
    h.closed_directories(old)
    for relative in [
        'protocol-env-v3/protocol.json', 'protocol-env-v3/source-review.json',
        'protocol-env-v3/grants/build.json', 'protocol-env-v3/grants/exact.json',
        'runs-env-v3/build-001/result.json', 'runs-env-v3/build-001/00-compile-tests.log',
        'runs-env-v3/build-001/tests', 'reviews/build-env-v3-root-independent-audit.json',
        'runs-env-v3/exact-001/result.json',
        'reviews/exact-env-v3-scheduling-abort-local.json']:
        h.bind(h.BUNDLE / relative, inputs)
    for path in sorted((h.BUNDLE / 'runs-env-v3/exact-001').glob('*.log')):
        h.bind(path, inputs)
    for path in sorted((h.BUNDLE / 'protocol-continuation-v4').iterdir()):
        if path.is_file():
            h.bind(path, inputs)
    for name in ['README.md', 'common.py', 'prepare.py', 'run.py', 'lifecycle.py',
                 'runner-diff.patch', 'affinity-diff.patch']:
        h.bind(h.HERE / name, inputs)
        if name.endswith('.py'):
            ast.parse((h.HERE / name).read_text(), filename=name)
    h.require(h.sha(h.HERE / 'lifecycle.py') == h.HELPER_SHA, 'lifecycle helper differs')
    h.require(h.BOUNDS == old['bounds'] and h.CPU['build'] == old['cpu_affinity']['build']
              and h.CPU['exact'] == [8],
              'original fixed bounds or root-selected CPU8 differs')
    selected = old['selected_tests'][9:]
    h.require(len(selected) == 7, 'remaining admission count differs')
    protocol = dict(
        schema_version=1, source_revision=5,
        status='source_frozen_same_binary_continuation_awaiting_review',
        scope='Complete seven remaining admissions of the original16 exact algebra cases after ROOT scheduling cancellation. No rebuild/source/numeric-gate changes, full-core/numerical/performance admission.',
        inputs=inputs, tools=old['tools'], bounds=old['bounds'],
        cpu_affinity=h.CPU, closed_search_directories=old['closed_search_directories'],
        stages=['exact'], selected_tests=selected, selected_case_count=7,
        expected_listing=old['expected_listing'],
        retained_build_protocol_sha256=h.sha(old_path),
        retained_test_binary_sha256=build['binary_sha256'],
        previously_completed_and_guarded=prior['completed_cases'],
        previously_executed_pass_but_postguard_incomplete=[selected[0]],
        previously_truly_unrun=selected[1:],
        complete_gate=old['selected_tests'], complete_gate_count=16,
        scheduling_abort_preserved=True, unexecuted_cpu6_draft_preserved='protocol-continuation-v4',
        affinity_change='ROOT engineering reassignment of only the unstarted seven-case continuation fromCPU6toCPU8; historical nine remainCPU6; not timing evidence',
        environment_additions=old['environment_additions'],
        lifecycle_sha256=h.HELPER_SHA, dependency_context=old['dependency_context'],
        test_domain_trace=old['test_domain_trace'], no_cargo=True,
        no_rebuild=True, no_retry=True, no_automatic_next_stage=True,
        production_sources_changed=False,
        grant_contract='ROOT already explicitly authorized this reviewed later continuation onCPU8 alongside N7captureCPU6; create one technical grants/exact.json binding exact protocol/review/binary/CPU8assignment. Never alter or restart prior exact-001.')
    h.save(h.PROTOCOL, protocol)
    print(dict(status=protocol['status'], inputs=len(inputs), selected_tests=len(selected),
               prior_guarded=len(prior['completed_cases']), protocol_sha256=h.sha(h.PROTOCOL)))


if __name__ == '__main__':
    main()
