# Seven-case same-binary continuation after a scheduling cancellation

ROOT's CPU6 reschedule crossed an already launched N7 regression. The routing
runner was canceled through its supported SIGTERM/lifecycle handling, leaving
the unrelated N7 work untouched. The original `runs-env-v3/exact-001` remains a
failed stage (42.172129s), not a successful sixteen-case gate or algebra failure.
Its nine fully guarded passes remain admitted. A tenth case's child passed,
but cancellation interrupted its postguard; it remains unadmitted. Six later
cases never ran. All eleven owned process groups were checked absent; all 141
input bindings, both closed dependency inventories and source/clone executable
hashes were freshly verified after cancellation.

ROOT explicitly authorized this later seven-case continuation, then reassigned
only its unstarted runtime affinity to **CPU8** so N7 can keep its frozen CPU6
capture recipe. The unexecuted CPU6 continuation draft remains unchanged under
`protocol-continuation-v4`; all nine previously guarded CPU6 passes remain
historical correctness evidence and are not rerun. This is an engineering
affinity change, not a timing measurement. The continuation uses the **same
already built executable**, hash
`83a78ded64b7b606ef09dcfcffa60b2b4b058d9263d768e40c6498ac5f60c8ba`.
No Rust source, dependency, numerical gate, compile flag or requested output is
changed, and no rebuild is permitted. The runner rejects the build stage.

The original bounds are retained: 300s total, 25s postwork reserve,
120s per selected case and 15s listing. A fresh complete39-case listing must
match the original source inventory. Only the remaining seven admissions run,
including the floating-literal case whose previous postguard was interrupted.
Those seven plus the preserved nine guarded passes must cover the exact original
sixteen-case gate. The first failed build and scheduling-aborted exact stage
remain visible regardless of the continuation's outcome.

`runner-diff.patch` shows the small runner delta: exact-only admission, retained
V3 build-result/product paths and matching build-protocol identity, seven-case
completion count. The process-group lifecycle, hashes, postguards, log parsers,
test commands and error behavior are otherwise unchanged. Fresh output is
`runs-continuation-v5-cpu8/exact-001`. `prepare.py` freezes all prior protected inputs,
successful build, saved root audit, aborted commands/logs and local postguard.
Independent review must precede one exact technical grant. No script creates
its own grant or automatically executes the next stage.

`affinity-diff.patch` records the CPU8 assignment, fresh output prefix and
metadata/frozen draft bindings. The runner is byte-identical to the unexecuted
CPU6 continuation runner; it obtains affinity from the frozen common recipe.

This is isolated module algebra qualification using historical compiled
Symbolica archives, not full-core/current-Cargo integration, high-point integral
reference agreement, public generalized/Dual support or a performance benchmark.
