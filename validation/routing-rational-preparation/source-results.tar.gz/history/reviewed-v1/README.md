# Private scalar routing solve proposal

This directory is a **source-only proposal**, not a built crate, benchmark, or
qualified support expansion. Production files are unchanged. Base is main
`2c1f3342e189a20fef3bbf7dd9e0baa372e2b4a2`.

`proposal.patch` changes only `ScalarCompiler::routing_relation` to use a private
`PreparedRoutingSystem` and adds its helper/tests. Recurrences, request/cache
keys, relation ordering, master requests and numerical workspaces are unchanged.
The current core already implements generalized N6/N7 denominator relations;
this proposal changes their exact preparation arithmetic.

The private fast subset is an at-most-5-row/6-column matrix whose entries are
explicit sums of constants and numeric multiples of bare symbols. Exact
rational entries use Symbolica's Q→Z `RationalPolynomialField`; exact Gaussian
entries use its existing complex algebraic coefficient field. The actual
generic N6/N7 scalar compiler supplies linear squared-distance aliases, so it
fits this subset without substituting aliases or numerical values. Larger,
nonlinear, powered, floating or opaque expressions keep the old AtomField path.
RHS entries are restricted to the current caller's literal zeros/ones.

Symbolica owns conversion, all elimination and exact solution checks. The
shared variable map is enforced; a conversion/certificate error returns an
explicit error. Only the same linear-solve failure previously ignored by the
caller permits trying its next homogeneous constraint. No numerical sample
specialization or f64 conversion was added.

`base/` contains the exact original ibp.rs. `core/` contains only the changed
ibp.rs and new helper, **not a full compilable checkout**. `proposal.json` binds
their source hashes and lists eleven new exact tests and three existing routing
tests. Apply the patch only to a separately owned private complete core after a
bounded build/test protocol, dependency/source closure and root authorization
are frozen. No compilation, tests or numerical evaluations have occurred.

The research note and three reuse checks are
`docs/research/highpoint-generalized-resume.md`. FeynKit's extracted
`AffineFamily` helpers have private matrix APIs, so they cannot directly supply
this tiny solve adapter without changing the extraction. The proposal reuses
the same public Symbolica conversion/Matrix operations and the existing private
N7 Q→Z matrix idiom; it does not add another algebra engine.

Independent source review first found an unbounded u16-exponent admission issue
in an earlier draft. The current syntax whitelist, matrix shape bound and
constant RHS restriction address it; a high-degree fallback test retains the
counterexample. The review did not execute the code. Any future source changes
must produce new hashes/review rather than relabel this draft as executed.

First numerical qualification should remain rank-zero ordinary real massive
N6/N7 with a single dot and fixed requested accuracy, then cover homogeneous,
shifted, complex and Dual descendants under separate gates. Generic D6
pentagon leaves remain genuine independent masters. Performance claims require
matched optimized measurements, not source review or test wall time.
