#[path = "core/crates/iregi-rust/src/ibp.rs"]
mod ibp;
