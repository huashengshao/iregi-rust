"""Freeze a private source/build recipe. Never compile or load Symbolica."""
import ast
from pathlib import Path
import re
import sys
sys.dont_write_bytecode = True
import common as h


def main():
    h.require(Path.cwd().resolve() == h.ROOT, 'run from the project root')
    h.require(not h.PROTOCOL.exists(), 'immutable protocol already exists')
    proposal = h.load(h.BUNDLE / 'proposal.json')
    h.require(proposal['base_commit'] == '2c1f3342e189a20fef3bbf7dd9e0baa372e2b4a2',
              'base revision differs')
    h.require(not proposal['production_applied'] and not proposal['builds_or_evaluations_run'],
              'proposal is not source-only')
    inputs = {}
    h.bind(h.BASE_MANIFEST, inputs)
    for item in h.load(h.BASE_MANIFEST)['files']:
        h.bind(h.ROOT / item['frozen'], inputs, item['sha256'])
    closed = {}
    for directory in [h.DEPS, h.NATIVE]:
        actual = sorted(h.key(path) for path in directory.rglob('*') if path.is_file())
        expected = sorted(path for path in inputs if h.absolute(path).is_relative_to(directory))
        h.require(actual == expected, 'frozen historical directory differs: ' + h.key(directory))
        closed[h.key(directory)] = actual
    h.require(h.key(h.SYMBOLICA) in inputs, 'Symbolica archive not in closed historical binding')
    for relative, expected in proposal['source_files'].items():
        h.bind(h.BUNDLE / relative, inputs, expected)
    for relative in ['proposal.json', 'harness.rs']:
        h.bind(h.BUNDLE / relative, inputs)
    for name in ['README.md', 'common.py', 'prepare.py', 'run.py', 'lifecycle.py']:
        h.bind(h.HERE / name, inputs)
        if name.endswith('.py'):
            ast.parse((h.HERE / name).read_text(), filename=name)
    h.require(h.sha(h.HERE / 'lifecycle.py') == h.HELPER_SHA, 'lifecycle helper differs')
    h.bind(h.ROOT / 'docs/research/highpoint-generalized-resume.md', inputs)
    for path in h.TOOLS.values():
        h.bind(path, inputs)
    for relative in ['protocol/protocol.json', 'protocol/source-review.json',
                     'protocol/grants/build.json', 'runs/build-001/result.json',
                     'runs/build-001/00-compile-tests.log',
                     'reviews/build-001-failure.json']:
        h.bind(h.BUNDLE / relative, inputs)
    helper = (h.BUNDLE / 'core/crates/iregi-rust/src/ibp/routing_rational.rs').read_text()
    base = (h.BUNDLE / 'base/crates/iregi-rust/src/ibp.rs').read_text()
    new_tests = re.findall(r'#\[test\]\s+fn\s+(\w+)\(', helper)
    old_tests = re.findall(r'#\[test\]\s+fn\s+(\w+)\(', base)
    h.require(new_tests == proposal['new_tests'] and len(new_tests) == 13,
              'new exact source inventory differs')
    listing = sorted(['ibp::routing_rational::tests::' + name for name in new_tests]
                     + ['ibp::tests::' + name for name in old_tests])
    selected = ['ibp::routing_rational::tests::' + name for name in new_tests]
    selected += proposal['selected_existing_tests']
    h.require(len(selected) == len(set(selected)) == 16 and set(selected) <= set(listing),
              'selected exact cases differ')
    protocol = dict(
        schema_version=1, source_revision=3,
        status='source_only_frozen_awaiting_root_review_and_per_stage_grants',
        scope='Isolated actual ibp.rs module qualification only: real generic aliased N6/N7 routing, preserved quadratic/opaque/Gaussian semantics, exact generalized recurrence source tests. No full-core/Cargo, scalar numerical reference, public support, Dual accuracy or performance admission.',
        source_base=proposal['base_commit'], inputs=inputs,
        previous_attempt='runs/build-001: FAILED48missingCARGO_CRATE_NAME; no executable/tests; ownedPGgone',
        harness_fix='Only compile environment CARGO_CRATE_NAME and fresh runs-env-v3 output paths changed; identical Rust/helper/dependency/bounds/testscope',
        closed_search_directories=closed, tools=h.TOOLS, cpu_affinity=h.CPU,
        bounds=h.BOUNDS, stages=['build', 'exact'], requires=dict(build=[], exact=['build']),
        compile_command=h.compile_command(), selected_tests=selected,
        expected_listing=listing, selected_case_count=16,
        dependency_context='Existing immutable historical e6-direct-n2 native Symbolica/Cargo archive closure, not the later current native-Cargo feature graph. No dependency rebuild; no claim of latest source-patch or performance equivalence.',
        environment_additions=dict(RAYON_NUM_THREADS='1', RUST_TEST_THREADS='1',
                                   OMP_NUM_THREADS='1', SYMBOLICA_HIDE_BANNER='1',
                                   CARGO_CRATE_NAME='routing_rational_qualification'),
        lifecycle_sha256=h.HELPER_SHA, no_cargo=True, no_retries=True,
        no_automatic_next_stage=True, production_sources_changed=False,
        test_domain_trace='cfg(test) thread-local constructor-domain trace only; absent in normal production code',
        grant_contract='A separately created grants/<stage>.json must match stage/protocol_sha256 and admitted=true. Root coordinates CPU/compiler/Symbolica slots; source preparation is not an execution grant.')
    h.save(h.PROTOCOL, protocol)
    print(dict(status=protocol['status'], inputs=len(inputs), selected_tests=len(selected),
               discovered_tests=len(listing), protocol_sha256=h.sha(h.PROTOCOL)))


if __name__ == '__main__':
    main()
