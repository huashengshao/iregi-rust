"""Run exactly one ROOT-granted bounded stage; importing launches no work."""
import os
from pathlib import Path
import re
import sys
import time
sys.dont_write_bytecode = True
import common as h
import lifecycle


def main():
    h.require(Path.cwd().resolve() == h.ROOT, 'run from the project root')
    h.require(len(sys.argv) == 2 and sys.argv[1] in ['build', 'exact'], 'choose one stage')
    stage = sys.argv[1]
    protocol = h.load(h.PROTOCOL)
    grant = h.load(h.HERE / 'grants' / (stage + '.json'))
    h.require(grant.get('admitted') is True and grant.get('stage') == stage
              and grant.get('protocol_sha256') == h.sha(h.PROTOCOL),
              'no exact per-stage ROOT grant')
    h.require(Path(sys.executable).resolve() == Path(h.TOOLS['python']).resolve(),
              'Python interpreter differs')
    h.require(h.sha(h.HERE / 'lifecycle.py') == h.HELPER_SHA, 'lifecycle helper differs')
    if stage == 'exact':
        build = h.load(h.RUNS / 'build-001/result.json')
        h.require(build['status'] == 'passed' and build['protocol_sha256'] == h.sha(h.PROTOCOL),
                  'no passed matching build stage')
        h.require(bool(os.environ.get('SYMBOLICA_LICENSE')), 'Symbolica license not present')
    attempt = h.RUNS / (stage + '-001')
    attempt.mkdir(parents=True, exist_ok=False)
    bounds = protocol['bounds'][stage]
    budget = lifecycle.Budget(bounds['total_seconds'])
    budget.work_deadline = budget.deadline - bounds['reserve_seconds']
    errors = []
    result = dict(stage=stage, status='running', protocol_sha256=h.sha(h.PROTOCOL),
                  start_unix_seconds=time.time(), commands=[], errors=errors,
                  selected_cases=protocol['selected_tests'] if stage == 'exact' else [],
                  completed_cases=[], unrun_cases=protocol['selected_tests'][:] if stage == 'exact' else [],
                  license_present=bool(os.environ.get('SYMBOLICA_LICENSE')))
    h.save(attempt / 'result.json', result)

    def persist():
        h.save(attempt / 'result.json', result)

    def guard():
        h.closed_directories(protocol, budget)
        h.verify(protocol['inputs'], budget)

    def execute(label, command, cap):
        index = len(result['commands'])
        event = dict(label=label, status='preparing')
        result['commands'].append(event)

        def terminal(value):
            event.update(value)
            persist()  # includes the terminal before hashes/parser reads

        event.update(lifecycle.execute(command, attempt / f'{index:02}-{label}.log',
                                      budget, cap, errors, terminal, environment))
        h.require(event['status'] == 'exited', 'owned command failed: ' + label)
        guard()
        return attempt / f'{index:02}-{label}.log'

    environment = os.environ.copy()
    environment.update(protocol['environment_additions'])
    environment['CARGO_MANIFEST_DIR'] = str(h.ROOT / 'crates/iregi-rust')
    try:
        budget.arm()
        guard()
        if stage == 'build':
            execute('compile-tests', protocol['compile_command'], bounds['per_child_seconds'])
            binary = attempt / 'tests'
            budget.remaining()
            result['binary_sha256'] = h.sha(binary)
        else:
            source = h.RUNS / 'build-001/tests'
            binary = lifecycle.freeze_binary(source, build['binary_sha256'],
                                               attempt / 'tests', budget)
            result['binary_sha256'] = build['binary_sha256']
            prefix = [h.TOOLS['taskset'], '-c', ','.join(map(str, h.CPU['exact'])), str(binary)]
            listing_log = execute('listing', prefix + ['--list'], bounds['listing_seconds'])
            names = sorted(line[:-6] for line in listing_log.read_text().splitlines()
                           if line.endswith(': test'))
            h.require(names == protocol['expected_listing'], 'compiled test inventory differs')
            for index, name in enumerate(protocol['selected_tests']):
                log = execute(f'test-{index:02}', prefix + [name, '--exact', '--nocapture',
                              '--test-threads=1'], bounds['per_child_seconds'])
                text = log.read_text()
                h.require(re.search(r'^test ' + re.escape(name) + r' \.\.\. ok$', text, re.M),
                          'named test success missing: ' + name)
                h.require(re.search(r'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured;',
                                    text, re.M), 'exact one-test summary missing: ' + name)
                result['completed_cases'].append(name)
                result['unrun_cases'].remove(name)
                persist()
            h.require(len(result['completed_cases']) == 16, 'selected case count differs')
        guard()
        result['status'] = 'passed'
    except BaseException as error:
        errors.append(repr(error))
        result['status'] = 'failed'
    finally:
        budget.disarm()
        result['elapsed_seconds'] = budget.elapsed()
        result['all_owned_groups_gone'] = all(
            event.get('owned_group_gone') is True for event in result['commands']
            if 'owned_process_group' in event)
        if result['elapsed_seconds'] > bounds['total_seconds'] or errors or not result['all_owned_groups_gone']:
            result['status'] = 'failed'
        persist()
    print(dict(status=result['status'], stage=stage, elapsed_seconds=result['elapsed_seconds'],
               completed_cases=len(result['completed_cases']), errors=errors))
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
