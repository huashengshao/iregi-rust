"""Source-only recipe helpers. Importing this module launches no processes."""
from pathlib import Path
import hashlib
import json

ROOT = Path('/shared/external/iregi/iregi-rust')
HERE = Path(__file__).resolve().parent
BUNDLE = HERE.parent
PROTOCOL = HERE / 'protocol.json'
RUNS = BUNDLE / 'runs-env-v3'
DEPS = ROOT / 'target/e6-direct-n2/deps'
NATIVE = ROOT / 'target/e6-direct-n2/native'
BASE_MANIFEST = ROOT / 'target/e6-direct-n2/preparation.json'
HELPER_SHA = 'c193cd7282d63b63a8f627612df684242a2a8941d1d0a35588514d0415ab8824'
SYMBOLICA = DEPS / 'libsymbolica-06e42762cabb77d9.rlib'
TOOLS = dict(
    compiler='/nix/store/1qg7z7i461qsv0lczc40nyi8ps6snlca-rustc-1.99.0/bin/rustc',
    linker='/nix/store/788mx070y81zjlg5ipcl0cra3afviw9k-gcc-wrapper-15.2.0/bin/cc',
    taskset='/nix/store/156fzvaz2nsq2hk0fkzn9jwk90bnzyn9-util-linux-2.42.2-bin/bin/taskset',
    python='/nix/store/0r6k8xa2kgqyp3r4v2w7yrb80ma2iawm-python3-3.13.12/bin/python3')
BOUNDS = dict(
    build=dict(total_seconds=90, reserve_seconds=20, per_child_seconds=65),
    exact=dict(total_seconds=300, reserve_seconds=25, per_child_seconds=120,
               listing_seconds=15))
CPU = dict(build=[18, 19], exact=[6])


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def key(path):
    path = Path(path).resolve()
    return str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)


def absolute(path):
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def bind(path, inputs, expected=None):
    path = absolute(path)
    digest = sha(path)
    require(expected is None or expected == digest, 'changed input: ' + key(path))
    require(key(path) not in inputs or inputs[key(path)] == digest,
            'conflicting input: ' + key(path))
    inputs[key(path)] = digest


def verify(inputs, budget=None):
    for path, expected in inputs.items():
        if budget is not None:
            budget.remaining()
        require(sha(absolute(path)) == expected, 'changed input: ' + path)


def closed_directories(protocol, budget=None):
    for directory, expected in protocol['closed_search_directories'].items():
        if budget is not None:
            budget.remaining()
        actual = sorted(key(path) for path in absolute(directory).rglob('*') if path.is_file())
        require(actual == expected, 'dependency/native search inventory differs: ' + directory)


def compile_command():
    return [TOOLS['taskset'], '-c', ','.join(map(str, CPU['build'])), TOOLS['compiler'],
            '--edition=2024', '--crate-name', 'routing_rational_qualification', '--test',
            '-C', 'metadata=routing_rational_source_v2', '-C', 'opt-level=0',
            '-C', 'debuginfo=0', '-C', 'debug-assertions=yes', '-C', 'overflow-checks=yes',
            '-C', 'linker=' + TOOLS['linker'], '-L', 'dependency=' + str(DEPS),
            '-L', 'native=' + str(NATIVE), '--extern', 'symbolica=' + str(SYMBOLICA),
            str(BUNDLE / 'harness.rs'), '-o', str(RUNS / 'build-001/tests')]
