# Source-only isolated routing-module qualification protocol

This is a proposed bounded recipe, not an execution grant or result. Run every
command from `/shared/external/iregi/iregi-rust` and source `scripts/env.sh`.
No compilation, Rust tests or Symbolica evaluation occurred while preparing it.

The small `harness.rs` imports the actual proposed ibp.rs module. Only the
already frozen historical native Symbolica archive and its full immutable e6
dependency/native search directories are reused. This tests the actual compiler
API and recurrences without rebuilding the core, masters or dependencies. It
does not establish current Cargo features, latest Symbolica patch equivalence,
full-core integration or numerical/performance qualification.

`prepare.py` performs static hashing, Python AST parsing and inventory checks,
then creates immutable `protocol.json`. Independent review must bind that exact
protocol, code, command, helper, dependency closure and complete source inventory.
Root then coordinates resource ownership and creates one exact
`grants/<stage>.json`; no script creates its own grant. No existing grant or
historical stage authorizes execution.

The proposed stages are separate, with no automatic continuation or retry:

| Stage | Work | Total bound | Postwork reserve | Child cap | CPUs |
| --- | --- | --- | --- | --- | --- |
| `build` | One direct rustc `--test` module build | 90s | 20s | 65s | 18,19 |
| `exact` | One complete listing and exactly 16 selected tests | 300s | 25s | 15s listing; 120s/test | 6 |

The exact stage requires a matching passed build. Thirteen proposed helper/API
tests include actual generic N6/N7 aliased ScalarCompiler routing and a raw
quadratic fallback, fractional/Gaussian coefficients, homogeneous search,
structural cache and error admission. Three existing actual scalar recurrence
tests cover exact relations, certified covectors and raised powers/negative
dimensions. Runtime listing must exactly match the entire source inventory;
each selected test must report exactly one passed and zero failed/ignored.
Other discovered tests remain explicitly unselected, not qualified by listing.

The copied c193 lifecycle helper owns each complete child process group,
persists terminal events before parsing/hashing, reserves cleanup time, kills
and reaps descendants and checks absence. The caller increases the overall
postwork reserve beyond the helper's original eight seconds. Inputs, tools and
closed search-directory inventories are checked before work, after every child
and at final success. A failure stops the stage and leaves subsequent tests
explicitly unrun. Symbolica license contents are inherited silently and never
logged; only presence is recorded.

Every attempt directory must be fresh. Preserve failed receipts, logs and
sources. A wall-clock observation timeout does not authorize restarting a run.
No source promotion or benchmark update may report algebra tests as numerical
reference agreement or kernel performance.
