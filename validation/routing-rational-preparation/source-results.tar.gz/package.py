"""Archive exact private sources/receipts after terminal algebra qualification.

No compiler, test executable, Symbolica evaluator or integral is invoked.
Compiled binaries and credentials are deliberately outside the capsule.
"""
from pathlib import Path
import gzip
import hashlib
import io
import json
import sys
import tarfile

ROOT = Path('/shared/external/iregi/iregi-rust')
BUNDLE = Path(__file__).resolve().parent
OUTPUT = ROOT / 'validation/routing-rational-preparation'


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def load(relative):
    return json.loads((BUNDLE / relative).read_text())


def main():
    assert Path.cwd().resolve() == ROOT
    assert len(sys.argv) == 2, 'pass the independent saved exact-stage audit path'
    exact_audit = Path(sys.argv[1]).resolve()
    assert exact_audit.is_relative_to(BUNDLE) and exact_audit.is_file()
    build = load('runs-env-v3/build-001/result.json')
    aborted = load('runs-env-v3/exact-001/result.json')
    exact = load('runs-continuation-v5-cpu8/exact-001/result.json')
    failed = load('runs/build-001/result.json')
    assert failed['status'] == 'failed' and build['status'] == 'passed'
    assert exact['status'] in ['passed', 'failed']
    assert build['all_owned_groups_gone'] and exact['all_owned_groups_gone']
    protocol = load('protocol-continuation-v5-cpu8/protocol.json')
    assert build['protocol_sha256'] == protocol['retained_build_protocol_sha256']
    assert exact['protocol_sha256'] == sha_bytes(
        (BUNDLE / 'protocol-continuation-v5-cpu8/protocol.json').read_bytes())
    assert aborted['status'] == 'failed' and aborted['all_owned_groups_gone']
    assert aborted['completed_cases'] == protocol['previously_completed_and_guarded']
    combined = aborted['completed_cases'] + exact['completed_cases']
    combined_passed = exact['status'] == 'passed' and combined == protocol['complete_gate']
    OUTPUT.mkdir(parents=True, exist_ok=False)
    payloads = {}
    excluded = []
    for path in sorted(BUNDLE.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(BUNDLE).as_posix()
        if path.suffix in ['.rlib', '.rmeta', '.a', '.o', '.so', '.pyc'] or path.name == 'tests':
            excluded.append(relative)
            continue
        data = path.read_bytes()
        assert not data.startswith((b'\x7fELF', b'!<arch>\n')), relative
        license_prefix = b'S-' + b'130-'
        assert license_prefix not in data, 'license literal in would-be capsule: ' + relative
        payloads[relative] = data
    members = {name: dict(sha256=sha_bytes(data), bytes=len(data))
               for name, data in payloads.items()}
    tar = io.BytesIO()
    with tarfile.open(fileobj=tar, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, data in payloads.items():
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mode = 0o644
            item.mtime = 0
            archive.addfile(item, io.BytesIO(data))
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=9) as stream:
        stream.write(tar.getvalue())
    compressed = output.getvalue()
    (OUTPUT / 'source-results.tar.gz').write_bytes(compressed)
    qualification = dict(
        schema_version=1, status='private_algebra_qualification_' + ('passed' if combined_passed else 'incomplete'),
        implementation='TIRust', production_applied=False,
        base_commit='2c1f3342e189a20fef3bbf7dd9e0baa372e2b4a2',
        protocol_sha256=exact['protocol_sha256'],
        retained_build_protocol_sha256=build['protocol_sha256'],
        first_build_failure_preserved=True, first_build_elapsed_seconds=failed['elapsed_seconds'],
        corrected_build_passed=True, corrected_build_elapsed_seconds=build['elapsed_seconds'],
        test_binary_sha256=build['binary_sha256'],
        scheduling_aborted_exact_stage_preserved=True,
        aborted_exact_stage_elapsed_seconds=aborted['elapsed_seconds'],
        previously_completed_guarded_cases=aborted['completed_cases'],
        previously_executed_unadmitted_case=protocol['previously_executed_pass_but_postguard_incomplete'],
        continuation_stage_status=exact['status'],
        continuation_elapsed_seconds=exact['elapsed_seconds'],
        continuation_completed_cases=exact['completed_cases'],
        selected_cases=protocol['complete_gate'], completed_cases=combined,
        remaining_unadmitted_cases=exact['unrun_cases'],
        complete_original_sixteen_case_gate_passed=combined_passed,
        discovered_cases=len(protocol['expected_listing']),
        bound_inputs=len(protocol['inputs']), closed_search_directories=2,
        new_exact_cases=13, existing_recurrence_cases=3,
        source_and_exact_independent_review=str(exact_audit.relative_to(BUNDLE)),
        independent_exact_audit_sha256=sha_bytes(exact_audit.read_bytes()),
        all_owned_groups_gone=True, full_core_integration_qualified=False,
        current_cargo_qualified=False, scalar_numerical_reference_qualified=False,
        generalized_highpoint_qualified=False, dual_accuracy_qualified=False,
        performance_qualified=False,
        dependency_context=protocol['dependency_context'],
        diagnostic_durations_are_not_benchmarks=True,
        archive=dict(path='source-results.tar.gz', sha256=sha_bytes(compressed),
                     bytes=len(compressed), members=len(members), member_bindings=members),
        excluded_compiled_cache_files=excluded)
    (OUTPUT / 'qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
    print(dict(status=qualification['status'], output=str(OUTPUT), members=len(members),
               bytes=len(compressed), qualification_sha256=sha_bytes(
                   (OUTPUT / 'qualification.json').read_bytes())))


if __name__ == '__main__':
    main()
