
target/native-dense-span/probe-fixed-b0:     file format elf64-x86-64


Disassembly of section .text:

00000000001a8e80 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>>:
  1a8e80:	push   %rbp
  1a8e81:	push   %r15
  1a8e83:	push   %r14
  1a8e85:	push   %r13
  1a8e87:	push   %r12
  1a8e89:	push   %rbx
  1a8e8a:	sub    $0x178,%rsp
  1a8e91:	mov    %r9,%r11
  1a8e94:	mov    %r8,0x90(%rsp)
  1a8e9c:	mov    %rcx,0x110(%rsp)
  1a8ea4:	mov    %rdx,(%rsp)
  1a8ea8:	mov    %rsi,%rbx
  1a8eab:	mov    %rdi,%r15
  1a8eae:	mov    0x1d8(%rsp),%r12
  1a8eb6:	mov    0x1c0(%rsp),%r13
  1a8ebe:	mov    0x1b8(%rsp),%rax
  1a8ec6:	mov    (%rax),%rdx
  1a8ec9:	test   %rdx,%rdx
  1a8ecc:	mov    %rsi,0x8(%rsp)
  1a8ed1:	mov    %r9,0x28(%rsp)
  1a8ed6:	je     1ad7ab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x492b>
  1a8edc:	mov    0x8(%r13),%rax
  1a8ee0:	mov    0x10(%r13),%rcx
  1a8ee4:	xor    %esi,%esi
  1a8ee6:	xorpd  %xmm0,%xmm0
  1a8eea:	xor    %r8d,%r8d
  1a8eed:	mov    0x1b0(%rsp),%r9
  1a8ef5:	mov    0x1c8(%rsp),%r10
  1a8efd:	jmp    1a8f0c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8c>
  1a8eff:	nop
  1a8f00:	inc    %r8
  1a8f03:	cmp    %r8,%rdx
  1a8f06:	je     1a8f8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10d>
  1a8f0c:	cmp    %r8,%r9
  1a8f0f:	je     1bd4e7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14667>
  1a8f15:	mov    (%r11,%r8,8),%rdi
  1a8f19:	cmp    %rbx,%rdi
  1a8f1c:	jae    1bd4fa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1467a>
  1a8f22:	mov    %rdi,%r9
  1a8f25:	shl    $0x4,%r9
  1a8f29:	movsd  (%r15,%r9,1),%xmm1
  1a8f2f:	ucomisd %xmm0,%xmm1
  1a8f33:	jne    1a8f70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf0>
  1a8f35:	jp     1a8f70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf0>
  1a8f37:	add    %r15,%r9
  1a8f3a:	movsd  0x8(%r9),%xmm1
  1a8f40:	ucomisd %xmm0,%xmm1
  1a8f44:	jne    1a8f70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf0>
  1a8f46:	jp     1a8f70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf0>
  1a8f48:	cmp    0x1d0(%rsp),%rdi
  1a8f50:	jae    1bda82 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c02>
  1a8f56:	movq   $0x16c,(%r10,%rdi,8)
  1a8f5e:	mov    0x1b0(%rsp),%r9
  1a8f66:	jmp    1a8f00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x80>
  1a8f68:	nopl   0x0(%rax,%rax,1)
  1a8f70:	mov    0x1b0(%rsp),%r9
  1a8f78:	cmp    %r9,%rsi
  1a8f7b:	jae    1bd81a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1499a>
  1a8f81:	mov    %rdi,(%r11,%rsi,8)
  1a8f85:	inc    %rsi
  1a8f88:	jmp    1a8f00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x80>
  1a8f8d:	cmp    %r9,%rsi
  1a8f90:	ja     1b5ad9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc59>
  1a8f96:	test   %rsi,%rsi
  1a8f99:	je     1ad7ab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x492b>
  1a8f9f:	mov    (%r11),%rdx
  1a8fa2:	lea    -0x1(%rsi),%rdi
  1a8fa6:	mov    -0x8(%r11,%rsi,8),%r8
  1a8fab:	sub    %rdx,%r8
  1a8fae:	setae  %r9b
  1a8fb2:	cmp    %rdi,%r8
  1a8fb5:	sete   %dil
  1a8fb9:	mov    %rdx,%r10
  1a8fbc:	add    %rsi,%r10
  1a8fbf:	cmovb  %rcx,%r10
  1a8fc3:	cmovb  %rax,%rdx
  1a8fc7:	test   %dil,%r9b
  1a8fca:	cmove  %rcx,%r10
  1a8fce:	cmove  %rax,%rdx
  1a8fd2:	xor    %eax,%eax
  1a8fd4:	xorpd  %xmm0,%xmm0
  1a8fd8:	xor    %r8d,%r8d
  1a8fdb:	mov    0x1b0(%rsp),%r9
  1a8fe3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1a8ff0:	mov    (%r11,%r8,8),%rdi
  1a8ff4:	mov    (%rsp),%rcx
  1a8ff8:	add    %rdi,%rcx
  1a8ffb:	cmp    %rbx,%rcx
  1a8ffe:	jae    1bd674 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x147f4>
  1a9004:	shl    $0x4,%rcx
  1a9008:	movsd  (%r15,%rcx,1),%xmm1
  1a900e:	ucomisd %xmm0,%xmm1
  1a9012:	jne    1a9050 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1d0>
  1a9014:	jp     1a9050 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1d0>
  1a9016:	add    %r15,%rcx
  1a9019:	movsd  0x8(%rcx),%xmm1
  1a901e:	ucomisd %xmm0,%xmm1
  1a9022:	jne    1a9050 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1d0>
  1a9024:	jp     1a9050 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1d0>
  1a9026:	cmp    0x1d0(%rsp),%rdi
  1a902e:	jae    1be0f7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15277>
  1a9034:	mov    0x1c8(%rsp),%rcx
  1a903c:	movq   $0x119,(%rcx,%rdi,8)
  1a9044:	inc    %r8
  1a9047:	cmp    %r8,%rsi
  1a904a:	jne    1a8ff0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x170>
  1a904c:	jmp    1a9068 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1e8>
  1a904e:	xchg   %ax,%ax
  1a9050:	cmp    %r9,%rax
  1a9053:	jae    1bdbac <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14d2c>
  1a9059:	mov    %rdi,(%r11,%rax,8)
  1a905d:	inc    %rax
  1a9060:	inc    %r8
  1a9063:	cmp    %r8,%rsi
  1a9066:	jne    1a8ff0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x170>
  1a9068:	cmp    %r9,%rax
  1a906b:	ja     1bd348 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x144c8>
  1a9071:	test   %rax,%rax
  1a9074:	je     1ad7ab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x492b>
  1a907a:	mov    (%r11),%r8
  1a907d:	lea    -0x1(%rax),%rcx
  1a9081:	mov    -0x8(%r11,%rax,8),%rsi
  1a9086:	sub    %r8,%rsi
  1a9089:	setae  %dil
  1a908d:	cmp    %rcx,%rsi
  1a9090:	sete   %cl
  1a9093:	mov    %r8,%r9
  1a9096:	add    %rax,%r9
  1a9099:	cmovb  %r10,%r9
  1a909d:	cmovb  %rdx,%r8
  1a90a1:	test   %cl,%dil
  1a90a4:	cmove  %r10,%r9
  1a90a8:	cmove  %rdx,%r8
  1a90ac:	mov    (%rsp),%rcx
  1a90b0:	lea    (%rcx,%rcx,1),%r10
  1a90b4:	xor    %r14d,%r14d
  1a90b7:	xorpd  %xmm0,%xmm0
  1a90bb:	xor    %edx,%edx
  1a90bd:	mov    0x1c8(%rsp),%rsi
  1a90c5:	data16 cs nopw 0x0(%rax,%rax,1)
  1a90d0:	mov    (%r11,%rdx,8),%rdi
  1a90d4:	lea    (%rdi,%r10,1),%rcx
  1a90d8:	cmp    %rbx,%rcx
  1a90db:	jae    1bda97 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c17>
  1a90e1:	shl    $0x4,%rcx
  1a90e5:	movsd  (%r15,%rcx,1),%xmm1
  1a90eb:	ucomisd %xmm0,%xmm1
  1a90ef:	jne    1a9130 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2b0>
  1a90f1:	jp     1a9130 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2b0>
  1a90f3:	add    %r15,%rcx
  1a90f6:	movsd  0x8(%rcx),%xmm1
  1a90fb:	ucomisd %xmm0,%xmm1
  1a90ff:	jne    1a9130 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2b0>
  1a9101:	jp     1a9130 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2b0>
  1a9103:	cmp    0x1d0(%rsp),%rdi
  1a910b:	jae    1be69c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1581c>
  1a9111:	movq   $0xc6,(%rsi,%rdi,8)
  1a9119:	inc    %rdx
  1a911c:	cmp    %rdx,%rax
  1a911f:	jne    1a90d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x250>
  1a9121:	jmp    1a914d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2cd>
  1a9123:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1a9130:	cmp    0x1b0(%rsp),%r14
  1a9138:	jae    1be251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x153d1>
  1a913e:	mov    %rdi,(%r11,%r14,8)
  1a9142:	inc    %r14
  1a9145:	inc    %rdx
  1a9148:	cmp    %rdx,%rax
  1a914b:	jne    1a90d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x250>
  1a914d:	cmp    0x1b0(%rsp),%r14
  1a9155:	ja     1bd413 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14593>
  1a915b:	test   %r14,%r14
  1a915e:	je     1ad7ab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x492b>
  1a9164:	mov    (%r11),%rdx
  1a9167:	lea    -0x1(%r14),%rsi
  1a916b:	mov    -0x8(%r11,%r14,8),%rax
  1a9170:	sub    %rdx,%rax
  1a9173:	setae  %cl
  1a9176:	mov    %rsi,0x60(%rsp)
  1a917b:	cmp    %rsi,%rax
  1a917e:	sete   %al
  1a9181:	lea    (%rdx,%r14,1),%rsi
  1a9185:	cmp    %rdx,%rsi
  1a9188:	setae  %dil
  1a918c:	and    %al,%dil
  1a918f:	and    %cl,%dil
  1a9192:	mov    %dil,0x38(%rsp)
  1a9197:	cmp    $0x1,%dil
  1a919b:	mov    %rdx,0x20(%rsp)
  1a91a0:	mov    %r10,0x10(%rsp)
  1a91a5:	je     1a9636 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7b6>
  1a91ab:	cmpq   $0x2,0x1e0(%rsp)
  1a91b4:	jb     1bf193 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16313>
  1a91ba:	lea    0x0(,%r14,8),%rdx
  1a91c2:	mov    (%rsp),%rax
  1a91c6:	lea    0x0(,%rax,8),%r11
  1a91ce:	mov    %r11,%r10
  1a91d1:	sub    %rax,%r10
  1a91d4:	xor    %ecx,%ecx
  1a91d6:	cs nopw 0x0(%rax,%rax,1)
  1a91e0:	mov    0x28(%rsp),%rax
  1a91e5:	mov    (%rax,%rcx,1),%rdi
  1a91e9:	mov    (%rsp),%rax
  1a91ed:	add    %rdi,%rax
  1a91f0:	cmp    %rbx,%rax
  1a91f3:	jae    1bf1a8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16328>
  1a91f9:	add    %r10,%rdi
  1a91fc:	cmp    %rbx,%rdi
  1a91ff:	jae    1be938 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ab8>
  1a9205:	shl    $0x4,%rax
  1a9209:	movupd 0x10(%r12),%xmm2
  1a9210:	shl    $0x4,%rdi
  1a9214:	movupd (%r15,%rax,1),%xmm3
  1a921a:	movapd %xmm2,%xmm0
  1a921e:	unpcklpd %xmm2,%xmm0
  1a9222:	movapd %xmm0,%xmm4
  1a9226:	mulpd  %xmm3,%xmm4
  1a922a:	shufpd $0x1,%xmm3,%xmm3
  1a922f:	movapd %xmm2,%xmm1
  1a9233:	unpckhpd %xmm2,%xmm1
  1a9237:	mulpd  %xmm1,%xmm3
  1a923b:	movapd %xmm4,%xmm5
  1a923f:	subpd  %xmm3,%xmm5
  1a9243:	addpd  %xmm4,%xmm3
  1a9247:	movsd  %xmm5,%xmm3
  1a924b:	movupd %xmm3,(%r15,%rdi,1)
  1a9251:	add    $0x8,%rcx
  1a9255:	cmp    %rcx,%rdx
  1a9258:	jne    1a91e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x360>
  1a925a:	mov    %r14,0x50(%rsp)
  1a925f:	xor    %r14d,%r14d
  1a9262:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1a9270:	mov    0x28(%rsp),%rax
  1a9275:	mov    (%rax,%r14,1),%rdi
  1a9279:	cmp    %rbx,%rdi
  1a927c:	jae    1be981 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15b01>
  1a9282:	mov    0x10(%rsp),%rax
  1a9287:	add    %rdi,%rax
  1a928a:	cmp    %rbx,%rax
  1a928d:	jae    1be96e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15aee>
  1a9293:	lea    (%rdi,%r10,1),%rcx
  1a9297:	cmp    %rbx,%rcx
  1a929a:	jae    1be95b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15adb>
  1a92a0:	lea    (%rdi,%r11,1),%rsi
  1a92a4:	cmp    %rbx,%rsi
  1a92a7:	jae    1be948 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ac8>
  1a92ad:	shl    $0x4,%rdi
  1a92b1:	shl    $0x4,%rax
  1a92b5:	shl    $0x4,%rcx
  1a92b9:	shl    $0x4,%rsi
  1a92bd:	movupd (%r15,%rdi,1),%xmm3
  1a92c3:	movupd (%r15,%rax,1),%xmm4
  1a92c9:	addpd  %xmm3,%xmm4
  1a92cd:	movupd (%r15,%rcx,1),%xmm3
  1a92d3:	addpd  %xmm4,%xmm3
  1a92d7:	movupd %xmm3,(%r15,%rsi,1)
  1a92dd:	add    $0x8,%r14
  1a92e1:	cmp    %r14,%rdx
  1a92e4:	jne    1a9270 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x3f0>
  1a92e6:	mov    (%rsp),%rax
  1a92ea:	lea    (%rax,%rax,8),%rcx
  1a92ee:	movapd %xmm2,%xmm3
  1a92f2:	shufpd $0x1,%xmm2,%xmm3
  1a92f7:	xor    %esi,%esi
  1a92f9:	nopl   0x0(%rax)
  1a9300:	mov    0x28(%rsp),%rax
  1a9305:	mov    (%rax,%rsi,1),%rdi
  1a9309:	lea    (%rdi,%r11,1),%rax
  1a930d:	cmp    %rbx,%rax
  1a9310:	jae    1be9a1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15b21>
  1a9316:	add    %rcx,%rdi
  1a9319:	cmp    %rbx,%rdi
  1a931c:	jae    1be991 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15b11>
  1a9322:	shl    $0x4,%rax
  1a9326:	shl    $0x4,%rdi
  1a932a:	movsd  (%r15,%rax,1),%xmm4
  1a9330:	movsd  0x8(%r15,%rax,1),%xmm5
  1a9337:	unpcklpd %xmm4,%xmm4
  1a933b:	mulpd  %xmm2,%xmm4
  1a933f:	unpcklpd %xmm5,%xmm5
  1a9343:	mulpd  %xmm3,%xmm5
  1a9347:	movapd %xmm4,%xmm6
  1a934b:	subpd  %xmm5,%xmm6
  1a934f:	addpd  %xmm4,%xmm5
  1a9353:	movsd  %xmm6,%xmm5
  1a9357:	movupd %xmm5,(%r15,%rdi,1)
  1a935d:	add    $0x8,%rsi
  1a9361:	cmp    %rsi,%rdx
  1a9364:	jne    1a9300 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x480>
  1a9366:	cmpq   $0x2,0x1e0(%rsp)
  1a936f:	je     1bf1bd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1633d>
  1a9375:	mov    0x10(%rsp),%rax
  1a937a:	lea    (%rax,%rax,4),%r11
  1a937e:	xor    %ecx,%ecx
  1a9380:	mov    0x28(%rsp),%rax
  1a9385:	mov    (%rax,%rcx,1),%rsi
  1a9389:	cmp    %rbx,%rsi
  1a938c:	jae    1be9c4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15b44>
  1a9392:	mov    (%rsp),%rax
  1a9396:	add    %rsi,%rax
  1a9399:	cmp    %rbx,%rax
  1a939c:	jae    1bf1df <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1635f>
  1a93a2:	lea    (%rsi,%r11,1),%rdi
  1a93a6:	cmp    %rbx,%rdi
  1a93a9:	jae    1be9b4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15b34>
  1a93af:	shl    $0x4,%rax
  1a93b3:	shl    $0x4,%rsi
  1a93b7:	movupd (%r15,%rax,1),%xmm2
  1a93bd:	movupd (%r15,%rsi,1),%xmm3
  1a93c3:	movapd %xmm2,%xmm4
  1a93c7:	mulpd  %xmm3,%xmm4
  1a93cb:	shl    $0x4,%rdi
  1a93cf:	movupd 0x20(%r12),%xmm5
  1a93d6:	movapd %xmm4,%xmm6
  1a93da:	unpcklpd %xmm4,%xmm6
  1a93de:	unpckhpd %xmm4,%xmm4
  1a93e2:	subpd  %xmm4,%xmm6
  1a93e6:	mulpd  %xmm5,%xmm6
  1a93ea:	movapd %xmm3,%xmm4
  1a93ee:	unpckhpd %xmm3,%xmm4
  1a93f2:	mulsd  %xmm2,%xmm4
  1a93f6:	unpckhpd %xmm2,%xmm2
  1a93fa:	mulsd  %xmm3,%xmm2
  1a93fe:	addsd  %xmm4,%xmm2
  1a9402:	unpcklpd %xmm2,%xmm2
  1a9406:	shufpd $0x1,%xmm5,%xmm5
  1a940b:	mulpd  %xmm2,%xmm5
  1a940f:	movapd %xmm6,%xmm2
  1a9413:	subpd  %xmm5,%xmm2
  1a9417:	addpd  %xmm6,%xmm5
  1a941b:	movsd  %xmm2,%xmm5
  1a941f:	movupd %xmm5,(%r15,%rdi,1)
  1a9425:	add    $0x8,%rcx
  1a9429:	cmp    %rcx,%rdx
  1a942c:	jne    1a9380 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x500>
  1a9432:	mov    (%rsp),%rcx
  1a9436:	lea    (%rcx,%rcx,4),%rax
  1a943a:	lea    (%rcx,%rax,2),%r12
  1a943e:	xor    %ecx,%ecx
  1a9440:	mov    0x28(%rsp),%rax
  1a9445:	mov    (%rax,%rcx,1),%rax
  1a9449:	cmp    %rbx,%rax
  1a944c:	jae    1be9f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15b70>
  1a9452:	lea    (%rax,%r12,1),%rdi
  1a9456:	cmp    %rbx,%rdi
  1a9459:	jae    1be9e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15b60>
  1a945f:	shl    $0x4,%rax
  1a9463:	shl    $0x4,%rdi
  1a9467:	movupd (%r15,%rax,1),%xmm2
  1a946d:	movapd %xmm0,%xmm3
  1a9471:	mulpd  %xmm2,%xmm3
  1a9475:	shufpd $0x1,%xmm2,%xmm2
  1a947a:	mulpd  %xmm1,%xmm2
  1a947e:	movapd %xmm3,%xmm4
  1a9482:	subpd  %xmm2,%xmm4
  1a9486:	addpd  %xmm3,%xmm2
  1a948a:	movsd  %xmm4,%xmm2
  1a948e:	movupd %xmm2,(%r15,%rdi,1)
  1a9494:	add    $0x8,%rcx
  1a9498:	cmp    %rcx,%rdx
  1a949b:	jne    1a9440 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5c0>
  1a949d:	mov    (%rsp),%rax
  1a94a1:	lea    0x0(,%rax,4),%rax
  1a94a9:	lea    (%rax,%rax,2),%r14
  1a94ad:	xor    %r13d,%r13d
  1a94b0:	mov    0x28(%rsp),%rax
  1a94b5:	mov    (%rax,%r13,1),%rdi
  1a94b9:	mov    0x10(%rsp),%rax
  1a94be:	add    %rdi,%rax
  1a94c1:	cmp    %rbx,%rax
  1a94c4:	jae    1bea39 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15bb9>
  1a94ca:	lea    (%rdi,%r10,1),%rcx
  1a94ce:	cmp    %rbx,%rcx
  1a94d1:	jae    1bea26 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ba6>
  1a94d7:	lea    (%rdi,%r12,1),%rsi
  1a94db:	cmp    %rbx,%rsi
  1a94de:	jae    1bea13 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15b93>
  1a94e4:	add    %r14,%rdi
  1a94e7:	cmp    %rbx,%rdi
  1a94ea:	jae    1bea03 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15b83>
  1a94f0:	shl    $0x4,%rax
  1a94f4:	shl    $0x4,%rcx
  1a94f8:	shl    $0x4,%rsi
  1a94fc:	shl    $0x4,%rdi
  1a9500:	movupd (%r15,%rax,1),%xmm0
  1a9506:	movupd (%r15,%rcx,1),%xmm1
  1a950c:	addpd  %xmm0,%xmm1
  1a9510:	movupd (%r15,%rsi,1),%xmm0
  1a9516:	addpd  %xmm1,%xmm0
  1a951a:	movupd %xmm0,(%r15,%rdi,1)
  1a9520:	add    $0x8,%r13
  1a9524:	cmp    %r13,%rdx
  1a9527:	jne    1a94b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x630>
  1a9529:	mov    (%rsp),%rcx
  1a952d:	lea    (%rcx,%rcx,2),%rax
  1a9531:	lea    (%rcx,%rax,4),%rsi
  1a9535:	xor    %ecx,%ecx
  1a9537:	mov    0x10(%rsp),%r10
  1a953c:	nopl   0x0(%rax)
  1a9540:	mov    0x28(%rsp),%rax
  1a9545:	mov    (%rax,%rcx,1),%rdi
  1a9549:	lea    (%rdi,%r14,1),%rax
  1a954d:	cmp    %rbx,%rax
  1a9550:	jae    1bea5c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15bdc>
  1a9556:	add    %rsi,%rdi
  1a9559:	cmp    %rbx,%rdi
  1a955c:	jae    1bea4c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15bcc>
  1a9562:	shl    $0x4,%rax
  1a9566:	movsd  (%r15,%rax,1),%xmm0
  1a956c:	movsd  0x8(%r15,%rax,1),%xmm1
  1a9573:	movapd %xmm0,%xmm2
  1a9577:	mulsd  %xmm1,%xmm2
  1a957b:	addsd  %xmm2,%xmm2
  1a957f:	mulsd  %xmm0,%xmm0
  1a9583:	mulsd  %xmm1,%xmm1
  1a9587:	subsd  %xmm1,%xmm0
  1a958b:	shl    $0x4,%rdi
  1a958f:	movsd  %xmm0,(%r15,%rdi,1)
  1a9595:	movsd  %xmm2,0x8(%r15,%rdi,1)
  1a959c:	add    $0x8,%rcx
  1a95a0:	cmp    %rcx,%rdx
  1a95a3:	jne    1a9540 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6c0>
  1a95a5:	mov    (%rsp),%rbp
  1a95a9:	shl    $0x4,%rbp
  1a95ad:	sub    %r10,%rbp
  1a95b0:	xor    %r10d,%r10d
  1a95b3:	mov    0x50(%rsp),%r14
  1a95b8:	nopl   0x0(%rax,%rax,1)
  1a95c0:	mov    0x28(%rsp),%rax
  1a95c5:	mov    (%rax,%r10,1),%rdi
  1a95c9:	lea    (%rdi,%r11,1),%rax
  1a95cd:	cmp    %rbx,%rax
  1a95d0:	jae    1bea92 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15c12>
  1a95d6:	lea    (%rdi,%rsi,1),%rcx
  1a95da:	cmp    %rbx,%rcx
  1a95dd:	jae    1bea7f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15bff>
  1a95e3:	add    %rbp,%rdi
  1a95e6:	cmp    %rbx,%rdi
  1a95e9:	jae    1bea6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15bef>
  1a95ef:	shl    $0x4,%rax
  1a95f3:	shl    $0x4,%rcx
  1a95f7:	shl    $0x4,%rdi
  1a95fb:	movupd (%r15,%rax,1),%xmm0
  1a9601:	movupd (%r15,%rcx,1),%xmm1
  1a9607:	addpd  %xmm0,%xmm1
  1a960b:	movupd %xmm1,(%r15,%rdi,1)
  1a9611:	add    $0x8,%r10
  1a9615:	cmp    %r10,%rdx
  1a9618:	jne    1a95c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x740>
  1a961a:	mov    %r8,0x20(%rsp)
  1a961f:	mov    %r9,0x30(%rsp)
  1a9624:	mov    0x1b0(%rsp),%r9
  1a962c:	mov    0x28(%rsp),%r11
  1a9631:	jmp    1aa228 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13a8>
  1a9636:	cmp    %rsi,%rdx
  1a9639:	mov    %rsi,0x30(%rsp)
  1a963e:	jae    1aa215 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1395>
  1a9644:	mov    %r14,0x50(%rsp)
  1a9649:	cmpq   $0x2,0x1e0(%rsp)
  1a9652:	jb     1bf240 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163c0>
  1a9658:	mov    (%rsp),%rsi
  1a965c:	lea    0x0(,%rsi,8),%rax
  1a9664:	mov    %rax,%rcx
  1a9667:	sub    %rsi,%rcx
  1a966a:	mov    0x20(%rsp),%r14
  1a966f:	mov    %rcx,0x18(%rsp)
  1a9674:	lea    (%r14,%rcx,1),%r10
  1a9678:	xor    %ecx,%ecx
  1a967a:	mov    %rbx,%rdx
  1a967d:	sub    %r10,%rdx
  1a9680:	cmovb  %rcx,%rdx
  1a9684:	lea    (%r14,%rsi,1),%rdi
  1a9688:	mov    %rbx,%rsi
  1a968b:	sub    %rdi,%rsi
  1a968e:	cmovb  %rcx,%rsi
  1a9692:	cmp    %rsi,%rdx
  1a9695:	mov    %rsi,0xe0(%rsp)
  1a969d:	mov    %rsi,%rcx
  1a96a0:	mov    %rdx,0x40(%rsp)
  1a96a5:	cmovb  %rdx,%rcx
  1a96a9:	mov    0x60(%rsp),%rdx
  1a96ae:	cmp    %rcx,%rdx
  1a96b1:	cmovb  %rdx,%rcx
  1a96b5:	mov    %r14,%rdx
  1a96b8:	cmp    $0x1a,%rcx
  1a96bc:	jb     1a98d9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa59>
  1a96c2:	xor    %edx,%edx
  1a96c4:	mov    %rbx,%rsi
  1a96c7:	sub    %r10,%rsi
  1a96ca:	cmovb  %rdx,%rsi
  1a96ce:	mov    %rbx,%r8
  1a96d1:	sub    %rdi,%r8
  1a96d4:	cmovb  %rdx,%r8
  1a96d8:	cmp    %r8,%rsi
  1a96db:	cmovb  %rsi,%r8
  1a96df:	mov    0x60(%rsp),%rdx
  1a96e4:	cmp    %r8,%rdx
  1a96e7:	cmovb  %rdx,%r8
  1a96eb:	mov    %rdi,%rdx
  1a96ee:	shl    $0x4,%rdx
  1a96f2:	lea    (%r15,%rdx,1),%r11
  1a96f6:	lea    (%r15,%rdx,1),%r9
  1a96fa:	add    $0x8,%r9
  1a96fe:	shl    $0x4,%r8
  1a9702:	lea    (%r8,%r11,1),%rsi
  1a9706:	add    $0x8,%rsi
  1a970a:	mov    %r14,%rdx
  1a970d:	cmp    %r9,%rsi
  1a9710:	jb     1a98d9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa59>
  1a9716:	imul   $0x70,(%rsp),%rsi
  1a971b:	mov    %r9,0x48(%rsp)
  1a9720:	mov    %r14,%r9
  1a9723:	shl    $0x4,%r9
  1a9727:	xor    %edx,%edx
  1a9729:	mov    %rbx,%r8
  1a972c:	sub    %r10,%r8
  1a972f:	cmovb  %rdx,%r8
  1a9733:	mov    %rbx,%r10
  1a9736:	sub    %rdi,%r10
  1a9739:	cmovb  %rdx,%r10
  1a973d:	lea    (%rsi,%r9,1),%rdx
  1a9741:	cmp    %r10,%r8
  1a9744:	cmovb  %r8,%r10
  1a9748:	lea    (%r15,%rdx,1),%r8
  1a974c:	mov    0x60(%rsp),%r12
  1a9751:	cmp    %r10,%r12
  1a9754:	cmovb  %r12,%r10
  1a9758:	lea    (%r15,%rdx,1),%r12
  1a975c:	add    $0x8,%r12
  1a9760:	shl    $0x4,%r10
  1a9764:	lea    (%r10,%r8,1),%rbp
  1a9768:	add    $0x8,%rbp
  1a976c:	lea    0x10(%r10,%r8,1),%r13
  1a9771:	lea    (%r10,%r11,1),%rdx
  1a9775:	add    $0x10,%rdx
  1a9779:	mov    %rdx,0xd0(%rsp)
  1a9781:	add    %r11,%r10
  1a9784:	add    $0x8,%r10
  1a9788:	cmp    %r13,%r8
  1a978b:	setb   0x100(%rsp)
  1a9793:	cmp    %rbp,%r12
  1a9796:	setb   0xb0(%rsp)
  1a979e:	cmp    %rdx,%r8
  1a97a1:	setb   0x58(%rsp)
  1a97a6:	mov    0x48(%rsp),%rdx
  1a97ab:	cmp    %rbp,%rdx
  1a97ae:	setb   0x88(%rsp)
  1a97b6:	cmp    %r10,%r8
  1a97b9:	setb   %r8b
  1a97bd:	cmp    %rbp,%r11
  1a97c0:	setb   0x78(%rsp)
  1a97c5:	cmp    0xd0(%rsp),%r12
  1a97cd:	setb   %bpl
  1a97d1:	cmp    %r13,%rdx
  1a97d4:	setb   0x48(%rsp)
  1a97d9:	cmp    %r10,%r12
  1a97dc:	setb   %r12b
  1a97e0:	cmp    %r13,%r11
  1a97e3:	setb   %r11b
  1a97e7:	mov    %r14,%rdx
  1a97ea:	movzbl 0xb0(%rsp),%r10d
  1a97f3:	test   %r10b,0x100(%rsp)
  1a97fb:	jne    1a98d9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa59>
  1a9801:	mov    %r14,%rdx
  1a9804:	movzbl 0x88(%rsp),%r10d
  1a980d:	and    %r10b,0x58(%rsp)
  1a9812:	jne    1a98d9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa59>
  1a9818:	mov    %r14,%rdx
  1a981b:	and    0x78(%rsp),%r8b
  1a9820:	jne    1a98d9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa59>
  1a9826:	mov    %r14,%rdx
  1a9829:	and    0x48(%rsp),%bpl
  1a982e:	jne    1a98d9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa59>
  1a9834:	mov    %r14,%rdx
  1a9837:	and    %r11b,%r12b
  1a983a:	jne    1a98d9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa59>
  1a9840:	movabs $0x7fffffffffffffe,%rdx
  1a984a:	and    %rdx,%rcx
  1a984d:	lea    (%r14,%rcx,1),%rdx
  1a9851:	mov    0x1d8(%rsp),%r8
  1a9859:	movsd  0x10(%r8),%xmm0
  1a985f:	movsd  0x18(%r8),%xmm1
  1a9865:	unpcklpd %xmm0,%xmm0
  1a9869:	unpcklpd %xmm1,%xmm1
  1a986d:	add    %r15,%r9
  1a9870:	mov    (%rsp),%r10
  1a9874:	shl    $0x4,%r10
  1a9878:	movupd (%r9,%r10,1),%xmm2
  1a987e:	movupd 0x10(%r9,%r10,1),%xmm3
  1a9885:	movapd %xmm2,%xmm4
  1a9889:	unpcklpd %xmm3,%xmm4
  1a988d:	unpckhpd %xmm3,%xmm2
  1a9891:	movapd %xmm2,%xmm3
  1a9895:	mulpd  %xmm0,%xmm3
  1a9899:	movapd %xmm0,%xmm5
  1a989d:	mulpd  %xmm4,%xmm5
  1a98a1:	mulpd  %xmm1,%xmm4
  1a98a5:	addpd  %xmm3,%xmm4
  1a98a9:	mulpd  %xmm1,%xmm2
  1a98ad:	subpd  %xmm2,%xmm5
  1a98b1:	movapd %xmm5,%xmm2
  1a98b5:	unpcklpd %xmm4,%xmm2
  1a98b9:	unpckhpd %xmm4,%xmm5
  1a98bd:	movupd %xmm5,0x10(%r9,%rsi,1)
  1a98c4:	movupd %xmm2,(%r9,%rsi,1)
  1a98ca:	add    $0x20,%r9
  1a98ce:	add    $0xfffffffffffffffe,%rcx
  1a98d2:	jne    1a9878 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9f8>
  1a98d4:	mov    0x20(%rsp),%r14
  1a98d9:	mov    0x18(%rsp),%rcx
  1a98de:	lea    (%rdx,%rcx,1),%rsi
  1a98e2:	mov    (%rsp),%r8
  1a98e6:	imul   $0x70,%r8,%r10
  1a98ea:	lea    (%r15,%r10,1),%r12
  1a98ee:	mov    %rdx,%r9
  1a98f1:	shl    $0x4,%r9
  1a98f5:	lea    (%rdx,%r8,1),%rcx
  1a98f9:	mov    %r8,%r11
  1a98fc:	shl    $0x4,%r11
  1a9900:	mov    %r11,0x100(%rsp)
  1a9908:	lea    (%r15,%r11,1),%r13
  1a990c:	sub    0x50(%rsp),%rdx
  1a9911:	mov    0x1d8(%rsp),%r11
  1a9919:	nopl   0x0(%rax)
  1a9920:	cmp    %rbx,%rcx
  1a9923:	jae    1bf26b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163eb>
  1a9929:	cmp    %rbx,%rsi
  1a992c:	jae    1bee68 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15fe8>
  1a9932:	movupd 0x10(%r11),%xmm2
  1a9938:	movupd 0x0(%r13,%r9,1),%xmm3
  1a993f:	movapd %xmm2,%xmm0
  1a9943:	unpcklpd %xmm2,%xmm0
  1a9947:	movapd %xmm0,%xmm4
  1a994b:	mulpd  %xmm3,%xmm4
  1a994f:	shufpd $0x1,%xmm3,%xmm3
  1a9954:	movapd %xmm2,%xmm1
  1a9958:	unpckhpd %xmm2,%xmm1
  1a995c:	mulpd  %xmm1,%xmm3
  1a9960:	movapd %xmm4,%xmm5
  1a9964:	subpd  %xmm3,%xmm5
  1a9968:	addpd  %xmm4,%xmm3
  1a996c:	movsd  %xmm5,%xmm3
  1a9970:	movupd %xmm3,(%r12,%r9,1)
  1a9976:	inc    %rsi
  1a9979:	add    $0x10,%r9
  1a997d:	inc    %rcx
  1a9980:	inc    %rdx
  1a9983:	cmp    %rdx,%r14
  1a9986:	jne    1a9920 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xaa0>
  1a9988:	mov    %r12,0x88(%rsp)
  1a9990:	mov    0x10(%rsp),%rcx
  1a9995:	lea    (%r14,%rcx,1),%rsi
  1a9999:	xor    %ecx,%ecx
  1a999b:	mov    %rbx,%rdx
  1a999e:	mov    %rsi,0x58(%rsp)
  1a99a3:	sub    %rsi,%rdx
  1a99a6:	cmovb  %rcx,%rdx
  1a99aa:	mov    0x40(%rsp),%rsi
  1a99af:	cmp    %rsi,%rdx
  1a99b2:	mov    %rdx,0xb0(%rsp)
  1a99ba:	cmovb  %rdx,%rsi
  1a99be:	lea    (%r14,%r8,8),%rdx
  1a99c2:	mov    %rbx,%r8
  1a99c5:	sub    %rdx,%r8
  1a99c8:	cmovb  %rcx,%r8
  1a99cc:	cmp    %r8,%rsi
  1a99cf:	mov    %r8,0xd0(%rsp)
  1a99d7:	cmovae %r8,%rsi
  1a99db:	mov    %rbx,%rdx
  1a99de:	sub    %r14,%rdx
  1a99e1:	cmovb  %rcx,%rdx
  1a99e5:	cmp    %rdx,%rsi
  1a99e8:	mov    %rdx,0x48(%rsp)
  1a99ed:	cmovae %rdx,%rsi
  1a99f1:	mov    0x60(%rsp),%rcx
  1a99f6:	cmp    %rsi,%rcx
  1a99f9:	cmovb  %rcx,%rsi
  1a99fd:	mov    %r14,%rcx
  1a9a00:	cmp    $0x39,%rsi
  1a9a04:	ja     1ab71a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x289a>
  1a9a0a:	mov    (%rsp),%rbp
  1a9a0e:	mov    %rbp,%r9
  1a9a11:	shl    $0x5,%r9
  1a9a15:	mov    %rcx,%rdx
  1a9a18:	shl    $0x4,%rdx
  1a9a1c:	add    %r15,%rdx
  1a9a1f:	shl    $0x7,%rbp
  1a9a23:	mov    0x30(%rsp),%r8
  1a9a28:	nopl   0x0(%rax,%rax,1)
  1a9a30:	cmp    %rbx,%rcx
  1a9a33:	jae    1beee4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16064>
  1a9a39:	mov    0x10(%rsp),%rsi
  1a9a3e:	add    %rcx,%rsi
  1a9a41:	cmp    %rbx,%rsi
  1a9a44:	jae    1beed1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16051>
  1a9a4a:	mov    0x18(%rsp),%rsi
  1a9a4f:	add    %rcx,%rsi
  1a9a52:	cmp    %rbx,%rsi
  1a9a55:	jae    1beebe <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1603e>
  1a9a5b:	lea    (%rax,%rcx,1),%rsi
  1a9a5f:	cmp    %rbx,%rsi
  1a9a62:	jae    1beeab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1602b>
  1a9a68:	inc    %rcx
  1a9a6b:	movupd (%rdx),%xmm3
  1a9a6f:	movupd (%rdx,%r9,1),%xmm4
  1a9a75:	addpd  %xmm3,%xmm4
  1a9a79:	movupd (%rdx,%r10,1),%xmm3
  1a9a7f:	addpd  %xmm4,%xmm3
  1a9a83:	movupd %xmm3,(%rdx,%rbp,1)
  1a9a88:	add    $0x10,%rdx
  1a9a8c:	cmp    %rcx,%r8
  1a9a8f:	jne    1a9a30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbb0>
  1a9a91:	mov    (%rsp),%rcx
  1a9a95:	lea    (%rcx,%rcx,8),%rcx
  1a9a99:	lea    (%r14,%rcx,1),%r11
  1a9a9d:	xor    %esi,%esi
  1a9a9f:	mov    %rbx,%rdx
  1a9aa2:	sub    %r11,%rdx
  1a9aa5:	cmovae %rdx,%rsi
  1a9aa9:	mov    0xd0(%rsp),%r8
  1a9ab1:	cmp    %rsi,%r8
  1a9ab4:	cmovb  %r8,%rsi
  1a9ab8:	mov    0x60(%rsp),%rdx
  1a9abd:	cmp    %rsi,%rdx
  1a9ac0:	cmovb  %rdx,%rsi
  1a9ac4:	lea    0x1(%rsi),%rdx
  1a9ac8:	mov    %r14,%r12
  1a9acb:	cmp    $0x1c,%rdx
  1a9acf:	ja     1ac048 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x31c8>
  1a9ad5:	movapd %xmm2,%xmm3
  1a9ad9:	shufpd $0x1,%xmm2,%xmm3
  1a9ade:	add    %r12,%rcx
  1a9ae1:	mov    0x100(%rsp),%rdx
  1a9ae9:	lea    (%rdx,%rdx,8),%rdx
  1a9aed:	mov    %r12,%rsi
  1a9af0:	shl    $0x4,%rsi
  1a9af4:	add    %r15,%rsi
  1a9af7:	add    %r12,%rax
  1a9afa:	sub    0x50(%rsp),%r12
  1a9aff:	mov    0x20(%rsp),%r8
  1a9b04:	mov    0xe0(%rsp),%r14
  1a9b0c:	nopl   0x0(%rax)
  1a9b10:	cmp    %rbx,%rax
  1a9b13:	jae    1bef0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1608a>
  1a9b19:	cmp    %rbx,%rcx
  1a9b1c:	jae    1beef7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16077>
  1a9b22:	movsd  (%rsi,%rbp,1),%xmm4
  1a9b27:	movsd  0x8(%rsi,%rbp,1),%xmm5
  1a9b2d:	unpcklpd %xmm4,%xmm4
  1a9b31:	mulpd  %xmm2,%xmm4
  1a9b35:	unpcklpd %xmm5,%xmm5
  1a9b39:	mulpd  %xmm3,%xmm5
  1a9b3d:	movapd %xmm4,%xmm6
  1a9b41:	subpd  %xmm5,%xmm6
  1a9b45:	addpd  %xmm4,%xmm5
  1a9b49:	movsd  %xmm6,%xmm5
  1a9b4d:	movupd %xmm5,(%rsi,%rdx,1)
  1a9b52:	inc    %rcx
  1a9b55:	add    $0x10,%rsi
  1a9b59:	inc    %rax
  1a9b5c:	inc    %r12
  1a9b5f:	cmp    %r12,%r8
  1a9b62:	jne    1a9b10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc90>
  1a9b64:	cmpq   $0x2,0x1e0(%rsp)
  1a9b6d:	je     1bf280 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16400>
  1a9b73:	mov    0x10(%rsp),%rax
  1a9b78:	lea    (%rax,%rax,4),%rcx
  1a9b7c:	lea    (%r8,%rcx,1),%rbp
  1a9b80:	xor    %edx,%edx
  1a9b82:	mov    %rbx,%rax
  1a9b85:	sub    %rbp,%rax
  1a9b88:	cmovae %rax,%rdx
  1a9b8c:	mov    0x48(%rsp),%rax
  1a9b91:	cmp    %rax,%rdx
  1a9b94:	mov    %rdx,0xd0(%rsp)
  1a9b9c:	cmovb  %rdx,%rax
  1a9ba0:	cmp    %r14,%rax
  1a9ba3:	cmovae %r14,%rax
  1a9ba7:	mov    0x60(%rsp),%rdx
  1a9bac:	cmp    %rax,%rdx
  1a9baf:	cmovb  %rdx,%rax
  1a9bb3:	mov    %r8,%r11
  1a9bb6:	cmp    $0x18,%rax
  1a9bba:	jae    1ac532 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x36b2>
  1a9bc0:	mov    %r11,%rax
  1a9bc3:	shl    $0x4,%rax
  1a9bc7:	mov    (%rsp),%r8
  1a9bcb:	lea    (%r8,%r8,4),%rdx
  1a9bcf:	mov    %rdx,%rbp
  1a9bd2:	shl    $0x5,%rbp
  1a9bd6:	lea    (%r15,%rbp,1),%rsi
  1a9bda:	mov    0x1d8(%rsp),%r14
  1a9be2:	mov    0x30(%rsp),%r12
  1a9be7:	nopw   0x0(%rax,%rax,1)
  1a9bf0:	cmp    %rbx,%r11
  1a9bf3:	jae    1bef50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x160d0>
  1a9bf9:	lea    (%r8,%r11,1),%rdi
  1a9bfd:	cmp    %rbx,%rdi
  1a9c00:	jae    1bf2a7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16427>
  1a9c06:	lea    (%rcx,%r11,1),%rdi
  1a9c0a:	cmp    %rbx,%rdi
  1a9c0d:	jae    1bef40 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x160c0>
  1a9c13:	inc    %r11
  1a9c16:	movupd 0x0(%r13,%rax,1),%xmm2
  1a9c1d:	movupd (%r15,%rax,1),%xmm3
  1a9c23:	movapd %xmm2,%xmm4
  1a9c27:	mulpd  %xmm3,%xmm4
  1a9c2b:	movupd 0x20(%r14),%xmm5
  1a9c31:	movapd %xmm4,%xmm6
  1a9c35:	unpcklpd %xmm4,%xmm6
  1a9c39:	unpckhpd %xmm4,%xmm4
  1a9c3d:	subpd  %xmm4,%xmm6
  1a9c41:	mulpd  %xmm5,%xmm6
  1a9c45:	movapd %xmm3,%xmm4
  1a9c49:	unpckhpd %xmm3,%xmm4
  1a9c4d:	mulsd  %xmm2,%xmm4
  1a9c51:	unpckhpd %xmm2,%xmm2
  1a9c55:	mulsd  %xmm3,%xmm2
  1a9c59:	addsd  %xmm4,%xmm2
  1a9c5d:	unpcklpd %xmm2,%xmm2
  1a9c61:	shufpd $0x1,%xmm5,%xmm5
  1a9c66:	mulpd  %xmm2,%xmm5
  1a9c6a:	movapd %xmm6,%xmm2
  1a9c6e:	subpd  %xmm5,%xmm2
  1a9c72:	addpd  %xmm6,%xmm5
  1a9c76:	movsd  %xmm2,%xmm5
  1a9c7a:	movupd %xmm5,(%rsi,%rax,1)
  1a9c7f:	add    $0x10,%rax
  1a9c83:	cmp    %r11,%r12
  1a9c86:	jne    1a9bf0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd70>
  1a9c8c:	mov    %rbp,0x58(%rsp)
  1a9c91:	lea    (%r8,%rdx,2),%r11
  1a9c95:	mov    0x20(%rsp),%r14
  1a9c9a:	lea    (%r14,%r11,1),%r13
  1a9c9e:	xor    %ebp,%ebp
  1a9ca0:	mov    %rbx,%rax
  1a9ca3:	sub    %r13,%rax
  1a9ca6:	cmovae %rax,%rbp
  1a9caa:	mov    0x48(%rsp),%r8
  1a9caf:	cmp    %r8,%rbp
  1a9cb2:	mov    %r8,%rax
  1a9cb5:	cmovb  %rbp,%rax
  1a9cb9:	mov    0x60(%rsp),%rdx
  1a9cbe:	cmp    %rax,%rdx
  1a9cc1:	cmovb  %rdx,%rax
  1a9cc5:	mov    %r14,%rdi
  1a9cc8:	cmp    $0x1a,%rax
  1a9ccc:	jb     1a9f06 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1086>
  1a9cd2:	xor    %esi,%esi
  1a9cd4:	mov    %rbx,%rdx
  1a9cd7:	sub    %r13,%rdx
  1a9cda:	cmovae %rdx,%rsi
  1a9cde:	cmp    %r8,%rsi
  1a9ce1:	cmovae %r8,%rsi
  1a9ce5:	mov    0x60(%rsp),%rdx
  1a9cea:	cmp    %rsi,%rdx
  1a9ced:	cmovb  %rdx,%rsi
  1a9cf1:	mov    %r14,%r12
  1a9cf4:	shl    $0x4,%r12
  1a9cf8:	lea    (%r15,%r12,1),%rdx
  1a9cfc:	mov    %rbp,0xe0(%rsp)
  1a9d04:	lea    (%r15,%r12,1),%rbp
  1a9d08:	add    $0x8,%rbp
  1a9d0c:	shl    $0x4,%rsi
  1a9d10:	add    %rdx,%rsi
  1a9d13:	add    $0x8,%rsi
  1a9d17:	mov    %r14,%rdi
  1a9d1a:	mov    %rbp,0x78(%rsp)
  1a9d1f:	cmp    %rbp,%rsi
  1a9d22:	mov    0xe0(%rsp),%rbp
  1a9d2a:	jb     1a9f06 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1086>
  1a9d30:	imul   $0xb0,(%rsp),%rsi
  1a9d38:	mov    %r8,%rdi
  1a9d3b:	lea    (%rsi,%r12,1),%r8
  1a9d3f:	lea    (%r15,%r8,1),%rbx
  1a9d43:	mov    %rbx,0x98(%rsp)
  1a9d4b:	xor    %ebx,%ebx
  1a9d4d:	mov    0x8(%rsp),%r14
  1a9d52:	sub    %r13,%r14
  1a9d55:	cmovae %r14,%rbx
  1a9d59:	lea    (%r15,%r8,1),%rbp
  1a9d5d:	add    $0x8,%rbp
  1a9d61:	cmp    %rdi,%rbx
  1a9d64:	cmovae %rdi,%rbx
  1a9d68:	mov    0x60(%rsp),%r8
  1a9d6d:	cmp    %rbx,%r8
  1a9d70:	cmovb  %r8,%rbx
  1a9d74:	shl    $0x4,%rbx
  1a9d78:	mov    0x98(%rsp),%r8
  1a9d80:	lea    (%rbx,%r8,1),%r14
  1a9d84:	add    $0x8,%r14
  1a9d88:	add    %r15,%r12
  1a9d8b:	lea    (%r12,%rbx,1),%r13
  1a9d8f:	add    %rsi,%r13
  1a9d92:	add    $0x10,%r13
  1a9d96:	lea    0x10(%rbx,%r12,1),%rdi
  1a9d9b:	mov    %rdi,0xa8(%rsp)
  1a9da3:	add    %r12,%rbx
  1a9da6:	add    $0x8,%rbx
  1a9daa:	mov    %rbx,0xc8(%rsp)
  1a9db2:	cmp    %r13,%r8
  1a9db5:	setb   0x48(%rsp)
  1a9dba:	cmp    %r14,%rbp
  1a9dbd:	mov    %rbp,%rbx
  1a9dc0:	setb   0x80(%rsp)
  1a9dc8:	cmp    %rdi,%r8
  1a9dcb:	setb   0xf8(%rsp)
  1a9dd3:	mov    0x78(%rsp),%rbp
  1a9dd8:	cmp    %r14,%rbp
  1a9ddb:	setb   0x118(%rsp)
  1a9de3:	mov    0xc8(%rsp),%rdi
  1a9deb:	cmp    %rdi,%r8
  1a9dee:	setb   0x98(%rsp)
  1a9df6:	cmp    %r14,%r12
  1a9df9:	mov    0x20(%rsp),%r14
  1a9dfe:	setb   0x120(%rsp)
  1a9e06:	cmp    0xa8(%rsp),%rbx
  1a9e0e:	setb   0xa8(%rsp)
  1a9e16:	cmp    %r13,%rbp
  1a9e19:	mov    0xe0(%rsp),%rbp
  1a9e21:	setb   0x78(%rsp)
  1a9e26:	cmp    %rdi,%rbx
  1a9e29:	mov    0x8(%rsp),%rbx
  1a9e2e:	setb   %r8b
  1a9e32:	cmp    %r13,%r12
  1a9e35:	setb   %r12b
  1a9e39:	mov    %r14,%rdi
  1a9e3c:	movzbl 0x80(%rsp),%r13d
  1a9e45:	test   %r13b,0x48(%rsp)
  1a9e4a:	jne    1a9f06 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1086>
  1a9e50:	mov    %r14,%rdi
  1a9e53:	movzbl 0x118(%rsp),%r13d
  1a9e5c:	and    %r13b,0xf8(%rsp)
  1a9e64:	jne    1a9f06 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1086>
  1a9e6a:	mov    %r14,%rdi
  1a9e6d:	movzbl 0x120(%rsp),%r13d
  1a9e76:	and    %r13b,0x98(%rsp)
  1a9e7e:	jne    1a9f06 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1086>
  1a9e84:	mov    %r14,%rdi
  1a9e87:	movzbl 0x78(%rsp),%r13d
  1a9e8d:	and    %r13b,0xa8(%rsp)
  1a9e95:	jne    1a9f06 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1086>
  1a9e97:	mov    %r14,%rdi
  1a9e9a:	and    %r12b,%r8b
  1a9e9d:	jne    1a9f06 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1086>
  1a9e9f:	movabs $0x7fffffffffffffe,%rdi
  1a9ea9:	and    %rdi,%rax
  1a9eac:	lea    (%r14,%rax,1),%rdi
  1a9eb0:	movupd (%rdx),%xmm2
  1a9eb4:	movupd 0x10(%rdx),%xmm3
  1a9eb9:	movapd %xmm2,%xmm4
  1a9ebd:	unpcklpd %xmm3,%xmm4
  1a9ec1:	unpckhpd %xmm3,%xmm2
  1a9ec5:	movapd %xmm0,%xmm3
  1a9ec9:	mulpd  %xmm2,%xmm3
  1a9ecd:	movapd %xmm1,%xmm5
  1a9ed1:	mulpd  %xmm4,%xmm5
  1a9ed5:	addpd  %xmm3,%xmm5
  1a9ed9:	mulpd  %xmm0,%xmm4
  1a9edd:	mulpd  %xmm1,%xmm2
  1a9ee1:	subpd  %xmm2,%xmm4
  1a9ee5:	movapd %xmm4,%xmm2
  1a9ee9:	unpcklpd %xmm5,%xmm2
  1a9eed:	unpckhpd %xmm5,%xmm4
  1a9ef1:	movupd %xmm4,0x10(%rdx,%rsi,1)
  1a9ef7:	movupd %xmm2,(%rdx,%rsi,1)
  1a9efc:	add    $0x20,%rdx
  1a9f00:	add    $0xfffffffffffffffe,%rax
  1a9f04:	jne    1a9eb0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1030>
  1a9f06:	imul   $0xb0,(%rsp),%r13
  1a9f0e:	mov    %rdi,%rdx
  1a9f11:	shl    $0x4,%rdx
  1a9f15:	add    %r15,%rdx
  1a9f18:	mov    0x30(%rsp),%rsi
  1a9f1d:	nopl   (%rax)
  1a9f20:	cmp    %rbx,%rdi
  1a9f23:	jae    1bef7f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x160ff>
  1a9f29:	lea    (%r11,%rdi,1),%rax
  1a9f2d:	cmp    %rbx,%rax
  1a9f30:	jae    1bef6c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x160ec>
  1a9f36:	inc    %rdi
  1a9f39:	movupd (%rdx),%xmm2
  1a9f3d:	movapd %xmm0,%xmm3
  1a9f41:	mulpd  %xmm2,%xmm3
  1a9f45:	shufpd $0x1,%xmm2,%xmm2
  1a9f4a:	mulpd  %xmm1,%xmm2
  1a9f4e:	movapd %xmm3,%xmm4
  1a9f52:	subpd  %xmm2,%xmm4
  1a9f56:	addpd  %xmm3,%xmm2
  1a9f5a:	movsd  %xmm4,%xmm2
  1a9f5e:	movupd %xmm2,(%rdx,%r13,1)
  1a9f64:	add    $0x10,%rdx
  1a9f68:	cmp    %rdi,%rsi
  1a9f6b:	jne    1a9f20 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10a0>
  1a9f6d:	mov    (%rsp),%rax
  1a9f71:	lea    0x0(,%rax,4),%rax
  1a9f79:	lea    (%rax,%rax,2),%rdi
  1a9f7d:	mov    0x40(%rsp),%rax
  1a9f82:	mov    0xb0(%rsp),%rdx
  1a9f8a:	cmp    %rax,%rdx
  1a9f8d:	cmovb  %rdx,%rax
  1a9f91:	cmp    %rbp,%rax
  1a9f94:	cmovae %rbp,%rax
  1a9f98:	lea    (%r14,%rdi,1),%r8
  1a9f9c:	xor    %esi,%esi
  1a9f9e:	mov    %rbx,%rdx
  1a9fa1:	mov    %r8,0xe0(%rsp)
  1a9fa9:	sub    %r8,%rdx
  1a9fac:	cmovae %rdx,%rsi
  1a9fb0:	cmp    %rsi,%rax
  1a9fb3:	mov    %rsi,0x48(%rsp)
  1a9fb8:	cmovae %rsi,%rax
  1a9fbc:	mov    0x60(%rsp),%rdx
  1a9fc1:	cmp    %rax,%rdx
  1a9fc4:	cmovb  %rdx,%rax
  1a9fc8:	lea    0x1(%rax),%rsi
  1a9fcc:	mov    %r14,%rdx
  1a9fcf:	cmp    $0x36,%rsi
  1a9fd3:	ja     1acb32 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x3cb2>
  1a9fd9:	mov    (%rsp),%r8
  1a9fdd:	mov    %r8,%rax
  1a9fe0:	shl    $0x6,%rax
  1a9fe4:	lea    (%rax,%rax,2),%r14
  1a9fe8:	mov    %rdx,%rsi
  1a9feb:	shl    $0x4,%rsi
  1a9fef:	add    %r15,%rsi
  1a9ff2:	mov    0x30(%rsp),%r12
  1a9ff7:	mov    0x48(%rsp),%rbp
  1a9ffc:	nopl   0x0(%rax)
  1aa000:	mov    0x10(%rsp),%rax
  1aa005:	add    %rdx,%rax
  1aa008:	cmp    %rbx,%rax
  1aa00b:	jae    1befeb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1616b>
  1aa011:	mov    0x18(%rsp),%rax
  1aa016:	add    %rdx,%rax
  1aa019:	cmp    %rbx,%rax
  1aa01c:	jae    1befd8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16158>
  1aa022:	lea    (%r11,%rdx,1),%rax
  1aa026:	cmp    %rbx,%rax
  1aa029:	jae    1befc5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16145>
  1aa02f:	lea    (%rdi,%rdx,1),%rax
  1aa033:	cmp    %rbx,%rax
  1aa036:	jae    1befb2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16132>
  1aa03c:	inc    %rdx
  1aa03f:	movupd (%rsi,%r9,1),%xmm0
  1aa045:	movupd (%rsi,%r10,1),%xmm1
  1aa04b:	addpd  %xmm0,%xmm1
  1aa04f:	movupd (%rsi,%r13,1),%xmm0
  1aa055:	addpd  %xmm1,%xmm0
  1aa059:	movupd %xmm0,(%rsi,%r14,1)
  1aa05f:	add    $0x10,%rsi
  1aa063:	cmp    %rdx,%r12
  1aa066:	jne    1aa000 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1180>
  1aa068:	lea    (%r8,%r8,2),%r12
  1aa06c:	lea    (%r8,%r12,4),%r8
  1aa070:	mov    0x20(%rsp),%r11
  1aa075:	lea    (%r11,%r8,1),%r13
  1aa079:	xor    %edx,%edx
  1aa07b:	mov    %rbx,%rax
  1aa07e:	sub    %r13,%rax
  1aa081:	cmovae %rax,%rdx
  1aa085:	cmp    %rdx,%rbp
  1aa088:	mov    %rdx,0x18(%rsp)
  1aa08d:	mov    %rdx,%rax
  1aa090:	cmovb  %rbp,%rax
  1aa094:	mov    0x60(%rsp),%rdx
  1aa099:	cmp    %rax,%rdx
  1aa09c:	cmovb  %rdx,%rax
  1aa0a0:	lea    0x1(%rax),%rdx
  1aa0a4:	mov    %r11,%rsi
  1aa0a7:	cmp    $0x1e,%rdx
  1aa0ab:	ja     1ad08e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x420e>
  1aa0b1:	lea    (%rsi,%r8,1),%rax
  1aa0b5:	imul   $0xd0,(%rsp),%r10
  1aa0bd:	mov    %rsi,%rdx
  1aa0c0:	shl    $0x4,%rdx
  1aa0c4:	add    %r15,%rdx
  1aa0c7:	add    $0x8,%rdx
  1aa0cb:	add    %rsi,%rdi
  1aa0ce:	sub    0x50(%rsp),%rsi
  1aa0d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1aa0e0:	cmp    %rbx,%rdi
  1aa0e3:	jae    1bf011 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16191>
  1aa0e9:	cmp    %rbx,%rax
  1aa0ec:	jae    1beffe <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1617e>
  1aa0f2:	movsd  -0x8(%rdx,%r14,1),%xmm0
  1aa0f9:	movsd  (%rdx,%r14,1),%xmm1
  1aa0ff:	movapd %xmm0,%xmm2
  1aa103:	mulsd  %xmm1,%xmm2
  1aa107:	addsd  %xmm2,%xmm2
  1aa10b:	mulsd  %xmm0,%xmm0
  1aa10f:	mulsd  %xmm1,%xmm1
  1aa113:	subsd  %xmm1,%xmm0
  1aa117:	movsd  %xmm0,-0x8(%rdx,%r10,1)
  1aa11e:	movsd  %xmm2,(%rdx,%r10,1)
  1aa124:	inc    %rax
  1aa127:	add    $0x10,%rdx
  1aa12b:	inc    %rdi
  1aa12e:	inc    %rsi
  1aa131:	cmp    %rsi,0x20(%rsp)
  1aa136:	jne    1aa0e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1260>
  1aa138:	mov    0x100(%rsp),%rax
  1aa140:	sub    0x10(%rsp),%rax
  1aa145:	mov    0xd0(%rsp),%rsi
  1aa14d:	mov    0x18(%rsp),%rdx
  1aa152:	cmp    %rdx,%rsi
  1aa155:	cmovb  %rsi,%rdx
  1aa159:	mov    0x20(%rsp),%rbp
  1aa15e:	mov    %rax,%r13
  1aa161:	lea    (%rax,%rbp,1),%r12
  1aa165:	xor    %eax,%eax
  1aa167:	mov    %rbx,%rsi
  1aa16a:	sub    %r12,%rsi
  1aa16d:	cmovae %rsi,%rax
  1aa171:	cmp    %rax,%rdx
  1aa174:	cmovb  %rdx,%rax
  1aa178:	mov    0x60(%rsp),%rdx
  1aa17d:	cmp    %rax,%rdx
  1aa180:	cmovb  %rdx,%rax
  1aa184:	lea    0x1(%rax),%rsi
  1aa188:	mov    %rbp,%rdx
  1aa18b:	cmp    $0x3a,%rsi
  1aa18f:	ja     1ad2e3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4463>
  1aa195:	imul   $0xe0,(%rsp),%rax
  1aa19d:	mov    %rdx,%rsi
  1aa1a0:	shl    $0x4,%rsi
  1aa1a4:	add    %r15,%rsi
  1aa1a7:	lea    (%r9,%r9,4),%r9
  1aa1ab:	mov    0x28(%rsp),%r11
  1aa1b0:	mov    0x50(%rsp),%r14
  1aa1b5:	mov    0x30(%rsp),%r12
  1aa1ba:	nopw   0x0(%rax,%rax,1)
  1aa1c0:	lea    (%rcx,%rdx,1),%rdi
  1aa1c4:	cmp    %rbx,%rdi
  1aa1c7:	jae    1bf041 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161c1>
  1aa1cd:	lea    (%r8,%rdx,1),%rdi
  1aa1d1:	cmp    %rbx,%rdi
  1aa1d4:	jae    1bf031 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161b1>
  1aa1da:	lea    (%rdx,%r13,1),%rdi
  1aa1de:	cmp    %rbx,%rdi
  1aa1e1:	jae    1bf021 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161a1>
  1aa1e7:	inc    %rdx
  1aa1ea:	movupd (%rsi,%r9,1),%xmm0
  1aa1f0:	movupd (%rsi,%r10,1),%xmm1
  1aa1f6:	addpd  %xmm0,%xmm1
  1aa1fa:	movupd %xmm1,(%rsi,%rax,1)
  1aa1ff:	add    $0x10,%rsi
  1aa203:	cmp    %rdx,%r12
  1aa206:	jne    1aa1c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1340>
  1aa208:	mov    0x1b0(%rsp),%r9
  1aa210:	mov    %r13,%rbp
  1aa213:	jmp    1aa228 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13a8>
  1aa215:	mov    (%rsp),%rbp
  1aa219:	shl    $0x4,%rbp
  1aa21d:	sub    %r10,%rbp
  1aa220:	mov    0x1b0(%rsp),%r9
  1aa228:	mov    %r14,0x50(%rsp)
  1aa22d:	lea    0x0(,%r14,8),%r8
  1aa235:	mov    (%rsp),%rax
  1aa239:	lea    (%rax,%rax,4),%rax
  1aa23d:	mov    %rax,0x48(%rsp)
  1aa242:	lea    (%rax,%rax,2),%r12
  1aa246:	xor    %r13d,%r13d
  1aa249:	xorpd  %xmm8,%xmm8
  1aa24e:	movapd 0x1febdaa(%rip),%xmm6        # 2196000 <_fini+0x520>
  1aa256:	movapd 0x1febdb1(%rip),%xmm9        # 2196010 <_fini+0x530>
  1aa25f:	movsd  0x1fed488(%rip),%xmm10        # 21976f0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3e0>
  1aa268:	movsd  0x1fed440(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1aa270:	mov    0x1c8(%rsp),%r10
  1aa278:	mov    %r8,0x18(%rsp)
  1aa27d:	nopl   (%rax)
  1aa280:	mov    (%r11,%r13,1),%r14
  1aa284:	lea    (%r14,%rbp,1),%rdi
  1aa288:	cmp    %rbx,%rdi
  1aa28b:	jae    1be11f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1529f>
  1aa291:	shl    $0x4,%rdi
  1aa295:	movupd (%r15,%rdi,1),%xmm13
  1aa29b:	movapd %xmm13,%xmm12
  1aa2a0:	unpckhpd %xmm13,%xmm12
  1aa2a5:	movapd %xmm12,%xmm11
  1aa2aa:	ucomisd %xmm8,%xmm12
  1aa2af:	movapd %xmm13,%xmm0
  1aa2b4:	andpd  %xmm6,%xmm0
  1aa2b8:	jne    1aa2f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1470>
  1aa2ba:	jp     1aa2f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1470>
  1aa2bc:	sqrtsd %xmm0,%xmm0
  1aa2c0:	ucomisd %xmm13,%xmm8
  1aa2c5:	jbe    1aa4f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1670>
  1aa2cb:	movq   %xmm12,%rax
  1aa2d0:	test   %rax,%rax
  1aa2d3:	jns    1aa2da <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x145a>
  1aa2d5:	xorpd  %xmm9,%xmm0
  1aa2da:	movapd %xmm0,%xmm11
  1aa2df:	xorpd  %xmm0,%xmm0
  1aa2e3:	jmp    1aa4f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1670>
  1aa2e8:	nopl   0x0(%rax,%rax,1)
  1aa2f0:	andpd  %xmm6,%xmm11
  1aa2f5:	movapd %xmm11,%xmm14
  1aa2fa:	cmplesd %xmm0,%xmm14
  1aa300:	movapd %xmm14,%xmm1
  1aa305:	andpd  %xmm0,%xmm1
  1aa309:	andnpd %xmm11,%xmm14
  1aa30e:	orpd   %xmm1,%xmm14
  1aa313:	movapd %xmm14,%xmm1
  1aa318:	unpcklpd %xmm14,%xmm1
  1aa31d:	movapd %xmm13,%xmm0
  1aa322:	divpd  %xmm1,%xmm0
  1aa326:	movapd %xmm0,%xmm1
  1aa32a:	unpckhpd %xmm0,%xmm1
  1aa32e:	ucomisd %xmm8,%xmm1
  1aa333:	jne    1aa349 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c9>
  1aa335:	jp     1aa349 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c9>
  1aa337:	unpcklpd %xmm0,%xmm0
  1aa33b:	andpd  %xmm6,%xmm0
  1aa33f:	movapd %xmm0,%xmm15
  1aa344:	jmp    1aa480 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1600>
  1aa349:	ucomisd %xmm8,%xmm0
  1aa34e:	movapd %xmm0,%xmm15
  1aa353:	andpd  %xmm6,%xmm15
  1aa358:	jne    1aa360 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14e0>
  1aa35a:	jnp    1aa480 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1600>
  1aa360:	pshufd $0xee,%xmm15,%xmm3
  1aa366:	movapd %xmm15,%xmm4
  1aa36b:	cmplesd %xmm3,%xmm4
  1aa370:	movapd %xmm4,%xmm2
  1aa374:	andpd  %xmm3,%xmm2
  1aa378:	andnpd %xmm15,%xmm4
  1aa37d:	orpd   %xmm2,%xmm4
  1aa381:	movapd %xmm0,%xmm2
  1aa385:	cmpunordsd %xmm0,%xmm2
  1aa38a:	movapd %xmm2,%xmm5
  1aa38e:	andnpd %xmm4,%xmm5
  1aa392:	andpd  %xmm3,%xmm2
  1aa396:	orpd   %xmm5,%xmm2
  1aa39a:	ucomisd %xmm7,%xmm2
  1aa39e:	jbe    1aa3ca <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x154a>
  1aa3a0:	movsd  0x1fed310(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1aa3a8:	ucomisd %xmm2,%xmm3
  1aa3ac:	jbe    1aa3ca <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x154a>
  1aa3ae:	mulpd  %xmm0,%xmm0
  1aa3b2:	movapd %xmm0,%xmm1
  1aa3b6:	unpckhpd %xmm0,%xmm1
  1aa3ba:	addsd  %xmm0,%xmm1
  1aa3be:	xorps  %xmm0,%xmm0
  1aa3c1:	sqrtsd %xmm1,%xmm0
  1aa3c5:	jmp    1aa46e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ee>
  1aa3ca:	movapd %xmm11,0x60(%rsp)
  1aa3d1:	movapd %xmm12,0x100(%rsp)
  1aa3db:	movapd %xmm13,0xb0(%rsp)
  1aa3e5:	movapd %xmm14,0xd0(%rsp)
  1aa3ef:	movaps %xmm15,0xe0(%rsp)
  1aa3f8:	call   *0x25217d2(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1aa3fe:	movapd 0xe0(%rsp),%xmm15
  1aa408:	movapd 0xd0(%rsp),%xmm14
  1aa412:	movapd 0xb0(%rsp),%xmm13
  1aa41c:	movapd 0x100(%rsp),%xmm12
  1aa426:	movapd 0x60(%rsp),%xmm11
  1aa42d:	movsd  0x1fed2ba(%rip),%xmm10        # 21976f0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3e0>
  1aa436:	movapd 0x1febbd1(%rip),%xmm9        # 2196010 <_fini+0x530>
  1aa43f:	xorpd  %xmm8,%xmm8
  1aa444:	movsd  0x1fed264(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1aa44c:	movapd 0x1febbac(%rip),%xmm6        # 2196000 <_fini+0x520>
  1aa454:	mov    0x18(%rsp),%r8
  1aa459:	mov    0x1c8(%rsp),%r10
  1aa461:	mov    0x28(%rsp),%r11
  1aa466:	mov    0x1b0(%rsp),%r9
  1aa46e:	unpcklpd %xmm0,%xmm15
  1aa473:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1aa480:	xorps  %xmm0,%xmm0
  1aa483:	sqrtsd %xmm14,%xmm0
  1aa488:	movapd %xmm15,%xmm1
  1aa48d:	unpckhpd %xmm15,%xmm1
  1aa492:	addsd  %xmm15,%xmm1
  1aa497:	mulsd  %xmm10,%xmm1
  1aa49c:	sqrtsd %xmm1,%xmm1
  1aa4a0:	mulsd  %xmm0,%xmm1
  1aa4a4:	ucomisd %xmm8,%xmm13
  1aa4a9:	jae    1aa4d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1650>
  1aa4ab:	divsd  %xmm1,%xmm11
  1aa4b0:	movapd %xmm11,%xmm0
  1aa4b5:	mulsd  %xmm10,%xmm0
  1aa4ba:	movq   %xmm12,%rax
  1aa4bf:	test   %rax,%rax
  1aa4c2:	jns    1aa4c9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1649>
  1aa4c4:	xorpd  %xmm9,%xmm1
  1aa4c9:	movapd %xmm1,%xmm11
  1aa4ce:	jmp    1aa4f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1670>
  1aa4d0:	divsd  %xmm1,%xmm12
  1aa4d5:	mulsd  %xmm10,%xmm12
  1aa4da:	movapd %xmm1,%xmm0
  1aa4de:	movapd %xmm12,%xmm11
  1aa4e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1aa4f0:	add    %r12,%r14
  1aa4f3:	cmp    %rbx,%r14
  1aa4f6:	jae    1be10c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1528c>
  1aa4fc:	shl    $0x4,%r14
  1aa500:	movsd  %xmm0,(%r15,%r14,1)
  1aa506:	movsd  %xmm11,0x8(%r15,%r14,1)
  1aa50d:	add    $0x8,%r13
  1aa511:	cmp    %r13,%r8
  1aa514:	jne    1aa280 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1400>
  1aa51a:	cmpb   $0x0,0x38(%rsp)
  1aa51f:	je     1aa638 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x17b8>
  1aa525:	mov    0x20(%rsp),%rbp
  1aa52a:	mov    0x30(%rsp),%rcx
  1aa52f:	cmp    %rcx,%rbp
  1aa532:	jae    1aa6a7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1827>
  1aa538:	mov    (%rsp),%r13
  1aa53c:	lea    0x0(,%r13,8),%rax
  1aa544:	add    %r13,%rax
  1aa547:	shl    $0x4,%r13
  1aa54b:	mov    %rbp,%r9
  1aa54e:	not    %r9
  1aa551:	add    %rcx,%r9
  1aa554:	lea    (%rax,%rbp,1),%r11
  1aa558:	xor    %edx,%edx
  1aa55a:	mov    %rbx,%rcx
  1aa55d:	sub    %r11,%rcx
  1aa560:	cmovb  %rdx,%rcx
  1aa564:	lea    (%r12,%rbp,1),%r14
  1aa568:	mov    %rbx,%rsi
  1aa56b:	sub    %r14,%rsi
  1aa56e:	cmovb  %rdx,%rsi
  1aa572:	cmp    %rsi,%rcx
  1aa575:	cmovb  %rcx,%rsi
  1aa579:	mov    %rbp,%rdi
  1aa57c:	add    %r13,%rdi
  1aa57f:	mov    %rbx,%rcx
  1aa582:	mov    %rdi,0x60(%rsp)
  1aa587:	sub    %rdi,%rcx
  1aa58a:	cmovb  %rdx,%rcx
  1aa58e:	cmp    %rcx,%rsi
  1aa591:	cmovb  %rsi,%rcx
  1aa595:	cmp    %rcx,%r9
  1aa598:	cmovb  %r9,%rcx
  1aa59c:	lea    0x1(%rcx),%rdx
  1aa5a0:	mov    %rbp,%r10
  1aa5a3:	cmp    $0x48,%rdx
  1aa5a7:	ja     1abc7a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2dfa>
  1aa5ad:	mov    (%rsp),%rdi
  1aa5b1:	mov    %rdi,%rcx
  1aa5b4:	shl    $0x8,%rcx
  1aa5b8:	mov    %r10,%rdx
  1aa5bb:	shl    $0x4,%rdx
  1aa5bf:	add    %r15,%rdx
  1aa5c2:	imul   $0xf0,%rdi,%rsi
  1aa5c9:	shl    $0x4,%rdi
  1aa5cd:	lea    (%rdi,%rdi,8),%r8
  1aa5d1:	mov    0x1b0(%rsp),%r9
  1aa5d9:	mov    0x28(%rsp),%r11
  1aa5de:	xchg   %ax,%ax
  1aa5e0:	lea    (%rax,%r10,1),%rdi
  1aa5e4:	cmp    %rbx,%rdi
  1aa5e7:	jae    1bee9b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1601b>
  1aa5ed:	lea    (%r12,%r10,1),%rdi
  1aa5f1:	cmp    %rbx,%rdi
  1aa5f4:	jae    1bee8b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1600b>
  1aa5fa:	lea    (%r10,%r13,1),%rdi
  1aa5fe:	cmp    %rbx,%rdi
  1aa601:	jae    1bee7b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ffb>
  1aa607:	inc    %r10
  1aa60a:	movupd (%rdx,%r8,1),%xmm0
  1aa610:	movupd (%rdx,%rsi,1),%xmm1
  1aa615:	addpd  %xmm0,%xmm1
  1aa619:	movupd %xmm1,(%rdx,%rcx,1)
  1aa61e:	add    $0x10,%rdx
  1aa622:	cmp    %r10,0x30(%rsp)
  1aa627:	jne    1aa5e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1760>
  1aa629:	mov    0x1c8(%rsp),%r10
  1aa631:	mov    0x18(%rsp),%r8
  1aa636:	jmp    1aa6af <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x182f>
  1aa638:	mov    (%rsp),%r13
  1aa63c:	lea    0x0(,%r13,8),%rdx
  1aa644:	add    %r13,%rdx
  1aa647:	shl    $0x4,%r13
  1aa64b:	xor    %esi,%esi
  1aa64d:	nopl   (%rax)
  1aa650:	mov    (%r11,%rsi,1),%rdi
  1aa654:	lea    (%rdi,%rdx,1),%rax
  1aa658:	cmp    %rbx,%rax
  1aa65b:	jae    1beac8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15c48>
  1aa661:	lea    (%rdi,%r12,1),%rcx
  1aa665:	cmp    %rbx,%rcx
  1aa668:	jae    1beab5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15c35>
  1aa66e:	add    %r13,%rdi
  1aa671:	cmp    %rbx,%rdi
  1aa674:	jae    1beaa5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15c25>
  1aa67a:	shl    $0x4,%rax
  1aa67e:	shl    $0x4,%rcx
  1aa682:	shl    $0x4,%rdi
  1aa686:	movupd (%r15,%rax,1),%xmm0
  1aa68c:	movupd (%r15,%rcx,1),%xmm1
  1aa692:	addpd  %xmm0,%xmm1
  1aa696:	movupd %xmm1,(%r15,%rdi,1)
  1aa69c:	add    $0x8,%rsi
  1aa6a0:	cmp    %rsi,%r8
  1aa6a3:	jne    1aa650 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x17d0>
  1aa6a5:	jmp    1aa6af <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x182f>
  1aa6a7:	mov    (%rsp),%r13
  1aa6ab:	shl    $0x4,%r13
  1aa6af:	mov    (%rsp),%rax
  1aa6b3:	mov    %rax,%rcx
  1aa6b6:	shl    $0x4,%rcx
  1aa6ba:	mov    %rcx,0x100(%rsp)
  1aa6c2:	add    %rcx,%rax
  1aa6c5:	xor    %ebp,%ebp
  1aa6c7:	xorpd  %xmm8,%xmm8
  1aa6cc:	mov    %r12,0x40(%rsp)
  1aa6d1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1aa6e0:	mov    (%r11,%rbp,1),%r14
  1aa6e4:	lea    (%r14,%r13,1),%rdi
  1aa6e8:	cmp    %rbx,%rdi
  1aa6eb:	jae    1be142 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x152c2>
  1aa6f1:	shl    $0x4,%rdi
  1aa6f5:	movupd (%r15,%rdi,1),%xmm0
  1aa6fb:	movapd %xmm0,%xmm1
  1aa6ff:	unpckhpd %xmm0,%xmm1
  1aa703:	ucomisd %xmm8,%xmm1
  1aa708:	jne    1aa720 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x18a0>
  1aa70a:	jp     1aa720 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x18a0>
  1aa70c:	andpd  %xmm6,%xmm0
  1aa710:	jmp    1aa7f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1970>
  1aa715:	data16 cs nopw 0x0(%rax,%rax,1)
  1aa720:	ucomisd %xmm8,%xmm0
  1aa725:	jne    1aa736 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x18b6>
  1aa727:	jp     1aa736 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x18b6>
  1aa729:	andpd  %xmm6,%xmm1
  1aa72d:	movapd %xmm1,%xmm0
  1aa731:	jmp    1aa7f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1970>
  1aa736:	movapd %xmm0,%xmm2
  1aa73a:	andpd  %xmm6,%xmm2
  1aa73e:	pshufd $0xee,%xmm2,%xmm3
  1aa743:	movapd %xmm2,%xmm4
  1aa747:	cmplesd %xmm3,%xmm4
  1aa74c:	movapd %xmm4,%xmm5
  1aa750:	andpd  %xmm3,%xmm5
  1aa754:	andnpd %xmm2,%xmm4
  1aa758:	orpd   %xmm5,%xmm4
  1aa75c:	movapd %xmm0,%xmm2
  1aa760:	cmpunordsd %xmm0,%xmm2
  1aa765:	movapd %xmm2,%xmm5
  1aa769:	andnpd %xmm4,%xmm5
  1aa76d:	andpd  %xmm3,%xmm2
  1aa771:	orpd   %xmm5,%xmm2
  1aa775:	ucomisd %xmm7,%xmm2
  1aa779:	jbe    1aa7a2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1922>
  1aa77b:	movsd  0x1fecf35(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1aa783:	ucomisd %xmm2,%xmm3
  1aa787:	jbe    1aa7a2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1922>
  1aa789:	mulpd  %xmm0,%xmm0
  1aa78d:	movapd %xmm0,%xmm1
  1aa791:	unpckhpd %xmm0,%xmm1
  1aa795:	addsd  %xmm0,%xmm1
  1aa799:	xorps  %xmm0,%xmm0
  1aa79c:	sqrtsd %xmm1,%xmm0
  1aa7a0:	jmp    1aa7f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1970>
  1aa7a2:	mov    %r13,%r12
  1aa7a5:	mov    %rax,%r13
  1aa7a8:	call   *0x2521422(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1aa7ae:	xorpd  %xmm8,%xmm8
  1aa7b3:	movsd  0x1fecef5(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1aa7bb:	movapd 0x1feb83d(%rip),%xmm6        # 2196000 <_fini+0x520>
  1aa7c3:	mov    %r13,%rax
  1aa7c6:	mov    %r12,%r13
  1aa7c9:	mov    0x40(%rsp),%r12
  1aa7ce:	mov    0x18(%rsp),%r8
  1aa7d3:	mov    0x1c8(%rsp),%r10
  1aa7db:	mov    0x28(%rsp),%r11
  1aa7e0:	mov    0x1b0(%rsp),%r9
  1aa7e8:	nopl   0x0(%rax,%rax,1)
  1aa7f0:	add    %rax,%r14
  1aa7f3:	cmp    %rbx,%r14
  1aa7f6:	jae    1be12f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x152af>
  1aa7fc:	shl    $0x4,%r14
  1aa800:	movsd  %xmm0,(%r15,%r14,1)
  1aa806:	movq   $0x0,0x8(%r15,%r14,1)
  1aa80f:	add    $0x8,%rbp
  1aa813:	cmp    %rbp,%r8
  1aa816:	jne    1aa6e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1860>
  1aa81c:	cmpb   $0x0,0x38(%rsp)
  1aa821:	mov    %rax,0x60(%rsp)
  1aa826:	je     1aa958 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1ad8>
  1aa82c:	mov    0x20(%rsp),%r14
  1aa831:	cmp    0x30(%rsp),%r14
  1aa836:	mov    (%rsp),%rbp
  1aa83a:	jae    1aa9fe <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1b7e>
  1aa840:	cmpq   $0x2,0x1e0(%rsp)
  1aa849:	jb     1bf251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163d1>
  1aa84f:	mov    0x10(%rsp),%rax
  1aa854:	lea    (%rax,%rax,8),%rdi
  1aa858:	mov    %r14,%r8
  1aa85b:	not    %r8
  1aa85e:	add    0x30(%rsp),%r8
  1aa863:	lea    (%r14,%r12,1),%r9
  1aa867:	xor    %ecx,%ecx
  1aa869:	mov    %rbx,%rdx
  1aa86c:	sub    %r9,%rdx
  1aa86f:	cmovb  %rcx,%rdx
  1aa873:	lea    (%r14,%rdi,1),%r10
  1aa877:	mov    %rbx,%rax
  1aa87a:	sub    %r10,%rax
  1aa87d:	cmovb  %rcx,%rax
  1aa881:	cmp    %rax,%rdx
  1aa884:	cmovb  %rdx,%rax
  1aa888:	cmp    %rax,%r8
  1aa88b:	cmovb  %r8,%rax
  1aa88f:	lea    0x1(%rax),%rcx
  1aa893:	mov    %r14,%rsi
  1aa896:	cmp    $0x22,%rcx
  1aa89a:	mov    %r14,0x20(%rsp)
  1aa89f:	ja     1ac2ea <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x346a>
  1aa8a5:	add    %rsi,%rdi
  1aa8a8:	mov    %rbp,%rax
  1aa8ab:	shl    $0x5,%rax
  1aa8af:	lea    (%rax,%rax,8),%rax
  1aa8b3:	mov    %rsi,%rcx
  1aa8b6:	shl    $0x4,%rcx
  1aa8ba:	add    %r15,%rcx
  1aa8bd:	add    %rsi,%r12
  1aa8c0:	imul   $0xf0,%rbp,%rdx
  1aa8c7:	mov    0x30(%rsp),%r8
  1aa8cc:	sub    %rsi,%r8
  1aa8cf:	mov    0x1b0(%rsp),%r9
  1aa8d7:	mov    0x28(%rsp),%r11
  1aa8dc:	mov    0x1c8(%rsp),%r10
  1aa8e4:	mov    0x20(%rsp),%r14
  1aa8e9:	nopl   0x0(%rax)
  1aa8f0:	cmp    %rbx,%r12
  1aa8f3:	jae    1bef2d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x160ad>
  1aa8f9:	cmp    %rbx,%rdi
  1aa8fc:	jae    1bef1d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1609d>
  1aa902:	mov    0x1d8(%rsp),%rsi
  1aa90a:	movupd 0x10(%rsi),%xmm0
  1aa90f:	movsd  (%rcx,%rdx,1),%xmm1
  1aa914:	movsd  0x8(%rcx,%rdx,1),%xmm2
  1aa91a:	unpcklpd %xmm1,%xmm1
  1aa91e:	mulpd  %xmm0,%xmm1
  1aa922:	shufpd $0x1,%xmm0,%xmm0
  1aa927:	unpcklpd %xmm2,%xmm2
  1aa92b:	mulpd  %xmm0,%xmm2
  1aa92f:	movapd %xmm1,%xmm0
  1aa933:	subpd  %xmm2,%xmm0
  1aa937:	addpd  %xmm1,%xmm2
  1aa93b:	movsd  %xmm0,%xmm2
  1aa93f:	movupd %xmm2,(%rcx,%rax,1)
  1aa944:	inc    %rdi
  1aa947:	add    $0x10,%rcx
  1aa94b:	inc    %r12
  1aa94e:	dec    %r8
  1aa951:	jne    1aa8f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1a70>
  1aa953:	jmp    1aa9f3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1b73>
  1aa958:	cmpq   $0x2,0x1e0(%rsp)
  1aa961:	mov    (%rsp),%rbp
  1aa965:	mov    0x20(%rsp),%r14
  1aa96a:	jb     1bf251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163d1>
  1aa970:	mov    0x10(%rsp),%rax
  1aa975:	lea    (%rax,%rax,8),%rcx
  1aa979:	xor    %edx,%edx
  1aa97b:	mov    0x18(%rsp),%r8
  1aa980:	mov    (%r11,%rdx,1),%rdi
  1aa984:	lea    (%rdi,%r12,1),%rax
  1aa988:	cmp    %rbx,%rax
  1aa98b:	jae    1beaeb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15c6b>
  1aa991:	add    %rcx,%rdi
  1aa994:	cmp    %rbx,%rdi
  1aa997:	jae    1beadb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15c5b>
  1aa99d:	shl    $0x4,%rax
  1aa9a1:	shl    $0x4,%rdi
  1aa9a5:	mov    0x1d8(%rsp),%rsi
  1aa9ad:	movupd 0x10(%rsi),%xmm0
  1aa9b2:	movsd  (%r15,%rax,1),%xmm1
  1aa9b8:	movsd  0x8(%r15,%rax,1),%xmm2
  1aa9bf:	unpcklpd %xmm1,%xmm1
  1aa9c3:	mulpd  %xmm0,%xmm1
  1aa9c7:	shufpd $0x1,%xmm0,%xmm0
  1aa9cc:	unpcklpd %xmm2,%xmm2
  1aa9d0:	mulpd  %xmm0,%xmm2
  1aa9d4:	movapd %xmm1,%xmm0
  1aa9d8:	subpd  %xmm2,%xmm0
  1aa9dc:	addpd  %xmm1,%xmm2
  1aa9e0:	movsd  %xmm0,%xmm2
  1aa9e4:	movupd %xmm2,(%r15,%rdi,1)
  1aa9ea:	add    $0x8,%rdx
  1aa9ee:	cmp    %rdx,%r8
  1aa9f1:	jne    1aa980 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1b00>
  1aa9f3:	cmpb   $0x0,0x38(%rsp)
  1aa9f8:	je     1aab30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1cb0>
  1aa9fe:	mov    0x30(%rsp),%rdx
  1aaa03:	lea    0x0(,%rbp,8),%rax
  1aaa0b:	add    %rbp,%rax
  1aaa0e:	cmp    %rdx,%r14
  1aaa11:	jae    1aabc1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1d41>
  1aaa17:	mov    0x10(%rsp),%rcx
  1aaa1c:	lea    (%rcx,%rcx,8),%rcx
  1aaa20:	lea    0x0(,%rax,2),%r13
  1aaa28:	add    %rbp,%r13
  1aaa2b:	mov    %r14,%r10
  1aaa2e:	not    %r10
  1aaa31:	add    %rdx,%r10
  1aaa34:	lea    (%r14,%rax,1),%r12
  1aaa38:	xor    %esi,%esi
  1aaa3a:	mov    %rbx,%rdx
  1aaa3d:	sub    %r12,%rdx
  1aaa40:	cmovb  %rsi,%rdx
  1aaa44:	mov    %r14,%rbp
  1aaa47:	lea    (%r14,%rcx,1),%r8
  1aaa4b:	mov    %rbx,%rdi
  1aaa4e:	mov    %r8,0x10(%rsp)
  1aaa53:	sub    %r8,%rdi
  1aaa56:	cmovb  %rsi,%rdi
  1aaa5a:	cmp    %rdi,%rdx
  1aaa5d:	cmovb  %rdx,%rdi
  1aaa61:	add    %r13,%r14
  1aaa64:	mov    %rbx,%rdx
  1aaa67:	sub    %r14,%rdx
  1aaa6a:	cmovb  %rsi,%rdx
  1aaa6e:	cmp    %rdx,%rdi
  1aaa71:	cmovb  %rdi,%rdx
  1aaa75:	cmp    %rdx,%r10
  1aaa78:	cmovb  %r10,%rdx
  1aaa7c:	lea    0x1(%rdx),%rsi
  1aaa80:	mov    %rbp,%r11
  1aaa83:	cmp    $0x4a,%rsi
  1aaa87:	ja     1ab36a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x24ea>
  1aaa8d:	mov    (%rsp),%rbp
  1aaa91:	imul   $0x130,%rbp,%rdx
  1aaa98:	mov    %r11,%rsi
  1aaa9b:	shl    $0x4,%rsi
  1aaa9f:	add    %r15,%rsi
  1aaaa2:	mov    %rbp,%rdi
  1aaaa5:	shl    $0x5,%rdi
  1aaaa9:	lea    (%rdi,%rdi,8),%r8
  1aaaad:	mov    0x100(%rsp),%rdi
  1aaab5:	lea    (%rdi,%rdi,8),%r9
  1aaab9:	mov    0x1c8(%rsp),%r10
  1aaac1:	mov    0x30(%rsp),%r14
  1aaac6:	cs nopw 0x0(%rax,%rax,1)
  1aaad0:	lea    (%rax,%r11,1),%rdi
  1aaad4:	cmp    %rbx,%rdi
  1aaad7:	jae    1bee28 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15fa8>
  1aaadd:	lea    (%rcx,%r11,1),%rdi
  1aaae1:	cmp    %rbx,%rdi
  1aaae4:	jae    1bee18 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f98>
  1aaaea:	lea    (%r11,%r13,1),%rdi
  1aaaee:	cmp    %rbx,%rdi
  1aaaf1:	jae    1bee08 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f88>
  1aaaf7:	inc    %r11
  1aaafa:	movupd (%rsi,%r9,1),%xmm0
  1aab00:	movupd (%rsi,%r8,1),%xmm1
  1aab06:	addpd  %xmm0,%xmm1
  1aab0a:	movupd %xmm1,(%rsi,%rdx,1)
  1aab0f:	add    $0x10,%rsi
  1aab13:	cmp    %r11,%r14
  1aab16:	jne    1aaad0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c50>
  1aab18:	mov    $0x1,%al
  1aab1a:	mov    %eax,0x10(%rsp)
  1aab1e:	mov    0x1b0(%rsp),%r9
  1aab26:	mov    0x28(%rsp),%r11
  1aab2b:	jmp    1aabd2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1d52>
  1aab30:	lea    0x0(,%rbp,8),%rdx
  1aab38:	add    %rbp,%rdx
  1aab3b:	mov    0x10(%rsp),%rax
  1aab40:	lea    (%rax,%rax,8),%rsi
  1aab44:	lea    0x0(,%rdx,2),%r13
  1aab4c:	add    %rbp,%r13
  1aab4f:	xor    %r8d,%r8d
  1aab52:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1aab60:	mov    (%r11,%r8,1),%rdi
  1aab64:	lea    (%rdi,%rdx,1),%rax
  1aab68:	cmp    %rbx,%rax
  1aab6b:	jae    1beda5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f25>
  1aab71:	lea    (%rdi,%rsi,1),%rcx
  1aab75:	cmp    %rbx,%rcx
  1aab78:	jae    1bed92 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f12>
  1aab7e:	add    %r13,%rdi
  1aab81:	cmp    %rbx,%rdi
  1aab84:	jae    1bed82 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f02>
  1aab8a:	shl    $0x4,%rax
  1aab8e:	shl    $0x4,%rcx
  1aab92:	shl    $0x4,%rdi
  1aab96:	movupd (%r15,%rax,1),%xmm0
  1aab9c:	movupd (%r15,%rcx,1),%xmm1
  1aaba2:	addpd  %xmm0,%xmm1
  1aaba6:	movupd %xmm1,(%r15,%rdi,1)
  1aabac:	add    $0x8,%r8
  1aabb0:	cmp    %r8,0x18(%rsp)
  1aabb5:	jne    1aab60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1ce0>
  1aabb7:	movl   $0x0,0x10(%rsp)
  1aabbf:	jmp    1aabd2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1d52>
  1aabc1:	lea    0x0(,%rax,2),%r13
  1aabc9:	add    %rbp,%r13
  1aabcc:	mov    $0x1,%al
  1aabce:	mov    %eax,0x10(%rsp)
  1aabd2:	lea    0x0(,%rbp,4),%rax
  1aabda:	lea    (%rax,%rax,4),%r14
  1aabde:	xor    %ebp,%ebp
  1aabe0:	xorpd  %xmm8,%xmm8
  1aabe5:	mov    0x18(%rsp),%rax
  1aabea:	nopw   0x0(%rax,%rax,1)
  1aabf0:	mov    (%r11,%rbp,1),%r12
  1aabf4:	lea    (%r12,%r13,1),%rdi
  1aabf8:	cmp    %rbx,%rdi
  1aabfb:	jae    1be178 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x152f8>
  1aac01:	shl    $0x4,%rdi
  1aac05:	movupd (%r15,%rdi,1),%xmm0
  1aac0b:	movapd %xmm0,%xmm1
  1aac0f:	unpckhpd %xmm0,%xmm1
  1aac13:	ucomisd %xmm8,%xmm1
  1aac18:	jne    1aac30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1db0>
  1aac1a:	jp     1aac30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1db0>
  1aac1c:	andpd  %xmm6,%xmm0
  1aac20:	jmp    1aacf0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1e70>
  1aac25:	data16 cs nopw 0x0(%rax,%rax,1)
  1aac30:	ucomisd %xmm8,%xmm0
  1aac35:	jne    1aac46 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1dc6>
  1aac37:	jp     1aac46 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1dc6>
  1aac39:	andpd  %xmm6,%xmm1
  1aac3d:	movapd %xmm1,%xmm0
  1aac41:	jmp    1aacf0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1e70>
  1aac46:	movapd %xmm0,%xmm2
  1aac4a:	andpd  %xmm6,%xmm2
  1aac4e:	pshufd $0xee,%xmm2,%xmm3
  1aac53:	movapd %xmm2,%xmm4
  1aac57:	cmplesd %xmm3,%xmm4
  1aac5c:	movapd %xmm4,%xmm5
  1aac60:	andpd  %xmm3,%xmm5
  1aac64:	andnpd %xmm2,%xmm4
  1aac68:	orpd   %xmm5,%xmm4
  1aac6c:	movapd %xmm0,%xmm2
  1aac70:	cmpunordsd %xmm0,%xmm2
  1aac75:	movapd %xmm2,%xmm5
  1aac79:	andnpd %xmm4,%xmm5
  1aac7d:	andpd  %xmm3,%xmm2
  1aac81:	orpd   %xmm5,%xmm2
  1aac85:	ucomisd %xmm7,%xmm2
  1aac89:	jbe    1aacb2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1e32>
  1aac8b:	movsd  0x1feca25(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1aac93:	ucomisd %xmm2,%xmm3
  1aac97:	jbe    1aacb2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1e32>
  1aac99:	mulpd  %xmm0,%xmm0
  1aac9d:	movapd %xmm0,%xmm1
  1aaca1:	unpckhpd %xmm0,%xmm1
  1aaca5:	addsd  %xmm0,%xmm1
  1aaca9:	xorps  %xmm0,%xmm0
  1aacac:	sqrtsd %xmm1,%xmm0
  1aacb0:	jmp    1aacf0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1e70>
  1aacb2:	call   *0x2520f18(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1aacb8:	xorpd  %xmm8,%xmm8
  1aacbd:	movsd  0x1fec9eb(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1aacc5:	movapd 0x1feb333(%rip),%xmm6        # 2196000 <_fini+0x520>
  1aaccd:	mov    0x18(%rsp),%rax
  1aacd2:	mov    0x1c8(%rsp),%r10
  1aacda:	mov    0x28(%rsp),%r11
  1aacdf:	mov    0x1b0(%rsp),%r9
  1aace7:	nopw   0x0(%rax,%rax,1)
  1aacf0:	add    %r14,%r12
  1aacf3:	cmp    %rbx,%r12
  1aacf6:	jae    1be165 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x152e5>
  1aacfc:	shl    $0x4,%r12
  1aad00:	movsd  %xmm0,(%r15,%r12,1)
  1aad06:	movq   $0x0,0x8(%r15,%r12,1)
  1aad0f:	add    $0x8,%rbp
  1aad13:	cmp    %rbp,%rax
  1aad16:	jne    1aabf0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1d70>
  1aad1c:	mov    0x10(%rsp),%ebp
  1aad20:	test   %bpl,%bpl
  1aad23:	je     1aae61 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1fe1>
  1aad29:	mov    0x30(%rsp),%r12
  1aad2e:	cmp    %r12,0x20(%rsp)
  1aad33:	mov    0x1c0(%rsp),%r13
  1aad3b:	jae    1aaf14 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2094>
  1aad41:	cmpq   $0x2,0x1e0(%rsp)
  1aad4a:	jb     1bf251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163d1>
  1aad50:	mov    0x48(%rsp),%rax
  1aad55:	mov    (%rsp),%rcx
  1aad59:	lea    (%rcx,%rax,4),%rdi
  1aad5d:	mov    0x20(%rsp),%r13
  1aad62:	mov    %r13,%r9
  1aad65:	not    %r9
  1aad68:	add    %r12,%r9
  1aad6b:	lea    (%r14,%r13,1),%r10
  1aad6f:	xor    %ecx,%ecx
  1aad71:	mov    %rbx,%rdx
  1aad74:	sub    %r10,%rdx
  1aad77:	cmovb  %rcx,%rdx
  1aad7b:	lea    (%rdi,%r13,1),%r11
  1aad7f:	mov    %rbx,%rax
  1aad82:	sub    %r11,%rax
  1aad85:	cmovb  %rcx,%rax
  1aad89:	cmp    %rax,%rdx
  1aad8c:	cmovb  %rdx,%rax
  1aad90:	cmp    %rax,%r9
  1aad93:	cmovb  %r9,%rax
  1aad97:	lea    0x1(%rax),%rcx
  1aad9b:	mov    %r13,%r8
  1aad9e:	cmp    $0x22,%rcx
  1aada2:	ja     1ac8c9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x3a49>
  1aada8:	add    %r8,%rdi
  1aadab:	mov    (%rsp),%rdx
  1aadaf:	imul   $0x150,%rdx,%rax
  1aadb6:	mov    %r8,%rcx
  1aadb9:	shl    $0x4,%rcx
  1aadbd:	add    %r15,%rcx
  1aadc0:	add    %r8,%r14
  1aadc3:	shl    $0x6,%rdx
  1aadc7:	lea    (%rdx,%rdx,4),%rdx
  1aadcb:	mov    0x30(%rsp),%r12
  1aadd0:	mov    %r12,%rsi
  1aadd3:	sub    %r8,%rsi
  1aadd6:	mov    0x1c0(%rsp),%r13
  1aadde:	mov    0x1d8(%rsp),%r8
  1aade6:	mov    0x1b0(%rsp),%r9
  1aadee:	mov    0x28(%rsp),%r11
  1aadf3:	mov    0x1c8(%rsp),%r10
  1aadfb:	nopl   0x0(%rax,%rax,1)
  1aae00:	cmp    %rbx,%r14
  1aae03:	jae    1bef9f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1611f>
  1aae09:	cmp    %rbx,%rdi
  1aae0c:	jae    1bef8f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1610f>
  1aae12:	movupd 0x10(%r8),%xmm0
  1aae18:	movsd  (%rcx,%rdx,1),%xmm1
  1aae1d:	movsd  0x8(%rcx,%rdx,1),%xmm2
  1aae23:	unpcklpd %xmm1,%xmm1
  1aae27:	mulpd  %xmm0,%xmm1
  1aae2b:	shufpd $0x1,%xmm0,%xmm0
  1aae30:	unpcklpd %xmm2,%xmm2
  1aae34:	mulpd  %xmm0,%xmm2
  1aae38:	movapd %xmm1,%xmm0
  1aae3c:	subpd  %xmm2,%xmm0
  1aae40:	addpd  %xmm1,%xmm2
  1aae44:	movsd  %xmm0,%xmm2
  1aae48:	movupd %xmm2,(%rcx,%rax,1)
  1aae4d:	inc    %rdi
  1aae50:	add    $0x10,%rcx
  1aae54:	inc    %r14
  1aae57:	dec    %rsi
  1aae5a:	jne    1aae00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1f80>
  1aae5c:	jmp    1aaf0b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x208b>
  1aae61:	cmpq   $0x2,0x1e0(%rsp)
  1aae6a:	mov    0x1c0(%rsp),%r13
  1aae72:	mov    0x1d8(%rsp),%rsi
  1aae7a:	mov    0x30(%rsp),%r12
  1aae7f:	jb     1bf251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163d1>
  1aae85:	mov    0x48(%rsp),%rax
  1aae8a:	mov    (%rsp),%rcx
  1aae8e:	lea    (%rcx,%rax,4),%rcx
  1aae92:	xor    %edx,%edx
  1aae94:	mov    0x18(%rsp),%r8
  1aae99:	nopl   0x0(%rax)
  1aaea0:	mov    (%r11,%rdx,1),%rdi
  1aaea4:	lea    (%rdi,%r14,1),%rax
  1aaea8:	cmp    %rbx,%rax
  1aaeab:	jae    1beb0e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15c8e>
  1aaeb1:	add    %rcx,%rdi
  1aaeb4:	cmp    %rbx,%rdi
  1aaeb7:	jae    1beafe <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15c7e>
  1aaebd:	shl    $0x4,%rax
  1aaec1:	shl    $0x4,%rdi
  1aaec5:	movupd 0x10(%rsi),%xmm0
  1aaeca:	movsd  (%r15,%rax,1),%xmm1
  1aaed0:	movsd  0x8(%r15,%rax,1),%xmm2
  1aaed7:	unpcklpd %xmm1,%xmm1
  1aaedb:	mulpd  %xmm0,%xmm1
  1aaedf:	shufpd $0x1,%xmm0,%xmm0
  1aaee4:	unpcklpd %xmm2,%xmm2
  1aaee8:	mulpd  %xmm0,%xmm2
  1aaeec:	movapd %xmm1,%xmm0
  1aaef0:	subpd  %xmm2,%xmm0
  1aaef4:	addpd  %xmm1,%xmm2
  1aaef8:	movsd  %xmm0,%xmm2
  1aaefc:	movupd %xmm2,(%r15,%rdi,1)
  1aaf02:	add    $0x8,%rdx
  1aaf06:	cmp    %rdx,%r8
  1aaf09:	jne    1aaea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2020>
  1aaf0b:	test   %bpl,%bpl
  1aaf0e:	je     1ab2d7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2457>
  1aaf14:	mov    0x20(%rsp),%rdi
  1aaf19:	cmp    %r12,%rdi
  1aaf1c:	jae    1ab350 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x24d0>
  1aaf22:	mov    0x48(%rsp),%rax
  1aaf27:	mov    (%rsp),%rcx
  1aaf2b:	lea    (%rcx,%rax,4),%rax
  1aaf2f:	lea    (%rcx,%rax,1),%rdx
  1aaf33:	mov    %rdi,%r10
  1aaf36:	not    %r10
  1aaf39:	add    %r12,%r10
  1aaf3c:	mov    0x60(%rsp),%rcx
  1aaf41:	lea    (%rdi,%rcx,1),%rbp
  1aaf45:	xor    %esi,%esi
  1aaf47:	mov    %rbx,%rcx
  1aaf4a:	sub    %rbp,%rcx
  1aaf4d:	cmovb  %rsi,%rcx
  1aaf51:	mov    %rdi,%r11
  1aaf54:	lea    (%rdi,%rax,1),%r14
  1aaf58:	mov    %rbx,%rdi
  1aaf5b:	sub    %r14,%rdi
  1aaf5e:	cmovb  %rsi,%rdi
  1aaf62:	cmp    %rdi,%rcx
  1aaf65:	cmovb  %rcx,%rdi
  1aaf69:	lea    (%r11,%rdx,1),%r12
  1aaf6d:	mov    %rbx,%rcx
  1aaf70:	sub    %r12,%rcx
  1aaf73:	cmovb  %rsi,%rcx
  1aaf77:	cmp    %rcx,%rdi
  1aaf7a:	cmovb  %rdi,%rcx
  1aaf7e:	cmp    %rcx,%r10
  1aaf81:	cmovb  %r10,%rcx
  1aaf85:	lea    0x1(%rcx),%rsi
  1aaf89:	cmp    $0x4a,%rsi
  1aaf8d:	jbe    1ad656 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x47d6>
  1aaf93:	xor    %esi,%esi
  1aaf95:	mov    %rbx,%rdi
  1aaf98:	sub    %rbp,%rdi
  1aaf9b:	cmovb  %rsi,%rdi
  1aaf9f:	mov    %rbx,%r8
  1aafa2:	sub    %r14,%r8
  1aafa5:	cmovb  %rsi,%r8
  1aafa9:	cmp    %r8,%rdi
  1aafac:	cmovb  %rdi,%r8
  1aafb0:	mov    %rbx,%r9
  1aafb3:	sub    %r12,%r9
  1aafb6:	cmovb  %rsi,%r9
  1aafba:	cmp    %r9,%r8
  1aafbd:	cmovb  %r8,%r9
  1aafc1:	cmp    %r9,%r10
  1aafc4:	cmovb  %r10,%r9
  1aafc8:	imul   $0x110,(%rsp),%rsi
  1aafd0:	mov    %r11,%rdi
  1aafd3:	shl    $0x4,%rdi
  1aafd7:	lea    (%r15,%rsi,1),%r8
  1aafdb:	lea    (%rdi,%r8,1),%rbx
  1aafdf:	add    $0x8,%rbx
  1aafe3:	add    %rdi,%r8
  1aafe6:	mov    %r9,%r13
  1aafe9:	shl    $0x4,%r13
  1aafed:	add    %r13,%r8
  1aaff0:	add    $0x8,%r8
  1aaff4:	cmp    %rbx,%r8
  1aaff7:	jb     1ad649 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x47c9>
  1aaffd:	mov    %rbp,%r11
  1ab000:	imul   $0x150,(%rsp),%r8
  1ab008:	lea    (%r15,%r8,1),%rbx
  1ab00c:	lea    (%rdi,%rbx,1),%rbp
  1ab010:	add    $0x8,%rbp
  1ab014:	add    %rdi,%rbx
  1ab017:	add    %r13,%rbx
  1ab01a:	add    $0x8,%rbx
  1ab01e:	cmp    %rbp,%rbx
  1ab021:	jb     1ad649 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x47c9>
  1ab027:	movabs $0xfffffffffffffff,%rbx
  1ab031:	cmp    %rbx,%r9
  1ab034:	ja     1ad649 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x47c9>
  1ab03a:	imul   $0x160,(%rsp),%r9
  1ab042:	xor    %ebp,%ebp
  1ab044:	mov    0x8(%rsp),%rbx
  1ab049:	mov    %rbx,%r13
  1ab04c:	sub    %r11,%r13
  1ab04f:	cmovb  %rbp,%r13
  1ab053:	mov    %rbx,%r11
  1ab056:	sub    %r14,%r11
  1ab059:	cmovb  %rbp,%r11
  1ab05d:	cmp    %r11,%r13
  1ab060:	cmovb  %r13,%r11
  1ab064:	sub    %r12,%rbx
  1ab067:	cmovb  %rbp,%rbx
  1ab06b:	cmp    %rbx,%r11
  1ab06e:	cmovb  %r11,%rbx
  1ab072:	mov    %r9,0x130(%rsp)
  1ab07a:	lea    (%r9,%rdi,1),%r14
  1ab07e:	cmp    %rbx,%r10
  1ab081:	cmovb  %r10,%rbx
  1ab085:	lea    (%r15,%r14,1),%rbp
  1ab089:	shl    $0x4,%rbx
  1ab08d:	lea    (%rbx,%rbp,1),%r11
  1ab091:	add    $0x8,%r11
  1ab095:	lea    0x8(%r15,%r14,1),%r13
  1ab09a:	lea    0x10(%rbx,%rbp,1),%r9
  1ab09f:	mov    %r9,0xe0(%rsp)
  1ab0a7:	lea    (%rsi,%rdi,1),%r12
  1ab0ab:	lea    (%r15,%r12,1),%r14
  1ab0af:	lea    0x8(%r15,%r12,1),%r12
  1ab0b4:	mov    %r12,0x18(%rsp)
  1ab0b9:	lea    0x10(%rbx,%r14,1),%r12
  1ab0be:	mov    %r14,0xb0(%rsp)
  1ab0c6:	lea    (%r8,%rdi,1),%r10
  1ab0ca:	lea    (%r15,%r10,1),%r9
  1ab0ce:	mov    %r9,0x38(%rsp)
  1ab0d3:	lea    0x8(%r15,%r10,1),%r9
  1ab0d8:	mov    %r9,0x40(%rsp)
  1ab0dd:	mov    0x38(%rsp),%r9
  1ab0e2:	lea    0x10(%rbx,%r9,1),%r10
  1ab0e7:	mov    %r10,0x58(%rsp)
  1ab0ec:	lea    0x8(%rbx,%r14,1),%r14
  1ab0f1:	mov    %r14,0xd0(%rsp)
  1ab0f9:	add    %r9,%rbx
  1ab0fc:	add    $0x8,%rbx
  1ab100:	mov    %rbx,0x10(%rsp)
  1ab105:	mov    0xe0(%rsp),%r14
  1ab10d:	cmp    %r14,%rbp
  1ab110:	setb   0x48(%rsp)
  1ab115:	cmp    %r11,%r13
  1ab118:	setb   0x100(%rsp)
  1ab120:	cmp    %r12,%rbp
  1ab123:	setb   0x88(%rsp)
  1ab12b:	cmp    %r11,0x18(%rsp)
  1ab130:	setb   0x78(%rsp)
  1ab135:	mov    0x58(%rsp),%r9
  1ab13a:	cmp    %r9,%rbp
  1ab13d:	setb   0x80(%rsp)
  1ab145:	cmp    %r11,0x40(%rsp)
  1ab14a:	setb   0x98(%rsp)
  1ab152:	mov    0xd0(%rsp),%r10
  1ab15a:	cmp    %r10,%rbp
  1ab15d:	setb   0xc8(%rsp)
  1ab165:	mov    0xb0(%rsp),%rbx
  1ab16d:	cmp    %r11,%rbx
  1ab170:	setb   0xa8(%rsp)
  1ab178:	cmp    0x10(%rsp),%rbp
  1ab17d:	setb   0xf8(%rsp)
  1ab185:	mov    0x38(%rsp),%rbp
  1ab18a:	cmp    %r11,%rbp
  1ab18d:	setb   0x118(%rsp)
  1ab195:	cmp    %r12,%r13
  1ab198:	setb   0x120(%rsp)
  1ab1a0:	cmp    %r14,0x18(%rsp)
  1ab1a5:	setb   0x18(%rsp)
  1ab1aa:	cmp    %r9,%r13
  1ab1ad:	setb   0x58(%rsp)
  1ab1b2:	cmp    %r14,0x40(%rsp)
  1ab1b7:	setb   0x40(%rsp)
  1ab1bc:	cmp    %r10,%r13
  1ab1bf:	setb   0xd0(%rsp)
  1ab1c7:	cmp    %r14,%rbx
  1ab1ca:	setb   %r9b
  1ab1ce:	cmp    0x10(%rsp),%r13
  1ab1d3:	setb   %r11b
  1ab1d7:	cmp    %r14,%rbp
  1ab1da:	setb   %r10b
  1ab1de:	movzbl 0x100(%rsp),%ebx
  1ab1e6:	test   %bl,0x48(%rsp)
  1ab1ea:	jne    1ad649 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x47c9>
  1ab1f0:	movzbl 0x78(%rsp),%ebx
  1ab1f5:	and    %bl,0x88(%rsp)
  1ab1fc:	jne    1ad649 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x47c9>
  1ab202:	movzbl 0x98(%rsp),%ebx
  1ab20a:	and    %bl,0x80(%rsp)
  1ab211:	mov    0x8(%rsp),%rbx
  1ab216:	mov    0x1c0(%rsp),%r13
  1ab21e:	mov    0x50(%rsp),%r14
  1ab223:	jne    1aee6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5fef>
  1ab229:	movzbl 0xa8(%rsp),%r12d
  1ab232:	and    %r12b,0xc8(%rsp)
  1ab23a:	jne    1aee6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5fef>
  1ab240:	movzbl 0x118(%rsp),%r12d
  1ab249:	and    %r12b,0xf8(%rsp)
  1ab251:	jne    1aee6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5fef>
  1ab257:	movzbl 0x18(%rsp),%r12d
  1ab25d:	and    %r12b,0x120(%rsp)
  1ab265:	jne    1aee6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5fef>
  1ab26b:	movzbl 0x40(%rsp),%r12d
  1ab271:	and    %r12b,0x58(%rsp)
  1ab276:	jne    1aee6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5fef>
  1ab27c:	and    %r9b,0xd0(%rsp)
  1ab284:	jne    1aee6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5fef>
  1ab28a:	and    %r10b,%r11b
  1ab28d:	jne    1aee6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5fef>
  1ab293:	and    $0xfffffffffffffffe,%rcx
  1ab297:	add    %rcx,0x20(%rsp)
  1ab29c:	add    %r15,%rdi
  1ab29f:	mov    0x28(%rsp),%r11
  1ab2a4:	mov    0x1c8(%rsp),%r10
  1ab2ac:	mov    0x130(%rsp),%r9
  1ab2b4:	movupd (%rdi,%rsi,1),%xmm0
  1ab2b9:	movupd (%rdi,%r8,1),%xmm1
  1ab2bf:	addpd  %xmm0,%xmm1
  1ab2c3:	movupd %xmm1,(%rdi,%r9,1)
  1ab2c9:	add    $0x10,%rdi
  1ab2cd:	dec    %rcx
  1ab2d0:	jne    1ab2b4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2434>
  1ab2d2:	jmp    1ad668 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x47e8>
  1ab2d7:	mov    0x48(%rsp),%rax
  1ab2dc:	mov    (%rsp),%rcx
  1ab2e0:	lea    (%rcx,%rax,4),%rsi
  1ab2e4:	lea    (%rcx,%rsi,1),%rdx
  1ab2e8:	xor    %r8d,%r8d
  1ab2eb:	mov    0x50(%rsp),%r14
  1ab2f0:	mov    (%r11,%r8,1),%rdi
  1ab2f4:	mov    0x60(%rsp),%rax
  1ab2f9:	add    %rdi,%rax
  1ab2fc:	cmp    %rbx,%rax
  1ab2ff:	jae    1beddb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f5b>
  1ab305:	lea    (%rdi,%rsi,1),%rcx
  1ab309:	cmp    %rbx,%rcx
  1ab30c:	jae    1bedc8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f48>
  1ab312:	add    %rdx,%rdi
  1ab315:	cmp    %rbx,%rdi
  1ab318:	jae    1bedb8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f38>
  1ab31e:	shl    $0x4,%rax
  1ab322:	shl    $0x4,%rcx
  1ab326:	shl    $0x4,%rdi
  1ab32a:	movupd (%r15,%rax,1),%xmm0
  1ab330:	movupd (%r15,%rcx,1),%xmm1
  1ab336:	addpd  %xmm0,%xmm1
  1ab33a:	movupd %xmm1,(%r15,%rdi,1)
  1ab340:	add    $0x8,%r8
  1ab344:	cmp    %r8,0x18(%rsp)
  1ab349:	jne    1ab2f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2470>
  1ab34b:	jmp    1ad6e6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4866>
  1ab350:	mov    0x48(%rsp),%rax
  1ab355:	mov    (%rsp),%rcx
  1ab359:	lea    (%rcx,%rax,4),%rdx
  1ab35d:	add    %rcx,%rdx
  1ab360:	mov    0x50(%rsp),%r14
  1ab365:	jmp    1ad6e6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4866>
  1ab36a:	xor    %esi,%esi
  1ab36c:	mov    %rbx,%rdi
  1ab36f:	sub    %r12,%rdi
  1ab372:	cmovb  %rsi,%rdi
  1ab376:	mov    %rbx,%r8
  1ab379:	sub    0x10(%rsp),%r8
  1ab37e:	cmovb  %rsi,%r8
  1ab382:	cmp    %r8,%rdi
  1ab385:	cmovb  %rdi,%r8
  1ab389:	mov    %rbx,%r9
  1ab38c:	sub    %r14,%r9
  1ab38f:	cmovb  %rsi,%r9
  1ab393:	cmp    %r9,%r8
  1ab396:	cmovb  %r8,%r9
  1ab39a:	cmp    %r9,%r10
  1ab39d:	cmovb  %r10,%r9
  1ab3a1:	mov    0x100(%rsp),%rsi
  1ab3a9:	lea    (%rsi,%rsi,8),%rsi
  1ab3ad:	mov    %rbp,%rdi
  1ab3b0:	shl    $0x4,%rdi
  1ab3b4:	mov    %rsi,0xd0(%rsp)
  1ab3bc:	lea    (%r15,%rsi,1),%r8
  1ab3c0:	lea    (%rdi,%r8,1),%rbx
  1ab3c4:	add    $0x8,%rbx
  1ab3c8:	add    %rdi,%r8
  1ab3cb:	mov    %r9,%rsi
  1ab3ce:	shl    $0x4,%rsi
  1ab3d2:	add    %rsi,%r8
  1ab3d5:	add    $0x8,%r8
  1ab3d9:	mov    %rbp,%r11
  1ab3dc:	cmp    %rbx,%r8
  1ab3df:	mov    0x8(%rsp),%rbx
  1ab3e4:	jb     1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab3ea:	mov    (%rsp),%r8
  1ab3ee:	shl    $0x5,%r8
  1ab3f2:	lea    (%r8,%r8,8),%r8
  1ab3f6:	mov    %r8,0xe0(%rsp)
  1ab3fe:	add    %r15,%r8
  1ab401:	lea    (%rdi,%r8,1),%rbx
  1ab405:	add    $0x8,%rbx
  1ab409:	add    %rdi,%r8
  1ab40c:	add    %r8,%rsi
  1ab40f:	add    $0x8,%rsi
  1ab413:	mov    %rbp,%r11
  1ab416:	cmp    %rbx,%rsi
  1ab419:	mov    0x8(%rsp),%rbx
  1ab41e:	jb     1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab424:	movabs $0xfffffffffffffff,%rsi
  1ab42e:	mov    %rbp,%r11
  1ab431:	cmp    %rsi,%r9
  1ab434:	ja     1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab43a:	mov    %r12,%r9
  1ab43d:	imul   $0x130,(%rsp),%r12
  1ab445:	xor    %esi,%esi
  1ab447:	mov    %rbx,%r8
  1ab44a:	sub    %r9,%r8
  1ab44d:	cmovb  %rsi,%r8
  1ab451:	mov    %rbx,%r11
  1ab454:	sub    0x10(%rsp),%r11
  1ab459:	cmovb  %rsi,%r11
  1ab45d:	cmp    %r11,%r8
  1ab460:	cmovb  %r8,%r11
  1ab464:	mov    %rbx,%r8
  1ab467:	sub    %r14,%r8
  1ab46a:	cmovb  %rsi,%r8
  1ab46e:	lea    (%r12,%rdi,1),%rbx
  1ab472:	cmp    %r8,%r11
  1ab475:	cmovb  %r11,%r8
  1ab479:	lea    (%r15,%rbx,1),%r14
  1ab47d:	cmp    %r8,%r10
  1ab480:	cmovb  %r10,%r8
  1ab484:	shl    $0x4,%r8
  1ab488:	lea    (%r8,%r14,1),%rsi
  1ab48c:	add    $0x8,%rsi
  1ab490:	lea    0x8(%r15,%rbx,1),%r11
  1ab495:	lea    (%r8,%r14,1),%r9
  1ab499:	add    $0x10,%r9
  1ab49d:	mov    %r9,0x78(%rsp)
  1ab4a2:	mov    %rax,%rbx
  1ab4a5:	shl    $0x4,%rbx
  1ab4a9:	add    %rdi,%rbx
  1ab4ac:	lea    (%r15,%rbx,1),%r9
  1ab4b0:	add    %r15,%rbx
  1ab4b3:	add    $0x8,%rbx
  1ab4b7:	mov    %rbx,0x40(%rsp)
  1ab4bc:	lea    0x10(%r8,%r9,1),%r10
  1ab4c1:	mov    %r10,0xc8(%rsp)
  1ab4c9:	mov    %r9,%r10
  1ab4cc:	mov    %r9,0x98(%rsp)
  1ab4d4:	mov    %rax,%r9
  1ab4d7:	shl    $0x5,%r9
  1ab4db:	add    %rdi,%r9
  1ab4de:	lea    (%r15,%r9,1),%rbx
  1ab4e2:	add    %r15,%r9
  1ab4e5:	add    $0x8,%r9
  1ab4e9:	mov    %r9,0xb0(%rsp)
  1ab4f1:	mov    %rbx,0x38(%rsp)
  1ab4f6:	lea    0x10(%r8,%rbx,1),%r9
  1ab4fb:	mov    %r9,0x80(%rsp)
  1ab503:	lea    0x8(%r8,%r10,1),%r10
  1ab508:	mov    %r10,0xa8(%rsp)
  1ab510:	add    %rbx,%r8
  1ab513:	add    $0x8,%r8
  1ab517:	mov    %r8,0x10(%rsp)
  1ab51c:	mov    0x78(%rsp),%r10
  1ab521:	cmp    %r10,%r14
  1ab524:	setb   0x58(%rsp)
  1ab529:	cmp    %rsi,%r11
  1ab52c:	setb   0x88(%rsp)
  1ab534:	mov    0xc8(%rsp),%rbx
  1ab53c:	cmp    %rbx,%r14
  1ab53f:	setb   0xf8(%rsp)
  1ab547:	cmp    %rsi,0x40(%rsp)
  1ab54c:	setb   0x118(%rsp)
  1ab554:	cmp    %r9,%r14
  1ab557:	setb   0x120(%rsp)
  1ab55f:	cmp    %rsi,0xb0(%rsp)
  1ab567:	setb   0x130(%rsp)
  1ab56f:	mov    0xa8(%rsp),%r9
  1ab577:	cmp    %r9,%r14
  1ab57a:	setb   0x140(%rsp)
  1ab582:	mov    0x98(%rsp),%r8
  1ab58a:	cmp    %rsi,%r8
  1ab58d:	setb   0x148(%rsp)
  1ab595:	cmp    0x10(%rsp),%r14
  1ab59a:	setb   0x158(%rsp)
  1ab5a2:	cmp    %rsi,0x38(%rsp)
  1ab5a7:	setb   0xa7(%rsp)
  1ab5af:	cmp    %rbx,%r11
  1ab5b2:	mov    0x8(%rsp),%rbx
  1ab5b7:	setb   0xc8(%rsp)
  1ab5bf:	cmp    %r10,0x40(%rsp)
  1ab5c4:	setb   0x40(%rsp)
  1ab5c9:	cmp    0x80(%rsp),%r11
  1ab5d1:	setb   %r14b
  1ab5d5:	cmp    %r10,0xb0(%rsp)
  1ab5dd:	setb   0xb0(%rsp)
  1ab5e5:	cmp    %r9,%r11
  1ab5e8:	setb   0x80(%rsp)
  1ab5f0:	cmp    %r10,%r8
  1ab5f3:	setb   %r9b
  1ab5f7:	cmp    0x10(%rsp),%r11
  1ab5fc:	setb   0x98(%rsp)
  1ab604:	cmp    %r10,0x38(%rsp)
  1ab609:	mov    %rbp,%r11
  1ab60c:	setb   0x10(%rsp)
  1ab611:	movzbl 0x88(%rsp),%r8d
  1ab61a:	test   %r8b,0x58(%rsp)
  1ab61f:	jne    1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab625:	mov    %rbp,%r11
  1ab628:	movzbl 0x118(%rsp),%r8d
  1ab631:	and    %r8b,0xf8(%rsp)
  1ab639:	jne    1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab63f:	mov    %rbp,%r11
  1ab642:	movzbl 0x130(%rsp),%r10d
  1ab64b:	and    %r10b,0x120(%rsp)
  1ab653:	jne    1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab659:	mov    %rbp,%r11
  1ab65c:	movzbl 0x148(%rsp),%r10d
  1ab665:	and    %r10b,0x140(%rsp)
  1ab66d:	jne    1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab673:	mov    %rbp,%r11
  1ab676:	movzbl 0xa7(%rsp),%r10d
  1ab67f:	and    %r10b,0x158(%rsp)
  1ab687:	jne    1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab68d:	mov    %rbp,%r11
  1ab690:	movzbl 0x40(%rsp),%r10d
  1ab696:	and    %r10b,0xc8(%rsp)
  1ab69e:	jne    1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab6a4:	mov    %rbp,%r11
  1ab6a7:	and    0xb0(%rsp),%r14b
  1ab6af:	jne    1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab6b5:	mov    %rbp,%r11
  1ab6b8:	and    %r9b,0x80(%rsp)
  1ab6c0:	jne    1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab6c6:	mov    %rbp,%r11
  1ab6c9:	movzbl 0x98(%rsp),%esi
  1ab6d1:	and    0x10(%rsp),%sil
  1ab6d6:	jne    1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab6dc:	and    $0xfffffffffffffffe,%rdx
  1ab6e0:	lea    (%rdx,%rbp,1),%r11
  1ab6e4:	add    %r15,%rdi
  1ab6e7:	mov    0xd0(%rsp),%rsi
  1ab6ef:	mov    0xe0(%rsp),%r8
  1ab6f7:	movupd (%rdi,%rsi,1),%xmm0
  1ab6fc:	movupd (%rdi,%r8,1),%xmm1
  1ab702:	addpd  %xmm0,%xmm1
  1ab706:	movupd %xmm1,(%rdi,%r12,1)
  1ab70c:	add    $0x10,%rdi
  1ab710:	dec    %rdx
  1ab713:	jne    1ab6f7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2877>
  1ab715:	jmp    1aaa8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1c0d>
  1ab71a:	xor    %ecx,%ecx
  1ab71c:	mov    %rbx,%rdx
  1ab71f:	sub    0x58(%rsp),%rdx
  1ab724:	cmovb  %rcx,%rdx
  1ab728:	mov    0x40(%rsp),%r8
  1ab72d:	cmp    %r8,%rdx
  1ab730:	cmovae %r8,%rdx
  1ab734:	lea    (%r14,%rax,1),%r9
  1ab738:	mov    %rbx,%r8
  1ab73b:	mov    %r9,0x80(%rsp)
  1ab743:	sub    %r9,%r8
  1ab746:	cmovb  %rcx,%r8
  1ab74a:	cmp    %r8,%rdx
  1ab74d:	cmovb  %rdx,%r8
  1ab751:	mov    %rbx,%r11
  1ab754:	sub    %r14,%r11
  1ab757:	cmovb  %rcx,%r11
  1ab75b:	cmp    %r11,%r8
  1ab75e:	cmovb  %r8,%r11
  1ab762:	mov    0x60(%rsp),%rcx
  1ab767:	cmp    %r11,%rcx
  1ab76a:	cmovb  %rcx,%r11
  1ab76e:	mov    %r14,%rdx
  1ab771:	shl    $0x4,%rdx
  1ab775:	lea    (%r15,%rdx,1),%r9
  1ab779:	lea    (%r15,%rdx,1),%r12
  1ab77d:	add    $0x8,%r12
  1ab781:	shl    $0x4,%r11
  1ab785:	lea    (%r11,%r9,1),%r8
  1ab789:	add    $0x8,%r8
  1ab78d:	mov    %r14,%rcx
  1ab790:	mov    %r12,0x78(%rsp)
  1ab795:	cmp    %r12,%r8
  1ab798:	jb     1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1ab79e:	mov    (%rsp),%rbp
  1ab7a2:	shl    $0x5,%rbp
  1ab7a6:	lea    (%r9,%rbp,1),%r8
  1ab7aa:	add    $0x8,%r8
  1ab7ae:	lea    (%r8,%r11,1),%r12
  1ab7b2:	mov    %r14,%rcx
  1ab7b5:	cmp    %r8,%r12
  1ab7b8:	jb     1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1ab7be:	lea    (%r10,%r9,1),%r8
  1ab7c2:	add    $0x8,%r8
  1ab7c6:	add    %r8,%r11
  1ab7c9:	mov    %r14,%rcx
  1ab7cc:	cmp    %r8,%r11
  1ab7cf:	jb     1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1ab7d5:	mov    (%rsp),%r12
  1ab7d9:	shl    $0x7,%r12
  1ab7dd:	xor    %r11d,%r11d
  1ab7e0:	mov    %rbx,%r8
  1ab7e3:	sub    0x58(%rsp),%r8
  1ab7e8:	cmovb  %r11,%r8
  1ab7ec:	lea    (%r12,%rdx,1),%rcx
  1ab7f0:	mov    %rcx,0x98(%rsp)
  1ab7f8:	mov    0x40(%rsp),%rcx
  1ab7fd:	cmp    %rcx,%r8
  1ab800:	cmovae %rcx,%r8
  1ab804:	mov    %rbx,%rcx
  1ab807:	sub    0x80(%rsp),%rcx
  1ab80f:	cmovb  %r11,%rcx
  1ab813:	mov    0x98(%rsp),%r11
  1ab81b:	add    %r15,%r11
  1ab81e:	mov    %r11,0x58(%rsp)
  1ab823:	cmp    %rcx,%r8
  1ab826:	cmovb  %r8,%rcx
  1ab82a:	mov    %rbx,%r8
  1ab82d:	sub    %r14,%r8
  1ab830:	mov    $0x0,%r11d
  1ab836:	cmovb  %r11,%r8
  1ab83a:	mov    0x98(%rsp),%r11
  1ab842:	add    %r15,%r11
  1ab845:	add    $0x8,%r11
  1ab849:	mov    %r11,0x80(%rsp)
  1ab851:	cmp    %r8,%rcx
  1ab854:	cmovb  %rcx,%r8
  1ab858:	mov    0x60(%rsp),%rcx
  1ab85d:	cmp    %r8,%rcx
  1ab860:	cmovb  %rcx,%r8
  1ab864:	shl    $0x4,%r8
  1ab868:	mov    0x58(%rsp),%rcx
  1ab86d:	add    %r8,%rcx
  1ab870:	add    $0x8,%rcx
  1ab874:	mov    %rcx,0x168(%rsp)
  1ab87c:	lea    (%r15,%rdx,1),%rcx
  1ab880:	mov    %rcx,0x148(%rsp)
  1ab888:	lea    (%rcx,%r8,1),%r11
  1ab88c:	lea    0x10(%r12,%r11,1),%rcx
  1ab891:	mov    %rcx,0x170(%rsp)
  1ab899:	mov    0x148(%rsp),%rcx
  1ab8a1:	lea    0x10(%r8,%rcx,1),%rcx
  1ab8a6:	mov    %rcx,0x118(%rsp)
  1ab8ae:	lea    (%rdx,%rbp,1),%r11
  1ab8b2:	lea    (%r15,%r11,1),%rcx
  1ab8b6:	add    $0x8,%rcx
  1ab8ba:	mov    %rcx,0x98(%rsp)
  1ab8c2:	add    %r15,%r11
  1ab8c5:	lea    (%r8,%r11,1),%rcx
  1ab8c9:	add    $0x10,%rcx
  1ab8cd:	mov    %rcx,0x120(%rsp)
  1ab8d5:	add    %r10,%rdx
  1ab8d8:	lea    (%r15,%rdx,1),%rcx
  1ab8dc:	add    $0x8,%rcx
  1ab8e0:	mov    %rcx,0xa8(%rsp)
  1ab8e8:	add    %r15,%rdx
  1ab8eb:	lea    (%r8,%rdx,1),%rcx
  1ab8ef:	add    $0x10,%rcx
  1ab8f3:	mov    %rcx,0x130(%rsp)
  1ab8fb:	lea    0x8(%r8,%r11,1),%rcx
  1ab900:	mov    %rcx,0xf8(%rsp)
  1ab908:	lea    0x8(%r8,%rdx,1),%rcx
  1ab90d:	mov    %rcx,0xc8(%rsp)
  1ab915:	mov    0x148(%rsp),%rdx
  1ab91d:	lea    0x8(%r8,%rdx,1),%rcx
  1ab922:	mov    %rcx,0x140(%rsp)
  1ab92a:	mov    0x170(%rsp),%r11
  1ab932:	mov    0x58(%rsp),%r8
  1ab937:	cmp    %r11,%r8
  1ab93a:	setb   0x158(%rsp)
  1ab942:	mov    0x168(%rsp),%rcx
  1ab94a:	cmp    %rcx,0x80(%rsp)
  1ab952:	setb   0xa7(%rsp)
  1ab95a:	cmp    0x118(%rsp),%r8
  1ab962:	setb   0x12f(%rsp)
  1ab96a:	cmp    %rcx,0x78(%rsp)
  1ab96f:	setb   0x12e(%rsp)
  1ab977:	cmp    0x120(%rsp),%r8
  1ab97f:	setb   0x12d(%rsp)
  1ab987:	cmp    %rcx,0x98(%rsp)
  1ab98f:	setb   0x12c(%rsp)
  1ab997:	cmp    0x130(%rsp),%r8
  1ab99f:	setb   0x12b(%rsp)
  1ab9a7:	cmp    %rcx,0xa8(%rsp)
  1ab9af:	setb   0x12a(%rsp)
  1ab9b7:	cmp    0x140(%rsp),%r8
  1ab9bf:	setb   0x129(%rsp)
  1ab9c7:	cmp    %rcx,%rdx
  1ab9ca:	setb   0x128(%rsp)
  1ab9d2:	cmp    0xf8(%rsp),%r8
  1ab9da:	setb   0x157(%rsp)
  1ab9e2:	mov    %rdx,%r8
  1ab9e5:	add    %rbp,%rdx
  1ab9e8:	mov    %rdx,0x160(%rsp)
  1ab9f0:	cmp    %rcx,%rdx
  1ab9f3:	mov    %rcx,%rdx
  1ab9f6:	setb   0x156(%rsp)
  1ab9fe:	mov    0x58(%rsp),%rcx
  1aba03:	cmp    0xc8(%rsp),%rcx
  1aba0b:	setb   0x155(%rsp)
  1aba13:	lea    (%r8,%r10,1),%rcx
  1aba17:	mov    %rcx,0x58(%rsp)
  1aba1c:	cmp    %rdx,%rcx
  1aba1f:	setb   0x168(%rsp)
  1aba27:	mov    0x80(%rsp),%rcx
  1aba2f:	cmp    0x118(%rsp),%rcx
  1aba37:	setb   0x118(%rsp)
  1aba3f:	cmp    %r11,0x78(%rsp)
  1aba44:	setb   0x78(%rsp)
  1aba49:	cmp    0x120(%rsp),%rcx
  1aba51:	setb   0x120(%rsp)
  1aba59:	cmp    %r11,0x98(%rsp)
  1aba61:	setb   0x98(%rsp)
  1aba69:	cmp    0x130(%rsp),%rcx
  1aba71:	setb   0x130(%rsp)
  1aba79:	cmp    %r11,0xa8(%rsp)
  1aba81:	setb   0xa8(%rsp)
  1aba89:	cmp    0x140(%rsp),%rcx
  1aba91:	setb   0x140(%rsp)
  1aba99:	cmp    %r11,%r8
  1aba9c:	setb   0x148(%rsp)
  1abaa4:	cmp    0xf8(%rsp),%rcx
  1abaac:	setb   0xf8(%rsp)
  1abab4:	cmp    %r11,0x160(%rsp)
  1ababc:	setb   0x160(%rsp)
  1abac4:	cmp    0xc8(%rsp),%rcx
  1abacc:	setb   0x80(%rsp)
  1abad4:	cmp    %r11,0x58(%rsp)
  1abad9:	mov    %r14,%rcx
  1abadc:	setb   0x58(%rsp)
  1abae1:	movzbl 0xa7(%rsp),%edx
  1abae9:	test   %dl,0x158(%rsp)
  1abaf0:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abaf6:	mov    %r14,%rcx
  1abaf9:	movzbl 0x12e(%rsp),%edx
  1abb01:	and    %dl,0x12f(%rsp)
  1abb08:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abb0e:	mov    %r14,%rcx
  1abb11:	movzbl 0x12c(%rsp),%edx
  1abb19:	and    %dl,0x12d(%rsp)
  1abb20:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abb26:	mov    %r14,%rcx
  1abb29:	movzbl 0x12a(%rsp),%edx
  1abb31:	and    %dl,0x12b(%rsp)
  1abb38:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abb3e:	mov    %r14,%rcx
  1abb41:	movzbl 0x128(%rsp),%edx
  1abb49:	and    %dl,0x129(%rsp)
  1abb50:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abb56:	mov    %r14,%rcx
  1abb59:	movzbl 0x156(%rsp),%edx
  1abb61:	and    %dl,0x157(%rsp)
  1abb68:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abb6e:	mov    %r14,%rcx
  1abb71:	movzbl 0x168(%rsp),%edx
  1abb79:	and    %dl,0x155(%rsp)
  1abb80:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abb86:	mov    %r14,%rcx
  1abb89:	movzbl 0x78(%rsp),%r11d
  1abb8f:	and    %r11b,0x118(%rsp)
  1abb97:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abb9d:	mov    %r14,%rcx
  1abba0:	movzbl 0x98(%rsp),%r11d
  1abba9:	and    %r11b,0x120(%rsp)
  1abbb1:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abbb7:	mov    %r14,%rcx
  1abbba:	movzbl 0xa8(%rsp),%r11d
  1abbc3:	and    %r11b,0x130(%rsp)
  1abbcb:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abbd1:	mov    %r14,%rcx
  1abbd4:	movzbl 0x148(%rsp),%r11d
  1abbdd:	and    %r11b,0x140(%rsp)
  1abbe5:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abbeb:	mov    %r14,%rcx
  1abbee:	movzbl 0x160(%rsp),%edx
  1abbf6:	and    %dl,0xf8(%rsp)
  1abbfd:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abc03:	mov    %r14,%rcx
  1abc06:	movzbl 0x80(%rsp),%edx
  1abc0e:	and    0x58(%rsp),%dl
  1abc12:	jne    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abc18:	movabs $0x7fffffffffffffe,%rcx
  1abc22:	and    %rcx,%rsi
  1abc25:	lea    (%r14,%rsi,1),%rcx
  1abc29:	movupd (%r9),%xmm3
  1abc2e:	movupd 0x10(%r9),%xmm4
  1abc34:	movupd (%r9,%rbp,1),%xmm5
  1abc3a:	addpd  %xmm3,%xmm5
  1abc3e:	movupd 0x10(%r9,%rbp,1),%xmm3
  1abc45:	addpd  %xmm4,%xmm3
  1abc49:	movupd (%r9,%r10,1),%xmm4
  1abc4f:	addpd  %xmm5,%xmm4
  1abc53:	movupd 0x10(%r9,%r10,1),%xmm5
  1abc5a:	addpd  %xmm3,%xmm5
  1abc5e:	movupd %xmm5,0x10(%r9,%r12,1)
  1abc65:	movupd %xmm4,(%r9,%r12,1)
  1abc6b:	add    $0x20,%r9
  1abc6f:	add    $0xfffffffffffffffe,%rsi
  1abc73:	jne    1abc29 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x2da9>
  1abc75:	jmp    1a9a0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb8a>
  1abc7a:	xor    %edx,%edx
  1abc7c:	mov    %rbx,%rsi
  1abc7f:	sub    %r11,%rsi
  1abc82:	cmovb  %rdx,%rsi
  1abc86:	mov    %rbx,%rdi
  1abc89:	sub    %r14,%rdi
  1abc8c:	cmovb  %rdx,%rdi
  1abc90:	cmp    %rdi,%rsi
  1abc93:	cmovb  %rsi,%rdi
  1abc97:	mov    %rbx,%r8
  1abc9a:	sub    0x60(%rsp),%r8
  1abc9f:	cmovb  %rdx,%r8
  1abca3:	cmp    %r8,%rdi
  1abca6:	cmovb  %rdi,%r8
  1abcaa:	cmp    %r8,%r9
  1abcad:	cmovb  %r9,%r8
  1abcb1:	mov    (%rsp),%rdx
  1abcb5:	shl    $0x4,%rdx
  1abcb9:	lea    (%rdx,%rdx,8),%rdx
  1abcbd:	mov    %rbp,%rsi
  1abcc0:	shl    $0x4,%rsi
  1abcc4:	mov    %rdx,0x88(%rsp)
  1abccc:	lea    (%r15,%rdx,1),%rdi
  1abcd0:	lea    (%rsi,%rdi,1),%rbx
  1abcd4:	add    $0x8,%rbx
  1abcd8:	add    %rsi,%rdi
  1abcdb:	mov    %r8,%rdx
  1abcde:	shl    $0x4,%rdx
  1abce2:	add    %rdx,%rdi
  1abce5:	add    $0x8,%rdi
  1abce9:	mov    %rbp,%r10
  1abcec:	cmp    %rbx,%rdi
  1abcef:	mov    0x8(%rsp),%rbx
  1abcf4:	jb     1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1abcfa:	imul   $0xf0,(%rsp),%rdi
  1abd02:	lea    (%r15,%rdi,1),%r10
  1abd06:	lea    (%rsi,%r10,1),%rbx
  1abd0a:	add    $0x8,%rbx
  1abd0e:	add    %rsi,%r10
  1abd11:	add    %r10,%rdx
  1abd14:	add    $0x8,%rdx
  1abd18:	mov    %rbp,%r10
  1abd1b:	cmp    %rbx,%rdx
  1abd1e:	mov    0x8(%rsp),%rbx
  1abd23:	jb     1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1abd29:	movabs $0xfffffffffffffff,%rdx
  1abd33:	mov    %rbp,%r10
  1abd36:	cmp    %rdx,%r8
  1abd39:	ja     1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1abd3f:	mov    (%rsp),%r8
  1abd43:	shl    $0x8,%r8
  1abd47:	lea    (%r8,%rsi,1),%rbx
  1abd4b:	xor    %r10d,%r10d
  1abd4e:	mov    0x8(%rsp),%rdx
  1abd53:	sub    %r11,%rdx
  1abd56:	cmovb  %r10,%rdx
  1abd5a:	mov    0x8(%rsp),%r11
  1abd5f:	sub    %r14,%r11
  1abd62:	cmovb  %r10,%r11
  1abd66:	lea    (%r15,%rbx,1),%r10
  1abd6a:	cmp    %r11,%rdx
  1abd6d:	cmovb  %rdx,%r11
  1abd71:	mov    0x8(%rsp),%r14
  1abd76:	sub    0x60(%rsp),%r14
  1abd7b:	mov    $0x0,%edx
  1abd80:	cmovb  %rdx,%r14
  1abd84:	cmp    %r14,%r11
  1abd87:	cmovb  %r11,%r14
  1abd8b:	cmp    %r14,%r9
  1abd8e:	cmovb  %r9,%r14
  1abd92:	shl    $0x4,%r14
  1abd96:	lea    (%r14,%r10,1),%rdx
  1abd9a:	add    $0x8,%rdx
  1abd9e:	lea    0x8(%r15,%rbx,1),%r9
  1abda3:	mov    %r9,0x98(%rsp)
  1abdab:	lea    (%r14,%r10,1),%r11
  1abdaf:	add    $0x10,%r11
  1abdb3:	mov    %r11,0x58(%rsp)
  1abdb8:	mov    %rax,%rbx
  1abdbb:	shl    $0x4,%rbx
  1abdbf:	add    %rsi,%rbx
  1abdc2:	mov    %rdi,%r11
  1abdc5:	lea    (%r15,%rbx,1),%rdi
  1abdc9:	add    %r15,%rbx
  1abdcc:	add    $0x8,%rbx
  1abdd0:	mov    %rbx,0x100(%rsp)
  1abdd8:	lea    0x10(%r14,%rdi,1),%r9
  1abddd:	mov    %r9,0xa8(%rsp)
  1abde5:	mov    %rdi,%r9
  1abde8:	mov    %rdi,0xc8(%rsp)
  1abdf0:	mov    %r11,0x60(%rsp)
  1abdf5:	mov    0x60(%rsp),%rdi
  1abdfa:	add    %rsi,%rdi
  1abdfd:	lea    (%r15,%rdi,1),%rbx
  1abe01:	lea    0x8(%r15,%rdi,1),%rdi
  1abe06:	mov    %rdi,0xe0(%rsp)
  1abe0e:	lea    0x10(%r14,%rbx,1),%r11
  1abe13:	lea    0x8(%r14,%r9,1),%rdi
  1abe18:	mov    %rdi,0xd0(%rsp)
  1abe20:	add    %rbx,%r14
  1abe23:	add    $0x8,%r14
  1abe27:	mov    %r14,0xb0(%rsp)
  1abe2f:	cmp    0x58(%rsp),%r10
  1abe34:	setb   0x78(%rsp)
  1abe39:	mov    0x98(%rsp),%r9
  1abe41:	cmp    %rdx,%r9
  1abe44:	setb   0x80(%rsp)
  1abe4c:	mov    0xa8(%rsp),%rdi
  1abe54:	cmp    %rdi,%r10
  1abe57:	setb   0xf8(%rsp)
  1abe5f:	cmp    %rdx,0x100(%rsp)
  1abe67:	setb   0x118(%rsp)
  1abe6f:	cmp    %r11,%r10
  1abe72:	setb   0x120(%rsp)
  1abe7a:	cmp    %rdx,0xe0(%rsp)
  1abe82:	setb   0x130(%rsp)
  1abe8a:	cmp    0xd0(%rsp),%r10
  1abe92:	setb   0x140(%rsp)
  1abe9a:	mov    0xc8(%rsp),%r14
  1abea2:	cmp    %rdx,%r14
  1abea5:	setb   0x148(%rsp)
  1abead:	cmp    0xb0(%rsp),%r10
  1abeb5:	setb   0x158(%rsp)
  1abebd:	cmp    %rdx,%rbx
  1abec0:	setb   0xa7(%rsp)
  1abec8:	cmp    %rdi,%r9
  1abecb:	setb   0xa8(%rsp)
  1abed3:	mov    0x58(%rsp),%r10
  1abed8:	cmp    %r10,0x100(%rsp)
  1abee0:	setb   0x100(%rsp)
  1abee8:	cmp    %r11,%r9
  1abeeb:	mov    0x60(%rsp),%rdi
  1abef0:	setb   0x168(%rsp)
  1abef8:	cmp    %r10,0xe0(%rsp)
  1abf00:	setb   0xe0(%rsp)
  1abf08:	cmp    0xd0(%rsp),%r9
  1abf10:	setb   0x160(%rsp)
  1abf18:	cmp    %r10,%r14
  1abf1b:	setb   0xd0(%rsp)
  1abf23:	cmp    0xb0(%rsp),%r9
  1abf2b:	setb   %dl
  1abf2e:	cmp    %r10,%rbx
  1abf31:	mov    0x8(%rsp),%rbx
  1abf36:	mov    %rbp,%r10
  1abf39:	setb   %r9b
  1abf3d:	movzbl 0x80(%rsp),%r11d
  1abf46:	test   %r11b,0x78(%rsp)
  1abf4b:	jne    1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1abf51:	mov    %rbp,%r10
  1abf54:	movzbl 0x118(%rsp),%r11d
  1abf5d:	and    %r11b,0xf8(%rsp)
  1abf65:	jne    1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1abf6b:	mov    %rbp,%r10
  1abf6e:	movzbl 0x130(%rsp),%r11d
  1abf77:	and    %r11b,0x120(%rsp)
  1abf7f:	jne    1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1abf85:	mov    %rbp,%r10
  1abf88:	movzbl 0x148(%rsp),%r11d
  1abf91:	and    %r11b,0x140(%rsp)
  1abf99:	jne    1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1abf9f:	mov    %rbp,%r10
  1abfa2:	movzbl 0xa7(%rsp),%r11d
  1abfab:	and    %r11b,0x158(%rsp)
  1abfb3:	jne    1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1abfb9:	mov    %rbp,%r10
  1abfbc:	movzbl 0x100(%rsp),%r11d
  1abfc5:	and    %r11b,0xa8(%rsp)
  1abfcd:	jne    1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1abfd3:	mov    %rbp,%r10
  1abfd6:	movzbl 0xe0(%rsp),%r11d
  1abfdf:	and    %r11b,0x168(%rsp)
  1abfe7:	jne    1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1abfed:	mov    %rbp,%r10
  1abff0:	movzbl 0x160(%rsp),%r11d
  1abff9:	and    0xd0(%rsp),%r11b
  1ac001:	jne    1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1ac007:	mov    %rbp,%r10
  1ac00a:	and    %r9b,%dl
  1ac00d:	jne    1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1ac013:	and    $0xfffffffffffffffe,%rcx
  1ac017:	lea    (%rcx,%rbp,1),%r10
  1ac01b:	add    %r15,%rsi
  1ac01e:	mov    0x88(%rsp),%rdx
  1ac026:	movupd (%rsi,%rdx,1),%xmm0
  1ac02b:	movupd (%rsi,%rdi,1),%xmm1
  1ac030:	addpd  %xmm0,%xmm1
  1ac034:	movupd %xmm1,(%rsi,%r8,1)
  1ac03a:	add    $0x10,%rsi
  1ac03e:	dec    %rcx
  1ac041:	jne    1ac026 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x31a6>
  1ac043:	jmp    1aa5ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x172d>
  1ac048:	xor    %r14d,%r14d
  1ac04b:	mov    %rbx,%rdx
  1ac04e:	sub    %r11,%rdx
  1ac051:	cmovae %rdx,%r14
  1ac055:	cmp    %r14,%r8
  1ac058:	cmovb  %r8,%r14
  1ac05c:	mov    0x60(%rsp),%rdx
  1ac061:	cmp    %r14,%rdx
  1ac064:	cmovb  %rdx,%r14
  1ac068:	mov    %r11,0x58(%rsp)
  1ac06d:	mov    0x20(%rsp),%r11
  1ac072:	mov    %r11,%rdx
  1ac075:	shl    $0x4,%rdx
  1ac079:	lea    (%r15,%rbp,1),%r12
  1ac07d:	lea    (%rdx,%r12,1),%r8
  1ac081:	add    $0x8,%r8
  1ac085:	mov    %r8,0x78(%rsp)
  1ac08a:	add    %rdx,%r12
  1ac08d:	mov    %r14,%r8
  1ac090:	shl    $0x4,%r8
  1ac094:	add    %r12,%r8
  1ac097:	add    $0x8,%r8
  1ac09b:	mov    %r11,%r12
  1ac09e:	mov    0x58(%rsp),%r11
  1ac0a3:	cmp    0x78(%rsp),%r8
  1ac0a8:	jb     1a9ad5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc55>
  1ac0ae:	mov    0x20(%rsp),%r12
  1ac0b3:	movabs $0xfffffffffffffff,%r8
  1ac0bd:	cmp    %r8,%r14
  1ac0c0:	mov    0xd0(%rsp),%r8
  1ac0c8:	ja     1a9ad5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc55>
  1ac0ce:	mov    %rcx,%r14
  1ac0d1:	shl    $0x4,%r14
  1ac0d5:	add    %rdx,%r14
  1ac0d8:	lea    (%r15,%r14,1),%r12
  1ac0dc:	lea    (%r15,%r14,1),%rbx
  1ac0e0:	add    $0x8,%rbx
  1ac0e4:	mov    %rbx,0x78(%rsp)
  1ac0e9:	xor    %r14d,%r14d
  1ac0ec:	mov    0x8(%rsp),%rbx
  1ac0f1:	sub    %r11,%rbx
  1ac0f4:	cmovae %rbx,%r14
  1ac0f8:	cmp    %r14,%r8
  1ac0fb:	cmovb  %r8,%r14
  1ac0ff:	mov    0x60(%rsp),%r8
  1ac104:	cmp    %r14,%r8
  1ac107:	cmovb  %r8,%r14
  1ac10b:	shl    $0x4,%r14
  1ac10f:	lea    (%r14,%r12,1),%r8
  1ac113:	add    $0x8,%r8
  1ac117:	mov    %r8,0xa8(%rsp)
  1ac11f:	lea    0x10(%r14,%r12,1),%r11
  1ac124:	mov    %r11,0x98(%rsp)
  1ac12c:	lea    0x0(%rbp,%rdx,1),%r8
  1ac131:	mov    %r8,0xc8(%rsp)
  1ac139:	add    %r15,%r8
  1ac13c:	lea    0x8(%r14,%r8,1),%rbx
  1ac141:	mov    %rbx,0xd0(%rsp)
  1ac149:	add    %r8,%r14
  1ac14c:	add    $0x10,%r14
  1ac150:	mov    %r14,0xf8(%rsp)
  1ac158:	cmp    %r11,%r12
  1ac15b:	setb   0x58(%rsp)
  1ac160:	mov    0x78(%rsp),%r11
  1ac165:	mov    0xa8(%rsp),%rbx
  1ac16d:	cmp    %rbx,%r11
  1ac170:	setb   0x80(%rsp)
  1ac178:	cmp    0xd0(%rsp),%r12
  1ac180:	setb   0x118(%rsp)
  1ac188:	cmp    %rbx,%r8
  1ac18b:	setb   0x120(%rsp)
  1ac193:	cmp    %r14,%r12
  1ac196:	mov    0xc8(%rsp),%r14
  1ac19e:	lea    0x8(%r15,%r14,1),%r12
  1ac1a3:	setb   0xc8(%rsp)
  1ac1ab:	cmp    %rbx,%r12
  1ac1ae:	mov    0x8(%rsp),%rbx
  1ac1b3:	setb   0xa8(%rsp)
  1ac1bb:	cmp    0xd0(%rsp),%r11
  1ac1c3:	mov    %r11,%r14
  1ac1c6:	setb   0xd0(%rsp)
  1ac1ce:	mov    0x98(%rsp),%r11
  1ac1d6:	cmp    %r11,%r8
  1ac1d9:	setb   0x130(%rsp)
  1ac1e1:	cmp    0xf8(%rsp),%r14
  1ac1e9:	setb   %r8b
  1ac1ed:	cmp    %r11,%r12
  1ac1f0:	setb   %r11b
  1ac1f4:	mov    0x20(%rsp),%r12
  1ac1f9:	movzbl 0x80(%rsp),%r14d
  1ac202:	test   %r14b,0x58(%rsp)
  1ac207:	jne    1a9ad5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc55>
  1ac20d:	mov    0x20(%rsp),%r12
  1ac212:	movzbl 0x120(%rsp),%r14d
  1ac21b:	and    %r14b,0x118(%rsp)
  1ac223:	jne    1a9ad5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc55>
  1ac229:	mov    0x20(%rsp),%r12
  1ac22e:	movzbl 0xa8(%rsp),%r14d
  1ac237:	and    %r14b,0xc8(%rsp)
  1ac23f:	jne    1a9ad5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc55>
  1ac245:	mov    0x20(%rsp),%r12
  1ac24a:	movzbl 0x130(%rsp),%r14d
  1ac253:	and    %r14b,0xd0(%rsp)
  1ac25b:	jne    1a9ad5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc55>
  1ac261:	mov    0x20(%rsp),%r12
  1ac266:	and    %r11b,%r8b
  1ac269:	jne    1a9ad5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc55>
  1ac26f:	and    $0xfffffffffffffffe,%rsi
  1ac273:	mov    0x20(%rsp),%r8
  1ac278:	lea    (%r8,%rsi,1),%r12
  1ac27c:	mov    0x100(%rsp),%r8
  1ac284:	lea    (%r8,%r8,8),%r11
  1ac288:	add    %r15,%rdx
  1ac28b:	movupd (%rdx,%rbp,1),%xmm3
  1ac290:	movupd 0x10(%rdx,%rbp,1),%xmm4
  1ac296:	movapd %xmm3,%xmm5
  1ac29a:	unpcklpd %xmm4,%xmm5
  1ac29e:	unpckhpd %xmm4,%xmm3
  1ac2a2:	movapd %xmm1,%xmm4
  1ac2a6:	mulpd  %xmm5,%xmm4
  1ac2aa:	movapd %xmm0,%xmm6
  1ac2ae:	mulpd  %xmm3,%xmm6
  1ac2b2:	addpd  %xmm4,%xmm6
  1ac2b6:	mulpd  %xmm0,%xmm5
  1ac2ba:	mulpd  %xmm1,%xmm3
  1ac2be:	subpd  %xmm3,%xmm5
  1ac2c2:	movapd %xmm5,%xmm3
  1ac2c6:	unpcklpd %xmm6,%xmm3
  1ac2ca:	unpckhpd %xmm6,%xmm5
  1ac2ce:	movupd %xmm5,0x10(%rdx,%r11,1)
  1ac2d5:	movupd %xmm3,(%rdx,%r11,1)
  1ac2db:	add    $0x20,%rdx
  1ac2df:	add    $0xfffffffffffffffe,%rsi
  1ac2e3:	jne    1ac28b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x340b>
  1ac2e5:	jmp    1a9ad5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc55>
  1ac2ea:	xor    %ecx,%ecx
  1ac2ec:	mov    %rbx,%rdx
  1ac2ef:	sub    %r9,%rdx
  1ac2f2:	cmovb  %rcx,%rdx
  1ac2f6:	mov    %rbx,%r11
  1ac2f9:	sub    %r10,%r11
  1ac2fc:	cmovb  %rcx,%r11
  1ac300:	cmp    %r11,%rdx
  1ac303:	cmovb  %rdx,%r11
  1ac307:	cmp    %r11,%r8
  1ac30a:	cmovb  %r8,%r11
  1ac30e:	imul   $0xf0,%rbp,%rcx
  1ac315:	mov    0x20(%rsp),%r13
  1ac31a:	mov    %r13,%rdx
  1ac31d:	shl    $0x4,%rdx
  1ac321:	lea    (%r15,%rcx,1),%rsi
  1ac325:	lea    (%rdx,%rsi,1),%rbx
  1ac329:	add    $0x8,%rbx
  1ac32d:	add    %rdx,%rsi
  1ac330:	mov    %r11,%r14
  1ac333:	shl    $0x4,%r14
  1ac337:	add    %rsi,%r14
  1ac33a:	add    $0x8,%r14
  1ac33e:	mov    %r13,%rsi
  1ac341:	cmp    %rbx,%r14
  1ac344:	mov    0x8(%rsp),%rbx
  1ac349:	jb     1aa8a5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1a25>
  1ac34f:	movabs $0xfffffffffffffff,%rbx
  1ac359:	mov    0x20(%rsp),%rsi
  1ac35e:	cmp    %rbx,%r11
  1ac361:	mov    0x8(%rsp),%rbx
  1ac366:	ja     1aa8a5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1a25>
  1ac36c:	lea    0x0(,%rbp,8),%rsi
  1ac374:	add    %rbp,%rsi
  1ac377:	shl    $0x5,%rsi
  1ac37b:	add    %rdx,%rsi
  1ac37e:	xor    %r11d,%r11d
  1ac381:	mov    0x8(%rsp),%rbx
  1ac386:	sub    %r9,%rbx
  1ac389:	cmovb  %r11,%rbx
  1ac38d:	mov    0x8(%rsp),%r9
  1ac392:	sub    %r10,%r9
  1ac395:	cmovb  %r11,%r9
  1ac399:	cmp    %r9,%rbx
  1ac39c:	cmovb  %rbx,%r9
  1ac3a0:	cmp    %r9,%r8
  1ac3a3:	cmovb  %r8,%r9
  1ac3a7:	lea    (%r15,%rsi,1),%r8
  1ac3ab:	shl    $0x4,%r9
  1ac3af:	lea    (%r9,%r8,1),%r10
  1ac3b3:	add    $0x8,%r10
  1ac3b7:	lea    0x8(%r15,%rsi,1),%rsi
  1ac3bc:	lea    0x10(%r9,%r8,1),%rbx
  1ac3c1:	lea    (%rcx,%rdx,1),%r11
  1ac3c5:	lea    (%r15,%r11,1),%r13
  1ac3c9:	lea    (%r9,%r13,1),%rbp
  1ac3cd:	add    $0x8,%rbp
  1ac3d1:	add    %r13,%r9
  1ac3d4:	add    $0x10,%r9
  1ac3d8:	cmp    %rbx,%r8
  1ac3db:	setb   0xb0(%rsp)
  1ac3e3:	cmp    %r10,%rsi
  1ac3e6:	setb   0xd0(%rsp)
  1ac3ee:	cmp    %rbp,%r8
  1ac3f1:	setb   %r14b
  1ac3f5:	cmp    %r10,%r13
  1ac3f8:	setb   0xe0(%rsp)
  1ac400:	cmp    %r9,%r8
  1ac403:	lea    0x8(%r15,%r11,1),%r8
  1ac408:	setb   %r11b
  1ac40c:	cmp    %r10,%r8
  1ac40f:	setb   0x58(%rsp)
  1ac414:	cmp    %rbp,%rsi
  1ac417:	mov    (%rsp),%rbp
  1ac41b:	setb   %r10b
  1ac41f:	cmp    %rbx,%r13
  1ac422:	setb   %r13b
  1ac426:	cmp    %r9,%rsi
  1ac429:	setb   %r9b
  1ac42d:	cmp    %rbx,%r8
  1ac430:	mov    0x8(%rsp),%rbx
  1ac435:	setb   0x88(%rsp)
  1ac43d:	mov    0x20(%rsp),%rsi
  1ac442:	movzbl 0xd0(%rsp),%r8d
  1ac44b:	test   %r8b,0xb0(%rsp)
  1ac453:	jne    1aa8a5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1a25>
  1ac459:	mov    0x20(%rsp),%rsi
  1ac45e:	and    0xe0(%rsp),%r14b
  1ac466:	jne    1aa8a5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1a25>
  1ac46c:	mov    0x20(%rsp),%rsi
  1ac471:	and    0x58(%rsp),%r11b
  1ac476:	jne    1aa8a5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1a25>
  1ac47c:	mov    0x20(%rsp),%rsi
  1ac481:	and    %r13b,%r10b
  1ac484:	jne    1aa8a5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1a25>
  1ac48a:	mov    0x20(%rsp),%rsi
  1ac48f:	and    0x88(%rsp),%r9b
  1ac497:	jne    1aa8a5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1a25>
  1ac49d:	and    $0xfffffffffffffffe,%rax
  1ac4a1:	mov    0x20(%rsp),%rsi
  1ac4a6:	add    %rax,%rsi
  1ac4a9:	mov    0x1d8(%rsp),%r8
  1ac4b1:	movsd  0x10(%r8),%xmm0
  1ac4b7:	movsd  0x18(%r8),%xmm1
  1ac4bd:	unpcklpd %xmm1,%xmm1
  1ac4c1:	unpcklpd %xmm0,%xmm0
  1ac4c5:	mov    %rbp,%r8
  1ac4c8:	shl    $0x5,%r8
  1ac4cc:	lea    (%r8,%r8,8),%r8
  1ac4d0:	add    %r15,%rdx
  1ac4d3:	movupd (%rdx,%rcx,1),%xmm2
  1ac4d8:	movupd 0x10(%rdx,%rcx,1),%xmm3
  1ac4de:	movapd %xmm2,%xmm4
  1ac4e2:	unpcklpd %xmm3,%xmm4
  1ac4e6:	unpckhpd %xmm3,%xmm2
  1ac4ea:	movapd %xmm1,%xmm3
  1ac4ee:	mulpd  %xmm4,%xmm3
  1ac4f2:	movapd %xmm0,%xmm5
  1ac4f6:	mulpd  %xmm2,%xmm5
  1ac4fa:	addpd  %xmm3,%xmm5
  1ac4fe:	mulpd  %xmm0,%xmm4
  1ac502:	mulpd  %xmm1,%xmm2
  1ac506:	subpd  %xmm2,%xmm4
  1ac50a:	movapd %xmm4,%xmm2
  1ac50e:	unpcklpd %xmm5,%xmm2
  1ac512:	unpckhpd %xmm5,%xmm4
  1ac516:	movupd %xmm4,0x10(%rdx,%r8,1)
  1ac51d:	movupd %xmm2,(%rdx,%r8,1)
  1ac523:	add    $0x20,%rdx
  1ac527:	add    $0xfffffffffffffffe,%rax
  1ac52b:	jne    1ac4d3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x3653>
  1ac52d:	jmp    1aa8a5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1a25>
  1ac532:	xor    %edx,%edx
  1ac534:	mov    %rbx,%rsi
  1ac537:	sub    %rbp,%rsi
  1ac53a:	cmovae %rsi,%rdx
  1ac53e:	mov    0x48(%rsp),%rsi
  1ac543:	cmp    %rsi,%rdx
  1ac546:	cmovae %rsi,%rdx
  1ac54a:	cmp    %r14,%rdx
  1ac54d:	cmovae %r14,%rdx
  1ac551:	mov    0x60(%rsp),%rsi
  1ac556:	cmp    %rdx,%rsi
  1ac559:	cmovb  %rsi,%rdx
  1ac55d:	shl    $0x4,%rdi
  1ac561:	lea    (%r15,%rdi,1),%rsi
  1ac565:	add    %r15,%rdi
  1ac568:	add    $0x8,%rdi
  1ac56c:	shl    $0x4,%rdx
  1ac570:	mov    %rsi,0x58(%rsp)
  1ac575:	add    %rdx,%rsi
  1ac578:	add    $0x8,%rsi
  1ac57c:	mov    %r8,%r11
  1ac57f:	mov    %rdi,0x78(%rsp)
  1ac584:	cmp    %rdi,%rsi
  1ac587:	jb     1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac58d:	mov    %r8,%r12
  1ac590:	shl    $0x4,%r12
  1ac594:	lea    (%r15,%r12,1),%rsi
  1ac598:	lea    (%r15,%r12,1),%rdi
  1ac59c:	add    $0x8,%rdi
  1ac5a0:	add    %rsi,%rdx
  1ac5a3:	add    $0x8,%rdx
  1ac5a7:	mov    %r8,%r11
  1ac5aa:	mov    %rdi,0xc8(%rsp)
  1ac5b2:	cmp    %rdi,%rdx
  1ac5b5:	jb     1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac5bb:	lea    (%r9,%r9,4),%rdi
  1ac5bf:	lea    (%rdi,%r12,1),%r8
  1ac5c3:	lea    (%r15,%r8,1),%rdx
  1ac5c7:	xor    %ebx,%ebx
  1ac5c9:	mov    0x8(%rsp),%r11
  1ac5ce:	sub    %rbp,%r11
  1ac5d1:	cmovae %r11,%rbx
  1ac5d5:	add    %r15,%r8
  1ac5d8:	add    $0x8,%r8
  1ac5dc:	mov    %r8,0x80(%rsp)
  1ac5e4:	mov    0x48(%rsp),%r8
  1ac5e9:	cmp    %r8,%rbx
  1ac5ec:	cmovae %r8,%rbx
  1ac5f0:	cmp    %r14,%rbx
  1ac5f3:	cmovae %r14,%rbx
  1ac5f7:	mov    0x60(%rsp),%r8
  1ac5fc:	cmp    %rbx,%r8
  1ac5ff:	cmovb  %r8,%rbx
  1ac603:	shl    $0x4,%rbx
  1ac607:	lea    (%rbx,%rdx,1),%r8
  1ac60b:	add    $0x8,%r8
  1ac60f:	add    %r15,%r12
  1ac612:	lea    (%rbx,%r12,1),%r11
  1ac616:	add    $0x10,%r11
  1ac61a:	mov    %r11,0xe0(%rsp)
  1ac622:	lea    (%r11,%rdi,1),%rbp
  1ac626:	mov    0x58(%rsp),%r11
  1ac62b:	lea    0x10(%rbx,%r11,1),%r11
  1ac630:	lea    0x8(%rbx,%r12,1),%r14
  1ac635:	mov    %r14,0x98(%rsp)
  1ac63d:	mov    0x58(%rsp),%r14
  1ac642:	add    %r14,%rbx
  1ac645:	add    $0x8,%rbx
  1ac649:	cmp    %rbp,%rdx
  1ac64c:	setb   0xa8(%rsp)
  1ac654:	cmp    %r8,0x80(%rsp)
  1ac65c:	setb   0xf8(%rsp)
  1ac664:	cmp    %r11,%rdx
  1ac667:	setb   0x118(%rsp)
  1ac66f:	cmp    %r8,0x78(%rsp)
  1ac674:	setb   0x120(%rsp)
  1ac67c:	cmp    0x98(%rsp),%rdx
  1ac684:	setb   0x130(%rsp)
  1ac68c:	cmp    %r8,%r12
  1ac68f:	setb   0x140(%rsp)
  1ac697:	cmp    %rbx,%rdx
  1ac69a:	setb   0x148(%rsp)
  1ac6a2:	cmp    %r8,%r14
  1ac6a5:	setb   0x158(%rsp)
  1ac6ad:	cmp    0xe0(%rsp),%rdx
  1ac6b5:	setb   0xa7(%rsp)
  1ac6bd:	mov    0xc8(%rsp),%r14
  1ac6c5:	cmp    %r8,%r14
  1ac6c8:	setb   0x168(%rsp)
  1ac6d0:	mov    0x80(%rsp),%rdx
  1ac6d8:	cmp    %r11,%rdx
  1ac6db:	mov    0x20(%rsp),%r8
  1ac6e0:	setb   0x160(%rsp)
  1ac6e8:	cmp    %rbp,0x78(%rsp)
  1ac6ed:	setb   0x78(%rsp)
  1ac6f2:	cmp    0x98(%rsp),%rdx
  1ac6fa:	setb   0x98(%rsp)
  1ac702:	cmp    %rbp,%r12
  1ac705:	setb   0x170(%rsp)
  1ac70d:	cmp    %rbx,%rdx
  1ac710:	mov    0x8(%rsp),%rbx
  1ac715:	setb   %r12b
  1ac719:	cmp    %rbp,0x58(%rsp)
  1ac71e:	setb   0x58(%rsp)
  1ac723:	cmp    0xe0(%rsp),%rdx
  1ac72b:	setb   %dl
  1ac72e:	cmp    %rbp,%r14
  1ac731:	mov    %r8,%r11
  1ac734:	setb   %r14b
  1ac738:	movzbl 0xf8(%rsp),%ebp
  1ac740:	test   %bpl,0xa8(%rsp)
  1ac748:	jne    1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac74e:	mov    %r8,%r11
  1ac751:	movzbl 0x120(%rsp),%ebp
  1ac759:	and    %bpl,0x118(%rsp)
  1ac761:	jne    1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac767:	mov    %r8,%r11
  1ac76a:	movzbl 0x140(%rsp),%ebp
  1ac772:	and    %bpl,0x130(%rsp)
  1ac77a:	jne    1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac780:	mov    %r8,%r11
  1ac783:	movzbl 0x158(%rsp),%ebp
  1ac78b:	and    %bpl,0x148(%rsp)
  1ac793:	jne    1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac799:	mov    %r8,%r11
  1ac79c:	movzbl 0x168(%rsp),%ebp
  1ac7a4:	and    %bpl,0xa7(%rsp)
  1ac7ac:	jne    1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac7b2:	mov    %r8,%r11
  1ac7b5:	movzbl 0x78(%rsp),%ebp
  1ac7ba:	and    %bpl,0x160(%rsp)
  1ac7c2:	jne    1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac7c8:	mov    %r8,%r11
  1ac7cb:	movzbl 0x170(%rsp),%ebp
  1ac7d3:	and    %bpl,0x98(%rsp)
  1ac7db:	jne    1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac7e1:	mov    %r8,%r11
  1ac7e4:	and    0x58(%rsp),%r12b
  1ac7e9:	jne    1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac7ef:	mov    %r8,%r11
  1ac7f2:	and    %r14b,%dl
  1ac7f5:	jne    1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac7fb:	movabs $0x7fffffffffffffe,%rdx
  1ac805:	and    %rdx,%rax
  1ac808:	lea    (%r8,%rax,1),%r11
  1ac80c:	mov    0x1d8(%rsp),%rdx
  1ac814:	movsd  0x20(%rdx),%xmm2
  1ac819:	movsd  0x28(%rdx),%xmm3
  1ac81e:	unpcklpd %xmm2,%xmm2
  1ac822:	unpcklpd %xmm3,%xmm3
  1ac826:	mov    0x100(%rsp),%rdx
  1ac82e:	movupd (%rsi,%rdx,1),%xmm5
  1ac833:	movupd 0x10(%rsi,%rdx,1),%xmm4
  1ac839:	movapd %xmm5,%xmm6
  1ac83d:	unpcklpd %xmm4,%xmm6
  1ac841:	unpckhpd %xmm4,%xmm5
  1ac845:	movupd (%rsi),%xmm7
  1ac849:	movupd 0x10(%rsi),%xmm8
  1ac84f:	movapd %xmm7,%xmm4
  1ac853:	unpcklpd %xmm8,%xmm4
  1ac858:	unpckhpd %xmm8,%xmm7
  1ac85d:	movapd %xmm5,%xmm8
  1ac862:	mulpd  %xmm4,%xmm8
  1ac867:	mulpd  %xmm6,%xmm4
  1ac86b:	mulpd  %xmm7,%xmm6
  1ac86f:	addpd  %xmm6,%xmm8
  1ac874:	movapd %xmm2,%xmm6
  1ac878:	mulpd  %xmm8,%xmm6
  1ac87d:	mulpd  %xmm5,%xmm7
  1ac881:	subpd  %xmm7,%xmm4
  1ac885:	movapd %xmm2,%xmm5
  1ac889:	mulpd  %xmm4,%xmm5
  1ac88d:	mulpd  %xmm3,%xmm4
  1ac891:	addpd  %xmm6,%xmm4
  1ac895:	mulpd  %xmm3,%xmm8
  1ac89a:	subpd  %xmm8,%xmm5
  1ac89f:	movapd %xmm5,%xmm6
  1ac8a3:	unpcklpd %xmm4,%xmm6
  1ac8a7:	unpckhpd %xmm4,%xmm5
  1ac8ab:	movupd %xmm5,0x10(%rsi,%rdi,1)
  1ac8b1:	movupd %xmm6,(%rsi,%rdi,1)
  1ac8b6:	add    $0x20,%rsi
  1ac8ba:	add    $0xfffffffffffffffe,%rax
  1ac8be:	jne    1ac82e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x39ae>
  1ac8c4:	jmp    1a9bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd40>
  1ac8c9:	xor    %ecx,%ecx
  1ac8cb:	mov    %rbx,%rdx
  1ac8ce:	sub    %r10,%rdx
  1ac8d1:	cmovb  %rcx,%rdx
  1ac8d5:	mov    %rbx,%rsi
  1ac8d8:	sub    %r11,%rsi
  1ac8db:	cmovb  %rcx,%rsi
  1ac8df:	cmp    %rsi,%rdx
  1ac8e2:	cmovb  %rdx,%rsi
  1ac8e6:	cmp    %rsi,%r9
  1ac8e9:	cmovb  %r9,%rsi
  1ac8ed:	mov    (%rsp),%rcx
  1ac8f1:	shl    $0x6,%rcx
  1ac8f5:	lea    (%rcx,%rcx,4),%rcx
  1ac8f9:	mov    %r13,%rdx
  1ac8fc:	shl    $0x4,%rdx
  1ac900:	lea    (%r15,%rcx,1),%r8
  1ac904:	lea    (%rdx,%r8,1),%rbx
  1ac908:	add    $0x8,%rbx
  1ac90c:	add    %rdx,%r8
  1ac90f:	mov    %rsi,%r12
  1ac912:	shl    $0x4,%r12
  1ac916:	add    %r8,%r12
  1ac919:	add    $0x8,%r12
  1ac91d:	mov    %r13,%r8
  1ac920:	cmp    %rbx,%r12
  1ac923:	mov    0x8(%rsp),%rbx
  1ac928:	jb     1aada8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1f28>
  1ac92e:	movabs $0xfffffffffffffff,%rbx
  1ac938:	mov    %r13,%r8
  1ac93b:	cmp    %rbx,%rsi
  1ac93e:	mov    0x8(%rsp),%rbx
  1ac943:	ja     1aada8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1f28>
  1ac949:	imul   $0x150,(%rsp),%rsi
  1ac951:	lea    (%rsi,%rdx,1),%r8
  1ac955:	xor    %ebx,%ebx
  1ac957:	mov    0x8(%rsp),%r12
  1ac95c:	sub    %r10,%r12
  1ac95f:	cmovb  %rbx,%r12
  1ac963:	mov    0x8(%rsp),%r10
  1ac968:	sub    %r11,%r10
  1ac96b:	cmovb  %rbx,%r10
  1ac96f:	lea    (%r15,%r8,1),%r11
  1ac973:	cmp    %r10,%r12
  1ac976:	cmovb  %r12,%r10
  1ac97a:	cmp    %r10,%r9
  1ac97d:	cmovb  %r9,%r10
  1ac981:	shl    $0x4,%r10
  1ac985:	lea    (%r10,%r11,1),%r9
  1ac989:	add    $0x8,%r9
  1ac98d:	lea    0x8(%r15,%r8,1),%r8
  1ac992:	mov    %r8,0xd0(%rsp)
  1ac99a:	lea    (%r10,%r11,1),%r8
  1ac99e:	add    $0x10,%r8
  1ac9a2:	mov    %r8,0x100(%rsp)
  1ac9aa:	mov    0x48(%rsp),%r12
  1ac9af:	shl    $0x6,%r12
  1ac9b3:	add    %rdx,%r12
  1ac9b6:	lea    (%r15,%r12,1),%rbp
  1ac9ba:	lea    (%r10,%rbp,1),%rbx
  1ac9be:	add    $0x8,%rbx
  1ac9c2:	mov    %rbx,0xb0(%rsp)
  1ac9ca:	add    %rbp,%r10
  1ac9cd:	add    $0x10,%r10
  1ac9d1:	cmp    %r8,%r11
  1ac9d4:	setb   0x38(%rsp)
  1ac9d9:	mov    0xd0(%rsp),%rbx
  1ac9e1:	cmp    %r9,%rbx
  1ac9e4:	setb   0x40(%rsp)
  1ac9e9:	mov    0xb0(%rsp),%r8
  1ac9f1:	cmp    %r8,%r11
  1ac9f4:	setb   0xe0(%rsp)
  1ac9fc:	cmp    %r9,%rbp
  1ac9ff:	setb   0x58(%rsp)
  1aca04:	cmp    %r10,%r11
  1aca07:	lea    0x8(%r15,%r12,1),%r11
  1aca0c:	setb   %r12b
  1aca10:	cmp    %r9,%r11
  1aca13:	setb   0x88(%rsp)
  1aca1b:	cmp    %r8,%rbx
  1aca1e:	setb   %r9b
  1aca22:	mov    0x100(%rsp),%r8
  1aca2a:	cmp    %r8,%rbp
  1aca2d:	mov    0x10(%rsp),%ebp
  1aca31:	setb   0xb0(%rsp)
  1aca39:	cmp    %r10,%rbx
  1aca3c:	setb   %r10b
  1aca40:	cmp    %r8,%r11
  1aca43:	mov    0x8(%rsp),%rbx
  1aca48:	setb   0x100(%rsp)
  1aca50:	mov    %r13,%r8
  1aca53:	movzbl 0x40(%rsp),%r11d
  1aca59:	test   %r11b,0x38(%rsp)
  1aca5e:	jne    1aada8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1f28>
  1aca64:	mov    %r13,%r8
  1aca67:	movzbl 0x58(%rsp),%r11d
  1aca6d:	and    %r11b,0xe0(%rsp)
  1aca75:	jne    1aada8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1f28>
  1aca7b:	mov    %r13,%r8
  1aca7e:	and    0x88(%rsp),%r12b
  1aca86:	jne    1aada8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1f28>
  1aca8c:	mov    %r13,%r8
  1aca8f:	and    0xb0(%rsp),%r9b
  1aca97:	jne    1aada8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1f28>
  1aca9d:	mov    %r13,%r8
  1acaa0:	and    0x100(%rsp),%r10b
  1acaa8:	jne    1aada8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1f28>
  1acaae:	and    $0xfffffffffffffffe,%rax
  1acab2:	lea    (%rax,%r13,1),%r8
  1acab6:	mov    0x1d8(%rsp),%r9
  1acabe:	movsd  0x10(%r9),%xmm0
  1acac4:	movsd  0x18(%r9),%xmm1
  1acaca:	unpcklpd %xmm1,%xmm1
  1acace:	unpcklpd %xmm0,%xmm0
  1acad2:	add    %r15,%rdx
  1acad5:	movupd (%rdx,%rcx,1),%xmm2
  1acada:	movupd 0x10(%rdx,%rcx,1),%xmm3
  1acae0:	movapd %xmm2,%xmm4
  1acae4:	unpcklpd %xmm3,%xmm4
  1acae8:	unpckhpd %xmm3,%xmm2
  1acaec:	movapd %xmm1,%xmm3
  1acaf0:	mulpd  %xmm4,%xmm3
  1acaf4:	movapd %xmm0,%xmm5
  1acaf8:	mulpd  %xmm2,%xmm5
  1acafc:	addpd  %xmm3,%xmm5
  1acb00:	mulpd  %xmm0,%xmm4
  1acb04:	mulpd  %xmm1,%xmm2
  1acb08:	subpd  %xmm2,%xmm4
  1acb0c:	movapd %xmm4,%xmm2
  1acb10:	unpcklpd %xmm5,%xmm2
  1acb14:	unpckhpd %xmm5,%xmm4
  1acb18:	movupd %xmm4,0x10(%rdx,%rsi,1)
  1acb1e:	movupd %xmm2,(%rdx,%rsi,1)
  1acb23:	add    $0x20,%rdx
  1acb27:	add    $0xfffffffffffffffe,%rax
  1acb2b:	jne    1acad5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x3c55>
  1acb2d:	jmp    1aada8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1f28>
  1acb32:	mov    0x40(%rsp),%rdx
  1acb37:	mov    0xb0(%rsp),%rsi
  1acb3f:	cmp    %rdx,%rsi
  1acb42:	cmovb  %rsi,%rdx
  1acb46:	cmp    %rbp,%rdx
  1acb49:	cmovae %rbp,%rdx
  1acb4d:	xor    %r12d,%r12d
  1acb50:	sub    0xe0(%rsp),%rbx
  1acb58:	cmovae %rbx,%r12
  1acb5c:	cmp    %r12,%rdx
  1acb5f:	cmovb  %rdx,%r12
  1acb63:	mov    0x60(%rsp),%rdx
  1acb68:	cmp    %r12,%rdx
  1acb6b:	cmovb  %rdx,%r12
  1acb6f:	mov    %r14,%rsi
  1acb72:	shl    $0x4,%rsi
  1acb76:	mov    %r12,%r8
  1acb79:	shl    $0x4,%r8
  1acb7d:	lea    (%r15,%r13,1),%rdx
  1acb81:	lea    (%rsi,%rdx,1),%rbx
  1acb85:	add    $0x8,%rbx
  1acb89:	add    %rsi,%rdx
  1acb8c:	lea    (%r8,%rdx,1),%r14
  1acb90:	add    $0x8,%r14
  1acb94:	mov    0x20(%rsp),%rdx
  1acb99:	cmp    %rbx,%r14
  1acb9c:	mov    0x8(%rsp),%rbx
  1acba1:	jb     1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acba7:	lea    (%r15,%r9,1),%rdx
  1acbab:	lea    (%rsi,%rdx,1),%rbx
  1acbaf:	add    $0x8,%rbx
  1acbb3:	add    %rsi,%rdx
  1acbb6:	lea    (%r8,%rdx,1),%r14
  1acbba:	add    $0x8,%r14
  1acbbe:	mov    0x20(%rsp),%rdx
  1acbc3:	cmp    %rbx,%r14
  1acbc6:	mov    0x20(%rsp),%r14
  1acbcb:	mov    0x8(%rsp),%rbx
  1acbd0:	jb     1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acbd6:	mov    0x88(%rsp),%rdx
  1acbde:	lea    (%rsi,%rdx,1),%rbx
  1acbe2:	add    $0x8,%rbx
  1acbe6:	add    %rsi,%rdx
  1acbe9:	add    %rdx,%r8
  1acbec:	add    $0x8,%r8
  1acbf0:	mov    %r14,%rdx
  1acbf3:	cmp    %rbx,%r8
  1acbf6:	mov    0x8(%rsp),%rbx
  1acbfb:	jb     1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acc01:	mov    %r14,%rdx
  1acc04:	movabs $0xfffffffffffffff,%r8
  1acc0e:	cmp    %r8,%r12
  1acc11:	ja     1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acc17:	mov    (%rsp),%rdx
  1acc1b:	lea    (%rdx,%rdx,2),%rbx
  1acc1f:	shl    $0x6,%rbx
  1acc23:	add    %rsi,%rbx
  1acc26:	mov    0x40(%rsp),%r14
  1acc2b:	mov    0xb0(%rsp),%rdx
  1acc33:	cmp    %r14,%rdx
  1acc36:	cmovb  %rdx,%r14
  1acc3a:	cmp    %rbp,%r14
  1acc3d:	cmovae %rbp,%r14
  1acc41:	xor    %r8d,%r8d
  1acc44:	mov    0x8(%rsp),%rdx
  1acc49:	sub    0xe0(%rsp),%rdx
  1acc51:	cmovae %rdx,%r8
  1acc55:	lea    (%r15,%rbx,1),%rdx
  1acc59:	cmp    %r8,%r14
  1acc5c:	cmovb  %r14,%r8
  1acc60:	lea    0x8(%r15,%rbx,1),%rbx
  1acc65:	mov    %rbx,0xb0(%rsp)
  1acc6d:	mov    0x8(%rsp),%rbx
  1acc72:	mov    0x60(%rsp),%r14
  1acc77:	cmp    %r8,%r14
  1acc7a:	cmovb  %r14,%r8
  1acc7e:	shl    $0x4,%r8
  1acc82:	lea    (%r8,%rdx,1),%r14
  1acc86:	add    $0x8,%r14
  1acc8a:	mov    %r14,0x158(%rsp)
  1acc92:	lea    0x10(%r8,%rdx,1),%r12
  1acc97:	mov    %r12,0xe0(%rsp)
  1acc9f:	lea    (%r9,%rsi,1),%r12
  1acca3:	lea    (%r15,%r12,1),%rbp
  1acca7:	add    $0x8,%rbp
  1accab:	mov    %rbp,0x88(%rsp)
  1accb3:	add    %r15,%r12
  1accb6:	mov    %r12,0x40(%rsp)
  1accbb:	add    %r8,%r12
  1accbe:	add    $0x10,%r12
  1accc2:	mov    %r12,0xa8(%rsp)
  1accca:	lea    (%r10,%rsi,1),%r14
  1accce:	lea    (%r15,%r14,1),%rbp
  1accd2:	add    $0x8,%rbp
  1accd6:	mov    %rbp,0x78(%rsp)
  1accdb:	add    %r15,%r14
  1accde:	lea    (%r8,%r14,1),%rbp
  1acce2:	add    $0x10,%rbp
  1acce6:	mov    %rbp,0xf8(%rsp)
  1accee:	lea    (%rsi,%r13,1),%r12
  1accf2:	lea    (%r15,%r12,1),%rbp
  1accf6:	add    $0x8,%rbp
  1accfa:	mov    %rbp,0x98(%rsp)
  1acd02:	add    %r15,%r12
  1acd05:	lea    (%r8,%r12,1),%rbp
  1acd09:	add    $0x10,%rbp
  1acd0d:	mov    %rbp,0x118(%rsp)
  1acd15:	mov    0x40(%rsp),%rbp
  1acd1a:	lea    0x8(%r8,%rbp,1),%rbp
  1acd1f:	mov    %rbp,0xc8(%rsp)
  1acd27:	mov    %r14,0x148(%rsp)
  1acd2f:	lea    0x8(%r8,%r14,1),%rbp
  1acd34:	mov    %rbp,0x80(%rsp)
  1acd3c:	add    %r12,%r8
  1acd3f:	add    $0x8,%r8
  1acd43:	mov    %r8,0x140(%rsp)
  1acd4b:	cmp    0xe0(%rsp),%rdx
  1acd53:	setb   0x120(%rsp)
  1acd5b:	mov    0x158(%rsp),%r14
  1acd63:	cmp    %r14,0xb0(%rsp)
  1acd6b:	setb   0x130(%rsp)
  1acd73:	cmp    0xa8(%rsp),%rdx
  1acd7b:	setb   0xa7(%rsp)
  1acd83:	cmp    %r14,0x88(%rsp)
  1acd8b:	setb   0x168(%rsp)
  1acd93:	cmp    0xf8(%rsp),%rdx
  1acd9b:	setb   0x160(%rsp)
  1acda3:	cmp    %r14,0x78(%rsp)
  1acda8:	setb   0x170(%rsp)
  1acdb0:	cmp    0x118(%rsp),%rdx
  1acdb8:	setb   0x12f(%rsp)
  1acdc0:	cmp    %r14,0x98(%rsp)
  1acdc8:	setb   0x12e(%rsp)
  1acdd0:	cmp    0xc8(%rsp),%rdx
  1acdd8:	setb   0x12d(%rsp)
  1acde0:	cmp    %r14,0x40(%rsp)
  1acde5:	setb   0x12c(%rsp)
  1acded:	cmp    0x80(%rsp),%rdx
  1acdf5:	setb   0x12b(%rsp)
  1acdfd:	mov    0x148(%rsp),%rbp
  1ace05:	cmp    %r14,%rbp
  1ace08:	setb   0x12a(%rsp)
  1ace10:	cmp    %r8,%rdx
  1ace13:	setb   0x129(%rsp)
  1ace1b:	cmp    %r14,%r12
  1ace1e:	mov    0x20(%rsp),%r8
  1ace23:	setb   0x158(%rsp)
  1ace2b:	mov    0xb0(%rsp),%rdx
  1ace33:	cmp    0xa8(%rsp),%rdx
  1ace3b:	setb   0xa8(%rsp)
  1ace43:	mov    0xe0(%rsp),%r14
  1ace4b:	cmp    %r14,0x88(%rsp)
  1ace53:	setb   0x88(%rsp)
  1ace5b:	cmp    0xf8(%rsp),%rdx
  1ace63:	setb   0xf8(%rsp)
  1ace6b:	cmp    %r14,0x78(%rsp)
  1ace70:	setb   0x78(%rsp)
  1ace75:	cmp    0x118(%rsp),%rdx
  1ace7d:	setb   0x118(%rsp)
  1ace85:	cmp    %r14,0x98(%rsp)
  1ace8d:	setb   0x98(%rsp)
  1ace95:	cmp    0xc8(%rsp),%rdx
  1ace9d:	setb   0xc8(%rsp)
  1acea5:	cmp    %r14,0x40(%rsp)
  1aceaa:	setb   0x40(%rsp)
  1aceaf:	cmp    0x80(%rsp),%rdx
  1aceb7:	setb   0x128(%rsp)
  1acebf:	cmp    %r14,%rbp
  1acec2:	setb   0x80(%rsp)
  1aceca:	cmp    0x140(%rsp),%rdx
  1aced2:	setb   %bpl
  1aced6:	cmp    %r14,%r12
  1aced9:	mov    %r8,%rdx
  1acedc:	setb   0xb0(%rsp)
  1acee4:	movzbl 0x130(%rsp),%r14d
  1aceed:	test   %r14b,0x120(%rsp)
  1acef5:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acefb:	mov    %r8,%rdx
  1acefe:	movzbl 0x168(%rsp),%r14d
  1acf07:	and    %r14b,0xa7(%rsp)
  1acf0f:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acf15:	mov    %r8,%rdx
  1acf18:	movzbl 0x170(%rsp),%r14d
  1acf21:	and    %r14b,0x160(%rsp)
  1acf29:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acf2f:	mov    %r8,%rdx
  1acf32:	movzbl 0x12e(%rsp),%r14d
  1acf3b:	and    %r14b,0x12f(%rsp)
  1acf43:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acf49:	mov    %r8,%rdx
  1acf4c:	movzbl 0x12c(%rsp),%r14d
  1acf55:	and    %r14b,0x12d(%rsp)
  1acf5d:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acf63:	mov    %r8,%rdx
  1acf66:	movzbl 0x12a(%rsp),%r14d
  1acf6f:	and    %r14b,0x12b(%rsp)
  1acf77:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acf7d:	mov    %r8,%rdx
  1acf80:	movzbl 0x158(%rsp),%r12d
  1acf89:	and    %r12b,0x129(%rsp)
  1acf91:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acf97:	mov    %r8,%rdx
  1acf9a:	movzbl 0x88(%rsp),%r12d
  1acfa3:	and    %r12b,0xa8(%rsp)
  1acfab:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acfb1:	mov    %r8,%rdx
  1acfb4:	movzbl 0x78(%rsp),%r12d
  1acfba:	and    %r12b,0xf8(%rsp)
  1acfc2:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acfc8:	mov    %r8,%rdx
  1acfcb:	movzbl 0x98(%rsp),%r12d
  1acfd4:	and    %r12b,0x118(%rsp)
  1acfdc:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acfe2:	mov    %r8,%rdx
  1acfe5:	movzbl 0x40(%rsp),%r12d
  1acfeb:	and    %r12b,0xc8(%rsp)
  1acff3:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1acff9:	mov    %r8,%rdx
  1acffc:	movzbl 0x128(%rsp),%r14d
  1ad005:	and    0x80(%rsp),%r14b
  1ad00d:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1ad013:	mov    %r8,%rdx
  1ad016:	and    0xb0(%rsp),%bpl
  1ad01e:	jne    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1ad024:	and    $0xfffffffffffffffe,%rax
  1ad028:	lea    (%r8,%rax,1),%rdx
  1ad02c:	mov    (%rsp),%r8
  1ad030:	shl    $0x6,%r8
  1ad034:	lea    (%r8,%r8,2),%r8
  1ad038:	add    %r15,%rsi
  1ad03b:	movupd (%rsi,%r9,1),%xmm0
  1ad041:	movupd 0x10(%rsi,%r9,1),%xmm1
  1ad048:	movupd (%rsi,%r10,1),%xmm2
  1ad04e:	addpd  %xmm0,%xmm2
  1ad052:	movupd 0x10(%rsi,%r10,1),%xmm0
  1ad059:	addpd  %xmm1,%xmm0
  1ad05d:	movupd (%rsi,%r13,1),%xmm1
  1ad063:	addpd  %xmm2,%xmm1
  1ad067:	movupd 0x10(%rsi,%r13,1),%xmm2
  1ad06e:	addpd  %xmm0,%xmm2
  1ad072:	movupd %xmm2,0x10(%rsi,%r8,1)
  1ad079:	movupd %xmm1,(%rsi,%r8,1)
  1ad07f:	add    $0x20,%rsi
  1ad083:	add    $0xfffffffffffffffe,%rax
  1ad087:	jne    1ad03b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x41bb>
  1ad089:	jmp    1a9fd9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1159>
  1ad08e:	xor    %r10d,%r10d
  1ad091:	sub    %r13,%rbx
  1ad094:	cmovae %rbx,%r10
  1ad098:	cmp    %r10,%rbp
  1ad09b:	cmovb  %rbp,%r10
  1ad09f:	mov    0x60(%rsp),%rdx
  1ad0a4:	cmp    %r10,%rdx
  1ad0a7:	cmovb  %rdx,%r10
  1ad0ab:	mov    %r11,%rdx
  1ad0ae:	shl    $0x4,%rdx
  1ad0b2:	lea    (%r15,%r14,1),%rsi
  1ad0b6:	lea    (%rdx,%rsi,1),%rbx
  1ad0ba:	add    $0x8,%rbx
  1ad0be:	add    %rdx,%rsi
  1ad0c1:	mov    %r10,%rbp
  1ad0c4:	shl    $0x4,%rbp
  1ad0c8:	add    %rsi,%rbp
  1ad0cb:	add    $0x8,%rbp
  1ad0cf:	mov    %r11,%rsi
  1ad0d2:	cmp    %rbx,%rbp
  1ad0d5:	mov    0x8(%rsp),%rbx
  1ad0da:	jb     1aa0b1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1231>
  1ad0e0:	mov    %r11,%rsi
  1ad0e3:	movabs $0xfffffffffffffff,%rbp
  1ad0ed:	cmp    %rbp,%r10
  1ad0f0:	mov    0x48(%rsp),%rbp
  1ad0f5:	ja     1aa0b1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1231>
  1ad0fb:	imul   $0xd0,(%rsp),%r10
  1ad103:	xor    %esi,%esi
  1ad105:	mov    0x8(%rsp),%rbx
  1ad10a:	sub    %r13,%rbx
  1ad10d:	cmovae %rbx,%rsi
  1ad111:	lea    (%r10,%rdx,1),%rbx
  1ad115:	cmp    %rsi,%rbp
  1ad118:	cmovb  %rbp,%rsi
  1ad11c:	lea    (%r15,%rbx,1),%r13
  1ad120:	mov    0x60(%rsp),%rbp
  1ad125:	cmp    %rsi,%rbp
  1ad128:	cmovb  %rbp,%rsi
  1ad12c:	add    %r15,%rbx
  1ad12f:	add    $0x8,%rbx
  1ad133:	mov    %rbx,0xb0(%rsp)
  1ad13b:	shl    $0x4,%rsi
  1ad13f:	lea    (%rsi,%r13,1),%rbx
  1ad143:	add    $0x8,%rbx
  1ad147:	mov    %rbx,0x78(%rsp)
  1ad14c:	lea    (%rsi,%r13,1),%rbx
  1ad150:	add    $0x10,%rbx
  1ad154:	mov    %rbx,0x40(%rsp)
  1ad159:	shl    $0x6,%r12
  1ad15d:	add    %rdx,%r12
  1ad160:	lea    (%r15,%r12,1),%rbx
  1ad164:	lea    (%rsi,%rbx,1),%rbp
  1ad168:	add    $0x8,%rbp
  1ad16c:	mov    %rbp,0x80(%rsp)
  1ad174:	add    %rbx,%rsi
  1ad177:	add    $0x10,%rsi
  1ad17b:	mov    %rsi,0x48(%rsp)
  1ad180:	cmp    0x40(%rsp),%r13
  1ad185:	setb   0xe0(%rsp)
  1ad18d:	mov    0x78(%rsp),%rsi
  1ad192:	cmp    %rsi,0xb0(%rsp)
  1ad19a:	setb   0x88(%rsp)
  1ad1a2:	cmp    %rbp,%r13
  1ad1a5:	setb   0x98(%rsp)
  1ad1ad:	cmp    %rsi,%rbx
  1ad1b0:	setb   0xc8(%rsp)
  1ad1b8:	cmp    0x48(%rsp),%r13
  1ad1bd:	lea    0x8(%r15,%r12,1),%r13
  1ad1c2:	setb   0xa8(%rsp)
  1ad1ca:	cmp    %rsi,%r13
  1ad1cd:	setb   0x78(%rsp)
  1ad1d2:	mov    0xb0(%rsp),%rbp
  1ad1da:	cmp    0x80(%rsp),%rbp
  1ad1e2:	setb   0x80(%rsp)
  1ad1ea:	mov    0x40(%rsp),%r12
  1ad1ef:	cmp    %r12,%rbx
  1ad1f2:	setb   0xf8(%rsp)
  1ad1fa:	cmp    0x48(%rsp),%rbp
  1ad1ff:	setb   0x48(%rsp)
  1ad204:	cmp    %r12,%r13
  1ad207:	mov    0x8(%rsp),%rbx
  1ad20c:	setb   %r13b
  1ad210:	mov    %r11,%rsi
  1ad213:	movzbl 0x88(%rsp),%ebp
  1ad21b:	test   %bpl,0xe0(%rsp)
  1ad223:	jne    1aa0b1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1231>
  1ad229:	mov    %r11,%rsi
  1ad22c:	movzbl 0xc8(%rsp),%ebp
  1ad234:	and    %bpl,0x98(%rsp)
  1ad23c:	jne    1aa0b1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1231>
  1ad242:	mov    %r11,%rsi
  1ad245:	movzbl 0x78(%rsp),%ebp
  1ad24a:	and    %bpl,0xa8(%rsp)
  1ad252:	jne    1aa0b1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1231>
  1ad258:	mov    %r11,%rsi
  1ad25b:	movzbl 0xf8(%rsp),%ebp
  1ad263:	and    %bpl,0x80(%rsp)
  1ad26b:	jne    1aa0b1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1231>
  1ad271:	mov    %r11,%rsi
  1ad274:	and    %r13b,0x48(%rsp)
  1ad279:	jne    1aa0b1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1231>
  1ad27f:	and    $0xfffffffffffffffe,%rax
  1ad283:	lea    (%r11,%rax,1),%rsi
  1ad287:	add    %r15,%rdx
  1ad28a:	movupd (%rdx,%r14,1),%xmm0
  1ad290:	movupd 0x10(%rdx,%r14,1),%xmm1
  1ad297:	movapd %xmm0,%xmm2
  1ad29b:	unpcklpd %xmm1,%xmm2
  1ad29f:	unpckhpd %xmm1,%xmm0
  1ad2a3:	movapd %xmm2,%xmm1
  1ad2a7:	mulpd  %xmm0,%xmm1
  1ad2ab:	addpd  %xmm1,%xmm1
  1ad2af:	mulpd  %xmm2,%xmm2
  1ad2b3:	mulpd  %xmm0,%xmm0
  1ad2b7:	subpd  %xmm0,%xmm2
  1ad2bb:	movapd %xmm2,%xmm0
  1ad2bf:	unpcklpd %xmm1,%xmm0
  1ad2c3:	unpckhpd %xmm1,%xmm2
  1ad2c7:	movupd %xmm2,0x10(%rdx,%r10,1)
  1ad2ce:	movupd %xmm0,(%rdx,%r10,1)
  1ad2d4:	add    $0x20,%rdx
  1ad2d8:	add    $0xfffffffffffffffe,%rax
  1ad2dc:	jne    1ad28a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x440a>
  1ad2de:	jmp    1aa0b1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1231>
  1ad2e3:	mov    0xd0(%rsp),%rsi
  1ad2eb:	mov    0x18(%rsp),%rdx
  1ad2f0:	cmp    %rdx,%rsi
  1ad2f3:	cmovb  %rsi,%rdx
  1ad2f7:	xor    %r14d,%r14d
  1ad2fa:	sub    %r12,%rbx
  1ad2fd:	cmovae %rbx,%r14
  1ad301:	cmp    %r14,%rdx
  1ad304:	cmovb  %rdx,%r14
  1ad308:	mov    0x60(%rsp),%rdx
  1ad30d:	cmp    %r14,%rdx
  1ad310:	cmovb  %rdx,%r14
  1ad314:	lea    (%r9,%r9,4),%rdx
  1ad318:	mov    %rbp,%rdi
  1ad31b:	shl    $0x4,%rdi
  1ad31f:	mov    %rdx,0xe0(%rsp)
  1ad327:	add    %r15,%rdx
  1ad32a:	lea    (%rdi,%rdx,1),%r11
  1ad32e:	add    $0x8,%r11
  1ad332:	add    %rdi,%rdx
  1ad335:	mov    %r14,%rsi
  1ad338:	shl    $0x4,%rsi
  1ad33c:	lea    (%rsi,%rdx,1),%rbx
  1ad340:	add    $0x8,%rbx
  1ad344:	mov    %rbp,%rdx
  1ad347:	cmp    %r11,%rbx
  1ad34a:	mov    0x8(%rsp),%rbx
  1ad34f:	jb     1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad355:	lea    (%r15,%r10,1),%rdx
  1ad359:	lea    (%rdi,%rdx,1),%r11
  1ad35d:	add    $0x8,%r11
  1ad361:	add    %rdi,%rdx
  1ad364:	add    %rdx,%rsi
  1ad367:	add    $0x8,%rsi
  1ad36b:	mov    %rbp,%rdx
  1ad36e:	cmp    %r11,%rsi
  1ad371:	jb     1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad377:	mov    %rbp,%rdx
  1ad37a:	movabs $0xfffffffffffffff,%rsi
  1ad384:	cmp    %rsi,%r14
  1ad387:	ja     1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad38d:	imul   $0xe0,(%rsp),%r14
  1ad395:	mov    0xd0(%rsp),%rdx
  1ad39d:	mov    0x18(%rsp),%r11
  1ad3a2:	cmp    %r11,%rdx
  1ad3a5:	cmovb  %rdx,%r11
  1ad3a9:	xor    %esi,%esi
  1ad3ab:	sub    %r12,%rbx
  1ad3ae:	cmovae %rbx,%rsi
  1ad3b2:	mov    %r14,0x140(%rsp)
  1ad3ba:	lea    (%r14,%rdi,1),%rdx
  1ad3be:	cmp    %rsi,%r11
  1ad3c1:	cmovb  %r11,%rsi
  1ad3c5:	lea    (%r15,%rdx,1),%r12
  1ad3c9:	mov    0x60(%rsp),%r11
  1ad3ce:	cmp    %rsi,%r11
  1ad3d1:	cmovb  %r11,%rsi
  1ad3d5:	add    %r15,%rdx
  1ad3d8:	add    $0x8,%rdx
  1ad3dc:	mov    %rdx,0x78(%rsp)
  1ad3e1:	shl    $0x4,%rsi
  1ad3e5:	lea    (%rsi,%r12,1),%r11
  1ad3e9:	add    $0x8,%r11
  1ad3ed:	lea    (%rsi,%r12,1),%rdx
  1ad3f1:	add    $0x10,%rdx
  1ad3f5:	mov    %rdx,0x40(%rsp)
  1ad3fa:	mov    0x58(%rsp),%r14
  1ad3ff:	add    %rdi,%r14
  1ad402:	lea    (%r15,%r14,1),%rdx
  1ad406:	add    $0x8,%rdx
  1ad40a:	mov    %rdx,0x48(%rsp)
  1ad40f:	add    %r15,%r14
  1ad412:	lea    (%rsi,%r14,1),%rdx
  1ad416:	add    $0x10,%rdx
  1ad41a:	mov    %rdx,0x100(%rsp)
  1ad422:	lea    (%r10,%rdi,1),%rdx
  1ad426:	lea    (%r15,%rdx,1),%rbx
  1ad42a:	add    $0x8,%rbx
  1ad42e:	mov    %rbx,0x60(%rsp)
  1ad433:	add    %r15,%rdx
  1ad436:	lea    (%rsi,%rdx,1),%rbx
  1ad43a:	add    $0x10,%rbx
  1ad43e:	mov    %rbx,0xd0(%rsp)
  1ad446:	lea    0x8(%rsi,%r14,1),%rbx
  1ad44b:	mov    %rbx,0xb0(%rsp)
  1ad453:	add    %rdx,%rsi
  1ad456:	add    $0x8,%rsi
  1ad45a:	mov    %rsi,0x18(%rsp)
  1ad45f:	cmp    0x40(%rsp),%r12
  1ad464:	setb   0x58(%rsp)
  1ad469:	mov    0x78(%rsp),%rsi
  1ad46e:	cmp    %r11,%rsi
  1ad471:	setb   0x88(%rsp)
  1ad479:	cmp    0x100(%rsp),%r12
  1ad481:	setb   0x80(%rsp)
  1ad489:	cmp    %r11,0x48(%rsp)
  1ad48e:	setb   0x98(%rsp)
  1ad496:	cmp    0xd0(%rsp),%r12
  1ad49e:	setb   0xc8(%rsp)
  1ad4a6:	cmp    %r11,0x60(%rsp)
  1ad4ab:	setb   0xa8(%rsp)
  1ad4b3:	cmp    0xb0(%rsp),%r12
  1ad4bb:	setb   0xf8(%rsp)
  1ad4c3:	cmp    %r11,%r14
  1ad4c6:	setb   0x118(%rsp)
  1ad4ce:	cmp    0x18(%rsp),%r12
  1ad4d3:	setb   0x120(%rsp)
  1ad4db:	cmp    %r11,%rdx
  1ad4de:	setb   0x130(%rsp)
  1ad4e6:	cmp    0x100(%rsp),%rsi
  1ad4ee:	setb   %r12b
  1ad4f2:	mov    0x40(%rsp),%r11
  1ad4f7:	cmp    %r11,0x48(%rsp)
  1ad4fc:	setb   0x48(%rsp)
  1ad501:	cmp    0xd0(%rsp),%rsi
  1ad509:	mov    0x8(%rsp),%rbx
  1ad50e:	setb   0x100(%rsp)
  1ad516:	cmp    %r11,0x60(%rsp)
  1ad51b:	setb   0x60(%rsp)
  1ad520:	cmp    0xb0(%rsp),%rsi
  1ad528:	setb   0xb0(%rsp)
  1ad530:	cmp    %r11,%r14
  1ad533:	setb   %r14b
  1ad537:	cmp    0x18(%rsp),%rsi
  1ad53c:	setb   %sil
  1ad540:	cmp    %r11,%rdx
  1ad543:	mov    %rbp,%rdx
  1ad546:	setb   0x18(%rsp)
  1ad54b:	movzbl 0x88(%rsp),%r11d
  1ad554:	test   %r11b,0x58(%rsp)
  1ad559:	jne    1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad55f:	mov    %rbp,%rdx
  1ad562:	movzbl 0x98(%rsp),%r11d
  1ad56b:	and    %r11b,0x80(%rsp)
  1ad573:	jne    1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad579:	mov    %rbp,%rdx
  1ad57c:	movzbl 0xa8(%rsp),%r11d
  1ad585:	and    %r11b,0xc8(%rsp)
  1ad58d:	jne    1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad593:	mov    %rbp,%rdx
  1ad596:	movzbl 0x118(%rsp),%r11d
  1ad59f:	and    %r11b,0xf8(%rsp)
  1ad5a7:	jne    1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad5ad:	mov    %rbp,%rdx
  1ad5b0:	movzbl 0x130(%rsp),%r11d
  1ad5b9:	and    %r11b,0x120(%rsp)
  1ad5c1:	jne    1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad5c7:	mov    %rbp,%rdx
  1ad5ca:	and    0x48(%rsp),%r12b
  1ad5cf:	jne    1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad5d5:	mov    %rbp,%rdx
  1ad5d8:	movzbl 0x60(%rsp),%r12d
  1ad5de:	and    %r12b,0x100(%rsp)
  1ad5e6:	jne    1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad5ec:	mov    %rbp,%rdx
  1ad5ef:	and    %r14b,0xb0(%rsp)
  1ad5f7:	jne    1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad5fd:	mov    %rbp,%rdx
  1ad600:	and    0x18(%rsp),%sil
  1ad605:	jne    1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad60b:	and    $0xfffffffffffffffe,%rax
  1ad60f:	lea    (%rax,%rbp,1),%rdx
  1ad613:	add    %r15,%rdi
  1ad616:	mov    0xe0(%rsp),%rsi
  1ad61e:	mov    0x140(%rsp),%r11
  1ad626:	movupd (%rdi,%rsi,1),%xmm0
  1ad62b:	movupd (%rdi,%r10,1),%xmm1
  1ad631:	addpd  %xmm0,%xmm1
  1ad635:	movupd %xmm1,(%rdi,%r11,1)
  1ad63b:	add    $0x10,%rdi
  1ad63f:	dec    %rax
  1ad642:	jne    1ad626 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x47a6>
  1ad644:	jmp    1aa195 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1315>
  1ad649:	mov    0x8(%rsp),%rbx
  1ad64e:	mov    0x1c0(%rsp),%r13
  1ad656:	mov    0x28(%rsp),%r11
  1ad65b:	mov    0x1c8(%rsp),%r10
  1ad663:	mov    0x50(%rsp),%r14
  1ad668:	mov    (%rsp),%rdi
  1ad66c:	imul   $0x160,%rdi,%rcx
  1ad673:	mov    0x20(%rsp),%r12
  1ad678:	mov    %r12,%rsi
  1ad67b:	shl    $0x4,%rsi
  1ad67f:	add    %r15,%rsi
  1ad682:	imul   $0x150,%rdi,%r8
  1ad689:	imul   $0x110,%rdi,%r9
  1ad690:	mov    0x60(%rsp),%rdi
  1ad695:	add    %r12,%rdi
  1ad698:	cmp    %rbx,%rdi
  1ad69b:	jae    1bee58 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15fd8>
  1ad6a1:	lea    (%rax,%r12,1),%rdi
  1ad6a5:	cmp    %rbx,%rdi
  1ad6a8:	jae    1bee48 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15fc8>
  1ad6ae:	lea    (%rdx,%r12,1),%rdi
  1ad6b2:	cmp    %rbx,%rdi
  1ad6b5:	jae    1bee38 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15fb8>
  1ad6bb:	inc    %r12
  1ad6be:	movupd (%rsi,%r9,1),%xmm0
  1ad6c4:	movupd (%rsi,%r8,1),%xmm1
  1ad6ca:	addpd  %xmm0,%xmm1
  1ad6ce:	movupd %xmm1,(%rsi,%rcx,1)
  1ad6d3:	add    $0x10,%rsi
  1ad6d7:	cmp    %r12,0x30(%rsp)
  1ad6dc:	jne    1ad690 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4810>
  1ad6de:	mov    0x1b0(%rsp),%r9
  1ad6e6:	xor    %ecx,%ecx
  1ad6e8:	xorpd  %xmm0,%xmm0
  1ad6ec:	xor    %esi,%esi
  1ad6ee:	xchg   %ax,%ax
  1ad6f0:	mov    (%r11,%rcx,8),%rdi
  1ad6f4:	lea    (%rdi,%rdx,1),%rax
  1ad6f8:	cmp    %rbx,%rax
  1ad6fb:	jae    1be188 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15308>
  1ad701:	shl    $0x4,%rax
  1ad705:	movsd  (%r15,%rax,1),%xmm1
  1ad70b:	ucomisd %xmm0,%xmm1
  1ad70f:	jne    1ad750 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x48d0>
  1ad711:	jp     1ad750 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x48d0>
  1ad713:	add    %r15,%rax
  1ad716:	movsd  0x8(%rax),%xmm1
  1ad71b:	ucomisd %xmm0,%xmm1
  1ad71f:	jne    1ad750 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x48d0>
  1ad721:	jp     1ad750 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x48d0>
  1ad723:	cmp    0x1d0(%rsp),%rdi
  1ad72b:	jae    1bec67 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15de7>
  1ad731:	movq   $0x15,(%r10,%rdi,8)
  1ad739:	inc    %rcx
  1ad73c:	cmp    %rcx,%r14
  1ad73f:	jne    1ad6f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4870>
  1ad741:	jmp    1ad768 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x48e8>
  1ad743:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ad750:	cmp    %r9,%rsi
  1ad753:	jae    1be8a4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15a24>
  1ad759:	mov    %rdi,(%r11,%rsi,8)
  1ad75d:	inc    %rsi
  1ad760:	inc    %rcx
  1ad763:	cmp    %rcx,%r14
  1ad766:	jne    1ad6f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4870>
  1ad768:	cmp    %r9,%rsi
  1ad76b:	ja     1bd451 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x145d1>
  1ad771:	test   %rsi,%rsi
  1ad774:	je     1ad7ab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x492b>
  1ad776:	shl    $0x3,%rsi
  1ad77a:	xor    %eax,%eax
  1ad77c:	nopl   0x0(%rax)
  1ad780:	mov    (%r11,%rax,1),%rdi
  1ad784:	cmp    0x1d0(%rsp),%rdi
  1ad78c:	jae    1be701 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15881>
  1ad792:	mov    0x1c8(%rsp),%rcx
  1ad79a:	movq   $0x16,(%rcx,%rdi,8)
  1ad7a2:	add    $0x8,%rax
  1ad7a6:	cmp    %rax,%rsi
  1ad7a9:	jne    1ad780 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4900>
  1ad7ab:	mov    $0x1,%r14d
  1ad7b1:	mov    0x90(%rsp),%rcx
  1ad7b9:	test   %rcx,%rcx
  1ad7bc:	je     1bc8c9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13a49>
  1ad7c2:	mov    %r15,0x138(%rsp)
  1ad7ca:	shl    $0x3,%rcx
  1ad7ce:	xor    %eax,%eax
  1ad7d0:	xor    %esi,%esi
  1ad7d2:	mov    0x1b0(%rsp),%r9
  1ad7da:	mov    0x1d0(%rsp),%rdx
  1ad7e2:	mov    0x110(%rsp),%r15
  1ad7ea:	mov    0x1c8(%rsp),%r10
  1ad7f2:	jmp    1ad809 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4989>
  1ad7f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ad800:	add    $0x8,%rax
  1ad804:	cmp    %rax,%rcx
  1ad807:	je     1ad82f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x49af>
  1ad809:	mov    (%r15,%rax,1),%rdi
  1ad80d:	cmp    %rdx,%rdi
  1ad810:	jae    1bd50a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1468a>
  1ad816:	cmpq   $0x16,(%r10,%rdi,8)
  1ad81b:	jae    1ad800 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4980>
  1ad81d:	cmp    %r9,%rsi
  1ad820:	jae    1bd997 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14b17>
  1ad826:	mov    %rdi,(%r11,%rsi,8)
  1ad82a:	inc    %rsi
  1ad82d:	jmp    1ad800 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4980>
  1ad82f:	cmp    %r9,%rsi
  1ad832:	ja     1b5aeb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc6b>
  1ad838:	test   %rsi,%rsi
  1ad83b:	mov    %rcx,0x90(%rsp)
  1ad843:	je     1ad878 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x49f8>
  1ad845:	mov    (%r11),%r8
  1ad848:	lea    -0x1(%rsi),%rax
  1ad84c:	mov    -0x8(%r11,%rsi,8),%rcx
  1ad851:	sub    %r8,%rcx
  1ad854:	setae  %dl
  1ad857:	cmp    %rax,%rcx
  1ad85a:	sete   %al
  1ad85d:	and    %dl,%al
  1ad85f:	cmp    $0x1,%al
  1ad861:	jne    1ad87f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x49ff>
  1ad863:	add    %r8,%rsi
  1ad866:	mov    0x1d0(%rsp),%rdx
  1ad86e:	mov    0x90(%rsp),%rcx
  1ad876:	jae    1ad894 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4a14>
  1ad878:	xor    %esi,%esi
  1ad87a:	xor    %r8d,%r8d
  1ad87d:	jmp    1ad894 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4a14>
  1ad87f:	xor    %esi,%esi
  1ad881:	xor    %r8d,%r8d
  1ad884:	mov    0x1d0(%rsp),%rdx
  1ad88c:	mov    0x90(%rsp),%rcx
  1ad894:	xor    %eax,%eax
  1ad896:	xor    %r13d,%r13d
  1ad899:	jmp    1ad8a9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4a29>
  1ad89b:	nopl   0x0(%rax,%rax,1)
  1ad8a0:	add    $0x8,%rax
  1ad8a4:	cmp    %rax,%rcx
  1ad8a7:	je     1ad8cf <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4a4f>
  1ad8a9:	mov    (%r15,%rax,1),%rdi
  1ad8ad:	cmp    %rdx,%rdi
  1ad8b0:	jae    1bd51a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1469a>
  1ad8b6:	cmpq   $0x17,(%r10,%rdi,8)
  1ad8bb:	jae    1ad8a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4a20>
  1ad8bd:	cmp    %r9,%r13
  1ad8c0:	jae    1bd9aa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14b2a>
  1ad8c6:	mov    %rdi,(%r11,%r13,8)
  1ad8ca:	inc    %r13
  1ad8cd:	jmp    1ad8a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4a20>
  1ad8cf:	cmp    %r9,%r13
  1ad8d2:	ja     1b5afd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc7d>
  1ad8d8:	test   %r13,%r13
  1ad8db:	je     1aefce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x614e>
  1ad8e1:	mov    (%r11),%rax
  1ad8e4:	lea    -0x1(%r13),%rcx
  1ad8e8:	mov    -0x8(%r11,%r13,8),%rdx
  1ad8ed:	sub    %rax,%rdx
  1ad8f0:	setae  %dil
  1ad8f4:	cmp    %rcx,%rdx
  1ad8f7:	sete   %cl
  1ad8fa:	and    %dil,%cl
  1ad8fd:	cmp    $0x1,%cl
  1ad900:	jne    1ad91c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4a9c>
  1ad902:	mov    %rax,%rcx
  1ad905:	add    %r13,%rcx
  1ad908:	jb     1ad91c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4a9c>
  1ad90a:	mov    $0x1,%dl
  1ad90c:	mov    %edx,0x20(%rsp)
  1ad910:	mov    %rcx,0x30(%rsp)
  1ad915:	mov    %rax,0x60(%rsp)
  1ad91a:	jmp    1ad92e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4aae>
  1ad91c:	mov    %r8,0x60(%rsp)
  1ad921:	mov    %rsi,0x30(%rsp)
  1ad926:	movl   $0x0,0x20(%rsp)
  1ad92e:	mov    0x110(%rsp),%r15
  1ad936:	lea    0x0(,%r13,8),%rbp
  1ad93e:	mov    (%rsp),%rcx
  1ad942:	lea    (%rcx,%rcx,4),%rax
  1ad946:	lea    (%rcx,%rax,4),%r14
  1ad94a:	add    %rcx,%r14
  1ad94d:	lea    (%rcx,%rcx,8),%rax
  1ad951:	mov    %rax,0x50(%rsp)
  1ad956:	lea    (%rax,%rax,2),%rax
  1ad95a:	mov    %rax,0x18(%rsp)
  1ad95f:	xor    %r12d,%r12d
  1ad962:	xorpd  %xmm1,%xmm1
  1ad966:	jmp    1ad9b5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4b35>
  1ad968:	nopl   0x0(%rax,%rax,1)
  1ad970:	mov    $0x1b,%r8d
  1ad976:	mov    $0x16,%r9d
  1ad97c:	mov    %rax,%rdi
  1ad97f:	mov    %rbx,%rsi
  1ad982:	mov    (%rsp),%rdx
  1ad986:	call   1a8d70 <oneloop::native::batch::copy_active_column::<f64>>
  1ad98b:	xorpd  %xmm1,%xmm1
  1ad98f:	mov    0x1c8(%rsp),%r10
  1ad997:	mov    0x110(%rsp),%r15
  1ad99f:	mov    0x28(%rsp),%r11
  1ad9a4:	mov    0x1b0(%rsp),%r9
  1ad9ac:	add    $0x8,%r12
  1ad9b0:	cmp    %r12,%rbp
  1ad9b3:	je     1ada33 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4bb3>
  1ad9b5:	mov    (%r11,%r12,1),%rcx
  1ad9b9:	lea    (%rcx,%r14,1),%rdi
  1ad9bd:	cmp    %rbx,%rdi
  1ad9c0:	jae    1bd687 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14807>
  1ad9c6:	shl    $0x4,%rdi
  1ad9ca:	mov    0x138(%rsp),%rax
  1ad9d2:	movsd  (%rax,%rdi,1),%xmm0
  1ad9d7:	ucomisd %xmm1,%xmm0
  1ad9db:	jne    1ad970 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4af0>
  1ad9dd:	jp     1ad970 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4af0>
  1ad9df:	add    %rax,%rdi
  1ad9e2:	movsd  0x8(%rdi),%xmm0
  1ad9e7:	ucomisd %xmm1,%xmm0
  1ad9eb:	jne    1ad970 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4af0>
  1ad9ed:	jp     1ad970 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4af0>
  1ad9ef:	add    0x18(%rsp),%rcx
  1ad9f4:	cmp    %rbx,%rcx
  1ad9f7:	jae    1be152 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x152d2>
  1ad9fd:	cmpq   $0x3,0x1e0(%rsp)
  1ada06:	jbe    1bda1c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14b9c>
  1ada0c:	shl    $0x4,%rcx
  1ada10:	mov    0x1d8(%rsp),%rax
  1ada18:	movupd 0x30(%rax),%xmm0
  1ada1d:	mov    0x138(%rsp),%rax
  1ada25:	movupd %xmm0,(%rax,%rcx,1)
  1ada2a:	add    $0x8,%r12
  1ada2e:	cmp    %r12,%rbp
  1ada31:	jne    1ad9b5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4b35>
  1ada33:	mov    (%rsp),%rax
  1ada37:	mov    0x18(%rsp),%rcx
  1ada3c:	add    %rax,%rcx
  1ada3f:	xor    %r12d,%r12d
  1ada42:	xorpd  %xmm8,%xmm8
  1ada47:	movapd 0x1fe85b0(%rip),%xmm9        # 2196000 <_fini+0x520>
  1ada50:	movsd  0x1fe9c58(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1ada58:	movsd  0x1fe9c58(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1ada60:	mov    %rcx,0x10(%rsp)
  1ada65:	data16 cs nopw 0x0(%rax,%rax,1)
  1ada70:	mov    (%r11,%r12,1),%r14
  1ada74:	mov    0x18(%rsp),%rax
  1ada79:	lea    (%r14,%rax,1),%rdi
  1ada7d:	cmp    %rbx,%rdi
  1ada80:	jae    1bd6aa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1482a>
  1ada86:	shl    $0x4,%rdi
  1ada8a:	mov    0x138(%rsp),%rax
  1ada92:	movupd (%rax,%rdi,1),%xmm0
  1ada97:	movapd %xmm0,%xmm1
  1ada9b:	unpckhpd %xmm0,%xmm1
  1ada9f:	ucomisd %xmm8,%xmm1
  1adaa4:	jne    1adac0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4c40>
  1adaa6:	jp     1adac0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4c40>
  1adaa8:	andpd  %xmm9,%xmm0
  1adaad:	jmp    1adb90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4d10>
  1adab2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1adac0:	ucomisd %xmm8,%xmm0
  1adac5:	jne    1adad7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4c57>
  1adac7:	jp     1adad7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4c57>
  1adac9:	andpd  %xmm9,%xmm1
  1adace:	movapd %xmm1,%xmm0
  1adad2:	jmp    1adb90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4d10>
  1adad7:	movapd %xmm0,%xmm2
  1adadb:	andpd  %xmm9,%xmm2
  1adae0:	pshufd $0xee,%xmm2,%xmm3
  1adae5:	movapd %xmm2,%xmm4
  1adae9:	cmplesd %xmm3,%xmm4
  1adaee:	movapd %xmm4,%xmm5
  1adaf2:	andpd  %xmm3,%xmm5
  1adaf6:	andnpd %xmm2,%xmm4
  1adafa:	orpd   %xmm5,%xmm4
  1adafe:	movapd %xmm0,%xmm2
  1adb02:	cmpunordsd %xmm0,%xmm2
  1adb07:	movapd %xmm2,%xmm5
  1adb0b:	andnpd %xmm4,%xmm5
  1adb0f:	andpd  %xmm3,%xmm2
  1adb13:	orpd   %xmm5,%xmm2
  1adb17:	ucomisd %xmm6,%xmm2
  1adb1b:	jbe    1adb3c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4cbc>
  1adb1d:	ucomisd %xmm2,%xmm7
  1adb21:	jbe    1adb3c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4cbc>
  1adb23:	mulpd  %xmm0,%xmm0
  1adb27:	movapd %xmm0,%xmm1
  1adb2b:	unpckhpd %xmm0,%xmm1
  1adb2f:	addsd  %xmm0,%xmm1
  1adb33:	xorps  %xmm0,%xmm0
  1adb36:	sqrtsd %xmm1,%xmm0
  1adb3a:	jmp    1adb90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4d10>
  1adb3c:	call   *0x251e08e(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1adb42:	movapd 0x1fe84b5(%rip),%xmm9        # 2196000 <_fini+0x520>
  1adb4b:	xorpd  %xmm8,%xmm8
  1adb50:	mov    0x10(%rsp),%rcx
  1adb55:	movsd  0x1fe9b5b(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1adb5d:	movsd  0x1fe9b4b(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1adb65:	mov    0x1c8(%rsp),%r10
  1adb6d:	mov    0x110(%rsp),%r15
  1adb75:	mov    0x28(%rsp),%r11
  1adb7a:	mov    0x1b0(%rsp),%r9
  1adb82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1adb90:	add    %rcx,%r14
  1adb93:	cmp    %rbx,%r14
  1adb96:	jae    1bd697 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14817>
  1adb9c:	shl    $0x4,%r14
  1adba0:	mov    0x138(%rsp),%rax
  1adba8:	movsd  %xmm0,(%rax,%r14,1)
  1adbae:	movq   $0x0,0x8(%rax,%r14,1)
  1adbb7:	add    $0x8,%r12
  1adbbb:	cmp    %r12,%rbp
  1adbbe:	jne    1ada70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4bf0>
  1adbc4:	cmpb   $0x0,0x20(%rsp)
  1adbc9:	je     1adde1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4f61>
  1adbcf:	mov    0x60(%rsp),%rbp
  1adbd4:	cmp    0x30(%rsp),%rbp
  1adbd9:	jae    1adf03 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5083>
  1adbdf:	cmpq   $0x2,0x1e0(%rsp)
  1adbe8:	mov    (%rsp),%rax
  1adbec:	jb     1bf251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163d1>
  1adbf2:	lea    (%rax,%rax,1),%rdx
  1adbf6:	mov    0x18(%rsp),%rax
  1adbfb:	mov    %rdx,0x20(%rsp)
  1adc00:	add    %rdx,%rax
  1adc03:	lea    (%rcx,%rbp,1),%r14
  1adc07:	xor    %ecx,%ecx
  1adc09:	mov    %rbx,%rdx
  1adc0c:	sub    %r14,%rdx
  1adc0f:	cmovb  %rcx,%rdx
  1adc13:	lea    (%rax,%rbp,1),%r12
  1adc17:	mov    %rbx,%rsi
  1adc1a:	sub    %r12,%rsi
  1adc1d:	cmovb  %rcx,%rsi
  1adc21:	cmp    %rsi,%rdx
  1adc24:	cmovae %rsi,%rdx
  1adc28:	mov    %rbp,%rcx
  1adc2b:	not    %rcx
  1adc2e:	add    0x30(%rsp),%rcx
  1adc33:	cmp    %rcx,%rdx
  1adc36:	cmovae %rcx,%rdx
  1adc3a:	lea    0x1(%rdx),%rdi
  1adc3e:	mov    %rbp,%r11
  1adc41:	cmp    $0x22,%rdi
  1adc45:	mov    0x138(%rsp),%r15
  1adc4d:	ja     1ae485 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5605>
  1adc53:	mov    (%rsp),%r9
  1adc57:	imul   $0x1d0,%r9,%r8
  1adc5e:	mov    %r11,%rdx
  1adc61:	shl    $0x4,%rdx
  1adc65:	add    %r15,%rdx
  1adc68:	imul   $0x1c0,%r9,%r10
  1adc6f:	mov    0x1d8(%rsp),%r14
  1adc77:	mov    0x30(%rsp),%r15
  1adc7c:	mov    %rbp,%r12
  1adc7f:	nop
  1adc80:	mov    0x10(%rsp),%rdi
  1adc85:	add    %r11,%rdi
  1adc88:	cmp    %rbx,%rdi
  1adc8b:	jae    1be53c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x156bc>
  1adc91:	lea    (%rax,%r11,1),%rdi
  1adc95:	cmp    %rbx,%rdi
  1adc98:	jae    1be52c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x156ac>
  1adc9e:	inc    %r11
  1adca1:	movupd 0x10(%r14),%xmm0
  1adca7:	movsd  (%rdx,%r10,1),%xmm1
  1adcad:	movsd  0x8(%rdx,%r10,1),%xmm2
  1adcb4:	unpcklpd %xmm1,%xmm1
  1adcb8:	mulpd  %xmm0,%xmm1
  1adcbc:	shufpd $0x1,%xmm0,%xmm0
  1adcc1:	unpcklpd %xmm2,%xmm2
  1adcc5:	mulpd  %xmm0,%xmm2
  1adcc9:	movapd %xmm1,%xmm0
  1adccd:	subpd  %xmm2,%xmm0
  1adcd1:	addpd  %xmm1,%xmm2
  1adcd5:	movsd  %xmm0,%xmm2
  1adcd9:	movupd %xmm2,(%rdx,%r8,1)
  1adcdf:	add    $0x10,%rdx
  1adce3:	cmp    %r11,%r15
  1adce6:	jne    1adc80 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4e00>
  1adce8:	mov    %r9,%rdx
  1adceb:	shl    $0x5,%rdx
  1adcef:	sub    0x20(%rsp),%rdx
  1adcf4:	mov    0x18(%rsp),%rdi
  1adcf9:	add    %r12,%rdi
  1adcfc:	xor    %r9d,%r9d
  1adcff:	mov    %rbx,%r10
  1add02:	mov    %rdi,0x10(%rsp)
  1add07:	sub    %rdi,%r10
  1add0a:	cmovb  %r9,%r10
  1add0e:	cmp    %rsi,%r10
  1add11:	cmovae %rsi,%r10
  1add15:	lea    (%r12,%rdx,1),%rbp
  1add19:	mov    %rbx,%rdi
  1add1c:	sub    %rbp,%rdi
  1add1f:	cmovb  %r9,%rdi
  1add23:	cmp    %rdi,%r10
  1add26:	cmovb  %r10,%rdi
  1add2a:	cmp    %rcx,%rdi
  1add2d:	cmovae %rcx,%rdi
  1add31:	lea    0x1(%rdi),%r9
  1add35:	mov    %r12,%r14
  1add38:	cmp    $0x42,%r9
  1add3c:	mov    0x138(%rsp),%r15
  1add44:	ja     1ae716 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5896>
  1add4a:	mov    (%rsp),%r9
  1add4e:	imul   $0x1e0,%r9,%rcx
  1add55:	mov    %r14,%rsi
  1add58:	shl    $0x4,%rsi
  1add5c:	add    %r15,%rsi
  1add5f:	imul   $0x1b0,%r9,%r9
  1add66:	mov    0x28(%rsp),%r11
  1add6b:	mov    0x1c8(%rsp),%r10
  1add73:	mov    0x30(%rsp),%r15
  1add78:	nopl   0x0(%rax,%rax,1)
  1add80:	mov    0x18(%rsp),%rdi
  1add85:	add    %r14,%rdi
  1add88:	cmp    %rbx,%rdi
  1add8b:	jae    1be56c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x156ec>
  1add91:	lea    (%rax,%r14,1),%rdi
  1add95:	cmp    %rbx,%rdi
  1add98:	jae    1be55c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x156dc>
  1add9e:	lea    (%rdx,%r14,1),%rdi
  1adda2:	cmp    %rbx,%rdi
  1adda5:	jae    1be54c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x156cc>
  1addab:	inc    %r14
  1addae:	movupd (%rsi,%r9,1),%xmm0
  1addb4:	movupd (%rsi,%r8,1),%xmm1
  1addba:	addpd  %xmm0,%xmm1
  1addbe:	movupd %xmm1,(%rsi,%rcx,1)
  1addc3:	add    $0x10,%rsi
  1addc7:	cmp    %r14,%r15
  1addca:	jne    1add80 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4f00>
  1addcc:	mov    0x1b0(%rsp),%r9
  1addd4:	mov    0x110(%rsp),%r15
  1adddc:	jmp    1adf12 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5092>
  1adde1:	cmpq   $0x2,0x1e0(%rsp)
  1addea:	mov    0x1d8(%rsp),%r8
  1addf2:	jb     1bf251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163d1>
  1addf8:	mov    (%rsp),%rax
  1addfc:	lea    (%rax,%rax,1),%rcx
  1ade00:	mov    0x18(%rsp),%rax
  1ade05:	lea    (%rcx,%rax,1),%rsi
  1ade09:	xor    %edx,%edx
  1ade0b:	mov    0x138(%rsp),%r14
  1ade13:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ade20:	mov    (%r11,%rdx,1),%rdi
  1ade24:	mov    0x10(%rsp),%rax
  1ade29:	add    %rdi,%rax
  1ade2c:	cmp    %rbx,%rax
  1ade2f:	jae    1bdd7e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14efe>
  1ade35:	add    %rsi,%rdi
  1ade38:	cmp    %rbx,%rdi
  1ade3b:	jae    1bdd6e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14eee>
  1ade41:	shl    $0x4,%rax
  1ade45:	shl    $0x4,%rdi
  1ade49:	movupd 0x10(%r8),%xmm0
  1ade4f:	movsd  (%r14,%rax,1),%xmm1
  1ade55:	movsd  0x8(%r14,%rax,1),%xmm2
  1ade5c:	unpcklpd %xmm1,%xmm1
  1ade60:	mulpd  %xmm0,%xmm1
  1ade64:	shufpd $0x1,%xmm0,%xmm0
  1ade69:	unpcklpd %xmm2,%xmm2
  1ade6d:	mulpd  %xmm0,%xmm2
  1ade71:	movapd %xmm1,%xmm0
  1ade75:	subpd  %xmm2,%xmm0
  1ade79:	addpd  %xmm1,%xmm2
  1ade7d:	movsd  %xmm0,%xmm2
  1ade81:	movupd %xmm2,(%r14,%rdi,1)
  1ade87:	add    $0x8,%rdx
  1ade8b:	cmp    %rdx,%rbp
  1ade8e:	jne    1ade20 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4fa0>
  1ade90:	mov    (%rsp),%rdx
  1ade94:	shl    $0x5,%rdx
  1ade98:	sub    %rcx,%rdx
  1ade9b:	xor    %r8d,%r8d
  1ade9e:	xchg   %ax,%ax
  1adea0:	mov    (%r11,%r8,1),%rdi
  1adea4:	mov    0x18(%rsp),%rax
  1adea9:	add    %rdi,%rax
  1adeac:	cmp    %rbx,%rax
  1adeaf:	jae    1bddb4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14f34>
  1adeb5:	lea    (%rdi,%rsi,1),%rcx
  1adeb9:	cmp    %rbx,%rcx
  1adebc:	jae    1bdda1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14f21>
  1adec2:	add    %rdx,%rdi
  1adec5:	cmp    %rbx,%rdi
  1adec8:	jae    1bdd91 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14f11>
  1adece:	shl    $0x4,%rax
  1aded2:	shl    $0x4,%rcx
  1aded6:	shl    $0x4,%rdi
  1adeda:	movupd (%r14,%rax,1),%xmm0
  1adee0:	movupd (%r14,%rcx,1),%xmm1
  1adee6:	addpd  %xmm0,%xmm1
  1adeea:	movupd %xmm1,(%r14,%rdi,1)
  1adef0:	add    $0x8,%r8
  1adef4:	cmp    %r8,%rbp
  1adef7:	jne    1adea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5020>
  1adef9:	mov    0x110(%rsp),%r15
  1adf01:	jmp    1adf12 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5092>
  1adf03:	mov    (%rsp),%rdx
  1adf07:	lea    (%rdx,%rdx,1),%rax
  1adf0b:	shl    $0x5,%rdx
  1adf0f:	sub    %rax,%rdx
  1adf12:	xor    %ecx,%ecx
  1adf14:	xorpd  %xmm0,%xmm0
  1adf18:	xor    %r14d,%r14d
  1adf1b:	mov    0x138(%rsp),%rsi
  1adf23:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1adf30:	mov    (%r11,%rcx,8),%rdi
  1adf34:	lea    (%rdi,%rdx,1),%rax
  1adf38:	cmp    %rbx,%rax
  1adf3b:	jae    1bd6ba <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1483a>
  1adf41:	shl    $0x4,%rax
  1adf45:	movsd  (%rsi,%rax,1),%xmm1
  1adf4a:	ucomisd %xmm0,%xmm1
  1adf4e:	jne    1adf90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5110>
  1adf50:	jp     1adf90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5110>
  1adf52:	add    %rsi,%rax
  1adf55:	movsd  0x8(%rax),%xmm1
  1adf5a:	ucomisd %xmm0,%xmm1
  1adf5e:	jne    1adf90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5110>
  1adf60:	jp     1adf90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5110>
  1adf62:	cmp    0x1d0(%rsp),%rdi
  1adf6a:	jae    1be19b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1531b>
  1adf70:	movq   $0x1f,(%r10,%rdi,8)
  1adf78:	inc    %rcx
  1adf7b:	cmp    %rcx,%r13
  1adf7e:	jne    1adf30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x50b0>
  1adf80:	jmp    1adfa8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5128>
  1adf82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1adf90:	cmp    %r9,%r14
  1adf93:	jae    1bdbcf <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14d4f>
  1adf99:	mov    %rdi,(%r11,%r14,8)
  1adf9d:	inc    %r14
  1adfa0:	inc    %rcx
  1adfa3:	cmp    %rcx,%r13
  1adfa6:	jne    1adf30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x50b0>
  1adfa8:	cmp    %r9,%r14
  1adfab:	ja     1bd35d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x144dd>
  1adfb1:	test   %r14,%r14
  1adfb4:	mov    0x1d0(%rsp),%rdx
  1adfbc:	mov    0x90(%rsp),%rcx
  1adfc4:	je     1aefce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x614e>
  1adfca:	mov    (%r11),%r13
  1adfcd:	lea    -0x1(%r14),%rax
  1adfd1:	mov    -0x8(%r11,%r14,8),%rcx
  1adfd6:	sub    %r13,%rcx
  1adfd9:	setae  %dl
  1adfdc:	cmp    %rax,%rcx
  1adfdf:	sete   %al
  1adfe2:	and    %dl,%al
  1adfe4:	cmp    $0x1,%al
  1adfe6:	jne    1ae018 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5198>
  1adfe8:	mov    %r13,%rax
  1adfeb:	add    %r14,%rax
  1adfee:	movabs $0x7fffffffffffffff,%rsi
  1adff8:	mov    0x138(%rsp),%r15
  1ae000:	jb     1bd4b3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14633>
  1ae006:	mov    $0x1,%cl
  1ae008:	mov    %ecx,0x20(%rsp)
  1ae00c:	mov    %rax,0x30(%rsp)
  1ae011:	mov    %r13,0x60(%rsp)
  1ae016:	jmp    1ae032 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x51b2>
  1ae018:	movl   $0x0,0x20(%rsp)
  1ae020:	movabs $0x7fffffffffffffff,%rsi
  1ae02a:	mov    0x138(%rsp),%r15
  1ae032:	shl    $0x3,%r14
  1ae036:	mov    0x50(%rsp),%rax
  1ae03b:	mov    (%rsp),%rcx
  1ae03f:	lea    (%rcx,%rax,2),%rax
  1ae043:	mov    %rax,0x10(%rsp)
  1ae048:	shl    $0x5,%rcx
  1ae04c:	mov    %rcx,0x18(%rsp)
  1ae051:	xor    %ebp,%ebp
  1ae053:	movapd 0x1fe7fa4(%rip),%xmm8        # 2196000 <_fini+0x520>
  1ae05c:	xorpd  %xmm9,%xmm9
  1ae061:	movsd  0x1fe965e(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1ae06a:	movapd 0x1fe7f9d(%rip),%xmm11        # 2196010 <_fini+0x530>
  1ae073:	movsd  0x1fe9644(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1ae07c:	nopl   0x0(%rax)
  1ae080:	mov    (%r11,%rbp,1),%r12
  1ae084:	mov    0x10(%rsp),%rax
  1ae089:	lea    (%r12,%rax,1),%rdi
  1ae08d:	cmp    %rbx,%rdi
  1ae090:	jae    1bdabd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c3d>
  1ae096:	shl    $0x4,%rdi
  1ae09a:	movupd (%r15,%rdi,1),%xmm0
  1ae0a0:	movapd %xmm0,%xmm2
  1ae0a4:	andpd  %xmm8,%xmm2
  1ae0a9:	movapd %xmm0,%xmm1
  1ae0ad:	unpckhpd %xmm0,%xmm1
  1ae0b1:	movapd %xmm1,%xmm3
  1ae0b5:	andpd  %xmm8,%xmm3
  1ae0ba:	ucomisd %xmm9,%xmm0
  1ae0bf:	je     1ae120 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x52a0>
  1ae0c1:	ucomisd %xmm9,%xmm1
  1ae0c6:	je     1ae120 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x52a0>
  1ae0c8:	movapd %xmm2,%xmm4
  1ae0cc:	cmplesd %xmm3,%xmm4
  1ae0d1:	movapd %xmm4,%xmm5
  1ae0d5:	andpd  %xmm3,%xmm5
  1ae0d9:	andnpd %xmm2,%xmm4
  1ae0dd:	orpd   %xmm5,%xmm4
  1ae0e1:	ucomisd %xmm6,%xmm4
  1ae0e5:	jbe    1ae120 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x52a0>
  1ae0e7:	ucomisd %xmm4,%xmm7
  1ae0eb:	jbe    1ae120 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x52a0>
  1ae0ed:	movapd %xmm0,%xmm2
  1ae0f1:	mulpd  %xmm0,%xmm2
  1ae0f5:	movapd %xmm2,%xmm3
  1ae0f9:	unpckhpd %xmm2,%xmm3
  1ae0fd:	addsd  %xmm2,%xmm3
  1ae101:	movapd %xmm10,%xmm2
  1ae106:	divsd  %xmm3,%xmm2
  1ae10a:	mulsd  %xmm2,%xmm0
  1ae10e:	xorpd  %xmm11,%xmm1
  1ae113:	mulsd  %xmm2,%xmm1
  1ae117:	jmp    1ae211 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5391>
  1ae11c:	nopl   0x0(%rax)
  1ae120:	ucomisd %xmm9,%xmm1
  1ae125:	setnp  %al
  1ae128:	sete   %cl
  1ae12b:	and    %al,%cl
  1ae12d:	movq   %xmm0,%rax
  1ae132:	and    %rsi,%rax
  1ae135:	movabs $0x7ff0000000000000,%r8
  1ae13f:	cmp    %r8,%rax
  1ae142:	setl   %dl
  1ae145:	test   %dl,%cl
  1ae147:	je     1ae160 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x52e0>
  1ae149:	movapd %xmm10,%xmm2
  1ae14e:	divsd  %xmm0,%xmm2
  1ae152:	xorpd  %xmm11,%xmm1
  1ae157:	movapd %xmm2,%xmm0
  1ae15b:	jmp    1ae211 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5391>
  1ae160:	ucomisd %xmm9,%xmm0
  1ae165:	setnp  %cl
  1ae168:	sete   %dl
  1ae16b:	and    %cl,%dl
  1ae16d:	movq   %xmm1,%rcx
  1ae172:	and    %rsi,%rcx
  1ae175:	cmp    %r8,%rcx
  1ae178:	setl   %sil
  1ae17c:	test   %sil,%dl
  1ae17f:	je     1ae190 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5310>
  1ae181:	movapd %xmm12,%xmm2
  1ae186:	divsd  %xmm1,%xmm2
  1ae18a:	movapd %xmm2,%xmm1
  1ae18e:	jmp    1ae207 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5387>
  1ae190:	movabs $0x7fefffffffffffff,%rdx
  1ae19a:	cmp    %rdx,%rax
  1ae19d:	setg   %al
  1ae1a0:	cmp    %rdx,%rcx
  1ae1a3:	setg   %cl
  1ae1a6:	or     %al,%cl
  1ae1a8:	cmp    $0x1,%cl
  1ae1ab:	jne    1ae242 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x53c2>
  1ae1b1:	add    %r15,%rdi
  1ae1b4:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1ae1b9:	movsd  0x1fe94fe(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1ae1c2:	movapd 0x1fe7e45(%rip),%xmm11        # 2196010 <_fini+0x530>
  1ae1cb:	movsd  0x1fe94f4(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1ae1d4:	xorpd  %xmm9,%xmm9
  1ae1d9:	movapd 0x1fe7e1e(%rip),%xmm8        # 2196000 <_fini+0x520>
  1ae1e2:	movsd  0x1fe94ce(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1ae1ea:	movsd  0x1fe94be(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1ae1f2:	mov    0x1c8(%rsp),%r10
  1ae1fa:	mov    0x28(%rsp),%r11
  1ae1ff:	mov    0x1b0(%rsp),%r9
  1ae207:	movabs $0x7fffffffffffffff,%rsi
  1ae211:	add    0x18(%rsp),%r12
  1ae216:	cmp    %rbx,%r12
  1ae219:	jae    1bdaaa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c2a>
  1ae21f:	shl    $0x4,%r12
  1ae223:	movsd  %xmm0,(%r15,%r12,1)
  1ae229:	movsd  %xmm1,0x8(%r15,%r12,1)
  1ae230:	add    $0x8,%rbp
  1ae234:	cmp    %rbp,%r14
  1ae237:	jne    1ae080 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5200>
  1ae23d:	jmp    1ae2cc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x544c>
  1ae242:	ucomisd %xmm9,%xmm1
  1ae247:	movabs $0x7fffffffffffffff,%rsi
  1ae251:	jne    1ae259 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x53d9>
  1ae253:	jnp    1ae149 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x52c9>
  1ae259:	ucomisd %xmm9,%xmm0
  1ae25e:	jne    1ae271 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x53f1>
  1ae260:	jp     1ae271 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x53f1>
  1ae262:	movapd %xmm12,%xmm2
  1ae267:	divsd  %xmm1,%xmm2
  1ae26b:	movapd %xmm2,%xmm1
  1ae26f:	jmp    1ae211 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5391>
  1ae271:	movapd %xmm3,%xmm1
  1ae275:	cmplesd %xmm2,%xmm1
  1ae27a:	movapd %xmm1,%xmm4
  1ae27e:	andpd  %xmm2,%xmm4
  1ae282:	andnpd %xmm3,%xmm1
  1ae286:	orpd   %xmm4,%xmm1
  1ae28a:	unpcklpd %xmm1,%xmm1
  1ae28e:	divpd  %xmm1,%xmm0
  1ae292:	movapd %xmm0,%xmm2
  1ae296:	xorpd  %xmm11,%xmm2
  1ae29b:	movsd  %xmm0,%xmm2
  1ae29f:	mulpd  %xmm0,%xmm0
  1ae2a3:	movapd %xmm0,%xmm3
  1ae2a7:	unpcklpd %xmm0,%xmm3
  1ae2ab:	unpckhpd %xmm0,%xmm0
  1ae2af:	addpd  %xmm3,%xmm0
  1ae2b3:	divpd  %xmm0,%xmm2
  1ae2b7:	divpd  %xmm1,%xmm2
  1ae2bb:	movapd %xmm2,%xmm0
  1ae2bf:	movapd %xmm2,%xmm1
  1ae2c3:	unpckhpd %xmm2,%xmm1
  1ae2c7:	jmp    1ae211 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5391>
  1ae2cc:	cmpb   $0x0,0x20(%rsp)
  1ae2d1:	je     1ae38b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x550b>
  1ae2d7:	mov    0x30(%rsp),%rdx
  1ae2dc:	mov    0x60(%rsp),%r13
  1ae2e1:	cmp    %rdx,%r13
  1ae2e4:	mov    0x18(%rsp),%rbp
  1ae2e9:	jae    1aef8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x610d>
  1ae2ef:	mov    (%rsp),%rax
  1ae2f3:	add    %rax,%rax
  1ae2f6:	cmpq   $0x0,0x1e0(%rsp)
  1ae2ff:	je     1bf1f4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16374>
  1ae305:	mov    (%rsp),%rcx
  1ae309:	add    %rbp,%rcx
  1ae30c:	mov    %r13,%r9
  1ae30f:	not    %r9
  1ae312:	add    %rdx,%r9
  1ae315:	lea    (%rax,%r13,1),%r10
  1ae319:	xor    %esi,%esi
  1ae31b:	mov    %rbx,%rdx
  1ae31e:	sub    %r10,%rdx
  1ae321:	cmovb  %rsi,%rdx
  1ae325:	mov    %r13,%r11
  1ae328:	add    %rbp,%r11
  1ae32b:	mov    %rbx,%rdi
  1ae32e:	sub    %r11,%rdi
  1ae331:	cmovb  %rsi,%rdi
  1ae335:	cmp    %rdi,%rdx
  1ae338:	cmovb  %rdx,%rdi
  1ae33c:	lea    (%rcx,%r13,1),%r12
  1ae340:	mov    %rbx,%rdx
  1ae343:	sub    %r12,%rdx
  1ae346:	cmovb  %rsi,%rdx
  1ae34a:	cmp    %rdx,%rdi
  1ae34d:	cmovb  %rdi,%rdx
  1ae351:	cmp    %rdx,%r9
  1ae354:	cmovb  %r9,%rdx
  1ae358:	lea    0x1(%rdx),%rsi
  1ae35c:	cmp    $0x20,%rsi
  1ae360:	ja     1aeaa4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5c24>
  1ae366:	mov    0x1d8(%rsp),%r11
  1ae36e:	mov    0x1b0(%rsp),%r9
  1ae376:	mov    0x1c8(%rsp),%r10
  1ae37e:	mov    0x30(%rsp),%r15
  1ae383:	mov    %r13,%r12
  1ae386:	jmp    1aeed1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6051>
  1ae38b:	mov    (%rsp),%rax
  1ae38f:	lea    (%rax,%rax,1),%rcx
  1ae393:	cmpq   $0x0,0x1e0(%rsp)
  1ae39c:	mov    0x1d8(%rsp),%r8
  1ae3a4:	mov    0x18(%rsp),%r15
  1ae3a9:	je     1bf113 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16293>
  1ae3af:	mov    (%rsp),%rax
  1ae3b3:	lea    (%rax,%r15,1),%rdx
  1ae3b7:	xor    %esi,%esi
  1ae3b9:	mov    0x138(%rsp),%r11
  1ae3c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ae3d0:	mov    0x28(%rsp),%rax
  1ae3d5:	mov    (%rax,%rsi,1),%rdi
  1ae3d9:	lea    (%rdi,%rcx,1),%r13
  1ae3dd:	cmp    %rbx,%r13
  1ae3e0:	jae    1bf11f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1629f>
  1ae3e6:	lea    (%rdi,%r15,1),%rax
  1ae3ea:	cmp    %rbx,%rax
  1ae3ed:	jae    1be326 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x154a6>
  1ae3f3:	add    %rdx,%rdi
  1ae3f6:	cmp    %rbx,%rdi
  1ae3f9:	jae    1be316 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15496>
  1ae3ff:	shl    $0x4,%r13
  1ae403:	shl    $0x4,%rax
  1ae407:	movupd (%r11,%r13,1),%xmm0
  1ae40d:	movupd (%r8),%xmm1
  1ae412:	movapd %xmm0,%xmm2
  1ae416:	mulpd  %xmm1,%xmm2
  1ae41a:	shl    $0x4,%rdi
  1ae41e:	movupd (%r11,%rax,1),%xmm3
  1ae424:	movapd %xmm2,%xmm4
  1ae428:	unpcklpd %xmm2,%xmm4
  1ae42c:	unpckhpd %xmm2,%xmm2
  1ae430:	subpd  %xmm2,%xmm4
  1ae434:	mulpd  %xmm3,%xmm4
  1ae438:	movapd %xmm1,%xmm2
  1ae43c:	unpckhpd %xmm1,%xmm2
  1ae440:	mulsd  %xmm0,%xmm2
  1ae444:	unpckhpd %xmm0,%xmm0
  1ae448:	mulsd  %xmm1,%xmm0
  1ae44c:	addsd  %xmm2,%xmm0
  1ae450:	unpcklpd %xmm0,%xmm0
  1ae454:	shufpd $0x1,%xmm3,%xmm3
  1ae459:	mulpd  %xmm0,%xmm3
  1ae45d:	movapd %xmm4,%xmm0
  1ae461:	subpd  %xmm3,%xmm0
  1ae465:	addpd  %xmm4,%xmm3
  1ae469:	movsd  %xmm0,%xmm3
  1ae46d:	movupd %xmm3,(%r11,%rdi,1)
  1ae473:	add    $0x8,%rsi
  1ae477:	cmp    %rsi,%r14
  1ae47a:	jne    1ae3d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5550>
  1ae480:	jmp    1aef8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x610d>
  1ae485:	xor    %edi,%edi
  1ae487:	mov    %rbx,%r8
  1ae48a:	sub    %r14,%r8
  1ae48d:	cmovb  %rdi,%r8
  1ae491:	mov    %rbx,%r10
  1ae494:	sub    %r12,%r10
  1ae497:	cmovb  %rdi,%r10
  1ae49b:	cmp    %r10,%r8
  1ae49e:	cmovb  %r8,%r10
  1ae4a2:	cmp    %rcx,%r10
  1ae4a5:	cmovae %rcx,%r10
  1ae4a9:	imul   $0x1c0,(%rsp),%rdi
  1ae4b1:	mov    %rbp,%r8
  1ae4b4:	shl    $0x4,%r8
  1ae4b8:	lea    (%r15,%rdi,1),%r9
  1ae4bc:	lea    (%r8,%r9,1),%rbx
  1ae4c0:	add    $0x8,%rbx
  1ae4c4:	add    %r8,%r9
  1ae4c7:	mov    %r10,%r11
  1ae4ca:	shl    $0x4,%r11
  1ae4ce:	add    %r11,%r9
  1ae4d1:	add    $0x8,%r9
  1ae4d5:	mov    %rbp,%r11
  1ae4d8:	cmp    %rbx,%r9
  1ae4db:	mov    0x8(%rsp),%rbx
  1ae4e0:	jb     1adc53 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4dd3>
  1ae4e6:	mov    %rbp,%r11
  1ae4e9:	movabs $0xfffffffffffffff,%r9
  1ae4f3:	cmp    %r9,%r10
  1ae4f6:	ja     1adc53 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4dd3>
  1ae4fc:	imul   $0x1d0,(%rsp),%r10
  1ae504:	xor    %r9d,%r9d
  1ae507:	mov    %rbx,%r11
  1ae50a:	sub    %r14,%r11
  1ae50d:	cmovb  %r9,%r11
  1ae511:	mov    0x8(%rsp),%rbx
  1ae516:	sub    %r12,%rbx
  1ae519:	cmovb  %r9,%rbx
  1ae51d:	cmp    %rbx,%r11
  1ae520:	cmovb  %r11,%rbx
  1ae524:	lea    (%r10,%r8,1),%r9
  1ae528:	cmp    %rcx,%rbx
  1ae52b:	cmovae %rcx,%rbx
  1ae52f:	lea    (%r15,%r9,1),%r11
  1ae533:	shl    $0x4,%rbx
  1ae537:	lea    (%rbx,%r11,1),%r14
  1ae53b:	add    $0x8,%r14
  1ae53f:	mov    %r14,0xd0(%rsp)
  1ae547:	lea    0x8(%r15,%r9,1),%r9
  1ae54c:	mov    %r9,0xe0(%rsp)
  1ae554:	lea    0x10(%rbx,%r11,1),%r12
  1ae559:	mov    %r12,0x100(%rsp)
  1ae561:	lea    (%rdi,%r8,1),%r9
  1ae565:	mov    %r9,0xb0(%rsp)
  1ae56d:	lea    (%r15,%r9,1),%r14
  1ae571:	lea    0x8(%rbx,%r14,1),%r9
  1ae576:	mov    %r9,0x58(%rsp)
  1ae57b:	add    %r14,%rbx
  1ae57e:	add    $0x10,%rbx
  1ae582:	mov    %rbx,0x38(%rsp)
  1ae587:	cmp    %r12,%r11
  1ae58a:	setb   0x40(%rsp)
  1ae58f:	mov    0xe0(%rsp),%r9
  1ae597:	mov    0xd0(%rsp),%r12
  1ae59f:	cmp    %r12,%r9
  1ae5a2:	setb   0x48(%rsp)
  1ae5a7:	mov    0x58(%rsp),%rbx
  1ae5ac:	cmp    %rbx,%r11
  1ae5af:	setb   0x88(%rsp)
  1ae5b7:	cmp    %r12,%r14
  1ae5ba:	setb   0x78(%rsp)
  1ae5bf:	cmp    0x38(%rsp),%r11
  1ae5c4:	mov    0xb0(%rsp),%r11
  1ae5cc:	lea    0x8(%r15,%r11,1),%r11
  1ae5d1:	setb   0xb0(%rsp)
  1ae5d9:	cmp    %r12,%r11
  1ae5dc:	setb   0xd0(%rsp)
  1ae5e4:	cmp    %rbx,%r9
  1ae5e7:	setb   0x80(%rsp)
  1ae5ef:	mov    0x100(%rsp),%r12
  1ae5f7:	cmp    %r12,%r14
  1ae5fa:	setb   0x58(%rsp)
  1ae5ff:	cmp    0x38(%rsp),%r9
  1ae604:	mov    0x8(%rsp),%rbx
  1ae609:	setb   %r9b
  1ae60d:	cmp    %r12,%r11
  1ae610:	setb   %r14b
  1ae614:	mov    %rbp,%r11
  1ae617:	movzbl 0x48(%rsp),%r12d
  1ae61d:	test   %r12b,0x40(%rsp)
  1ae622:	jne    1adc53 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4dd3>
  1ae628:	mov    %rbp,%r11
  1ae62b:	movzbl 0x78(%rsp),%r12d
  1ae631:	and    %r12b,0x88(%rsp)
  1ae639:	jne    1adc53 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4dd3>
  1ae63f:	mov    %rbp,%r11
  1ae642:	movzbl 0xd0(%rsp),%r12d
  1ae64b:	and    %r12b,0xb0(%rsp)
  1ae653:	jne    1adc53 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4dd3>
  1ae659:	mov    %rbp,%r11
  1ae65c:	movzbl 0x80(%rsp),%r12d
  1ae665:	and    0x58(%rsp),%r12b
  1ae66a:	jne    1adc53 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4dd3>
  1ae670:	mov    %rbp,%r11
  1ae673:	and    %r14b,%r9b
  1ae676:	jne    1adc53 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4dd3>
  1ae67c:	and    $0xfffffffffffffffe,%rdx
  1ae680:	lea    (%rdx,%rbp,1),%r11
  1ae684:	mov    0x1d8(%rsp),%r9
  1ae68c:	movsd  0x10(%r9),%xmm0
  1ae692:	movsd  0x18(%r9),%xmm1
  1ae698:	unpcklpd %xmm1,%xmm1
  1ae69c:	unpcklpd %xmm0,%xmm0
  1ae6a0:	add    %r15,%r8
  1ae6a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ae6b0:	movupd (%r8,%rdi,1),%xmm2
  1ae6b6:	movupd 0x10(%r8,%rdi,1),%xmm3
  1ae6bd:	movapd %xmm2,%xmm4
  1ae6c1:	unpcklpd %xmm3,%xmm4
  1ae6c5:	unpckhpd %xmm3,%xmm2
  1ae6c9:	movapd %xmm1,%xmm3
  1ae6cd:	mulpd  %xmm4,%xmm3
  1ae6d1:	movapd %xmm0,%xmm5
  1ae6d5:	mulpd  %xmm2,%xmm5
  1ae6d9:	addpd  %xmm3,%xmm5
  1ae6dd:	mulpd  %xmm0,%xmm4
  1ae6e1:	mulpd  %xmm1,%xmm2
  1ae6e5:	subpd  %xmm2,%xmm4
  1ae6e9:	movapd %xmm4,%xmm2
  1ae6ed:	unpcklpd %xmm5,%xmm2
  1ae6f1:	unpckhpd %xmm5,%xmm4
  1ae6f5:	movupd %xmm4,0x10(%r8,%r10,1)
  1ae6fc:	movupd %xmm2,(%r8,%r10,1)
  1ae702:	add    $0x20,%r8
  1ae706:	add    $0xfffffffffffffffe,%rdx
  1ae70a:	jne    1ae6b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5830>
  1ae70c:	mov    0x60(%rsp),%rbp
  1ae711:	jmp    1adc53 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4dd3>
  1ae716:	xor    %r9d,%r9d
  1ae719:	mov    %rbx,%r10
  1ae71c:	sub    0x10(%rsp),%r10
  1ae721:	cmovb  %r9,%r10
  1ae725:	cmp    %rsi,%r10
  1ae728:	cmovae %rsi,%r10
  1ae72c:	mov    %rbx,%r11
  1ae72f:	sub    %rbp,%r11
  1ae732:	cmovb  %r9,%r11
  1ae736:	cmp    %r11,%r10
  1ae739:	cmovb  %r10,%r11
  1ae73d:	cmp    %rcx,%r11
  1ae740:	cmovae %rcx,%r11
  1ae744:	imul   $0x1b0,(%rsp),%r9
  1ae74c:	mov    %r12,%r10
  1ae74f:	shl    $0x4,%r10
  1ae753:	mov    %r9,0x20(%rsp)
  1ae758:	lea    (%r15,%r9,1),%rbx
  1ae75c:	lea    (%r10,%rbx,1),%r12
  1ae760:	add    $0x8,%r12
  1ae764:	add    %r10,%rbx
  1ae767:	mov    %r11,%r9
  1ae76a:	shl    $0x4,%r9
  1ae76e:	add    %r9,%rbx
  1ae771:	add    $0x8,%rbx
  1ae775:	mov    0x60(%rsp),%r14
  1ae77a:	cmp    %r12,%rbx
  1ae77d:	mov    0x8(%rsp),%rbx
  1ae782:	jb     1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1ae788:	lea    (%r15,%r8,1),%rbx
  1ae78c:	lea    (%r10,%rbx,1),%r12
  1ae790:	add    $0x8,%r12
  1ae794:	add    %r10,%rbx
  1ae797:	add    %rbx,%r9
  1ae79a:	add    $0x8,%r9
  1ae79e:	mov    0x8(%rsp),%rbx
  1ae7a3:	mov    0x60(%rsp),%r14
  1ae7a8:	cmp    %r12,%r9
  1ae7ab:	mov    0x60(%rsp),%r9
  1ae7b0:	jb     1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1ae7b6:	mov    %r9,%r14
  1ae7b9:	movabs $0xfffffffffffffff,%r9
  1ae7c3:	cmp    %r9,%r11
  1ae7c6:	ja     1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1ae7cc:	imul   $0x1e0,(%rsp),%r11
  1ae7d4:	xor    %r9d,%r9d
  1ae7d7:	mov    0x8(%rsp),%rbx
  1ae7dc:	sub    0x10(%rsp),%rbx
  1ae7e1:	cmovb  %r9,%rbx
  1ae7e5:	cmp    %rsi,%rbx
  1ae7e8:	cmovae %rsi,%rbx
  1ae7ec:	mov    0x8(%rsp),%rsi
  1ae7f1:	sub    %rbp,%rsi
  1ae7f4:	cmovb  %r9,%rsi
  1ae7f8:	mov    %r11,0x140(%rsp)
  1ae800:	lea    (%r11,%r10,1),%r14
  1ae804:	cmp    %rsi,%rbx
  1ae807:	cmovb  %rbx,%rsi
  1ae80b:	lea    (%r15,%r14,1),%r9
  1ae80f:	cmp    %rcx,%rsi
  1ae812:	cmovae %rcx,%rsi
  1ae816:	shl    $0x4,%rsi
  1ae81a:	lea    (%rsi,%r9,1),%rbx
  1ae81e:	add    $0x8,%rbx
  1ae822:	lea    0x8(%r15,%r14,1),%rbp
  1ae827:	lea    0x10(%rsi,%r9,1),%rcx
  1ae82c:	mov    %rcx,0x58(%rsp)
  1ae831:	mov    0x20(%rsp),%r11
  1ae836:	lea    (%r11,%r10,1),%r12
  1ae83a:	lea    (%r15,%r12,1),%r14
  1ae83e:	lea    0x8(%r15,%r12,1),%rcx
  1ae843:	mov    %rcx,0xe0(%rsp)
  1ae84b:	lea    0x10(%rsi,%r14,1),%r12
  1ae850:	mov    %r12,0xb0(%rsp)
  1ae858:	mov    %r14,0xd0(%rsp)
  1ae860:	lea    (%r8,%r10,1),%r11
  1ae864:	lea    (%r15,%r11,1),%rcx
  1ae868:	mov    0x138(%rsp),%r15
  1ae870:	lea    0x8(%r15,%r11,1),%r15
  1ae875:	mov    %rcx,0x48(%rsp)
  1ae87a:	lea    0x10(%rsi,%rcx,1),%r11
  1ae87f:	mov    %r11,0x88(%rsp)
  1ae887:	lea    0x8(%rsi,%r14,1),%r11
  1ae88c:	mov    %r11,0x100(%rsp)
  1ae894:	add    %rcx,%rsi
  1ae897:	add    $0x8,%rsi
  1ae89b:	mov    %rsi,0x10(%rsp)
  1ae8a0:	mov    0x58(%rsp),%r14
  1ae8a5:	cmp    %r14,%r9
  1ae8a8:	setb   0x38(%rsp)
  1ae8ad:	cmp    %rbx,%rbp
  1ae8b0:	setb   0x40(%rsp)
  1ae8b5:	cmp    %r12,%r9
  1ae8b8:	setb   0x78(%rsp)
  1ae8bd:	mov    0xe0(%rsp),%rsi
  1ae8c5:	cmp    %rbx,%rsi
  1ae8c8:	setb   0x80(%rsp)
  1ae8d0:	mov    0x88(%rsp),%rcx
  1ae8d8:	cmp    %rcx,%r9
  1ae8db:	setb   0x98(%rsp)
  1ae8e3:	cmp    %rbx,%r15
  1ae8e6:	setb   0xc8(%rsp)
  1ae8ee:	cmp    %r11,%r9
  1ae8f1:	setb   0xa8(%rsp)
  1ae8f9:	mov    0xd0(%rsp),%r11
  1ae901:	cmp    %rbx,%r11
  1ae904:	setb   0xf8(%rsp)
  1ae90c:	cmp    0x10(%rsp),%r9
  1ae911:	setb   0x118(%rsp)
  1ae919:	mov    0x48(%rsp),%r12
  1ae91e:	cmp    %rbx,%r12
  1ae921:	setb   0x120(%rsp)
  1ae929:	cmp    0xb0(%rsp),%rbp
  1ae931:	setb   0xb0(%rsp)
  1ae939:	cmp    %r14,%rsi
  1ae93c:	setb   0xe0(%rsp)
  1ae944:	cmp    %rcx,%rbp
  1ae947:	setb   0x88(%rsp)
  1ae94f:	cmp    %r14,%r15
  1ae952:	mov    0x138(%rsp),%r15
  1ae95a:	setb   0x130(%rsp)
  1ae962:	cmp    0x100(%rsp),%rbp
  1ae96a:	setb   %r9b
  1ae96e:	cmp    %r14,%r11
  1ae971:	mov    0x8(%rsp),%rbx
  1ae976:	setb   0x100(%rsp)
  1ae97e:	cmp    0x10(%rsp),%rbp
  1ae983:	setb   %sil
  1ae987:	cmp    %r14,%r12
  1ae98a:	mov    0x60(%rsp),%rcx
  1ae98f:	mov    %rcx,%r14
  1ae992:	setb   %bpl
  1ae996:	movzbl 0x40(%rsp),%r12d
  1ae99c:	test   %r12b,0x38(%rsp)
  1ae9a1:	jne    1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1ae9a7:	mov    %rcx,%r14
  1ae9aa:	movzbl 0x80(%rsp),%r12d
  1ae9b3:	and    %r12b,0x78(%rsp)
  1ae9b8:	jne    1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1ae9be:	mov    %rcx,%r14
  1ae9c1:	movzbl 0xc8(%rsp),%r12d
  1ae9ca:	and    %r12b,0x98(%rsp)
  1ae9d2:	jne    1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1ae9d8:	mov    %rcx,%r14
  1ae9db:	movzbl 0xf8(%rsp),%r12d
  1ae9e4:	and    %r12b,0xa8(%rsp)
  1ae9ec:	jne    1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1ae9f2:	mov    %rcx,%r14
  1ae9f5:	movzbl 0x120(%rsp),%r12d
  1ae9fe:	and    %r12b,0x118(%rsp)
  1aea06:	jne    1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1aea0c:	mov    %rcx,%r14
  1aea0f:	movzbl 0xe0(%rsp),%r12d
  1aea18:	and    %r12b,0xb0(%rsp)
  1aea20:	jne    1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1aea26:	mov    %rcx,%r14
  1aea29:	movzbl 0x130(%rsp),%r12d
  1aea32:	and    %r12b,0x88(%rsp)
  1aea3a:	jne    1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1aea40:	mov    %rcx,%r14
  1aea43:	and    0x100(%rsp),%r9b
  1aea4b:	jne    1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1aea51:	mov    %rcx,%r14
  1aea54:	and    %bpl,%sil
  1aea57:	jne    1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1aea5d:	and    $0xfffffffffffffffe,%rdi
  1aea61:	lea    (%rcx,%rdi,1),%r14
  1aea65:	add    %r15,%r10
  1aea68:	mov    0x20(%rsp),%rcx
  1aea6d:	mov    0x140(%rsp),%rsi
  1aea75:	data16 cs nopw 0x0(%rax,%rax,1)
  1aea80:	movupd (%r10,%rcx,1),%xmm0
  1aea86:	movupd (%r10,%r8,1),%xmm1
  1aea8c:	addpd  %xmm0,%xmm1
  1aea90:	movupd %xmm1,(%r10,%rsi,1)
  1aea96:	add    $0x10,%r10
  1aea9a:	dec    %rdi
  1aea9d:	jne    1aea80 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5c00>
  1aea9f:	jmp    1add4a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x4eca>
  1aeaa4:	xor    %esi,%esi
  1aeaa6:	mov    %rbx,%rdi
  1aeaa9:	sub    %r10,%rdi
  1aeaac:	cmovb  %rsi,%rdi
  1aeab0:	mov    %rbx,%r8
  1aeab3:	sub    %r11,%rbx
  1aeab6:	cmovb  %rsi,%rbx
  1aeaba:	cmp    %rbx,%rdi
  1aeabd:	cmovb  %rdi,%rbx
  1aeac1:	sub    %r12,%r8
  1aeac4:	cmovb  %rsi,%r8
  1aeac8:	cmp    %r8,%rbx
  1aeacb:	cmovb  %rbx,%r8
  1aeacf:	cmp    %r8,%r9
  1aead2:	cmovb  %r9,%r8
  1aead6:	mov    %r13,%rsi
  1aead9:	shl    $0x4,%rsi
  1aeadd:	mov    0x138(%rsp),%r15
  1aeae5:	lea    (%r15,%rbp,1),%rdi
  1aeae9:	lea    (%rsi,%rdi,1),%rbx
  1aeaed:	add    $0x8,%rbx
  1aeaf1:	add    %rsi,%rdi
  1aeaf4:	mov    %r8,%r13
  1aeaf7:	shl    $0x4,%r13
  1aeafb:	add    %r13,%rdi
  1aeafe:	add    $0x8,%rdi
  1aeb02:	cmp    %rbx,%rdi
  1aeb05:	jb     1aee46 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5fc6>
  1aeb0b:	mov    (%rsp),%rdi
  1aeb0f:	shl    $0x9,%rdi
  1aeb13:	lea    (%r15,%rdi,1),%rbx
  1aeb17:	lea    (%rsi,%rbx,1),%rbp
  1aeb1b:	add    $0x8,%rbp
  1aeb1f:	add    %rsi,%rbx
  1aeb22:	add    %r13,%rbx
  1aeb25:	add    $0x8,%rbx
  1aeb29:	cmp    %rbp,%rbx
  1aeb2c:	jb     1aee81 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6001>
  1aeb32:	movabs $0xfffffffffffffff,%rbx
  1aeb3c:	cmp    %rbx,%r8
  1aeb3f:	mov    0x8(%rsp),%rbx
  1aeb44:	ja     1aee86 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6006>
  1aeb4a:	imul   $0x210,(%rsp),%r8
  1aeb52:	xor    %ebp,%ebp
  1aeb54:	mov    %rbx,%r13
  1aeb57:	sub    %r10,%r13
  1aeb5a:	cmovb  %rbp,%r13
  1aeb5e:	mov    %rbx,%r10
  1aeb61:	sub    %r11,%r10
  1aeb64:	cmovb  %rbp,%r10
  1aeb68:	cmp    %r10,%r13
  1aeb6b:	cmovb  %r13,%r10
  1aeb6f:	sub    %r12,%rbx
  1aeb72:	cmovb  %rbp,%rbx
  1aeb76:	cmp    %rbx,%r10
  1aeb79:	cmovb  %r10,%rbx
  1aeb7d:	lea    (%r8,%rsi,1),%r10
  1aeb81:	cmp    %rbx,%r9
  1aeb84:	cmovb  %r9,%rbx
  1aeb88:	lea    (%r15,%r10,1),%r12
  1aeb8c:	shl    $0x4,%rbx
  1aeb90:	lea    (%rbx,%r12,1),%r9
  1aeb94:	add    $0x8,%r9
  1aeb98:	lea    0x8(%r15,%r10,1),%r10
  1aeb9d:	lea    0x10(%rbx,%r12,1),%r11
  1aeba2:	mov    0x18(%rsp),%r13
  1aeba7:	lea    0x0(%r13,%rsi,1),%rbp
  1aebac:	lea    (%r15,%rbp,1),%r13
  1aebb0:	lea    0x8(%r15,%rbp,1),%rbp
  1aebb5:	mov    %rbp,0x20(%rsp)
  1aebba:	mov    %r13,0xd0(%rsp)
  1aebc2:	lea    0x10(%rbx,%r13,1),%rbp
  1aebc7:	mov    %rbp,0x38(%rsp)
  1aebcc:	lea    0x8(%rbx,%r13,1),%rbp
  1aebd1:	mov    %rbp,0x50(%rsp)
  1aebd6:	lea    (%rdi,%rsi,1),%r13
  1aebda:	mov    %r13,0x100(%rsp)
  1aebe2:	lea    (%r15,%r13,1),%rbp
  1aebe6:	lea    0x8(%rbx,%rbp,1),%r13
  1aebeb:	mov    %r13,0x10(%rsp)
  1aebf0:	add    %rbp,%rbx
  1aebf3:	add    $0x10,%rbx
  1aebf7:	mov    %rbx,0xb0(%rsp)
  1aebff:	cmp    %r11,%r12
  1aec02:	setb   0x40(%rsp)
  1aec07:	cmp    %r9,%r10
  1aec0a:	setb   0x48(%rsp)
  1aec0f:	cmp    0x38(%rsp),%r12
  1aec14:	setb   0xe0(%rsp)
  1aec1c:	cmp    %r9,0x20(%rsp)
  1aec21:	setb   0x58(%rsp)
  1aec26:	cmp    0x50(%rsp),%r12
  1aec2b:	setb   0x88(%rsp)
  1aec33:	mov    0xd0(%rsp),%r13
  1aec3b:	cmp    %r9,%r13
  1aec3e:	setb   0x78(%rsp)
  1aec43:	cmp    0x10(%rsp),%r12
  1aec48:	setb   0x80(%rsp)
  1aec50:	cmp    %r9,%rbp
  1aec53:	setb   0x98(%rsp)
  1aec5b:	cmp    %rbx,%r12
  1aec5e:	mov    0x100(%rsp),%rbx
  1aec66:	lea    0x8(%r15,%rbx,1),%rbx
  1aec6b:	setb   %r12b
  1aec6f:	cmp    %r9,%rbx
  1aec72:	setb   0x100(%rsp)
  1aec7a:	cmp    0x38(%rsp),%r10
  1aec7f:	setb   %r15b
  1aec83:	cmp    %r11,0x20(%rsp)
  1aec88:	setb   0x20(%rsp)
  1aec8d:	cmp    0x50(%rsp),%r10
  1aec92:	setb   0x50(%rsp)
  1aec97:	cmp    %r11,%r13
  1aec9a:	setb   0x38(%rsp)
  1aec9f:	cmp    0x10(%rsp),%r10
  1aeca4:	setb   %r13b
  1aeca8:	cmp    %r11,%rbp
  1aecab:	setb   %bpl
  1aecaf:	cmp    0xb0(%rsp),%r10
  1aecb7:	setb   %r10b
  1aecbb:	cmp    %r11,%rbx
  1aecbe:	setb   %r9b
  1aecc2:	movzbl 0x48(%rsp),%r11d
  1aecc8:	test   %r11b,0x40(%rsp)
  1aeccd:	jne    1aee81 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6001>
  1aecd3:	movzbl 0x58(%rsp),%r11d
  1aecd9:	and    %r11b,0xe0(%rsp)
  1aece1:	jne    1aee81 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6001>
  1aece7:	movzbl 0x78(%rsp),%r11d
  1aeced:	and    %r11b,0x88(%rsp)
  1aecf5:	mov    0x8(%rsp),%rbx
  1aecfa:	jne    1aee86 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6006>
  1aed00:	movzbl 0x98(%rsp),%r11d
  1aed09:	and    %r11b,0x80(%rsp)
  1aed11:	jne    1aee86 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6006>
  1aed17:	and    0x100(%rsp),%r12b
  1aed1f:	jne    1aee86 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6006>
  1aed25:	and    0x20(%rsp),%r15b
  1aed2a:	mov    0x1d8(%rsp),%r11
  1aed32:	mov    0x30(%rsp),%r15
  1aed37:	mov    0x60(%rsp),%r12
  1aed3c:	jne    1aeebc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x603c>
  1aed42:	mov    %r9b,0x10(%rsp)
  1aed47:	movzbl 0x38(%rsp),%r9d
  1aed4d:	and    %r9b,0x50(%rsp)
  1aed52:	jne    1aeebc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x603c>
  1aed58:	and    %bpl,%r13b
  1aed5b:	jne    1aeebc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x603c>
  1aed61:	and    0x10(%rsp),%r10b
  1aed66:	mov    0x18(%rsp),%rbp
  1aed6b:	jne    1aeeaa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x602a>
  1aed71:	and    $0xfffffffffffffffe,%rdx
  1aed75:	add    %rdx,%r12
  1aed78:	movsd  (%r11),%xmm0
  1aed7d:	movsd  0x8(%r11),%xmm1
  1aed83:	unpcklpd %xmm0,%xmm0
  1aed87:	unpcklpd %xmm1,%xmm1
  1aed8b:	add    0x138(%rsp),%rsi
  1aed93:	mov    0x1b0(%rsp),%r9
  1aed9b:	mov    0x1c8(%rsp),%r10
  1aeda3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1aedb0:	movupd (%rsi,%rbp,1),%xmm2
  1aedb5:	movupd 0x10(%rsi,%rbp,1),%xmm3
  1aedbb:	movapd %xmm2,%xmm4
  1aedbf:	unpcklpd %xmm3,%xmm4
  1aedc3:	unpckhpd %xmm3,%xmm2
  1aedc7:	movapd %xmm2,%xmm3
  1aedcb:	mulpd  %xmm0,%xmm3
  1aedcf:	movapd %xmm0,%xmm5
  1aedd3:	mulpd  %xmm4,%xmm5
  1aedd7:	mulpd  %xmm1,%xmm4
  1aeddb:	addpd  %xmm3,%xmm4
  1aeddf:	movupd (%rsi,%rdi,1),%xmm3
  1aede4:	movupd 0x10(%rsi,%rdi,1),%xmm6
  1aedea:	movapd %xmm3,%xmm7
  1aedee:	unpcklpd %xmm6,%xmm7
  1aedf2:	unpckhpd %xmm6,%xmm3
  1aedf6:	movapd %xmm7,%xmm6
  1aedfa:	mulpd  %xmm4,%xmm6
  1aedfe:	mulpd  %xmm1,%xmm2
  1aee02:	subpd  %xmm2,%xmm5
  1aee06:	mulpd  %xmm5,%xmm7
  1aee0a:	mulpd  %xmm3,%xmm5
  1aee0e:	addpd  %xmm6,%xmm5
  1aee12:	mulpd  %xmm4,%xmm3
  1aee16:	subpd  %xmm3,%xmm7
  1aee1a:	movapd %xmm7,%xmm2
  1aee1e:	unpcklpd %xmm5,%xmm2
  1aee22:	unpckhpd %xmm5,%xmm7
  1aee26:	movupd %xmm7,0x10(%rsi,%r8,1)
  1aee2d:	movupd %xmm2,(%rsi,%r8,1)
  1aee33:	add    $0x20,%rsi
  1aee37:	add    $0xfffffffffffffffe,%rdx
  1aee3b:	jne    1aedb0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x5f30>
  1aee41:	jmp    1aeed1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6051>
  1aee46:	mov    0x8(%rsp),%rbx
  1aee4b:	mov    0x1d8(%rsp),%r11
  1aee53:	mov    0x1b0(%rsp),%r9
  1aee5b:	mov    0x1c8(%rsp),%r10
  1aee63:	mov    0x30(%rsp),%r15
  1aee68:	mov    0x60(%rsp),%r12
  1aee6d:	jmp    1aeed1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6051>
  1aee6f:	mov    0x28(%rsp),%r11
  1aee74:	mov    0x1c8(%rsp),%r10
  1aee7c:	jmp    1ad668 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x47e8>
  1aee81:	mov    0x8(%rsp),%rbx
  1aee86:	mov    0x1d8(%rsp),%r11
  1aee8e:	mov    0x1b0(%rsp),%r9
  1aee96:	mov    0x1c8(%rsp),%r10
  1aee9e:	mov    0x30(%rsp),%r15
  1aeea3:	mov    0x60(%rsp),%r12
  1aeea8:	jmp    1aeecc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x604c>
  1aeeaa:	mov    0x1b0(%rsp),%r9
  1aeeb2:	mov    0x1c8(%rsp),%r10
  1aeeba:	jmp    1aeed1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6051>
  1aeebc:	mov    0x1b0(%rsp),%r9
  1aeec4:	mov    0x1c8(%rsp),%r10
  1aeecc:	mov    0x18(%rsp),%rbp
  1aeed1:	mov    (%rsp),%r8
  1aeed5:	imul   $0x210,%r8,%rdx
  1aeedc:	mov    %r12,%rsi
  1aeedf:	shl    $0x4,%rsi
  1aeee3:	add    0x138(%rsp),%rsi
  1aeeeb:	shl    $0x9,%r8
  1aeeef:	nop
  1aeef0:	lea    (%rax,%r12,1),%rdi
  1aeef4:	cmp    %rbx,%rdi
  1aeef7:	jae    1bf1ff <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1637f>
  1aeefd:	lea    (%r12,%rbp,1),%rdi
  1aef01:	cmp    %rbx,%rdi
  1aef04:	jae    1beb91 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15d11>
  1aef0a:	lea    (%rcx,%r12,1),%rdi
  1aef0e:	cmp    %rbx,%rdi
  1aef11:	jae    1beb81 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15d01>
  1aef17:	inc    %r12
  1aef1a:	movupd (%rsi,%rbp,1),%xmm0
  1aef1f:	movupd (%r11),%xmm1
  1aef24:	movapd %xmm0,%xmm2
  1aef28:	mulpd  %xmm1,%xmm2
  1aef2c:	movupd (%rsi,%r8,1),%xmm3
  1aef32:	movapd %xmm2,%xmm4
  1aef36:	unpcklpd %xmm2,%xmm4
  1aef3a:	unpckhpd %xmm2,%xmm2
  1aef3e:	subpd  %xmm2,%xmm4
  1aef42:	mulpd  %xmm3,%xmm4
  1aef46:	movapd %xmm1,%xmm2
  1aef4a:	unpckhpd %xmm1,%xmm2
  1aef4e:	mulsd  %xmm0,%xmm2
  1aef52:	unpckhpd %xmm0,%xmm0
  1aef56:	mulsd  %xmm1,%xmm0
  1aef5a:	addsd  %xmm2,%xmm0
  1aef5e:	unpcklpd %xmm0,%xmm0
  1aef62:	shufpd $0x1,%xmm3,%xmm3
  1aef67:	mulpd  %xmm0,%xmm3
  1aef6b:	movapd %xmm4,%xmm0
  1aef6f:	subpd  %xmm3,%xmm0
  1aef73:	addpd  %xmm4,%xmm3
  1aef77:	movsd  %xmm0,%xmm3
  1aef7b:	movupd %xmm3,(%rsi,%rdx,1)
  1aef80:	add    $0x10,%rsi
  1aef84:	cmp    %r12,%r15
  1aef87:	jne    1aeef0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6070>
  1aef8d:	xor    %eax,%eax
  1aef8f:	mov    0x28(%rsp),%r11
  1aef94:	mov    0x1d0(%rsp),%rdx
  1aef9c:	mov    0x90(%rsp),%rcx
  1aefa4:	mov    0x110(%rsp),%r15
  1aefac:	nopl   0x0(%rax)
  1aefb0:	mov    (%r11,%rax,1),%rdi
  1aefb4:	cmp    %rdx,%rdi
  1aefb7:	jae    1bdacd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c4d>
  1aefbd:	movq   $0x22,(%r10,%rdi,8)
  1aefc5:	add    $0x8,%rax
  1aefc9:	cmp    %rax,%r14
  1aefcc:	jne    1aefb0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6130>
  1aefce:	xor    %eax,%eax
  1aefd0:	xor    %r14d,%r14d
  1aefd3:	jmp    1aefe9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6169>
  1aefd5:	data16 cs nopw 0x0(%rax,%rax,1)
  1aefe0:	add    $0x8,%rax
  1aefe4:	cmp    %rax,%rcx
  1aefe7:	je     1af00f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x618f>
  1aefe9:	mov    (%r15,%rax,1),%rdi
  1aefed:	cmp    %rdx,%rdi
  1aeff0:	jae    1bd52a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x146aa>
  1aeff6:	cmpq   $0x20,(%r10,%rdi,8)
  1aeffb:	jae    1aefe0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6160>
  1aeffd:	cmp    %r9,%r14
  1af000:	jae    1bd9bd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14b3d>
  1af006:	mov    %rdi,(%r11,%r14,8)
  1af00a:	inc    %r14
  1af00d:	jmp    1aefe0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6160>
  1af00f:	cmp    %r9,%r14
  1af012:	ja     1b5b12 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc92>
  1af018:	test   %r14,%r14
  1af01b:	je     1af056 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x61d6>
  1af01d:	mov    (%r11),%rsi
  1af020:	lea    -0x1(%r14),%rax
  1af024:	mov    -0x8(%r11,%r14,8),%rcx
  1af029:	sub    %rsi,%rcx
  1af02c:	setae  %dl
  1af02f:	cmp    %rax,%rcx
  1af032:	sete   %al
  1af035:	and    %dl,%al
  1af037:	cmp    $0x1,%al
  1af039:	jne    1af060 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x61e0>
  1af03b:	mov    %rsi,%rax
  1af03e:	add    %r14,%rax
  1af041:	jb     1af060 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x61e0>
  1af043:	mov    %rax,0x10(%rsp)
  1af048:	mov    %rsi,0x30(%rsp)
  1af04d:	mov    $0x1,%al
  1af04f:	mov    %rax,0x60(%rsp)
  1af054:	jmp    1af07b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x61fb>
  1af056:	xor    %r12d,%r12d
  1af059:	xor    %ebp,%ebp
  1af05b:	jmp    1af660 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x67e0>
  1af060:	movq   $0x0,0x10(%rsp)
  1af069:	movq   $0x0,0x30(%rsp)
  1af072:	movq   $0x0,0x60(%rsp)
  1af07b:	mov    0x1d0(%rsp),%rdx
  1af083:	mov    0x90(%rsp),%rcx
  1af08b:	shl    $0x3,%r14
  1af08f:	mov    (%rsp),%rax
  1af093:	lea    0x0(,%rax,4),%rax
  1af09b:	lea    (%rax,%rax,8),%rax
  1af09f:	mov    %rax,0x18(%rsp)
  1af0a4:	xor    %ebp,%ebp
  1af0a6:	movapd 0x1fe6f52(%rip),%xmm6        # 2196000 <_fini+0x520>
  1af0ae:	xorpd  %xmm7,%xmm7
  1af0b2:	movsd  0x1fe85f5(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1af0bb:	movsd  0x1fe85f4(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1af0c4:	movsd  0x1fe85fb(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1af0cd:	movapd 0x1fe6f3a(%rip),%xmm11        # 2196010 <_fini+0x530>
  1af0d6:	movsd  0x1fe85e1(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1af0df:	movabs $0x7ff0000000000000,%r13
  1af0e9:	nopl   0x0(%rax)
  1af0f0:	mov    (%r11,%rbp,1),%r12
  1af0f4:	cmp    %rbx,%r12
  1af0f7:	jae    1bd6e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14860>
  1af0fd:	mov    %r12,%rdi
  1af100:	shl    $0x4,%rdi
  1af104:	mov    0x138(%rsp),%rax
  1af10c:	movupd (%rax,%rdi,1),%xmm0
  1af111:	movapd %xmm0,%xmm2
  1af115:	andpd  %xmm6,%xmm2
  1af119:	movapd %xmm0,%xmm1
  1af11d:	unpckhpd %xmm0,%xmm1
  1af121:	movapd %xmm1,%xmm3
  1af125:	andpd  %xmm6,%xmm3
  1af129:	ucomisd %xmm7,%xmm0
  1af12d:	je     1af190 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6310>
  1af12f:	ucomisd %xmm7,%xmm1
  1af133:	je     1af190 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6310>
  1af135:	movapd %xmm2,%xmm4
  1af139:	cmplesd %xmm3,%xmm4
  1af13e:	movapd %xmm4,%xmm5
  1af142:	andpd  %xmm3,%xmm5
  1af146:	andnpd %xmm2,%xmm4
  1af14a:	orpd   %xmm5,%xmm4
  1af14e:	ucomisd %xmm8,%xmm4
  1af153:	jbe    1af190 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6310>
  1af155:	ucomisd %xmm4,%xmm9
  1af15a:	jbe    1af190 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6310>
  1af15c:	movapd %xmm0,%xmm2
  1af160:	mulpd  %xmm0,%xmm2
  1af164:	movapd %xmm2,%xmm3
  1af168:	unpckhpd %xmm2,%xmm3
  1af16c:	addsd  %xmm2,%xmm3
  1af170:	movapd %xmm10,%xmm2
  1af175:	divsd  %xmm3,%xmm2
  1af179:	mulsd  %xmm2,%xmm0
  1af17d:	xorpd  %xmm11,%xmm1
  1af182:	mulsd  %xmm2,%xmm1
  1af186:	jmp    1af2a3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6423>
  1af18b:	nopl   0x0(%rax,%rax,1)
  1af190:	ucomisd %xmm7,%xmm1
  1af194:	setnp  %al
  1af197:	sete   %cl
  1af19a:	and    %al,%cl
  1af19c:	movq   %xmm0,%rax
  1af1a1:	movabs $0x7fffffffffffffff,%r8
  1af1ab:	and    %r8,%rax
  1af1ae:	cmp    %r13,%rax
  1af1b1:	setl   %dl
  1af1b4:	test   %dl,%cl
  1af1b6:	je     1af1e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6360>
  1af1b8:	movapd %xmm10,%xmm2
  1af1bd:	divsd  %xmm0,%xmm2
  1af1c1:	xorpd  %xmm11,%xmm1
  1af1c6:	movapd %xmm2,%xmm0
  1af1ca:	mov    0x1d0(%rsp),%rdx
  1af1d2:	mov    0x90(%rsp),%rcx
  1af1da:	jmp    1af2a3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6423>
  1af1df:	nop
  1af1e0:	ucomisd %xmm7,%xmm0
  1af1e4:	setnp  %cl
  1af1e7:	sete   %dl
  1af1ea:	and    %cl,%dl
  1af1ec:	movq   %xmm1,%rcx
  1af1f1:	and    %r8,%rcx
  1af1f4:	cmp    %r13,%rcx
  1af1f7:	setl   %sil
  1af1fb:	test   %sil,%dl
  1af1fe:	je     1af20f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x638f>
  1af200:	movapd %xmm12,%xmm2
  1af205:	divsd  %xmm1,%xmm2
  1af209:	movapd %xmm2,%xmm1
  1af20d:	jmp    1af28b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x640b>
  1af20f:	movabs $0x7fefffffffffffff,%rdx
  1af219:	cmp    %rdx,%rax
  1af21c:	setg   %al
  1af21f:	cmp    %rdx,%rcx
  1af222:	setg   %cl
  1af225:	or     %al,%cl
  1af227:	cmp    $0x1,%cl
  1af22a:	jne    1af2dc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x645c>
  1af230:	add    0x138(%rsp),%rdi
  1af238:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1af23d:	movsd  0x1fe847a(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1af246:	movapd 0x1fe6dc1(%rip),%xmm11        # 2196010 <_fini+0x530>
  1af24f:	movsd  0x1fe8470(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1af258:	movsd  0x1fe8457(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1af261:	movsd  0x1fe8446(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1af26a:	xorpd  %xmm7,%xmm7
  1af26e:	movapd 0x1fe6d8a(%rip),%xmm6        # 2196000 <_fini+0x520>
  1af276:	mov    0x1c8(%rsp),%r10
  1af27e:	mov    0x28(%rsp),%r11
  1af283:	mov    0x1b0(%rsp),%r9
  1af28b:	mov    0x1d0(%rsp),%rdx
  1af293:	mov    0x90(%rsp),%rcx
  1af29b:	mov    0x110(%rsp),%r15
  1af2a3:	add    0x18(%rsp),%r12
  1af2a8:	cmp    %rbx,%r12
  1af2ab:	jae    1bd6cd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1484d>
  1af2b1:	shl    $0x4,%r12
  1af2b5:	mov    0x138(%rsp),%rax
  1af2bd:	movsd  %xmm0,(%rax,%r12,1)
  1af2c3:	movsd  %xmm1,0x8(%rax,%r12,1)
  1af2ca:	add    $0x8,%rbp
  1af2ce:	cmp    %rbp,%r14
  1af2d1:	jne    1af0f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6270>
  1af2d7:	jmp    1af38d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x650d>
  1af2dc:	ucomisd %xmm7,%xmm1
  1af2e0:	mov    0x1d0(%rsp),%rdx
  1af2e8:	mov    0x110(%rsp),%r15
  1af2f0:	jne    1af310 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6490>
  1af2f2:	jp     1af310 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6490>
  1af2f4:	movapd %xmm10,%xmm2
  1af2f9:	divsd  %xmm0,%xmm2
  1af2fd:	xorpd  %xmm11,%xmm1
  1af302:	movapd %xmm2,%xmm0
  1af306:	mov    0x90(%rsp),%rcx
  1af30e:	jmp    1af2a3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6423>
  1af310:	ucomisd %xmm7,%xmm0
  1af314:	mov    0x90(%rsp),%rcx
  1af31c:	jne    1af332 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x64b2>
  1af31e:	jp     1af332 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x64b2>
  1af320:	movapd %xmm12,%xmm2
  1af325:	divsd  %xmm1,%xmm2
  1af329:	movapd %xmm2,%xmm1
  1af32d:	jmp    1af2a3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6423>
  1af332:	movapd %xmm3,%xmm1
  1af336:	cmplesd %xmm2,%xmm1
  1af33b:	movapd %xmm1,%xmm4
  1af33f:	andpd  %xmm2,%xmm4
  1af343:	andnpd %xmm3,%xmm1
  1af347:	orpd   %xmm4,%xmm1
  1af34b:	unpcklpd %xmm1,%xmm1
  1af34f:	divpd  %xmm1,%xmm0
  1af353:	movapd %xmm0,%xmm2
  1af357:	xorpd  %xmm11,%xmm2
  1af35c:	movsd  %xmm0,%xmm2
  1af360:	mulpd  %xmm0,%xmm0
  1af364:	movapd %xmm0,%xmm3
  1af368:	unpcklpd %xmm0,%xmm3
  1af36c:	unpckhpd %xmm0,%xmm0
  1af370:	addpd  %xmm3,%xmm0
  1af374:	divpd  %xmm0,%xmm2
  1af378:	divpd  %xmm1,%xmm2
  1af37c:	movapd %xmm2,%xmm0
  1af380:	movapd %xmm2,%xmm1
  1af384:	unpckhpd %xmm2,%xmm1
  1af388:	jmp    1af2a3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6423>
  1af38d:	cmpb   $0x0,0x60(%rsp)
  1af392:	je     1af545 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x66c5>
  1af398:	mov    0x30(%rsp),%rbp
  1af39d:	mov    0x10(%rsp),%r12
  1af3a2:	cmp    %r12,%rbp
  1af3a5:	jae    1af660 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x67e0>
  1af3ab:	cmpq   $0x5,0x1e0(%rsp)
  1af3b4:	jb     1bf051 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161d1>
  1af3ba:	mov    (%rsp),%rcx
  1af3be:	mov    %rcx,%rax
  1af3c1:	shl    $0x4,%rax
  1af3c5:	lea    (%rcx,%rcx,8),%rdx
  1af3c9:	mov    %rdx,0x20(%rsp)
  1af3ce:	lea    (%rcx,%rdx,4),%rcx
  1af3d2:	lea    (%rax,%rbp,1),%rdi
  1af3d6:	xor    %esi,%esi
  1af3d8:	mov    %rbx,%rdx
  1af3db:	mov    %rdi,0x60(%rsp)
  1af3e0:	sub    %rdi,%rdx
  1af3e3:	cmovb  %rsi,%rdx
  1af3e7:	mov    0x18(%rsp),%rdi
  1af3ec:	lea    (%rdi,%rbp,1),%r15
  1af3f0:	mov    %rbx,%rdi
  1af3f3:	sub    %r15,%rdi
  1af3f6:	cmovb  %rsi,%rdi
  1af3fa:	cmp    %rdi,%rdx
  1af3fd:	cmovb  %rdx,%rdi
  1af401:	lea    (%rcx,%rbp,1),%r11
  1af405:	mov    %rbx,%rdx
  1af408:	sub    %r11,%rdx
  1af40b:	cmovb  %rsi,%rdx
  1af40f:	cmp    %rdx,%rdi
  1af412:	cmovb  %rdi,%rdx
  1af416:	mov    %rbp,%r12
  1af419:	not    %r12
  1af41c:	add    0x10(%rsp),%r12
  1af421:	cmp    %r12,%rdx
  1af424:	cmovae %r12,%rdx
  1af428:	lea    0x1(%rdx),%rsi
  1af42c:	mov    %rbp,%r10
  1af42f:	cmp    $0x20,%rsi
  1af433:	ja     1b032a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x74aa>
  1af439:	mov    (%rsp),%r9
  1af43d:	imul   $0x250,%r9,%rdx
  1af444:	mov    %r10,%rsi
  1af447:	shl    $0x4,%rsi
  1af44b:	add    0x138(%rsp),%rsi
  1af453:	mov    %r9,%rdi
  1af456:	shl    $0x6,%rdi
  1af45a:	lea    (%rdi,%rdi,8),%r8
  1af45e:	shl    $0x8,%r9
  1af462:	mov    0x1d8(%rsp),%r11
  1af46a:	mov    0x10(%rsp),%r12
  1af46f:	nop
  1af470:	lea    (%rax,%r10,1),%rdi
  1af474:	cmp    %rbx,%rdi
  1af477:	jae    1be59c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1571c>
  1af47d:	mov    0x18(%rsp),%rdi
  1af482:	add    %r10,%rdi
  1af485:	cmp    %rbx,%rdi
  1af488:	jae    1be58c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1570c>
  1af48e:	lea    (%rcx,%r10,1),%rdi
  1af492:	cmp    %rbx,%rdi
  1af495:	jae    1be57c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x156fc>
  1af49b:	inc    %r10
  1af49e:	movupd 0x40(%r11),%xmm0
  1af4a4:	movupd (%rsi,%r9,1),%xmm1
  1af4aa:	movapd %xmm0,%xmm2
  1af4ae:	mulpd  %xmm1,%xmm2
  1af4b2:	movupd (%rsi,%r8,1),%xmm3
  1af4b8:	movapd %xmm2,%xmm4
  1af4bc:	unpcklpd %xmm2,%xmm4
  1af4c0:	unpckhpd %xmm2,%xmm2
  1af4c4:	subpd  %xmm2,%xmm4
  1af4c8:	mulpd  %xmm3,%xmm4
  1af4cc:	movapd %xmm1,%xmm2
  1af4d0:	unpckhpd %xmm1,%xmm2
  1af4d4:	mulsd  %xmm0,%xmm2
  1af4d8:	unpckhpd %xmm0,%xmm0
  1af4dc:	mulsd  %xmm1,%xmm0
  1af4e0:	addsd  %xmm2,%xmm0
  1af4e4:	unpcklpd %xmm0,%xmm0
  1af4e8:	shufpd $0x1,%xmm3,%xmm3
  1af4ed:	mulpd  %xmm0,%xmm3
  1af4f1:	movapd %xmm4,%xmm0
  1af4f5:	subpd  %xmm3,%xmm0
  1af4f9:	addpd  %xmm4,%xmm3
  1af4fd:	movsd  %xmm0,%xmm3
  1af501:	movupd %xmm3,(%rsi,%rdx,1)
  1af506:	add    $0x10,%rsi
  1af50a:	cmp    %r10,%r12
  1af50d:	jne    1af470 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65f0>
  1af513:	mov    0x1b0(%rsp),%r9
  1af51b:	mov    0x28(%rsp),%r11
  1af520:	mov    0x1d0(%rsp),%rdx
  1af528:	mov    0x90(%rsp),%rcx
  1af530:	mov    0x110(%rsp),%r15
  1af538:	mov    0x1c8(%rsp),%r10
  1af540:	jmp    1af660 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x67e0>
  1af545:	cmpq   $0x5,0x1e0(%rsp)
  1af54e:	mov    0x1d8(%rsp),%r9
  1af556:	mov    0x30(%rsp),%rbp
  1af55b:	mov    0x10(%rsp),%r12
  1af560:	jb     1bf051 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161d1>
  1af566:	mov    (%rsp),%rcx
  1af56a:	mov    %rcx,%rdx
  1af56d:	shl    $0x4,%rdx
  1af571:	lea    (%rcx,%rcx,8),%rax
  1af575:	lea    (%rcx,%rax,4),%rsi
  1af579:	xor    %r8d,%r8d
  1af57c:	mov    0x138(%rsp),%r15
  1af584:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1af590:	mov    (%r11,%r8,1),%rdi
  1af594:	lea    (%rdi,%rdx,1),%rax
  1af598:	cmp    %rbx,%rax
  1af59b:	jae    1bddea <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14f6a>
  1af5a1:	mov    0x18(%rsp),%rcx
  1af5a6:	add    %rdi,%rcx
  1af5a9:	cmp    %rbx,%rcx
  1af5ac:	jae    1bddd7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14f57>
  1af5b2:	add    %rsi,%rdi
  1af5b5:	cmp    %rbx,%rdi
  1af5b8:	jae    1bddc7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14f47>
  1af5be:	shl    $0x4,%rax
  1af5c2:	shl    $0x4,%rcx
  1af5c6:	movupd 0x40(%r9),%xmm0
  1af5cc:	movupd (%r15,%rax,1),%xmm1
  1af5d2:	movapd %xmm0,%xmm2
  1af5d6:	mulpd  %xmm1,%xmm2
  1af5da:	shl    $0x4,%rdi
  1af5de:	movupd (%r15,%rcx,1),%xmm3
  1af5e4:	movapd %xmm2,%xmm4
  1af5e8:	unpcklpd %xmm2,%xmm4
  1af5ec:	unpckhpd %xmm2,%xmm2
  1af5f0:	subpd  %xmm2,%xmm4
  1af5f4:	mulpd  %xmm3,%xmm4
  1af5f8:	movapd %xmm0,%xmm2
  1af5fc:	unpckhpd %xmm0,%xmm2
  1af600:	mulsd  %xmm1,%xmm2
  1af604:	unpckhpd %xmm1,%xmm1
  1af608:	mulsd  %xmm0,%xmm1
  1af60c:	addsd  %xmm2,%xmm1
  1af610:	unpcklpd %xmm1,%xmm1
  1af614:	shufpd $0x1,%xmm3,%xmm3
  1af619:	mulpd  %xmm1,%xmm3
  1af61d:	movapd %xmm4,%xmm0
  1af621:	subpd  %xmm3,%xmm0
  1af625:	addpd  %xmm4,%xmm3
  1af629:	movsd  %xmm0,%xmm3
  1af62d:	movupd %xmm3,(%r15,%rdi,1)
  1af633:	add    $0x8,%r8
  1af637:	cmp    %r8,%r14
  1af63a:	jne    1af590 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6710>
  1af640:	mov    0x1b0(%rsp),%r9
  1af648:	mov    0x1d0(%rsp),%rdx
  1af650:	mov    0x90(%rsp),%rcx
  1af658:	mov    0x110(%rsp),%r15
  1af660:	xor    %eax,%eax
  1af662:	xor    %r14d,%r14d
  1af665:	jmp    1af680 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6800>
  1af667:	nopw   0x0(%rax,%rax,1)
  1af670:	mov    %rdi,(%r11,%r14,8)
  1af674:	inc    %r14
  1af677:	add    $0x8,%rax
  1af67b:	cmp    %rax,%rcx
  1af67e:	je     1af6ac <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x682c>
  1af680:	mov    (%r15,%rax,1),%rdi
  1af684:	cmp    %rdx,%rdi
  1af687:	jae    1bd53a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x146ba>
  1af68d:	cmpq   $0x23,(%r10,%rdi,8)
  1af692:	jae    1af677 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x67f7>
  1af694:	cmp    %r9,%r14
  1af697:	jb     1af670 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x67f0>
  1af699:	lea    0x24725c8(%rip),%rdx        # 2621c68 <__gmpfr_one+0xa4e8>
  1af6a0:	mov    %r14,%rdi
  1af6a3:	mov    %r9,%rsi
  1af6a6:	call   *0x251f854(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1af6ac:	cmp    %r9,%r14
  1af6af:	ja     1b5b27 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcca7>
  1af6b5:	test   %r14,%r14
  1af6b8:	mov    0x138(%rsp),%r15
  1af6c0:	je     1b17a6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8926>
  1af6c6:	mov    (%r11),%rsi
  1af6c9:	lea    -0x1(%r14),%rax
  1af6cd:	mov    -0x8(%r11,%r14,8),%rcx
  1af6d2:	sub    %rsi,%rcx
  1af6d5:	setae  %dl
  1af6d8:	cmp    %rax,%rcx
  1af6db:	sete   %al
  1af6de:	mov    %rsi,%rcx
  1af6e1:	add    %r14,%rcx
  1af6e4:	cmovb  %r12,%rcx
  1af6e8:	cmovb  %rbp,%rsi
  1af6ec:	test   %al,%dl
  1af6ee:	cmove  %r12,%rcx
  1af6f2:	mov    %rcx,0x10(%rsp)
  1af6f7:	cmove  %rbp,%rsi
  1af6fb:	mov    %rsi,0x18(%rsp)
  1af700:	lea    0x0(,%r14,8),%r12
  1af708:	mov    (%rsp),%r13
  1af70c:	lea    0x0(,%r13,2),%rcx
  1af714:	shl    $0x5,%r13
  1af718:	mov    %r13,0x40(%rsp)
  1af71d:	mov    %rcx,0x38(%rsp)
  1af722:	sub    %rcx,%r13
  1af725:	xor    %ebp,%ebp
  1af727:	xorpd  %xmm1,%xmm1
  1af72b:	jmp    1af757 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x68d7>
  1af72d:	nopl   (%rax)
  1af730:	mov    $0x27,%r8d
  1af736:	mov    %r15,%rdi
  1af739:	mov    %rbx,%rsi
  1af73c:	mov    (%rsp),%rdx
  1af740:	call   1a8d70 <oneloop::native::batch::copy_active_column::<f64>>
  1af745:	add    $0x8,%rbp
  1af749:	cmp    %rbp,%r12
  1af74c:	mov    0x28(%rsp),%r11
  1af751:	xorpd  %xmm1,%xmm1
  1af755:	je     1af798 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6918>
  1af757:	mov    (%r11,%rbp,1),%rcx
  1af75b:	lea    (%rcx,%r13,1),%rdi
  1af75f:	cmp    %rbx,%rdi
  1af762:	jae    1bd6f3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14873>
  1af768:	shl    $0x4,%rdi
  1af76c:	movsd  (%r15,%rdi,1),%xmm0
  1af772:	mov    $0x21,%r9d
  1af778:	ucomisd %xmm1,%xmm0
  1af77c:	jne    1af730 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x68b0>
  1af77e:	jp     1af730 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x68b0>
  1af780:	add    %r15,%rdi
  1af783:	movsd  0x8(%rdi),%xmm0
  1af788:	ucomisd %xmm1,%xmm0
  1af78c:	jne    1af730 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x68b0>
  1af78e:	jp     1af730 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x68b0>
  1af790:	mov    $0x25,%r9d
  1af796:	jmp    1af730 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x68b0>
  1af798:	imul   $0x27,(%rsp),%rcx
  1af79d:	xor    %edx,%edx
  1af79f:	xorpd  %xmm0,%xmm0
  1af7a3:	xor    %esi,%esi
  1af7a5:	mov    0x1d8(%rsp),%r10
  1af7ad:	mov    0x1b0(%rsp),%r9
  1af7b5:	data16 cs nopw 0x0(%rax,%rax,1)
  1af7c0:	mov    (%r11,%rdx,8),%rdi
  1af7c4:	lea    (%rdi,%rcx,1),%rax
  1af7c8:	cmp    %rbx,%rax
  1af7cb:	jae    1bd703 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14883>
  1af7d1:	shl    $0x4,%rax
  1af7d5:	movsd  (%r15,%rax,1),%xmm1
  1af7db:	ucomisd %xmm0,%xmm1
  1af7df:	jne    1af820 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x69a0>
  1af7e1:	jp     1af820 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x69a0>
  1af7e3:	add    %r15,%rax
  1af7e6:	movsd  0x8(%rax),%xmm1
  1af7eb:	ucomisd %xmm0,%xmm1
  1af7ef:	jne    1af820 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x69a0>
  1af7f1:	jp     1af820 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x69a0>
  1af7f3:	cmp    0x1d0(%rsp),%rdi
  1af7fb:	jae    1be1b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15330>
  1af801:	mov    0x1c8(%rsp),%rax
  1af809:	movq   $0x5d,(%rax,%rdi,8)
  1af811:	inc    %rdx
  1af814:	cmp    %rdx,%r14
  1af817:	jne    1af7c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6940>
  1af819:	jmp    1af838 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x69b8>
  1af81b:	nopl   0x0(%rax,%rax,1)
  1af820:	cmp    %r9,%rsi
  1af823:	jae    1bdbe2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14d62>
  1af829:	mov    %rdi,(%r11,%rsi,8)
  1af82d:	inc    %rsi
  1af830:	inc    %rdx
  1af833:	cmp    %rdx,%r14
  1af836:	jne    1af7c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6940>
  1af838:	cmp    %r9,%rsi
  1af83b:	ja     1bd372 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x144f2>
  1af841:	test   %rsi,%rsi
  1af844:	mov    0x1d0(%rsp),%rdx
  1af84c:	mov    0x90(%rsp),%rcx
  1af854:	je     1b17a6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8926>
  1af85a:	mov    (%r11),%rbp
  1af85d:	lea    -0x1(%rsi),%rdx
  1af861:	mov    -0x8(%r11,%rsi,8),%rax
  1af866:	sub    %rbp,%rax
  1af869:	setae  %cl
  1af86c:	cmp    %rdx,%rax
  1af86f:	sete   %al
  1af872:	lea    (%rsi,%rbp,1),%rdi
  1af876:	cmp    %rbp,%rdi
  1af879:	setae  %r14b
  1af87d:	and    %al,%r14b
  1af880:	and    %cl,%r14b
  1af883:	mov    %r14b,0x60(%rsp)
  1af888:	cmp    $0x1,%r14b
  1af88c:	je     1af9be <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6b3e>
  1af892:	cmpq   $0x2,0x1e0(%rsp)
  1af89b:	jb     1bf251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163d1>
  1af8a1:	lea    0x0(,%rsi,8),%rdx
  1af8a9:	mov    (%rsp),%rdi
  1af8ad:	lea    0x0(,%rdi,4),%rax
  1af8b5:	lea    (%rax,%rax,2),%r8
  1af8b9:	lea    (%rdi,%rdi,4),%rcx
  1af8bd:	lea    (%rdi,%rcx,8),%r14
  1af8c1:	xor    %r9d,%r9d
  1af8c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1af8d0:	mov    (%r11,%r9,1),%rdi
  1af8d4:	lea    (%rdi,%r8,1),%rax
  1af8d8:	cmp    %rbx,%rax
  1af8db:	jae    1be349 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x154c9>
  1af8e1:	add    %r14,%rdi
  1af8e4:	cmp    %rbx,%rdi
  1af8e7:	jae    1be339 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x154b9>
  1af8ed:	shl    $0x4,%rax
  1af8f1:	shl    $0x4,%rdi
  1af8f5:	movupd 0x10(%r10),%xmm0
  1af8fb:	movsd  (%r15,%rax,1),%xmm1
  1af901:	movsd  0x8(%r15,%rax,1),%xmm2
  1af908:	unpcklpd %xmm1,%xmm1
  1af90c:	mulpd  %xmm0,%xmm1
  1af910:	shufpd $0x1,%xmm0,%xmm0
  1af915:	unpcklpd %xmm2,%xmm2
  1af919:	mulpd  %xmm0,%xmm2
  1af91d:	movapd %xmm1,%xmm0
  1af921:	subpd  %xmm2,%xmm0
  1af925:	addpd  %xmm1,%xmm2
  1af929:	movsd  %xmm0,%xmm2
  1af92d:	movupd %xmm2,(%r15,%rdi,1)
  1af933:	add    $0x8,%r9
  1af937:	cmp    %r9,%rdx
  1af93a:	jne    1af8d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6a50>
  1af93c:	lea    (%rcx,%rcx,2),%r8
  1af940:	imul   $0x2a,(%rsp),%r12
  1af945:	xor    %r9d,%r9d
  1af948:	mov    0x1c8(%rsp),%r10
  1af950:	mov    (%r11,%r9,1),%rdi
  1af954:	lea    (%rdi,%r8,1),%rax
  1af958:	cmp    %rbx,%rax
  1af95b:	jae    1be37f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x154ff>
  1af961:	lea    (%rdi,%r14,1),%rcx
  1af965:	cmp    %rbx,%rcx
  1af968:	jae    1be36c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x154ec>
  1af96e:	add    %r12,%rdi
  1af971:	cmp    %rbx,%rdi
  1af974:	jae    1be35c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x154dc>
  1af97a:	shl    $0x4,%rax
  1af97e:	shl    $0x4,%rcx
  1af982:	shl    $0x4,%rdi
  1af986:	movupd (%r15,%rax,1),%xmm0
  1af98c:	movupd (%r15,%rcx,1),%xmm1
  1af992:	addpd  %xmm0,%xmm1
  1af996:	movupd %xmm1,(%r15,%rdi,1)
  1af99c:	add    $0x8,%r9
  1af9a0:	cmp    %r9,%rdx
  1af9a3:	jne    1af950 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6ad0>
  1af9a5:	mov    0x18(%rsp),%rax
  1af9aa:	mov    %rax,0x20(%rsp)
  1af9af:	mov    0x10(%rsp),%rax
  1af9b4:	mov    %rax,0x30(%rsp)
  1af9b9:	jmp    1afbbe <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6d3e>
  1af9be:	cmp    %rdi,%rbp
  1af9c1:	mov    %rbp,0x20(%rsp)
  1af9c6:	mov    %rdi,0x30(%rsp)
  1af9cb:	jae    1afbc8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6d48>
  1af9d1:	mov    %rsi,0x50(%rsp)
  1af9d6:	cmpq   $0x2,0x1e0(%rsp)
  1af9df:	jb     1bf251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163d1>
  1af9e5:	mov    (%rsp),%rcx
  1af9e9:	lea    0x0(,%rcx,4),%rax
  1af9f1:	lea    (%rax,%rax,2),%rdi
  1af9f5:	lea    (%rcx,%rcx,4),%rax
  1af9f9:	mov    %rax,0x10(%rsp)
  1af9fe:	lea    (%rcx,%rax,8),%rcx
  1afa02:	lea    (%rdi,%rbp,1),%r12
  1afa06:	xor    %r8d,%r8d
  1afa09:	mov    %rbx,%rax
  1afa0c:	sub    %r12,%rax
  1afa0f:	cmovb  %r8,%rax
  1afa13:	lea    (%rcx,%rbp,1),%r13
  1afa17:	sub    %r13,%rbx
  1afa1a:	cmovb  %r8,%rbx
  1afa1e:	cmp    %rbx,%rax
  1afa21:	mov    %rbx,0x18(%rsp)
  1afa26:	cmovae %rbx,%rax
  1afa2a:	cmp    %rax,%rdx
  1afa2d:	cmovb  %rdx,%rax
  1afa31:	lea    0x1(%rax),%r8
  1afa35:	mov    %rbp,%r11
  1afa38:	cmp    $0x1e,%r8
  1afa3c:	ja     1b1032 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x81b2>
  1afa42:	lea    (%r11,%rcx,1),%rax
  1afa46:	mov    (%rsp),%r9
  1afa4a:	imul   $0x290,%r9,%r8
  1afa51:	mov    %r11,%r10
  1afa54:	shl    $0x4,%r10
  1afa58:	add    %r15,%r10
  1afa5b:	add    %r11,%rdi
  1afa5e:	shl    $0x6,%r9
  1afa62:	lea    (%r9,%r9,2),%r14
  1afa66:	sub    0x50(%rsp),%r11
  1afa6b:	mov    0x8(%rsp),%rbx
  1afa70:	mov    0x1d8(%rsp),%rsi
  1afa78:	nopl   0x0(%rax,%rax,1)
  1afa80:	cmp    %rbx,%rdi
  1afa83:	jae    1bec07 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15d87>
  1afa89:	cmp    %rbx,%rax
  1afa8c:	jae    1bebf4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15d74>
  1afa92:	movupd 0x10(%rsi),%xmm0
  1afa97:	movsd  (%r10,%r14,1),%xmm1
  1afa9d:	movsd  0x8(%r10,%r14,1),%xmm2
  1afaa4:	unpcklpd %xmm1,%xmm1
  1afaa8:	mulpd  %xmm0,%xmm1
  1afaac:	shufpd $0x1,%xmm0,%xmm0
  1afab1:	unpcklpd %xmm2,%xmm2
  1afab5:	mulpd  %xmm0,%xmm2
  1afab9:	movapd %xmm1,%xmm0
  1afabd:	subpd  %xmm2,%xmm0
  1afac1:	addpd  %xmm1,%xmm2
  1afac5:	movsd  %xmm0,%xmm2
  1afac9:	movupd %xmm2,(%r10,%r8,1)
  1afacf:	inc    %rax
  1afad2:	add    $0x10,%r10
  1afad6:	inc    %rdi
  1afad9:	inc    %r11
  1afadc:	cmp    %r11,%rbp
  1afadf:	jne    1afa80 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6c00>
  1afae1:	mov    0x10(%rsp),%rax
  1afae6:	lea    (%rax,%rax,2),%rax
  1afaea:	imul   $0x2a,(%rsp),%r12
  1afaef:	lea    (%rax,%rbp,1),%rsi
  1afaf3:	xor    %r9d,%r9d
  1afaf6:	mov    %rbx,%r10
  1afaf9:	mov    %rsi,0x10(%rsp)
  1afafe:	sub    %rsi,%r10
  1afb01:	cmovb  %r9,%r10
  1afb05:	mov    0x18(%rsp),%rsi
  1afb0a:	cmp    %rsi,%r10
  1afb0d:	cmovae %rsi,%r10
  1afb11:	lea    (%r12,%rbp,1),%rsi
  1afb15:	mov    %rbx,%rdi
  1afb18:	sub    %rsi,%rdi
  1afb1b:	cmovb  %r9,%rdi
  1afb1f:	cmp    %rdi,%r10
  1afb22:	cmovb  %r10,%rdi
  1afb26:	cmp    %rdi,%rdx
  1afb29:	cmovb  %rdx,%rdi
  1afb2d:	lea    0x1(%rdi),%r9
  1afb31:	mov    %rbp,%r14
  1afb34:	cmp    $0x3e,%r9
  1afb38:	ja     1b12b6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8436>
  1afb3e:	mov    (%rsp),%rdi
  1afb42:	imul   $0x2a0,%rdi,%rdx
  1afb49:	mov    %r14,%r13
  1afb4c:	shl    $0x4,%r13
  1afb50:	add    %r15,%r13
  1afb53:	imul   $0xf0,%rdi,%r9
  1afb5a:	mov    0x28(%rsp),%r11
  1afb5f:	mov    0x1c8(%rsp),%r10
  1afb67:	mov    0x50(%rsp),%rsi
  1afb6c:	nopl   0x0(%rax)
  1afb70:	lea    (%rax,%r14,1),%rdi
  1afb74:	cmp    %rbx,%rdi
  1afb77:	jae    1bec37 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15db7>
  1afb7d:	lea    (%rcx,%r14,1),%rdi
  1afb81:	cmp    %rbx,%rdi
  1afb84:	jae    1bec27 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15da7>
  1afb8a:	lea    (%r12,%r14,1),%rdi
  1afb8e:	cmp    %rbx,%rdi
  1afb91:	jae    1bec17 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15d97>
  1afb97:	inc    %r14
  1afb9a:	movupd 0x0(%r13,%r9,1),%xmm0
  1afba1:	movupd 0x0(%r13,%r8,1),%xmm1
  1afba8:	addpd  %xmm0,%xmm1
  1afbac:	movupd %xmm1,0x0(%r13,%rdx,1)
  1afbb3:	add    $0x10,%r13
  1afbb7:	cmp    %r14,0x30(%rsp)
  1afbbc:	jne    1afb70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cf0>
  1afbbe:	mov    0x1b0(%rsp),%r9
  1afbc6:	jmp    1afbd5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6d55>
  1afbc8:	imul   $0x2a,(%rsp),%r12
  1afbcd:	mov    0x1c8(%rsp),%r10
  1afbd5:	mov    %rsi,0x50(%rsp)
  1afbda:	lea    0x0(,%rsi,8),%rsi
  1afbe2:	imul   $0x2b,(%rsp),%rax
  1afbe7:	xor    %r13d,%r13d
  1afbea:	xorpd  %xmm8,%xmm8
  1afbef:	movapd 0x1fe6409(%rip),%xmm6        # 2196000 <_fini+0x520>
  1afbf7:	movsd  0x1fe7ab1(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1afbff:	mov    %rax,0x10(%rsp)
  1afc04:	mov    %rsi,0x18(%rsp)
  1afc09:	nopl   0x0(%rax)
  1afc10:	mov    (%r11,%r13,1),%r14
  1afc14:	lea    (%r14,%r12,1),%rdi
  1afc18:	cmp    %rbx,%rdi
  1afc1b:	jae    1bdaf0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c70>
  1afc21:	shl    $0x4,%rdi
  1afc25:	movupd (%r15,%rdi,1),%xmm0
  1afc2b:	movapd %xmm0,%xmm1
  1afc2f:	unpckhpd %xmm0,%xmm1
  1afc33:	ucomisd %xmm8,%xmm1
  1afc38:	jne    1afc50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6dd0>
  1afc3a:	jp     1afc50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6dd0>
  1afc3c:	andpd  %xmm6,%xmm0
  1afc40:	jmp    1afd10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6e90>
  1afc45:	data16 cs nopw 0x0(%rax,%rax,1)
  1afc50:	ucomisd %xmm8,%xmm0
  1afc55:	jne    1afc66 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6de6>
  1afc57:	jp     1afc66 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6de6>
  1afc59:	andpd  %xmm6,%xmm1
  1afc5d:	movapd %xmm1,%xmm0
  1afc61:	jmp    1afd10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6e90>
  1afc66:	movapd %xmm0,%xmm2
  1afc6a:	andpd  %xmm6,%xmm2
  1afc6e:	pshufd $0xee,%xmm2,%xmm3
  1afc73:	movapd %xmm2,%xmm4
  1afc77:	cmplesd %xmm3,%xmm4
  1afc7c:	movapd %xmm4,%xmm5
  1afc80:	andpd  %xmm3,%xmm5
  1afc84:	andnpd %xmm2,%xmm4
  1afc88:	orpd   %xmm5,%xmm4
  1afc8c:	movapd %xmm0,%xmm2
  1afc90:	cmpunordsd %xmm0,%xmm2
  1afc95:	movapd %xmm2,%xmm5
  1afc99:	andnpd %xmm4,%xmm5
  1afc9d:	andpd  %xmm3,%xmm2
  1afca1:	orpd   %xmm5,%xmm2
  1afca5:	ucomisd %xmm7,%xmm2
  1afca9:	jbe    1afcd2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6e52>
  1afcab:	movsd  0x1fe7a05(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1afcb3:	ucomisd %xmm2,%xmm3
  1afcb7:	jbe    1afcd2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6e52>
  1afcb9:	mulpd  %xmm0,%xmm0
  1afcbd:	movapd %xmm0,%xmm1
  1afcc1:	unpckhpd %xmm0,%xmm1
  1afcc5:	addsd  %xmm0,%xmm1
  1afcc9:	xorps  %xmm0,%xmm0
  1afccc:	sqrtsd %xmm1,%xmm0
  1afcd0:	jmp    1afd10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6e90>
  1afcd2:	call   *0x251bef8(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1afcd8:	xorpd  %xmm8,%xmm8
  1afcdd:	movsd  0x1fe79cb(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1afce5:	movapd 0x1fe6313(%rip),%xmm6        # 2196000 <_fini+0x520>
  1afced:	mov    0x18(%rsp),%rsi
  1afcf2:	mov    0x10(%rsp),%rax
  1afcf7:	mov    0x1c8(%rsp),%r10
  1afcff:	mov    0x28(%rsp),%r11
  1afd04:	mov    0x1b0(%rsp),%r9
  1afd0c:	nopl   0x0(%rax)
  1afd10:	add    %rax,%r14
  1afd13:	cmp    %rbx,%r14
  1afd16:	jae    1bdadd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c5d>
  1afd1c:	shl    $0x4,%r14
  1afd20:	movsd  %xmm0,(%r15,%r14,1)
  1afd26:	movq   $0x0,0x8(%r15,%r14,1)
  1afd2f:	add    $0x8,%r13
  1afd33:	cmp    %r13,%rsi
  1afd36:	jne    1afc10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6d90>
  1afd3c:	cmpb   $0x0,0x60(%rsp)
  1afd41:	je     1afe69 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6fe9>
  1afd47:	mov    0x20(%rsp),%r13
  1afd4c:	mov    0x30(%rsp),%rdx
  1afd51:	cmp    %rdx,%r13
  1afd54:	jae    1afeee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x706e>
  1afd5a:	mov    0x38(%rsp),%rax
  1afd5f:	lea    (%rax,%rax,8),%rax
  1afd63:	mov    (%rsp),%rsi
  1afd67:	lea    (%rsi,%rsi,4),%rcx
  1afd6b:	lea    (%rsi,%rcx,8),%rcx
  1afd6f:	imul   $0x2c,%rsi,%r12
  1afd73:	mov    %r13,%r10
  1afd76:	not    %r10
  1afd79:	add    %rdx,%r10
  1afd7c:	lea    (%rax,%r13,1),%r14
  1afd80:	xor    %esi,%esi
  1afd82:	mov    %rbx,%rdx
  1afd85:	sub    %r14,%rdx
  1afd88:	cmovb  %rsi,%rdx
  1afd8c:	lea    (%rcx,%r13,1),%r8
  1afd90:	mov    %rbx,%rdi
  1afd93:	mov    %r8,0x38(%rsp)
  1afd98:	sub    %r8,%rdi
  1afd9b:	cmovb  %rsi,%rdi
  1afd9f:	cmp    %rdi,%rdx
  1afda2:	cmovb  %rdx,%rdi
  1afda6:	lea    (%r12,%r13,1),%rbp
  1afdaa:	mov    %rbx,%rdx
  1afdad:	sub    %rbp,%rdx
  1afdb0:	cmovb  %rsi,%rdx
  1afdb4:	cmp    %rdx,%rdi
  1afdb7:	cmovb  %rdi,%rdx
  1afdbb:	cmp    %rdx,%r10
  1afdbe:	cmovb  %r10,%rdx
  1afdc2:	lea    0x1(%rdx),%rsi
  1afdc6:	mov    %r13,%r11
  1afdc9:	cmp    $0x4a,%rsi
  1afdcd:	ja     1b0a73 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7bf3>
  1afdd3:	mov    (%rsp),%r8
  1afdd7:	imul   $0x2c0,%r8,%rdx
  1afdde:	mov    %r11,%rsi
  1afde1:	shl    $0x4,%rsi
  1afde5:	add    %r15,%rsi
  1afde8:	imul   $0x290,%r8,%r8
  1afdef:	mov    0x40(%rsp),%rdi
  1afdf4:	lea    (%rdi,%rdi,8),%r9
  1afdf8:	mov    0x8(%rsp),%rbx
  1afdfd:	mov    0x1c8(%rsp),%r10
  1afe05:	data16 cs nopw 0x0(%rax,%rax,1)
  1afe10:	lea    (%rax,%r11,1),%rdi
  1afe14:	cmp    %rbx,%rdi
  1afe17:	jae    1bebc1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15d41>
  1afe1d:	lea    (%rcx,%r11,1),%rdi
  1afe21:	cmp    %rbx,%rdi
  1afe24:	jae    1bebb1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15d31>
  1afe2a:	lea    (%r12,%r11,1),%rdi
  1afe2e:	cmp    %rbx,%rdi
  1afe31:	jae    1beba1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15d21>
  1afe37:	inc    %r11
  1afe3a:	movupd (%rsi,%r9,1),%xmm0
  1afe40:	movupd (%rsi,%r8,1),%xmm1
  1afe46:	addpd  %xmm0,%xmm1
  1afe4a:	movupd %xmm1,(%rsi,%rdx,1)
  1afe4f:	add    $0x10,%rsi
  1afe53:	cmp    %r11,0x30(%rsp)
  1afe58:	jne    1afe10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f90>
  1afe5a:	mov    0x1b0(%rsp),%r9
  1afe62:	mov    0x28(%rsp),%r11
  1afe67:	jmp    1afee7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7067>
  1afe69:	mov    0x38(%rsp),%rax
  1afe6e:	lea    (%rax,%rax,8),%rdx
  1afe72:	mov    (%rsp),%rcx
  1afe76:	lea    (%rcx,%rcx,4),%rax
  1afe7a:	lea    (%rcx,%rax,8),%rsi
  1afe7e:	imul   $0x2c,%rcx,%r12
  1afe82:	xor    %r8d,%r8d
  1afe85:	data16 cs nopw 0x0(%rax,%rax,1)
  1afe90:	mov    (%r11,%r8,1),%rdi
  1afe94:	lea    (%rdi,%rdx,1),%rax
  1afe98:	cmp    %rbx,%rax
  1afe9b:	jae    1be3b5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15535>
  1afea1:	lea    (%rdi,%rsi,1),%rcx
  1afea5:	cmp    %rbx,%rcx
  1afea8:	jae    1be3a2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15522>
  1afeae:	add    %r12,%rdi
  1afeb1:	cmp    %rbx,%rdi
  1afeb4:	jae    1be392 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15512>
  1afeba:	shl    $0x4,%rax
  1afebe:	shl    $0x4,%rcx
  1afec2:	shl    $0x4,%rdi
  1afec6:	movupd (%r15,%rax,1),%xmm0
  1afecc:	movupd (%r15,%rcx,1),%xmm1
  1afed2:	addpd  %xmm0,%xmm1
  1afed6:	movupd %xmm1,(%r15,%rdi,1)
  1afedc:	add    $0x8,%r8
  1afee0:	cmp    %r8,0x18(%rsp)
  1afee5:	jne    1afe90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7010>
  1afee7:	mov    0x18(%rsp),%rsi
  1afeec:	jmp    1afef3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7073>
  1afeee:	imul   $0x2c,(%rsp),%r12
  1afef3:	mov    (%rsp),%rax
  1afef7:	lea    (%rax,%rax,8),%rax
  1afefb:	lea    (%rax,%rax,4),%r14
  1afeff:	xor    %ebp,%ebp
  1aff01:	xorpd  %xmm8,%xmm8
  1aff06:	cs nopw 0x0(%rax,%rax,1)
  1aff10:	mov    (%r11,%rbp,1),%r13
  1aff14:	lea    (%r12,%r13,1),%rdi
  1aff18:	cmp    %rbx,%rdi
  1aff1b:	jae    1bdb13 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c93>
  1aff21:	shl    $0x4,%rdi
  1aff25:	movupd (%r15,%rdi,1),%xmm0
  1aff2b:	movapd %xmm0,%xmm1
  1aff2f:	unpckhpd %xmm0,%xmm1
  1aff33:	ucomisd %xmm8,%xmm1
  1aff38:	jne    1aff50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x70d0>
  1aff3a:	jp     1aff50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x70d0>
  1aff3c:	andpd  %xmm6,%xmm0
  1aff40:	jmp    1b0010 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7190>
  1aff45:	data16 cs nopw 0x0(%rax,%rax,1)
  1aff50:	ucomisd %xmm8,%xmm0
  1aff55:	jne    1aff66 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x70e6>
  1aff57:	jp     1aff66 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x70e6>
  1aff59:	andpd  %xmm6,%xmm1
  1aff5d:	movapd %xmm1,%xmm0
  1aff61:	jmp    1b0010 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7190>
  1aff66:	movapd %xmm0,%xmm2
  1aff6a:	andpd  %xmm6,%xmm2
  1aff6e:	pshufd $0xee,%xmm2,%xmm3
  1aff73:	movapd %xmm2,%xmm4
  1aff77:	cmplesd %xmm3,%xmm4
  1aff7c:	movapd %xmm4,%xmm5
  1aff80:	andpd  %xmm3,%xmm5
  1aff84:	andnpd %xmm2,%xmm4
  1aff88:	orpd   %xmm5,%xmm4
  1aff8c:	movapd %xmm0,%xmm2
  1aff90:	cmpunordsd %xmm0,%xmm2
  1aff95:	movapd %xmm2,%xmm5
  1aff99:	andnpd %xmm4,%xmm5
  1aff9d:	andpd  %xmm3,%xmm2
  1affa1:	orpd   %xmm5,%xmm2
  1affa5:	ucomisd %xmm7,%xmm2
  1affa9:	jbe    1affd2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7152>
  1affab:	movsd  0x1fe7705(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1affb3:	ucomisd %xmm2,%xmm3
  1affb7:	jbe    1affd2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7152>
  1affb9:	mulpd  %xmm0,%xmm0
  1affbd:	movapd %xmm0,%xmm1
  1affc1:	unpckhpd %xmm0,%xmm1
  1affc5:	addsd  %xmm0,%xmm1
  1affc9:	xorps  %xmm0,%xmm0
  1affcc:	sqrtsd %xmm1,%xmm0
  1affd0:	jmp    1b0010 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7190>
  1affd2:	call   *0x251bbf8(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1affd8:	xorpd  %xmm8,%xmm8
  1affdd:	movsd  0x1fe76cb(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1affe5:	movapd 0x1fe6013(%rip),%xmm6        # 2196000 <_fini+0x520>
  1affed:	mov    0x18(%rsp),%rsi
  1afff2:	mov    0x1c8(%rsp),%r10
  1afffa:	mov    0x28(%rsp),%r11
  1affff:	mov    0x1b0(%rsp),%r9
  1b0007:	nopw   0x0(%rax,%rax,1)
  1b0010:	add    %r14,%r13
  1b0013:	cmp    %rbx,%r13
  1b0016:	jae    1bdb00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14c80>
  1b001c:	shl    $0x4,%r13
  1b0020:	movsd  %xmm0,(%r15,%r13,1)
  1b0026:	movq   $0x0,0x8(%r15,%r13,1)
  1b002f:	add    $0x8,%rbp
  1b0033:	cmp    %rbp,%rsi
  1b0036:	jne    1aff10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7090>
  1b003c:	cmpb   $0x0,0x60(%rsp)
  1b0041:	je     1b0171 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x72f1>
  1b0047:	mov    0x20(%rsp),%r12
  1b004c:	cmp    0x30(%rsp),%r12
  1b0051:	mov    0x50(%rsp),%r13
  1b0056:	jae    1b0218 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7398>
  1b005c:	cmpq   $0x2,0x1e0(%rsp)
  1b0065:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b006b:	imul   $0x2e,(%rsp),%rdi
  1b0070:	mov    %r12,%r9
  1b0073:	not    %r9
  1b0076:	add    0x30(%rsp),%r9
  1b007b:	lea    (%r12,%r14,1),%r10
  1b007f:	xor    %ecx,%ecx
  1b0081:	mov    %rbx,%rdx
  1b0084:	sub    %r10,%rdx
  1b0087:	cmovb  %rcx,%rdx
  1b008b:	lea    (%r12,%rdi,1),%r11
  1b008f:	mov    %rbx,%rax
  1b0092:	sub    %r11,%rax
  1b0095:	cmovb  %rcx,%rax
  1b0099:	cmp    %rax,%rdx
  1b009c:	cmovb  %rdx,%rax
  1b00a0:	cmp    %rax,%r9
  1b00a3:	cmovb  %r9,%rax
  1b00a7:	lea    0x1(%rax),%rcx
  1b00ab:	mov    %r12,%r8
  1b00ae:	cmp    $0x22,%rcx
  1b00b2:	mov    %r12,%rbp
  1b00b5:	ja     1b0df3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7f73>
  1b00bb:	add    %r8,%rdi
  1b00be:	mov    (%rsp),%rdx
  1b00c2:	imul   $0x2e0,%rdx,%rax
  1b00c9:	mov    %r8,%rcx
  1b00cc:	shl    $0x4,%rcx
  1b00d0:	add    %r15,%rcx
  1b00d3:	add    %r8,%r14
  1b00d6:	imul   $0x2d0,%rdx,%rdx
  1b00dd:	mov    0x30(%rsp),%rsi
  1b00e2:	sub    %r8,%rsi
  1b00e5:	mov    0x1d8(%rsp),%r8
  1b00ed:	mov    0x1b0(%rsp),%r9
  1b00f5:	mov    0x28(%rsp),%r11
  1b00fa:	mov    0x1c8(%rsp),%r10
  1b0102:	mov    %rbp,%r12
  1b0105:	data16 cs nopw 0x0(%rax,%rax,1)
  1b0110:	cmp    %rbx,%r14
  1b0113:	jae    1bebe1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15d61>
  1b0119:	cmp    %rbx,%rdi
  1b011c:	jae    1bebd1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15d51>
  1b0122:	movupd 0x10(%r8),%xmm0
  1b0128:	movsd  (%rcx,%rdx,1),%xmm1
  1b012d:	movsd  0x8(%rcx,%rdx,1),%xmm2
  1b0133:	unpcklpd %xmm1,%xmm1
  1b0137:	mulpd  %xmm0,%xmm1
  1b013b:	shufpd $0x1,%xmm0,%xmm0
  1b0140:	unpcklpd %xmm2,%xmm2
  1b0144:	mulpd  %xmm0,%xmm2
  1b0148:	movapd %xmm1,%xmm0
  1b014c:	subpd  %xmm2,%xmm0
  1b0150:	addpd  %xmm1,%xmm2
  1b0154:	movsd  %xmm0,%xmm2
  1b0158:	movupd %xmm2,(%rcx,%rax,1)
  1b015d:	inc    %rdi
  1b0160:	add    $0x10,%rcx
  1b0164:	inc    %r14
  1b0167:	dec    %rsi
  1b016a:	jne    1b0110 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7290>
  1b016c:	jmp    1b020d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x738d>
  1b0171:	cmpq   $0x2,0x1e0(%rsp)
  1b017a:	mov    0x1d8(%rsp),%rsi
  1b0182:	mov    0x50(%rsp),%r13
  1b0187:	mov    0x20(%rsp),%r12
  1b018c:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b0192:	imul   $0x2e,(%rsp),%rcx
  1b0197:	xor    %edx,%edx
  1b0199:	nopl   0x0(%rax)
  1b01a0:	mov    (%r11,%rdx,1),%rdi
  1b01a4:	lea    (%rdi,%r14,1),%rax
  1b01a8:	cmp    %rbx,%rax
  1b01ab:	jae    1be3d8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15558>
  1b01b1:	add    %rcx,%rdi
  1b01b4:	cmp    %rbx,%rdi
  1b01b7:	jae    1be3c8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15548>
  1b01bd:	shl    $0x4,%rax
  1b01c1:	shl    $0x4,%rdi
  1b01c5:	movupd 0x10(%rsi),%xmm0
  1b01ca:	movsd  (%r15,%rax,1),%xmm1
  1b01d0:	movsd  0x8(%r15,%rax,1),%xmm2
  1b01d7:	unpcklpd %xmm1,%xmm1
  1b01db:	mulpd  %xmm0,%xmm1
  1b01df:	shufpd $0x1,%xmm0,%xmm0
  1b01e4:	unpcklpd %xmm2,%xmm2
  1b01e8:	mulpd  %xmm0,%xmm2
  1b01ec:	movapd %xmm1,%xmm0
  1b01f0:	subpd  %xmm2,%xmm0
  1b01f4:	addpd  %xmm1,%xmm2
  1b01f8:	movsd  %xmm0,%xmm2
  1b01fc:	movupd %xmm2,(%r15,%rdi,1)
  1b0202:	add    $0x8,%rdx
  1b0206:	cmp    %rdx,0x18(%rsp)
  1b020b:	jne    1b01a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7320>
  1b020d:	cmpb   $0x0,0x60(%rsp)
  1b0212:	je     1b02a4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7424>
  1b0218:	mov    0x30(%rsp),%rcx
  1b021d:	cmp    %rcx,%r12
  1b0220:	jae    1b0320 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x74a0>
  1b0226:	mov    (%rsp),%rdx
  1b022a:	imul   $0x2e,%rdx,%rax
  1b022e:	imul   $0x2f,%rdx,%rdx
  1b0232:	mov    %r12,%r10
  1b0235:	not    %r10
  1b0238:	add    %rcx,%r10
  1b023b:	mov    0x10(%rsp),%rcx
  1b0240:	lea    (%r12,%rcx,1),%r11
  1b0244:	xor    %esi,%esi
  1b0246:	mov    %rbx,%rcx
  1b0249:	sub    %r11,%rcx
  1b024c:	cmovb  %rsi,%rcx
  1b0250:	lea    (%r12,%rax,1),%rbp
  1b0254:	mov    %rbx,%rdi
  1b0257:	sub    %rbp,%rdi
  1b025a:	cmovb  %rsi,%rdi
  1b025e:	cmp    %rdi,%rcx
  1b0261:	cmovb  %rcx,%rdi
  1b0265:	lea    (%r12,%rdx,1),%r14
  1b0269:	mov    %rbx,%rcx
  1b026c:	sub    %r14,%rcx
  1b026f:	cmovb  %rsi,%rcx
  1b0273:	cmp    %rcx,%rdi
  1b0276:	cmovb  %rdi,%rcx
  1b027a:	cmp    %rcx,%r10
  1b027d:	cmovb  %r10,%rcx
  1b0281:	lea    0x1(%rcx),%rsi
  1b0285:	cmp    $0x4a,%rsi
  1b0289:	ja     1b072d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x78ad>
  1b028f:	mov    0x28(%rsp),%r11
  1b0294:	mov    0x1c8(%rsp),%r10
  1b029c:	mov    %r12,%r14
  1b029f:	jmp    1b1650 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x87d0>
  1b02a4:	mov    (%rsp),%rax
  1b02a8:	imul   $0x2e,%rax,%rsi
  1b02ac:	imul   $0x2f,%rax,%rdx
  1b02b0:	xor    %r8d,%r8d
  1b02b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b02c0:	mov    (%r11,%r8,1),%rdi
  1b02c4:	mov    0x10(%rsp),%rax
  1b02c9:	add    %rdi,%rax
  1b02cc:	cmp    %rbx,%rax
  1b02cf:	jae    1be8ef <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15a6f>
  1b02d5:	lea    (%rdi,%rsi,1),%rcx
  1b02d9:	cmp    %rbx,%rcx
  1b02dc:	jae    1be8dc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15a5c>
  1b02e2:	add    %rdx,%rdi
  1b02e5:	cmp    %rbx,%rdi
  1b02e8:	jae    1be8cc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15a4c>
  1b02ee:	shl    $0x4,%rax
  1b02f2:	shl    $0x4,%rcx
  1b02f6:	shl    $0x4,%rdi
  1b02fa:	movupd (%r15,%rax,1),%xmm0
  1b0300:	movupd (%r15,%rcx,1),%xmm1
  1b0306:	addpd  %xmm0,%xmm1
  1b030a:	movupd %xmm1,(%r15,%rdi,1)
  1b0310:	add    $0x8,%r8
  1b0314:	cmp    %r8,0x18(%rsp)
  1b0319:	jne    1b02c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7440>
  1b031b:	jmp    1b16d4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8854>
  1b0320:	imul   $0x2f,(%rsp),%rdx
  1b0325:	jmp    1b16d4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8854>
  1b032a:	xor    %esi,%esi
  1b032c:	mov    %rbx,%rdi
  1b032f:	sub    0x60(%rsp),%rdi
  1b0334:	cmovb  %rsi,%rdi
  1b0338:	mov    %rbx,%r8
  1b033b:	sub    %r15,%r8
  1b033e:	cmovb  %rsi,%r8
  1b0342:	cmp    %r8,%rdi
  1b0345:	cmovb  %rdi,%r8
  1b0349:	mov    %rbx,%r9
  1b034c:	sub    %r11,%r9
  1b034f:	cmovb  %rsi,%r9
  1b0353:	cmp    %r9,%r8
  1b0356:	cmovb  %r8,%r9
  1b035a:	cmp    %r12,%r9
  1b035d:	cmovae %r12,%r9
  1b0361:	mov    (%rsp),%rsi
  1b0365:	shl    $0x8,%rsi
  1b0369:	mov    %rbp,%rdi
  1b036c:	shl    $0x4,%rdi
  1b0370:	mov    0x138(%rsp),%r8
  1b0378:	add    %rsi,%r8
  1b037b:	lea    (%rdi,%r8,1),%rbx
  1b037f:	add    $0x8,%rbx
  1b0383:	add    %rdi,%r8
  1b0386:	mov    %r9,%r14
  1b0389:	shl    $0x4,%r14
  1b038d:	add    %r14,%r8
  1b0390:	add    $0x8,%r8
  1b0394:	mov    %rbp,%r10
  1b0397:	cmp    %rbx,%r8
  1b039a:	mov    0x8(%rsp),%rbx
  1b039f:	jb     1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b03a5:	mov    (%rsp),%r8
  1b03a9:	shl    $0x6,%r8
  1b03ad:	lea    (%r8,%r8,8),%r8
  1b03b1:	mov    0x138(%rsp),%r10
  1b03b9:	mov    %r8,0x100(%rsp)
  1b03c1:	add    %r8,%r10
  1b03c4:	lea    (%rdi,%r10,1),%rbx
  1b03c8:	add    $0x8,%rbx
  1b03cc:	add    %rdi,%r10
  1b03cf:	add    %r10,%r14
  1b03d2:	add    $0x8,%r14
  1b03d6:	mov    %rbp,%r10
  1b03d9:	cmp    %rbx,%r14
  1b03dc:	mov    0x8(%rsp),%rbx
  1b03e1:	jb     1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b03e7:	mov    %rbp,%r10
  1b03ea:	movabs $0xfffffffffffffff,%r14
  1b03f4:	cmp    %r14,%r9
  1b03f7:	ja     1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b03fd:	imul   $0x250,(%rsp),%r9
  1b0405:	xor    %r8d,%r8d
  1b0408:	mov    0x8(%rsp),%rbx
  1b040d:	sub    0x60(%rsp),%rbx
  1b0412:	cmovb  %r8,%rbx
  1b0416:	mov    0x8(%rsp),%r14
  1b041b:	sub    %r15,%r14
  1b041e:	cmovb  %r8,%r14
  1b0422:	lea    (%r9,%rdi,1),%r10
  1b0426:	cmp    %r14,%rbx
  1b0429:	cmovb  %rbx,%r14
  1b042d:	mov    0x8(%rsp),%rbx
  1b0432:	sub    %r11,%rbx
  1b0435:	cmovb  %r8,%rbx
  1b0439:	mov    0x138(%rsp),%r8
  1b0441:	lea    (%r8,%r10,1),%r13
  1b0445:	cmp    %rbx,%r14
  1b0448:	cmovb  %r14,%rbx
  1b044c:	cmp    %r12,%rbx
  1b044f:	cmovae %r12,%rbx
  1b0453:	shl    $0x4,%rbx
  1b0457:	lea    (%rbx,%r13,1),%r11
  1b045b:	add    $0x8,%r11
  1b045f:	lea    0x8(%r8,%r10,1),%r12
  1b0464:	lea    0x10(%rbx,%r13,1),%r10
  1b0469:	mov    %r10,0x50(%rsp)
  1b046e:	lea    (%rsi,%rdi,1),%r14
  1b0472:	lea    (%r8,%r14,1),%r10
  1b0476:	lea    0x8(%rbx,%r10,1),%r15
  1b047b:	mov    %r15,0x40(%rsp)
  1b0480:	lea    0x8(%r8,%r14,1),%r14
  1b0485:	mov    %r14,0x60(%rsp)
  1b048a:	lea    (%rbx,%r10,1),%r14
  1b048e:	add    $0x10,%r14
  1b0492:	mov    %r14,0x38(%rsp)
  1b0497:	mov    0x20(%rsp),%r15
  1b049c:	shl    $0x6,%r15
  1b04a0:	add    %rdi,%r15
  1b04a3:	mov    0x138(%rsp),%r14
  1b04ab:	add    %r15,%r14
  1b04ae:	lea    (%rbx,%r14,1),%r8
  1b04b2:	add    $0x8,%r8
  1b04b6:	add    %r14,%rbx
  1b04b9:	add    $0x10,%rbx
  1b04bd:	cmp    0x50(%rsp),%r13
  1b04c2:	setb   0x20(%rsp)
  1b04c7:	cmp    %r11,%r12
  1b04ca:	setb   0x48(%rsp)
  1b04cf:	cmp    0x40(%rsp),%r13
  1b04d4:	setb   0xb0(%rsp)
  1b04dc:	cmp    %r11,%r10
  1b04df:	setb   0xd0(%rsp)
  1b04e7:	cmp    0x38(%rsp),%r13
  1b04ec:	setb   0xe0(%rsp)
  1b04f4:	cmp    %r11,0x60(%rsp)
  1b04f9:	setb   0x58(%rsp)
  1b04fe:	cmp    %r8,%r13
  1b0501:	setb   0x88(%rsp)
  1b0509:	cmp    %r11,%r14
  1b050c:	setb   0x78(%rsp)
  1b0511:	cmp    %rbx,%r13
  1b0514:	mov    %rbx,%r13
  1b0517:	mov    0x138(%rsp),%rbx
  1b051f:	lea    0x8(%rbx,%r15,1),%rbx
  1b0524:	setb   0x80(%rsp)
  1b052c:	cmp    %r11,%rbx
  1b052f:	setb   0x98(%rsp)
  1b0537:	cmp    0x40(%rsp),%r12
  1b053c:	setb   0x40(%rsp)
  1b0541:	mov    0x50(%rsp),%r11
  1b0546:	cmp    %r11,%r10
  1b0549:	setb   0xc8(%rsp)
  1b0551:	cmp    0x38(%rsp),%r12
  1b0556:	setb   0x38(%rsp)
  1b055b:	cmp    %r11,0x60(%rsp)
  1b0560:	setb   0x60(%rsp)
  1b0565:	cmp    %r8,%r12
  1b0568:	setb   0xa8(%rsp)
  1b0570:	cmp    %r11,%r14
  1b0573:	mov    %r11,%r10
  1b0576:	setb   %r14b
  1b057a:	cmp    %r13,%r12
  1b057d:	setb   %r11b
  1b0581:	cmp    %r10,%rbx
  1b0584:	mov    0x8(%rsp),%rbx
  1b0589:	mov    %rbp,%r10
  1b058c:	setb   0x50(%rsp)
  1b0591:	movzbl 0x48(%rsp),%r12d
  1b0597:	test   %r12b,0x20(%rsp)
  1b059c:	jne    1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b05a2:	mov    %rbp,%r10
  1b05a5:	movzbl 0xd0(%rsp),%r12d
  1b05ae:	and    %r12b,0xb0(%rsp)
  1b05b6:	jne    1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b05bc:	mov    %rbp,%r10
  1b05bf:	movzbl 0x58(%rsp),%r12d
  1b05c5:	and    %r12b,0xe0(%rsp)
  1b05cd:	jne    1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b05d3:	mov    %rbp,%r10
  1b05d6:	movzbl 0x78(%rsp),%r12d
  1b05dc:	and    %r12b,0x88(%rsp)
  1b05e4:	jne    1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b05ea:	mov    %rbp,%r10
  1b05ed:	movzbl 0x98(%rsp),%r12d
  1b05f6:	and    %r12b,0x80(%rsp)
  1b05fe:	jne    1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b0604:	mov    %rbp,%r10
  1b0607:	movzbl 0xc8(%rsp),%r12d
  1b0610:	and    %r12b,0x40(%rsp)
  1b0615:	jne    1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b061b:	mov    %rbp,%r10
  1b061e:	movzbl 0x60(%rsp),%r12d
  1b0624:	and    %r12b,0x38(%rsp)
  1b0629:	jne    1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b062f:	mov    %rbp,%r10
  1b0632:	and    %r14b,0xa8(%rsp)
  1b063a:	jne    1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b0640:	mov    %rbp,%r10
  1b0643:	and    0x50(%rsp),%r11b
  1b0648:	jne    1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b064e:	and    $0xfffffffffffffffe,%rdx
  1b0652:	lea    (%rdx,%rbp,1),%r10
  1b0656:	mov    0x1d8(%rsp),%r11
  1b065e:	movsd  0x40(%r11),%xmm0
  1b0664:	movsd  0x48(%r11),%xmm1
  1b066a:	unpcklpd %xmm1,%xmm1
  1b066e:	unpcklpd %xmm0,%xmm0
  1b0672:	add    0x138(%rsp),%rdi
  1b067a:	mov    0x100(%rsp),%r8
  1b0682:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b0690:	movupd (%rdi,%rsi,1),%xmm3
  1b0695:	movupd 0x10(%rdi,%rsi,1),%xmm4
  1b069b:	movapd %xmm3,%xmm2
  1b069f:	unpcklpd %xmm4,%xmm2
  1b06a3:	unpckhpd %xmm4,%xmm3
  1b06a7:	movapd %xmm1,%xmm4
  1b06ab:	mulpd  %xmm2,%xmm4
  1b06af:	movapd %xmm0,%xmm5
  1b06b3:	mulpd  %xmm3,%xmm5
  1b06b7:	addpd  %xmm4,%xmm5
  1b06bb:	movupd (%rdi,%r8,1),%xmm4
  1b06c1:	movupd 0x10(%rdi,%r8,1),%xmm6
  1b06c8:	movapd %xmm4,%xmm7
  1b06cc:	unpcklpd %xmm6,%xmm7
  1b06d0:	unpckhpd %xmm6,%xmm4
  1b06d4:	movapd %xmm7,%xmm6
  1b06d8:	mulpd  %xmm5,%xmm6
  1b06dc:	mulpd  %xmm0,%xmm2
  1b06e0:	mulpd  %xmm1,%xmm3
  1b06e4:	subpd  %xmm3,%xmm2
  1b06e8:	mulpd  %xmm2,%xmm7
  1b06ec:	mulpd  %xmm4,%xmm2
  1b06f0:	addpd  %xmm6,%xmm2
  1b06f4:	mulpd  %xmm5,%xmm4
  1b06f8:	subpd  %xmm4,%xmm7
  1b06fc:	movapd %xmm7,%xmm3
  1b0700:	unpcklpd %xmm2,%xmm3
  1b0704:	unpckhpd %xmm2,%xmm7
  1b0708:	movupd %xmm7,0x10(%rdi,%r9,1)
  1b070f:	movupd %xmm3,(%rdi,%r9,1)
  1b0715:	add    $0x20,%rdi
  1b0719:	add    $0xfffffffffffffffe,%rdx
  1b071d:	jne    1b0690 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7810>
  1b0723:	mov    0x30(%rsp),%rbp
  1b0728:	jmp    1af439 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x65b9>
  1b072d:	xor    %esi,%esi
  1b072f:	mov    %rbx,%rdi
  1b0732:	sub    %r11,%rdi
  1b0735:	cmovb  %rsi,%rdi
  1b0739:	mov    %rbx,%r8
  1b073c:	sub    %rbp,%r8
  1b073f:	cmovb  %rsi,%r8
  1b0743:	cmp    %r8,%rdi
  1b0746:	cmovb  %rdi,%r8
  1b074a:	mov    %rbx,%r9
  1b074d:	sub    %r14,%r9
  1b0750:	cmovb  %rsi,%r9
  1b0754:	cmp    %r9,%r8
  1b0757:	cmovb  %r8,%r9
  1b075b:	cmp    %r9,%r10
  1b075e:	cmovb  %r10,%r9
  1b0762:	imul   $0x2b0,(%rsp),%rsi
  1b076a:	mov    %r12,%rdi
  1b076d:	shl    $0x4,%rdi
  1b0771:	lea    (%r15,%rsi,1),%r8
  1b0775:	lea    (%rdi,%r8,1),%rbx
  1b0779:	add    $0x8,%rbx
  1b077d:	add    %rdi,%r8
  1b0780:	mov    %r9,%r13
  1b0783:	shl    $0x4,%r13
  1b0787:	add    %r13,%r8
  1b078a:	add    $0x8,%r8
  1b078e:	cmp    %rbx,%r8
  1b0791:	jb     1b1634 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x87b4>
  1b0797:	mov    %rbp,0x18(%rsp)
  1b079c:	imul   $0x2e0,(%rsp),%r8
  1b07a4:	lea    (%r15,%r8,1),%rbx
  1b07a8:	lea    (%rdi,%rbx,1),%rbp
  1b07ac:	add    $0x8,%rbp
  1b07b0:	add    %rdi,%rbx
  1b07b3:	add    %r13,%rbx
  1b07b6:	add    $0x8,%rbx
  1b07ba:	cmp    %rbp,%rbx
  1b07bd:	mov    0x30(%rsp),%r12
  1b07c2:	jb     1b5aa1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc21>
  1b07c8:	movabs $0xfffffffffffffff,%rbx
  1b07d2:	cmp    %rbx,%r9
  1b07d5:	mov    0x8(%rsp),%rbx
  1b07da:	ja     1b5aa6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc26>
  1b07e0:	imul   $0x2f0,(%rsp),%r9
  1b07e8:	xor    %ebp,%ebp
  1b07ea:	mov    %rbx,%r13
  1b07ed:	sub    %r11,%r13
  1b07f0:	cmovb  %rbp,%r13
  1b07f4:	mov    %rbx,%r11
  1b07f7:	sub    0x18(%rsp),%r11
  1b07fc:	cmovb  %rbp,%r11
  1b0800:	cmp    %r11,%r13
  1b0803:	cmovb  %r13,%r11
  1b0807:	sub    %r14,%rbx
  1b080a:	cmovb  %rbp,%rbx
  1b080e:	cmp    %rbx,%r11
  1b0811:	cmovb  %r11,%rbx
  1b0815:	lea    (%r9,%rdi,1),%r14
  1b0819:	cmp    %rbx,%r10
  1b081c:	cmovb  %r10,%rbx
  1b0820:	lea    (%r15,%r14,1),%rbp
  1b0824:	shl    $0x4,%rbx
  1b0828:	lea    (%rbx,%rbp,1),%r11
  1b082c:	add    $0x8,%r11
  1b0830:	lea    0x8(%r15,%r14,1),%r13
  1b0835:	lea    0x10(%rbx,%rbp,1),%r10
  1b083a:	mov    %r10,0x58(%rsp)
  1b083f:	lea    (%rsi,%rdi,1),%r12
  1b0843:	lea    (%r15,%r12,1),%r14
  1b0847:	lea    0x8(%r15,%r12,1),%r12
  1b084c:	mov    %r12,0x18(%rsp)
  1b0851:	lea    0x10(%rbx,%r14,1),%r12
  1b0856:	mov    %r12,0x38(%rsp)
  1b085b:	mov    %r14,0xd0(%rsp)
  1b0863:	lea    (%r8,%rdi,1),%r10
  1b0867:	lea    (%r15,%r10,1),%r12
  1b086b:	lea    0x8(%r15,%r10,1),%r10
  1b0870:	mov    %r10,0x40(%rsp)
  1b0875:	lea    0x10(%rbx,%r12,1),%r10
  1b087a:	mov    %r10,0xb0(%rsp)
  1b0882:	lea    0x8(%rbx,%r14,1),%r14
  1b0887:	mov    %r14,0xe0(%rsp)
  1b088f:	add    %r12,%rbx
  1b0892:	add    $0x8,%rbx
  1b0896:	mov    %rbx,0x60(%rsp)
  1b089b:	mov    0x58(%rsp),%r14
  1b08a0:	cmp    %r14,%rbp
  1b08a3:	setb   0x48(%rsp)
  1b08a8:	cmp    %r11,%r13
  1b08ab:	setb   0x100(%rsp)
  1b08b3:	cmp    0x38(%rsp),%rbp
  1b08b8:	setb   0x88(%rsp)
  1b08c0:	cmp    %r11,0x18(%rsp)
  1b08c5:	setb   0x78(%rsp)
  1b08ca:	cmp    %r10,%rbp
  1b08cd:	setb   0x80(%rsp)
  1b08d5:	cmp    %r11,0x40(%rsp)
  1b08da:	setb   0x98(%rsp)
  1b08e2:	mov    0xe0(%rsp),%r10
  1b08ea:	cmp    %r10,%rbp
  1b08ed:	setb   0xc8(%rsp)
  1b08f5:	mov    0xd0(%rsp),%rbx
  1b08fd:	cmp    %r11,%rbx
  1b0900:	setb   0xa8(%rsp)
  1b0908:	cmp    0x60(%rsp),%rbp
  1b090d:	setb   0xf8(%rsp)
  1b0915:	cmp    %r11,%r12
  1b0918:	setb   0x118(%rsp)
  1b0920:	cmp    0x38(%rsp),%r13
  1b0925:	setb   0x38(%rsp)
  1b092a:	cmp    %r14,0x18(%rsp)
  1b092f:	setb   0x18(%rsp)
  1b0934:	cmp    0xb0(%rsp),%r13
  1b093c:	setb   0xb0(%rsp)
  1b0944:	cmp    %r14,0x40(%rsp)
  1b0949:	setb   0x40(%rsp)
  1b094e:	cmp    %r10,%r13
  1b0951:	setb   0xe0(%rsp)
  1b0959:	cmp    %r14,%rbx
  1b095c:	setb   %r11b
  1b0960:	cmp    0x60(%rsp),%r13
  1b0965:	setb   %r10b
  1b0969:	cmp    %r14,%r12
  1b096c:	setb   %bpl
  1b0970:	movzbl 0x100(%rsp),%ebx
  1b0978:	test   %bl,0x48(%rsp)
  1b097c:	jne    1b1634 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x87b4>
  1b0982:	movzbl 0x78(%rsp),%ebx
  1b0987:	and    %bl,0x88(%rsp)
  1b098e:	jne    1b1634 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x87b4>
  1b0994:	mov    %r10b,0x60(%rsp)
  1b0999:	movzbl 0x98(%rsp),%ebx
  1b09a1:	and    %bl,0x80(%rsp)
  1b09a8:	mov    0x8(%rsp),%rbx
  1b09ad:	mov    0x50(%rsp),%r13
  1b09b2:	mov    0x20(%rsp),%r14
  1b09b7:	mov    0x30(%rsp),%r12
  1b09bc:	jne    1b5a2d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbad>
  1b09c2:	movzbl 0xa8(%rsp),%r10d
  1b09cb:	and    %r10b,0xc8(%rsp)
  1b09d3:	jne    1b5a2d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbad>
  1b09d9:	movzbl 0x118(%rsp),%r10d
  1b09e2:	and    %r10b,0xf8(%rsp)
  1b09ea:	jne    1b5a2d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbad>
  1b09f0:	movzbl 0x18(%rsp),%r10d
  1b09f6:	and    %r10b,0x38(%rsp)
  1b09fb:	jne    1b5a2d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbad>
  1b0a01:	movzbl 0x40(%rsp),%r10d
  1b0a07:	and    %r10b,0xb0(%rsp)
  1b0a0f:	jne    1b5a2d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbad>
  1b0a15:	and    %r11b,0xe0(%rsp)
  1b0a1d:	jne    1b5a2d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbad>
  1b0a23:	and    %bpl,0x60(%rsp)
  1b0a28:	jne    1b5a2d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbad>
  1b0a2e:	and    $0xfffffffffffffffe,%rcx
  1b0a32:	add    %rcx,%r14
  1b0a35:	add    %r15,%rdi
  1b0a38:	mov    0x28(%rsp),%r11
  1b0a3d:	mov    0x1c8(%rsp),%r10
  1b0a45:	data16 cs nopw 0x0(%rax,%rax,1)
  1b0a50:	movupd (%rdi,%rsi,1),%xmm0
  1b0a55:	movupd (%rdi,%r8,1),%xmm1
  1b0a5b:	addpd  %xmm0,%xmm1
  1b0a5f:	movupd %xmm1,(%rdi,%r9,1)
  1b0a65:	add    $0x10,%rdi
  1b0a69:	dec    %rcx
  1b0a6c:	jne    1b0a50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7bd0>
  1b0a6e:	jmp    1b1655 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x87d5>
  1b0a73:	xor    %esi,%esi
  1b0a75:	mov    0x8(%rsp),%r9
  1b0a7a:	mov    %r9,%rdi
  1b0a7d:	sub    %r14,%rdi
  1b0a80:	cmovb  %rsi,%rdi
  1b0a84:	mov    %r9,%r8
  1b0a87:	sub    0x38(%rsp),%r8
  1b0a8c:	cmovb  %rsi,%r8
  1b0a90:	cmp    %r8,%rdi
  1b0a93:	cmovb  %rdi,%r8
  1b0a97:	sub    %rbp,%r9
  1b0a9a:	cmovb  %rsi,%r9
  1b0a9e:	cmp    %r9,%r8
  1b0aa1:	cmovb  %r8,%r9
  1b0aa5:	cmp    %r9,%r10
  1b0aa8:	cmovb  %r10,%r9
  1b0aac:	mov    0x40(%rsp),%rsi
  1b0ab1:	lea    (%rsi,%rsi,8),%rsi
  1b0ab5:	mov    %r13,%rdi
  1b0ab8:	shl    $0x4,%rdi
  1b0abc:	mov    %rsi,0xd0(%rsp)
  1b0ac4:	lea    (%r15,%rsi,1),%r8
  1b0ac8:	lea    (%rdi,%r8,1),%rbx
  1b0acc:	add    $0x8,%rbx
  1b0ad0:	add    %rdi,%r8
  1b0ad3:	mov    %r9,%rsi
  1b0ad6:	shl    $0x4,%rsi
  1b0ada:	add    %rsi,%r8
  1b0add:	add    $0x8,%r8
  1b0ae1:	mov    %r13,%r11
  1b0ae4:	cmp    %rbx,%r8
  1b0ae7:	jb     1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0aed:	imul   $0x290,(%rsp),%r8
  1b0af5:	lea    (%r15,%r8,1),%r11
  1b0af9:	lea    (%rdi,%r11,1),%rbx
  1b0afd:	add    $0x8,%rbx
  1b0b01:	add    %rdi,%r11
  1b0b04:	add    %r11,%rsi
  1b0b07:	add    $0x8,%rsi
  1b0b0b:	mov    %r13,%r11
  1b0b0e:	cmp    %rbx,%rsi
  1b0b11:	jb     1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0b17:	mov    %r13,%r11
  1b0b1a:	movabs $0xfffffffffffffff,%rsi
  1b0b24:	cmp    %rsi,%r9
  1b0b27:	ja     1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0b2d:	mov    (%rsp),%rbx
  1b0b31:	imul   $0x2c0,%rbx,%rsi
  1b0b38:	mov    %rsi,0x148(%rsp)
  1b0b40:	lea    (%rsi,%rdi,1),%r9
  1b0b44:	xor    %r11d,%r11d
  1b0b47:	mov    %r13,0x20(%rsp)
  1b0b4c:	mov    0x8(%rsp),%r13
  1b0b51:	mov    %r13,%rsi
  1b0b54:	sub    %r14,%rsi
  1b0b57:	cmovb  %r11,%rsi
  1b0b5b:	mov    %r13,%r14
  1b0b5e:	sub    0x38(%rsp),%r14
  1b0b63:	cmovb  %r11,%r14
  1b0b67:	lea    (%r15,%r9,1),%r11
  1b0b6b:	cmp    %r14,%rsi
  1b0b6e:	cmovb  %rsi,%r14
  1b0b72:	sub    %rbp,%r13
  1b0b75:	mov    $0x0,%esi
  1b0b7a:	cmovb  %rsi,%r13
  1b0b7e:	cmp    %r13,%r14
  1b0b81:	cmovb  %r14,%r13
  1b0b85:	cmp    %r13,%r10
  1b0b88:	cmovb  %r10,%r13
  1b0b8c:	shl    $0x4,%r13
  1b0b90:	lea    (%r11,%r13,1),%rsi
  1b0b94:	add    $0x8,%rsi
  1b0b98:	lea    0x8(%r15,%r9,1),%rbp
  1b0b9d:	lea    (%r11,%r13,1),%r9
  1b0ba1:	add    $0x10,%r9
  1b0ba5:	mov    %r9,0xb0(%rsp)
  1b0bad:	lea    (%rbx,%rbx,8),%r14
  1b0bb1:	shl    $0x5,%r14
  1b0bb5:	add    %rdi,%r14
  1b0bb8:	lea    (%r15,%r14,1),%r9
  1b0bbc:	lea    (%r15,%r14,1),%rbx
  1b0bc0:	add    $0x8,%rbx
  1b0bc4:	mov    %rbx,0x38(%rsp)
  1b0bc9:	lea    0x10(%r13,%r9,1),%r10
  1b0bce:	mov    %r10,0x88(%rsp)
  1b0bd6:	mov    %r9,%rbx
  1b0bd9:	lea    (%r8,%rdi,1),%r9
  1b0bdd:	lea    (%r15,%r9,1),%r14
  1b0be1:	lea    0x8(%r15,%r9,1),%r9
  1b0be6:	mov    %r9,0x100(%rsp)
  1b0bee:	lea    0x10(%r13,%r14,1),%r9
  1b0bf3:	mov    %r9,0x78(%rsp)
  1b0bf8:	lea    0x8(%r13,%rbx,1),%r9
  1b0bfd:	mov    %r9,0x48(%rsp)
  1b0c02:	lea    (%r14,%r13,1),%r9
  1b0c06:	add    $0x8,%r9
  1b0c0a:	mov    0x20(%rsp),%r13
  1b0c0f:	cmp    0xb0(%rsp),%r11
  1b0c17:	setb   0xe0(%rsp)
  1b0c1f:	cmp    %rsi,%rbp
  1b0c22:	setb   0x58(%rsp)
  1b0c27:	cmp    %r10,%r11
  1b0c2a:	setb   0x80(%rsp)
  1b0c32:	cmp    %rsi,0x38(%rsp)
  1b0c37:	setb   0x98(%rsp)
  1b0c3f:	mov    0x78(%rsp),%r10
  1b0c44:	cmp    %r10,%r11
  1b0c47:	setb   0xc8(%rsp)
  1b0c4f:	cmp    %rsi,0x100(%rsp)
  1b0c57:	setb   0xa8(%rsp)
  1b0c5f:	cmp    0x48(%rsp),%r11
  1b0c64:	setb   0xf8(%rsp)
  1b0c6c:	cmp    %rsi,%rbx
  1b0c6f:	setb   0x118(%rsp)
  1b0c77:	cmp    %r9,%r11
  1b0c7a:	setb   0x120(%rsp)
  1b0c82:	cmp    %rsi,%r14
  1b0c85:	setb   0x130(%rsp)
  1b0c8d:	cmp    0x88(%rsp),%rbp
  1b0c95:	setb   0x88(%rsp)
  1b0c9d:	mov    0xb0(%rsp),%rsi
  1b0ca5:	cmp    %rsi,0x38(%rsp)
  1b0caa:	setb   0x38(%rsp)
  1b0caf:	cmp    %r10,%rbp
  1b0cb2:	setb   0x78(%rsp)
  1b0cb7:	cmp    %rsi,0x100(%rsp)
  1b0cbf:	setb   0x100(%rsp)
  1b0cc7:	cmp    0x48(%rsp),%rbp
  1b0ccc:	setb   0x140(%rsp)
  1b0cd4:	cmp    %rsi,%rbx
  1b0cd7:	mov    %rsi,%r10
  1b0cda:	setb   0x48(%rsp)
  1b0cdf:	cmp    %r9,%rbp
  1b0ce2:	setb   %sil
  1b0ce6:	cmp    %r10,%r14
  1b0ce9:	mov    %r13,%r11
  1b0cec:	setb   %r10b
  1b0cf0:	movzbl 0x58(%rsp),%ebx
  1b0cf5:	test   %bl,0xe0(%rsp)
  1b0cfc:	jne    1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0d02:	mov    %r13,%r11
  1b0d05:	movzbl 0x98(%rsp),%ebp
  1b0d0d:	and    %bpl,0x80(%rsp)
  1b0d15:	jne    1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0d1b:	mov    %r13,%r11
  1b0d1e:	movzbl 0xa8(%rsp),%ebp
  1b0d26:	and    %bpl,0xc8(%rsp)
  1b0d2e:	jne    1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0d34:	mov    %r13,%r11
  1b0d37:	movzbl 0x118(%rsp),%ebp
  1b0d3f:	and    %bpl,0xf8(%rsp)
  1b0d47:	jne    1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0d4d:	mov    %r13,%r11
  1b0d50:	movzbl 0x130(%rsp),%ebp
  1b0d58:	and    %bpl,0x120(%rsp)
  1b0d60:	jne    1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0d66:	mov    %r13,%r11
  1b0d69:	movzbl 0x38(%rsp),%ebp
  1b0d6e:	and    %bpl,0x88(%rsp)
  1b0d76:	jne    1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0d7c:	mov    %r13,%r11
  1b0d7f:	movzbl 0x100(%rsp),%ebp
  1b0d87:	and    %bpl,0x78(%rsp)
  1b0d8c:	jne    1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0d92:	mov    %r13,%r11
  1b0d95:	movzbl 0x140(%rsp),%r9d
  1b0d9e:	and    0x48(%rsp),%r9b
  1b0da3:	jne    1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0da9:	mov    %r13,%r11
  1b0dac:	and    %r10b,%sil
  1b0daf:	jne    1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0db5:	and    $0xfffffffffffffffe,%rdx
  1b0db9:	lea    (%rdx,%r13,1),%r11
  1b0dbd:	add    %r15,%rdi
  1b0dc0:	mov    0xd0(%rsp),%rsi
  1b0dc8:	mov    0x148(%rsp),%r9
  1b0dd0:	movupd (%rdi,%rsi,1),%xmm0
  1b0dd5:	movupd (%rdi,%r8,1),%xmm1
  1b0ddb:	addpd  %xmm0,%xmm1
  1b0ddf:	movupd %xmm1,(%rdi,%r9,1)
  1b0de5:	add    $0x10,%rdi
  1b0de9:	dec    %rdx
  1b0dec:	jne    1b0dd0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x7f50>
  1b0dee:	jmp    1afdd3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6f53>
  1b0df3:	xor    %ecx,%ecx
  1b0df5:	mov    %rbx,%rdx
  1b0df8:	sub    %r10,%rdx
  1b0dfb:	cmovb  %rcx,%rdx
  1b0dff:	mov    %rbx,%rsi
  1b0e02:	sub    %r11,%rsi
  1b0e05:	cmovb  %rcx,%rsi
  1b0e09:	cmp    %rsi,%rdx
  1b0e0c:	cmovb  %rdx,%rsi
  1b0e10:	cmp    %rsi,%r9
  1b0e13:	cmovb  %r9,%rsi
  1b0e17:	imul   $0x2d0,(%rsp),%rcx
  1b0e1f:	mov    %rbp,%rdx
  1b0e22:	shl    $0x4,%rdx
  1b0e26:	lea    (%r15,%rcx,1),%r8
  1b0e2a:	lea    (%rdx,%r8,1),%rbx
  1b0e2e:	add    $0x8,%rbx
  1b0e32:	add    %rdx,%r8
  1b0e35:	mov    %rsi,%r12
  1b0e38:	shl    $0x4,%r12
  1b0e3c:	add    %r8,%r12
  1b0e3f:	add    $0x8,%r12
  1b0e43:	mov    %rbp,%r8
  1b0e46:	cmp    %rbx,%r12
  1b0e49:	mov    0x8(%rsp),%rbx
  1b0e4e:	jb     1b00bb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x723b>
  1b0e54:	mov    %rbp,%r8
  1b0e57:	movabs $0xfffffffffffffff,%r12
  1b0e61:	cmp    %r12,%rsi
  1b0e64:	ja     1b00bb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x723b>
  1b0e6a:	imul   $0x2e0,(%rsp),%rsi
  1b0e72:	xor    %r8d,%r8d
  1b0e75:	mov    0x8(%rsp),%rbx
  1b0e7a:	sub    %r10,%rbx
  1b0e7d:	cmovb  %r8,%rbx
  1b0e81:	mov    0x8(%rsp),%r10
  1b0e86:	sub    %r11,%r10
  1b0e89:	cmovb  %r8,%r10
  1b0e8d:	cmp    %r10,%rbx
  1b0e90:	cmovb  %rbx,%r10
  1b0e94:	lea    (%rsi,%rdx,1),%r8
  1b0e98:	cmp    %r10,%r9
  1b0e9b:	cmovb  %r9,%r10
  1b0e9f:	lea    (%r15,%r8,1),%r9
  1b0ea3:	shl    $0x4,%r10
  1b0ea7:	lea    (%r10,%r9,1),%r11
  1b0eab:	add    $0x8,%r11
  1b0eaf:	lea    0x8(%r15,%r8,1),%r8
  1b0eb4:	lea    0x10(%r10,%r9,1),%rbx
  1b0eb9:	lea    (%rcx,%rdx,1),%r12
  1b0ebd:	mov    %rbp,0x20(%rsp)
  1b0ec2:	lea    (%r15,%r12,1),%rbp
  1b0ec6:	lea    (%r10,%rbp,1),%r13
  1b0eca:	add    $0x8,%r13
  1b0ece:	add    %rbp,%r10
  1b0ed1:	add    $0x10,%r10
  1b0ed5:	cmp    %rbx,%r9
  1b0ed8:	setb   0x38(%rsp)
  1b0edd:	cmp    %r11,%r8
  1b0ee0:	setb   0x40(%rsp)
  1b0ee5:	cmp    %r13,%r9
  1b0ee8:	setb   0x48(%rsp)
  1b0eed:	cmp    %r11,%rbp
  1b0ef0:	setb   0x100(%rsp)
  1b0ef8:	cmp    %r10,%r9
  1b0efb:	lea    0x8(%r15,%r12,1),%r9
  1b0f00:	setb   %r12b
  1b0f04:	cmp    %r11,%r9
  1b0f07:	setb   0xb0(%rsp)
  1b0f0f:	cmp    %r13,%r8
  1b0f12:	mov    0x50(%rsp),%r13
  1b0f17:	setb   %r11b
  1b0f1b:	cmp    %rbx,%rbp
  1b0f1e:	mov    0x20(%rsp),%rbp
  1b0f23:	setb   0xd0(%rsp)
  1b0f2b:	cmp    %r10,%r8
  1b0f2e:	setb   %r10b
  1b0f32:	cmp    %rbx,%r9
  1b0f35:	mov    0x8(%rsp),%rbx
  1b0f3a:	setb   0xe0(%rsp)
  1b0f42:	mov    %rbp,%r8
  1b0f45:	movzbl 0x40(%rsp),%r9d
  1b0f4b:	test   %r9b,0x38(%rsp)
  1b0f50:	jne    1b00bb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x723b>
  1b0f56:	mov    %rbp,%r8
  1b0f59:	movzbl 0x100(%rsp),%r9d
  1b0f62:	and    %r9b,0x48(%rsp)
  1b0f67:	jne    1b00bb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x723b>
  1b0f6d:	mov    %rbp,%r8
  1b0f70:	and    0xb0(%rsp),%r12b
  1b0f78:	jne    1b00bb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x723b>
  1b0f7e:	mov    %rbp,%r8
  1b0f81:	and    0xd0(%rsp),%r11b
  1b0f89:	jne    1b00bb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x723b>
  1b0f8f:	mov    %rbp,%r8
  1b0f92:	and    0xe0(%rsp),%r10b
  1b0f9a:	jne    1b00bb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x723b>
  1b0fa0:	and    $0xfffffffffffffffe,%rax
  1b0fa4:	lea    (%rax,%rbp,1),%r8
  1b0fa8:	mov    0x1d8(%rsp),%r9
  1b0fb0:	movsd  0x10(%r9),%xmm0
  1b0fb6:	movsd  0x18(%r9),%xmm1
  1b0fbc:	unpcklpd %xmm1,%xmm1
  1b0fc0:	unpcklpd %xmm0,%xmm0
  1b0fc4:	add    %r15,%rdx
  1b0fc7:	nopw   0x0(%rax,%rax,1)
  1b0fd0:	movupd (%rdx,%rcx,1),%xmm2
  1b0fd5:	movupd 0x10(%rdx,%rcx,1),%xmm3
  1b0fdb:	movapd %xmm2,%xmm4
  1b0fdf:	unpcklpd %xmm3,%xmm4
  1b0fe3:	unpckhpd %xmm3,%xmm2
  1b0fe7:	movapd %xmm1,%xmm3
  1b0feb:	mulpd  %xmm4,%xmm3
  1b0fef:	movapd %xmm0,%xmm5
  1b0ff3:	mulpd  %xmm2,%xmm5
  1b0ff7:	addpd  %xmm3,%xmm5
  1b0ffb:	mulpd  %xmm0,%xmm4
  1b0fff:	mulpd  %xmm1,%xmm2
  1b1003:	subpd  %xmm2,%xmm4
  1b1007:	movapd %xmm4,%xmm2
  1b100b:	unpcklpd %xmm5,%xmm2
  1b100f:	unpckhpd %xmm5,%xmm4
  1b1013:	movupd %xmm4,0x10(%rdx,%rsi,1)
  1b1019:	movupd %xmm2,(%rdx,%rsi,1)
  1b101e:	add    $0x20,%rdx
  1b1022:	add    $0xfffffffffffffffe,%rax
  1b1026:	jne    1b0fd0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8150>
  1b1028:	mov    0x20(%rsp),%rbp
  1b102d:	jmp    1b00bb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x723b>
  1b1032:	xor    %r8d,%r8d
  1b1035:	mov    0x8(%rsp),%r14
  1b103a:	mov    %r14,%r9
  1b103d:	sub    %r12,%r9
  1b1040:	cmovb  %r8,%r9
  1b1044:	sub    %r13,%r14
  1b1047:	cmovb  %r8,%r14
  1b104b:	cmp    %r14,%r9
  1b104e:	cmovb  %r9,%r14
  1b1052:	cmp    %r14,%rdx
  1b1055:	cmovb  %rdx,%r14
  1b1059:	mov    (%rsp),%r8
  1b105d:	shl    $0x6,%r8
  1b1061:	lea    (%r8,%r8,2),%r8
  1b1065:	mov    %rbp,%r10
  1b1068:	shl    $0x4,%r10
  1b106c:	lea    (%r15,%r8,1),%r9
  1b1070:	lea    (%r10,%r9,1),%rbx
  1b1074:	add    $0x8,%rbx
  1b1078:	add    %r10,%r9
  1b107b:	mov    %r14,%r11
  1b107e:	shl    $0x4,%r11
  1b1082:	add    %r11,%r9
  1b1085:	add    $0x8,%r9
  1b1089:	mov    %rbp,%r11
  1b108c:	cmp    %rbx,%r9
  1b108f:	jb     1afa42 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6bc2>
  1b1095:	mov    %rbp,%r11
  1b1098:	movabs $0xfffffffffffffff,%rsi
  1b10a2:	cmp    %rsi,%r14
  1b10a5:	ja     1afa42 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6bc2>
  1b10ab:	imul   $0x290,(%rsp),%r14
  1b10b3:	lea    (%r14,%r10,1),%r9
  1b10b7:	xor    %r11d,%r11d
  1b10ba:	mov    0x8(%rsp),%rsi
  1b10bf:	mov    %rsi,%rbx
  1b10c2:	sub    %r12,%rbx
  1b10c5:	cmovb  %r11,%rbx
  1b10c9:	mov    %rsi,%r12
  1b10cc:	sub    %r13,%r12
  1b10cf:	cmovb  %r11,%r12
  1b10d3:	lea    (%r15,%r9,1),%r13
  1b10d7:	cmp    %r12,%rbx
  1b10da:	cmovb  %rbx,%r12
  1b10de:	lea    (%r15,%r9,1),%rsi
  1b10e2:	add    $0x8,%rsi
  1b10e6:	mov    %rsi,0xd0(%rsp)
  1b10ee:	cmp    %r12,%rdx
  1b10f1:	cmovb  %rdx,%r12
  1b10f5:	shl    $0x4,%r12
  1b10f9:	lea    (%r12,%r13,1),%rsi
  1b10fd:	add    $0x8,%rsi
  1b1101:	mov    %rsi,0x88(%rsp)
  1b1109:	lea    0x10(%r12,%r13,1),%r11
  1b110e:	mov    %r11,0xe0(%rsp)
  1b1116:	mov    (%rsp),%rsi
  1b111a:	lea    (%rsi,%rsi,2),%r9
  1b111e:	shl    $0x6,%r9
  1b1122:	add    %r10,%r9
  1b1125:	lea    (%r15,%r9,1),%rsi
  1b1129:	lea    (%r12,%rsi,1),%rbx
  1b112d:	add    $0x8,%rbx
  1b1131:	mov    %rbx,0x58(%rsp)
  1b1136:	add    %rsi,%r12
  1b1139:	add    $0x10,%r12
  1b113d:	mov    %r12,0x48(%rsp)
  1b1142:	cmp    %r11,%r13
  1b1145:	setb   0x100(%rsp)
  1b114d:	mov    0xd0(%rsp),%r12
  1b1155:	mov    0x88(%rsp),%rbx
  1b115d:	cmp    %rbx,%r12
  1b1160:	setb   0xb0(%rsp)
  1b1168:	mov    0x58(%rsp),%r11
  1b116d:	cmp    %r11,%r13
  1b1170:	setb   0x78(%rsp)
  1b1175:	cmp    %rbx,%rsi
  1b1178:	setb   0x80(%rsp)
  1b1180:	cmp    0x48(%rsp),%r13
  1b1185:	lea    0x8(%r15,%r9,1),%r13
  1b118a:	setb   %r9b
  1b118e:	cmp    %rbx,%r13
  1b1191:	setb   0x88(%rsp)
  1b1199:	cmp    %r11,%r12
  1b119c:	setb   0x58(%rsp)
  1b11a1:	mov    0xe0(%rsp),%r11
  1b11a9:	cmp    %r11,%rsi
  1b11ac:	setb   0x98(%rsp)
  1b11b4:	cmp    0x48(%rsp),%r12
  1b11b9:	setb   %sil
  1b11bd:	cmp    %r11,%r13
  1b11c0:	setb   %bl
  1b11c3:	mov    %rbp,%r11
  1b11c6:	movzbl 0xb0(%rsp),%r12d
  1b11cf:	test   %r12b,0x100(%rsp)
  1b11d7:	jne    1afa42 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6bc2>
  1b11dd:	mov    %rbp,%r11
  1b11e0:	movzbl 0x80(%rsp),%r12d
  1b11e9:	and    %r12b,0x78(%rsp)
  1b11ee:	jne    1afa42 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6bc2>
  1b11f4:	mov    %rbp,%r11
  1b11f7:	and    0x88(%rsp),%r9b
  1b11ff:	jne    1afa42 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6bc2>
  1b1205:	mov    %rbp,%r11
  1b1208:	movzbl 0x98(%rsp),%r9d
  1b1211:	and    %r9b,0x58(%rsp)
  1b1216:	jne    1afa42 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6bc2>
  1b121c:	mov    %rbp,%r11
  1b121f:	and    %bl,%sil
  1b1222:	jne    1afa42 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6bc2>
  1b1228:	and    $0xfffffffffffffffe,%rax
  1b122c:	lea    (%rax,%rbp,1),%r11
  1b1230:	mov    0x1d8(%rsp),%rsi
  1b1238:	movsd  0x10(%rsi),%xmm0
  1b123d:	movsd  0x18(%rsi),%xmm1
  1b1242:	unpcklpd %xmm1,%xmm1
  1b1246:	unpcklpd %xmm0,%xmm0
  1b124a:	add    %r15,%r10
  1b124d:	nopl   (%rax)
  1b1250:	movupd (%r10,%r8,1),%xmm2
  1b1256:	movupd 0x10(%r10,%r8,1),%xmm3
  1b125d:	movapd %xmm2,%xmm4
  1b1261:	unpcklpd %xmm3,%xmm4
  1b1265:	unpckhpd %xmm3,%xmm2
  1b1269:	movapd %xmm1,%xmm3
  1b126d:	mulpd  %xmm4,%xmm3
  1b1271:	movapd %xmm0,%xmm5
  1b1275:	mulpd  %xmm2,%xmm5
  1b1279:	addpd  %xmm3,%xmm5
  1b127d:	mulpd  %xmm0,%xmm4
  1b1281:	mulpd  %xmm1,%xmm2
  1b1285:	subpd  %xmm2,%xmm4
  1b1289:	movapd %xmm4,%xmm2
  1b128d:	unpcklpd %xmm5,%xmm2
  1b1291:	unpckhpd %xmm5,%xmm4
  1b1295:	movupd %xmm4,0x10(%r10,%r14,1)
  1b129c:	movupd %xmm2,(%r10,%r14,1)
  1b12a2:	add    $0x20,%r10
  1b12a6:	add    $0xfffffffffffffffe,%rax
  1b12aa:	jne    1b1250 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x83d0>
  1b12ac:	mov    0x20(%rsp),%rbp
  1b12b1:	jmp    1afa42 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6bc2>
  1b12b6:	xor    %r9d,%r9d
  1b12b9:	mov    %rbx,%r10
  1b12bc:	sub    0x10(%rsp),%r10
  1b12c1:	cmovb  %r9,%r10
  1b12c5:	mov    0x18(%rsp),%r11
  1b12ca:	cmp    %r11,%r10
  1b12cd:	cmovae %r11,%r10
  1b12d1:	mov    %rbx,%r11
  1b12d4:	sub    %rsi,%r11
  1b12d7:	cmovb  %r9,%r11
  1b12db:	cmp    %r11,%r10
  1b12de:	cmovb  %r10,%r11
  1b12e2:	cmp    %r11,%rdx
  1b12e5:	cmovb  %rdx,%r11
  1b12e9:	imul   $0xf0,(%rsp),%r9
  1b12f1:	mov    %rbp,%r10
  1b12f4:	shl    $0x4,%r10
  1b12f8:	mov    %r9,0x48(%rsp)
  1b12fd:	lea    (%r15,%r9,1),%rbx
  1b1301:	lea    (%r10,%rbx,1),%r13
  1b1305:	add    $0x8,%r13
  1b1309:	add    %r10,%rbx
  1b130c:	mov    %r11,%r9
  1b130f:	shl    $0x4,%r9
  1b1313:	add    %r9,%rbx
  1b1316:	add    $0x8,%rbx
  1b131a:	mov    %rbp,%r14
  1b131d:	cmp    %r13,%rbx
  1b1320:	mov    0x8(%rsp),%rbx
  1b1325:	jb     1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b132b:	lea    (%r15,%r8,1),%rbx
  1b132f:	lea    (%r10,%rbx,1),%r13
  1b1333:	add    $0x8,%r13
  1b1337:	add    %r10,%rbx
  1b133a:	add    %rbx,%r9
  1b133d:	add    $0x8,%r9
  1b1341:	mov    0x8(%rsp),%rbx
  1b1346:	mov    %rbp,%r14
  1b1349:	cmp    %r13,%r9
  1b134c:	jb     1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b1352:	mov    %rbp,%r14
  1b1355:	movabs $0xfffffffffffffff,%r9
  1b135f:	cmp    %r9,%r11
  1b1362:	ja     1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b1368:	imul   $0x2a0,(%rsp),%r13
  1b1370:	xor    %r9d,%r9d
  1b1373:	mov    0x8(%rsp),%rbx
  1b1378:	sub    0x10(%rsp),%rbx
  1b137d:	cmovb  %r9,%rbx
  1b1381:	mov    0x18(%rsp),%r11
  1b1386:	cmp    %r11,%rbx
  1b1389:	cmovae %r11,%rbx
  1b138d:	mov    0x8(%rsp),%r14
  1b1392:	sub    %rsi,%r14
  1b1395:	cmovb  %r9,%r14
  1b1399:	lea    (%r10,%r13,1),%r9
  1b139d:	cmp    %r14,%rbx
  1b13a0:	cmovb  %rbx,%r14
  1b13a4:	lea    (%r15,%r9,1),%rsi
  1b13a8:	cmp    %r14,%rdx
  1b13ab:	cmovb  %rdx,%r14
  1b13af:	lea    (%r15,%r9,1),%rdx
  1b13b3:	add    $0x8,%rdx
  1b13b7:	mov    %rdx,0xb0(%rsp)
  1b13bf:	shl    $0x4,%r14
  1b13c3:	lea    (%r14,%rsi,1),%r9
  1b13c7:	add    $0x8,%r9
  1b13cb:	lea    0x10(%r14,%rsi,1),%rdx
  1b13d0:	mov    %rdx,0x18(%rsp)
  1b13d5:	mov    0x48(%rsp),%rdx
  1b13da:	add    %r10,%rdx
  1b13dd:	lea    (%r15,%rdx,1),%r11
  1b13e1:	add    $0x8,%r11
  1b13e5:	mov    %r11,0x80(%rsp)
  1b13ed:	add    %r15,%rdx
  1b13f0:	lea    (%r14,%rdx,1),%r11
  1b13f4:	add    $0x10,%r11
  1b13f8:	mov    %r11,0xd0(%rsp)
  1b1400:	lea    (%r8,%r10,1),%r11
  1b1404:	lea    (%r15,%r11,1),%rbx
  1b1408:	add    $0x8,%rbx
  1b140c:	mov    %rbx,0x100(%rsp)
  1b1414:	add    %r15,%r11
  1b1417:	lea    (%r14,%r11,1),%rbx
  1b141b:	add    $0x10,%rbx
  1b141f:	mov    %rbx,0x58(%rsp)
  1b1424:	lea    0x8(%r14,%rdx,1),%rbx
  1b1429:	mov    %rbx,0xe0(%rsp)
  1b1431:	add    %r11,%r14
  1b1434:	add    $0x8,%r14
  1b1438:	mov    %r14,0x10(%rsp)
  1b143d:	cmp    0x18(%rsp),%rsi
  1b1442:	setb   0x88(%rsp)
  1b144a:	cmp    %r9,0xb0(%rsp)
  1b1452:	setb   0x78(%rsp)
  1b1457:	cmp    0xd0(%rsp),%rsi
  1b145f:	setb   0x98(%rsp)
  1b1467:	mov    0x80(%rsp),%r14
  1b146f:	cmp    %r9,%r14
  1b1472:	setb   0xc8(%rsp)
  1b147a:	cmp    0x58(%rsp),%rsi
  1b147f:	setb   0xa8(%rsp)
  1b1487:	cmp    %r9,0x100(%rsp)
  1b148f:	setb   0xf8(%rsp)
  1b1497:	cmp    0xe0(%rsp),%rsi
  1b149f:	setb   0x118(%rsp)
  1b14a7:	cmp    %r9,%rdx
  1b14aa:	setb   0x120(%rsp)
  1b14b2:	cmp    0x10(%rsp),%rsi
  1b14b7:	setb   0x130(%rsp)
  1b14bf:	cmp    %r9,%r11
  1b14c2:	setb   0x140(%rsp)
  1b14ca:	mov    0xb0(%rsp),%rbx
  1b14d2:	cmp    0xd0(%rsp),%rbx
  1b14da:	setb   0xd0(%rsp)
  1b14e2:	mov    0x18(%rsp),%r9
  1b14e7:	cmp    %r9,%r14
  1b14ea:	setb   0x80(%rsp)
  1b14f2:	cmp    0x58(%rsp),%rbx
  1b14f7:	setb   0x58(%rsp)
  1b14fc:	cmp    %r9,0x100(%rsp)
  1b1504:	setb   0x100(%rsp)
  1b150c:	cmp    0xe0(%rsp),%rbx
  1b1514:	setb   %sil
  1b1518:	cmp    %r9,%rdx
  1b151b:	mov    %r9,%r14
  1b151e:	setb   %r9b
  1b1522:	cmp    0x10(%rsp),%rbx
  1b1527:	mov    0x8(%rsp),%rbx
  1b152c:	setb   %dl
  1b152f:	cmp    %r14,%r11
  1b1532:	mov    %rbp,%r14
  1b1535:	setb   0x18(%rsp)
  1b153a:	movzbl 0x78(%rsp),%r11d
  1b1540:	test   %r11b,0x88(%rsp)
  1b1548:	jne    1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b154e:	mov    %rbp,%r14
  1b1551:	movzbl 0xc8(%rsp),%r11d
  1b155a:	and    %r11b,0x98(%rsp)
  1b1562:	jne    1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b1568:	mov    %rbp,%r14
  1b156b:	movzbl 0xf8(%rsp),%r11d
  1b1574:	and    %r11b,0xa8(%rsp)
  1b157c:	jne    1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b1582:	mov    %rbp,%r14
  1b1585:	movzbl 0x120(%rsp),%r11d
  1b158e:	and    %r11b,0x118(%rsp)
  1b1596:	jne    1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b159c:	mov    %rbp,%r14
  1b159f:	movzbl 0x140(%rsp),%r11d
  1b15a8:	and    %r11b,0x130(%rsp)
  1b15b0:	jne    1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b15b6:	mov    %rbp,%r14
  1b15b9:	movzbl 0x80(%rsp),%r11d
  1b15c2:	and    %r11b,0xd0(%rsp)
  1b15ca:	jne    1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b15d0:	mov    %rbp,%r14
  1b15d3:	movzbl 0x100(%rsp),%r11d
  1b15dc:	and    %r11b,0x58(%rsp)
  1b15e1:	jne    1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b15e7:	mov    %rbp,%r14
  1b15ea:	and    %r9b,%sil
  1b15ed:	jne    1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b15f3:	mov    %rbp,%r14
  1b15f6:	and    0x18(%rsp),%dl
  1b15fa:	jne    1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b1600:	and    $0xfffffffffffffffe,%rdi
  1b1604:	lea    (%rdi,%rbp,1),%r14
  1b1608:	add    %r15,%r10
  1b160b:	mov    0x48(%rsp),%rdx
  1b1610:	movupd (%r10,%rdx,1),%xmm0
  1b1616:	movupd (%r10,%r8,1),%xmm1
  1b161c:	addpd  %xmm0,%xmm1
  1b1620:	movupd %xmm1,(%r10,%r13,1)
  1b1626:	add    $0x10,%r10
  1b162a:	dec    %rdi
  1b162d:	jne    1b1610 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8790>
  1b162f:	jmp    1afb3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x6cbe>
  1b1634:	mov    0x8(%rsp),%rbx
  1b1639:	mov    0x28(%rsp),%r11
  1b163e:	mov    0x1c8(%rsp),%r10
  1b1646:	mov    0x50(%rsp),%r13
  1b164b:	mov    0x20(%rsp),%r14
  1b1650:	mov    0x30(%rsp),%r12
  1b1655:	mov    (%rsp),%rdi
  1b1659:	imul   $0x2f0,%rdi,%rcx
  1b1660:	mov    %r14,%rsi
  1b1663:	shl    $0x4,%rsi
  1b1667:	add    %r15,%rsi
  1b166a:	imul   $0x2e0,%rdi,%r8
  1b1671:	imul   $0x2b0,%rdi,%r9
  1b1678:	nopl   0x0(%rax,%rax,1)
  1b1680:	mov    0x10(%rsp),%rdi
  1b1685:	add    %r14,%rdi
  1b1688:	cmp    %rbx,%rdi
  1b168b:	jae    1beb41 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15cc1>
  1b1691:	lea    (%rax,%r14,1),%rdi
  1b1695:	cmp    %rbx,%rdi
  1b1698:	jae    1beb31 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15cb1>
  1b169e:	lea    (%rdx,%r14,1),%rdi
  1b16a2:	cmp    %rbx,%rdi
  1b16a5:	jae    1beb21 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ca1>
  1b16ab:	inc    %r14
  1b16ae:	movupd (%rsi,%r9,1),%xmm0
  1b16b4:	movupd (%rsi,%r8,1),%xmm1
  1b16ba:	addpd  %xmm0,%xmm1
  1b16be:	movupd %xmm1,(%rsi,%rcx,1)
  1b16c3:	add    $0x10,%rsi
  1b16c7:	cmp    %r14,%r12
  1b16ca:	jne    1b1680 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8800>
  1b16cc:	mov    0x1b0(%rsp),%r9
  1b16d4:	xor    %ecx,%ecx
  1b16d6:	xorpd  %xmm0,%xmm0
  1b16da:	xor    %esi,%esi
  1b16dc:	nopl   0x0(%rax)
  1b16e0:	mov    (%r11,%rcx,8),%rdi
  1b16e4:	lea    (%rdi,%rdx,1),%rax
  1b16e8:	cmp    %rbx,%rax
  1b16eb:	jae    1bdb23 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14ca3>
  1b16f1:	shl    $0x4,%rax
  1b16f5:	movsd  (%r15,%rax,1),%xmm1
  1b16fb:	ucomisd %xmm0,%xmm1
  1b16ff:	jne    1b1740 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x88c0>
  1b1701:	jp     1b1740 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x88c0>
  1b1703:	add    %r15,%rax
  1b1706:	movsd  0x8(%rax),%xmm1
  1b170b:	ucomisd %xmm0,%xmm1
  1b170f:	jne    1b1740 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x88c0>
  1b1711:	jp     1b1740 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x88c0>
  1b1713:	cmp    0x1d0(%rsp),%rdi
  1b171b:	jae    1be806 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15986>
  1b1721:	movq   $0x2e,(%r10,%rdi,8)
  1b1729:	inc    %rcx
  1b172c:	cmp    %rcx,%r13
  1b172f:	jne    1b16e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8860>
  1b1731:	jmp    1b1758 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x88d8>
  1b1733:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b1740:	cmp    %r9,%rsi
  1b1743:	jae    1be2a1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15421>
  1b1749:	mov    %rdi,(%r11,%rsi,8)
  1b174d:	inc    %rsi
  1b1750:	inc    %rcx
  1b1753:	cmp    %rcx,%r13
  1b1756:	jne    1b16e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8860>
  1b1758:	cmp    %r9,%rsi
  1b175b:	ja     1bd42d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x145ad>
  1b1761:	test   %rsi,%rsi
  1b1764:	mov    0x1d0(%rsp),%rdx
  1b176c:	mov    0x90(%rsp),%rcx
  1b1774:	je     1b17a6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8926>
  1b1776:	shl    $0x3,%rsi
  1b177a:	xor    %eax,%eax
  1b177c:	nopl   0x0(%rax)
  1b1780:	mov    (%r11,%rax,1),%rdi
  1b1784:	cmp    %rdx,%rdi
  1b1787:	jae    1be1c5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15345>
  1b178d:	mov    0x1c8(%rsp),%r8
  1b1795:	movq   $0x2f,(%r8,%rdi,8)
  1b179d:	add    $0x8,%rax
  1b17a1:	cmp    %rax,%rsi
  1b17a4:	jne    1b1780 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8900>
  1b17a6:	xor    %eax,%eax
  1b17a8:	xor    %esi,%esi
  1b17aa:	mov    0x110(%rsp),%rbx
  1b17b2:	mov    0x1c8(%rsp),%r10
  1b17ba:	jmp    1b17c9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8949>
  1b17bc:	nopl   0x0(%rax)
  1b17c0:	add    $0x8,%rax
  1b17c4:	cmp    %rax,%rcx
  1b17c7:	je     1b17ef <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x896f>
  1b17c9:	mov    (%rbx,%rax,1),%rdi
  1b17cd:	cmp    %rdx,%rdi
  1b17d0:	jae    1bd54a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x146ca>
  1b17d6:	cmpq   $0x2f,(%r10,%rdi,8)
  1b17db:	jae    1b17c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8940>
  1b17dd:	cmp    %r9,%rsi
  1b17e0:	jae    1bd9d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14b50>
  1b17e6:	mov    %rdi,(%r11,%rsi,8)
  1b17ea:	inc    %rsi
  1b17ed:	jmp    1b17c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8940>
  1b17ef:	cmp    %r9,%rsi
  1b17f2:	ja     1b5b3c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xccbc>
  1b17f8:	test   %rsi,%rsi
  1b17fb:	je     1b183b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x89bb>
  1b17fd:	mov    (%r11),%rdi
  1b1800:	lea    -0x1(%rsi),%rax
  1b1804:	mov    -0x8(%r11,%rsi,8),%rcx
  1b1809:	sub    %rdi,%rcx
  1b180c:	setae  %dl
  1b180f:	cmp    %rax,%rcx
  1b1812:	sete   %al
  1b1815:	and    %dl,%al
  1b1817:	cmp    $0x1,%al
  1b1819:	jne    1b1848 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x89c8>
  1b181b:	add    %rdi,%rsi
  1b181e:	jb     1bd463 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x145e3>
  1b1824:	mov    0x1d0(%rsp),%rdx
  1b182c:	mov    0x90(%rsp),%rcx
  1b1834:	mov    %rdi,0x60(%rsp)
  1b1839:	jmp    1b1863 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x89e3>
  1b183b:	xor    %esi,%esi
  1b183d:	movq   $0x0,0x60(%rsp)
  1b1846:	jmp    1b1863 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x89e3>
  1b1848:	xor    %esi,%esi
  1b184a:	movq   $0x0,0x60(%rsp)
  1b1853:	mov    0x1d0(%rsp),%rdx
  1b185b:	mov    0x90(%rsp),%rcx
  1b1863:	xor    %eax,%eax
  1b1865:	xor    %r13d,%r13d
  1b1868:	jmp    1b1879 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x89f9>
  1b186a:	nopw   0x0(%rax,%rax,1)
  1b1870:	add    $0x8,%rax
  1b1874:	cmp    %rax,%rcx
  1b1877:	je     1b189f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8a1f>
  1b1879:	mov    (%rbx,%rax,1),%rdi
  1b187d:	cmp    %rdx,%rdi
  1b1880:	jae    1bd55a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x146da>
  1b1886:	cmpq   $0x30,(%r10,%rdi,8)
  1b188b:	jae    1b1870 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x89f0>
  1b188d:	cmp    %r9,%r13
  1b1890:	jae    1bd9e3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14b63>
  1b1896:	mov    %rdi,(%r11,%r13,8)
  1b189a:	inc    %r13
  1b189d:	jmp    1b1870 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x89f0>
  1b189f:	cmp    %r9,%r13
  1b18a2:	ja     1b5b4e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xccce>
  1b18a8:	test   %r13,%r13
  1b18ab:	je     1b24be <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x963e>
  1b18b1:	mov    (%r11),%rax
  1b18b4:	lea    -0x1(%r13),%rcx
  1b18b8:	mov    -0x8(%r11,%r13,8),%rdx
  1b18bd:	sub    %rax,%rdx
  1b18c0:	setae  %dil
  1b18c4:	cmp    %rcx,%rdx
  1b18c7:	sete   %cl
  1b18ca:	and    %dil,%cl
  1b18cd:	cmp    $0x1,%cl
  1b18d0:	jne    1b18ec <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8a6c>
  1b18d2:	mov    %rax,%rcx
  1b18d5:	add    %r13,%rcx
  1b18d8:	jb     1b18ec <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8a6c>
  1b18da:	mov    $0x1,%dl
  1b18dc:	mov    %edx,0x20(%rsp)
  1b18e0:	mov    %rcx,0x30(%rsp)
  1b18e5:	mov    %rax,0x60(%rsp)
  1b18ea:	jmp    1b18f9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8a79>
  1b18ec:	mov    %rsi,0x30(%rsp)
  1b18f1:	movl   $0x0,0x20(%rsp)
  1b18f9:	mov    0x110(%rsp),%rbx
  1b1901:	lea    0x0(,%r13,8),%rbp
  1b1909:	mov    (%rsp),%rax
  1b190d:	imul   $0x2f,%rax,%r14
  1b1911:	imul   $0x34,%rax,%rax
  1b1915:	mov    %rax,0x18(%rsp)
  1b191a:	xor    %r12d,%r12d
  1b191d:	xorpd  %xmm1,%xmm1
  1b1921:	jmp    1b1977 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8af7>
  1b1923:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b1930:	mov    $0x34,%r8d
  1b1936:	mov    $0x2f,%r9d
  1b193c:	mov    %r15,%rdi
  1b193f:	mov    0x8(%rsp),%rsi
  1b1944:	mov    (%rsp),%rdx
  1b1948:	call   1a8d70 <oneloop::native::batch::copy_active_column::<f64>>
  1b194d:	xorpd  %xmm1,%xmm1
  1b1951:	mov    0x1c8(%rsp),%r10
  1b1959:	mov    0x110(%rsp),%rbx
  1b1961:	mov    0x28(%rsp),%r11
  1b1966:	mov    0x1b0(%rsp),%r9
  1b196e:	add    $0x8,%r12
  1b1972:	cmp    %r12,%rbp
  1b1975:	je     1b19eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8b6b>
  1b1977:	mov    (%r11,%r12,1),%rcx
  1b197b:	lea    (%rcx,%r14,1),%rdi
  1b197f:	cmp    0x8(%rsp),%rdi
  1b1984:	jae    1bd716 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14896>
  1b198a:	shl    $0x4,%rdi
  1b198e:	movsd  (%r15,%rdi,1),%xmm0
  1b1994:	ucomisd %xmm1,%xmm0
  1b1998:	jne    1b1930 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8ab0>
  1b199a:	jp     1b1930 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8ab0>
  1b199c:	add    %r15,%rdi
  1b199f:	movsd  0x8(%rdi),%xmm0
  1b19a4:	ucomisd %xmm1,%xmm0
  1b19a8:	jne    1b1930 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8ab0>
  1b19aa:	jp     1b1930 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8ab0>
  1b19ac:	add    0x18(%rsp),%rcx
  1b19b1:	cmp    0x8(%rsp),%rcx
  1b19b6:	jae    1be1d5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15355>
  1b19bc:	cmpq   $0x3,0x1e0(%rsp)
  1b19c5:	jbe    1bda1c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14b9c>
  1b19cb:	shl    $0x4,%rcx
  1b19cf:	mov    0x1d8(%rsp),%rax
  1b19d7:	movupd 0x30(%rax),%xmm0
  1b19dc:	movupd %xmm0,(%r15,%rcx,1)
  1b19e2:	add    $0x8,%r12
  1b19e6:	cmp    %r12,%rbp
  1b19e9:	jne    1b1977 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8af7>
  1b19eb:	imul   $0x35,(%rsp),%r8
  1b19f0:	xor    %r12d,%r12d
  1b19f3:	xorpd  %xmm8,%xmm8
  1b19f8:	movapd 0x1fe45ff(%rip),%xmm9        # 2196000 <_fini+0x520>
  1b1a01:	movsd  0x1fe5ca7(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b1a09:	movsd  0x1fe5ca7(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b1a11:	mov    %r8,0x10(%rsp)
  1b1a16:	cs nopw 0x0(%rax,%rax,1)
  1b1a20:	mov    (%r11,%r12,1),%r14
  1b1a24:	mov    0x18(%rsp),%rax
  1b1a29:	lea    (%r14,%rax,1),%rdi
  1b1a2d:	cmp    0x8(%rsp),%rdi
  1b1a32:	jae    1bd73d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x148bd>
  1b1a38:	shl    $0x4,%rdi
  1b1a3c:	movupd (%r15,%rdi,1),%xmm0
  1b1a42:	movapd %xmm0,%xmm1
  1b1a46:	unpckhpd %xmm0,%xmm1
  1b1a4a:	ucomisd %xmm8,%xmm1
  1b1a4f:	jne    1b1a60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8be0>
  1b1a51:	jp     1b1a60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8be0>
  1b1a53:	andpd  %xmm9,%xmm0
  1b1a58:	jmp    1b1b30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8cb0>
  1b1a5d:	nopl   (%rax)
  1b1a60:	ucomisd %xmm8,%xmm0
  1b1a65:	jne    1b1a77 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8bf7>
  1b1a67:	jp     1b1a77 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8bf7>
  1b1a69:	andpd  %xmm9,%xmm1
  1b1a6e:	movapd %xmm1,%xmm0
  1b1a72:	jmp    1b1b30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8cb0>
  1b1a77:	movapd %xmm0,%xmm2
  1b1a7b:	andpd  %xmm9,%xmm2
  1b1a80:	pshufd $0xee,%xmm2,%xmm3
  1b1a85:	movapd %xmm2,%xmm4
  1b1a89:	cmplesd %xmm3,%xmm4
  1b1a8e:	movapd %xmm4,%xmm5
  1b1a92:	andpd  %xmm3,%xmm5
  1b1a96:	andnpd %xmm2,%xmm4
  1b1a9a:	orpd   %xmm5,%xmm4
  1b1a9e:	movapd %xmm0,%xmm2
  1b1aa2:	cmpunordsd %xmm0,%xmm2
  1b1aa7:	movapd %xmm2,%xmm5
  1b1aab:	andnpd %xmm4,%xmm5
  1b1aaf:	andpd  %xmm3,%xmm2
  1b1ab3:	orpd   %xmm5,%xmm2
  1b1ab7:	ucomisd %xmm6,%xmm2
  1b1abb:	jbe    1b1adc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8c5c>
  1b1abd:	ucomisd %xmm2,%xmm7
  1b1ac1:	jbe    1b1adc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8c5c>
  1b1ac3:	mulpd  %xmm0,%xmm0
  1b1ac7:	movapd %xmm0,%xmm1
  1b1acb:	unpckhpd %xmm0,%xmm1
  1b1acf:	addsd  %xmm0,%xmm1
  1b1ad3:	xorps  %xmm0,%xmm0
  1b1ad6:	sqrtsd %xmm1,%xmm0
  1b1ada:	jmp    1b1b30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8cb0>
  1b1adc:	call   *0x251a0ee(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1b1ae2:	movapd 0x1fe4515(%rip),%xmm9        # 2196000 <_fini+0x520>
  1b1aeb:	xorpd  %xmm8,%xmm8
  1b1af0:	mov    0x10(%rsp),%r8
  1b1af5:	movsd  0x1fe5bbb(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b1afd:	movsd  0x1fe5bab(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b1b05:	mov    0x1c8(%rsp),%r10
  1b1b0d:	mov    0x110(%rsp),%rbx
  1b1b15:	mov    0x28(%rsp),%r11
  1b1b1a:	mov    0x1b0(%rsp),%r9
  1b1b22:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b1b30:	add    %r8,%r14
  1b1b33:	cmp    0x8(%rsp),%r14
  1b1b38:	jae    1bd728 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x148a8>
  1b1b3e:	shl    $0x4,%r14
  1b1b42:	movsd  %xmm0,(%r15,%r14,1)
  1b1b48:	movq   $0x0,0x8(%r15,%r14,1)
  1b1b51:	add    $0x8,%r12
  1b1b55:	cmp    %r12,%rbp
  1b1b58:	jne    1b1a20 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8ba0>
  1b1b5e:	cmpb   $0x0,0x20(%rsp)
  1b1b63:	je     1b1d78 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8ef8>
  1b1b69:	mov    0x30(%rsp),%rdi
  1b1b6e:	cmp    %rdi,0x60(%rsp)
  1b1b73:	jae    1b1e83 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9003>
  1b1b79:	cmpq   $0x2,0x1e0(%rsp)
  1b1b82:	mov    (%rsp),%rbp
  1b1b86:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b1b8c:	imul   $0x36,%rbp,%rax
  1b1b90:	mov    0x60(%rsp),%rsi
  1b1b95:	lea    (%rsi,%r8,1),%r11
  1b1b99:	xor    %ecx,%ecx
  1b1b9b:	mov    0x8(%rsp),%rbx
  1b1ba0:	mov    %rbx,%rdx
  1b1ba3:	sub    %r11,%rdx
  1b1ba6:	cmovb  %rcx,%rdx
  1b1baa:	lea    (%rsi,%rax,1),%r14
  1b1bae:	mov    %rbx,%r8
  1b1bb1:	sub    %r14,%r8
  1b1bb4:	cmovb  %rcx,%r8
  1b1bb8:	cmp    %r8,%rdx
  1b1bbb:	mov    %r8,0x20(%rsp)
  1b1bc0:	cmovae %r8,%rdx
  1b1bc4:	mov    %rsi,%rcx
  1b1bc7:	not    %rcx
  1b1bca:	add    %rdi,%rcx
  1b1bcd:	cmp    %rcx,%rdx
  1b1bd0:	cmovae %rcx,%rdx
  1b1bd4:	lea    0x1(%rdx),%rdi
  1b1bd8:	mov    %rsi,%r10
  1b1bdb:	cmp    $0x22,%rdi
  1b1bdf:	ja     1b30bc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa23c>
  1b1be5:	mov    %rbx,%rsi
  1b1be8:	imul   $0x360,%rbp,%r8
  1b1bef:	mov    %r10,%rdx
  1b1bf2:	shl    $0x4,%rdx
  1b1bf6:	add    %r15,%rdx
  1b1bf9:	imul   $0x350,%rbp,%r9
  1b1c00:	mov    0x1d8(%rsp),%r11
  1b1c08:	mov    0x30(%rsp),%rbx
  1b1c0d:	nopl   (%rax)
  1b1c10:	mov    0x10(%rsp),%rdi
  1b1c15:	add    %r10,%rdi
  1b1c18:	mov    %rsi,%r14
  1b1c1b:	cmp    %rsi,%rdi
  1b1c1e:	jae    1be5b9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15739>
  1b1c24:	lea    (%rax,%r10,1),%rdi
  1b1c28:	cmp    %r14,%rdi
  1b1c2b:	jae    1be5ac <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1572c>
  1b1c31:	inc    %r10
  1b1c34:	movupd 0x10(%r11),%xmm0
  1b1c3a:	movsd  (%rdx,%r9,1),%xmm1
  1b1c40:	movsd  0x8(%rdx,%r9,1),%xmm2
  1b1c47:	unpcklpd %xmm1,%xmm1
  1b1c4b:	mulpd  %xmm0,%xmm1
  1b1c4f:	shufpd $0x1,%xmm0,%xmm0
  1b1c54:	unpcklpd %xmm2,%xmm2
  1b1c58:	mulpd  %xmm0,%xmm2
  1b1c5c:	movapd %xmm1,%xmm0
  1b1c60:	subpd  %xmm2,%xmm0
  1b1c64:	addpd  %xmm1,%xmm2
  1b1c68:	movsd  %xmm0,%xmm2
  1b1c6c:	movupd %xmm2,(%rdx,%r8,1)
  1b1c72:	add    $0x10,%rdx
  1b1c76:	cmp    %r10,%rbx
  1b1c79:	jne    1b1c10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8d90>
  1b1c7b:	imul   $0x37,%rbp,%rdx
  1b1c7f:	mov    0x60(%rsp),%rbp
  1b1c84:	mov    0x18(%rsp),%rdi
  1b1c89:	lea    (%rdi,%rbp,1),%r12
  1b1c8d:	xor    %r9d,%r9d
  1b1c90:	mov    %rsi,%rbx
  1b1c93:	mov    %rsi,%r10
  1b1c96:	sub    %r12,%r10
  1b1c99:	cmovb  %r9,%r10
  1b1c9d:	mov    0x20(%rsp),%rsi
  1b1ca2:	cmp    %rsi,%r10
  1b1ca5:	cmovae %rsi,%r10
  1b1ca9:	lea    (%rdx,%rbp,1),%r11
  1b1cad:	mov    %rbx,%rdi
  1b1cb0:	mov    %r11,0x10(%rsp)
  1b1cb5:	sub    %r11,%rdi
  1b1cb8:	cmovb  %r9,%rdi
  1b1cbc:	cmp    %rdi,%r10
  1b1cbf:	cmovb  %r10,%rdi
  1b1cc3:	cmp    %rcx,%rdi
  1b1cc6:	cmovae %rcx,%rdi
  1b1cca:	lea    0x1(%rdi),%r9
  1b1cce:	mov    %rbp,%r14
  1b1cd1:	cmp    $0x42,%r9
  1b1cd5:	ja     1b3321 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa4a1>
  1b1cdb:	mov    (%rsp),%rdi
  1b1cdf:	imul   $0x370,%rdi,%rcx
  1b1ce6:	mov    %r14,%r12
  1b1ce9:	shl    $0x4,%r12
  1b1ced:	add    %r15,%r12
  1b1cf0:	imul   $0x340,%rdi,%r9
  1b1cf7:	mov    0x28(%rsp),%r11
  1b1cfc:	mov    0x1c8(%rsp),%r10
  1b1d04:	mov    0x30(%rsp),%rbx
  1b1d09:	nopl   0x0(%rax)
  1b1d10:	mov    0x18(%rsp),%rsi
  1b1d15:	lea    (%rsi,%r14,1),%rdi
  1b1d19:	mov    0x8(%rsp),%rsi
  1b1d1e:	cmp    %rsi,%rdi
  1b1d21:	jae    1be5e8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15768>
  1b1d27:	lea    (%rax,%r14,1),%rdi
  1b1d2b:	cmp    %rsi,%rdi
  1b1d2e:	jae    1be5db <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1575b>
  1b1d34:	lea    (%rdx,%r14,1),%rdi
  1b1d38:	cmp    %rsi,%rdi
  1b1d3b:	jae    1be5c9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15749>
  1b1d41:	inc    %r14
  1b1d44:	movupd (%r12,%r9,1),%xmm0
  1b1d4a:	movupd (%r12,%r8,1),%xmm1
  1b1d50:	addpd  %xmm0,%xmm1
  1b1d54:	movupd %xmm1,(%r12,%rcx,1)
  1b1d5a:	add    $0x10,%r12
  1b1d5e:	cmp    %r14,%rbx
  1b1d61:	jne    1b1d10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e90>
  1b1d63:	mov    0x1b0(%rsp),%r9
  1b1d6b:	mov    0x110(%rsp),%rbx
  1b1d73:	jmp    1b1e88 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9008>
  1b1d78:	cmpq   $0x2,0x1e0(%rsp)
  1b1d81:	mov    0x1d8(%rsp),%rdx
  1b1d89:	mov    0x8(%rsp),%rsi
  1b1d8e:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b1d94:	imul   $0x36,(%rsp),%rbx
  1b1d99:	xor    %ecx,%ecx
  1b1d9b:	nopl   0x0(%rax,%rax,1)
  1b1da0:	mov    (%r11,%rcx,1),%rdi
  1b1da4:	lea    (%rdi,%r8,1),%rax
  1b1da8:	cmp    %rsi,%rax
  1b1dab:	jae    1bde0a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14f8a>
  1b1db1:	add    %rbx,%rdi
  1b1db4:	cmp    %rsi,%rdi
  1b1db7:	jae    1bddfd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14f7d>
  1b1dbd:	shl    $0x4,%rax
  1b1dc1:	shl    $0x4,%rdi
  1b1dc5:	movupd 0x10(%rdx),%xmm0
  1b1dca:	movsd  (%r15,%rax,1),%xmm1
  1b1dd0:	movsd  0x8(%r15,%rax,1),%xmm2
  1b1dd7:	unpcklpd %xmm1,%xmm1
  1b1ddb:	mulpd  %xmm0,%xmm1
  1b1ddf:	shufpd $0x1,%xmm0,%xmm0
  1b1de4:	unpcklpd %xmm2,%xmm2
  1b1de8:	mulpd  %xmm0,%xmm2
  1b1dec:	movapd %xmm1,%xmm0
  1b1df0:	subpd  %xmm2,%xmm0
  1b1df4:	addpd  %xmm1,%xmm2
  1b1df8:	movsd  %xmm0,%xmm2
  1b1dfc:	movupd %xmm2,(%r15,%rdi,1)
  1b1e02:	add    $0x8,%rcx
  1b1e06:	cmp    %rcx,%rbp
  1b1e09:	jne    1b1da0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8f20>
  1b1e0b:	imul   $0x37,(%rsp),%rdx
  1b1e10:	xor    %r8d,%r8d
  1b1e13:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b1e20:	mov    (%r11,%r8,1),%rdi
  1b1e24:	mov    0x18(%rsp),%rax
  1b1e29:	add    %rdi,%rax
  1b1e2c:	cmp    %rsi,%rax
  1b1e2f:	jae    1bde37 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14fb7>
  1b1e35:	lea    (%rdi,%rbx,1),%rcx
  1b1e39:	cmp    %rsi,%rcx
  1b1e3c:	jae    1bde27 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14fa7>
  1b1e42:	add    %rdx,%rdi
  1b1e45:	cmp    %rsi,%rdi
  1b1e48:	jae    1bde1a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14f9a>
  1b1e4e:	shl    $0x4,%rax
  1b1e52:	shl    $0x4,%rcx
  1b1e56:	shl    $0x4,%rdi
  1b1e5a:	movupd (%r15,%rax,1),%xmm0
  1b1e60:	movupd (%r15,%rcx,1),%xmm1
  1b1e66:	addpd  %xmm0,%xmm1
  1b1e6a:	movupd %xmm1,(%r15,%rdi,1)
  1b1e70:	add    $0x8,%r8
  1b1e74:	cmp    %r8,%rbp
  1b1e77:	jne    1b1e20 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8fa0>
  1b1e79:	mov    0x110(%rsp),%rbx
  1b1e81:	jmp    1b1e88 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9008>
  1b1e83:	imul   $0x37,(%rsp),%rdx
  1b1e88:	xor    %ecx,%ecx
  1b1e8a:	xorpd  %xmm0,%xmm0
  1b1e8e:	xor    %r14d,%r14d
  1b1e91:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b1ea0:	mov    (%r11,%rcx,8),%rdi
  1b1ea4:	lea    (%rdi,%rdx,1),%rax
  1b1ea8:	cmp    0x8(%rsp),%rax
  1b1ead:	jae    1bd74f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x148cf>
  1b1eb3:	shl    $0x4,%rax
  1b1eb7:	movsd  (%r15,%rax,1),%xmm1
  1b1ebd:	ucomisd %xmm0,%xmm1
  1b1ec1:	jne    1b1f00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9080>
  1b1ec3:	jp     1b1f00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9080>
  1b1ec5:	add    %r15,%rax
  1b1ec8:	movsd  0x8(%rax),%xmm1
  1b1ecd:	ucomisd %xmm0,%xmm1
  1b1ed1:	jne    1b1f00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9080>
  1b1ed3:	jp     1b1f00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9080>
  1b1ed5:	cmp    0x1d0(%rsp),%rdi
  1b1edd:	jae    1be1ea <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1536a>
  1b1ee3:	movq   $0x38,(%r10,%rdi,8)
  1b1eeb:	inc    %rcx
  1b1eee:	cmp    %rcx,%r13
  1b1ef1:	jne    1b1ea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9020>
  1b1ef3:	jmp    1b1f18 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9098>
  1b1ef5:	data16 cs nopw 0x0(%rax,%rax,1)
  1b1f00:	cmp    %r9,%r14
  1b1f03:	jae    1bdc2b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14dab>
  1b1f09:	mov    %rdi,(%r11,%r14,8)
  1b1f0d:	inc    %r14
  1b1f10:	inc    %rcx
  1b1f13:	cmp    %rcx,%r13
  1b1f16:	jne    1b1ea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9020>
  1b1f18:	cmp    %r9,%r14
  1b1f1b:	ja     1bd384 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14504>
  1b1f21:	test   %r14,%r14
  1b1f24:	mov    0x1d0(%rsp),%rdx
  1b1f2c:	mov    0x90(%rsp),%rcx
  1b1f34:	je     1b24be <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x963e>
  1b1f3a:	mov    (%r11),%r13
  1b1f3d:	lea    -0x1(%r14),%rax
  1b1f41:	mov    -0x8(%r11,%r14,8),%rcx
  1b1f46:	sub    %r13,%rcx
  1b1f49:	setae  %dl
  1b1f4c:	cmp    %rax,%rcx
  1b1f4f:	sete   %al
  1b1f52:	and    %dl,%al
  1b1f54:	cmp    $0x1,%al
  1b1f56:	jne    1b1f85 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9105>
  1b1f58:	mov    %r13,%rax
  1b1f5b:	add    %r14,%rax
  1b1f5e:	movabs $0x7fffffffffffffff,%rsi
  1b1f68:	mov    0x8(%rsp),%rbx
  1b1f6d:	jb     1bd4c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14640>
  1b1f73:	mov    $0x1,%cl
  1b1f75:	mov    %ecx,0x20(%rsp)
  1b1f79:	mov    %rax,0x30(%rsp)
  1b1f7e:	mov    %r13,0x60(%rsp)
  1b1f83:	jmp    1b1f9c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x911c>
  1b1f85:	movl   $0x0,0x20(%rsp)
  1b1f8d:	movabs $0x7fffffffffffffff,%rsi
  1b1f97:	mov    0x8(%rsp),%rbx
  1b1f9c:	shl    $0x3,%r14
  1b1fa0:	mov    (%rsp),%rax
  1b1fa4:	imul   $0x2c,%rax,%rcx
  1b1fa8:	mov    %rcx,0x10(%rsp)
  1b1fad:	imul   $0x39,%rax,%rax
  1b1fb1:	mov    %rax,0x18(%rsp)
  1b1fb6:	xor    %ebp,%ebp
  1b1fb8:	movapd 0x1fe403f(%rip),%xmm8        # 2196000 <_fini+0x520>
  1b1fc1:	xorpd  %xmm9,%xmm9
  1b1fc6:	movsd  0x1fe56f9(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1b1fcf:	movapd 0x1fe4038(%rip),%xmm11        # 2196010 <_fini+0x530>
  1b1fd8:	movsd  0x1fe56df(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1b1fe1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b1ff0:	mov    (%r11,%rbp,1),%r12
  1b1ff4:	mov    0x10(%rsp),%rax
  1b1ff9:	lea    (%r12,%rax,1),%rdi
  1b1ffd:	cmp    %rbx,%rdi
  1b2000:	jae    1bdb49 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14cc9>
  1b2006:	shl    $0x4,%rdi
  1b200a:	movupd (%r15,%rdi,1),%xmm0
  1b2010:	movapd %xmm0,%xmm2
  1b2014:	andpd  %xmm8,%xmm2
  1b2019:	movapd %xmm0,%xmm1
  1b201d:	unpckhpd %xmm0,%xmm1
  1b2021:	movapd %xmm1,%xmm3
  1b2025:	andpd  %xmm8,%xmm3
  1b202a:	ucomisd %xmm9,%xmm0
  1b202f:	je     1b2090 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9210>
  1b2031:	ucomisd %xmm9,%xmm1
  1b2036:	je     1b2090 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9210>
  1b2038:	movapd %xmm2,%xmm4
  1b203c:	cmplesd %xmm3,%xmm4
  1b2041:	movapd %xmm4,%xmm5
  1b2045:	andpd  %xmm3,%xmm5
  1b2049:	andnpd %xmm2,%xmm4
  1b204d:	orpd   %xmm5,%xmm4
  1b2051:	ucomisd %xmm6,%xmm4
  1b2055:	jbe    1b2090 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9210>
  1b2057:	ucomisd %xmm4,%xmm7
  1b205b:	jbe    1b2090 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9210>
  1b205d:	movapd %xmm0,%xmm2
  1b2061:	mulpd  %xmm0,%xmm2
  1b2065:	movapd %xmm2,%xmm3
  1b2069:	unpckhpd %xmm2,%xmm3
  1b206d:	addsd  %xmm2,%xmm3
  1b2071:	movapd %xmm10,%xmm2
  1b2076:	divsd  %xmm3,%xmm2
  1b207a:	mulsd  %xmm2,%xmm0
  1b207e:	xorpd  %xmm11,%xmm1
  1b2083:	mulsd  %xmm2,%xmm1
  1b2087:	jmp    1b2181 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9301>
  1b208c:	nopl   0x0(%rax)
  1b2090:	ucomisd %xmm9,%xmm1
  1b2095:	setnp  %al
  1b2098:	sete   %cl
  1b209b:	and    %al,%cl
  1b209d:	movq   %xmm0,%rax
  1b20a2:	and    %rsi,%rax
  1b20a5:	movabs $0x7ff0000000000000,%r8
  1b20af:	cmp    %r8,%rax
  1b20b2:	setl   %dl
  1b20b5:	test   %dl,%cl
  1b20b7:	je     1b20d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9250>
  1b20b9:	movapd %xmm10,%xmm2
  1b20be:	divsd  %xmm0,%xmm2
  1b20c2:	xorpd  %xmm11,%xmm1
  1b20c7:	movapd %xmm2,%xmm0
  1b20cb:	jmp    1b2181 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9301>
  1b20d0:	ucomisd %xmm9,%xmm0
  1b20d5:	setnp  %cl
  1b20d8:	sete   %dl
  1b20db:	and    %cl,%dl
  1b20dd:	movq   %xmm1,%rcx
  1b20e2:	and    %rsi,%rcx
  1b20e5:	cmp    %r8,%rcx
  1b20e8:	setl   %sil
  1b20ec:	test   %sil,%dl
  1b20ef:	je     1b2100 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9280>
  1b20f1:	movapd %xmm12,%xmm2
  1b20f6:	divsd  %xmm1,%xmm2
  1b20fa:	movapd %xmm2,%xmm1
  1b20fe:	jmp    1b2177 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x92f7>
  1b2100:	movabs $0x7fefffffffffffff,%rdx
  1b210a:	cmp    %rdx,%rax
  1b210d:	setg   %al
  1b2110:	cmp    %rdx,%rcx
  1b2113:	setg   %cl
  1b2116:	or     %al,%cl
  1b2118:	cmp    $0x1,%cl
  1b211b:	jne    1b21b2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9332>
  1b2121:	add    %r15,%rdi
  1b2124:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1b2129:	movsd  0x1fe558e(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1b2132:	movapd 0x1fe3ed5(%rip),%xmm11        # 2196010 <_fini+0x530>
  1b213b:	movsd  0x1fe5584(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1b2144:	xorpd  %xmm9,%xmm9
  1b2149:	movapd 0x1fe3eae(%rip),%xmm8        # 2196000 <_fini+0x520>
  1b2152:	movsd  0x1fe555e(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b215a:	movsd  0x1fe554e(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b2162:	mov    0x1c8(%rsp),%r10
  1b216a:	mov    0x28(%rsp),%r11
  1b216f:	mov    0x1b0(%rsp),%r9
  1b2177:	movabs $0x7fffffffffffffff,%rsi
  1b2181:	add    0x18(%rsp),%r12
  1b2186:	cmp    %rbx,%r12
  1b2189:	jae    1bdb36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14cb6>
  1b218f:	shl    $0x4,%r12
  1b2193:	movsd  %xmm0,(%r15,%r12,1)
  1b2199:	movsd  %xmm1,0x8(%r15,%r12,1)
  1b21a0:	add    $0x8,%rbp
  1b21a4:	cmp    %rbp,%r14
  1b21a7:	jne    1b1ff0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9170>
  1b21ad:	jmp    1b223c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x93bc>
  1b21b2:	ucomisd %xmm9,%xmm1
  1b21b7:	movabs $0x7fffffffffffffff,%rsi
  1b21c1:	jne    1b21c9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9349>
  1b21c3:	jnp    1b20b9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9239>
  1b21c9:	ucomisd %xmm9,%xmm0
  1b21ce:	jne    1b21e1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9361>
  1b21d0:	jp     1b21e1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9361>
  1b21d2:	movapd %xmm12,%xmm2
  1b21d7:	divsd  %xmm1,%xmm2
  1b21db:	movapd %xmm2,%xmm1
  1b21df:	jmp    1b2181 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9301>
  1b21e1:	movapd %xmm3,%xmm1
  1b21e5:	cmplesd %xmm2,%xmm1
  1b21ea:	movapd %xmm1,%xmm4
  1b21ee:	andpd  %xmm2,%xmm4
  1b21f2:	andnpd %xmm3,%xmm1
  1b21f6:	orpd   %xmm4,%xmm1
  1b21fa:	unpcklpd %xmm1,%xmm1
  1b21fe:	divpd  %xmm1,%xmm0
  1b2202:	movapd %xmm0,%xmm2
  1b2206:	xorpd  %xmm11,%xmm2
  1b220b:	movsd  %xmm0,%xmm2
  1b220f:	mulpd  %xmm0,%xmm0
  1b2213:	movapd %xmm0,%xmm3
  1b2217:	unpcklpd %xmm0,%xmm3
  1b221b:	unpckhpd %xmm0,%xmm0
  1b221f:	addpd  %xmm3,%xmm0
  1b2223:	divpd  %xmm0,%xmm2
  1b2227:	divpd  %xmm1,%xmm2
  1b222b:	movapd %xmm2,%xmm0
  1b222f:	movapd %xmm2,%xmm1
  1b2233:	unpckhpd %xmm2,%xmm1
  1b2237:	jmp    1b2181 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9301>
  1b223c:	cmpb   $0x0,0x20(%rsp)
  1b2241:	je     1b23ac <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x952c>
  1b2247:	mov    0x60(%rsp),%r13
  1b224c:	cmp    0x30(%rsp),%r13
  1b2251:	jae    1b2482 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9602>
  1b2257:	cmpq   $0x0,0x1e0(%rsp)
  1b2260:	je     1bf211 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16391>
  1b2266:	mov    (%rsp),%rdi
  1b226a:	imul   $0x3a,%rdi,%rax
  1b226e:	mov    %r13,%r8
  1b2271:	not    %r8
  1b2274:	add    0x30(%rsp),%r8
  1b2279:	mov    0x18(%rsp),%rcx
  1b227e:	lea    (%rcx,%r13,1),%r11
  1b2282:	xor    %edx,%edx
  1b2284:	mov    %rbx,%rcx
  1b2287:	sub    %r11,%rcx
  1b228a:	cmovb  %rdx,%rcx
  1b228e:	lea    (%rax,%r13,1),%r12
  1b2292:	mov    %rbx,%rsi
  1b2295:	sub    %r12,%rsi
  1b2298:	cmovb  %rdx,%rsi
  1b229c:	cmp    %rsi,%rcx
  1b229f:	cmovb  %rcx,%rsi
  1b22a3:	add    %rdi,%r13
  1b22a6:	mov    %rbx,%rcx
  1b22a9:	sub    %r13,%rcx
  1b22ac:	cmovb  %rdx,%rcx
  1b22b0:	cmp    %rcx,%rsi
  1b22b3:	cmovb  %rsi,%rcx
  1b22b7:	cmp    %rcx,%r8
  1b22ba:	cmovb  %r8,%rcx
  1b22be:	cmp    $0x1f,%rcx
  1b22c2:	ja     1b3e04 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xaf84>
  1b22c8:	mov    0x1d8(%rsp),%r12
  1b22d0:	mov    0x28(%rsp),%r11
  1b22d5:	mov    0x60(%rsp),%r13
  1b22da:	mov    (%rsp),%r8
  1b22de:	imul   $0x3a0,%r8,%rcx
  1b22e5:	add    %r15,%rcx
  1b22e8:	mov    %r13,%rdx
  1b22eb:	shl    $0x4,%rdx
  1b22ef:	imul   $0x390,%r8,%rsi
  1b22f6:	add    %r15,%rsi
  1b22f9:	shl    $0x4,%r8
  1b22fd:	add    %r15,%r8
  1b2300:	mov    (%rsp),%rdi
  1b2304:	add    %r13,%rdi
  1b2307:	cmp    %rbx,%rdi
  1b230a:	jae    1bf22e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163ae>
  1b2310:	mov    0x18(%rsp),%rdi
  1b2315:	add    %r13,%rdi
  1b2318:	cmp    %rbx,%rdi
  1b231b:	jae    1bec57 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15dd7>
  1b2321:	lea    (%rax,%r13,1),%rdi
  1b2325:	cmp    %rbx,%rdi
  1b2328:	jae    1bec47 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15dc7>
  1b232e:	inc    %r13
  1b2331:	movupd (%r8,%rdx,1),%xmm0
  1b2337:	movupd (%r12),%xmm1
  1b233d:	movapd %xmm0,%xmm2
  1b2341:	mulpd  %xmm1,%xmm2
  1b2345:	movupd (%rsi,%rdx,1),%xmm3
  1b234a:	movapd %xmm2,%xmm4
  1b234e:	unpcklpd %xmm2,%xmm4
  1b2352:	unpckhpd %xmm2,%xmm2
  1b2356:	subpd  %xmm2,%xmm4
  1b235a:	mulpd  %xmm3,%xmm4
  1b235e:	movapd %xmm1,%xmm2
  1b2362:	unpckhpd %xmm1,%xmm2
  1b2366:	mulsd  %xmm0,%xmm2
  1b236a:	unpckhpd %xmm0,%xmm0
  1b236e:	mulsd  %xmm1,%xmm0
  1b2372:	addsd  %xmm2,%xmm0
  1b2376:	unpcklpd %xmm0,%xmm0
  1b237a:	shufpd $0x1,%xmm3,%xmm3
  1b237f:	mulpd  %xmm0,%xmm3
  1b2383:	movapd %xmm4,%xmm0
  1b2387:	subpd  %xmm3,%xmm0
  1b238b:	addpd  %xmm4,%xmm3
  1b238f:	movsd  %xmm0,%xmm3
  1b2393:	movupd %xmm3,(%rcx,%rdx,1)
  1b2398:	add    $0x10,%rdx
  1b239c:	cmp    %r13,0x30(%rsp)
  1b23a1:	jne    1b2300 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9480>
  1b23a7:	jmp    1b2482 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9602>
  1b23ac:	cmpq   $0x0,0x1e0(%rsp)
  1b23b5:	mov    0x1d8(%rsp),%rsi
  1b23bd:	je     1bf134 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x162b4>
  1b23c3:	imul   $0x3a,(%rsp),%rcx
  1b23c8:	xor    %edx,%edx
  1b23ca:	nopw   0x0(%rax,%rax,1)
  1b23d0:	mov    (%r11,%rdx,1),%rdi
  1b23d4:	mov    (%rsp),%rax
  1b23d8:	lea    (%rdi,%rax,1),%r13
  1b23dc:	cmp    %rbx,%r13
  1b23df:	jae    1bf141 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x162c1>
  1b23e5:	mov    0x18(%rsp),%rax
  1b23ea:	add    %rdi,%rax
  1b23ed:	cmp    %rbx,%rax
  1b23f0:	jae    1be3fb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1557b>
  1b23f6:	add    %rcx,%rdi
  1b23f9:	cmp    %rbx,%rdi
  1b23fc:	jae    1be3eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1556b>
  1b2402:	shl    $0x4,%r13
  1b2406:	shl    $0x4,%rax
  1b240a:	movupd (%r15,%r13,1),%xmm0
  1b2410:	movupd (%rsi),%xmm1
  1b2414:	movapd %xmm0,%xmm2
  1b2418:	mulpd  %xmm1,%xmm2
  1b241c:	shl    $0x4,%rdi
  1b2420:	movupd (%r15,%rax,1),%xmm3
  1b2426:	movapd %xmm2,%xmm4
  1b242a:	unpcklpd %xmm2,%xmm4
  1b242e:	unpckhpd %xmm2,%xmm2
  1b2432:	subpd  %xmm2,%xmm4
  1b2436:	mulpd  %xmm3,%xmm4
  1b243a:	movapd %xmm1,%xmm2
  1b243e:	unpckhpd %xmm1,%xmm2
  1b2442:	mulsd  %xmm0,%xmm2
  1b2446:	unpckhpd %xmm0,%xmm0
  1b244a:	mulsd  %xmm1,%xmm0
  1b244e:	addsd  %xmm2,%xmm0
  1b2452:	unpcklpd %xmm0,%xmm0
  1b2456:	shufpd $0x1,%xmm3,%xmm3
  1b245b:	mulpd  %xmm0,%xmm3
  1b245f:	movapd %xmm4,%xmm0
  1b2463:	subpd  %xmm3,%xmm0
  1b2467:	addpd  %xmm4,%xmm3
  1b246b:	movsd  %xmm0,%xmm3
  1b246f:	movupd %xmm3,(%r15,%rdi,1)
  1b2475:	add    $0x8,%rdx
  1b2479:	cmp    %rdx,%r14
  1b247c:	jne    1b23d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9550>
  1b2482:	xor    %eax,%eax
  1b2484:	mov    0x1d0(%rsp),%rdx
  1b248c:	mov    0x90(%rsp),%rcx
  1b2494:	mov    0x110(%rsp),%rbx
  1b249c:	nopl   0x0(%rax)
  1b24a0:	mov    (%r11,%rax,1),%rdi
  1b24a4:	cmp    %rdx,%rdi
  1b24a7:	jae    1bdb59 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14cd9>
  1b24ad:	movq   $0x3b,(%r10,%rdi,8)
  1b24b5:	add    $0x8,%rax
  1b24b9:	cmp    %rax,%r14
  1b24bc:	jne    1b24a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9620>
  1b24be:	xor    %eax,%eax
  1b24c0:	xor    %r14d,%r14d
  1b24c3:	jmp    1b24e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9660>
  1b24c5:	data16 cs nopw 0x0(%rax,%rax,1)
  1b24d0:	mov    %rdi,(%r11,%r14,8)
  1b24d4:	inc    %r14
  1b24d7:	add    $0x8,%rax
  1b24db:	cmp    %rax,%rcx
  1b24de:	je     1b250c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x968c>
  1b24e0:	mov    (%rbx,%rax,1),%rdi
  1b24e4:	cmp    %rdx,%rdi
  1b24e7:	jae    1bd56a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x146ea>
  1b24ed:	cmpq   $0x39,(%r10,%rdi,8)
  1b24f2:	jae    1b24d7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9657>
  1b24f4:	cmp    %r9,%r14
  1b24f7:	jb     1b24d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9650>
  1b24f9:	lea    0x246fd20(%rip),%rdx        # 2622220 <__gmpfr_one+0xaaa0>
  1b2500:	mov    %r14,%rdi
  1b2503:	mov    %r9,%rsi
  1b2506:	call   *0x251c9f4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1b250c:	cmp    %r9,%r14
  1b250f:	ja     1b5b63 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcce3>
  1b2515:	test   %r14,%r14
  1b2518:	je     1b2550 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x96d0>
  1b251a:	mov    (%r11),%rsi
  1b251d:	lea    -0x1(%r14),%rax
  1b2521:	mov    -0x8(%r11,%r14,8),%rcx
  1b2526:	sub    %rsi,%rcx
  1b2529:	setae  %dl
  1b252c:	cmp    %rax,%rcx
  1b252f:	sete   %al
  1b2532:	and    %dl,%al
  1b2534:	cmp    $0x1,%al
  1b2536:	jne    1b2561 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x96e1>
  1b2538:	mov    %rsi,0x60(%rsp)
  1b253d:	add    %r14,%rsi
  1b2540:	jb     1b2561 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x96e1>
  1b2542:	mov    %rsi,0x30(%rsp)
  1b2547:	mov    $0x1,%al
  1b2549:	mov    %rax,0x10(%rsp)
  1b254e:	jmp    1b257c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x96fc>
  1b2550:	movq   $0x0,0x30(%rsp)
  1b2559:	xor    %r14d,%r14d
  1b255c:	jmp    1b2b71 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9cf1>
  1b2561:	movq   $0x0,0x30(%rsp)
  1b256a:	movq   $0x0,0x60(%rsp)
  1b2573:	movq   $0x0,0x10(%rsp)
  1b257c:	mov    0x1d0(%rsp),%rdx
  1b2584:	mov    0x90(%rsp),%rcx
  1b258c:	shl    $0x3,%r14
  1b2590:	imul   $0x3d,(%rsp),%r13
  1b2595:	xor    %ebp,%ebp
  1b2597:	movapd 0x1fe3a61(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b259f:	xorpd  %xmm7,%xmm7
  1b25a3:	movsd  0x1fe5104(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b25ac:	movsd  0x1fe5103(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b25b5:	movsd  0x1fe510a(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1b25be:	movapd 0x1fe3a49(%rip),%xmm11        # 2196010 <_fini+0x530>
  1b25c7:	movsd  0x1fe50f0(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1b25d0:	mov    %r13,0x18(%rsp)
  1b25d5:	data16 cs nopw 0x0(%rax,%rax,1)
  1b25e0:	mov    (%r11,%rbp,1),%r12
  1b25e4:	cmp    0x8(%rsp),%r12
  1b25e9:	jae    1bd779 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x148f9>
  1b25ef:	mov    %r12,%rdi
  1b25f2:	shl    $0x4,%rdi
  1b25f6:	movupd (%r15,%rdi,1),%xmm0
  1b25fc:	movapd %xmm0,%xmm2
  1b2600:	andpd  %xmm6,%xmm2
  1b2604:	movapd %xmm0,%xmm1
  1b2608:	unpckhpd %xmm0,%xmm1
  1b260c:	movapd %xmm1,%xmm3
  1b2610:	andpd  %xmm6,%xmm3
  1b2614:	ucomisd %xmm7,%xmm0
  1b2618:	je     1b2680 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9800>
  1b261a:	ucomisd %xmm7,%xmm1
  1b261e:	je     1b2680 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9800>
  1b2620:	movapd %xmm2,%xmm4
  1b2624:	cmplesd %xmm3,%xmm4
  1b2629:	movapd %xmm4,%xmm5
  1b262d:	andpd  %xmm3,%xmm5
  1b2631:	andnpd %xmm2,%xmm4
  1b2635:	orpd   %xmm5,%xmm4
  1b2639:	ucomisd %xmm8,%xmm4
  1b263e:	jbe    1b2680 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9800>
  1b2640:	ucomisd %xmm4,%xmm9
  1b2645:	jbe    1b2680 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9800>
  1b2647:	movapd %xmm0,%xmm2
  1b264b:	mulpd  %xmm0,%xmm2
  1b264f:	movapd %xmm2,%xmm3
  1b2653:	unpckhpd %xmm2,%xmm3
  1b2657:	addsd  %xmm2,%xmm3
  1b265b:	movapd %xmm10,%xmm2
  1b2660:	divsd  %xmm3,%xmm2
  1b2664:	mulsd  %xmm2,%xmm0
  1b2668:	xorpd  %xmm11,%xmm1
  1b266d:	mulsd  %xmm2,%xmm1
  1b2671:	jmp    1b272a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x98aa>
  1b2676:	cs nopw 0x0(%rax,%rax,1)
  1b2680:	ucomisd %xmm7,%xmm1
  1b2684:	setnp  %al
  1b2687:	sete   %cl
  1b268a:	and    %al,%cl
  1b268c:	movq   %xmm0,%rax
  1b2691:	movabs $0x7fffffffffffffff,%r8
  1b269b:	and    %r8,%rax
  1b269e:	movabs $0x7ff0000000000000,%r13
  1b26a8:	cmp    %r13,%rax
  1b26ab:	setl   %dl
  1b26ae:	test   %dl,%cl
  1b26b0:	je     1b26e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9860>
  1b26b2:	movapd %xmm10,%xmm2
  1b26b7:	divsd  %xmm0,%xmm2
  1b26bb:	xorpd  %xmm11,%xmm1
  1b26c0:	movapd %xmm2,%xmm0
  1b26c4:	mov    0x1d0(%rsp),%rdx
  1b26cc:	mov    0x90(%rsp),%rcx
  1b26d4:	jmp    1b2725 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x98a5>
  1b26d6:	cs nopw 0x0(%rax,%rax,1)
  1b26e0:	ucomisd %xmm7,%xmm0
  1b26e4:	setnp  %cl
  1b26e7:	sete   %dl
  1b26ea:	and    %cl,%dl
  1b26ec:	movq   %xmm1,%rcx
  1b26f1:	and    %r8,%rcx
  1b26f4:	cmp    %r13,%rcx
  1b26f7:	setl   %sil
  1b26fb:	test   %sil,%dl
  1b26fe:	je     1b275b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x98db>
  1b2700:	movapd %xmm12,%xmm2
  1b2705:	divsd  %xmm1,%xmm2
  1b2709:	movapd %xmm2,%xmm1
  1b270d:	mov    0x1d0(%rsp),%rdx
  1b2715:	mov    0x90(%rsp),%rcx
  1b271d:	mov    0x110(%rsp),%rbx
  1b2725:	mov    0x18(%rsp),%r13
  1b272a:	add    %r13,%r12
  1b272d:	cmp    0x8(%rsp),%r12
  1b2732:	jae    1bd764 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x148e4>
  1b2738:	shl    $0x4,%r12
  1b273c:	movsd  %xmm0,(%r15,%r12,1)
  1b2742:	movsd  %xmm1,0x8(%r15,%r12,1)
  1b2749:	add    $0x8,%rbp
  1b274d:	cmp    %rbp,%r14
  1b2750:	jne    1b25e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9760>
  1b2756:	jmp    1b28a4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9a24>
  1b275b:	movabs $0x7fefffffffffffff,%rdx
  1b2765:	cmp    %rdx,%rax
  1b2768:	setg   %al
  1b276b:	cmp    %rdx,%rcx
  1b276e:	setg   %cl
  1b2771:	or     %al,%cl
  1b2773:	cmp    $0x1,%cl
  1b2776:	mov    0x18(%rsp),%r13
  1b277b:	jne    1b27f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9970>
  1b277d:	add    %r15,%rdi
  1b2780:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1b2785:	movsd  0x1fe4f32(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1b278e:	movapd 0x1fe3879(%rip),%xmm11        # 2196010 <_fini+0x530>
  1b2797:	movsd  0x1fe4f28(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1b27a0:	movsd  0x1fe4f0f(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b27a9:	movsd  0x1fe4efe(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b27b2:	xorpd  %xmm7,%xmm7
  1b27b6:	movapd 0x1fe3842(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b27be:	mov    0x1c8(%rsp),%r10
  1b27c6:	mov    0x28(%rsp),%r11
  1b27cb:	mov    0x1b0(%rsp),%r9
  1b27d3:	mov    0x1d0(%rsp),%rdx
  1b27db:	mov    0x90(%rsp),%rcx
  1b27e3:	mov    0x110(%rsp),%rbx
  1b27eb:	jmp    1b272a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x98aa>
  1b27f0:	ucomisd %xmm7,%xmm1
  1b27f4:	mov    0x1d0(%rsp),%rdx
  1b27fc:	mov    0x110(%rsp),%rbx
  1b2804:	jne    1b2827 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x99a7>
  1b2806:	jp     1b2827 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x99a7>
  1b2808:	movapd %xmm10,%xmm2
  1b280d:	divsd  %xmm0,%xmm2
  1b2811:	xorpd  %xmm11,%xmm1
  1b2816:	movapd %xmm2,%xmm0
  1b281a:	mov    0x90(%rsp),%rcx
  1b2822:	jmp    1b272a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x98aa>
  1b2827:	ucomisd %xmm7,%xmm0
  1b282b:	mov    0x90(%rsp),%rcx
  1b2833:	jne    1b2849 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x99c9>
  1b2835:	jp     1b2849 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x99c9>
  1b2837:	movapd %xmm12,%xmm2
  1b283c:	divsd  %xmm1,%xmm2
  1b2840:	movapd %xmm2,%xmm1
  1b2844:	jmp    1b272a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x98aa>
  1b2849:	movapd %xmm3,%xmm1
  1b284d:	cmplesd %xmm2,%xmm1
  1b2852:	movapd %xmm1,%xmm4
  1b2856:	andpd  %xmm2,%xmm4
  1b285a:	andnpd %xmm3,%xmm1
  1b285e:	orpd   %xmm4,%xmm1
  1b2862:	unpcklpd %xmm1,%xmm1
  1b2866:	divpd  %xmm1,%xmm0
  1b286a:	movapd %xmm0,%xmm2
  1b286e:	xorpd  %xmm11,%xmm2
  1b2873:	movsd  %xmm0,%xmm2
  1b2877:	mulpd  %xmm0,%xmm0
  1b287b:	movapd %xmm0,%xmm3
  1b287f:	unpcklpd %xmm0,%xmm3
  1b2883:	unpckhpd %xmm0,%xmm0
  1b2887:	addpd  %xmm3,%xmm0
  1b288b:	divpd  %xmm0,%xmm2
  1b288f:	divpd  %xmm1,%xmm2
  1b2893:	movapd %xmm2,%xmm0
  1b2897:	movapd %xmm2,%xmm1
  1b289b:	unpckhpd %xmm2,%xmm1
  1b289f:	jmp    1b272a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x98aa>
  1b28a4:	cmpb   $0x0,0x10(%rsp)
  1b28a9:	je     1b2a61 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9be1>
  1b28af:	mov    0x60(%rsp),%r14
  1b28b4:	cmp    0x30(%rsp),%r14
  1b28b9:	jae    1b2b71 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9cf1>
  1b28bf:	cmpq   $0x5,0x1e0(%rsp)
  1b28c8:	jb     1bf051 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161d1>
  1b28ce:	mov    (%rsp),%rcx
  1b28d2:	imul   $0x2a,%rcx,%rax
  1b28d6:	lea    (%rcx,%rcx,1),%rdx
  1b28da:	shl    $0x6,%rcx
  1b28de:	sub    %rdx,%rcx
  1b28e1:	lea    (%r14,%rax,1),%rdi
  1b28e5:	xor    %r8d,%r8d
  1b28e8:	mov    0x8(%rsp),%rsi
  1b28ed:	mov    %rsi,%rdx
  1b28f0:	mov    %rdi,0x10(%rsp)
  1b28f5:	sub    %rdi,%rdx
  1b28f8:	cmovb  %r8,%rdx
  1b28fc:	lea    (%r14,%r13,1),%r12
  1b2900:	mov    %rsi,%rdi
  1b2903:	sub    %r12,%rdi
  1b2906:	cmovb  %r8,%rdi
  1b290a:	cmp    %rdi,%rdx
  1b290d:	cmovb  %rdx,%rdi
  1b2911:	lea    (%r14,%rcx,1),%rbp
  1b2915:	mov    %rsi,%rdx
  1b2918:	sub    %rbp,%rdx
  1b291b:	cmovb  %r8,%rdx
  1b291f:	cmp    %rdx,%rdi
  1b2922:	cmovb  %rdi,%rdx
  1b2926:	mov    %r14,%rbx
  1b2929:	not    %r14
  1b292c:	add    0x30(%rsp),%r14
  1b2931:	cmp    %r14,%rdx
  1b2934:	cmovae %r14,%rdx
  1b2938:	lea    0x1(%rdx),%rdi
  1b293c:	mov    %rbx,%r10
  1b293f:	cmp    $0x22,%rdi
  1b2943:	ja     1b3674 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa7f4>
  1b2949:	mov    (%rsp),%r9
  1b294d:	imul   $0x3e0,%r9,%rdx
  1b2954:	mov    %rbx,%r14
  1b2957:	mov    %r10,%rbx
  1b295a:	shl    $0x4,%rbx
  1b295e:	add    %r15,%rbx
  1b2961:	imul   $0x3d0,%r9,%r8
  1b2968:	imul   $0x2a0,%r9,%r9
  1b296f:	mov    0x1d8(%rsp),%r11
  1b2977:	mov    0x30(%rsp),%r12
  1b297c:	mov    0x18(%rsp),%r13
  1b2981:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b2990:	lea    (%rax,%r10,1),%rdi
  1b2994:	cmp    %rsi,%rdi
  1b2997:	jae    1be60f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1578f>
  1b299d:	lea    (%r10,%r13,1),%rdi
  1b29a1:	cmp    %rsi,%rdi
  1b29a4:	jae    1be602 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15782>
  1b29aa:	lea    (%rcx,%r10,1),%rdi
  1b29ae:	cmp    %rsi,%rdi
  1b29b1:	jae    1be5f5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15775>
  1b29b7:	inc    %r10
  1b29ba:	movupd 0x40(%r11),%xmm0
  1b29c0:	movupd (%rbx,%r9,1),%xmm1
  1b29c6:	movapd %xmm0,%xmm2
  1b29ca:	mulpd  %xmm1,%xmm2
  1b29ce:	movupd (%rbx,%r8,1),%xmm3
  1b29d4:	movapd %xmm2,%xmm4
  1b29d8:	unpcklpd %xmm2,%xmm4
  1b29dc:	unpckhpd %xmm2,%xmm2
  1b29e0:	subpd  %xmm2,%xmm4
  1b29e4:	mulpd  %xmm3,%xmm4
  1b29e8:	movapd %xmm1,%xmm2
  1b29ec:	unpckhpd %xmm1,%xmm2
  1b29f0:	mulsd  %xmm0,%xmm2
  1b29f4:	unpckhpd %xmm0,%xmm0
  1b29f8:	mulsd  %xmm1,%xmm0
  1b29fc:	addsd  %xmm2,%xmm0
  1b2a00:	unpcklpd %xmm0,%xmm0
  1b2a04:	shufpd $0x1,%xmm3,%xmm3
  1b2a09:	mulpd  %xmm0,%xmm3
  1b2a0d:	movapd %xmm4,%xmm0
  1b2a11:	subpd  %xmm3,%xmm0
  1b2a15:	addpd  %xmm4,%xmm3
  1b2a19:	movsd  %xmm0,%xmm3
  1b2a1d:	movupd %xmm3,(%rbx,%rdx,1)
  1b2a22:	add    $0x10,%rbx
  1b2a26:	cmp    %r10,%r12
  1b2a29:	jne    1b2990 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9b10>
  1b2a2f:	mov    0x1b0(%rsp),%r9
  1b2a37:	mov    0x28(%rsp),%r11
  1b2a3c:	mov    0x1d0(%rsp),%rdx
  1b2a44:	mov    0x90(%rsp),%rcx
  1b2a4c:	mov    0x110(%rsp),%rbx
  1b2a54:	mov    0x1c8(%rsp),%r10
  1b2a5c:	jmp    1b2b71 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9cf1>
  1b2a61:	cmpq   $0x5,0x1e0(%rsp)
  1b2a6a:	mov    0x8(%rsp),%rsi
  1b2a6f:	jb     1bf051 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161d1>
  1b2a75:	mov    (%rsp),%rbx
  1b2a79:	imul   $0x2a,%rbx,%rdx
  1b2a7d:	lea    (%rbx,%rbx,1),%rax
  1b2a81:	shl    $0x6,%rbx
  1b2a85:	sub    %rax,%rbx
  1b2a88:	xor    %r8d,%r8d
  1b2a8b:	mov    0x1d8(%rsp),%r9
  1b2a93:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b2aa0:	mov    (%r11,%r8,1),%rdi
  1b2aa4:	lea    (%rdi,%rdx,1),%rax
  1b2aa8:	cmp    %rsi,%rax
  1b2aab:	jae    1bde64 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14fe4>
  1b2ab1:	lea    (%rdi,%r13,1),%rcx
  1b2ab5:	cmp    %rsi,%rcx
  1b2ab8:	jae    1bde54 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14fd4>
  1b2abe:	add    %rbx,%rdi
  1b2ac1:	cmp    %rsi,%rdi
  1b2ac4:	jae    1bde47 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14fc7>
  1b2aca:	shl    $0x4,%rax
  1b2ace:	shl    $0x4,%rcx
  1b2ad2:	movupd 0x40(%r9),%xmm0
  1b2ad8:	movupd (%r15,%rax,1),%xmm1
  1b2ade:	movapd %xmm0,%xmm2
  1b2ae2:	mulpd  %xmm1,%xmm2
  1b2ae6:	shl    $0x4,%rdi
  1b2aea:	movupd (%r15,%rcx,1),%xmm3
  1b2af0:	movapd %xmm2,%xmm4
  1b2af4:	unpcklpd %xmm2,%xmm4
  1b2af8:	unpckhpd %xmm2,%xmm2
  1b2afc:	subpd  %xmm2,%xmm4
  1b2b00:	mulpd  %xmm3,%xmm4
  1b2b04:	movapd %xmm0,%xmm2
  1b2b08:	unpckhpd %xmm0,%xmm2
  1b2b0c:	mulsd  %xmm1,%xmm2
  1b2b10:	unpckhpd %xmm1,%xmm1
  1b2b14:	mulsd  %xmm0,%xmm1
  1b2b18:	addsd  %xmm2,%xmm1
  1b2b1c:	unpcklpd %xmm1,%xmm1
  1b2b20:	shufpd $0x1,%xmm3,%xmm3
  1b2b25:	mulpd  %xmm1,%xmm3
  1b2b29:	movapd %xmm4,%xmm0
  1b2b2d:	subpd  %xmm3,%xmm0
  1b2b31:	addpd  %xmm4,%xmm3
  1b2b35:	movsd  %xmm0,%xmm3
  1b2b39:	movupd %xmm3,(%r15,%rdi,1)
  1b2b3f:	add    $0x8,%r8
  1b2b43:	cmp    %r8,%r14
  1b2b46:	jne    1b2aa0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9c20>
  1b2b4c:	mov    0x1b0(%rsp),%r9
  1b2b54:	mov    0x1d0(%rsp),%rdx
  1b2b5c:	mov    0x90(%rsp),%rcx
  1b2b64:	mov    0x110(%rsp),%rbx
  1b2b6c:	mov    0x60(%rsp),%r14
  1b2b71:	xor    %eax,%eax
  1b2b73:	xor    %r12d,%r12d
  1b2b76:	jmp    1b2b90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9d10>
  1b2b78:	nopl   0x0(%rax,%rax,1)
  1b2b80:	mov    %rdi,(%r11,%r12,8)
  1b2b84:	inc    %r12
  1b2b87:	add    $0x8,%rax
  1b2b8b:	cmp    %rax,%rcx
  1b2b8e:	je     1b2bbc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9d3c>
  1b2b90:	mov    (%rbx,%rax,1),%rdi
  1b2b94:	cmp    %rdx,%rdi
  1b2b97:	jae    1bd57a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x146fa>
  1b2b9d:	cmpq   $0x3c,(%r10,%rdi,8)
  1b2ba2:	jae    1b2b87 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9d07>
  1b2ba4:	cmp    %r9,%r12
  1b2ba7:	jb     1b2b80 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9d00>
  1b2ba9:	lea    0x246f760(%rip),%rdx        # 2622310 <__gmpfr_one+0xab90>
  1b2bb0:	mov    %r12,%rdi
  1b2bb3:	mov    %r9,%rsi
  1b2bb6:	call   *0x251c344(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1b2bbc:	cmp    %r9,%r12
  1b2bbf:	ja     1b5b78 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xccf8>
  1b2bc5:	test   %r12,%r12
  1b2bc8:	mov    0x8(%rsp),%rbx
  1b2bcd:	je     1b430e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb48e>
  1b2bd3:	mov    (%r11),%rax
  1b2bd6:	lea    -0x1(%r12),%rcx
  1b2bdb:	mov    -0x8(%r11,%r12,8),%rdx
  1b2be0:	sub    %rax,%rdx
  1b2be3:	setae  %sil
  1b2be7:	cmp    %rcx,%rdx
  1b2bea:	sete   %cl
  1b2bed:	and    %sil,%cl
  1b2bf0:	cmp    $0x1,%cl
  1b2bf3:	jne    1b2c0f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9d8f>
  1b2bf5:	mov    %rax,%rcx
  1b2bf8:	add    %r12,%rcx
  1b2bfb:	jb     1b2c0f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9d8f>
  1b2bfd:	mov    $0x1,%dl
  1b2bff:	mov    %edx,0x20(%rsp)
  1b2c03:	mov    %rcx,0x30(%rsp)
  1b2c08:	mov    %rax,0x60(%rsp)
  1b2c0d:	jmp    1b2c1c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9d9c>
  1b2c0f:	mov    %r14,0x60(%rsp)
  1b2c14:	movl   $0x0,0x20(%rsp)
  1b2c1c:	lea    0x0(,%r12,8),%r13
  1b2c24:	imul   $0x37,(%rsp),%r14
  1b2c29:	xor    %ebp,%ebp
  1b2c2b:	xorpd  %xmm1,%xmm1
  1b2c2f:	jmp    1b2c79 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9df9>
  1b2c31:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b2c40:	mov    $0x40,%r8d
  1b2c46:	mov    %r15,%rdi
  1b2c49:	mov    %rbx,%rsi
  1b2c4c:	mov    (%rsp),%rdx
  1b2c50:	call   1a8d70 <oneloop::native::batch::copy_active_column::<f64>>
  1b2c55:	add    $0x8,%rbp
  1b2c59:	cmp    %rbp,%r13
  1b2c5c:	mov    0x28(%rsp),%r11
  1b2c61:	mov    0x1c8(%rsp),%r10
  1b2c69:	movabs $0x7fffffffffffffff,%rsi
  1b2c73:	xorpd  %xmm1,%xmm1
  1b2c77:	je     1b2cba <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9e3a>
  1b2c79:	mov    (%r11,%rbp,1),%rcx
  1b2c7d:	lea    (%rcx,%r14,1),%rdi
  1b2c81:	cmp    %rbx,%rdi
  1b2c84:	jae    1bd78e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1490e>
  1b2c8a:	shl    $0x4,%rdi
  1b2c8e:	movsd  (%r15,%rdi,1),%xmm0
  1b2c94:	mov    $0x3a,%r9d
  1b2c9a:	ucomisd %xmm1,%xmm0
  1b2c9e:	jne    1b2c40 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9dc0>
  1b2ca0:	jp     1b2c40 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9dc0>
  1b2ca2:	add    %r15,%rdi
  1b2ca5:	movsd  0x8(%rdi),%xmm0
  1b2caa:	ucomisd %xmm1,%xmm0
  1b2cae:	jne    1b2c40 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9dc0>
  1b2cb0:	jp     1b2c40 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9dc0>
  1b2cb2:	mov    $0x3e,%r9d
  1b2cb8:	jmp    1b2c40 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9dc0>
  1b2cba:	mov    (%rsp),%rax
  1b2cbe:	mov    %rax,%rcx
  1b2cc1:	shl    $0x6,%rcx
  1b2cc5:	mov    %rcx,0x10(%rsp)
  1b2cca:	add    %rcx,%rax
  1b2ccd:	mov    %rax,0x18(%rsp)
  1b2cd2:	xor    %ebp,%ebp
  1b2cd4:	movapd 0x1fe3324(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b2cdc:	xorpd  %xmm7,%xmm7
  1b2ce0:	movsd  0x1fe49c7(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b2ce9:	movsd  0x1fe49c6(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b2cf2:	movsd  0x1fe49cd(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1b2cfb:	movapd 0x1fe330c(%rip),%xmm11        # 2196010 <_fini+0x530>
  1b2d04:	movsd  0x1fe49b3(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1b2d0d:	mov    0x1b0(%rsp),%r9
  1b2d15:	data16 cs nopw 0x0(%rax,%rax,1)
  1b2d20:	mov    (%r11,%rbp,1),%r14
  1b2d24:	mov    0x10(%rsp),%rax
  1b2d29:	lea    (%r14,%rax,1),%rdi
  1b2d2d:	cmp    %rbx,%rdi
  1b2d30:	jae    1bd7b1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14931>
  1b2d36:	shl    $0x4,%rdi
  1b2d3a:	movupd (%r15,%rdi,1),%xmm0
  1b2d40:	movapd %xmm0,%xmm2
  1b2d44:	andpd  %xmm6,%xmm2
  1b2d48:	movapd %xmm0,%xmm1
  1b2d4c:	unpckhpd %xmm0,%xmm1
  1b2d50:	movapd %xmm1,%xmm3
  1b2d54:	andpd  %xmm6,%xmm3
  1b2d58:	ucomisd %xmm7,%xmm0
  1b2d5c:	je     1b2dc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9f40>
  1b2d5e:	ucomisd %xmm7,%xmm1
  1b2d62:	je     1b2dc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9f40>
  1b2d64:	movapd %xmm2,%xmm4
  1b2d68:	cmplesd %xmm3,%xmm4
  1b2d6d:	movapd %xmm4,%xmm5
  1b2d71:	andpd  %xmm3,%xmm5
  1b2d75:	andnpd %xmm2,%xmm4
  1b2d79:	orpd   %xmm5,%xmm4
  1b2d7d:	ucomisd %xmm8,%xmm4
  1b2d82:	jbe    1b2dc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9f40>
  1b2d84:	ucomisd %xmm4,%xmm9
  1b2d89:	jbe    1b2dc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9f40>
  1b2d8b:	movapd %xmm0,%xmm2
  1b2d8f:	mulpd  %xmm0,%xmm2
  1b2d93:	movapd %xmm2,%xmm3
  1b2d97:	unpckhpd %xmm2,%xmm3
  1b2d9b:	addsd  %xmm2,%xmm3
  1b2d9f:	movapd %xmm10,%xmm2
  1b2da4:	divsd  %xmm3,%xmm2
  1b2da8:	mulsd  %xmm2,%xmm0
  1b2dac:	xorpd  %xmm11,%xmm1
  1b2db1:	mulsd  %xmm2,%xmm1
  1b2db5:	jmp    1b2eb0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa030>
  1b2dba:	nopw   0x0(%rax,%rax,1)
  1b2dc0:	ucomisd %xmm7,%xmm1
  1b2dc4:	setnp  %al
  1b2dc7:	sete   %cl
  1b2dca:	and    %al,%cl
  1b2dcc:	movq   %xmm0,%rax
  1b2dd1:	and    %rsi,%rax
  1b2dd4:	movabs $0x7ff0000000000000,%r8
  1b2dde:	cmp    %r8,%rax
  1b2de1:	setl   %dl
  1b2de4:	test   %dl,%cl
  1b2de6:	je     1b2e00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9f80>
  1b2de8:	movapd %xmm10,%xmm2
  1b2ded:	divsd  %xmm0,%xmm2
  1b2df1:	xorpd  %xmm11,%xmm1
  1b2df6:	movapd %xmm2,%xmm0
  1b2dfa:	jmp    1b2eb0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa030>
  1b2dff:	nop
  1b2e00:	ucomisd %xmm7,%xmm0
  1b2e04:	setnp  %cl
  1b2e07:	sete   %dl
  1b2e0a:	and    %cl,%dl
  1b2e0c:	movq   %xmm1,%rcx
  1b2e11:	and    %rsi,%rcx
  1b2e14:	cmp    %r8,%rcx
  1b2e17:	setl   %sil
  1b2e1b:	test   %sil,%dl
  1b2e1e:	je     1b2e2f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9faf>
  1b2e20:	movapd %xmm12,%xmm2
  1b2e25:	divsd  %xmm1,%xmm2
  1b2e29:	movapd %xmm2,%xmm1
  1b2e2d:	jmp    1b2ea6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa026>
  1b2e2f:	movabs $0x7fefffffffffffff,%rdx
  1b2e39:	cmp    %rdx,%rax
  1b2e3c:	setg   %al
  1b2e3f:	cmp    %rdx,%rcx
  1b2e42:	setg   %cl
  1b2e45:	or     %al,%cl
  1b2e47:	cmp    $0x1,%cl
  1b2e4a:	jne    1b2ee1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa061>
  1b2e50:	add    %r15,%rdi
  1b2e53:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1b2e58:	movsd  0x1fe485f(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1b2e61:	movapd 0x1fe31a6(%rip),%xmm11        # 2196010 <_fini+0x530>
  1b2e6a:	movsd  0x1fe4855(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1b2e73:	movsd  0x1fe483c(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b2e7c:	movsd  0x1fe482b(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b2e85:	xorpd  %xmm7,%xmm7
  1b2e89:	movapd 0x1fe316f(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b2e91:	mov    0x1c8(%rsp),%r10
  1b2e99:	mov    0x28(%rsp),%r11
  1b2e9e:	mov    0x1b0(%rsp),%r9
  1b2ea6:	movabs $0x7fffffffffffffff,%rsi
  1b2eb0:	add    0x18(%rsp),%r14
  1b2eb5:	cmp    %rbx,%r14
  1b2eb8:	jae    1bd79e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1491e>
  1b2ebe:	shl    $0x4,%r14
  1b2ec2:	movsd  %xmm0,(%r15,%r14,1)
  1b2ec8:	movsd  %xmm1,0x8(%r15,%r14,1)
  1b2ecf:	add    $0x8,%rbp
  1b2ed3:	cmp    %rbp,%r13
  1b2ed6:	jne    1b2d20 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ea0>
  1b2edc:	jmp    1b2f69 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa0e9>
  1b2ee1:	ucomisd %xmm7,%xmm1
  1b2ee5:	movabs $0x7fffffffffffffff,%rsi
  1b2eef:	jne    1b2ef7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa077>
  1b2ef1:	jnp    1b2de8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9f68>
  1b2ef7:	ucomisd %xmm7,%xmm0
  1b2efb:	jne    1b2f0e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa08e>
  1b2efd:	jp     1b2f0e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa08e>
  1b2eff:	movapd %xmm12,%xmm2
  1b2f04:	divsd  %xmm1,%xmm2
  1b2f08:	movapd %xmm2,%xmm1
  1b2f0c:	jmp    1b2eb0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa030>
  1b2f0e:	movapd %xmm3,%xmm1
  1b2f12:	cmplesd %xmm2,%xmm1
  1b2f17:	movapd %xmm1,%xmm4
  1b2f1b:	andpd  %xmm2,%xmm4
  1b2f1f:	andnpd %xmm3,%xmm1
  1b2f23:	orpd   %xmm4,%xmm1
  1b2f27:	unpcklpd %xmm1,%xmm1
  1b2f2b:	divpd  %xmm1,%xmm0
  1b2f2f:	movapd %xmm0,%xmm2
  1b2f33:	xorpd  %xmm11,%xmm2
  1b2f38:	movsd  %xmm0,%xmm2
  1b2f3c:	mulpd  %xmm0,%xmm0
  1b2f40:	movapd %xmm0,%xmm3
  1b2f44:	unpcklpd %xmm0,%xmm3
  1b2f48:	unpckhpd %xmm0,%xmm0
  1b2f4c:	addpd  %xmm3,%xmm0
  1b2f50:	divpd  %xmm0,%xmm2
  1b2f54:	divpd  %xmm1,%xmm2
  1b2f58:	movapd %xmm2,%xmm0
  1b2f5c:	movapd %xmm2,%xmm1
  1b2f60:	unpckhpd %xmm2,%xmm1
  1b2f64:	jmp    1b2eb0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa030>
  1b2f69:	cmpb   $0x0,0x20(%rsp)
  1b2f6e:	je     1b3002 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa182>
  1b2f74:	mov    0x60(%rsp),%r13
  1b2f79:	mov    0x30(%rsp),%r8
  1b2f7e:	cmp    %r8,%r13
  1b2f81:	jae    1b30aa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa22a>
  1b2f87:	mov    (%rsp),%rcx
  1b2f8b:	imul   $0x27,%rcx,%rax
  1b2f8f:	mov    0x10(%rsp),%rdx
  1b2f94:	lea    (%rdx,%rcx,2),%rdx
  1b2f98:	lea    (%rax,%r13,1),%r9
  1b2f9c:	xor    %esi,%esi
  1b2f9e:	mov    %rbx,%rcx
  1b2fa1:	sub    %r9,%rcx
  1b2fa4:	cmovb  %rsi,%rcx
  1b2fa8:	mov    0x18(%rsp),%rdi
  1b2fad:	lea    (%rdi,%r13,1),%rbp
  1b2fb1:	mov    %rbx,%rdi
  1b2fb4:	sub    %rbp,%rdi
  1b2fb7:	cmovb  %rsi,%rdi
  1b2fbb:	cmp    %rdi,%rcx
  1b2fbe:	cmovb  %rcx,%rdi
  1b2fc2:	lea    (%rdx,%r13,1),%r11
  1b2fc6:	mov    %rbx,%rcx
  1b2fc9:	sub    %r11,%rcx
  1b2fcc:	cmovb  %rsi,%rcx
  1b2fd0:	cmp    %rcx,%rdi
  1b2fd3:	cmovb  %rdi,%rcx
  1b2fd7:	mov    %r13,%r14
  1b2fda:	not    %r14
  1b2fdd:	add    %r8,%r14
  1b2fe0:	cmp    %r14,%rcx
  1b2fe3:	cmovae %r14,%rcx
  1b2fe7:	lea    0x1(%rcx),%rsi
  1b2feb:	cmp    $0x32,%rsi
  1b2fef:	ja     1b3a7f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xabff>
  1b2ff5:	mov    0x28(%rsp),%r11
  1b2ffa:	mov    %r13,%r14
  1b2ffd:	jmp    1b419d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb31d>
  1b3002:	mov    (%rsp),%rax
  1b3006:	imul   $0x27,%rax,%rsi
  1b300a:	mov    0x10(%rsp),%rcx
  1b300f:	lea    (%rcx,%rax,2),%rdx
  1b3013:	xor    %r8d,%r8d
  1b3016:	cs nopw 0x0(%rax,%rax,1)
  1b3020:	mov    (%r11,%r8,1),%rdi
  1b3024:	lea    (%rdi,%rsi,1),%rax
  1b3028:	cmp    %rbx,%rax
  1b302b:	jae    1bde97 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15017>
  1b3031:	mov    0x18(%rsp),%rcx
  1b3036:	add    %rdi,%rcx
  1b3039:	cmp    %rbx,%rcx
  1b303c:	jae    1bde84 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15004>
  1b3042:	add    %rdx,%rdi
  1b3045:	cmp    %rbx,%rdi
  1b3048:	jae    1bde74 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14ff4>
  1b304e:	shl    $0x4,%rax
  1b3052:	shl    $0x4,%rcx
  1b3056:	shl    $0x4,%rdi
  1b305a:	movupd (%r15,%rax,1),%xmm0
  1b3060:	movsd  (%r15,%rcx,1),%xmm1
  1b3066:	movsd  0x8(%r15,%rcx,1),%xmm2
  1b306d:	unpcklpd %xmm1,%xmm1
  1b3071:	mulpd  %xmm0,%xmm1
  1b3075:	shufpd $0x1,%xmm0,%xmm0
  1b307a:	unpcklpd %xmm2,%xmm2
  1b307e:	mulpd  %xmm0,%xmm2
  1b3082:	movapd %xmm1,%xmm0
  1b3086:	subpd  %xmm2,%xmm0
  1b308a:	addpd  %xmm1,%xmm2
  1b308e:	movsd  %xmm0,%xmm2
  1b3092:	movupd %xmm2,(%r15,%rdi,1)
  1b3098:	add    $0x8,%r8
  1b309c:	cmp    %r8,%r13
  1b309f:	jne    1b3020 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa1a0>
  1b30a5:	jmp    1b423e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb3be>
  1b30aa:	mov    (%rsp),%rax
  1b30ae:	mov    0x10(%rsp),%rcx
  1b30b3:	lea    (%rcx,%rax,2),%rdx
  1b30b7:	jmp    1b423e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb3be>
  1b30bc:	xor    %edi,%edi
  1b30be:	mov    %rbx,%r8
  1b30c1:	sub    %r11,%r8
  1b30c4:	cmovb  %rdi,%r8
  1b30c8:	mov    %rbx,%r9
  1b30cb:	sub    %r14,%r9
  1b30ce:	cmovb  %rdi,%r9
  1b30d2:	cmp    %r9,%r8
  1b30d5:	cmovb  %r8,%r9
  1b30d9:	cmp    %rcx,%r9
  1b30dc:	cmovae %rcx,%r9
  1b30e0:	imul   $0x350,%rbp,%rdi
  1b30e7:	mov    %rsi,%r8
  1b30ea:	shl    $0x4,%r8
  1b30ee:	lea    (%r15,%rdi,1),%r10
  1b30f2:	lea    (%r8,%r10,1),%rbx
  1b30f6:	add    $0x8,%rbx
  1b30fa:	add    %r8,%r10
  1b30fd:	mov    %r9,%r12
  1b3100:	shl    $0x4,%r12
  1b3104:	add    %r10,%r12
  1b3107:	add    $0x8,%r12
  1b310b:	mov    %rsi,%r10
  1b310e:	cmp    %rbx,%r12
  1b3111:	mov    0x8(%rsp),%rbx
  1b3116:	jb     1b1be5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8d65>
  1b311c:	mov    %rsi,%r10
  1b311f:	movabs $0xfffffffffffffff,%r12
  1b3129:	cmp    %r12,%r9
  1b312c:	ja     1b1be5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8d65>
  1b3132:	imul   $0x360,%rbp,%r9
  1b3139:	xor    %r10d,%r10d
  1b313c:	mov    0x8(%rsp),%rbx
  1b3141:	sub    %r11,%rbx
  1b3144:	cmovb  %r10,%rbx
  1b3148:	mov    0x8(%rsp),%r11
  1b314d:	sub    %r14,%r11
  1b3150:	cmovb  %r10,%r11
  1b3154:	cmp    %r11,%rbx
  1b3157:	cmovb  %rbx,%r11
  1b315b:	lea    (%r9,%r8,1),%r10
  1b315f:	cmp    %rcx,%r11
  1b3162:	cmovae %rcx,%r11
  1b3166:	lea    (%r15,%r10,1),%rbx
  1b316a:	shl    $0x4,%r11
  1b316e:	lea    (%r11,%rbx,1),%r12
  1b3172:	add    $0x8,%r12
  1b3176:	lea    0x8(%r15,%r10,1),%r10
  1b317b:	mov    %r10,0x100(%rsp)
  1b3183:	lea    0x10(%r11,%rbx,1),%r14
  1b3188:	mov    %r14,0x40(%rsp)
  1b318d:	lea    (%rdi,%r8,1),%r10
  1b3191:	mov    %r10,0x48(%rsp)
  1b3196:	add    %r15,%r10
  1b3199:	lea    (%r11,%r10,1),%rbp
  1b319d:	add    $0x8,%rbp
  1b31a1:	mov    %rbp,0xb0(%rsp)
  1b31a9:	lea    (%r11,%r10,1),%rbp
  1b31ad:	add    $0x10,%rbp
  1b31b1:	cmp    %r14,%rbx
  1b31b4:	setb   0x50(%rsp)
  1b31b9:	mov    0x100(%rsp),%r14
  1b31c1:	cmp    %r12,%r14
  1b31c4:	setb   0x38(%rsp)
  1b31c9:	mov    0xb0(%rsp),%r11
  1b31d1:	cmp    %r11,%rbx
  1b31d4:	setb   0xd0(%rsp)
  1b31dc:	cmp    %r12,%r10
  1b31df:	setb   0xe0(%rsp)
  1b31e7:	cmp    %rbp,%rbx
  1b31ea:	mov    0x48(%rsp),%rbx
  1b31ef:	lea    0x8(%r15,%rbx,1),%rbx
  1b31f4:	setb   0x48(%rsp)
  1b31f9:	cmp    %r12,%rbx
  1b31fc:	setb   0x58(%rsp)
  1b3201:	cmp    %r11,%r14
  1b3204:	mov    %r14,%r12
  1b3207:	setb   %r14b
  1b320b:	mov    0x40(%rsp),%r11
  1b3210:	cmp    %r11,%r10
  1b3213:	setb   0xb0(%rsp)
  1b321b:	cmp    %rbp,%r12
  1b321e:	setb   %r12b
  1b3222:	cmp    %r11,%rbx
  1b3225:	mov    (%rsp),%rbp
  1b3229:	mov    0x8(%rsp),%rbx
  1b322e:	setb   0x40(%rsp)
  1b3233:	mov    %rsi,%r10
  1b3236:	movzbl 0x38(%rsp),%r11d
  1b323c:	test   %r11b,0x50(%rsp)
  1b3241:	jne    1b1be5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8d65>
  1b3247:	mov    %rsi,%r10
  1b324a:	movzbl 0xe0(%rsp),%r11d
  1b3253:	and    %r11b,0xd0(%rsp)
  1b325b:	jne    1b1be5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8d65>
  1b3261:	mov    %rsi,%r10
  1b3264:	movzbl 0x58(%rsp),%r11d
  1b326a:	and    %r11b,0x48(%rsp)
  1b326f:	jne    1b1be5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8d65>
  1b3275:	mov    %rsi,%r10
  1b3278:	and    0xb0(%rsp),%r14b
  1b3280:	jne    1b1be5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8d65>
  1b3286:	mov    %rsi,%r10
  1b3289:	and    0x40(%rsp),%r12b
  1b328e:	jne    1b1be5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8d65>
  1b3294:	and    $0xfffffffffffffffe,%rdx
  1b3298:	lea    (%rsi,%rdx,1),%r10
  1b329c:	mov    0x1d8(%rsp),%r11
  1b32a4:	movsd  0x10(%r11),%xmm0
  1b32aa:	movsd  0x18(%r11),%xmm1
  1b32b0:	unpcklpd %xmm1,%xmm1
  1b32b4:	unpcklpd %xmm0,%xmm0
  1b32b8:	add    %r15,%r8
  1b32bb:	nopl   0x0(%rax,%rax,1)
  1b32c0:	movupd (%r8,%rdi,1),%xmm2
  1b32c6:	movupd 0x10(%r8,%rdi,1),%xmm3
  1b32cd:	movapd %xmm2,%xmm4
  1b32d1:	unpcklpd %xmm3,%xmm4
  1b32d5:	unpckhpd %xmm3,%xmm2
  1b32d9:	movapd %xmm1,%xmm3
  1b32dd:	mulpd  %xmm4,%xmm3
  1b32e1:	movapd %xmm0,%xmm5
  1b32e5:	mulpd  %xmm2,%xmm5
  1b32e9:	addpd  %xmm3,%xmm5
  1b32ed:	mulpd  %xmm0,%xmm4
  1b32f1:	mulpd  %xmm1,%xmm2
  1b32f5:	subpd  %xmm2,%xmm4
  1b32f9:	movapd %xmm4,%xmm2
  1b32fd:	unpcklpd %xmm5,%xmm2
  1b3301:	unpckhpd %xmm5,%xmm4
  1b3305:	movupd %xmm4,0x10(%r8,%r9,1)
  1b330c:	movupd %xmm2,(%r8,%r9,1)
  1b3312:	add    $0x20,%r8
  1b3316:	add    $0xfffffffffffffffe,%rdx
  1b331a:	jne    1b32c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa440>
  1b331c:	jmp    1b1be5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8d65>
  1b3321:	xor    %r9d,%r9d
  1b3324:	mov    %rbx,%r10
  1b3327:	sub    %r12,%r10
  1b332a:	cmovb  %r9,%r10
  1b332e:	cmp    %rsi,%r10
  1b3331:	cmovae %rsi,%r10
  1b3335:	mov    %rbx,%r11
  1b3338:	sub    0x10(%rsp),%r11
  1b333d:	cmovb  %r9,%r11
  1b3341:	cmp    %r11,%r10
  1b3344:	cmovb  %r10,%r11
  1b3348:	cmp    %rcx,%r11
  1b334b:	cmovae %rcx,%r11
  1b334f:	imul   $0x340,(%rsp),%r9
  1b3357:	mov    %rbp,%r10
  1b335a:	shl    $0x4,%r10
  1b335e:	mov    %r9,0x50(%rsp)
  1b3363:	lea    (%r15,%r9,1),%rbx
  1b3367:	mov    %r12,0x38(%rsp)
  1b336c:	lea    (%r10,%rbx,1),%r12
  1b3370:	add    $0x8,%r12
  1b3374:	add    %r10,%rbx
  1b3377:	mov    %r11,%r9
  1b337a:	shl    $0x4,%r9
  1b337e:	add    %r9,%rbx
  1b3381:	add    $0x8,%rbx
  1b3385:	mov    %rbp,%r14
  1b3388:	cmp    %r12,%rbx
  1b338b:	jb     1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b3391:	lea    (%r15,%r8,1),%rbx
  1b3395:	lea    (%r10,%rbx,1),%r12
  1b3399:	add    $0x8,%r12
  1b339d:	add    %r10,%rbx
  1b33a0:	add    %rbx,%r9
  1b33a3:	add    $0x8,%r9
  1b33a7:	mov    %rbp,%r14
  1b33aa:	cmp    %r12,%r9
  1b33ad:	mov    0x38(%rsp),%r12
  1b33b2:	jb     1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b33b8:	mov    %rbp,%r14
  1b33bb:	movabs $0xfffffffffffffff,%r9
  1b33c5:	cmp    %r9,%r11
  1b33c8:	ja     1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b33ce:	imul   $0x370,(%rsp),%r11
  1b33d6:	xor    %r9d,%r9d
  1b33d9:	mov    0x8(%rsp),%rbx
  1b33de:	sub    %r12,%rbx
  1b33e1:	cmovb  %r9,%rbx
  1b33e5:	cmp    %rsi,%rbx
  1b33e8:	cmovae %rsi,%rbx
  1b33ec:	mov    0x8(%rsp),%rsi
  1b33f1:	sub    0x10(%rsp),%rsi
  1b33f6:	cmovb  %r9,%rsi
  1b33fa:	mov    %r11,0x120(%rsp)
  1b3402:	lea    (%r11,%r10,1),%r14
  1b3406:	cmp    %rsi,%rbx
  1b3409:	cmovb  %rbx,%rsi
  1b340d:	lea    (%r15,%r14,1),%r9
  1b3411:	cmp    %rcx,%rsi
  1b3414:	cmovae %rcx,%rsi
  1b3418:	shl    $0x4,%rsi
  1b341c:	lea    (%rsi,%r9,1),%rcx
  1b3420:	add    $0x8,%rcx
  1b3424:	lea    0x8(%r15,%r14,1),%r14
  1b3429:	lea    0x10(%rsi,%r9,1),%r11
  1b342e:	mov    %r11,0x10(%rsp)
  1b3433:	mov    0x50(%rsp),%r11
  1b3438:	lea    (%r11,%r10,1),%r12
  1b343c:	lea    (%r15,%r12,1),%r11
  1b3440:	lea    0x8(%r15,%r12,1),%rbx
  1b3445:	mov    %rbx,0xd0(%rsp)
  1b344d:	lea    0x10(%rsi,%r11,1),%rbx
  1b3452:	mov    %rbx,0x38(%rsp)
  1b3457:	mov    %r11,%rbx
  1b345a:	mov    %r11,0x40(%rsp)
  1b345f:	lea    (%r8,%r10,1),%r11
  1b3463:	lea    (%r15,%r11,1),%r12
  1b3467:	lea    0x8(%r15,%r11,1),%r11
  1b346c:	mov    %r11,0x48(%rsp)
  1b3471:	lea    0x10(%rsi,%r12,1),%r11
  1b3476:	mov    %r11,0x58(%rsp)
  1b347b:	lea    0x8(%rsi,%rbx,1),%rbx
  1b3480:	mov    %rbx,0xe0(%rsp)
  1b3488:	add    %r12,%rsi
  1b348b:	add    $0x8,%rsi
  1b348f:	mov    %rsi,0x20(%rsp)
  1b3494:	cmp    0x10(%rsp),%r9
  1b3499:	setb   0x100(%rsp)
  1b34a1:	cmp    %rcx,%r14
  1b34a4:	setb   0xb0(%rsp)
  1b34ac:	cmp    0x38(%rsp),%r9
  1b34b1:	setb   0x88(%rsp)
  1b34b9:	mov    0xd0(%rsp),%rsi
  1b34c1:	cmp    %rcx,%rsi
  1b34c4:	setb   0x78(%rsp)
  1b34c9:	mov    0x58(%rsp),%rbx
  1b34ce:	cmp    %rbx,%r9
  1b34d1:	setb   0x80(%rsp)
  1b34d9:	cmp    %rcx,0x48(%rsp)
  1b34de:	setb   0x98(%rsp)
  1b34e6:	mov    0xe0(%rsp),%r11
  1b34ee:	cmp    %r11,%r9
  1b34f1:	setb   0xc8(%rsp)
  1b34f9:	cmp    %rcx,0x40(%rsp)
  1b34fe:	setb   0xa8(%rsp)
  1b3506:	cmp    0x20(%rsp),%r9
  1b350b:	setb   0xf8(%rsp)
  1b3513:	cmp    %rcx,%r12
  1b3516:	setb   0x118(%rsp)
  1b351e:	cmp    0x38(%rsp),%r14
  1b3523:	setb   0x38(%rsp)
  1b3528:	mov    0x10(%rsp),%rcx
  1b352d:	cmp    %rcx,%rsi
  1b3530:	setb   0xd0(%rsp)
  1b3538:	cmp    %rbx,%r14
  1b353b:	setb   0x58(%rsp)
  1b3540:	cmp    %rcx,0x48(%rsp)
  1b3545:	setb   0x48(%rsp)
  1b354a:	cmp    %r11,%r14
  1b354d:	setb   0xe0(%rsp)
  1b3555:	cmp    %rcx,0x40(%rsp)
  1b355a:	mov    %rcx,%r11
  1b355d:	setb   %sil
  1b3561:	cmp    0x20(%rsp),%r14
  1b3566:	setb   %cl
  1b3569:	cmp    %r11,%r12
  1b356c:	mov    %rbp,%r14
  1b356f:	setb   %r11b
  1b3573:	movzbl 0xb0(%rsp),%r12d
  1b357c:	test   %r12b,0x100(%rsp)
  1b3584:	jne    1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b358a:	mov    %rbp,%r14
  1b358d:	movzbl 0x78(%rsp),%r12d
  1b3593:	and    %r12b,0x88(%rsp)
  1b359b:	jne    1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b35a1:	mov    %rbp,%r14
  1b35a4:	movzbl 0x98(%rsp),%r12d
  1b35ad:	and    %r12b,0x80(%rsp)
  1b35b5:	jne    1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b35bb:	mov    %rbp,%r14
  1b35be:	movzbl 0xa8(%rsp),%r12d
  1b35c7:	and    %r12b,0xc8(%rsp)
  1b35cf:	jne    1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b35d5:	mov    %rbp,%r14
  1b35d8:	movzbl 0x118(%rsp),%r12d
  1b35e1:	and    %r12b,0xf8(%rsp)
  1b35e9:	jne    1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b35ef:	mov    %rbp,%r14
  1b35f2:	movzbl 0xd0(%rsp),%r12d
  1b35fb:	and    %r12b,0x38(%rsp)
  1b3600:	jne    1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b3606:	mov    %rbp,%r14
  1b3609:	movzbl 0x48(%rsp),%r12d
  1b360f:	and    %r12b,0x58(%rsp)
  1b3614:	jne    1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b361a:	mov    %rbp,%r14
  1b361d:	and    %sil,0xe0(%rsp)
  1b3625:	jne    1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b362b:	mov    %rbp,%r14
  1b362e:	and    %r11b,%cl
  1b3631:	jne    1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b3637:	and    $0xfffffffffffffffe,%rdi
  1b363b:	lea    (%rdi,%rbp,1),%r14
  1b363f:	add    %r15,%r10
  1b3642:	mov    0x50(%rsp),%rcx
  1b3647:	mov    0x120(%rsp),%rsi
  1b364f:	nop
  1b3650:	movupd (%r10,%rcx,1),%xmm0
  1b3656:	movupd (%r10,%r8,1),%xmm1
  1b365c:	addpd  %xmm0,%xmm1
  1b3660:	movupd %xmm1,(%r10,%rsi,1)
  1b3666:	add    $0x10,%r10
  1b366a:	dec    %rdi
  1b366d:	jne    1b3650 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xa7d0>
  1b366f:	jmp    1b1cdb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x8e5b>
  1b3674:	xor    %r10d,%r10d
  1b3677:	mov    %rsi,%rdi
  1b367a:	sub    0x10(%rsp),%rdi
  1b367f:	cmovb  %r10,%rdi
  1b3683:	mov    %rsi,%r8
  1b3686:	sub    %r12,%r8
  1b3689:	cmovb  %r10,%r8
  1b368d:	cmp    %r8,%rdi
  1b3690:	cmovb  %rdi,%r8
  1b3694:	mov    %rsi,%r9
  1b3697:	sub    %rbp,%r9
  1b369a:	cmovb  %r10,%r9
  1b369e:	cmp    %r9,%r8
  1b36a1:	cmovb  %r8,%r9
  1b36a5:	cmp    %r14,%r9
  1b36a8:	cmovae %r14,%r9
  1b36ac:	imul   $0x2a0,(%rsp),%r13
  1b36b4:	mov    %rbx,%rdi
  1b36b7:	shl    $0x4,%rdi
  1b36bb:	lea    (%r15,%r13,1),%r8
  1b36bf:	mov    %rbx,0x60(%rsp)
  1b36c4:	lea    (%rdi,%r8,1),%rbx
  1b36c8:	add    $0x8,%rbx
  1b36cc:	add    %rdi,%r8
  1b36cf:	mov    %r9,%r11
  1b36d2:	shl    $0x4,%r11
  1b36d6:	add    %r11,%r8
  1b36d9:	add    $0x8,%r8
  1b36dd:	mov    0x60(%rsp),%r10
  1b36e2:	cmp    %rbx,%r8
  1b36e5:	mov    0x60(%rsp),%rbx
  1b36ea:	mov    0x8(%rsp),%rsi
  1b36ef:	jb     1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b36f5:	imul   $0x3d0,(%rsp),%r8
  1b36fd:	lea    (%r15,%r8,1),%r10
  1b3701:	lea    (%rdi,%r10,1),%rbx
  1b3705:	add    $0x8,%rbx
  1b3709:	add    %rdi,%r10
  1b370c:	add    %r10,%r11
  1b370f:	add    $0x8,%r11
  1b3713:	mov    0x60(%rsp),%r10
  1b3718:	cmp    %rbx,%r11
  1b371b:	mov    0x60(%rsp),%rbx
  1b3720:	mov    0x8(%rsp),%rsi
  1b3725:	jb     1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b372b:	mov    %rbx,%r10
  1b372e:	movabs $0xfffffffffffffff,%r11
  1b3738:	cmp    %r11,%r9
  1b373b:	ja     1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b3741:	imul   $0x3e0,(%rsp),%r9
  1b3749:	xor    %r10d,%r10d
  1b374c:	mov    %rsi,%r11
  1b374f:	sub    0x10(%rsp),%r11
  1b3754:	cmovb  %r10,%r11
  1b3758:	mov    0x8(%rsp),%rbx
  1b375d:	sub    %r12,%rbx
  1b3760:	cmovb  %r10,%rbx
  1b3764:	cmp    %rbx,%r11
  1b3767:	cmovb  %r11,%rbx
  1b376b:	mov    0x8(%rsp),%r12
  1b3770:	sub    %rbp,%r12
  1b3773:	cmovb  %r10,%r12
  1b3777:	lea    (%r9,%rdi,1),%r10
  1b377b:	cmp    %r12,%rbx
  1b377e:	cmovb  %rbx,%r12
  1b3782:	lea    (%r15,%r10,1),%rbp
  1b3786:	cmp    %r14,%r12
  1b3789:	cmovae %r14,%r12
  1b378d:	shl    $0x4,%r12
  1b3791:	lea    (%r12,%rbp,1),%r11
  1b3795:	add    $0x8,%r11
  1b3799:	lea    0x8(%r15,%r10,1),%r14
  1b379e:	lea    0x10(%r12,%rbp,1),%rsi
  1b37a3:	mov    %rsi,0x50(%rsp)
  1b37a8:	lea    0x0(%r13,%rdi,1),%r10
  1b37ad:	lea    (%r15,%r10,1),%rbx
  1b37b1:	lea    0x8(%r12,%rbx,1),%rsi
  1b37b6:	mov    %rsi,0xd0(%rsp)
  1b37be:	lea    0x8(%r15,%r10,1),%rsi
  1b37c3:	mov    %rsi,0x10(%rsp)
  1b37c8:	lea    0x10(%r12,%rbx,1),%rsi
  1b37cd:	mov    %rsi,0x20(%rsp)
  1b37d2:	lea    (%r8,%rdi,1),%rsi
  1b37d6:	mov    %rsi,0x48(%rsp)
  1b37db:	add    %r15,%rsi
  1b37de:	mov    %rsi,0xb0(%rsp)
  1b37e6:	lea    (%r12,%rsi,1),%r10
  1b37ea:	add    $0x8,%r10
  1b37ee:	mov    %r10,0x100(%rsp)
  1b37f6:	add    %rsi,%r12
  1b37f9:	add    $0x10,%r12
  1b37fd:	cmp    0x50(%rsp),%rbp
  1b3802:	setb   0x38(%rsp)
  1b3807:	cmp    %r11,%r14
  1b380a:	setb   0x40(%rsp)
  1b380f:	mov    0xd0(%rsp),%rsi
  1b3817:	cmp    %rsi,%rbp
  1b381a:	setb   0xe0(%rsp)
  1b3822:	cmp    %r11,%rbx
  1b3825:	setb   0x58(%rsp)
  1b382a:	cmp    0x20(%rsp),%rbp
  1b382f:	setb   0x88(%rsp)
  1b3837:	cmp    %r11,0x10(%rsp)
  1b383c:	setb   0x78(%rsp)
  1b3841:	cmp    %r10,%rbp
  1b3844:	setb   0x80(%rsp)
  1b384c:	mov    0xb0(%rsp),%r10
  1b3854:	cmp    %r11,%r10
  1b3857:	setb   0x98(%rsp)
  1b385f:	cmp    %r12,%rbp
  1b3862:	mov    0x48(%rsp),%rbp
  1b3867:	lea    0x8(%r15,%rbp,1),%rbp
  1b386c:	setb   0x48(%rsp)
  1b3871:	cmp    %r11,%rbp
  1b3874:	setb   0xc8(%rsp)
  1b387c:	cmp    %rsi,%r14
  1b387f:	setb   0xd0(%rsp)
  1b3887:	mov    0x50(%rsp),%r11
  1b388c:	cmp    %r11,%rbx
  1b388f:	mov    0x60(%rsp),%rbx
  1b3894:	mov    0x8(%rsp),%rsi
  1b3899:	setb   0xa8(%rsp)
  1b38a1:	cmp    0x20(%rsp),%r14
  1b38a6:	setb   0x20(%rsp)
  1b38ab:	cmp    %r11,0x10(%rsp)
  1b38b0:	setb   0x10(%rsp)
  1b38b5:	cmp    0x100(%rsp),%r14
  1b38bd:	setb   0x100(%rsp)
  1b38c5:	cmp    %r11,%r10
  1b38c8:	setb   0xb0(%rsp)
  1b38d0:	cmp    %r12,%r14
  1b38d3:	setb   0xf8(%rsp)
  1b38db:	cmp    %r11,%rbp
  1b38de:	mov    %rbx,%r10
  1b38e1:	setb   0x50(%rsp)
  1b38e6:	movzbl 0x40(%rsp),%r11d
  1b38ec:	test   %r11b,0x38(%rsp)
  1b38f1:	jne    1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b38f7:	mov    %rbx,%r10
  1b38fa:	movzbl 0x58(%rsp),%r11d
  1b3900:	and    %r11b,0xe0(%rsp)
  1b3908:	jne    1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b390e:	mov    %rbx,%r10
  1b3911:	movzbl 0x78(%rsp),%r11d
  1b3917:	and    %r11b,0x88(%rsp)
  1b391f:	jne    1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b3925:	mov    %rbx,%r10
  1b3928:	movzbl 0x98(%rsp),%r11d
  1b3931:	and    %r11b,0x80(%rsp)
  1b3939:	jne    1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b393f:	mov    %rbx,%r10
  1b3942:	movzbl 0xc8(%rsp),%r14d
  1b394b:	and    %r14b,0x48(%rsp)
  1b3950:	jne    1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b3956:	mov    %rbx,%r10
  1b3959:	movzbl 0xa8(%rsp),%r14d
  1b3962:	and    %r14b,0xd0(%rsp)
  1b396a:	jne    1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b3970:	mov    %rbx,%r10
  1b3973:	movzbl 0x10(%rsp),%r14d
  1b3979:	and    %r14b,0x20(%rsp)
  1b397e:	jne    1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b3984:	mov    %rbx,%r10
  1b3987:	movzbl 0xb0(%rsp),%r11d
  1b3990:	and    %r11b,0x100(%rsp)
  1b3998:	jne    1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b399e:	mov    %rbx,%r10
  1b39a1:	movzbl 0xf8(%rsp),%r11d
  1b39aa:	and    0x50(%rsp),%r11b
  1b39af:	jne    1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b39b5:	and    $0xfffffffffffffffe,%rdx
  1b39b9:	lea    (%rbx,%rdx,1),%r10
  1b39bd:	mov    0x1d8(%rsp),%r11
  1b39c5:	movsd  0x40(%r11),%xmm0
  1b39cb:	movsd  0x48(%r11),%xmm1
  1b39d1:	unpcklpd %xmm1,%xmm1
  1b39d5:	unpcklpd %xmm0,%xmm0
  1b39d9:	add    %r15,%rdi
  1b39dc:	nopl   0x0(%rax)
  1b39e0:	movupd (%rdi,%r13,1),%xmm3
  1b39e6:	movupd 0x10(%rdi,%r13,1),%xmm4
  1b39ed:	movapd %xmm3,%xmm2
  1b39f1:	unpcklpd %xmm4,%xmm2
  1b39f5:	unpckhpd %xmm4,%xmm3
  1b39f9:	movapd %xmm1,%xmm4
  1b39fd:	mulpd  %xmm2,%xmm4
  1b3a01:	movapd %xmm0,%xmm5
  1b3a05:	mulpd  %xmm3,%xmm5
  1b3a09:	addpd  %xmm4,%xmm5
  1b3a0d:	movupd (%rdi,%r8,1),%xmm4
  1b3a13:	movupd 0x10(%rdi,%r8,1),%xmm6
  1b3a1a:	movapd %xmm4,%xmm7
  1b3a1e:	unpcklpd %xmm6,%xmm7
  1b3a22:	unpckhpd %xmm6,%xmm4
  1b3a26:	movapd %xmm7,%xmm6
  1b3a2a:	mulpd  %xmm5,%xmm6
  1b3a2e:	mulpd  %xmm0,%xmm2
  1b3a32:	mulpd  %xmm1,%xmm3
  1b3a36:	subpd  %xmm3,%xmm2
  1b3a3a:	mulpd  %xmm2,%xmm7
  1b3a3e:	mulpd  %xmm4,%xmm2
  1b3a42:	addpd  %xmm6,%xmm2
  1b3a46:	mulpd  %xmm5,%xmm4
  1b3a4a:	subpd  %xmm4,%xmm7
  1b3a4e:	movapd %xmm7,%xmm3
  1b3a52:	unpcklpd %xmm2,%xmm3
  1b3a56:	unpckhpd %xmm2,%xmm7
  1b3a5a:	movupd %xmm7,0x10(%rdi,%r9,1)
  1b3a61:	movupd %xmm3,(%rdi,%r9,1)
  1b3a67:	add    $0x20,%rdi
  1b3a6b:	add    $0xfffffffffffffffe,%rdx
  1b3a6f:	jne    1b39e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xab60>
  1b3a75:	mov    0x60(%rsp),%rbx
  1b3a7a:	jmp    1b2949 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9ac9>
  1b3a7f:	xor    %esi,%esi
  1b3a81:	mov    %rbx,%rdi
  1b3a84:	mov    %r9,0x10(%rsp)
  1b3a89:	sub    %r9,%rdi
  1b3a8c:	cmovb  %rsi,%rdi
  1b3a90:	mov    %rbx,%r8
  1b3a93:	mov    %rbp,0x20(%rsp)
  1b3a98:	sub    %rbp,%r8
  1b3a9b:	cmovb  %rsi,%r8
  1b3a9f:	cmp    %r8,%rdi
  1b3aa2:	cmovb  %rdi,%r8
  1b3aa6:	mov    %rbx,%r9
  1b3aa9:	sub    %r11,%r9
  1b3aac:	cmovb  %rsi,%r9
  1b3ab0:	cmp    %r9,%r8
  1b3ab3:	cmovb  %r8,%r9
  1b3ab7:	cmp    %r14,%r9
  1b3aba:	cmovae %r14,%r9
  1b3abe:	mov    (%rsp),%r10
  1b3ac2:	imul   $0x270,%r10,%rsi
  1b3ac9:	mov    %r13,%rdi
  1b3acc:	shl    $0x4,%rdi
  1b3ad0:	lea    (%r15,%rsi,1),%r8
  1b3ad4:	lea    (%rdi,%r8,1),%rbx
  1b3ad8:	add    $0x8,%rbx
  1b3adc:	add    %rdi,%r8
  1b3adf:	mov    %r9,%rbp
  1b3ae2:	shl    $0x4,%rbp
  1b3ae6:	add    %rbp,%r8
  1b3ae9:	add    $0x8,%r8
  1b3aed:	cmp    %rbx,%r8
  1b3af0:	jb     1b4186 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb306>
  1b3af6:	imul   $0x410,%r10,%r8
  1b3afd:	lea    (%r15,%r8,1),%rbx
  1b3b01:	lea    (%rdi,%rbx,1),%r10
  1b3b05:	add    $0x8,%r10
  1b3b09:	add    %rdi,%rbx
  1b3b0c:	add    %rbp,%rbx
  1b3b0f:	add    $0x8,%rbx
  1b3b13:	cmp    %r10,%rbx
  1b3b16:	jb     1b4186 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb306>
  1b3b1c:	movabs $0xfffffffffffffff,%r10
  1b3b26:	cmp    %r10,%r9
  1b3b29:	mov    0x8(%rsp),%rbx
  1b3b2e:	ja     1b418b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb30b>
  1b3b34:	imul   $0x420,(%rsp),%r9
  1b3b3c:	xor    %r13d,%r13d
  1b3b3f:	mov    %rbx,%r10
  1b3b42:	sub    0x10(%rsp),%rbx
  1b3b47:	cmovb  %r13,%rbx
  1b3b4b:	mov    %r10,%rbp
  1b3b4e:	sub    0x20(%rsp),%rbp
  1b3b53:	cmovb  %r13,%rbp
  1b3b57:	cmp    %rbp,%rbx
  1b3b5a:	cmovb  %rbx,%rbp
  1b3b5e:	mov    %r10,%rbx
  1b3b61:	sub    %r11,%rbx
  1b3b64:	cmovb  %r13,%rbx
  1b3b68:	cmp    %rbx,%rbp
  1b3b6b:	cmovb  %rbp,%rbx
  1b3b6f:	lea    (%r9,%rdi,1),%r11
  1b3b73:	cmp    %r14,%rbx
  1b3b76:	cmovae %r14,%rbx
  1b3b7a:	lea    (%r15,%r11,1),%r13
  1b3b7e:	shl    $0x4,%rbx
  1b3b82:	lea    (%rbx,%r13,1),%r14
  1b3b86:	add    $0x8,%r14
  1b3b8a:	lea    0x8(%r15,%r11,1),%r10
  1b3b8f:	mov    %r10,0x58(%rsp)
  1b3b94:	lea    0x10(%rbx,%r13,1),%r10
  1b3b99:	mov    %r10,0x20(%rsp)
  1b3b9e:	lea    (%rsi,%rdi,1),%r11
  1b3ba2:	lea    (%r15,%r11,1),%r10
  1b3ba6:	mov    %r10,0x10(%rsp)
  1b3bab:	lea    0x8(%r15,%r11,1),%r11
  1b3bb0:	mov    %r11,0x50(%rsp)
  1b3bb5:	lea    0x10(%rbx,%r10,1),%r11
  1b3bba:	mov    %r11,0x40(%rsp)
  1b3bbf:	lea    (%r8,%rdi,1),%r11
  1b3bc3:	mov    %r11,0xb0(%rsp)
  1b3bcb:	add    %r15,%r11
  1b3bce:	lea    0x8(%rbx,%r11,1),%rbp
  1b3bd3:	mov    %rbp,0x38(%rsp)
  1b3bd8:	lea    0x8(%rbx,%r10,1),%r10
  1b3bdd:	mov    %r10,0xe0(%rsp)
  1b3be5:	add    %r11,%rbx
  1b3be8:	add    $0x10,%rbx
  1b3bec:	mov    %rbx,0xd0(%rsp)
  1b3bf4:	cmp    0x20(%rsp),%r13
  1b3bf9:	setb   0x48(%rsp)
  1b3bfe:	mov    0x58(%rsp),%rbp
  1b3c03:	cmp    %r14,%rbp
  1b3c06:	setb   0x100(%rsp)
  1b3c0e:	cmp    0x40(%rsp),%r13
  1b3c13:	setb   0x88(%rsp)
  1b3c1b:	cmp    %r14,0x50(%rsp)
  1b3c20:	setb   0x78(%rsp)
  1b3c25:	cmp    0x38(%rsp),%r13
  1b3c2a:	setb   0x80(%rsp)
  1b3c32:	cmp    %r14,%r11
  1b3c35:	setb   0x98(%rsp)
  1b3c3d:	cmp    %r10,%r13
  1b3c40:	setb   0xc8(%rsp)
  1b3c48:	cmp    %r14,0x10(%rsp)
  1b3c4d:	setb   0xa8(%rsp)
  1b3c55:	cmp    %rbx,%r13
  1b3c58:	mov    0xb0(%rsp),%r10
  1b3c60:	lea    0x8(%r15,%r10,1),%rbx
  1b3c65:	setb   %r13b
  1b3c69:	cmp    %r14,%rbx
  1b3c6c:	setb   0xb0(%rsp)
  1b3c74:	cmp    0x40(%rsp),%rbp
  1b3c79:	setb   0x40(%rsp)
  1b3c7e:	mov    0x20(%rsp),%r10
  1b3c83:	cmp    %r10,0x50(%rsp)
  1b3c88:	setb   0x50(%rsp)
  1b3c8d:	cmp    0x38(%rsp),%rbp
  1b3c92:	setb   0x38(%rsp)
  1b3c97:	cmp    %r10,%r11
  1b3c9a:	setb   0xf8(%rsp)
  1b3ca2:	cmp    0xe0(%rsp),%rbp
  1b3caa:	setb   0xe0(%rsp)
  1b3cb2:	cmp    %r10,0x10(%rsp)
  1b3cb7:	setb   0x10(%rsp)
  1b3cbc:	cmp    0xd0(%rsp),%rbp
  1b3cc4:	setb   %r11b
  1b3cc8:	cmp    %r10,%rbx
  1b3ccb:	setb   %r10b
  1b3ccf:	movzbl 0x100(%rsp),%ebx
  1b3cd7:	test   %bl,0x48(%rsp)
  1b3cdb:	jne    1b4186 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb306>
  1b3ce1:	movzbl 0x78(%rsp),%ebx
  1b3ce6:	and    %bl,0x88(%rsp)
  1b3ced:	jne    1b4186 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb306>
  1b3cf3:	movzbl 0x98(%rsp),%ebx
  1b3cfb:	and    %bl,0x80(%rsp)
  1b3d02:	mov    0x8(%rsp),%rbx
  1b3d07:	mov    0x60(%rsp),%r14
  1b3d0c:	jne    1b5a85 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc05>
  1b3d12:	movzbl 0xa8(%rsp),%ebp
  1b3d1a:	and    %bpl,0xc8(%rsp)
  1b3d22:	jne    1b5a85 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc05>
  1b3d28:	and    0xb0(%rsp),%r13b
  1b3d30:	jne    1b5a85 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc05>
  1b3d36:	movzbl 0x50(%rsp),%ebp
  1b3d3b:	and    %bpl,0x40(%rsp)
  1b3d40:	jne    1b5a85 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc05>
  1b3d46:	movzbl 0xf8(%rsp),%ebp
  1b3d4e:	and    %bpl,0x38(%rsp)
  1b3d53:	jne    1b5a85 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc05>
  1b3d59:	movzbl 0x10(%rsp),%ebp
  1b3d5e:	and    %bpl,0xe0(%rsp)
  1b3d66:	jne    1b5a85 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc05>
  1b3d6c:	and    %r10b,%r11b
  1b3d6f:	mov    0x1c8(%rsp),%r10
  1b3d77:	jne    1b5a7b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbfb>
  1b3d7d:	and    $0xfffffffffffffffe,%rcx
  1b3d81:	add    %rcx,%r14
  1b3d84:	add    %r15,%rdi
  1b3d87:	mov    0x28(%rsp),%r11
  1b3d8c:	nopl   0x0(%rax)
  1b3d90:	movupd (%rdi,%rsi,1),%xmm0
  1b3d95:	movupd 0x10(%rdi,%rsi,1),%xmm1
  1b3d9b:	movapd %xmm0,%xmm2
  1b3d9f:	unpcklpd %xmm1,%xmm2
  1b3da3:	unpckhpd %xmm1,%xmm0
  1b3da7:	movupd (%rdi,%r8,1),%xmm1
  1b3dad:	movupd 0x10(%rdi,%r8,1),%xmm3
  1b3db4:	movapd %xmm1,%xmm4
  1b3db8:	unpcklpd %xmm3,%xmm4
  1b3dbc:	unpckhpd %xmm3,%xmm1
  1b3dc0:	movapd %xmm0,%xmm3
  1b3dc4:	mulpd  %xmm4,%xmm3
  1b3dc8:	mulpd  %xmm2,%xmm4
  1b3dcc:	mulpd  %xmm1,%xmm2
  1b3dd0:	addpd  %xmm3,%xmm2
  1b3dd4:	mulpd  %xmm0,%xmm1
  1b3dd8:	subpd  %xmm1,%xmm4
  1b3ddc:	movapd %xmm4,%xmm0
  1b3de0:	unpcklpd %xmm2,%xmm0
  1b3de4:	unpckhpd %xmm2,%xmm4
  1b3de8:	movupd %xmm4,0x10(%rdi,%r9,1)
  1b3def:	movupd %xmm0,(%rdi,%r9,1)
  1b3df5:	add    $0x20,%rdi
  1b3df9:	add    $0xfffffffffffffffe,%rcx
  1b3dfd:	jne    1b3d90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xaf10>
  1b3dff:	jmp    1b419d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb31d>
  1b3e04:	xor    %edx,%edx
  1b3e06:	mov    %rbx,%rsi
  1b3e09:	sub    %r11,%rsi
  1b3e0c:	cmovb  %rdx,%rsi
  1b3e10:	mov    %rbx,%r9
  1b3e13:	sub    %r12,%r9
  1b3e16:	cmovb  %rdx,%r9
  1b3e1a:	cmp    %r9,%rsi
  1b3e1d:	cmovb  %rsi,%r9
  1b3e21:	mov    %rbx,%rdi
  1b3e24:	sub    %r13,%rdi
  1b3e27:	cmovb  %rdx,%rdi
  1b3e2b:	cmp    %rdi,%r9
  1b3e2e:	cmovb  %r9,%rdi
  1b3e32:	cmp    %rdi,%r8
  1b3e35:	cmovb  %r8,%rdi
  1b3e39:	mov    %r13,%rbp
  1b3e3c:	shl    $0x4,%rbp
  1b3e40:	lea    (%r15,%rbp,1),%rsi
  1b3e44:	lea    (%r15,%rbp,1),%r9
  1b3e48:	add    $0x8,%r9
  1b3e4c:	shl    $0x4,%rdi
  1b3e50:	lea    (%rdi,%rsi,1),%rdx
  1b3e54:	add    $0x8,%rdx
  1b3e58:	cmp    %r9,%rdx
  1b3e5b:	jb     1b5a66 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbe6>
  1b3e61:	mov    %r9,0x40(%rsp)
  1b3e66:	mov    %rsi,0x10(%rsp)
  1b3e6b:	mov    (%rsp),%r10
  1b3e6f:	imul   $0x390,%r10,%rdx
  1b3e76:	mov    0x60(%rsp),%rsi
  1b3e7b:	shl    $0x4,%rsi
  1b3e7f:	lea    (%r15,%rdx,1),%r9
  1b3e83:	lea    (%rsi,%r9,1),%rbx
  1b3e87:	add    $0x8,%rbx
  1b3e8b:	add    %rsi,%r9
  1b3e8e:	add    %r9,%rdi
  1b3e91:	add    $0x8,%rdi
  1b3e95:	cmp    %rbx,%rdi
  1b3e98:	jb     1b5a3f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbbf>
  1b3e9e:	imul   $0x3a0,%r10,%rdi
  1b3ea5:	xor    %r10d,%r10d
  1b3ea8:	mov    0x8(%rsp),%r9
  1b3ead:	mov    %r9,%rbx
  1b3eb0:	sub    %r11,%rbx
  1b3eb3:	cmovb  %r10,%rbx
  1b3eb7:	mov    %r9,%r11
  1b3eba:	sub    %r12,%r11
  1b3ebd:	cmovb  %r10,%r11
  1b3ec1:	xor    %r12d,%r12d
  1b3ec4:	lea    (%rdi,%rsi,1),%r10
  1b3ec8:	cmp    %r11,%rbx
  1b3ecb:	cmovb  %rbx,%r11
  1b3ecf:	mov    %r9,%rbx
  1b3ed2:	sub    %r13,%rbx
  1b3ed5:	cmovb  %r12,%rbx
  1b3ed9:	lea    (%r15,%r10,1),%r12
  1b3edd:	cmp    %rbx,%r11
  1b3ee0:	cmovb  %r11,%rbx
  1b3ee4:	cmp    %rbx,%r8
  1b3ee7:	cmovb  %r8,%rbx
  1b3eeb:	shl    $0x4,%rbx
  1b3eef:	lea    (%rbx,%r12,1),%r9
  1b3ef3:	add    $0x8,%r9
  1b3ef7:	lea    (%r15,%r10,1),%r11
  1b3efb:	add    $0x8,%r11
  1b3eff:	lea    (%rbx,%r12,1),%r8
  1b3f03:	add    $0x10,%r8
  1b3f07:	add    %rbx,%rbp
  1b3f0a:	lea    (%r15,%rbp,1),%r10
  1b3f0e:	add    $0x10,%r10
  1b3f12:	lea    0x8(%r15,%rbp,1),%r13
  1b3f17:	mov    %r13,0x38(%rsp)
  1b3f1c:	lea    (%rdx,%rsi,1),%r13
  1b3f20:	mov    %r13,0xb0(%rsp)
  1b3f28:	add    %r15,%r13
  1b3f2b:	lea    0x8(%rbx,%r13,1),%rbp
  1b3f30:	mov    %rbp,0x50(%rsp)
  1b3f35:	add    %r13,%rbx
  1b3f38:	add    $0x10,%rbx
  1b3f3c:	mov    %rbx,0x20(%rsp)
  1b3f41:	cmp    %r8,%r12
  1b3f44:	setb   0x48(%rsp)
  1b3f49:	cmp    %r9,%r11
  1b3f4c:	setb   0x100(%rsp)
  1b3f54:	cmp    %r10,%r12
  1b3f57:	setb   0xd0(%rsp)
  1b3f5f:	mov    0x40(%rsp),%rbx
  1b3f64:	cmp    %r9,%rbx
  1b3f67:	setb   0xe0(%rsp)
  1b3f6f:	cmp    0x38(%rsp),%r12
  1b3f74:	setb   0x58(%rsp)
  1b3f79:	cmp    %r9,0x10(%rsp)
  1b3f7e:	setb   0x88(%rsp)
  1b3f86:	cmp    0x50(%rsp),%r12
  1b3f8b:	setb   0x78(%rsp)
  1b3f90:	cmp    %r9,%r13
  1b3f93:	setb   0x80(%rsp)
  1b3f9b:	cmp    0x20(%rsp),%r12
  1b3fa0:	mov    0xb0(%rsp),%r12
  1b3fa8:	lea    0x8(%r15,%r12,1),%rbp
  1b3fad:	setb   %r12b
  1b3fb1:	cmp    %r9,%rbp
  1b3fb4:	setb   0xb0(%rsp)
  1b3fbc:	cmp    %r10,%r11
  1b3fbf:	setb   0x98(%rsp)
  1b3fc7:	cmp    %r8,%rbx
  1b3fca:	setb   0x40(%rsp)
  1b3fcf:	cmp    0x38(%rsp),%r11
  1b3fd4:	setb   %r9b
  1b3fd8:	cmp    %r8,0x10(%rsp)
  1b3fdd:	setb   0x10(%rsp)
  1b3fe2:	cmp    0x50(%rsp),%r11
  1b3fe7:	setb   %r10b
  1b3feb:	cmp    %r8,%r13
  1b3fee:	setb   %r13b
  1b3ff2:	cmp    0x20(%rsp),%r11
  1b3ff7:	setb   %r11b
  1b3ffb:	cmp    %r8,%rbp
  1b3ffe:	setb   %r8b
  1b4002:	movzbl 0x100(%rsp),%ebx
  1b400a:	test   %bl,0x48(%rsp)
  1b400e:	jne    1b5a3f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbbf>
  1b4014:	movzbl 0xe0(%rsp),%ebx
  1b401c:	and    %bl,0xd0(%rsp)
  1b4023:	jne    1b5a3f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbbf>
  1b4029:	movzbl 0x88(%rsp),%ebx
  1b4031:	and    %bl,0x58(%rsp)
  1b4035:	mov    0x8(%rsp),%rbx
  1b403a:	jne    1b5a44 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbc4>
  1b4040:	movzbl 0x80(%rsp),%ebp
  1b4048:	and    %bpl,0x78(%rsp)
  1b404d:	jne    1b5a44 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbc4>
  1b4053:	and    0xb0(%rsp),%r12b
  1b405b:	jne    1b5a44 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbc4>
  1b4061:	movzbl 0x40(%rsp),%ebp
  1b4066:	and    %bpl,0x98(%rsp)
  1b406e:	mov    0x1d8(%rsp),%r12
  1b4076:	jne    1b5a4c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbcc>
  1b407c:	and    0x10(%rsp),%r9b
  1b4081:	jne    1b5a4c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcbcc>
  1b4087:	and    %r13b,%r10b
  1b408a:	mov    0x1c8(%rsp),%r10
  1b4092:	jne    1b5acc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc4c>
  1b4098:	and    %r8b,%r11b
  1b409b:	mov    0x1b0(%rsp),%r9
  1b40a3:	mov    0x60(%rsp),%r13
  1b40a8:	jne    1b5ac2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc42>
  1b40ae:	movabs $0x7fffffffffffffe,%r8
  1b40b8:	and    %r8,%rcx
  1b40bb:	add    %rcx,%r13
  1b40be:	movsd  (%r12),%xmm0
  1b40c4:	movsd  0x8(%r12),%xmm1
  1b40cb:	unpcklpd %xmm0,%xmm0
  1b40cf:	unpcklpd %xmm1,%xmm1
  1b40d3:	add    %r15,%rsi
  1b40d6:	mov    (%rsp),%r8
  1b40da:	shl    $0x4,%r8
  1b40de:	mov    0x28(%rsp),%r11
  1b40e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b40f0:	movupd (%rsi,%r8,1),%xmm2
  1b40f6:	movupd 0x10(%rsi,%r8,1),%xmm3
  1b40fd:	movapd %xmm2,%xmm4
  1b4101:	unpcklpd %xmm3,%xmm4
  1b4105:	unpckhpd %xmm3,%xmm2
  1b4109:	movapd %xmm2,%xmm3
  1b410d:	mulpd  %xmm0,%xmm3
  1b4111:	movapd %xmm0,%xmm5
  1b4115:	mulpd  %xmm4,%xmm5
  1b4119:	mulpd  %xmm1,%xmm4
  1b411d:	addpd  %xmm3,%xmm4
  1b4121:	movupd (%rsi,%rdx,1),%xmm3
  1b4126:	movupd 0x10(%rsi,%rdx,1),%xmm6
  1b412c:	movapd %xmm3,%xmm7
  1b4130:	unpcklpd %xmm6,%xmm7
  1b4134:	unpckhpd %xmm6,%xmm3
  1b4138:	movapd %xmm7,%xmm6
  1b413c:	mulpd  %xmm4,%xmm6
  1b4140:	mulpd  %xmm1,%xmm2
  1b4144:	subpd  %xmm2,%xmm5
  1b4148:	mulpd  %xmm5,%xmm7
  1b414c:	mulpd  %xmm3,%xmm5
  1b4150:	addpd  %xmm6,%xmm5
  1b4154:	mulpd  %xmm4,%xmm3
  1b4158:	subpd  %xmm3,%xmm7
  1b415c:	movapd %xmm7,%xmm2
  1b4160:	unpcklpd %xmm5,%xmm2
  1b4164:	unpckhpd %xmm5,%xmm7
  1b4168:	movupd %xmm7,0x10(%rsi,%rdi,1)
  1b416e:	movupd %xmm2,(%rsi,%rdi,1)
  1b4173:	add    $0x20,%rsi
  1b4177:	add    $0xfffffffffffffffe,%rcx
  1b417b:	jne    1b40f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb270>
  1b4181:	jmp    1b22da <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x945a>
  1b4186:	mov    0x8(%rsp),%rbx
  1b418b:	mov    0x28(%rsp),%r11
  1b4190:	mov    0x1c8(%rsp),%r10
  1b4198:	mov    0x60(%rsp),%r14
  1b419d:	mov    (%rsp),%rdi
  1b41a1:	imul   $0x420,%rdi,%rcx
  1b41a8:	mov    %r14,%rsi
  1b41ab:	shl    $0x4,%rsi
  1b41af:	add    %r15,%rsi
  1b41b2:	imul   $0x410,%rdi,%r8
  1b41b9:	imul   $0x270,%rdi,%r9
  1b41c0:	lea    (%rax,%r14,1),%rdi
  1b41c4:	cmp    %rbx,%rdi
  1b41c7:	jae    1be63c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x157bc>
  1b41cd:	mov    0x18(%rsp),%rdi
  1b41d2:	add    %r14,%rdi
  1b41d5:	cmp    %rbx,%rdi
  1b41d8:	jae    1be62c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x157ac>
  1b41de:	lea    (%rdx,%r14,1),%rdi
  1b41e2:	cmp    %rbx,%rdi
  1b41e5:	jae    1be61c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1579c>
  1b41eb:	inc    %r14
  1b41ee:	movupd (%rsi,%r9,1),%xmm0
  1b41f4:	movsd  (%rsi,%r8,1),%xmm1
  1b41fa:	movsd  0x8(%rsi,%r8,1),%xmm2
  1b4201:	unpcklpd %xmm1,%xmm1
  1b4205:	mulpd  %xmm0,%xmm1
  1b4209:	shufpd $0x1,%xmm0,%xmm0
  1b420e:	unpcklpd %xmm2,%xmm2
  1b4212:	mulpd  %xmm0,%xmm2
  1b4216:	movapd %xmm1,%xmm0
  1b421a:	subpd  %xmm2,%xmm0
  1b421e:	addpd  %xmm1,%xmm2
  1b4222:	movsd  %xmm0,%xmm2
  1b4226:	movupd %xmm2,(%rsi,%rcx,1)
  1b422b:	add    $0x10,%rsi
  1b422f:	cmp    %r14,0x30(%rsp)
  1b4234:	jne    1b41c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb340>
  1b4236:	mov    0x1b0(%rsp),%r9
  1b423e:	xor    %ecx,%ecx
  1b4240:	xorpd  %xmm0,%xmm0
  1b4244:	xor    %esi,%esi
  1b4246:	cs nopw 0x0(%rax,%rax,1)
  1b4250:	mov    (%r11,%rcx,8),%rdi
  1b4254:	lea    (%rdi,%rdx,1),%rax
  1b4258:	cmp    %rbx,%rax
  1b425b:	jae    1bd7c1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14941>
  1b4261:	shl    $0x4,%rax
  1b4265:	movsd  (%r15,%rax,1),%xmm1
  1b426b:	ucomisd %xmm0,%xmm1
  1b426f:	jne    1b42b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb430>
  1b4271:	jp     1b42b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb430>
  1b4273:	add    %r15,%rax
  1b4276:	movsd  0x8(%rax),%xmm1
  1b427b:	ucomisd %xmm0,%xmm1
  1b427f:	jne    1b42b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb430>
  1b4281:	jp     1b42b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb430>
  1b4283:	cmp    0x1d0(%rsp),%rdi
  1b428b:	jae    1be1ff <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1537f>
  1b4291:	movq   $0x41,(%r10,%rdi,8)
  1b4299:	inc    %rcx
  1b429c:	cmp    %rcx,%r12
  1b429f:	jne    1b4250 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb3d0>
  1b42a1:	jmp    1b42c8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb448>
  1b42a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b42b0:	cmp    %r9,%rsi
  1b42b3:	jae    1bdcb1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14e31>
  1b42b9:	mov    %rdi,(%r11,%rsi,8)
  1b42bd:	inc    %rsi
  1b42c0:	inc    %rcx
  1b42c3:	cmp    %rcx,%r12
  1b42c6:	jne    1b4250 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb3d0>
  1b42c8:	cmp    %r9,%rsi
  1b42cb:	ja     1bd399 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14519>
  1b42d1:	test   %rsi,%rsi
  1b42d4:	mov    0x1d0(%rsp),%rdx
  1b42dc:	mov    0x90(%rsp),%rcx
  1b42e4:	je     1b430e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb48e>
  1b42e6:	shl    $0x3,%rsi
  1b42ea:	xor    %eax,%eax
  1b42ec:	nopl   0x0(%rax)
  1b42f0:	mov    (%r11,%rax,1),%rdi
  1b42f4:	cmp    %rdx,%rdi
  1b42f7:	jae    1bdb69 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14ce9>
  1b42fd:	movq   $0x42,(%r10,%rdi,8)
  1b4305:	add    $0x8,%rax
  1b4309:	cmp    %rax,%rsi
  1b430c:	jne    1b42f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb470>
  1b430e:	xor    %eax,%eax
  1b4310:	xor    %esi,%esi
  1b4312:	mov    0x110(%rsp),%r8
  1b431a:	jmp    1b4329 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb4a9>
  1b431c:	nopl   0x0(%rax)
  1b4320:	add    $0x8,%rax
  1b4324:	cmp    %rax,%rcx
  1b4327:	je     1b434f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb4cf>
  1b4329:	mov    (%r8,%rax,1),%rdi
  1b432d:	cmp    %rdx,%rdi
  1b4330:	jae    1bd58a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1470a>
  1b4336:	cmpq   $0x42,(%r10,%rdi,8)
  1b433b:	jae    1b4320 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb4a0>
  1b433d:	cmp    %r9,%rsi
  1b4340:	jae    1bd9f6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14b76>
  1b4346:	mov    %rdi,(%r11,%rsi,8)
  1b434a:	inc    %rsi
  1b434d:	jmp    1b4320 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb4a0>
  1b434f:	cmp    %r9,%rsi
  1b4352:	ja     1b5b8d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd0d>
  1b4358:	test   %rsi,%rsi
  1b435b:	je     1b438f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb50f>
  1b435d:	mov    (%r11),%r14
  1b4360:	lea    -0x1(%rsi),%rax
  1b4364:	mov    -0x8(%r11,%rsi,8),%rcx
  1b4369:	sub    %r14,%rcx
  1b436c:	setae  %dl
  1b436f:	cmp    %rax,%rcx
  1b4372:	sete   %al
  1b4375:	and    %dl,%al
  1b4377:	cmp    $0x1,%al
  1b4379:	jne    1b4396 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb516>
  1b437b:	add    %r14,%rsi
  1b437e:	mov    0x1d0(%rsp),%rdx
  1b4386:	jae    1b43a3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb523>
  1b4388:	xor    %esi,%esi
  1b438a:	xor    %r14d,%r14d
  1b438d:	jmp    1b43a3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb523>
  1b438f:	xor    %esi,%esi
  1b4391:	xor    %r14d,%r14d
  1b4394:	jmp    1b43ab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb52b>
  1b4396:	xor    %esi,%esi
  1b4398:	xor    %r14d,%r14d
  1b439b:	mov    0x1d0(%rsp),%rdx
  1b43a3:	mov    0x90(%rsp),%rcx
  1b43ab:	xor    %eax,%eax
  1b43ad:	xor    %r12d,%r12d
  1b43b0:	jmp    1b43d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb550>
  1b43b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b43c0:	mov    %rdi,(%r11,%r12,8)
  1b43c4:	inc    %r12
  1b43c7:	add    $0x8,%rax
  1b43cb:	cmp    %rax,%rcx
  1b43ce:	je     1b43fc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb57c>
  1b43d0:	mov    (%r8,%rax,1),%rdi
  1b43d4:	cmp    %rdx,%rdi
  1b43d7:	jae    1bd59a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1471a>
  1b43dd:	cmpq   $0x43,(%r10,%rdi,8)
  1b43e2:	jae    1b43c7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb547>
  1b43e4:	cmp    %r9,%r12
  1b43e7:	jb     1b43c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb540>
  1b43e9:	lea    0x246e070(%rip),%rdx        # 2622460 <__gmpfr_one+0xace0>
  1b43f0:	mov    %r12,%rdi
  1b43f3:	mov    %r9,%rsi
  1b43f6:	call   *0x251ab04(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1b43fc:	cmp    %r9,%r12
  1b43ff:	ja     1b5b9f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd1f>
  1b4405:	test   %r12,%r12
  1b4408:	je     1b4ffe <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc17e>
  1b440e:	mov    (%r11),%rax
  1b4411:	lea    -0x1(%r12),%rcx
  1b4416:	mov    -0x8(%r11,%r12,8),%rdx
  1b441b:	sub    %rax,%rdx
  1b441e:	setae  %dil
  1b4422:	cmp    %rcx,%rdx
  1b4425:	sete   %cl
  1b4428:	and    %dil,%cl
  1b442b:	cmp    $0x1,%cl
  1b442e:	jne    1b4448 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb5c8>
  1b4430:	mov    %rax,%rcx
  1b4433:	add    %r12,%rcx
  1b4436:	jb     1b4448 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb5c8>
  1b4438:	mov    $0x1,%dl
  1b443a:	mov    %edx,0x60(%rsp)
  1b443e:	mov    %rcx,0x10(%rsp)
  1b4443:	mov    %rax,%r14
  1b4446:	jmp    1b4455 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb5d5>
  1b4448:	mov    %rsi,0x10(%rsp)
  1b444d:	movl   $0x0,0x60(%rsp)
  1b4455:	mov    %r14,0x30(%rsp)
  1b445a:	lea    0x0(,%r12,8),%rbp
  1b4462:	mov    (%rsp),%rcx
  1b4466:	mov    %rcx,%rax
  1b4469:	shl    $0x6,%rax
  1b446d:	lea    (%rax,%rcx,2),%r14
  1b4471:	imul   $0x47,%rcx,%rax
  1b4475:	mov    %rax,0x18(%rsp)
  1b447a:	xor    %r13d,%r13d
  1b447d:	xorpd  %xmm1,%xmm1
  1b4481:	jmp    1b44cd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb64d>
  1b4483:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b4490:	mov    $0x47,%r8d
  1b4496:	mov    $0x42,%r9d
  1b449c:	mov    %r15,%rdi
  1b449f:	mov    %rbx,%rsi
  1b44a2:	mov    (%rsp),%rdx
  1b44a6:	call   1a8d70 <oneloop::native::batch::copy_active_column::<f64>>
  1b44ab:	xorpd  %xmm1,%xmm1
  1b44af:	mov    0x1c8(%rsp),%r10
  1b44b7:	mov    0x28(%rsp),%r11
  1b44bc:	mov    0x1b0(%rsp),%r9
  1b44c4:	add    $0x8,%r13
  1b44c8:	cmp    %r13,%rbp
  1b44cb:	je     1b453d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb6bd>
  1b44cd:	mov    (%r11,%r13,1),%rcx
  1b44d1:	lea    (%rcx,%r14,1),%rdi
  1b44d5:	cmp    %rbx,%rdi
  1b44d8:	jae    1bd7d4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14954>
  1b44de:	shl    $0x4,%rdi
  1b44e2:	movsd  (%r15,%rdi,1),%xmm0
  1b44e8:	ucomisd %xmm1,%xmm0
  1b44ec:	jne    1b4490 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb610>
  1b44ee:	jp     1b4490 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb610>
  1b44f0:	add    %r15,%rdi
  1b44f3:	movsd  0x8(%rdi),%xmm0
  1b44f8:	ucomisd %xmm1,%xmm0
  1b44fc:	jne    1b4490 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb610>
  1b44fe:	jp     1b4490 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb610>
  1b4500:	add    0x18(%rsp),%rcx
  1b4505:	cmp    %rbx,%rcx
  1b4508:	jae    1be214 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15394>
  1b450e:	cmpq   $0x3,0x1e0(%rsp)
  1b4517:	jbe    1bd65a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x147da>
  1b451d:	shl    $0x4,%rcx
  1b4521:	mov    0x1d8(%rsp),%rax
  1b4529:	movupd 0x30(%rax),%xmm0
  1b452e:	movupd %xmm0,(%r15,%rcx,1)
  1b4534:	add    $0x8,%r13
  1b4538:	cmp    %r13,%rbp
  1b453b:	jne    1b44cd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb64d>
  1b453d:	mov    (%rsp),%rax
  1b4541:	lea    0x0(,%rax,8),%rax
  1b4549:	lea    (%rax,%rax,8),%rcx
  1b454d:	xor    %edx,%edx
  1b454f:	movabs $0x8000000000000000,%rsi
  1b4559:	mov    0x18(%rsp),%r14
  1b455e:	xchg   %ax,%ax
  1b4560:	mov    (%r11,%rdx,1),%rdi
  1b4564:	lea    (%rdi,%r14,1),%rax
  1b4568:	cmp    %rbx,%rax
  1b456b:	jae    1bd7f4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14974>
  1b4571:	add    %rcx,%rdi
  1b4574:	cmp    %rbx,%rdi
  1b4577:	jae    1bd7e4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14964>
  1b457d:	shl    $0x4,%rax
  1b4581:	movsd  (%r15,%rax,1),%xmm0
  1b4587:	shl    $0x4,%rdi
  1b458b:	mov    0x8(%r15,%rax,1),%rax
  1b4590:	xor    %rsi,%rax
  1b4593:	movsd  %xmm0,(%r15,%rdi,1)
  1b4599:	mov    %rax,0x8(%r15,%rdi,1)
  1b459e:	add    $0x8,%rdx
  1b45a2:	cmp    %rdx,%rbp
  1b45a5:	jne    1b4560 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb6e0>
  1b45a7:	cmpb   $0x0,0x60(%rsp)
  1b45ac:	je     1b4a64 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbbe4>
  1b45b2:	mov    0x10(%rsp),%rdi
  1b45b7:	cmp    %rdi,0x30(%rsp)
  1b45bc:	mov    0x110(%rsp),%r8
  1b45c4:	jae    1b4b6a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbcea>
  1b45ca:	cmpq   $0x2,0x1e0(%rsp)
  1b45d3:	mov    (%rsp),%rax
  1b45d7:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b45dd:	lea    (%rax,%rax,8),%rdx
  1b45e1:	mov    %rdx,0x20(%rsp)
  1b45e6:	lea    (%rax,%rdx,8),%rax
  1b45ea:	mov    0x30(%rsp),%r13
  1b45ef:	lea    (%rcx,%r13,1),%r14
  1b45f3:	xor    %esi,%esi
  1b45f5:	mov    %rbx,%rdx
  1b45f8:	sub    %r14,%rdx
  1b45fb:	cmovb  %rsi,%rdx
  1b45ff:	lea    (%rax,%r13,1),%rbp
  1b4603:	mov    %rbx,%r8
  1b4606:	sub    %rbp,%r8
  1b4609:	cmovb  %rsi,%r8
  1b460d:	cmp    %r8,%rdx
  1b4610:	mov    %r8,0x60(%rsp)
  1b4615:	cmovae %r8,%rdx
  1b4619:	mov    %r13,%rsi
  1b461c:	not    %rsi
  1b461f:	add    %rdi,%rsi
  1b4622:	cmp    %rsi,%rdx
  1b4625:	cmovae %rsi,%rdx
  1b4629:	lea    0x1(%rdx),%rdi
  1b462d:	mov    %r13,%r11
  1b4630:	cmp    $0x22,%rdi
  1b4634:	ja     1b4b74 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbcf4>
  1b463a:	mov    (%rsp),%r14
  1b463e:	imul   $0x490,%r14,%r8
  1b4645:	mov    %r11,%rdx
  1b4648:	shl    $0x4,%rdx
  1b464c:	add    %r15,%rdx
  1b464f:	mov    %r14,%rdi
  1b4652:	shl    $0x7,%rdi
  1b4656:	lea    (%rdi,%rdi,8),%r10
  1b465a:	mov    0x18(%rsp),%r13
  1b465f:	nop
  1b4660:	lea    (%rcx,%r11,1),%rdi
  1b4664:	cmp    %rbx,%rdi
  1b4667:	jae    1be65c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x157dc>
  1b466d:	lea    (%rax,%r11,1),%rdi
  1b4671:	cmp    %rbx,%rdi
  1b4674:	jae    1be64c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x157cc>
  1b467a:	inc    %r11
  1b467d:	mov    0x1d8(%rsp),%rdi
  1b4685:	movupd 0x10(%rdi),%xmm0
  1b468a:	movsd  (%rdx,%r10,1),%xmm1
  1b4690:	movsd  0x8(%rdx,%r10,1),%xmm2
  1b4697:	unpcklpd %xmm1,%xmm1
  1b469b:	mulpd  %xmm0,%xmm1
  1b469f:	shufpd $0x1,%xmm0,%xmm0
  1b46a4:	unpcklpd %xmm2,%xmm2
  1b46a8:	mulpd  %xmm0,%xmm2
  1b46ac:	movapd %xmm1,%xmm0
  1b46b0:	subpd  %xmm2,%xmm0
  1b46b4:	addpd  %xmm1,%xmm2
  1b46b8:	movsd  %xmm0,%xmm2
  1b46bc:	movupd %xmm2,(%rdx,%r8,1)
  1b46c2:	add    $0x10,%rdx
  1b46c6:	cmp    %r11,0x10(%rsp)
  1b46cb:	jne    1b4660 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb7e0>
  1b46cd:	imul   $0x4a,%r14,%rdx
  1b46d1:	mov    0x30(%rsp),%rbp
  1b46d6:	mov    %rbp,%r11
  1b46d9:	add    %r13,%r11
  1b46dc:	xor    %edi,%edi
  1b46de:	mov    %rbx,%r10
  1b46e1:	sub    %r11,%r10
  1b46e4:	cmovb  %rdi,%r10
  1b46e8:	mov    0x60(%rsp),%rcx
  1b46ed:	cmp    %rcx,%r10
  1b46f0:	cmovae %rcx,%r10
  1b46f4:	lea    (%rdx,%rbp,1),%r9
  1b46f8:	mov    %rbx,%rcx
  1b46fb:	sub    %r9,%rcx
  1b46fe:	cmovb  %rdi,%rcx
  1b4702:	cmp    %rcx,%r10
  1b4705:	cmovb  %r10,%rcx
  1b4709:	cmp    %rsi,%rcx
  1b470c:	cmovae %rsi,%rcx
  1b4710:	lea    0x1(%rcx),%rdi
  1b4714:	cmp    $0x42,%rdi
  1b4718:	jbe    1b4dfb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbf7b>
  1b471e:	xor    %edi,%edi
  1b4720:	mov    %rbx,%r10
  1b4723:	mov    %r11,0x20(%rsp)
  1b4728:	sub    %r11,%r10
  1b472b:	cmovb  %rdi,%r10
  1b472f:	mov    0x60(%rsp),%r11
  1b4734:	cmp    %r11,%r10
  1b4737:	cmovae %r11,%r10
  1b473b:	mov    %rbx,%r11
  1b473e:	mov    %r9,0x50(%rsp)
  1b4743:	sub    %r9,%r11
  1b4746:	cmovb  %rdi,%r11
  1b474a:	cmp    %r11,%r10
  1b474d:	cmovb  %r10,%r11
  1b4751:	cmp    %rsi,%r11
  1b4754:	cmovae %rsi,%r11
  1b4758:	imul   $0x470,%r14,%rdi
  1b475f:	mov    %rbp,%r10
  1b4762:	shl    $0x4,%r10
  1b4766:	lea    (%r15,%rdi,1),%rbx
  1b476a:	lea    (%r10,%rbx,1),%r13
  1b476e:	add    $0x8,%r13
  1b4772:	add    %r10,%rbx
  1b4775:	mov    %r11,%r14
  1b4778:	shl    $0x4,%r14
  1b477c:	add    %r14,%rbx
  1b477f:	add    $0x8,%rbx
  1b4783:	cmp    %r13,%rbx
  1b4786:	jb     1b4df1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbf71>
  1b478c:	lea    (%r15,%r8,1),%rbx
  1b4790:	lea    (%r10,%rbx,1),%r13
  1b4794:	add    $0x8,%r13
  1b4798:	add    %r10,%rbx
  1b479b:	add    %r14,%rbx
  1b479e:	add    $0x8,%rbx
  1b47a2:	cmp    %r13,%rbx
  1b47a5:	jb     1b4df1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbf71>
  1b47ab:	movabs $0xfffffffffffffff,%rbx
  1b47b5:	cmp    %rbx,%r11
  1b47b8:	mov    0x8(%rsp),%rbx
  1b47bd:	ja     1b4df6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbf76>
  1b47c3:	imul   $0x4a0,(%rsp),%rbp
  1b47cb:	xor    %r13d,%r13d
  1b47ce:	mov    %rbx,%r14
  1b47d1:	sub    0x20(%rsp),%r14
  1b47d6:	cmovb  %r13,%r14
  1b47da:	mov    0x60(%rsp),%r9
  1b47df:	cmp    %r9,%r14
  1b47e2:	cmovae %r9,%r14
  1b47e6:	sub    0x50(%rsp),%rbx
  1b47eb:	cmovb  %r13,%rbx
  1b47ef:	cmp    %rbx,%r14
  1b47f2:	cmovb  %r14,%rbx
  1b47f6:	lea    (%r10,%rbp,1),%r9
  1b47fa:	cmp    %rsi,%rbx
  1b47fd:	cmovae %rsi,%rbx
  1b4801:	lea    (%r15,%r9,1),%rsi
  1b4805:	shl    $0x4,%rbx
  1b4809:	lea    (%rbx,%rsi,1),%r13
  1b480d:	add    $0x8,%r13
  1b4811:	lea    0x8(%r15,%r9,1),%r9
  1b4816:	mov    %r9,0x88(%rsp)
  1b481e:	lea    0x10(%rbx,%rsi,1),%r9
  1b4823:	mov    %r9,0x60(%rsp)
  1b4828:	lea    (%rdi,%r10,1),%r9
  1b482c:	lea    (%r15,%r9,1),%r11
  1b4830:	lea    0x8(%r15,%r9,1),%r9
  1b4835:	mov    %r9,0xe0(%rsp)
  1b483d:	lea    0x10(%rbx,%r11,1),%r9
  1b4842:	mov    %r11,0xd0(%rsp)
  1b484a:	mov    %r9,0x48(%rsp)
  1b484f:	lea    (%r8,%r10,1),%r9
  1b4853:	lea    (%r15,%r9,1),%r14
  1b4857:	lea    0x8(%r15,%r9,1),%r9
  1b485c:	mov    %r9,0x38(%rsp)
  1b4861:	mov    %r14,%r9
  1b4864:	mov    %r14,0x50(%rsp)
  1b4869:	lea    0x10(%rbx,%r14,1),%r14
  1b486e:	mov    %r14,0x58(%rsp)
  1b4873:	lea    0x8(%rbx,%r11,1),%r11
  1b4878:	mov    %r11,0x40(%rsp)
  1b487d:	add    %rbx,%r9
  1b4880:	add    $0x8,%r9
  1b4884:	mov    %r9,0x20(%rsp)
  1b4889:	cmp    0x60(%rsp),%rsi
  1b488e:	setb   0x100(%rsp)
  1b4896:	mov    0x88(%rsp),%r14
  1b489e:	cmp    %r13,%r14
  1b48a1:	setb   0xb0(%rsp)
  1b48a9:	cmp    0x48(%rsp),%rsi
  1b48ae:	setb   0x78(%rsp)
  1b48b3:	mov    0xe0(%rsp),%r9
  1b48bb:	cmp    %r13,%r9
  1b48be:	setb   0x80(%rsp)
  1b48c6:	mov    0x58(%rsp),%r11
  1b48cb:	cmp    %r11,%rsi
  1b48ce:	setb   0x98(%rsp)
  1b48d6:	cmp    %r13,0x38(%rsp)
  1b48db:	setb   0xc8(%rsp)
  1b48e3:	cmp    0x40(%rsp),%rsi
  1b48e8:	setb   0xa8(%rsp)
  1b48f0:	mov    0xd0(%rsp),%rbx
  1b48f8:	cmp    %r13,%rbx
  1b48fb:	setb   0xf8(%rsp)
  1b4903:	cmp    0x20(%rsp),%rsi
  1b4908:	setb   0x118(%rsp)
  1b4910:	cmp    %r13,0x50(%rsp)
  1b4915:	setb   0x120(%rsp)
  1b491d:	mov    %r14,%r13
  1b4920:	cmp    0x48(%rsp),%r14
  1b4925:	setb   %r14b
  1b4929:	mov    0x60(%rsp),%rsi
  1b492e:	cmp    %rsi,%r9
  1b4931:	setb   0x48(%rsp)
  1b4936:	cmp    %r11,%r13
  1b4939:	setb   0xe0(%rsp)
  1b4941:	cmp    %rsi,0x38(%rsp)
  1b4946:	setb   0x38(%rsp)
  1b494b:	cmp    0x40(%rsp),%r13
  1b4950:	setb   0x40(%rsp)
  1b4955:	cmp    %rsi,%rbx
  1b4958:	setb   %bl
  1b495b:	cmp    0x20(%rsp),%r13
  1b4960:	setb   %r9b
  1b4964:	cmp    %rsi,0x50(%rsp)
  1b4969:	setb   %r11b
  1b496d:	movzbl 0xb0(%rsp),%esi
  1b4975:	test   %sil,0x100(%rsp)
  1b497d:	jne    1b4df1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbf71>
  1b4983:	mov    %r11b,0x60(%rsp)
  1b4988:	movzbl 0x80(%rsp),%r11d
  1b4991:	and    %r11b,0x78(%rsp)
  1b4996:	jne    1b4df1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbf71>
  1b499c:	mov    %r14d,%esi
  1b499f:	movzbl 0xc8(%rsp),%r11d
  1b49a8:	and    %r11b,0x98(%rsp)
  1b49b0:	mov    0x18(%rsp),%r13
  1b49b5:	mov    0x10(%rsp),%r14
  1b49ba:	jne    1b5a97 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc17>
  1b49c0:	movzbl 0xf8(%rsp),%r11d
  1b49c9:	and    %r11b,0xa8(%rsp)
  1b49d1:	jne    1b5a97 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc17>
  1b49d7:	movzbl 0x120(%rsp),%r11d
  1b49e0:	and    %r11b,0x118(%rsp)
  1b49e8:	jne    1b5a97 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc17>
  1b49ee:	and    0x48(%rsp),%sil
  1b49f3:	jne    1b5a97 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc17>
  1b49f9:	movzbl 0x38(%rsp),%esi
  1b49fe:	and    %sil,0xe0(%rsp)
  1b4a06:	jne    1b5a97 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc17>
  1b4a0c:	and    %bl,0x40(%rsp)
  1b4a10:	jne    1b5a97 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcc17>
  1b4a16:	and    0x60(%rsp),%r9b
  1b4a1b:	mov    0x8(%rsp),%rbx
  1b4a20:	jne    1b4e00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbf80>
  1b4a26:	and    $0xfffffffffffffffe,%rcx
  1b4a2a:	add    %rcx,0x30(%rsp)
  1b4a2f:	add    %r15,%r10
  1b4a32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b4a40:	movupd (%r10,%rdi,1),%xmm0
  1b4a46:	movupd (%r10,%r8,1),%xmm1
  1b4a4c:	addpd  %xmm0,%xmm1
  1b4a50:	movupd %xmm1,(%r10,%rbp,1)
  1b4a56:	add    $0x10,%r10
  1b4a5a:	dec    %rcx
  1b4a5d:	jne    1b4a40 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbbc0>
  1b4a5f:	jmp    1b4e00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbf80>
  1b4a64:	cmpq   $0x2,0x1e0(%rsp)
  1b4a6d:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b4a73:	mov    (%rsp),%rdx
  1b4a77:	lea    (%rdx,%rdx,8),%rax
  1b4a7b:	lea    (%rdx,%rax,8),%rsi
  1b4a7f:	xor    %edx,%edx
  1b4a81:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b4a90:	mov    (%r11,%rdx,1),%rdi
  1b4a94:	lea    (%rdi,%rcx,1),%rax
  1b4a98:	cmp    %rbx,%rax
  1b4a9b:	jae    1bdeba <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1503a>
  1b4aa1:	add    %rsi,%rdi
  1b4aa4:	cmp    %rbx,%rdi
  1b4aa7:	jae    1bdeaa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1502a>
  1b4aad:	shl    $0x4,%rax
  1b4ab1:	shl    $0x4,%rdi
  1b4ab5:	mov    0x1d8(%rsp),%r8
  1b4abd:	movupd 0x10(%r8),%xmm0
  1b4ac3:	movsd  (%r15,%rax,1),%xmm1
  1b4ac9:	movsd  0x8(%r15,%rax,1),%xmm2
  1b4ad0:	unpcklpd %xmm1,%xmm1
  1b4ad4:	mulpd  %xmm0,%xmm1
  1b4ad8:	shufpd $0x1,%xmm0,%xmm0
  1b4add:	unpcklpd %xmm2,%xmm2
  1b4ae1:	mulpd  %xmm0,%xmm2
  1b4ae5:	movapd %xmm1,%xmm0
  1b4ae9:	subpd  %xmm2,%xmm0
  1b4aed:	addpd  %xmm1,%xmm2
  1b4af1:	movsd  %xmm0,%xmm2
  1b4af5:	movupd %xmm2,(%r15,%rdi,1)
  1b4afb:	add    $0x8,%rdx
  1b4aff:	cmp    %rdx,%rbp
  1b4b02:	jne    1b4a90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbc10>
  1b4b04:	imul   $0x4a,(%rsp),%rdx
  1b4b09:	xor    %r8d,%r8d
  1b4b0c:	nopl   0x0(%rax)
  1b4b10:	mov    (%r11,%r8,1),%rdi
  1b4b14:	lea    (%rdi,%r14,1),%rax
  1b4b18:	cmp    %rbx,%rax
  1b4b1b:	jae    1bdef0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15070>
  1b4b21:	lea    (%rdi,%rsi,1),%rcx
  1b4b25:	cmp    %rbx,%rcx
  1b4b28:	jae    1bdedd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1505d>
  1b4b2e:	add    %rdx,%rdi
  1b4b31:	cmp    %rbx,%rdi
  1b4b34:	jae    1bdecd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1504d>
  1b4b3a:	shl    $0x4,%rax
  1b4b3e:	shl    $0x4,%rcx
  1b4b42:	shl    $0x4,%rdi
  1b4b46:	movupd (%r15,%rax,1),%xmm0
  1b4b4c:	movupd (%r15,%rcx,1),%xmm1
  1b4b52:	addpd  %xmm0,%xmm1
  1b4b56:	movupd %xmm1,(%r15,%rdi,1)
  1b4b5c:	add    $0x8,%r8
  1b4b60:	cmp    %r8,%rbp
  1b4b63:	jne    1b4b10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbc90>
  1b4b65:	jmp    1b4e82 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc002>
  1b4b6a:	imul   $0x4a,(%rsp),%rdx
  1b4b6f:	jmp    1b4e8a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc00a>
  1b4b74:	xor    %edi,%edi
  1b4b76:	mov    %rbx,%r8
  1b4b79:	sub    %r14,%r8
  1b4b7c:	cmovb  %rdi,%r8
  1b4b80:	mov    %rbx,%r10
  1b4b83:	sub    %rbp,%r10
  1b4b86:	cmovb  %rdi,%r10
  1b4b8a:	cmp    %r10,%r8
  1b4b8d:	cmovb  %r8,%r10
  1b4b91:	cmp    %rsi,%r10
  1b4b94:	cmovae %rsi,%r10
  1b4b98:	mov    (%rsp),%rdi
  1b4b9c:	shl    $0x7,%rdi
  1b4ba0:	lea    (%rdi,%rdi,8),%rdi
  1b4ba4:	mov    %r13,%r8
  1b4ba7:	shl    $0x4,%r8
  1b4bab:	lea    (%r15,%rdi,1),%r11
  1b4baf:	lea    (%r8,%r11,1),%rbx
  1b4bb3:	add    $0x8,%rbx
  1b4bb7:	add    %r8,%r11
  1b4bba:	mov    %r14,0x50(%rsp)
  1b4bbf:	mov    %r10,%r14
  1b4bc2:	shl    $0x4,%r14
  1b4bc6:	add    %r11,%r14
  1b4bc9:	add    $0x8,%r14
  1b4bcd:	mov    %r13,%r11
  1b4bd0:	cmp    %rbx,%r14
  1b4bd3:	mov    0x8(%rsp),%rbx
  1b4bd8:	jb     1b463a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb7ba>
  1b4bde:	mov    %r13,%r11
  1b4be1:	movabs $0xfffffffffffffff,%r14
  1b4beb:	cmp    %r14,%r10
  1b4bee:	mov    0x50(%rsp),%r14
  1b4bf3:	ja     1b463a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb7ba>
  1b4bf9:	imul   $0x490,(%rsp),%r10
  1b4c01:	xor    %r11d,%r11d
  1b4c04:	mov    0x8(%rsp),%rbx
  1b4c09:	sub    %r14,%rbx
  1b4c0c:	cmovb  %r11,%rbx
  1b4c10:	mov    0x8(%rsp),%r14
  1b4c15:	sub    %rbp,%r14
  1b4c18:	cmovb  %r11,%r14
  1b4c1c:	lea    (%r10,%r8,1),%r11
  1b4c20:	cmp    %r14,%rbx
  1b4c23:	cmovb  %rbx,%r14
  1b4c27:	lea    (%r15,%r11,1),%rbx
  1b4c2b:	cmp    %rsi,%r14
  1b4c2e:	cmovae %rsi,%r14
  1b4c32:	shl    $0x4,%r14
  1b4c36:	mov    %rsi,0x48(%rsp)
  1b4c3b:	lea    (%r14,%rbx,1),%rsi
  1b4c3f:	add    $0x8,%rsi
  1b4c43:	lea    0x8(%r15,%r11,1),%r9
  1b4c48:	mov    %r9,0x100(%rsp)
  1b4c50:	lea    (%r14,%rbx,1),%r9
  1b4c54:	add    $0x10,%r9
  1b4c58:	mov    %r9,0x50(%rsp)
  1b4c5d:	mov    0x20(%rsp),%r9
  1b4c62:	shl    $0x7,%r9
  1b4c66:	add    %r8,%r9
  1b4c69:	lea    (%r15,%r9,1),%r11
  1b4c6d:	lea    (%r14,%r11,1),%rbp
  1b4c71:	add    $0x8,%rbp
  1b4c75:	add    %r11,%r14
  1b4c78:	add    $0x10,%r14
  1b4c7c:	mov    %r14,0x20(%rsp)
  1b4c81:	cmp    0x50(%rsp),%rbx
  1b4c86:	setb   0x38(%rsp)
  1b4c8b:	mov    0x100(%rsp),%r14
  1b4c93:	cmp    %rsi,%r14
  1b4c96:	setb   0x40(%rsp)
  1b4c9b:	cmp    %rbp,%rbx
  1b4c9e:	setb   0xb0(%rsp)
  1b4ca6:	cmp    %rsi,%r11
  1b4ca9:	setb   0xd0(%rsp)
  1b4cb1:	cmp    0x20(%rsp),%rbx
  1b4cb6:	lea    0x8(%r15,%r9,1),%rbx
  1b4cbb:	setb   0xe0(%rsp)
  1b4cc3:	cmp    %rsi,%rbx
  1b4cc6:	mov    0x48(%rsp),%rsi
  1b4ccb:	setb   0x58(%rsp)
  1b4cd0:	cmp    %rbp,%r14
  1b4cd3:	setb   0x88(%rsp)
  1b4cdb:	mov    0x50(%rsp),%rbp
  1b4ce0:	cmp    %rbp,%r11
  1b4ce3:	setb   0x78(%rsp)
  1b4ce8:	cmp    0x20(%rsp),%r14
  1b4ced:	setb   %r9b
  1b4cf1:	cmp    %rbp,%rbx
  1b4cf4:	mov    0x8(%rsp),%rbx
  1b4cf9:	setb   %bpl
  1b4cfd:	mov    %r13,%r11
  1b4d00:	movzbl 0x40(%rsp),%r14d
  1b4d06:	test   %r14b,0x38(%rsp)
  1b4d0b:	jne    1b463a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb7ba>
  1b4d11:	mov    %r13,%r11
  1b4d14:	movzbl 0xd0(%rsp),%r14d
  1b4d1d:	and    %r14b,0xb0(%rsp)
  1b4d25:	jne    1b463a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb7ba>
  1b4d2b:	mov    %r13,%r11
  1b4d2e:	movzbl 0x58(%rsp),%r14d
  1b4d34:	and    %r14b,0xe0(%rsp)
  1b4d3c:	jne    1b463a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb7ba>
  1b4d42:	mov    %r13,%r11
  1b4d45:	movzbl 0x78(%rsp),%r14d
  1b4d4b:	and    %r14b,0x88(%rsp)
  1b4d53:	jne    1b463a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb7ba>
  1b4d59:	mov    %r13,%r11
  1b4d5c:	and    %bpl,%r9b
  1b4d5f:	jne    1b463a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb7ba>
  1b4d65:	and    $0xfffffffffffffffe,%rdx
  1b4d69:	lea    (%rdx,%r13,1),%r11
  1b4d6d:	mov    0x1d8(%rsp),%r14
  1b4d75:	movsd  0x10(%r14),%xmm0
  1b4d7b:	movsd  0x18(%r14),%xmm1
  1b4d81:	unpcklpd %xmm1,%xmm1
  1b4d85:	unpcklpd %xmm0,%xmm0
  1b4d89:	add    %r15,%r8
  1b4d8c:	nopl   0x0(%rax)
  1b4d90:	movupd (%r8,%rdi,1),%xmm2
  1b4d96:	movupd 0x10(%r8,%rdi,1),%xmm3
  1b4d9d:	movapd %xmm2,%xmm4
  1b4da1:	unpcklpd %xmm3,%xmm4
  1b4da5:	unpckhpd %xmm3,%xmm2
  1b4da9:	movapd %xmm1,%xmm3
  1b4dad:	mulpd  %xmm4,%xmm3
  1b4db1:	movapd %xmm0,%xmm5
  1b4db5:	mulpd  %xmm2,%xmm5
  1b4db9:	addpd  %xmm3,%xmm5
  1b4dbd:	mulpd  %xmm0,%xmm4
  1b4dc1:	mulpd  %xmm1,%xmm2
  1b4dc5:	subpd  %xmm2,%xmm4
  1b4dc9:	movapd %xmm4,%xmm2
  1b4dcd:	unpcklpd %xmm5,%xmm2
  1b4dd1:	unpckhpd %xmm5,%xmm4
  1b4dd5:	movupd %xmm4,0x10(%r8,%r10,1)
  1b4ddc:	movupd %xmm2,(%r8,%r10,1)
  1b4de2:	add    $0x20,%r8
  1b4de6:	add    $0xfffffffffffffffe,%rdx
  1b4dea:	jne    1b4d90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbf10>
  1b4dec:	jmp    1b463a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb7ba>
  1b4df1:	mov    0x8(%rsp),%rbx
  1b4df6:	mov    0x18(%rsp),%r13
  1b4dfb:	mov    0x10(%rsp),%r14
  1b4e00:	mov    (%rsp),%rdi
  1b4e04:	imul   $0x4a0,%rdi,%rcx
  1b4e0b:	mov    0x30(%rsp),%rbp
  1b4e10:	mov    %rbp,%rsi
  1b4e13:	shl    $0x4,%rsi
  1b4e17:	add    %r15,%rsi
  1b4e1a:	imul   $0x470,%rdi,%r9
  1b4e21:	mov    0x28(%rsp),%r11
  1b4e26:	mov    0x1c8(%rsp),%r10
  1b4e2e:	xchg   %ax,%ax
  1b4e30:	mov    %r13,%rdi
  1b4e33:	add    %rbp,%rdi
  1b4e36:	cmp    %rbx,%rdi
  1b4e39:	jae    1be68c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1580c>
  1b4e3f:	lea    (%rax,%rbp,1),%rdi
  1b4e43:	cmp    %rbx,%rdi
  1b4e46:	jae    1be67c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x157fc>
  1b4e4c:	lea    (%rdx,%rbp,1),%rdi
  1b4e50:	cmp    %rbx,%rdi
  1b4e53:	jae    1be66c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x157ec>
  1b4e59:	inc    %rbp
  1b4e5c:	movupd (%rsi,%r9,1),%xmm0
  1b4e62:	movupd (%rsi,%r8,1),%xmm1
  1b4e68:	addpd  %xmm0,%xmm1
  1b4e6c:	movupd %xmm1,(%rsi,%rcx,1)
  1b4e71:	add    $0x10,%rsi
  1b4e75:	cmp    %rbp,%r14
  1b4e78:	jne    1b4e30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbfb0>
  1b4e7a:	mov    0x1b0(%rsp),%r9
  1b4e82:	mov    0x110(%rsp),%r8
  1b4e8a:	xor    %ecx,%ecx
  1b4e8c:	xorpd  %xmm0,%xmm0
  1b4e90:	xor    %r14d,%r14d
  1b4e93:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b4ea0:	mov    (%r11,%rcx,8),%rdi
  1b4ea4:	lea    (%rdi,%rdx,1),%rax
  1b4ea8:	cmp    %rbx,%rax
  1b4eab:	jae    1bd807 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14987>
  1b4eb1:	shl    $0x4,%rax
  1b4eb5:	movsd  (%r15,%rax,1),%xmm1
  1b4ebb:	ucomisd %xmm0,%xmm1
  1b4ebf:	jne    1b4f00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc080>
  1b4ec1:	jp     1b4f00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc080>
  1b4ec3:	add    %r15,%rax
  1b4ec6:	movsd  0x8(%rax),%xmm1
  1b4ecb:	ucomisd %xmm0,%xmm1
  1b4ecf:	jne    1b4f00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc080>
  1b4ed1:	jp     1b4f00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc080>
  1b4ed3:	cmp    0x1d0(%rsp),%rdi
  1b4edb:	jae    1be227 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x153a7>
  1b4ee1:	movq   $0x4a,(%r10,%rdi,8)
  1b4ee9:	inc    %rcx
  1b4eec:	cmp    %rcx,%r12
  1b4eef:	jne    1b4ea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc020>
  1b4ef1:	jmp    1b4f18 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc098>
  1b4ef3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b4f00:	cmp    %r9,%r14
  1b4f03:	jae    1bdcfa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14e7a>
  1b4f09:	mov    %rdi,(%r11,%r14,8)
  1b4f0d:	inc    %r14
  1b4f10:	inc    %rcx
  1b4f13:	cmp    %rcx,%r12
  1b4f16:	jne    1b4ea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc020>
  1b4f18:	cmp    %r9,%r14
  1b4f1b:	ja     1bd3ab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1452b>
  1b4f21:	test   %r14,%r14
  1b4f24:	mov    0x1d0(%rsp),%rdx
  1b4f2c:	mov    0x90(%rsp),%rcx
  1b4f34:	je     1b4ffe <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc17e>
  1b4f3a:	shl    $0x3,%r14
  1b4f3e:	imul   $0x4c,(%rsp),%r13
  1b4f43:	xor    %ebp,%ebp
  1b4f45:	data16 cs nopw 0x0(%rax,%rax,1)
  1b4f50:	mov    (%r11,%rbp,1),%r12
  1b4f54:	mov    0x18(%rsp),%rax
  1b4f59:	lea    (%r12,%rax,1),%rdi
  1b4f5d:	cmp    %rbx,%rdi
  1b4f60:	jae    1bdb8c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14d0c>
  1b4f66:	shl    $0x4,%rdi
  1b4f6a:	movsd  (%r15,%rdi,1),%xmm0
  1b4f70:	movsd  0x8(%r15,%rdi,1),%xmm1
  1b4f77:	call   1a8a60 <oneloop::native::primitives::log::<f64>>
  1b4f7c:	add    %r13,%r12
  1b4f7f:	cmp    %rbx,%r12
  1b4f82:	jae    1bdb79 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14cf9>
  1b4f88:	shl    $0x4,%r12
  1b4f8c:	movsd  %xmm0,(%r15,%r12,1)
  1b4f92:	movsd  %xmm1,0x8(%r15,%r12,1)
  1b4f99:	add    $0x8,%rbp
  1b4f9d:	cmp    %rbp,%r14
  1b4fa0:	mov    0x1b0(%rsp),%r9
  1b4fa8:	mov    0x28(%rsp),%r11
  1b4fad:	mov    0x1d0(%rsp),%rdx
  1b4fb5:	mov    0x90(%rsp),%rcx
  1b4fbd:	mov    0x110(%rsp),%r8
  1b4fc5:	mov    0x1c8(%rsp),%r10
  1b4fcd:	jne    1b4f50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc0d0>
  1b4fcf:	xor    %eax,%eax
  1b4fd1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b4fe0:	mov    (%r11,%rax,1),%rdi
  1b4fe4:	cmp    %rdx,%rdi
  1b4fe7:	jae    1bdb9c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14d1c>
  1b4fed:	movq   $0x59,(%r10,%rdi,8)
  1b4ff5:	add    $0x8,%rax
  1b4ff9:	cmp    %rax,%r14
  1b4ffc:	jne    1b4fe0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc160>
  1b4ffe:	xor    %eax,%eax
  1b5000:	xor    %r12d,%r12d
  1b5003:	jmp    1b5019 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc199>
  1b5005:	data16 cs nopw 0x0(%rax,%rax,1)
  1b5010:	add    $0x8,%rax
  1b5014:	cmp    %rax,%rcx
  1b5017:	je     1b503f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc1bf>
  1b5019:	mov    (%r8,%rax,1),%rdi
  1b501d:	cmp    %rdx,%rdi
  1b5020:	jae    1bd5aa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1472a>
  1b5026:	cmpq   $0x4b,(%r10,%rdi,8)
  1b502b:	jae    1b5010 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc190>
  1b502d:	cmp    %r9,%r12
  1b5030:	jae    1bda09 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14b89>
  1b5036:	mov    %rdi,(%r11,%r12,8)
  1b503a:	inc    %r12
  1b503d:	jmp    1b5010 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc190>
  1b503f:	cmp    %r9,%r12
  1b5042:	ja     1b5bb4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd34>
  1b5048:	test   %r12,%r12
  1b504b:	je     1b5d1e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xce9e>
  1b5051:	mov    (%r11),%rsi
  1b5054:	lea    -0x1(%r12),%rax
  1b5059:	mov    -0x8(%r11,%r12,8),%rcx
  1b505e:	sub    %rsi,%rcx
  1b5061:	setae  %dl
  1b5064:	cmp    %rax,%rcx
  1b5067:	sete   %al
  1b506a:	and    %dl,%al
  1b506c:	cmp    $0x1,%al
  1b506e:	jne    1b508b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc20b>
  1b5070:	mov    %rsi,%rax
  1b5073:	add    %r12,%rax
  1b5076:	jb     1b508b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc20b>
  1b5078:	mov    %rax,0x60(%rsp)
  1b507d:	mov    %rsi,0x20(%rsp)
  1b5082:	mov    $0x1,%al
  1b5084:	mov    %rax,0x30(%rsp)
  1b5089:	jmp    1b50a6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc226>
  1b508b:	movq   $0x0,0x60(%rsp)
  1b5094:	movq   $0x0,0x20(%rsp)
  1b509d:	movq   $0x0,0x30(%rsp)
  1b50a6:	lea    0x0(,%r12,8),%rbp
  1b50ae:	mov    (%rsp),%rax
  1b50b2:	imul   $0x47,%rax,%rcx
  1b50b6:	imul   $0x4f,%rax,%r8
  1b50ba:	xor    %r13d,%r13d
  1b50bd:	xorpd  %xmm6,%xmm6
  1b50c1:	movapd 0x1fe0f37(%rip),%xmm7        # 2196000 <_fini+0x520>
  1b50c9:	movsd  0x1fe25de(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b50d2:	mov    %rcx,0x18(%rsp)
  1b50d7:	mov    %r8,0x10(%rsp)
  1b50dc:	nopl   0x0(%rax)
  1b50e0:	mov    (%r11,%r13,1),%r14
  1b50e4:	lea    (%r14,%rcx,1),%rdi
  1b50e8:	cmp    %rbx,%rdi
  1b50eb:	jae    1bd840 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x149c0>
  1b50f1:	shl    $0x4,%rdi
  1b50f5:	movupd (%r15,%rdi,1),%xmm0
  1b50fb:	movapd %xmm0,%xmm1
  1b50ff:	unpckhpd %xmm0,%xmm1
  1b5103:	ucomisd %xmm6,%xmm1
  1b5107:	jne    1b5120 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc2a0>
  1b5109:	jp     1b5120 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc2a0>
  1b510b:	andpd  %xmm7,%xmm0
  1b510f:	jmp    1b51e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc360>
  1b5114:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b5120:	ucomisd %xmm6,%xmm0
  1b5124:	jne    1b5135 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc2b5>
  1b5126:	jp     1b5135 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc2b5>
  1b5128:	andpd  %xmm7,%xmm1
  1b512c:	movapd %xmm1,%xmm0
  1b5130:	jmp    1b51e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc360>
  1b5135:	movapd %xmm0,%xmm2
  1b5139:	andpd  %xmm7,%xmm2
  1b513d:	pshufd $0xee,%xmm2,%xmm3
  1b5142:	movapd %xmm2,%xmm4
  1b5146:	cmplesd %xmm3,%xmm4
  1b514b:	movapd %xmm4,%xmm5
  1b514f:	andpd  %xmm3,%xmm5
  1b5153:	andnpd %xmm2,%xmm4
  1b5157:	orpd   %xmm5,%xmm4
  1b515b:	movapd %xmm0,%xmm2
  1b515f:	cmpunordsd %xmm0,%xmm2
  1b5164:	movapd %xmm2,%xmm5
  1b5168:	andnpd %xmm4,%xmm5
  1b516c:	andpd  %xmm3,%xmm2
  1b5170:	orpd   %xmm5,%xmm2
  1b5174:	ucomisd %xmm8,%xmm2
  1b5179:	jbe    1b51a2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc322>
  1b517b:	movsd  0x1fe2535(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b5183:	ucomisd %xmm2,%xmm3
  1b5187:	jbe    1b51a2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc322>
  1b5189:	mulpd  %xmm0,%xmm0
  1b518d:	movapd %xmm0,%xmm1
  1b5191:	unpckhpd %xmm0,%xmm1
  1b5195:	addsd  %xmm0,%xmm1
  1b5199:	xorps  %xmm0,%xmm0
  1b519c:	sqrtsd %xmm1,%xmm0
  1b51a0:	jmp    1b51e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc360>
  1b51a2:	call   *0x2516a28(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1b51a8:	movsd  0x1fe24ff(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b51b1:	movapd 0x1fe0e47(%rip),%xmm7        # 2196000 <_fini+0x520>
  1b51b9:	xorpd  %xmm6,%xmm6
  1b51bd:	mov    0x10(%rsp),%r8
  1b51c2:	mov    0x18(%rsp),%rcx
  1b51c7:	mov    0x1c8(%rsp),%r10
  1b51cf:	mov    0x28(%rsp),%r11
  1b51d4:	mov    0x1b0(%rsp),%r9
  1b51dc:	nopl   0x0(%rax)
  1b51e0:	add    %r8,%r14
  1b51e3:	cmp    %rbx,%r14
  1b51e6:	jae    1bd82d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x149ad>
  1b51ec:	shl    $0x4,%r14
  1b51f0:	movsd  %xmm0,(%r15,%r14,1)
  1b51f6:	movq   $0x0,0x8(%r15,%r14,1)
  1b51ff:	add    $0x8,%r13
  1b5203:	cmp    %r13,%rbp
  1b5206:	jne    1b50e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc260>
  1b520c:	cmpb   $0x0,0x30(%rsp)
  1b5211:	je     1b537b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc4fb>
  1b5217:	mov    0x20(%rsp),%rbp
  1b521c:	mov    0x60(%rsp),%rsi
  1b5221:	cmp    %rsi,%rbp
  1b5224:	jae    1b548e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc60e>
  1b522a:	cmpq   $0x2,0x1e0(%rsp)
  1b5233:	mov    (%rsp),%rax
  1b5237:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b523d:	shl    $0x4,%rax
  1b5241:	lea    (%rax,%rax,4),%rax
  1b5245:	lea    (%r8,%rbp,1),%r10
  1b5249:	xor    %ecx,%ecx
  1b524b:	mov    %rbx,%rdx
  1b524e:	sub    %r10,%rdx
  1b5251:	cmovb  %rcx,%rdx
  1b5255:	lea    (%rax,%rbp,1),%r11
  1b5259:	mov    %rbx,%r8
  1b525c:	sub    %r11,%r8
  1b525f:	cmovb  %rcx,%r8
  1b5263:	cmp    %r8,%rdx
  1b5266:	cmovae %r8,%rdx
  1b526a:	mov    %rbp,%rcx
  1b526d:	not    %rcx
  1b5270:	add    %rsi,%rcx
  1b5273:	cmp    %rcx,%rdx
  1b5276:	cmovae %rcx,%rdx
  1b527a:	lea    0x1(%rdx),%rsi
  1b527e:	mov    %rbp,%r9
  1b5281:	cmp    $0x22,%rsi
  1b5285:	ja     1b549f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc61f>
  1b528b:	mov    (%rsp),%rdi
  1b528f:	mov    %rdi,%rdx
  1b5292:	shl    $0x8,%rdx
  1b5296:	lea    (%rdx,%rdx,4),%rsi
  1b529a:	mov    %r9,%rdx
  1b529d:	shl    $0x4,%rdx
  1b52a1:	add    %r15,%rdx
  1b52a4:	imul   $0x4f0,%rdi,%r10
  1b52ab:	mov    0x60(%rsp),%r14
  1b52b0:	mov    0x10(%rsp),%rdi
  1b52b5:	add    %r9,%rdi
  1b52b8:	cmp    %rbx,%rdi
  1b52bb:	jae    1be6c1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15841>
  1b52c1:	lea    (%rax,%r9,1),%rdi
  1b52c5:	cmp    %rbx,%rdi
  1b52c8:	jae    1be6b1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15831>
  1b52ce:	inc    %r9
  1b52d1:	mov    0x1d8(%rsp),%rdi
  1b52d9:	movupd 0x10(%rdi),%xmm0
  1b52de:	movsd  (%rdx,%r10,1),%xmm1
  1b52e4:	movsd  0x8(%rdx,%r10,1),%xmm2
  1b52eb:	unpcklpd %xmm1,%xmm1
  1b52ef:	mulpd  %xmm0,%xmm1
  1b52f3:	shufpd $0x1,%xmm0,%xmm0
  1b52f8:	unpcklpd %xmm2,%xmm2
  1b52fc:	mulpd  %xmm0,%xmm2
  1b5300:	movapd %xmm1,%xmm0
  1b5304:	subpd  %xmm2,%xmm0
  1b5308:	addpd  %xmm1,%xmm2
  1b530c:	movsd  %xmm0,%xmm2
  1b5310:	movupd %xmm2,(%rdx,%rsi,1)
  1b5315:	add    $0x10,%rdx
  1b5319:	cmp    %r9,%r14
  1b531c:	jne    1b52b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc430>
  1b531e:	mov    (%rsp),%rdx
  1b5322:	lea    (%rdx,%rdx,8),%rdx
  1b5326:	lea    (%rdx,%rdx,8),%rdx
  1b532a:	mov    0x18(%rsp),%rdi
  1b532f:	lea    (%rdi,%rbp,1),%r11
  1b5333:	xor    %r9d,%r9d
  1b5336:	mov    %rbx,%r10
  1b5339:	sub    %r11,%r10
  1b533c:	cmovb  %r9,%r10
  1b5340:	cmp    %r8,%r10
  1b5343:	cmovae %r8,%r10
  1b5347:	lea    (%rdx,%rbp,1),%r13
  1b534b:	mov    %rbx,%rdi
  1b534e:	sub    %r13,%rdi
  1b5351:	cmovb  %r9,%rdi
  1b5355:	cmp    %rdi,%r10
  1b5358:	cmovb  %r10,%rdi
  1b535c:	cmp    %rcx,%rdi
  1b535f:	cmovae %rcx,%rdi
  1b5363:	lea    0x1(%rdi),%r9
  1b5367:	cmp    $0x42,%r9
  1b536b:	ja     1b5704 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc884>
  1b5371:	mov    0x28(%rsp),%r11
  1b5376:	jmp    1b5bd8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd58>
  1b537b:	cmpq   $0x2,0x1e0(%rsp)
  1b5384:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b538a:	mov    (%rsp),%rax
  1b538e:	shl    $0x4,%rax
  1b5392:	lea    (%rax,%rax,4),%rsi
  1b5396:	xor    %ecx,%ecx
  1b5398:	nopl   0x0(%rax,%rax,1)
  1b53a0:	mov    (%r11,%rcx,1),%rdi
  1b53a4:	lea    (%rdi,%r8,1),%rax
  1b53a8:	cmp    %rbx,%rax
  1b53ab:	jae    1bdf13 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15093>
  1b53b1:	add    %rsi,%rdi
  1b53b4:	cmp    %rbx,%rdi
  1b53b7:	jae    1bdf03 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15083>
  1b53bd:	shl    $0x4,%rax
  1b53c1:	shl    $0x4,%rdi
  1b53c5:	mov    0x1d8(%rsp),%rdx
  1b53cd:	movupd 0x10(%rdx),%xmm0
  1b53d2:	movsd  (%r15,%rax,1),%xmm1
  1b53d8:	movsd  0x8(%r15,%rax,1),%xmm2
  1b53df:	unpcklpd %xmm1,%xmm1
  1b53e3:	mulpd  %xmm0,%xmm1
  1b53e7:	shufpd $0x1,%xmm0,%xmm0
  1b53ec:	unpcklpd %xmm2,%xmm2
  1b53f0:	mulpd  %xmm0,%xmm2
  1b53f4:	movapd %xmm1,%xmm0
  1b53f8:	subpd  %xmm2,%xmm0
  1b53fc:	addpd  %xmm1,%xmm2
  1b5400:	movsd  %xmm0,%xmm2
  1b5404:	movupd %xmm2,(%r15,%rdi,1)
  1b540a:	add    $0x8,%rcx
  1b540e:	cmp    %rcx,%rbp
  1b5411:	jne    1b53a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc520>
  1b5413:	mov    (%rsp),%rax
  1b5417:	lea    (%rax,%rax,8),%rax
  1b541b:	lea    (%rax,%rax,8),%rdx
  1b541f:	xor    %r8d,%r8d
  1b5422:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b5430:	mov    (%r11,%r8,1),%rdi
  1b5434:	mov    0x18(%rsp),%rax
  1b5439:	add    %rdi,%rax
  1b543c:	cmp    %rbx,%rax
  1b543f:	jae    1bdf49 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x150c9>
  1b5445:	lea    (%rdi,%rsi,1),%rcx
  1b5449:	cmp    %rbx,%rcx
  1b544c:	jae    1bdf36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x150b6>
  1b5452:	add    %rdx,%rdi
  1b5455:	cmp    %rbx,%rdi
  1b5458:	jae    1bdf26 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x150a6>
  1b545e:	shl    $0x4,%rax
  1b5462:	shl    $0x4,%rcx
  1b5466:	shl    $0x4,%rdi
  1b546a:	movupd (%r15,%rax,1),%xmm0
  1b5470:	movupd (%r15,%rcx,1),%xmm1
  1b5476:	addpd  %xmm0,%xmm1
  1b547a:	movupd %xmm1,(%r15,%rdi,1)
  1b5480:	add    $0x8,%r8
  1b5484:	cmp    %r8,%rbp
  1b5487:	jne    1b5430 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc5b0>
  1b5489:	jmp    1b5c55 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcdd5>
  1b548e:	mov    (%rsp),%rax
  1b5492:	lea    (%rax,%rax,8),%rax
  1b5496:	lea    (%rax,%rax,8),%rdx
  1b549a:	jmp    1b5c55 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcdd5>
  1b549f:	xor    %esi,%esi
  1b54a1:	mov    %rbx,%rdi
  1b54a4:	sub    %r10,%rdi
  1b54a7:	cmovb  %rsi,%rdi
  1b54ab:	mov    %rbx,%r14
  1b54ae:	sub    %r11,%r14
  1b54b1:	cmovb  %rsi,%r14
  1b54b5:	cmp    %r14,%rdi
  1b54b8:	cmovb  %rdi,%r14
  1b54bc:	cmp    %rcx,%r14
  1b54bf:	cmovae %rcx,%r14
  1b54c3:	imul   $0x4f0,(%rsp),%rsi
  1b54cb:	mov    %rbp,%rdi
  1b54ce:	shl    $0x4,%rdi
  1b54d2:	lea    (%r15,%rsi,1),%r9
  1b54d6:	lea    (%rdi,%r9,1),%rbx
  1b54da:	add    $0x8,%rbx
  1b54de:	add    %rdi,%r9
  1b54e1:	mov    %r14,%r13
  1b54e4:	shl    $0x4,%r13
  1b54e8:	add    %r9,%r13
  1b54eb:	add    $0x8,%r13
  1b54ef:	mov    %rbp,%r9
  1b54f2:	cmp    %rbx,%r13
  1b54f5:	mov    0x8(%rsp),%rbx
  1b54fa:	jb     1b528b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc40b>
  1b5500:	mov    %rbp,%r9
  1b5503:	movabs $0xfffffffffffffff,%r13
  1b550d:	cmp    %r13,%r14
  1b5510:	ja     1b528b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc40b>
  1b5516:	mov    (%rsp),%r9
  1b551a:	lea    (%r9,%r9,4),%r9
  1b551e:	shl    $0x8,%r9
  1b5522:	add    %rdi,%r9
  1b5525:	xor    %ebx,%ebx
  1b5527:	mov    0x8(%rsp),%r14
  1b552c:	sub    %r10,%r14
  1b552f:	cmovb  %rbx,%r14
  1b5533:	mov    0x8(%rsp),%r10
  1b5538:	sub    %r11,%r10
  1b553b:	cmovb  %rbx,%r10
  1b553f:	cmp    %r10,%r14
  1b5542:	cmovb  %r14,%r10
  1b5546:	cmp    %rcx,%r10
  1b5549:	cmovae %rcx,%r10
  1b554d:	lea    (%r15,%r9,1),%rbx
  1b5551:	shl    $0x4,%r10
  1b5555:	lea    (%r10,%rbx,1),%r13
  1b5559:	add    $0x8,%r13
  1b555d:	lea    0x8(%r15,%r9,1),%r9
  1b5562:	mov    %r9,0x48(%rsp)
  1b5567:	lea    0x10(%r10,%rbx,1),%r14
  1b556c:	mov    %r14,0x38(%rsp)
  1b5571:	lea    (%rsi,%rdi,1),%r9
  1b5575:	mov    %r9,0x40(%rsp)
  1b557a:	lea    (%r15,%r9,1),%r11
  1b557e:	lea    (%r10,%r11,1),%r9
  1b5582:	add    $0x8,%r9
  1b5586:	add    %r11,%r10
  1b5589:	add    $0x10,%r10
  1b558d:	cmp    %r14,%rbx
  1b5590:	setb   0x30(%rsp)
  1b5595:	mov    0x48(%rsp),%r14
  1b559a:	cmp    %r13,%r14
  1b559d:	setb   0x50(%rsp)
  1b55a2:	cmp    %r9,%rbx
  1b55a5:	setb   0x100(%rsp)
  1b55ad:	cmp    %r13,%r11
  1b55b0:	setb   0xb0(%rsp)
  1b55b8:	cmp    %r10,%rbx
  1b55bb:	mov    0x40(%rsp),%rbx
  1b55c0:	lea    0x8(%r15,%rbx,1),%rbx
  1b55c5:	setb   0x40(%rsp)
  1b55ca:	cmp    %r13,%rbx
  1b55cd:	setb   0xd0(%rsp)
  1b55d5:	cmp    %r9,%r14
  1b55d8:	mov    %r14,%r13
  1b55db:	setb   %r14b
  1b55df:	mov    0x38(%rsp),%r9
  1b55e4:	cmp    %r9,%r11
  1b55e7:	setb   0xe0(%rsp)
  1b55ef:	cmp    %r10,%r13
  1b55f2:	setb   %r11b
  1b55f6:	cmp    %r9,%rbx
  1b55f9:	mov    0x8(%rsp),%rbx
  1b55fe:	setb   %r10b
  1b5602:	mov    %rbp,%r9
  1b5605:	movzbl 0x50(%rsp),%r13d
  1b560b:	test   %r13b,0x30(%rsp)
  1b5610:	jne    1b528b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc40b>
  1b5616:	mov    %rbp,%r9
  1b5619:	movzbl 0xb0(%rsp),%r13d
  1b5622:	and    %r13b,0x100(%rsp)
  1b562a:	jne    1b528b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc40b>
  1b5630:	mov    %rbp,%r9
  1b5633:	movzbl 0xd0(%rsp),%r13d
  1b563c:	and    %r13b,0x40(%rsp)
  1b5641:	jne    1b528b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc40b>
  1b5647:	mov    %rbp,%r9
  1b564a:	and    0xe0(%rsp),%r14b
  1b5652:	jne    1b528b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc40b>
  1b5658:	mov    %rbp,%r9
  1b565b:	and    %r10b,%r11b
  1b565e:	jne    1b528b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc40b>
  1b5664:	and    $0xfffffffffffffffe,%rdx
  1b5668:	lea    (%rdx,%rbp,1),%r9
  1b566c:	mov    0x1d8(%rsp),%r10
  1b5674:	movsd  0x10(%r10),%xmm0
  1b567a:	movsd  0x18(%r10),%xmm1
  1b5680:	unpcklpd %xmm1,%xmm1
  1b5684:	unpcklpd %xmm0,%xmm0
  1b5688:	mov    (%rsp),%r10
  1b568c:	shl    $0x8,%r10
  1b5690:	lea    (%r10,%r10,4),%r10
  1b5694:	add    %r15,%rdi
  1b5697:	nopw   0x0(%rax,%rax,1)
  1b56a0:	movupd (%rdi,%rsi,1),%xmm2
  1b56a5:	movupd 0x10(%rdi,%rsi,1),%xmm3
  1b56ab:	movapd %xmm2,%xmm4
  1b56af:	unpcklpd %xmm3,%xmm4
  1b56b3:	unpckhpd %xmm3,%xmm2
  1b56b7:	movapd %xmm1,%xmm3
  1b56bb:	mulpd  %xmm4,%xmm3
  1b56bf:	movapd %xmm0,%xmm5
  1b56c3:	mulpd  %xmm2,%xmm5
  1b56c7:	addpd  %xmm3,%xmm5
  1b56cb:	mulpd  %xmm0,%xmm4
  1b56cf:	mulpd  %xmm1,%xmm2
  1b56d3:	subpd  %xmm2,%xmm4
  1b56d7:	movapd %xmm4,%xmm2
  1b56db:	unpcklpd %xmm5,%xmm2
  1b56df:	unpckhpd %xmm5,%xmm4
  1b56e3:	movupd %xmm4,0x10(%rdi,%r10,1)
  1b56ea:	movupd %xmm2,(%rdi,%r10,1)
  1b56f0:	add    $0x20,%rdi
  1b56f4:	add    $0xfffffffffffffffe,%rdx
  1b56f8:	jne    1b56a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc820>
  1b56fa:	mov    0x20(%rsp),%rbp
  1b56ff:	jmp    1b528b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc40b>
  1b5704:	xor    %r9d,%r9d
  1b5707:	mov    %rbx,%r10
  1b570a:	mov    %r11,0x10(%rsp)
  1b570f:	sub    %r11,%r10
  1b5712:	cmovb  %r9,%r10
  1b5716:	cmp    %r8,%r10
  1b5719:	cmovae %r8,%r10
  1b571d:	mov    %rbx,%r11
  1b5720:	sub    %r13,%r11
  1b5723:	cmovb  %r9,%r11
  1b5727:	cmp    %r11,%r10
  1b572a:	cmovb  %r10,%r11
  1b572e:	cmp    %rcx,%r11
  1b5731:	cmovae %rcx,%r11
  1b5735:	imul   $0x470,(%rsp),%r9
  1b573d:	mov    %rbp,%r10
  1b5740:	shl    $0x4,%r10
  1b5744:	lea    (%r15,%r9,1),%rbx
  1b5748:	lea    (%r10,%rbx,1),%r14
  1b574c:	add    $0x8,%r14
  1b5750:	add    %r10,%rbx
  1b5753:	mov    %r11,%rbp
  1b5756:	shl    $0x4,%rbp
  1b575a:	add    %rbp,%rbx
  1b575d:	add    $0x8,%rbx
  1b5761:	cmp    %r14,%rbx
  1b5764:	jb     1b5a14 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcb94>
  1b576a:	lea    (%r15,%rsi,1),%rbx
  1b576e:	lea    (%r10,%rbx,1),%r14
  1b5772:	add    $0x8,%r14
  1b5776:	add    %r10,%rbx
  1b5779:	add    %rbp,%rbx
  1b577c:	add    $0x8,%rbx
  1b5780:	cmp    %r14,%rbx
  1b5783:	jb     1b5a14 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcb94>
  1b5789:	movabs $0xfffffffffffffff,%rbx
  1b5793:	cmp    %rbx,%r11
  1b5796:	ja     1b5a14 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcb94>
  1b579c:	mov    (%rsp),%r11
  1b57a0:	imul   $0x510,%r11,%r11
  1b57a7:	xor    %ebp,%ebp
  1b57a9:	mov    0x8(%rsp),%rbx
  1b57ae:	mov    %rbx,%r14
  1b57b1:	sub    0x10(%rsp),%r14
  1b57b6:	cmovb  %rbp,%r14
  1b57ba:	lea    (%r11,%r10,1),%rbp
  1b57be:	cmp    %r8,%r14
  1b57c1:	cmovae %r8,%r14
  1b57c5:	mov    %rbx,%r8
  1b57c8:	sub    %r13,%r8
  1b57cb:	mov    $0x0,%ebx
  1b57d0:	cmovb  %rbx,%r8
  1b57d4:	lea    (%r15,%rbp,1),%r13
  1b57d8:	cmp    %r8,%r14
  1b57db:	cmovb  %r14,%r8
  1b57df:	cmp    %rcx,%r8
  1b57e2:	cmovae %rcx,%r8
  1b57e6:	shl    $0x4,%r8
  1b57ea:	lea    (%r8,%r13,1),%rbx
  1b57ee:	add    $0x8,%rbx
  1b57f2:	lea    0x8(%r15,%rbp,1),%r14
  1b57f7:	lea    0x10(%r8,%r13,1),%rcx
  1b57fc:	mov    %rcx,0x30(%rsp)
  1b5801:	lea    (%r9,%r10,1),%rbp
  1b5805:	lea    (%r15,%rbp,1),%rcx
  1b5809:	mov    %rcx,0xd0(%rsp)
  1b5811:	lea    0x8(%r15,%rbp,1),%rbp
  1b5816:	mov    %rbp,0x10(%rsp)
  1b581b:	lea    0x10(%r8,%rcx,1),%rbp
  1b5820:	mov    %rbp,0x50(%rsp)
  1b5825:	mov    (%rsp),%rcx
  1b5829:	lea    (%rcx,%rcx,4),%rcx
  1b582d:	shl    $0x8,%rcx
  1b5831:	add    %r10,%rcx
  1b5834:	lea    (%r15,%rcx,1),%rbp
  1b5838:	mov    %rbp,0xe0(%rsp)
  1b5840:	add    %r15,%rcx
  1b5843:	add    $0x8,%rcx
  1b5847:	mov    %rcx,0x38(%rsp)
  1b584c:	lea    0x10(%r8,%rbp,1),%rcx
  1b5851:	mov    %rcx,0x48(%rsp)
  1b5856:	mov    0xd0(%rsp),%rcx
  1b585e:	lea    0x8(%r8,%rcx,1),%rbp
  1b5863:	mov    %rbp,0x40(%rsp)
  1b5868:	mov    0xe0(%rsp),%rbp
  1b5870:	add    %rbp,%r8
  1b5873:	add    $0x8,%r8
  1b5877:	cmp    0x30(%rsp),%r13
  1b587c:	setb   0x100(%rsp)
  1b5884:	cmp    %rbx,%r14
  1b5887:	setb   0xb0(%rsp)
  1b588f:	cmp    0x50(%rsp),%r13
  1b5894:	setb   0x58(%rsp)
  1b5899:	cmp    %rbx,0x10(%rsp)
  1b589e:	setb   0x88(%rsp)
  1b58a6:	cmp    0x48(%rsp),%r13
  1b58ab:	setb   0x78(%rsp)
  1b58b0:	cmp    %rbx,0x38(%rsp)
  1b58b5:	setb   0x80(%rsp)
  1b58bd:	cmp    0x40(%rsp),%r13
  1b58c2:	setb   0x98(%rsp)
  1b58ca:	cmp    %rbx,%rcx
  1b58cd:	setb   0xc8(%rsp)
  1b58d5:	cmp    %r8,%r13
  1b58d8:	mov    %r8,%r13
  1b58db:	setb   0xa8(%rsp)
  1b58e3:	cmp    %rbx,%rbp
  1b58e6:	setb   %bl
  1b58e9:	cmp    0x50(%rsp),%r14
  1b58ee:	setb   0x50(%rsp)
  1b58f3:	mov    0x30(%rsp),%r8
  1b58f8:	cmp    %r8,0x10(%rsp)
  1b58fd:	setb   0x10(%rsp)
  1b5902:	cmp    0x48(%rsp),%r14
  1b5907:	setb   0x48(%rsp)
  1b590c:	cmp    %r8,0x38(%rsp)
  1b5911:	setb   0x38(%rsp)
  1b5916:	cmp    0x40(%rsp),%r14
  1b591b:	setb   0x40(%rsp)
  1b5920:	cmp    %r8,%rcx
  1b5923:	mov    %r8,%rcx
  1b5926:	setb   0xd0(%rsp)
  1b592e:	cmp    %r13,%r14
  1b5931:	setb   %r8b
  1b5935:	cmp    %rcx,%rbp
  1b5938:	setb   %bpl
  1b593c:	movzbl 0xb0(%rsp),%ecx
  1b5944:	test   %cl,0x100(%rsp)
  1b594b:	jne    1b5a14 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcb94>
  1b5951:	movzbl 0x88(%rsp),%ecx
  1b5959:	and    %cl,0x58(%rsp)
  1b595d:	jne    1b5a14 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcb94>
  1b5963:	movzbl 0x80(%rsp),%ecx
  1b596b:	and    %cl,0x78(%rsp)
  1b596f:	mov    0x60(%rsp),%r14
  1b5974:	jne    1b5bc9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd49>
  1b597a:	movzbl 0xc8(%rsp),%ecx
  1b5982:	and    %cl,0x98(%rsp)
  1b5989:	jne    1b5bc9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd49>
  1b598f:	and    %bl,0xa8(%rsp)
  1b5996:	jne    1b5bc9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd49>
  1b599c:	movzbl 0x10(%rsp),%ecx
  1b59a1:	and    %cl,0x50(%rsp)
  1b59a5:	mov    0x8(%rsp),%rbx
  1b59aa:	jne    1b5bce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd4e>
  1b59b0:	movzbl 0x38(%rsp),%ecx
  1b59b5:	and    %cl,0x48(%rsp)
  1b59b9:	jne    1b5bce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd4e>
  1b59bf:	movzbl 0xd0(%rsp),%ecx
  1b59c7:	and    %cl,0x40(%rsp)
  1b59cb:	jne    1b5bce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd4e>
  1b59d1:	and    %bpl,%r8b
  1b59d4:	jne    1b5bce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd4e>
  1b59da:	and    $0xfffffffffffffffe,%rdi
  1b59de:	mov    0x20(%rsp),%rbp
  1b59e3:	add    %rdi,%rbp
  1b59e6:	add    %r15,%r10
  1b59e9:	nopl   0x0(%rax)
  1b59f0:	movupd (%r10,%r9,1),%xmm0
  1b59f6:	movupd (%r10,%rsi,1),%xmm1
  1b59fc:	addpd  %xmm0,%xmm1
  1b5a00:	movupd %xmm1,(%r10,%r11,1)
  1b5a06:	add    $0x10,%r10
  1b5a0a:	dec    %rdi
  1b5a0d:	jne    1b59f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcb70>
  1b5a0f:	jmp    1b5371 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xc4f1>
  1b5a14:	mov    0x8(%rsp),%rbx
  1b5a19:	mov    0x28(%rsp),%r11
  1b5a1e:	mov    0x20(%rsp),%rbp
  1b5a23:	mov    0x60(%rsp),%r14
  1b5a28:	jmp    1b5bd8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd58>
  1b5a2d:	mov    0x28(%rsp),%r11
  1b5a32:	mov    0x1c8(%rsp),%r10
  1b5a3a:	jmp    1b1655 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x87d5>
  1b5a3f:	mov    0x8(%rsp),%rbx
  1b5a44:	mov    0x1d8(%rsp),%r12
  1b5a4c:	mov    0x1b0(%rsp),%r9
  1b5a54:	mov    0x28(%rsp),%r11
  1b5a59:	mov    0x1c8(%rsp),%r10
  1b5a61:	jmp    1b22d5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9455>
  1b5a66:	mov    0x1d8(%rsp),%r12
  1b5a6e:	mov    0x1b0(%rsp),%r9
  1b5a76:	jmp    1b22d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9450>
  1b5a7b:	mov    0x28(%rsp),%r11
  1b5a80:	jmp    1b419d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb31d>
  1b5a85:	mov    0x28(%rsp),%r11
  1b5a8a:	mov    0x1c8(%rsp),%r10
  1b5a92:	jmp    1b419d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xb31d>
  1b5a97:	mov    0x8(%rsp),%rbx
  1b5a9c:	jmp    1b4e00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xbf80>
  1b5aa1:	mov    0x8(%rsp),%rbx
  1b5aa6:	mov    0x28(%rsp),%r11
  1b5aab:	mov    0x1c8(%rsp),%r10
  1b5ab3:	mov    0x50(%rsp),%r13
  1b5ab8:	mov    0x20(%rsp),%r14
  1b5abd:	jmp    1b1655 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x87d5>
  1b5ac2:	mov    0x28(%rsp),%r11
  1b5ac7:	jmp    1b22da <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x945a>
  1b5acc:	mov    0x1b0(%rsp),%r9
  1b5ad4:	jmp    1b22d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x9450>
  1b5ad9:	lea    0x246e0d8(%rip),%rcx        # 2623bb8 <__gmpfr_one+0xc438>
  1b5ae0:	xor    %edi,%edi
  1b5ae2:	mov    %r9,%rdx
  1b5ae5:	call   *0x251b39d(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5aeb:	lea    0x246df8e(%rip),%rcx        # 2623a80 <__gmpfr_one+0xc300>
  1b5af2:	xor    %edi,%edi
  1b5af4:	mov    %r9,%rdx
  1b5af7:	call   *0x251b38b(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5afd:	lea    0x246df64(%rip),%rcx        # 2623a68 <__gmpfr_one+0xc2e8>
  1b5b04:	xor    %edi,%edi
  1b5b06:	mov    %r13,%rsi
  1b5b09:	mov    %r9,%rdx
  1b5b0c:	call   *0x251b376(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5b12:	lea    0x246ded7(%rip),%rcx        # 26239f0 <__gmpfr_one+0xc270>
  1b5b19:	xor    %edi,%edi
  1b5b1b:	mov    %r14,%rsi
  1b5b1e:	mov    %r9,%rdx
  1b5b21:	call   *0x251b361(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5b27:	lea    0x246deaa(%rip),%rcx        # 26239d8 <__gmpfr_one+0xc258>
  1b5b2e:	xor    %edi,%edi
  1b5b30:	mov    %r14,%rsi
  1b5b33:	mov    %r9,%rdx
  1b5b36:	call   *0x251b34c(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5b3c:	lea    0x246ddbd(%rip),%rcx        # 2623900 <__gmpfr_one+0xc180>
  1b5b43:	xor    %edi,%edi
  1b5b45:	mov    %r9,%rdx
  1b5b48:	call   *0x251b33a(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5b4e:	lea    0x246dd93(%rip),%rcx        # 26238e8 <__gmpfr_one+0xc168>
  1b5b55:	xor    %edi,%edi
  1b5b57:	mov    %r13,%rsi
  1b5b5a:	mov    %r9,%rdx
  1b5b5d:	call   *0x251b325(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5b63:	lea    0x246dd06(%rip),%rcx        # 2623870 <__gmpfr_one+0xc0f0>
  1b5b6a:	xor    %edi,%edi
  1b5b6c:	mov    %r14,%rsi
  1b5b6f:	mov    %r9,%rdx
  1b5b72:	call   *0x251b310(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5b78:	lea    0x246dcd9(%rip),%rcx        # 2623858 <__gmpfr_one+0xc0d8>
  1b5b7f:	xor    %edi,%edi
  1b5b81:	mov    %r12,%rsi
  1b5b84:	mov    %r9,%rdx
  1b5b87:	call   *0x251b2fb(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5b8d:	lea    0x246dc4c(%rip),%rcx        # 26237e0 <__gmpfr_one+0xc060>
  1b5b94:	xor    %edi,%edi
  1b5b96:	mov    %r9,%rdx
  1b5b99:	call   *0x251b2e9(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5b9f:	lea    0x246dc22(%rip),%rcx        # 26237c8 <__gmpfr_one+0xc048>
  1b5ba6:	xor    %edi,%edi
  1b5ba8:	mov    %r12,%rsi
  1b5bab:	mov    %r9,%rdx
  1b5bae:	call   *0x251b2d4(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5bb4:	lea    0x246db95(%rip),%rcx        # 2623750 <__gmpfr_one+0xbfd0>
  1b5bbb:	xor    %edi,%edi
  1b5bbd:	mov    %r12,%rsi
  1b5bc0:	mov    %r9,%rdx
  1b5bc3:	call   *0x251b2bf(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1b5bc9:	mov    0x8(%rsp),%rbx
  1b5bce:	mov    0x28(%rsp),%r11
  1b5bd3:	mov    0x20(%rsp),%rbp
  1b5bd8:	mov    (%rsp),%rdi
  1b5bdc:	imul   $0x510,%rdi,%rcx
  1b5be3:	mov    %rbp,%r8
  1b5be6:	shl    $0x4,%r8
  1b5bea:	add    %r15,%r8
  1b5bed:	imul   $0x470,%rdi,%r9
  1b5bf4:	mov    0x1c8(%rsp),%r10
  1b5bfc:	nopl   0x0(%rax)
  1b5c00:	mov    0x18(%rsp),%rdi
  1b5c05:	add    %rbp,%rdi
  1b5c08:	cmp    %rbx,%rdi
  1b5c0b:	jae    1be6f1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15871>
  1b5c11:	lea    (%rax,%rbp,1),%rdi
  1b5c15:	cmp    %rbx,%rdi
  1b5c18:	jae    1be6e1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15861>
  1b5c1e:	lea    (%rdx,%rbp,1),%rdi
  1b5c22:	cmp    %rbx,%rdi
  1b5c25:	jae    1be6d1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15851>
  1b5c2b:	inc    %rbp
  1b5c2e:	movupd (%r8,%r9,1),%xmm0
  1b5c34:	movupd (%r8,%rsi,1),%xmm1
  1b5c3a:	addpd  %xmm0,%xmm1
  1b5c3e:	movupd %xmm1,(%r8,%rcx,1)
  1b5c44:	add    $0x10,%r8
  1b5c48:	cmp    %rbp,%r14
  1b5c4b:	jne    1b5c00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcd80>
  1b5c4d:	mov    0x1b0(%rsp),%r9
  1b5c55:	xor    %ecx,%ecx
  1b5c57:	xorpd  %xmm0,%xmm0
  1b5c5b:	xor    %esi,%esi
  1b5c5d:	nopl   (%rax)
  1b5c60:	mov    (%r11,%rcx,8),%rdi
  1b5c64:	lea    (%rdi,%rdx,1),%rax
  1b5c68:	cmp    %rbx,%rax
  1b5c6b:	jae    1bd850 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x149d0>
  1b5c71:	shl    $0x4,%rax
  1b5c75:	movsd  (%r15,%rax,1),%xmm1
  1b5c7b:	ucomisd %xmm0,%xmm1
  1b5c7f:	jne    1b5cc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xce40>
  1b5c81:	jp     1b5cc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xce40>
  1b5c83:	add    %r15,%rax
  1b5c86:	movsd  0x8(%rax),%xmm1
  1b5c8b:	ucomisd %xmm0,%xmm1
  1b5c8f:	jne    1b5cc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xce40>
  1b5c91:	jp     1b5cc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xce40>
  1b5c93:	cmp    0x1d0(%rsp),%rdi
  1b5c9b:	jae    1be23c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x153bc>
  1b5ca1:	movq   $0x50,(%r10,%rdi,8)
  1b5ca9:	inc    %rcx
  1b5cac:	cmp    %rcx,%r12
  1b5caf:	jne    1b5c60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcde0>
  1b5cb1:	jmp    1b5cd8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xce58>
  1b5cb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b5cc0:	cmp    %r9,%rsi
  1b5cc3:	jae    1bdd0d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14e8d>
  1b5cc9:	mov    %rdi,(%r11,%rsi,8)
  1b5ccd:	inc    %rsi
  1b5cd0:	inc    %rcx
  1b5cd3:	cmp    %rcx,%r12
  1b5cd6:	jne    1b5c60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcde0>
  1b5cd8:	cmp    %r9,%rsi
  1b5cdb:	ja     1bd3c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14540>
  1b5ce1:	test   %rsi,%rsi
  1b5ce4:	mov    0x1d0(%rsp),%rdx
  1b5cec:	mov    0x90(%rsp),%rcx
  1b5cf4:	je     1b5d1e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xce9e>
  1b5cf6:	shl    $0x3,%rsi
  1b5cfa:	xor    %eax,%eax
  1b5cfc:	nopl   0x0(%rax)
  1b5d00:	mov    (%r11,%rax,1),%rdi
  1b5d04:	cmp    %rdx,%rdi
  1b5d07:	jae    1bdbbf <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14d3f>
  1b5d0d:	movq   $0x51,(%r10,%rdi,8)
  1b5d15:	add    $0x8,%rax
  1b5d19:	cmp    %rax,%rsi
  1b5d1c:	jne    1b5d00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xce80>
  1b5d1e:	xor    %eax,%eax
  1b5d20:	xor    %esi,%esi
  1b5d22:	mov    0x1d8(%rsp),%r12
  1b5d2a:	mov    0x110(%rsp),%r8
  1b5d32:	jmp    1b5d50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xced0>
  1b5d34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b5d40:	mov    %rdi,(%r11,%rsi,8)
  1b5d44:	inc    %rsi
  1b5d47:	add    $0x8,%rax
  1b5d4b:	cmp    %rax,%rcx
  1b5d4e:	je     1b5d7c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcefc>
  1b5d50:	mov    (%r8,%rax,1),%rdi
  1b5d54:	cmp    %rdx,%rdi
  1b5d57:	jae    1bd5ba <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1473a>
  1b5d5d:	cmpq   $0x51,(%r10,%rdi,8)
  1b5d62:	jae    1b5d47 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcec7>
  1b5d64:	cmp    %r9,%rsi
  1b5d67:	jb     1b5d40 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcec0>
  1b5d69:	lea    0x246ca20(%rip),%rdx        # 2622790 <__gmpfr_one+0xb010>
  1b5d70:	mov    %rsi,%rdi
  1b5d73:	mov    %r9,%rsi
  1b5d76:	call   *0x2519184(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1b5d7c:	cmp    %r9,%rsi
  1b5d7f:	ja     1bd27f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x143ff>
  1b5d85:	test   %rsi,%rsi
  1b5d88:	je     1b5dcd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcf4d>
  1b5d8a:	mov    (%r11),%rdi
  1b5d8d:	lea    -0x1(%rsi),%rax
  1b5d91:	mov    -0x8(%r11,%rsi,8),%rcx
  1b5d96:	sub    %rdi,%rcx
  1b5d99:	setae  %dl
  1b5d9c:	cmp    %rax,%rcx
  1b5d9f:	sete   %al
  1b5da2:	and    %dl,%al
  1b5da4:	cmp    $0x1,%al
  1b5da6:	jne    1b5de1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcf61>
  1b5da8:	mov    %rdi,0x30(%rsp)
  1b5dad:	add    %rdi,%rsi
  1b5db0:	jb     1bd46c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x145ec>
  1b5db6:	mov    0x1d0(%rsp),%rdx
  1b5dbe:	mov    0x90(%rsp),%rcx
  1b5dc6:	mov    %rsi,0x10(%rsp)
  1b5dcb:	jmp    1b5e03 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcf83>
  1b5dcd:	movq   $0x0,0x10(%rsp)
  1b5dd6:	movq   $0x0,0x30(%rsp)
  1b5ddf:	jmp    1b5e03 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcf83>
  1b5de1:	movq   $0x0,0x10(%rsp)
  1b5dea:	movq   $0x0,0x30(%rsp)
  1b5df3:	mov    0x1d0(%rsp),%rdx
  1b5dfb:	mov    0x90(%rsp),%rcx
  1b5e03:	xor    %eax,%eax
  1b5e05:	xor    %r13d,%r13d
  1b5e08:	jmp    1b5e20 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcfa0>
  1b5e0a:	nopw   0x0(%rax,%rax,1)
  1b5e10:	mov    %rdi,(%r11,%r13,8)
  1b5e14:	inc    %r13
  1b5e17:	add    $0x8,%rax
  1b5e1b:	cmp    %rax,%rcx
  1b5e1e:	je     1b5e4c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcfcc>
  1b5e20:	mov    (%r8,%rax,1),%rdi
  1b5e24:	cmp    %rdx,%rdi
  1b5e27:	jae    1bd5ca <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1474a>
  1b5e2d:	cmpq   $0x52,(%r10,%rdi,8)
  1b5e32:	jae    1b5e17 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcf97>
  1b5e34:	cmp    %r9,%r13
  1b5e37:	jb     1b5e10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcf90>
  1b5e39:	lea    0x246c980(%rip),%rdx        # 26227c0 <__gmpfr_one+0xb040>
  1b5e40:	mov    %r13,%rdi
  1b5e43:	mov    %r9,%rsi
  1b5e46:	call   *0x25190b4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1b5e4c:	cmp    %r9,%r13
  1b5e4f:	ja     1bd291 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14411>
  1b5e55:	test   %r13,%r13
  1b5e58:	je     1b5e92 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd012>
  1b5e5a:	mov    (%r11),%rax
  1b5e5d:	lea    -0x1(%r13),%rcx
  1b5e61:	mov    -0x8(%r11,%r13,8),%rdx
  1b5e66:	sub    %rax,%rdx
  1b5e69:	setae  %sil
  1b5e6d:	cmp    %rcx,%rdx
  1b5e70:	sete   %cl
  1b5e73:	and    %sil,%cl
  1b5e76:	cmp    $0x1,%cl
  1b5e79:	jne    1b5e9d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd01d>
  1b5e7b:	mov    %rax,%rcx
  1b5e7e:	add    %r13,%rcx
  1b5e81:	jb     1b5e9d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd01d>
  1b5e83:	mov    $0x1,%r9b
  1b5e86:	mov    %rcx,0x10(%rsp)
  1b5e8b:	mov    %rax,0x30(%rsp)
  1b5e90:	jmp    1b5ea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd020>
  1b5e92:	xor    %r12d,%r12d
  1b5e95:	xor    %r13d,%r13d
  1b5e98:	jmp    1b67ed <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd96d>
  1b5e9d:	xor    %r9d,%r9d
  1b5ea0:	shl    $0x3,%r13
  1b5ea4:	mov    (%rsp),%rdx
  1b5ea8:	lea    (%rdx,%rdx,8),%rax
  1b5eac:	lea    (%rax,%rax,8),%rcx
  1b5eb0:	imul   $0x56,%rdx,%rsi
  1b5eb4:	xor    %edx,%edx
  1b5eb6:	xorpd  %xmm0,%xmm0
  1b5eba:	jmp    1b5ede <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd05e>
  1b5ebc:	nopl   0x0(%rax)
  1b5ec0:	shl    $0x4,%rdi
  1b5ec4:	movupd 0x30(%r12),%xmm1
  1b5ecb:	movupd %xmm1,(%r15,%rdi,1)
  1b5ed1:	add    $0x8,%rdx
  1b5ed5:	cmp    %rdx,%r13
  1b5ed8:	je     1b5f69 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd0e9>
  1b5ede:	mov    (%r11,%rdx,1),%rdi
  1b5ee2:	lea    (%rdi,%rcx,1),%rax
  1b5ee6:	cmp    %rbx,%rax
  1b5ee9:	jae    1bd863 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x149e3>
  1b5eef:	shl    $0x4,%rax
  1b5ef3:	movsd  (%r15,%rax,1),%xmm1
  1b5ef9:	ucomisd %xmm0,%xmm1
  1b5efd:	jne    1b5f30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd0b0>
  1b5eff:	jp     1b5f30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd0b0>
  1b5f01:	add    %r15,%rax
  1b5f04:	movsd  0x8(%rax),%xmm1
  1b5f09:	ucomisd %xmm0,%xmm1
  1b5f0d:	jne    1b5f30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd0b0>
  1b5f0f:	jp     1b5f30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd0b0>
  1b5f11:	add    %rsi,%rdi
  1b5f14:	cmp    %rbx,%rdi
  1b5f17:	jae    1be269 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x153e9>
  1b5f1d:	cmpq   $0x3,0x1e0(%rsp)
  1b5f26:	ja     1b5ec0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd040>
  1b5f28:	jmp    1bd65a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x147da>
  1b5f2d:	nopl   (%rax)
  1b5f30:	add    %rsi,%rdi
  1b5f33:	cmp    %rbx,%rdi
  1b5f36:	jae    1bdd20 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14ea0>
  1b5f3c:	cmpq   $0x5,0x1e0(%rsp)
  1b5f45:	jbe    1bdc97 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14e17>
  1b5f4b:	shl    $0x4,%rdi
  1b5f4f:	movupd 0x50(%r12),%xmm1
  1b5f56:	movupd %xmm1,(%r15,%rdi,1)
  1b5f5c:	add    $0x8,%rdx
  1b5f60:	cmp    %rdx,%r13
  1b5f63:	jne    1b5ede <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd05e>
  1b5f69:	test   %r9b,%r9b
  1b5f6c:	mov    %rsi,0x60(%rsp)
  1b5f71:	mov    %r9d,0x20(%rsp)
  1b5f76:	je     1b6238 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd3b8>
  1b5f7c:	mov    0x30(%rsp),%rax
  1b5f81:	cmp    0x10(%rsp),%rax
  1b5f86:	jae    1b63af <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd52f>
  1b5f8c:	cmpq   $0x7,0x1e0(%rsp)
  1b5f95:	jb     1bf085 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16205>
  1b5f9b:	imul   $0x57,(%rsp),%rdx
  1b5fa0:	mov    0x30(%rsp),%r14
  1b5fa5:	mov    0x60(%rsp),%rax
  1b5faa:	lea    (%r14,%rax,1),%r11
  1b5fae:	xor    %eax,%eax
  1b5fb0:	mov    %rbx,%rcx
  1b5fb3:	sub    %r11,%rcx
  1b5fb6:	cmovb  %rax,%rcx
  1b5fba:	lea    (%r14,%rdx,1),%rdi
  1b5fbe:	mov    %rbx,%rsi
  1b5fc1:	mov    %rdi,%rbx
  1b5fc4:	sub    %rdi,%rsi
  1b5fc7:	cmovb  %rax,%rsi
  1b5fcb:	cmp    %rsi,%rcx
  1b5fce:	cmovae %rsi,%rcx
  1b5fd2:	mov    %r14,%rbp
  1b5fd5:	not    %rbp
  1b5fd8:	add    0x10(%rsp),%rbp
  1b5fdd:	cmp    %rbp,%rcx
  1b5fe0:	cmovae %rbp,%rcx
  1b5fe4:	lea    0x1(%rcx),%rdi
  1b5fe8:	mov    %r14,%r10
  1b5feb:	cmp    $0x22,%rdi
  1b5fef:	mov    %rbp,0x50(%rsp)
  1b5ff4:	ja     1b6a42 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xdbc2>
  1b5ffa:	mov    (%rsp),%rax
  1b5ffe:	imul   $0x570,%rax,%r9
  1b6005:	mov    %r10,%rcx
  1b6008:	shl    $0x4,%rcx
  1b600c:	add    %r15,%rcx
  1b600f:	imul   $0x560,%rax,%r8
  1b6016:	mov    0x8(%rsp),%rax
  1b601b:	mov    0x60(%rsp),%r11
  1b6020:	lea    (%r11,%r10,1),%rdi
  1b6024:	cmp    %rax,%rdi
  1b6027:	jae    1be726 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x158a6>
  1b602d:	lea    (%rdx,%r10,1),%rdi
  1b6031:	cmp    %rax,%rdi
  1b6034:	jae    1be716 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15896>
  1b603a:	inc    %r10
  1b603d:	movupd 0x60(%r12),%xmm0
  1b6044:	movsd  (%rcx,%r8,1),%xmm1
  1b604a:	movsd  0x8(%rcx,%r8,1),%xmm2
  1b6051:	unpcklpd %xmm1,%xmm1
  1b6055:	mulpd  %xmm0,%xmm1
  1b6059:	shufpd $0x1,%xmm0,%xmm0
  1b605e:	unpcklpd %xmm2,%xmm2
  1b6062:	mulpd  %xmm0,%xmm2
  1b6066:	movapd %xmm1,%xmm0
  1b606a:	subpd  %xmm2,%xmm0
  1b606e:	addpd  %xmm1,%xmm2
  1b6072:	movsd  %xmm0,%xmm2
  1b6076:	movupd %xmm2,(%rcx,%r9,1)
  1b607c:	add    $0x10,%rcx
  1b6080:	cmp    %r10,0x10(%rsp)
  1b6085:	jne    1b6020 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd1a0>
  1b6087:	cmpq   $0x6,0x1e0(%rsp)
  1b6090:	jb     1bdc97 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14e17>
  1b6096:	imul   $0x58,(%rsp),%rcx
  1b609b:	mov    0x30(%rsp),%r8
  1b60a0:	lea    (%r8,%rcx,1),%r12
  1b60a4:	xor    %edi,%edi
  1b60a6:	sub    %r12,%rax
  1b60a9:	cmovae %rax,%rdi
  1b60ad:	cmp    %rdi,%rsi
  1b60b0:	mov    %rdi,0x18(%rsp)
  1b60b5:	cmovb  %rsi,%rdi
  1b60b9:	cmp    %rbp,%rdi
  1b60bc:	cmovae %rbp,%rdi
  1b60c0:	lea    0x1(%rdi),%rax
  1b60c4:	mov    %r8,%r14
  1b60c7:	cmp    $0x2a,%rax
  1b60cb:	ja     1b6cb1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xde31>
  1b60d1:	imul   $0x580,(%rsp),%rsi
  1b60d9:	mov    %r14,%r10
  1b60dc:	shl    $0x4,%r10
  1b60e0:	add    %r15,%r10
  1b60e3:	mov    0x8(%rsp),%rbx
  1b60e8:	mov    0x1d8(%rsp),%rax
  1b60f0:	lea    (%rdx,%r14,1),%rdi
  1b60f4:	cmp    %rbx,%rdi
  1b60f7:	jae    1be746 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x158c6>
  1b60fd:	lea    (%rcx,%r14,1),%rdi
  1b6101:	cmp    %rbx,%rdi
  1b6104:	jae    1be736 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x158b6>
  1b610a:	inc    %r14
  1b610d:	movupd 0x50(%rax),%xmm0
  1b6112:	movupd (%r10,%r9,1),%xmm1
  1b6118:	addpd  %xmm0,%xmm1
  1b611c:	movupd %xmm1,(%r10,%rsi,1)
  1b6122:	add    $0x10,%r10
  1b6126:	cmp    %r14,0x10(%rsp)
  1b612b:	jne    1b60f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd270>
  1b612d:	mov    (%rsp),%rax
  1b6131:	imul   $0x47,%rax,%rdx
  1b6135:	imul   $0x59,%rax,%r12
  1b6139:	mov    0x30(%rsp),%r8
  1b613e:	lea    (%r8,%rdx,1),%rdi
  1b6142:	xor    %eax,%eax
  1b6144:	mov    %rbx,%r9
  1b6147:	mov    %rdi,0x38(%rsp)
  1b614c:	sub    %rdi,%r9
  1b614f:	cmovb  %rax,%r9
  1b6153:	mov    0x18(%rsp),%rdi
  1b6158:	cmp    %rdi,%r9
  1b615b:	cmovae %rdi,%r9
  1b615f:	lea    (%r8,%r12,1),%r10
  1b6163:	mov    %rbx,%rdi
  1b6166:	mov    %r10,0x40(%rsp)
  1b616b:	sub    %r10,%rdi
  1b616e:	cmovb  %rax,%rdi
  1b6172:	cmp    %rdi,%r9
  1b6175:	cmovb  %r9,%rdi
  1b6179:	cmp    %rbp,%rdi
  1b617c:	cmovae %rbp,%rdi
  1b6180:	lea    0x1(%rdi),%rax
  1b6184:	mov    %r8,%r14
  1b6187:	cmp    $0x2e,%rax
  1b618b:	ja     1b6eb1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xe031>
  1b6191:	mov    (%rsp),%r9
  1b6195:	imul   $0x590,%r9,%rax
  1b619c:	mov    %r14,%r8
  1b619f:	shl    $0x4,%r8
  1b61a3:	add    %r15,%r8
  1b61a6:	imul   $0x470,%r9,%r9
  1b61ad:	mov    0x28(%rsp),%r11
  1b61b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b61c0:	lea    (%rdx,%r14,1),%rdi
  1b61c4:	cmp    %rbx,%rdi
  1b61c7:	jae    1be776 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x158f6>
  1b61cd:	lea    (%rcx,%r14,1),%rdi
  1b61d1:	cmp    %rbx,%rdi
  1b61d4:	jae    1be766 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x158e6>
  1b61da:	lea    (%r12,%r14,1),%rdi
  1b61de:	cmp    %rbx,%rdi
  1b61e1:	jae    1be756 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x158d6>
  1b61e7:	inc    %r14
  1b61ea:	movupd (%r8,%r9,1),%xmm0
  1b61f0:	movsd  (%r8,%rsi,1),%xmm1
  1b61f6:	movsd  0x8(%r8,%rsi,1),%xmm2
  1b61fd:	unpcklpd %xmm1,%xmm1
  1b6201:	mulpd  %xmm0,%xmm1
  1b6205:	shufpd $0x1,%xmm0,%xmm0
  1b620a:	unpcklpd %xmm2,%xmm2
  1b620e:	mulpd  %xmm0,%xmm2
  1b6212:	movapd %xmm1,%xmm0
  1b6216:	subpd  %xmm2,%xmm0
  1b621a:	addpd  %xmm1,%xmm2
  1b621e:	movsd  %xmm0,%xmm2
  1b6222:	movupd %xmm2,(%r8,%rax,1)
  1b6228:	add    $0x10,%r8
  1b622c:	cmp    %r14,0x10(%rsp)
  1b6231:	jne    1b61c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd340>
  1b6233:	jmp    1b63b4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd534>
  1b6238:	cmpq   $0x7,0x1e0(%rsp)
  1b6241:	jb     1bf085 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16205>
  1b6247:	imul   $0x57,(%rsp),%rcx
  1b624c:	xor    %edx,%edx
  1b624e:	xchg   %ax,%ax
  1b6250:	mov    (%r11,%rdx,1),%rdi
  1b6254:	lea    (%rdi,%rsi,1),%rax
  1b6258:	cmp    %rbx,%rax
  1b625b:	jae    1bdf6c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x150ec>
  1b6261:	add    %rcx,%rdi
  1b6264:	cmp    %rbx,%rdi
  1b6267:	jae    1bdf5c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x150dc>
  1b626d:	shl    $0x4,%rax
  1b6271:	shl    $0x4,%rdi
  1b6275:	movupd 0x60(%r12),%xmm0
  1b627c:	movsd  (%r15,%rax,1),%xmm1
  1b6282:	movsd  0x8(%r15,%rax,1),%xmm2
  1b6289:	unpcklpd %xmm1,%xmm1
  1b628d:	mulpd  %xmm0,%xmm1
  1b6291:	shufpd $0x1,%xmm0,%xmm0
  1b6296:	unpcklpd %xmm2,%xmm2
  1b629a:	mulpd  %xmm0,%xmm2
  1b629e:	movapd %xmm1,%xmm0
  1b62a2:	subpd  %xmm2,%xmm0
  1b62a6:	addpd  %xmm1,%xmm2
  1b62aa:	movsd  %xmm0,%xmm2
  1b62ae:	movupd %xmm2,(%r15,%rdi,1)
  1b62b4:	add    $0x8,%rdx
  1b62b8:	cmp    %rdx,%r13
  1b62bb:	jne    1b6250 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd3d0>
  1b62bd:	imul   $0x58,(%rsp),%rdx
  1b62c2:	xor    %esi,%esi
  1b62c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b62d0:	mov    (%r11,%rsi,1),%rdi
  1b62d4:	lea    (%rdi,%rcx,1),%rax
  1b62d8:	cmp    %rbx,%rax
  1b62db:	jae    1bdf8f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1510f>
  1b62e1:	add    %rdx,%rdi
  1b62e4:	cmp    %rbx,%rdi
  1b62e7:	jae    1bdf7f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x150ff>
  1b62ed:	shl    $0x4,%rax
  1b62f1:	shl    $0x4,%rdi
  1b62f5:	movupd 0x50(%r12),%xmm0
  1b62fc:	movupd (%r15,%rax,1),%xmm1
  1b6302:	addpd  %xmm0,%xmm1
  1b6306:	movupd %xmm1,(%r15,%rdi,1)
  1b630c:	add    $0x8,%rsi
  1b6310:	cmp    %rsi,%r13
  1b6313:	jne    1b62d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd450>
  1b6315:	mov    (%rsp),%rax
  1b6319:	imul   $0x47,%rax,%rsi
  1b631d:	imul   $0x59,%rax,%r12
  1b6321:	xor    %r8d,%r8d
  1b6324:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b6330:	mov    (%r11,%r8,1),%rdi
  1b6334:	lea    (%rdi,%rsi,1),%rax
  1b6338:	cmp    %rbx,%rax
  1b633b:	jae    1bdfc5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15145>
  1b6341:	lea    (%rdi,%rdx,1),%rcx
  1b6345:	cmp    %rbx,%rcx
  1b6348:	jae    1bdfb2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15132>
  1b634e:	add    %r12,%rdi
  1b6351:	cmp    %rbx,%rdi
  1b6354:	jae    1bdfa2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15122>
  1b635a:	shl    $0x4,%rax
  1b635e:	shl    $0x4,%rcx
  1b6362:	shl    $0x4,%rdi
  1b6366:	movupd (%r15,%rax,1),%xmm0
  1b636c:	movsd  (%r15,%rcx,1),%xmm1
  1b6372:	movsd  0x8(%r15,%rcx,1),%xmm2
  1b6379:	unpcklpd %xmm1,%xmm1
  1b637d:	mulpd  %xmm0,%xmm1
  1b6381:	shufpd $0x1,%xmm0,%xmm0
  1b6386:	unpcklpd %xmm2,%xmm2
  1b638a:	mulpd  %xmm0,%xmm2
  1b638e:	movapd %xmm1,%xmm0
  1b6392:	subpd  %xmm2,%xmm0
  1b6396:	addpd  %xmm1,%xmm2
  1b639a:	movsd  %xmm0,%xmm2
  1b639e:	movupd %xmm2,(%r15,%rdi,1)
  1b63a4:	add    $0x8,%r8
  1b63a8:	cmp    %r8,%r13
  1b63ab:	jne    1b6330 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd4b0>
  1b63ad:	jmp    1b63b4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd534>
  1b63af:	imul   $0x59,(%rsp),%r12
  1b63b4:	imul   $0x5a,(%rsp),%rax
  1b63b9:	mov    %rax,0x18(%rsp)
  1b63be:	xor    %ebp,%ebp
  1b63c0:	mov    (%r11,%rbp,1),%r14
  1b63c4:	lea    (%r14,%r12,1),%rdi
  1b63c8:	cmp    %rbx,%rdi
  1b63cb:	jae    1bd889 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14a09>
  1b63d1:	shl    $0x4,%rdi
  1b63d5:	movsd  (%r15,%rdi,1),%xmm0
  1b63db:	movsd  0x8(%r15,%rdi,1),%xmm1
  1b63e2:	call   1a8a60 <oneloop::native::primitives::log::<f64>>
  1b63e7:	add    0x18(%rsp),%r14
  1b63ec:	cmp    %rbx,%r14
  1b63ef:	jae    1bd876 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x149f6>
  1b63f5:	shl    $0x4,%r14
  1b63f9:	movsd  %xmm0,(%r15,%r14,1)
  1b63ff:	movsd  %xmm1,0x8(%r15,%r14,1)
  1b6406:	add    $0x8,%rbp
  1b640a:	cmp    %rbp,%r13
  1b640d:	mov    0x1b0(%rsp),%r9
  1b6415:	mov    0x28(%rsp),%r11
  1b641a:	mov    0x90(%rsp),%rcx
  1b6422:	mov    0x1c8(%rsp),%r10
  1b642a:	jne    1b63c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd540>
  1b642c:	cmpb   $0x0,0x20(%rsp)
  1b6431:	je     1b6690 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd810>
  1b6437:	mov    0x10(%rsp),%r13
  1b643c:	cmp    %r13,0x30(%rsp)
  1b6441:	mov    0x1d8(%rsp),%r12
  1b6449:	mov    0x1d0(%rsp),%rdx
  1b6451:	mov    0x110(%rsp),%r8
  1b6459:	mov    0x60(%rsp),%rsi
  1b645e:	jae    1b67e8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd968>
  1b6464:	imul   $0x5b,(%rsp),%rax
  1b6469:	cmpq   $0x8,0x1e0(%rsp)
  1b6472:	jb     1bf09f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1621f>
  1b6478:	je     1bf0b9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16239>
  1b647e:	mov    0x30(%rsp),%rcx
  1b6483:	lea    (%rcx,%rsi,1),%r11
  1b6487:	xor    %edi,%edi
  1b6489:	mov    %rbx,%rsi
  1b648c:	sub    %r11,%rsi
  1b648f:	cmovb  %rdi,%rsi
  1b6493:	lea    (%rcx,%rax,1),%r14
  1b6497:	mov    %rbx,%rdx
  1b649a:	sub    %r14,%rdx
  1b649d:	cmovb  %rdi,%rdx
  1b64a1:	cmp    %rdx,%rsi
  1b64a4:	cmovae %rdx,%rsi
  1b64a8:	mov    %rcx,%rbp
  1b64ab:	not    %rbp
  1b64ae:	add    %r13,%rbp
  1b64b1:	cmp    %rbp,%rsi
  1b64b4:	cmovae %rbp,%rsi
  1b64b8:	lea    0x1(%rsi),%rdi
  1b64bc:	mov    %rcx,%r9
  1b64bf:	cmp    $0x16,%rdi
  1b64c3:	mov    %rbp,0x20(%rsp)
  1b64c8:	ja     1b72a6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xe426>
  1b64ce:	mov    (%rsp),%rcx
  1b64d2:	imul   $0x5b0,%rcx,%rsi
  1b64d9:	mov    %r9,%r8
  1b64dc:	shl    $0x4,%r8
  1b64e0:	add    %r15,%r8
  1b64e3:	imul   $0x560,%rcx,%r10
  1b64ea:	mov    0x10(%rsp),%r11
  1b64ef:	mov    0x60(%rsp),%rcx
  1b64f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b6500:	lea    (%rcx,%r9,1),%rdi
  1b6504:	cmp    %rbx,%rdi
  1b6507:	jae    1be796 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15916>
  1b650d:	lea    (%rax,%r9,1),%rdi
  1b6511:	cmp    %rbx,%rdi
  1b6514:	jae    1be786 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15906>
  1b651a:	inc    %r9
  1b651d:	movupd 0x70(%r12),%xmm0
  1b6524:	movupd 0x80(%r12),%xmm1
  1b652e:	movapd %xmm0,%xmm2
  1b6532:	mulpd  %xmm1,%xmm2
  1b6536:	movupd (%r8,%r10,1),%xmm3
  1b653c:	movapd %xmm2,%xmm4
  1b6540:	unpcklpd %xmm2,%xmm4
  1b6544:	unpckhpd %xmm2,%xmm2
  1b6548:	subpd  %xmm2,%xmm4
  1b654c:	mulpd  %xmm3,%xmm4
  1b6550:	movapd %xmm1,%xmm2
  1b6554:	unpckhpd %xmm1,%xmm2
  1b6558:	mulsd  %xmm0,%xmm2
  1b655c:	unpckhpd %xmm0,%xmm0
  1b6560:	mulsd  %xmm1,%xmm0
  1b6564:	addsd  %xmm2,%xmm0
  1b6568:	unpcklpd %xmm0,%xmm0
  1b656c:	shufpd $0x1,%xmm3,%xmm3
  1b6571:	mulpd  %xmm0,%xmm3
  1b6575:	movapd %xmm4,%xmm0
  1b6579:	subpd  %xmm3,%xmm0
  1b657d:	addpd  %xmm4,%xmm3
  1b6581:	movsd  %xmm0,%xmm3
  1b6585:	movupd %xmm3,(%r8,%rsi,1)
  1b658b:	add    $0x10,%r8
  1b658f:	cmp    %r9,%r11
  1b6592:	jne    1b6500 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd680>
  1b6598:	imul   $0x5c,(%rsp),%r8
  1b659d:	mov    0x30(%rsp),%r12
  1b65a2:	mov    0x18(%rsp),%rcx
  1b65a7:	add    %r12,%rcx
  1b65aa:	xor    %r9d,%r9d
  1b65ad:	mov    %rbx,%r10
  1b65b0:	sub    %rcx,%r10
  1b65b3:	cmovb  %r9,%r10
  1b65b7:	cmp    %rdx,%r10
  1b65ba:	cmovae %rdx,%r10
  1b65be:	lea    (%r12,%r8,1),%r13
  1b65c2:	mov    %rbx,%rdi
  1b65c5:	sub    %r13,%rdi
  1b65c8:	cmovb  %r9,%rdi
  1b65cc:	cmp    %rdi,%r10
  1b65cf:	cmovb  %r10,%rdi
  1b65d3:	cmp    %rbp,%rdi
  1b65d6:	cmovae %rbp,%rdi
  1b65da:	lea    0x1(%rdi),%r9
  1b65de:	mov    %r12,%r14
  1b65e1:	cmp    $0x42,%r9
  1b65e5:	ja     1b7531 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xe6b1>
  1b65eb:	mov    (%rsp),%r9
  1b65ef:	imul   $0x5c0,%r9,%rcx
  1b65f6:	mov    %r14,%rdx
  1b65f9:	shl    $0x4,%rdx
  1b65fd:	add    %r15,%rdx
  1b6600:	imul   $0x5a0,%r9,%r9
  1b6607:	mov    0x28(%rsp),%r11
  1b660c:	mov    0x1c8(%rsp),%r10
  1b6614:	mov    0x10(%rsp),%r13
  1b6619:	nopl   0x0(%rax)
  1b6620:	mov    0x18(%rsp),%rdi
  1b6625:	add    %r14,%rdi
  1b6628:	cmp    %rbx,%rdi
  1b662b:	jae    1be7c6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15946>
  1b6631:	lea    (%rax,%r14,1),%rdi
  1b6635:	cmp    %rbx,%rdi
  1b6638:	jae    1be7b6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15936>
  1b663e:	lea    (%r8,%r14,1),%rdi
  1b6642:	cmp    %rbx,%rdi
  1b6645:	jae    1be7a6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15926>
  1b664b:	inc    %r14
  1b664e:	movupd (%rdx,%r9,1),%xmm0
  1b6654:	movupd (%rdx,%rsi,1),%xmm1
  1b6659:	addpd  %xmm0,%xmm1
  1b665d:	movupd %xmm1,(%rdx,%rcx,1)
  1b6662:	add    $0x10,%rdx
  1b6666:	cmp    %r14,%r13
  1b6669:	jne    1b6620 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd7a0>
  1b666b:	mov    0x1b0(%rsp),%r9
  1b6673:	mov    0x1d0(%rsp),%rdx
  1b667b:	mov    0x90(%rsp),%rcx
  1b6683:	mov    0x110(%rsp),%r8
  1b668b:	jmp    1b67ed <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd96d>
  1b6690:	imul   $0x5b,(%rsp),%rdx
  1b6695:	cmpq   $0x8,0x1e0(%rsp)
  1b669e:	mov    0x1d8(%rsp),%rsi
  1b66a6:	mov    0x30(%rsp),%r12
  1b66ab:	mov    0x60(%rsp),%r8
  1b66b0:	jb     1bf09f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1621f>
  1b66b6:	je     1bf0b9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16239>
  1b66bc:	xor    %ecx,%ecx
  1b66be:	xchg   %ax,%ax
  1b66c0:	mov    (%r11,%rcx,1),%rdi
  1b66c4:	lea    (%rdi,%r8,1),%rax
  1b66c8:	cmp    %rbx,%rax
  1b66cb:	jae    1bdfe8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15168>
  1b66d1:	add    %rdx,%rdi
  1b66d4:	cmp    %rbx,%rdi
  1b66d7:	jae    1bdfd8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15158>
  1b66dd:	shl    $0x4,%rax
  1b66e1:	movupd 0x70(%rsi),%xmm0
  1b66e6:	movupd 0x80(%rsi),%xmm1
  1b66ee:	movapd %xmm0,%xmm2
  1b66f2:	mulpd  %xmm1,%xmm2
  1b66f6:	shl    $0x4,%rdi
  1b66fa:	movupd (%r15,%rax,1),%xmm3
  1b6700:	movapd %xmm2,%xmm4
  1b6704:	unpcklpd %xmm2,%xmm4
  1b6708:	unpckhpd %xmm2,%xmm2
  1b670c:	subpd  %xmm2,%xmm4
  1b6710:	mulpd  %xmm3,%xmm4
  1b6714:	movapd %xmm1,%xmm2
  1b6718:	unpckhpd %xmm1,%xmm2
  1b671c:	mulsd  %xmm0,%xmm2
  1b6720:	unpckhpd %xmm0,%xmm0
  1b6724:	mulsd  %xmm1,%xmm0
  1b6728:	addsd  %xmm2,%xmm0
  1b672c:	unpcklpd %xmm0,%xmm0
  1b6730:	shufpd $0x1,%xmm3,%xmm3
  1b6735:	mulpd  %xmm0,%xmm3
  1b6739:	movapd %xmm4,%xmm0
  1b673d:	subpd  %xmm3,%xmm0
  1b6741:	addpd  %xmm4,%xmm3
  1b6745:	movsd  %xmm0,%xmm3
  1b6749:	movupd %xmm3,(%r15,%rdi,1)
  1b674f:	add    $0x8,%rcx
  1b6753:	cmp    %rcx,%r13
  1b6756:	jne    1b66c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd840>
  1b675c:	imul   $0x5c,(%rsp),%rsi
  1b6761:	xor    %r8d,%r8d
  1b6764:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b6770:	mov    (%r11,%r8,1),%rdi
  1b6774:	mov    0x18(%rsp),%rax
  1b6779:	add    %rdi,%rax
  1b677c:	cmp    %rbx,%rax
  1b677f:	jae    1be01e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1519e>
  1b6785:	lea    (%rdi,%rdx,1),%rcx
  1b6789:	cmp    %rbx,%rcx
  1b678c:	jae    1be00b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1518b>
  1b6792:	add    %rsi,%rdi
  1b6795:	cmp    %rbx,%rdi
  1b6798:	jae    1bdffb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1517b>
  1b679e:	shl    $0x4,%rax
  1b67a2:	shl    $0x4,%rcx
  1b67a6:	shl    $0x4,%rdi
  1b67aa:	movupd (%r15,%rax,1),%xmm0
  1b67b0:	movupd (%r15,%rcx,1),%xmm1
  1b67b6:	addpd  %xmm0,%xmm1
  1b67ba:	movupd %xmm1,(%r15,%rdi,1)
  1b67c0:	add    $0x8,%r8
  1b67c4:	cmp    %r8,%r13
  1b67c7:	jne    1b6770 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd8f0>
  1b67c9:	mov    0x1d0(%rsp),%rdx
  1b67d1:	mov    0x90(%rsp),%rcx
  1b67d9:	mov    0x110(%rsp),%r8
  1b67e1:	mov    0x10(%rsp),%r13
  1b67e6:	jmp    1b67ed <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd96d>
  1b67e8:	mov    0x30(%rsp),%r12
  1b67ed:	xor    %eax,%eax
  1b67ef:	xor    %r14d,%r14d
  1b67f2:	jmp    1b6810 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd990>
  1b67f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b6800:	mov    %rdi,(%r11,%r14,8)
  1b6804:	inc    %r14
  1b6807:	add    $0x8,%rax
  1b680b:	cmp    %rax,%rcx
  1b680e:	je     1b683c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd9bc>
  1b6810:	mov    (%r8,%rax,1),%rdi
  1b6814:	cmp    %rdx,%rdi
  1b6817:	jae    1bd5da <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1475a>
  1b681d:	cmpq   $0x5a,(%r10,%rdi,8)
  1b6822:	jae    1b6807 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd987>
  1b6824:	cmp    %r9,%r14
  1b6827:	jb     1b6800 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd980>
  1b6829:	lea    0x246c278(%rip),%rdx        # 2622aa8 <__gmpfr_one+0xb328>
  1b6830:	mov    %r14,%rdi
  1b6833:	mov    %r9,%rsi
  1b6836:	call   *0x25186c4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1b683c:	cmp    %r9,%r14
  1b683f:	ja     1bd2a6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14426>
  1b6845:	test   %r14,%r14
  1b6848:	je     1b7d1e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xee9e>
  1b684e:	mov    (%r11),%rax
  1b6851:	lea    -0x1(%r14),%rcx
  1b6855:	mov    -0x8(%r11,%r14,8),%rdx
  1b685a:	sub    %rax,%rdx
  1b685d:	setae  %sil
  1b6861:	cmp    %rcx,%rdx
  1b6864:	sete   %cl
  1b6867:	and    %sil,%cl
  1b686a:	cmp    $0x1,%cl
  1b686d:	jne    1b6886 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xda06>
  1b686f:	mov    %rax,%rcx
  1b6872:	add    %r14,%rcx
  1b6875:	jb     1b6886 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xda06>
  1b6877:	mov    $0x1,%bpl
  1b687a:	mov    %rcx,0x10(%rsp)
  1b687f:	mov    %rax,0x30(%rsp)
  1b6884:	jmp    1b6892 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xda12>
  1b6886:	mov    %r12,0x30(%rsp)
  1b688b:	mov    %r13,0x10(%rsp)
  1b6890:	xor    %ebp,%ebp
  1b6892:	shl    $0x3,%r14
  1b6896:	imul   $0x4a,(%rsp),%r12
  1b689b:	xor    %r13d,%r13d
  1b689e:	xorpd  %xmm1,%xmm1
  1b68a2:	jmp    1b68d7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xda57>
  1b68a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b68b0:	mov    $0x5e,%r8d
  1b68b6:	mov    %r15,%rdi
  1b68b9:	mov    %rbx,%rsi
  1b68bc:	mov    (%rsp),%rdx
  1b68c0:	call   1a8d70 <oneloop::native::batch::copy_active_column::<f64>>
  1b68c5:	add    $0x8,%r13
  1b68c9:	cmp    %r13,%r14
  1b68cc:	mov    0x28(%rsp),%r11
  1b68d1:	xorpd  %xmm1,%xmm1
  1b68d5:	je     1b6918 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xda98>
  1b68d7:	mov    (%r11,%r13,1),%rcx
  1b68db:	lea    (%rcx,%r12,1),%rdi
  1b68df:	cmp    %rbx,%rdi
  1b68e2:	jae    1bd899 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14a19>
  1b68e8:	shl    $0x4,%rdi
  1b68ec:	movsd  (%r15,%rdi,1),%xmm0
  1b68f2:	mov    $0x4c,%r9d
  1b68f8:	ucomisd %xmm1,%xmm0
  1b68fc:	jne    1b68b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xda30>
  1b68fe:	jp     1b68b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xda30>
  1b6900:	add    %r15,%rdi
  1b6903:	movsd  0x8(%rdi),%xmm0
  1b6908:	ucomisd %xmm1,%xmm0
  1b690c:	jne    1b68b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xda30>
  1b690e:	jp     1b68b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xda30>
  1b6910:	mov    $0x5c,%r9d
  1b6916:	jmp    1b68b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xda30>
  1b6918:	test   %bpl,%bpl
  1b691b:	je     1b69ab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xdb2b>
  1b6921:	mov    0x10(%rsp),%r13
  1b6926:	mov    0x30(%rsp),%r12
  1b692b:	cmp    %r13,%r12
  1b692e:	jae    1b7cd1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xee51>
  1b6934:	mov    (%rsp),%rdx
  1b6938:	imul   $0x27,%rdx,%rax
  1b693c:	imul   $0x5e,%rdx,%rcx
  1b6940:	imul   $0x5f,%rdx,%rdx
  1b6944:	mov    %r12,%r11
  1b6947:	not    %r11
  1b694a:	add    %r13,%r11
  1b694d:	lea    (%r12,%rax,1),%r8
  1b6951:	xor    %edi,%edi
  1b6953:	mov    %rbx,%rsi
  1b6956:	mov    %r8,0x18(%rsp)
  1b695b:	sub    %r8,%rsi
  1b695e:	cmovb  %rdi,%rsi
  1b6962:	lea    (%r12,%rcx,1),%r10
  1b6966:	mov    %rbx,%r8
  1b6969:	sub    %r10,%r8
  1b696c:	cmovb  %rdi,%r8
  1b6970:	cmp    %r8,%rsi
  1b6973:	cmovb  %rsi,%r8
  1b6977:	lea    (%r12,%rdx,1),%r9
  1b697b:	mov    %rbx,%rsi
  1b697e:	sub    %r9,%rsi
  1b6981:	cmovb  %rdi,%rsi
  1b6985:	cmp    %rsi,%r8
  1b6988:	cmovb  %r8,%rsi
  1b698c:	cmp    %rsi,%r11
  1b698f:	cmovb  %r11,%rsi
  1b6993:	lea    0x1(%rsi),%rdi
  1b6997:	cmp    $0x32,%rdi
  1b699b:	ja     1b7879 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xe9f9>
  1b69a1:	mov    0x28(%rsp),%r11
  1b69a6:	jmp    1b7c32 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xedb2>
  1b69ab:	mov    (%rsp),%rcx
  1b69af:	imul   $0x27,%rcx,%rdx
  1b69b3:	imul   $0x5e,%rcx,%rsi
  1b69b7:	imul   $0x5f,%rcx,%r8
  1b69bb:	xor    %r9d,%r9d
  1b69be:	xchg   %ax,%ax
  1b69c0:	mov    (%r11,%r9,1),%rdi
  1b69c4:	lea    (%rdi,%rdx,1),%rax
  1b69c8:	cmp    %rbx,%rax
  1b69cb:	jae    1be054 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x151d4>
  1b69d1:	lea    (%rdi,%rsi,1),%rcx
  1b69d5:	cmp    %rbx,%rcx
  1b69d8:	jae    1be041 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x151c1>
  1b69de:	add    %r8,%rdi
  1b69e1:	cmp    %rbx,%rdi
  1b69e4:	jae    1be031 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x151b1>
  1b69ea:	shl    $0x4,%rax
  1b69ee:	shl    $0x4,%rcx
  1b69f2:	shl    $0x4,%rdi
  1b69f6:	movupd (%r15,%rax,1),%xmm0
  1b69fc:	movsd  (%r15,%rcx,1),%xmm1
  1b6a02:	movsd  0x8(%r15,%rcx,1),%xmm2
  1b6a09:	unpcklpd %xmm1,%xmm1
  1b6a0d:	mulpd  %xmm0,%xmm1
  1b6a11:	shufpd $0x1,%xmm0,%xmm0
  1b6a16:	unpcklpd %xmm2,%xmm2
  1b6a1a:	mulpd  %xmm0,%xmm2
  1b6a1e:	movapd %xmm1,%xmm0
  1b6a22:	subpd  %xmm2,%xmm0
  1b6a26:	addpd  %xmm1,%xmm2
  1b6a2a:	movsd  %xmm0,%xmm2
  1b6a2e:	movupd %xmm2,(%r15,%rdi,1)
  1b6a34:	add    $0x8,%r9
  1b6a38:	cmp    %r9,%r14
  1b6a3b:	jne    1b69c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xdb40>
  1b6a3d:	jmp    1b7cd1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xee51>
  1b6a42:	xor    %edi,%edi
  1b6a44:	mov    0x8(%rsp),%r9
  1b6a49:	mov    %r9,%r8
  1b6a4c:	sub    %r11,%r8
  1b6a4f:	cmovb  %rdi,%r8
  1b6a53:	sub    %rbx,%r9
  1b6a56:	cmovb  %rdi,%r9
  1b6a5a:	cmp    %r9,%r8
  1b6a5d:	cmovb  %r8,%r9
  1b6a61:	cmp    %rbp,%r9
  1b6a64:	cmovae %rbp,%r9
  1b6a68:	imul   $0x560,(%rsp),%rdi
  1b6a70:	mov    %r14,%r8
  1b6a73:	shl    $0x4,%r8
  1b6a77:	lea    (%r15,%rdi,1),%r10
  1b6a7b:	mov    %rbx,%rax
  1b6a7e:	lea    (%r8,%r10,1),%rbx
  1b6a82:	add    $0x8,%rbx
  1b6a86:	add    %r8,%r10
  1b6a89:	mov    %r9,%r12
  1b6a8c:	shl    $0x4,%r12
  1b6a90:	add    %r10,%r12
  1b6a93:	add    $0x8,%r12
  1b6a97:	mov    %r14,%r10
  1b6a9a:	cmp    %rbx,%r12
  1b6a9d:	mov    0x1d8(%rsp),%r12
  1b6aa5:	jb     1b5ffa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd17a>
  1b6aab:	mov    %rax,%rbx
  1b6aae:	mov    %r14,%r10
  1b6ab1:	movabs $0xfffffffffffffff,%rax
  1b6abb:	cmp    %rax,%r9
  1b6abe:	ja     1b5ffa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd17a>
  1b6ac4:	imul   $0x570,(%rsp),%r9
  1b6acc:	xor    %r10d,%r10d
  1b6acf:	mov    0x8(%rsp),%rax
  1b6ad4:	mov    %rbx,%r12
  1b6ad7:	mov    %rax,%rbx
  1b6ada:	sub    %r11,%rbx
  1b6add:	cmovb  %r10,%rbx
  1b6ae1:	mov    %rax,%r11
  1b6ae4:	sub    %r12,%r11
  1b6ae7:	cmovb  %r10,%r11
  1b6aeb:	cmp    %r11,%rbx
  1b6aee:	cmovb  %rbx,%r11
  1b6af2:	lea    (%r9,%r8,1),%r10
  1b6af6:	cmp    %rbp,%r11
  1b6af9:	cmovae %rbp,%r11
  1b6afd:	lea    (%r15,%r10,1),%rbx
  1b6b01:	shl    $0x4,%r11
  1b6b05:	lea    (%r11,%rbx,1),%rbp
  1b6b09:	add    $0x8,%rbp
  1b6b0d:	lea    0x8(%r15,%r10,1),%rax
  1b6b12:	mov    %rax,0x100(%rsp)
  1b6b1a:	lea    0x10(%r11,%rbx,1),%r12
  1b6b1f:	mov    %r12,0x40(%rsp)
  1b6b24:	lea    (%rdi,%r8,1),%rax
  1b6b28:	mov    %rax,0x48(%rsp)
  1b6b2d:	lea    (%r15,%rax,1),%r10
  1b6b31:	lea    (%r11,%r10,1),%rax
  1b6b35:	add    $0x8,%rax
  1b6b39:	add    %r10,%r11
  1b6b3c:	add    $0x10,%r11
  1b6b40:	cmp    %r12,%rbx
  1b6b43:	setb   0x18(%rsp)
  1b6b48:	mov    0x100(%rsp),%r12
  1b6b50:	cmp    %rbp,%r12
  1b6b53:	setb   0x38(%rsp)
  1b6b58:	cmp    %rax,%rbx
  1b6b5b:	setb   0xb0(%rsp)
  1b6b63:	cmp    %rbp,%r10
  1b6b66:	setb   0xd0(%rsp)
  1b6b6e:	cmp    %r11,%rbx
  1b6b71:	mov    0x48(%rsp),%rbx
  1b6b76:	lea    0x8(%r15,%rbx,1),%rbx
  1b6b7b:	setb   0x48(%rsp)
  1b6b80:	cmp    %rbp,%rbx
  1b6b83:	setb   0xe0(%rsp)
  1b6b8b:	cmp    %rax,%r12
  1b6b8e:	mov    %r12,%rax
  1b6b91:	setb   0x58(%rsp)
  1b6b96:	mov    0x40(%rsp),%r12
  1b6b9b:	cmp    %r12,%r10
  1b6b9e:	setb   0x88(%rsp)
  1b6ba6:	cmp    %r11,%rax
  1b6ba9:	setb   %al
  1b6bac:	cmp    %r12,%rbx
  1b6baf:	mov    0x50(%rsp),%rbp
  1b6bb4:	mov    0x1d8(%rsp),%r12
  1b6bbc:	setb   %r11b
  1b6bc0:	mov    %r14,%r10
  1b6bc3:	movzbl 0x38(%rsp),%ebx
  1b6bc8:	test   %bl,0x18(%rsp)
  1b6bcc:	jne    1b5ffa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd17a>
  1b6bd2:	mov    %r14,%r10
  1b6bd5:	movzbl 0xd0(%rsp),%ebx
  1b6bdd:	and    %bl,0xb0(%rsp)
  1b6be4:	jne    1b5ffa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd17a>
  1b6bea:	mov    %r14,%r10
  1b6bed:	movzbl 0xe0(%rsp),%ebx
  1b6bf5:	and    %bl,0x48(%rsp)
  1b6bf9:	jne    1b5ffa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd17a>
  1b6bff:	mov    %r14,%r10
  1b6c02:	movzbl 0x88(%rsp),%ebx
  1b6c0a:	and    %bl,0x58(%rsp)
  1b6c0e:	jne    1b5ffa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd17a>
  1b6c14:	mov    %r14,%r10
  1b6c17:	and    %r11b,%al
  1b6c1a:	jne    1b5ffa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd17a>
  1b6c20:	and    $0xfffffffffffffffe,%rcx
  1b6c24:	lea    (%r14,%rcx,1),%r10
  1b6c28:	movsd  0x60(%r12),%xmm0
  1b6c2f:	movsd  0x68(%r12),%xmm1
  1b6c36:	unpcklpd %xmm1,%xmm1
  1b6c3a:	unpcklpd %xmm0,%xmm0
  1b6c3e:	add    %r15,%r8
  1b6c41:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b6c50:	movupd (%r8,%rdi,1),%xmm2
  1b6c56:	movupd 0x10(%r8,%rdi,1),%xmm3
  1b6c5d:	movapd %xmm2,%xmm4
  1b6c61:	unpcklpd %xmm3,%xmm4
  1b6c65:	unpckhpd %xmm3,%xmm2
  1b6c69:	movapd %xmm1,%xmm3
  1b6c6d:	mulpd  %xmm4,%xmm3
  1b6c71:	movapd %xmm0,%xmm5
  1b6c75:	mulpd  %xmm2,%xmm5
  1b6c79:	addpd  %xmm3,%xmm5
  1b6c7d:	mulpd  %xmm0,%xmm4
  1b6c81:	mulpd  %xmm1,%xmm2
  1b6c85:	subpd  %xmm2,%xmm4
  1b6c89:	movapd %xmm4,%xmm2
  1b6c8d:	unpcklpd %xmm5,%xmm2
  1b6c91:	unpckhpd %xmm5,%xmm4
  1b6c95:	movupd %xmm4,0x10(%r8,%r9,1)
  1b6c9c:	movupd %xmm2,(%r8,%r9,1)
  1b6ca2:	add    $0x20,%r8
  1b6ca6:	add    $0xfffffffffffffffe,%rcx
  1b6caa:	jne    1b6c50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xddd0>
  1b6cac:	jmp    1b5ffa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd17a>
  1b6cb1:	xor    %r11d,%r11d
  1b6cb4:	mov    0x8(%rsp),%rax
  1b6cb9:	sub    %r12,%rax
  1b6cbc:	cmovae %rax,%r11
  1b6cc0:	cmp    %r11,%rsi
  1b6cc3:	cmovb  %rsi,%r11
  1b6cc7:	cmp    %rbp,%r11
  1b6cca:	cmovae %rbp,%r11
  1b6cce:	mov    %r8,%r10
  1b6cd1:	shl    $0x4,%r10
  1b6cd5:	lea    (%r15,%r9,1),%rax
  1b6cd9:	lea    (%r10,%rax,1),%rbx
  1b6cdd:	add    $0x8,%rbx
  1b6ce1:	add    %r10,%rax
  1b6ce4:	mov    %r11,%r14
  1b6ce7:	shl    $0x4,%r14
  1b6ceb:	add    %r14,%rax
  1b6cee:	add    $0x8,%rax
  1b6cf2:	mov    %r8,%r14
  1b6cf5:	cmp    %rbx,%rax
  1b6cf8:	jb     1b60d1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd251>
  1b6cfe:	mov    %r8,%r14
  1b6d01:	movabs $0xfffffffffffffff,%rax
  1b6d0b:	cmp    %rax,%r11
  1b6d0e:	ja     1b60d1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd251>
  1b6d14:	imul   $0x580,(%rsp),%r11
  1b6d1c:	xor    %eax,%eax
  1b6d1e:	mov    0x8(%rsp),%rbx
  1b6d23:	sub    %r12,%rbx
  1b6d26:	cmovae %rbx,%rax
  1b6d2a:	cmp    %rax,%rsi
  1b6d2d:	cmovb  %rsi,%rax
  1b6d31:	lea    (%r11,%r10,1),%rsi
  1b6d35:	cmp    %rbp,%rax
  1b6d38:	cmovae %rbp,%rax
  1b6d3c:	lea    (%r15,%rsi,1),%rbx
  1b6d40:	shl    $0x4,%rax
  1b6d44:	lea    (%rax,%rbx,1),%rbp
  1b6d48:	add    $0x8,%rbp
  1b6d4c:	lea    0x8(%r15,%rsi,1),%rsi
  1b6d51:	mov    %rsi,0xb0(%rsp)
  1b6d59:	lea    0x10(%rax,%rbx,1),%r12
  1b6d5e:	mov    %r12,0x100(%rsp)
  1b6d66:	lea    (%r9,%r10,1),%rsi
  1b6d6a:	lea    (%r15,%rsi,1),%r14
  1b6d6e:	lea    0x8(%r15,%rsi,1),%rsi
  1b6d73:	mov    %rsi,0xd0(%rsp)
  1b6d7b:	lea    (%rax,%r14,1),%rsi
  1b6d7f:	add    $0x10,%rsi
  1b6d83:	add    %r14,%rax
  1b6d86:	add    $0x8,%rax
  1b6d8a:	mov    %rax,0x38(%rsp)
  1b6d8f:	cmp    %r12,%rbx
  1b6d92:	setb   0x40(%rsp)
  1b6d97:	mov    0xb0(%rsp),%r12
  1b6d9f:	cmp    %rbp,%r12
  1b6da2:	setb   0x48(%rsp)
  1b6da7:	cmp    %rsi,%rbx
  1b6daa:	setb   0xe0(%rsp)
  1b6db2:	mov    0xd0(%rsp),%rax
  1b6dba:	cmp    %rbp,%rax
  1b6dbd:	setb   0x58(%rsp)
  1b6dc2:	cmp    0x38(%rsp),%rbx
  1b6dc7:	setb   0x78(%rsp)
  1b6dcc:	cmp    %rbp,%r14
  1b6dcf:	setb   0x88(%rsp)
  1b6dd7:	cmp    %rsi,%r12
  1b6dda:	mov    %r12,%rbp
  1b6ddd:	setb   %r12b
  1b6de1:	mov    0x100(%rsp),%rsi
  1b6de9:	cmp    %rsi,%rax
  1b6dec:	setb   0xd0(%rsp)
  1b6df4:	cmp    0x38(%rsp),%rbp
  1b6df9:	mov    0x50(%rsp),%rbp
  1b6dfe:	setb   %al
  1b6e01:	cmp    %rsi,%r14
  1b6e04:	setb   0x38(%rsp)
  1b6e09:	mov    %r8,%r14
  1b6e0c:	movzbl 0x48(%rsp),%esi
  1b6e11:	test   %sil,0x40(%rsp)
  1b6e16:	jne    1b60d1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd251>
  1b6e1c:	mov    %r8,%r14
  1b6e1f:	movzbl 0x58(%rsp),%esi
  1b6e24:	and    %sil,0xe0(%rsp)
  1b6e2c:	jne    1b60d1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd251>
  1b6e32:	mov    %r8,%r14
  1b6e35:	movzbl 0x78(%rsp),%esi
  1b6e3a:	and    0x88(%rsp),%sil
  1b6e42:	jne    1b60d1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd251>
  1b6e48:	mov    %r8,%r14
  1b6e4b:	and    0xd0(%rsp),%r12b
  1b6e53:	jne    1b60d1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd251>
  1b6e59:	mov    %r8,%r14
  1b6e5c:	and    0x38(%rsp),%al
  1b6e60:	jne    1b60d1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd251>
  1b6e66:	and    $0xfffffffffffffffe,%rdi
  1b6e6a:	lea    (%r8,%rdi,1),%r14
  1b6e6e:	mov    0x1d8(%rsp),%rax
  1b6e76:	movupd 0x50(%rax),%xmm0
  1b6e7b:	add    %r15,%r10
  1b6e7e:	xchg   %ax,%ax
  1b6e80:	movupd (%r10,%r9,1),%xmm1
  1b6e86:	movupd 0x10(%r10,%r9,1),%xmm2
  1b6e8d:	addpd  %xmm0,%xmm1
  1b6e91:	addpd  %xmm0,%xmm2
  1b6e95:	movupd %xmm2,0x10(%r10,%r11,1)
  1b6e9c:	movupd %xmm1,(%r10,%r11,1)
  1b6ea2:	add    $0x20,%r10
  1b6ea6:	add    $0xfffffffffffffffe,%rdi
  1b6eaa:	jne    1b6e80 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xe000>
  1b6eac:	jmp    1b60d1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd251>
  1b6eb1:	xor    %eax,%eax
  1b6eb3:	mov    %rbx,%r9
  1b6eb6:	sub    0x38(%rsp),%r9
  1b6ebb:	cmovb  %rax,%r9
  1b6ebf:	mov    0x18(%rsp),%r10
  1b6ec4:	cmp    %r10,%r9
  1b6ec7:	cmovae %r10,%r9
  1b6ecb:	mov    %rbx,%r11
  1b6ece:	sub    0x40(%rsp),%r11
  1b6ed3:	cmovb  %rax,%r11
  1b6ed7:	cmp    %r11,%r9
  1b6eda:	cmovb  %r9,%r11
  1b6ede:	mov    0x50(%rsp),%rax
  1b6ee3:	cmp    %rax,%r11
  1b6ee6:	cmovae %rax,%r11
  1b6eea:	imul   $0x470,(%rsp),%r9
  1b6ef2:	mov    %r8,%r10
  1b6ef5:	shl    $0x4,%r10
  1b6ef9:	lea    (%r15,%r9,1),%rax
  1b6efd:	lea    (%r10,%rax,1),%rbx
  1b6f01:	add    $0x8,%rbx
  1b6f05:	add    %r10,%rax
  1b6f08:	mov    %r11,%rbp
  1b6f0b:	shl    $0x4,%rbp
  1b6f0f:	add    %rbp,%rax
  1b6f12:	add    $0x8,%rax
  1b6f16:	mov    %r8,%r14
  1b6f19:	cmp    %rbx,%rax
  1b6f1c:	mov    0x8(%rsp),%rbx
  1b6f21:	jb     1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b6f27:	lea    (%r15,%rsi,1),%rax
  1b6f2b:	lea    (%r10,%rax,1),%rbx
  1b6f2f:	add    $0x8,%rbx
  1b6f33:	add    %r10,%rax
  1b6f36:	add    %rbp,%rax
  1b6f39:	add    $0x8,%rax
  1b6f3d:	mov    %r8,%r14
  1b6f40:	cmp    %rbx,%rax
  1b6f43:	mov    0x8(%rsp),%rbx
  1b6f48:	jb     1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b6f4e:	mov    %r8,%r14
  1b6f51:	movabs $0xfffffffffffffff,%rax
  1b6f5b:	cmp    %rax,%r11
  1b6f5e:	ja     1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b6f64:	imul   $0x590,(%rsp),%r11
  1b6f6c:	xor    %eax,%eax
  1b6f6e:	mov    0x8(%rsp),%rbx
  1b6f73:	sub    0x38(%rsp),%rbx
  1b6f78:	cmovb  %rax,%rbx
  1b6f7c:	mov    0x18(%rsp),%r14
  1b6f81:	cmp    %r14,%rbx
  1b6f84:	cmovae %r14,%rbx
  1b6f88:	mov    0x8(%rsp),%r14
  1b6f8d:	sub    0x40(%rsp),%r14
  1b6f92:	cmovb  %rax,%r14
  1b6f96:	lea    (%r11,%r10,1),%rax
  1b6f9a:	cmp    %r14,%rbx
  1b6f9d:	cmovb  %rbx,%r14
  1b6fa1:	lea    (%r15,%rax,1),%rbp
  1b6fa5:	mov    %rax,%rbx
  1b6fa8:	mov    0x50(%rsp),%rax
  1b6fad:	cmp    %rax,%r14
  1b6fb0:	cmovae %rax,%r14
  1b6fb4:	shl    $0x4,%r14
  1b6fb8:	lea    (%r14,%rbp,1),%rax
  1b6fbc:	add    $0x8,%rax
  1b6fc0:	mov    %rax,0xd0(%rsp)
  1b6fc8:	lea    0x8(%r15,%rbx,1),%rax
  1b6fcd:	mov    %rax,0x38(%rsp)
  1b6fd2:	lea    0x10(%r14,%rbp,1),%rax
  1b6fd7:	mov    %rax,0x50(%rsp)
  1b6fdc:	lea    (%r9,%r10,1),%rbx
  1b6fe0:	lea    (%r15,%rbx,1),%rax
  1b6fe4:	mov    %rax,0x18(%rsp)
  1b6fe9:	lea    0x8(%r15,%rbx,1),%rax
  1b6fee:	mov    %rax,0x48(%rsp)
  1b6ff3:	mov    0x18(%rsp),%rax
  1b6ff8:	lea    0x10(%r14,%rax,1),%rbx
  1b6ffd:	mov    %rbx,0xb0(%rsp)
  1b7005:	lea    (%rsi,%r10,1),%rbx
  1b7009:	mov    %rbx,0x78(%rsp)
  1b700e:	lea    (%r15,%rbx,1),%rbx
  1b7012:	mov    %rbx,0xe0(%rsp)
  1b701a:	mov    0xe0(%rsp),%rbx
  1b7022:	lea    0x8(%r14,%rbx,1),%rbx
  1b7027:	mov    %rbx,0x100(%rsp)
  1b702f:	lea    0x8(%r14,%rax,1),%rax
  1b7034:	mov    %rax,0x80(%rsp)
  1b703c:	mov    0xe0(%rsp),%rbx
  1b7044:	add    %rbx,%r14
  1b7047:	add    $0x10,%r14
  1b704b:	mov    %r14,0x40(%rsp)
  1b7050:	cmp    0x50(%rsp),%rbp
  1b7055:	setb   0x58(%rsp)
  1b705a:	mov    0xd0(%rsp),%r14
  1b7062:	cmp    %r14,0x38(%rsp)
  1b7067:	setb   0x88(%rsp)
  1b706f:	cmp    0xb0(%rsp),%rbp
  1b7077:	setb   0x98(%rsp)
  1b707f:	cmp    %r14,0x48(%rsp)
  1b7084:	setb   0xc8(%rsp)
  1b708c:	cmp    0x100(%rsp),%rbp
  1b7094:	setb   0xa8(%rsp)
  1b709c:	cmp    %r14,%rbx
  1b709f:	setb   0xf8(%rsp)
  1b70a7:	cmp    %rax,%rbp
  1b70aa:	setb   0x118(%rsp)
  1b70b2:	cmp    %r14,0x18(%rsp)
  1b70b7:	setb   0x120(%rsp)
  1b70bf:	cmp    0x40(%rsp),%rbp
  1b70c4:	mov    0x78(%rsp),%rax
  1b70c9:	lea    0x8(%r15,%rax,1),%r14
  1b70ce:	setb   0x78(%rsp)
  1b70d3:	cmp    0xd0(%rsp),%r14
  1b70db:	setb   0xd0(%rsp)
  1b70e3:	mov    0x38(%rsp),%rax
  1b70e8:	cmp    0xb0(%rsp),%rax
  1b70f0:	setb   0xb0(%rsp)
  1b70f8:	mov    0x50(%rsp),%rbp
  1b70fd:	cmp    %rbp,0x48(%rsp)
  1b7102:	setb   0x48(%rsp)
  1b7107:	cmp    0x100(%rsp),%rax
  1b710f:	setb   0x100(%rsp)
  1b7117:	cmp    %rbp,%rbx
  1b711a:	setb   0xe0(%rsp)
  1b7122:	cmp    0x80(%rsp),%rax
  1b712a:	setb   0x80(%rsp)
  1b7132:	cmp    %rbp,0x18(%rsp)
  1b7137:	setb   0x18(%rsp)
  1b713c:	cmp    0x40(%rsp),%rax
  1b7141:	mov    0x8(%rsp),%rbx
  1b7146:	setb   0x38(%rsp)
  1b714b:	cmp    %rbp,%r14
  1b714e:	mov    %r8,%r14
  1b7151:	setb   0x50(%rsp)
  1b7156:	movzbl 0x88(%rsp),%eax
  1b715e:	test   %al,0x58(%rsp)
  1b7162:	jne    1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b7168:	mov    %r8,%r14
  1b716b:	movzbl 0xc8(%rsp),%eax
  1b7173:	and    %al,0x98(%rsp)
  1b717a:	jne    1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b7180:	mov    %r8,%r14
  1b7183:	movzbl 0xf8(%rsp),%eax
  1b718b:	and    %al,0xa8(%rsp)
  1b7192:	jne    1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b7198:	mov    %r8,%r14
  1b719b:	movzbl 0x120(%rsp),%ebp
  1b71a3:	and    %bpl,0x118(%rsp)
  1b71ab:	jne    1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b71b1:	mov    %r8,%r14
  1b71b4:	movzbl 0xd0(%rsp),%ebp
  1b71bc:	and    %bpl,0x78(%rsp)
  1b71c1:	jne    1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b71c7:	mov    %r8,%r14
  1b71ca:	movzbl 0xb0(%rsp),%eax
  1b71d2:	and    0x48(%rsp),%al
  1b71d6:	jne    1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b71dc:	mov    %r8,%r14
  1b71df:	movzbl 0xe0(%rsp),%eax
  1b71e7:	and    %al,0x100(%rsp)
  1b71ee:	jne    1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b71f4:	mov    %r8,%r14
  1b71f7:	movzbl 0x80(%rsp),%eax
  1b71ff:	and    0x18(%rsp),%al
  1b7203:	jne    1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b7209:	mov    %r8,%r14
  1b720c:	movzbl 0x38(%rsp),%eax
  1b7211:	and    0x50(%rsp),%al
  1b7215:	jne    1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b721b:	and    $0xfffffffffffffffe,%rdi
  1b721f:	lea    (%r8,%rdi,1),%r14
  1b7223:	add    %r15,%r10
  1b7226:	cs nopw 0x0(%rax,%rax,1)
  1b7230:	movupd (%r10,%r9,1),%xmm0
  1b7236:	movupd 0x10(%r10,%r9,1),%xmm1
  1b723d:	movapd %xmm0,%xmm2
  1b7241:	unpcklpd %xmm1,%xmm2
  1b7245:	unpckhpd %xmm1,%xmm0
  1b7249:	movupd (%r10,%rsi,1),%xmm1
  1b724f:	movupd 0x10(%r10,%rsi,1),%xmm3
  1b7256:	movapd %xmm1,%xmm4
  1b725a:	unpcklpd %xmm3,%xmm4
  1b725e:	unpckhpd %xmm3,%xmm1
  1b7262:	movapd %xmm0,%xmm3
  1b7266:	mulpd  %xmm4,%xmm3
  1b726a:	mulpd  %xmm2,%xmm4
  1b726e:	mulpd  %xmm1,%xmm2
  1b7272:	addpd  %xmm3,%xmm2
  1b7276:	mulpd  %xmm0,%xmm1
  1b727a:	subpd  %xmm1,%xmm4
  1b727e:	movapd %xmm4,%xmm0
  1b7282:	unpcklpd %xmm2,%xmm0
  1b7286:	unpckhpd %xmm2,%xmm4
  1b728a:	movupd %xmm4,0x10(%r10,%r11,1)
  1b7291:	movupd %xmm0,(%r10,%r11,1)
  1b7297:	add    $0x20,%r10
  1b729b:	add    $0xfffffffffffffffe,%rdi
  1b729f:	jne    1b7230 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xe3b0>
  1b72a1:	jmp    1b6191 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd311>
  1b72a6:	xor    %edi,%edi
  1b72a8:	mov    %rbx,%r8
  1b72ab:	sub    %r11,%r8
  1b72ae:	cmovb  %rdi,%r8
  1b72b2:	mov    %rbx,%r10
  1b72b5:	sub    %r14,%r10
  1b72b8:	cmovb  %rdi,%r10
  1b72bc:	cmp    %r10,%r8
  1b72bf:	cmovb  %r8,%r10
  1b72c3:	cmp    %rbp,%r10
  1b72c6:	cmovae %rbp,%r10
  1b72ca:	imul   $0x560,(%rsp),%rdi
  1b72d2:	mov    %rcx,%r8
  1b72d5:	shl    $0x4,%r8
  1b72d9:	lea    (%r15,%rdi,1),%r9
  1b72dd:	lea    (%r8,%r9,1),%rbx
  1b72e1:	add    $0x8,%rbx
  1b72e5:	add    %r8,%r9
  1b72e8:	mov    %r10,%r12
  1b72eb:	shl    $0x4,%r12
  1b72ef:	add    %r9,%r12
  1b72f2:	add    $0x8,%r12
  1b72f6:	mov    %rcx,%r9
  1b72f9:	cmp    %rbx,%r12
  1b72fc:	mov    0x1d8(%rsp),%r12
  1b7304:	mov    0x8(%rsp),%rbx
  1b7309:	jb     1b64ce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd64e>
  1b730f:	mov    %rcx,%r9
  1b7312:	movabs $0xfffffffffffffff,%r13
  1b731c:	cmp    %r13,%r10
  1b731f:	ja     1b64ce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd64e>
  1b7325:	imul   $0x5b0,(%rsp),%r10
  1b732d:	xor    %r9d,%r9d
  1b7330:	mov    0x8(%rsp),%rbx
  1b7335:	sub    %r11,%rbx
  1b7338:	cmovb  %r9,%rbx
  1b733c:	mov    0x8(%rsp),%r11
  1b7341:	sub    %r14,%r11
  1b7344:	cmovb  %r9,%r11
  1b7348:	cmp    %r11,%rbx
  1b734b:	cmovb  %rbx,%r11
  1b734f:	lea    (%r10,%r8,1),%r9
  1b7353:	cmp    %rbp,%r11
  1b7356:	cmovae %rbp,%r11
  1b735a:	lea    (%r15,%r9,1),%rbx
  1b735e:	shl    $0x4,%r11
  1b7362:	lea    (%r11,%rbx,1),%r14
  1b7366:	add    $0x8,%r14
  1b736a:	lea    0x8(%r15,%r9,1),%r12
  1b736f:	lea    0x10(%r11,%rbx,1),%r13
  1b7374:	lea    (%rdi,%r8,1),%r9
  1b7378:	mov    %r9,0x40(%rsp)
  1b737d:	lea    (%r15,%r9,1),%rbp
  1b7381:	lea    (%r11,%rbp,1),%r9
  1b7385:	add    $0x8,%r9
  1b7389:	add    %rbp,%r11
  1b738c:	add    $0x10,%r11
  1b7390:	cmp    %r13,%rbx
  1b7393:	setb   0x50(%rsp)
  1b7398:	cmp    %r14,%r12
  1b739b:	setb   0x38(%rsp)
  1b73a0:	cmp    %r9,%rbx
  1b73a3:	setb   0x48(%rsp)
  1b73a8:	cmp    %r14,%rbp
  1b73ab:	setb   0x100(%rsp)
  1b73b3:	cmp    %r11,%rbx
  1b73b6:	mov    0x40(%rsp),%rbx
  1b73bb:	lea    0x8(%r15,%rbx,1),%rbx
  1b73c0:	setb   0xb0(%rsp)
  1b73c8:	cmp    %r14,%rbx
  1b73cb:	setb   0x40(%rsp)
  1b73d0:	cmp    %r9,%r12
  1b73d3:	setb   %r14b
  1b73d7:	cmp    %r13,%rbp
  1b73da:	mov    0x20(%rsp),%rbp
  1b73df:	setb   0xd0(%rsp)
  1b73e7:	cmp    %r11,%r12
  1b73ea:	setb   0x58(%rsp)
  1b73ef:	cmp    %r13,%rbx
  1b73f2:	mov    0x1d8(%rsp),%r12
  1b73fa:	mov    0x8(%rsp),%rbx
  1b73ff:	setb   0xe0(%rsp)
  1b7407:	mov    %rcx,%r9
  1b740a:	movzbl 0x38(%rsp),%r11d
  1b7410:	test   %r11b,0x50(%rsp)
  1b7415:	jne    1b64ce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd64e>
  1b741b:	mov    %rcx,%r9
  1b741e:	movzbl 0x100(%rsp),%r11d
  1b7427:	and    %r11b,0x48(%rsp)
  1b742c:	jne    1b64ce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd64e>
  1b7432:	mov    %rcx,%r9
  1b7435:	movzbl 0xb0(%rsp),%r11d
  1b743e:	and    0x40(%rsp),%r11b
  1b7443:	jne    1b64ce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd64e>
  1b7449:	mov    %rcx,%r9
  1b744c:	and    0xd0(%rsp),%r14b
  1b7454:	jne    1b64ce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd64e>
  1b745a:	mov    %rcx,%r9
  1b745d:	movzbl 0x58(%rsp),%r11d
  1b7463:	and    0xe0(%rsp),%r11b
  1b746b:	jne    1b64ce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd64e>
  1b7471:	and    $0xfffffffffffffffe,%rsi
  1b7475:	lea    (%rcx,%rsi,1),%r9
  1b7479:	movsd  0x70(%r12),%xmm0
  1b7480:	movsd  0x78(%r12),%xmm2
  1b7487:	movsd  0x80(%r12),%xmm1
  1b7491:	movapd %xmm2,%xmm3
  1b7495:	mulsd  %xmm1,%xmm3
  1b7499:	movsd  0x88(%r12),%xmm4
  1b74a3:	mulsd  %xmm0,%xmm1
  1b74a7:	mulsd  %xmm4,%xmm0
  1b74ab:	addsd  %xmm3,%xmm0
  1b74af:	unpcklpd %xmm0,%xmm0
  1b74b3:	mulsd  %xmm4,%xmm2
  1b74b7:	subsd  %xmm2,%xmm1
  1b74bb:	unpcklpd %xmm1,%xmm1
  1b74bf:	add    %r15,%r8
  1b74c2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b74d0:	movupd (%r8,%rdi,1),%xmm2
  1b74d6:	movupd 0x10(%r8,%rdi,1),%xmm3
  1b74dd:	movapd %xmm2,%xmm4
  1b74e1:	unpcklpd %xmm3,%xmm4
  1b74e5:	unpckhpd %xmm3,%xmm2
  1b74e9:	movapd %xmm4,%xmm3
  1b74ed:	mulpd  %xmm0,%xmm3
  1b74f1:	movapd %xmm1,%xmm5
  1b74f5:	mulpd  %xmm2,%xmm5
  1b74f9:	addpd  %xmm3,%xmm5
  1b74fd:	mulpd  %xmm1,%xmm4
  1b7501:	mulpd  %xmm0,%xmm2
  1b7505:	subpd  %xmm2,%xmm4
  1b7509:	movapd %xmm4,%xmm2
  1b750d:	unpcklpd %xmm5,%xmm2
  1b7511:	unpckhpd %xmm5,%xmm4
  1b7515:	movupd %xmm4,0x10(%r8,%r10,1)
  1b751c:	movupd %xmm2,(%r8,%r10,1)
  1b7522:	add    $0x20,%r8
  1b7526:	add    $0xfffffffffffffffe,%rsi
  1b752a:	jne    1b74d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xe650>
  1b752c:	jmp    1b64ce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd64e>
  1b7531:	xor    %r9d,%r9d
  1b7534:	mov    %rbx,%r10
  1b7537:	sub    %rcx,%r10
  1b753a:	cmovb  %r9,%r10
  1b753e:	cmp    %rdx,%r10
  1b7541:	cmovae %rdx,%r10
  1b7545:	mov    %rbx,%r11
  1b7548:	sub    %r13,%r11
  1b754b:	cmovb  %r9,%r11
  1b754f:	cmp    %r11,%r10
  1b7552:	cmovb  %r10,%r11
  1b7556:	mov    0x20(%rsp),%r9
  1b755b:	cmp    %r9,%r11
  1b755e:	cmovae %r9,%r11
  1b7562:	imul   $0x5a0,(%rsp),%r9
  1b756a:	mov    %r12,%r10
  1b756d:	shl    $0x4,%r10
  1b7571:	mov    %r9,0x60(%rsp)
  1b7576:	lea    (%r15,%r9,1),%rbx
  1b757a:	lea    (%r10,%rbx,1),%r9
  1b757e:	add    $0x8,%r9
  1b7582:	add    %r10,%rbx
  1b7585:	mov    %r11,%rbp
  1b7588:	shl    $0x4,%rbp
  1b758c:	add    %rbp,%rbx
  1b758f:	add    $0x8,%rbx
  1b7593:	mov    %r12,%r14
  1b7596:	cmp    %r9,%rbx
  1b7599:	mov    0x8(%rsp),%rbx
  1b759e:	jb     1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b75a4:	lea    (%r15,%rsi,1),%r9
  1b75a8:	lea    (%r10,%r9,1),%rbx
  1b75ac:	add    $0x8,%rbx
  1b75b0:	add    %r10,%r9
  1b75b3:	add    %rbp,%r9
  1b75b6:	add    $0x8,%r9
  1b75ba:	mov    %r12,%r14
  1b75bd:	cmp    %rbx,%r9
  1b75c0:	mov    0x8(%rsp),%rbx
  1b75c5:	jb     1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b75cb:	mov    %r12,%r14
  1b75ce:	movabs $0xfffffffffffffff,%r9
  1b75d8:	cmp    %r9,%r11
  1b75db:	ja     1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b75e1:	imul   $0x5c0,(%rsp),%r11
  1b75e9:	xor    %r14d,%r14d
  1b75ec:	mov    0x8(%rsp),%rbx
  1b75f1:	sub    %rcx,%rbx
  1b75f4:	cmovb  %r14,%rbx
  1b75f8:	cmp    %rdx,%rbx
  1b75fb:	cmovae %rdx,%rbx
  1b75ff:	mov    0x8(%rsp),%r9
  1b7604:	sub    %r13,%r9
  1b7607:	cmovb  %r14,%r9
  1b760b:	mov    %r11,0x118(%rsp)
  1b7613:	lea    (%r11,%r10,1),%r14
  1b7617:	cmp    %r9,%rbx
  1b761a:	cmovb  %rbx,%r9
  1b761e:	lea    (%r15,%r14,1),%rdx
  1b7622:	mov    0x20(%rsp),%rcx
  1b7627:	cmp    %rcx,%r9
  1b762a:	cmovae %rcx,%r9
  1b762e:	shl    $0x4,%r9
  1b7632:	lea    (%r9,%rdx,1),%rcx
  1b7636:	add    $0x8,%rcx
  1b763a:	lea    0x8(%r15,%r14,1),%r13
  1b763f:	lea    0x10(%r9,%rdx,1),%r14
  1b7644:	mov    0x60(%rsp),%r11
  1b7649:	lea    (%r11,%r10,1),%rbx
  1b764d:	lea    (%r15,%rbx,1),%r11
  1b7651:	lea    0x8(%r15,%rbx,1),%rbx
  1b7656:	mov    %rbx,0x20(%rsp)
  1b765b:	lea    0x10(%r9,%r11,1),%rbx
  1b7660:	mov    %rbx,0x38(%rsp)
  1b7665:	mov    %r11,%rbx
  1b7668:	mov    %r11,0xb0(%rsp)
  1b7670:	lea    (%rsi,%r10,1),%r11
  1b7674:	lea    (%r15,%r11,1),%rbp
  1b7678:	lea    0x8(%r15,%r11,1),%r11
  1b767d:	mov    %r11,0x40(%rsp)
  1b7682:	lea    0x10(%r9,%rbp,1),%r11
  1b7687:	mov    %r11,0xe0(%rsp)
  1b768f:	lea    0x8(%r9,%rbx,1),%rbx
  1b7694:	mov    %rbx,0xd0(%rsp)
  1b769c:	add    %rbp,%r9
  1b769f:	add    $0x8,%r9
  1b76a3:	mov    %r9,0x50(%rsp)
  1b76a8:	cmp    %r14,%rdx
  1b76ab:	setb   0x48(%rsp)
  1b76b0:	cmp    %rcx,%r13
  1b76b3:	setb   0x100(%rsp)
  1b76bb:	cmp    0x38(%rsp),%rdx
  1b76c0:	setb   0x58(%rsp)
  1b76c5:	cmp    %rcx,0x20(%rsp)
  1b76ca:	setb   0x88(%rsp)
  1b76d2:	mov    0xe0(%rsp),%rbx
  1b76da:	cmp    %rbx,%rdx
  1b76dd:	setb   0x78(%rsp)
  1b76e2:	cmp    %rcx,0x40(%rsp)
  1b76e7:	setb   0x80(%rsp)
  1b76ef:	mov    0xd0(%rsp),%r11
  1b76f7:	cmp    %r11,%rdx
  1b76fa:	setb   0x98(%rsp)
  1b7702:	mov    0xb0(%rsp),%r9
  1b770a:	cmp    %rcx,%r9
  1b770d:	setb   0xc8(%rsp)
  1b7715:	cmp    0x50(%rsp),%rdx
  1b771a:	setb   0xa8(%rsp)
  1b7722:	cmp    %rcx,%rbp
  1b7725:	setb   0xf8(%rsp)
  1b772d:	cmp    0x38(%rsp),%r13
  1b7732:	setb   0x38(%rsp)
  1b7737:	cmp    %r14,0x20(%rsp)
  1b773c:	setb   0x20(%rsp)
  1b7741:	cmp    %rbx,%r13
  1b7744:	setb   0xe0(%rsp)
  1b774c:	cmp    %r14,0x40(%rsp)
  1b7751:	setb   0x40(%rsp)
  1b7756:	cmp    %r11,%r13
  1b7759:	setb   %dl
  1b775c:	cmp    %r14,%r9
  1b775f:	setb   %r9b
  1b7763:	cmp    0x50(%rsp),%r13
  1b7768:	setb   %cl
  1b776b:	cmp    %r14,%rbp
  1b776e:	mov    0x8(%rsp),%rbx
  1b7773:	mov    %r12,%r14
  1b7776:	setb   %r11b
  1b777a:	movzbl 0x100(%rsp),%r13d
  1b7783:	test   %r13b,0x48(%rsp)
  1b7788:	jne    1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b778e:	mov    %r12,%r14
  1b7791:	movzbl 0x88(%rsp),%r13d
  1b779a:	and    %r13b,0x58(%rsp)
  1b779f:	jne    1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b77a5:	mov    %r12,%r14
  1b77a8:	movzbl 0x80(%rsp),%r13d
  1b77b1:	and    %r13b,0x78(%rsp)
  1b77b6:	jne    1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b77bc:	mov    %r12,%r14
  1b77bf:	movzbl 0xc8(%rsp),%r13d
  1b77c8:	and    %r13b,0x98(%rsp)
  1b77d0:	jne    1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b77d6:	mov    %r12,%r14
  1b77d9:	movzbl 0xf8(%rsp),%r13d
  1b77e2:	and    %r13b,0xa8(%rsp)
  1b77ea:	jne    1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b77f0:	mov    %r12,%r14
  1b77f3:	movzbl 0x20(%rsp),%r13d
  1b77f9:	and    %r13b,0x38(%rsp)
  1b77fe:	jne    1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b7804:	mov    %r12,%r14
  1b7807:	movzbl 0x40(%rsp),%r13d
  1b780d:	and    %r13b,0xe0(%rsp)
  1b7815:	jne    1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b781b:	mov    %r12,%r14
  1b781e:	and    %r9b,%dl
  1b7821:	jne    1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b7827:	mov    %r12,%r14
  1b782a:	and    %r11b,%cl
  1b782d:	jne    1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b7833:	and    $0xfffffffffffffffe,%rdi
  1b7837:	lea    (%r12,%rdi,1),%r14
  1b783b:	add    %r15,%r10
  1b783e:	mov    0x60(%rsp),%rcx
  1b7843:	mov    0x118(%rsp),%rdx
  1b784b:	nopl   0x0(%rax,%rax,1)
  1b7850:	movupd (%r10,%rcx,1),%xmm0
  1b7856:	movupd (%r10,%rsi,1),%xmm1
  1b785c:	addpd  %xmm0,%xmm1
  1b7860:	movupd %xmm1,(%r10,%rdx,1)
  1b7866:	add    $0x10,%r10
  1b786a:	dec    %rdi
  1b786d:	jne    1b7850 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xe9d0>
  1b786f:	mov    0x30(%rsp),%r12
  1b7874:	jmp    1b65eb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xd76b>
  1b7879:	xor    %edi,%edi
  1b787b:	mov    %rbx,%r8
  1b787e:	sub    0x18(%rsp),%r8
  1b7883:	cmovb  %rdi,%r8
  1b7887:	mov    %r9,%rdi
  1b788a:	mov    %rbx,%r9
  1b788d:	mov    %r10,0x60(%rsp)
  1b7892:	sub    %r10,%r9
  1b7895:	mov    $0x0,%r10d
  1b789b:	cmovb  %r10,%r9
  1b789f:	cmp    %r9,%r8
  1b78a2:	cmovb  %r8,%r9
  1b78a6:	mov    %rbx,%r10
  1b78a9:	mov    %rdi,0x20(%rsp)
  1b78ae:	sub    %rdi,%r10
  1b78b1:	mov    $0x0,%edi
  1b78b6:	cmovb  %rdi,%r10
  1b78ba:	cmp    %r10,%r9
  1b78bd:	cmovb  %r9,%r10
  1b78c1:	cmp    %r10,%r11
  1b78c4:	cmovb  %r11,%r10
  1b78c8:	imul   $0x270,(%rsp),%rdi
  1b78d0:	mov    %r12,%r8
  1b78d3:	shl    $0x4,%r8
  1b78d7:	lea    (%r15,%rdi,1),%r9
  1b78db:	lea    (%r8,%r9,1),%rbx
  1b78df:	add    $0x8,%rbx
  1b78e3:	add    %r8,%r9
  1b78e6:	mov    %r10,%r12
  1b78e9:	shl    $0x4,%r12
  1b78ed:	add    %r12,%r9
  1b78f0:	add    $0x8,%r9
  1b78f4:	cmp    %rbx,%r9
  1b78f7:	jb     1b7c23 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeda3>
  1b78fd:	imul   $0x5e0,(%rsp),%r9
  1b7905:	lea    (%r15,%r9,1),%rbx
  1b7909:	lea    (%r8,%rbx,1),%rbp
  1b790d:	add    $0x8,%rbp
  1b7911:	mov    %rbp,0x50(%rsp)
  1b7916:	add    %r8,%rbx
  1b7919:	add    %r12,%rbx
  1b791c:	add    $0x8,%rbx
  1b7920:	cmp    0x50(%rsp),%rbx
  1b7925:	jb     1b7c23 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeda3>
  1b792b:	movabs $0xfffffffffffffff,%rbx
  1b7935:	cmp    %rbx,%r10
  1b7938:	ja     1b7c23 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeda3>
  1b793e:	imul   $0x5f0,(%rsp),%r10
  1b7946:	xor    %ebx,%ebx
  1b7948:	mov    0x8(%rsp),%rbp
  1b794d:	mov    %rbp,%r12
  1b7950:	sub    0x18(%rsp),%r12
  1b7955:	cmovb  %rbx,%r12
  1b7959:	mov    %rbp,%r13
  1b795c:	sub    0x60(%rsp),%r13
  1b7961:	cmovb  %rbx,%r13
  1b7965:	cmp    %r13,%r12
  1b7968:	cmovb  %r12,%r13
  1b796c:	sub    0x20(%rsp),%rbp
  1b7971:	cmovb  %rbx,%rbp
  1b7975:	cmp    %rbp,%r13
  1b7978:	cmovb  %r13,%rbp
  1b797c:	lea    (%r10,%r8,1),%rbx
  1b7980:	cmp    %rbp,%r11
  1b7983:	cmovb  %r11,%rbp
  1b7987:	lea    (%r15,%rbx,1),%r11
  1b798b:	shl    $0x4,%rbp
  1b798f:	lea    (%r11,%rbp,1),%r12
  1b7993:	add    $0x8,%r12
  1b7997:	mov    %r12,0x58(%rsp)
  1b799c:	lea    0x8(%r15,%rbx,1),%rbx
  1b79a1:	mov    %rbx,0x20(%rsp)
  1b79a6:	lea    0x10(%rbp,%r11,1),%rbx
  1b79ab:	mov    %rbx,0x18(%rsp)
  1b79b0:	lea    (%rdi,%r8,1),%r13
  1b79b4:	lea    (%r15,%r13,1),%r12
  1b79b8:	lea    0x8(%r15,%r13,1),%rbx
  1b79bd:	mov    %rbx,0x50(%rsp)
  1b79c2:	mov    %r12,%rbx
  1b79c5:	mov    %r12,0x60(%rsp)
  1b79ca:	lea    0x10(%rbp,%r12,1),%r12
  1b79cf:	mov    %r12,0x40(%rsp)
  1b79d4:	lea    (%r9,%r8,1),%r12
  1b79d8:	mov    %r12,0xb0(%rsp)
  1b79e0:	add    %r15,%r12
  1b79e3:	lea    0x8(%rbp,%r12,1),%r13
  1b79e8:	mov    %r13,0x38(%rsp)
  1b79ed:	lea    0x8(%rbp,%rbx,1),%rbx
  1b79f2:	mov    %rbx,0xe0(%rsp)
  1b79fa:	add    %r12,%rbp
  1b79fd:	add    $0x10,%rbp
  1b7a01:	mov    %rbp,0xd0(%rsp)
  1b7a09:	cmp    0x18(%rsp),%r11
  1b7a0e:	setb   0x48(%rsp)
  1b7a13:	mov    0x58(%rsp),%r13
  1b7a18:	cmp    %r13,0x20(%rsp)
  1b7a1d:	setb   0x100(%rsp)
  1b7a25:	cmp    0x40(%rsp),%r11
  1b7a2a:	setb   0x88(%rsp)
  1b7a32:	cmp    %r13,0x50(%rsp)
  1b7a37:	setb   0x78(%rsp)
  1b7a3c:	cmp    0x38(%rsp),%r11
  1b7a41:	setb   0x80(%rsp)
  1b7a49:	cmp    %r13,%r12
  1b7a4c:	setb   0x98(%rsp)
  1b7a54:	cmp    %rbx,%r11
  1b7a57:	setb   0xc8(%rsp)
  1b7a5f:	cmp    %r13,0x60(%rsp)
  1b7a64:	setb   0xa8(%rsp)
  1b7a6c:	cmp    %rbp,%r11
  1b7a6f:	mov    0xb0(%rsp),%r11
  1b7a77:	lea    0x8(%r15,%r11,1),%rbp
  1b7a7c:	setb   0xb0(%rsp)
  1b7a84:	cmp    %r13,%rbp
  1b7a87:	setb   0x58(%rsp)
  1b7a8c:	mov    0x20(%rsp),%rbx
  1b7a91:	cmp    0x40(%rsp),%rbx
  1b7a96:	setb   0x40(%rsp)
  1b7a9b:	mov    0x18(%rsp),%r13
  1b7aa0:	cmp    %r13,0x50(%rsp)
  1b7aa5:	setb   0x50(%rsp)
  1b7aaa:	cmp    0x38(%rsp),%rbx
  1b7aaf:	setb   0x38(%rsp)
  1b7ab4:	cmp    %r13,%r12
  1b7ab7:	setb   0xf8(%rsp)
  1b7abf:	cmp    0xe0(%rsp),%rbx
  1b7ac7:	setb   0xe0(%rsp)
  1b7acf:	cmp    %r13,0x60(%rsp)
  1b7ad4:	setb   0x60(%rsp)
  1b7ad9:	cmp    0xd0(%rsp),%rbx
  1b7ae1:	setb   %r12b
  1b7ae5:	cmp    %r13,%rbp
  1b7ae8:	setb   %r11b
  1b7aec:	movzbl 0x100(%rsp),%ebx
  1b7af4:	test   %bl,0x48(%rsp)
  1b7af8:	jne    1bd49f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1461f>
  1b7afe:	movzbl 0x78(%rsp),%ebx
  1b7b03:	and    %bl,0x88(%rsp)
  1b7b0a:	jne    1bd49f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1461f>
  1b7b10:	movzbl 0x98(%rsp),%ebx
  1b7b18:	and    %bl,0x80(%rsp)
  1b7b1f:	mov    0x8(%rsp),%rbx
  1b7b24:	mov    0x10(%rsp),%r13
  1b7b29:	jne    1b7c28 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeda8>
  1b7b2f:	movzbl 0xa8(%rsp),%ebp
  1b7b37:	and    %bpl,0xc8(%rsp)
  1b7b3f:	jne    1b7c28 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeda8>
  1b7b45:	movzbl 0x58(%rsp),%ebp
  1b7b4a:	and    %bpl,0xb0(%rsp)
  1b7b52:	jne    1b7c28 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeda8>
  1b7b58:	movzbl 0x50(%rsp),%ebp
  1b7b5d:	and    %bpl,0x40(%rsp)
  1b7b62:	jne    1b7c28 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeda8>
  1b7b68:	movzbl 0xf8(%rsp),%ebp
  1b7b70:	and    %bpl,0x38(%rsp)
  1b7b75:	jne    1b7c28 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeda8>
  1b7b7b:	movzbl 0x60(%rsp),%ebp
  1b7b80:	and    %bpl,0xe0(%rsp)
  1b7b88:	jne    1b7c28 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeda8>
  1b7b8e:	and    %r11b,%r12b
  1b7b91:	mov    0x28(%rsp),%r11
  1b7b96:	jne    1b7c2d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xedad>
  1b7b9c:	and    $0xfffffffffffffffe,%rsi
  1b7ba0:	mov    0x30(%rsp),%r12
  1b7ba5:	add    %rsi,%r12
  1b7ba8:	add    %r15,%r8
  1b7bab:	nopl   0x0(%rax,%rax,1)
  1b7bb0:	movupd (%r8,%rdi,1),%xmm0
  1b7bb6:	movupd 0x10(%r8,%rdi,1),%xmm1
  1b7bbd:	movapd %xmm0,%xmm2
  1b7bc1:	unpcklpd %xmm1,%xmm2
  1b7bc5:	unpckhpd %xmm1,%xmm0
  1b7bc9:	movupd (%r8,%r9,1),%xmm1
  1b7bcf:	movupd 0x10(%r8,%r9,1),%xmm3
  1b7bd6:	movapd %xmm1,%xmm4
  1b7bda:	unpcklpd %xmm3,%xmm4
  1b7bde:	unpckhpd %xmm3,%xmm1
  1b7be2:	movapd %xmm0,%xmm3
  1b7be6:	mulpd  %xmm4,%xmm3
  1b7bea:	mulpd  %xmm2,%xmm4
  1b7bee:	mulpd  %xmm1,%xmm2
  1b7bf2:	addpd  %xmm3,%xmm2
  1b7bf6:	mulpd  %xmm0,%xmm1
  1b7bfa:	subpd  %xmm1,%xmm4
  1b7bfe:	movapd %xmm4,%xmm0
  1b7c02:	unpcklpd %xmm2,%xmm0
  1b7c06:	unpckhpd %xmm2,%xmm4
  1b7c0a:	movupd %xmm4,0x10(%r8,%r10,1)
  1b7c11:	movupd %xmm0,(%r8,%r10,1)
  1b7c17:	add    $0x20,%r8
  1b7c1b:	add    $0xfffffffffffffffe,%rsi
  1b7c1f:	jne    1b7bb0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xed30>
  1b7c21:	jmp    1b7c32 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xedb2>
  1b7c23:	mov    0x8(%rsp),%rbx
  1b7c28:	mov    0x28(%rsp),%r11
  1b7c2d:	mov    0x30(%rsp),%r12
  1b7c32:	mov    (%rsp),%rdi
  1b7c36:	imul   $0x5f0,%rdi,%rsi
  1b7c3d:	mov    %r12,%r8
  1b7c40:	shl    $0x4,%r8
  1b7c44:	add    %r15,%r8
  1b7c47:	imul   $0x5e0,%rdi,%r9
  1b7c4e:	imul   $0x270,%rdi,%r10
  1b7c55:	data16 cs nopw 0x0(%rax,%rax,1)
  1b7c60:	lea    (%rax,%r12,1),%rdi
  1b7c64:	cmp    %rbx,%rdi
  1b7c67:	jae    1be7f6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15976>
  1b7c6d:	lea    (%rcx,%r12,1),%rdi
  1b7c71:	cmp    %rbx,%rdi
  1b7c74:	jae    1be7e6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15966>
  1b7c7a:	lea    (%rdx,%r12,1),%rdi
  1b7c7e:	cmp    %rbx,%rdi
  1b7c81:	jae    1be7d6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15956>
  1b7c87:	inc    %r12
  1b7c8a:	movupd (%r8,%r10,1),%xmm0
  1b7c90:	movsd  (%r8,%r9,1),%xmm1
  1b7c96:	movsd  0x8(%r8,%r9,1),%xmm2
  1b7c9d:	unpcklpd %xmm1,%xmm1
  1b7ca1:	mulpd  %xmm0,%xmm1
  1b7ca5:	shufpd $0x1,%xmm0,%xmm0
  1b7caa:	unpcklpd %xmm2,%xmm2
  1b7cae:	mulpd  %xmm0,%xmm2
  1b7cb2:	movapd %xmm1,%xmm0
  1b7cb6:	subpd  %xmm2,%xmm0
  1b7cba:	addpd  %xmm1,%xmm2
  1b7cbe:	movsd  %xmm0,%xmm2
  1b7cc2:	movupd %xmm2,(%r8,%rsi,1)
  1b7cc8:	add    $0x10,%r8
  1b7ccc:	cmp    %r12,%r13
  1b7ccf:	jne    1b7c60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xede0>
  1b7cd1:	xor    %eax,%eax
  1b7cd3:	mov    0x1b0(%rsp),%r9
  1b7cdb:	mov    0x1d0(%rsp),%rdx
  1b7ce3:	mov    0x90(%rsp),%rcx
  1b7ceb:	mov    0x1c8(%rsp),%r10
  1b7cf3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b7d00:	mov    (%r11,%rax,1),%rdi
  1b7d04:	cmp    %rdx,%rdi
  1b7d07:	jae    1bd8a9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14a29>
  1b7d0d:	movq   $0x5e,(%r10,%rdi,8)
  1b7d15:	add    $0x8,%rax
  1b7d19:	cmp    %rax,%r14
  1b7d1c:	jne    1b7d00 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xee80>
  1b7d1e:	xor    %eax,%eax
  1b7d20:	xor    %esi,%esi
  1b7d22:	jmp    1b7d40 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeec0>
  1b7d24:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b7d30:	mov    %rdi,(%r11,%rsi,8)
  1b7d34:	inc    %rsi
  1b7d37:	add    $0x8,%rax
  1b7d3b:	cmp    %rax,%rcx
  1b7d3e:	je     1b7d74 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeef4>
  1b7d40:	mov    0x110(%rsp),%rdi
  1b7d48:	mov    (%rdi,%rax,1),%rdi
  1b7d4c:	cmp    %rdx,%rdi
  1b7d4f:	jae    1bd5ea <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1476a>
  1b7d55:	cmpq   $0x5e,(%r10,%rdi,8)
  1b7d5a:	jae    1b7d37 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeeb7>
  1b7d5c:	cmp    %r9,%rsi
  1b7d5f:	jb     1b7d30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xeeb0>
  1b7d61:	lea    0x246ae30(%rip),%rdx        # 2622b98 <__gmpfr_one+0xb418>
  1b7d68:	mov    %rsi,%rdi
  1b7d6b:	mov    %r9,%rsi
  1b7d6e:	call   *0x251718c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1b7d74:	cmp    %r9,%rsi
  1b7d77:	ja     1bd2bb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1443b>
  1b7d7d:	test   %rsi,%rsi
  1b7d80:	je     1b7db6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xef36>
  1b7d82:	mov    (%r11),%rax
  1b7d85:	lea    -0x1(%rsi),%rcx
  1b7d89:	mov    -0x8(%r11,%rsi,8),%rdx
  1b7d8e:	sub    %rax,%rdx
  1b7d91:	setae  %dil
  1b7d95:	cmp    %rcx,%rdx
  1b7d98:	sete   %cl
  1b7d9b:	and    %dil,%cl
  1b7d9e:	cmp    $0x1,%cl
  1b7da1:	jne    1b7da8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xef28>
  1b7da3:	add    %rax,%rsi
  1b7da6:	jae    1b7dac <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xef2c>
  1b7da8:	xor    %esi,%esi
  1b7daa:	xor    %eax,%eax
  1b7dac:	mov    0x1d0(%rsp),%rdx
  1b7db4:	jmp    1b7dba <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xef3a>
  1b7db6:	xor    %esi,%esi
  1b7db8:	xor    %eax,%eax
  1b7dba:	xor    %ecx,%ecx
  1b7dbc:	xor    %r12d,%r12d
  1b7dbf:	jmp    1b7de5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xef65>
  1b7dc1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b7dd0:	mov    %rdi,(%r11,%r12,8)
  1b7dd4:	inc    %r12
  1b7dd7:	add    $0x8,%rcx
  1b7ddb:	cmp    %rcx,0x90(%rsp)
  1b7de3:	je     1b7e19 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xef99>
  1b7de5:	mov    0x110(%rsp),%rdi
  1b7ded:	mov    (%rdi,%rcx,1),%rdi
  1b7df1:	cmp    %rdx,%rdi
  1b7df4:	jae    1bd5fa <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1477a>
  1b7dfa:	cmpq   $0x5f,(%r10,%rdi,8)
  1b7dff:	jae    1b7dd7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xef57>
  1b7e01:	cmp    %r9,%r12
  1b7e04:	jb     1b7dd0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xef50>
  1b7e06:	lea    0x246adbb(%rip),%rdx        # 2622bc8 <__gmpfr_one+0xb448>
  1b7e0d:	mov    %r12,%rdi
  1b7e10:	mov    %r9,%rsi
  1b7e13:	call   *0x25170e7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1b7e19:	cmp    %r9,%r12
  1b7e1c:	ja     1bd2cd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1444d>
  1b7e22:	test   %r12,%r12
  1b7e25:	mov    0x90(%rsp),%rcx
  1b7e2d:	je     1b899e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfb1e>
  1b7e33:	mov    (%r11),%r8
  1b7e36:	lea    -0x1(%r12),%rcx
  1b7e3b:	mov    -0x8(%r11,%r12,8),%rdx
  1b7e40:	sub    %r8,%rdx
  1b7e43:	setae  %dil
  1b7e47:	cmp    %rcx,%rdx
  1b7e4a:	sete   %cl
  1b7e4d:	mov    %r8,%rdx
  1b7e50:	add    %r12,%rdx
  1b7e53:	cmovb  %rsi,%rdx
  1b7e57:	cmovb  %rax,%r8
  1b7e5b:	test   %cl,%dil
  1b7e5e:	cmove  %rsi,%rdx
  1b7e62:	mov    %rdx,0x30(%rsp)
  1b7e67:	cmove  %rax,%r8
  1b7e6b:	mov    %r8,0x10(%rsp)
  1b7e70:	lea    0x0(,%r12,8),%r14
  1b7e78:	mov    (%rsp),%rax
  1b7e7c:	imul   $0x27,%rax,%rbp
  1b7e80:	imul   $0x63,%rax,%rax
  1b7e84:	mov    %rax,0x18(%rsp)
  1b7e89:	xor    %r13d,%r13d
  1b7e8c:	xorpd  %xmm1,%xmm1
  1b7e90:	jmp    1b7edd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf05d>
  1b7e92:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b7ea0:	mov    $0x63,%r8d
  1b7ea6:	mov    $0x5f,%r9d
  1b7eac:	mov    %r15,%rdi
  1b7eaf:	mov    %rbx,%rsi
  1b7eb2:	mov    (%rsp),%rdx
  1b7eb6:	call   1a8d70 <oneloop::native::batch::copy_active_column::<f64>>
  1b7ebb:	xorpd  %xmm1,%xmm1
  1b7ebf:	mov    0x1c8(%rsp),%r10
  1b7ec7:	mov    0x28(%rsp),%r11
  1b7ecc:	mov    0x1b0(%rsp),%r9
  1b7ed4:	add    $0x8,%r13
  1b7ed8:	cmp    %r13,%r14
  1b7edb:	je     1b7f4d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf0cd>
  1b7edd:	mov    (%r11,%r13,1),%rcx
  1b7ee1:	lea    (%rcx,%rbp,1),%rdi
  1b7ee5:	cmp    %rbx,%rdi
  1b7ee8:	jae    1bd8b9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14a39>
  1b7eee:	shl    $0x4,%rdi
  1b7ef2:	movsd  (%r15,%rdi,1),%xmm0
  1b7ef8:	ucomisd %xmm1,%xmm0
  1b7efc:	jne    1b7ea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf020>
  1b7efe:	jp     1b7ea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf020>
  1b7f00:	add    %r15,%rdi
  1b7f03:	movsd  0x8(%rdi),%xmm0
  1b7f08:	ucomisd %xmm1,%xmm0
  1b7f0c:	jne    1b7ea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf020>
  1b7f0e:	jp     1b7ea0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf020>
  1b7f10:	add    0x18(%rsp),%rcx
  1b7f15:	cmp    %rbx,%rcx
  1b7f18:	jae    1be279 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x153f9>
  1b7f1e:	cmpq   $0x3,0x1e0(%rsp)
  1b7f27:	jbe    1bd65a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x147da>
  1b7f2d:	shl    $0x4,%rcx
  1b7f31:	mov    0x1d8(%rsp),%rax
  1b7f39:	movupd 0x30(%rax),%xmm0
  1b7f3e:	movupd %xmm0,(%r15,%rcx,1)
  1b7f44:	add    $0x8,%r13
  1b7f48:	cmp    %r13,%r14
  1b7f4b:	jne    1b7edd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf05d>
  1b7f4d:	mov    (%rsp),%rcx
  1b7f51:	lea    (%rcx,%rcx,1),%rax
  1b7f55:	shl    $0x5,%rcx
  1b7f59:	sub    %rax,%rcx
  1b7f5c:	xor    %edx,%edx
  1b7f5e:	xorpd  %xmm0,%xmm0
  1b7f62:	xor    %r14d,%r14d
  1b7f65:	mov    0x10(%rsp),%r13
  1b7f6a:	nopw   0x0(%rax,%rax,1)
  1b7f70:	mov    (%r11,%rdx,8),%rdi
  1b7f74:	lea    (%rdi,%rcx,1),%rax
  1b7f78:	cmp    %rbx,%rax
  1b7f7b:	jae    1bd8c9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14a49>
  1b7f81:	shl    $0x4,%rax
  1b7f85:	movsd  (%r15,%rax,1),%xmm1
  1b7f8b:	ucomisd %xmm0,%xmm1
  1b7f8f:	jne    1b7fd0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf150>
  1b7f91:	jp     1b7fd0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf150>
  1b7f93:	add    %r15,%rax
  1b7f96:	movsd  0x8(%rax),%xmm1
  1b7f9b:	ucomisd %xmm0,%xmm1
  1b7f9f:	jne    1b7fd0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf150>
  1b7fa1:	jp     1b7fd0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf150>
  1b7fa3:	cmp    0x1d0(%rsp),%rdi
  1b7fab:	jae    1be28c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1540c>
  1b7fb1:	movq   $0x64,(%r10,%rdi,8)
  1b7fb9:	inc    %rdx
  1b7fbc:	cmp    %rdx,%r12
  1b7fbf:	jne    1b7f70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf0f0>
  1b7fc1:	jmp    1b7fe8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf168>
  1b7fc3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b7fd0:	cmp    %r9,%r14
  1b7fd3:	jae    1bdd30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14eb0>
  1b7fd9:	mov    %rdi,(%r11,%r14,8)
  1b7fdd:	inc    %r14
  1b7fe0:	inc    %rdx
  1b7fe3:	cmp    %rdx,%r12
  1b7fe6:	jne    1b7f70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf0f0>
  1b7fe8:	cmp    %r9,%r14
  1b7feb:	ja     1bd3d2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14552>
  1b7ff1:	test   %r14,%r14
  1b7ff4:	mov    0x1d0(%rsp),%rdx
  1b7ffc:	mov    0x90(%rsp),%rcx
  1b8004:	je     1b899e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfb1e>
  1b800a:	mov    (%r11),%rax
  1b800d:	lea    -0x1(%r14),%rcx
  1b8011:	mov    -0x8(%r11,%r14,8),%rdx
  1b8016:	sub    %rax,%rdx
  1b8019:	setae  %sil
  1b801d:	cmp    %rcx,%rdx
  1b8020:	sete   %cl
  1b8023:	and    %sil,%cl
  1b8026:	cmp    $0x1,%cl
  1b8029:	jne    1b805b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf1db>
  1b802b:	mov    %rax,%rcx
  1b802e:	add    %r14,%rcx
  1b8031:	movabs $0x7fffffffffffffff,%rsi
  1b803b:	movabs $0x7ff0000000000000,%r8
  1b8045:	jb     1bd4cd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1464d>
  1b804b:	mov    $0x1,%dl
  1b804d:	mov    %edx,0x60(%rsp)
  1b8051:	mov    %rcx,0x30(%rsp)
  1b8056:	mov    %rax,%r13
  1b8059:	jmp    1b8077 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf1f7>
  1b805b:	movl   $0x0,0x60(%rsp)
  1b8063:	movabs $0x7fffffffffffffff,%rsi
  1b806d:	movabs $0x7ff0000000000000,%r8
  1b8077:	shl    $0x3,%r14
  1b807b:	imul   $0x65,(%rsp),%r9
  1b8080:	xor    %ebp,%ebp
  1b8082:	movapd 0x1fddf76(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b808a:	xorpd  %xmm7,%xmm7
  1b808e:	movsd  0x1fdf619(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b8097:	movsd  0x1fdf618(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b80a0:	movsd  0x1fdf61f(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1b80a9:	movapd 0x1fddf5e(%rip),%xmm11        # 2196010 <_fini+0x530>
  1b80b2:	movsd  0x1fdf605(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1b80bb:	mov    %r9,0x18(%rsp)
  1b80c0:	mov    (%r11,%rbp,1),%r12
  1b80c4:	cmp    %rbx,%r12
  1b80c7:	jae    1bdc08 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14d88>
  1b80cd:	mov    %r12,%rdi
  1b80d0:	shl    $0x4,%rdi
  1b80d4:	movupd (%r15,%rdi,1),%xmm0
  1b80da:	movapd %xmm0,%xmm2
  1b80de:	andpd  %xmm6,%xmm2
  1b80e2:	movapd %xmm0,%xmm1
  1b80e6:	unpckhpd %xmm0,%xmm1
  1b80ea:	movapd %xmm1,%xmm3
  1b80ee:	andpd  %xmm6,%xmm3
  1b80f2:	ucomisd %xmm7,%xmm0
  1b80f6:	je     1b8160 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf2e0>
  1b80f8:	ucomisd %xmm7,%xmm1
  1b80fc:	je     1b8160 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf2e0>
  1b80fe:	movapd %xmm2,%xmm4
  1b8102:	cmplesd %xmm3,%xmm4
  1b8107:	movapd %xmm4,%xmm5
  1b810b:	andpd  %xmm3,%xmm5
  1b810f:	andnpd %xmm2,%xmm4
  1b8113:	orpd   %xmm5,%xmm4
  1b8117:	ucomisd %xmm8,%xmm4
  1b811c:	jbe    1b8160 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf2e0>
  1b811e:	ucomisd %xmm4,%xmm9
  1b8123:	jbe    1b8160 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf2e0>
  1b8125:	movapd %xmm0,%xmm2
  1b8129:	mulpd  %xmm0,%xmm2
  1b812d:	movapd %xmm2,%xmm3
  1b8131:	unpckhpd %xmm2,%xmm3
  1b8135:	addsd  %xmm2,%xmm3
  1b8139:	movapd %xmm10,%xmm2
  1b813e:	divsd  %xmm3,%xmm2
  1b8142:	mulsd  %xmm2,%xmm0
  1b8146:	xorpd  %xmm11,%xmm1
  1b814b:	mulsd  %xmm2,%xmm1
  1b814f:	jmp    1b824f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf3cf>
  1b8154:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b8160:	ucomisd %xmm7,%xmm1
  1b8164:	setnp  %al
  1b8167:	sete   %cl
  1b816a:	and    %al,%cl
  1b816c:	movq   %xmm0,%rax
  1b8171:	and    %rsi,%rax
  1b8174:	cmp    %r8,%rax
  1b8177:	setl   %dl
  1b817a:	test   %dl,%cl
  1b817c:	je     1b81a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf320>
  1b817e:	movapd %xmm10,%xmm2
  1b8183:	divsd  %xmm0,%xmm2
  1b8187:	xorpd  %xmm11,%xmm1
  1b818c:	movapd %xmm2,%xmm0
  1b8190:	jmp    1b824f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf3cf>
  1b8195:	data16 cs nopw 0x0(%rax,%rax,1)
  1b81a0:	ucomisd %xmm7,%xmm0
  1b81a4:	setnp  %cl
  1b81a7:	sete   %dl
  1b81aa:	and    %cl,%dl
  1b81ac:	movq   %xmm1,%rcx
  1b81b1:	and    %rsi,%rcx
  1b81b4:	cmp    %r8,%rcx
  1b81b7:	setl   %sil
  1b81bb:	test   %sil,%dl
  1b81be:	je     1b81cf <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf34f>
  1b81c0:	movapd %xmm12,%xmm2
  1b81c5:	divsd  %xmm1,%xmm2
  1b81c9:	movapd %xmm2,%xmm1
  1b81cd:	jmp    1b8245 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf3c5>
  1b81cf:	movabs $0x7fefffffffffffff,%rdx
  1b81d9:	cmp    %rdx,%rax
  1b81dc:	setg   %al
  1b81df:	cmp    %rdx,%rcx
  1b81e2:	setg   %cl
  1b81e5:	or     %al,%cl
  1b81e7:	cmp    $0x1,%cl
  1b81ea:	jne    1b827e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf3fe>
  1b81f0:	add    %r15,%rdi
  1b81f3:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1b81f8:	movsd  0x1fdf4bf(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1b8201:	movapd 0x1fdde06(%rip),%xmm11        # 2196010 <_fini+0x530>
  1b820a:	movsd  0x1fdf4b5(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1b8213:	movsd  0x1fdf49c(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b821c:	movsd  0x1fdf48b(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b8225:	xorpd  %xmm7,%xmm7
  1b8229:	movapd 0x1fdddcf(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b8231:	mov    0x18(%rsp),%r9
  1b8236:	movabs $0x7ff0000000000000,%r8
  1b8240:	mov    0x28(%rsp),%r11
  1b8245:	movabs $0x7fffffffffffffff,%rsi
  1b824f:	add    %r9,%r12
  1b8252:	cmp    %rbx,%r12
  1b8255:	jae    1bdbf5 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14d75>
  1b825b:	shl    $0x4,%r12
  1b825f:	movsd  %xmm0,(%r15,%r12,1)
  1b8265:	movsd  %xmm1,0x8(%r15,%r12,1)
  1b826c:	add    $0x8,%rbp
  1b8270:	cmp    %rbp,%r14
  1b8273:	jne    1b80c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf240>
  1b8279:	jmp    1b8306 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf486>
  1b827e:	ucomisd %xmm7,%xmm1
  1b8282:	movabs $0x7fffffffffffffff,%rsi
  1b828c:	jne    1b8294 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf414>
  1b828e:	jnp    1b817e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf2fe>
  1b8294:	ucomisd %xmm7,%xmm0
  1b8298:	jne    1b82ab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf42b>
  1b829a:	jp     1b82ab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf42b>
  1b829c:	movapd %xmm12,%xmm2
  1b82a1:	divsd  %xmm1,%xmm2
  1b82a5:	movapd %xmm2,%xmm1
  1b82a9:	jmp    1b824f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf3cf>
  1b82ab:	movapd %xmm3,%xmm1
  1b82af:	cmplesd %xmm2,%xmm1
  1b82b4:	movapd %xmm1,%xmm4
  1b82b8:	andpd  %xmm2,%xmm4
  1b82bc:	andnpd %xmm3,%xmm1
  1b82c0:	orpd   %xmm4,%xmm1
  1b82c4:	unpcklpd %xmm1,%xmm1
  1b82c8:	divpd  %xmm1,%xmm0
  1b82cc:	movapd %xmm0,%xmm2
  1b82d0:	xorpd  %xmm11,%xmm2
  1b82d5:	movsd  %xmm0,%xmm2
  1b82d9:	mulpd  %xmm0,%xmm0
  1b82dd:	movapd %xmm0,%xmm3
  1b82e1:	unpcklpd %xmm0,%xmm3
  1b82e5:	unpckhpd %xmm0,%xmm0
  1b82e9:	addpd  %xmm3,%xmm0
  1b82ed:	divpd  %xmm0,%xmm2
  1b82f1:	divpd  %xmm1,%xmm2
  1b82f5:	movapd %xmm2,%xmm0
  1b82f9:	movapd %xmm2,%xmm1
  1b82fd:	unpckhpd %xmm2,%xmm1
  1b8301:	jmp    1b824f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf3cf>
  1b8306:	cmpb   $0x0,0x60(%rsp)
  1b830b:	je     1b83ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf52d>
  1b8311:	mov    0x30(%rsp),%rdx
  1b8316:	cmp    %rdx,%r13
  1b8319:	jae    1b8953 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfad3>
  1b831f:	cmpq   $0x5,0x1e0(%rsp)
  1b8328:	jb     1bf06b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161eb>
  1b832e:	mov    (%rsp),%r11
  1b8332:	imul   $0x66,%r11,%rax
  1b8336:	lea    (%r11,%r11,8),%rcx
  1b833a:	lea    (%r11,%rcx,2),%rcx
  1b833e:	mov    %r13,%r10
  1b8341:	not    %r10
  1b8344:	add    %rdx,%r10
  1b8347:	lea    (%rcx,%r13,1),%r8
  1b834b:	xor    %esi,%esi
  1b834d:	mov    %rbx,%rdx
  1b8350:	sub    %r8,%rdx
  1b8353:	cmovb  %rsi,%rdx
  1b8357:	mov    0x18(%rsp),%rdi
  1b835c:	lea    (%rdi,%r13,1),%r12
  1b8360:	mov    %rbx,%rdi
  1b8363:	sub    %r12,%rdi
  1b8366:	cmovb  %rsi,%rdi
  1b836a:	cmp    %rdi,%rdx
  1b836d:	cmovb  %rdx,%rdi
  1b8371:	lea    (%rax,%r13,1),%rbp
  1b8375:	mov    %rbx,%rdx
  1b8378:	sub    %rbp,%rdx
  1b837b:	cmovb  %rsi,%rdx
  1b837f:	cmp    %rdx,%rdi
  1b8382:	cmovb  %rdi,%rdx
  1b8386:	cmp    %rdx,%r10
  1b8389:	cmovb  %r10,%rdx
  1b838d:	lea    0x1(%rdx),%rsi
  1b8391:	cmp    $0x22,%rsi
  1b8395:	ja     1b8495 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf615>
  1b839b:	mov    0x1d8(%rsp),%r10
  1b83a3:	mov    0x28(%rsp),%r11
  1b83a8:	jmp    1b887c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf9fc>
  1b83ad:	cmpq   $0x5,0x1e0(%rsp)
  1b83b6:	mov    0x1d8(%rsp),%r9
  1b83be:	jb     1bf06b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161eb>
  1b83c4:	mov    (%rsp),%rcx
  1b83c8:	imul   $0x66,%rcx,%rdx
  1b83cc:	lea    (%rcx,%rcx,8),%rax
  1b83d0:	lea    (%rcx,%rax,2),%rsi
  1b83d4:	xor    %r8d,%r8d
  1b83d7:	nopw   0x0(%rax,%rax,1)
  1b83e0:	mov    (%r11,%r8,1),%rdi
  1b83e4:	lea    (%rdi,%rsi,1),%rax
  1b83e8:	cmp    %rbx,%rax
  1b83eb:	jae    1be431 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x155b1>
  1b83f1:	mov    0x18(%rsp),%rcx
  1b83f6:	add    %rdi,%rcx
  1b83f9:	cmp    %rbx,%rcx
  1b83fc:	jae    1be41e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1559e>
  1b8402:	add    %rdx,%rdi
  1b8405:	cmp    %rbx,%rdi
  1b8408:	jae    1be40e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1558e>
  1b840e:	shl    $0x4,%rax
  1b8412:	shl    $0x4,%rcx
  1b8416:	movupd 0x40(%r9),%xmm0
  1b841c:	movupd (%r15,%rax,1),%xmm1
  1b8422:	movapd %xmm0,%xmm2
  1b8426:	mulpd  %xmm1,%xmm2
  1b842a:	shl    $0x4,%rdi
  1b842e:	movupd (%r15,%rcx,1),%xmm3
  1b8434:	movapd %xmm2,%xmm4
  1b8438:	unpcklpd %xmm2,%xmm4
  1b843c:	unpckhpd %xmm2,%xmm2
  1b8440:	subpd  %xmm2,%xmm4
  1b8444:	mulpd  %xmm3,%xmm4
  1b8448:	movapd %xmm0,%xmm2
  1b844c:	unpckhpd %xmm0,%xmm2
  1b8450:	mulsd  %xmm1,%xmm2
  1b8454:	unpckhpd %xmm1,%xmm1
  1b8458:	mulsd  %xmm0,%xmm1
  1b845c:	addsd  %xmm2,%xmm1
  1b8460:	unpcklpd %xmm1,%xmm1
  1b8464:	shufpd $0x1,%xmm3,%xmm3
  1b8469:	mulpd  %xmm1,%xmm3
  1b846d:	movapd %xmm4,%xmm0
  1b8471:	subpd  %xmm3,%xmm0
  1b8475:	addpd  %xmm4,%xmm3
  1b8479:	movsd  %xmm0,%xmm3
  1b847d:	movupd %xmm3,(%r15,%rdi,1)
  1b8483:	add    $0x8,%r8
  1b8487:	cmp    %r8,%r14
  1b848a:	jne    1b83e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf560>
  1b8490:	jmp    1b8953 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfad3>
  1b8495:	xor    %esi,%esi
  1b8497:	mov    %rbx,%rdi
  1b849a:	mov    %r8,0x60(%rsp)
  1b849f:	sub    %r8,%rdi
  1b84a2:	cmovb  %rsi,%rdi
  1b84a6:	mov    %rbx,%r8
  1b84a9:	sub    %r12,%r8
  1b84ac:	cmovb  %rsi,%r8
  1b84b0:	cmp    %r8,%rdi
  1b84b3:	cmovb  %rdi,%r8
  1b84b7:	mov    %rbx,%r9
  1b84ba:	sub    %rbp,%r9
  1b84bd:	cmovb  %rsi,%r9
  1b84c1:	cmp    %r9,%r8
  1b84c4:	cmovb  %r8,%r9
  1b84c8:	cmp    %r9,%r10
  1b84cb:	cmovb  %r10,%r9
  1b84cf:	imul   $0x130,%r11,%rsi
  1b84d6:	mov    %r13,0x10(%rsp)
  1b84db:	mov    %r13,%rdi
  1b84de:	shl    $0x4,%rdi
  1b84e2:	lea    (%r15,%rsi,1),%r8
  1b84e6:	lea    (%rdi,%r8,1),%rbx
  1b84ea:	add    $0x8,%rbx
  1b84ee:	add    %rdi,%r8
  1b84f1:	mov    %r9,%r13
  1b84f4:	shl    $0x4,%r13
  1b84f8:	add    %r13,%r8
  1b84fb:	add    $0x8,%r8
  1b84ff:	cmp    %rbx,%r8
  1b8502:	jb     1b8865 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf9e5>
  1b8508:	imul   $0x650,%r11,%r8
  1b850f:	lea    (%r15,%r8,1),%rbx
  1b8513:	lea    (%rdi,%rbx,1),%r11
  1b8517:	add    $0x8,%r11
  1b851b:	add    %rdi,%rbx
  1b851e:	add    %r13,%rbx
  1b8521:	add    $0x8,%rbx
  1b8525:	cmp    %r11,%rbx
  1b8528:	jb     1b8865 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf9e5>
  1b852e:	movabs $0xfffffffffffffff,%r11
  1b8538:	cmp    %r11,%r9
  1b853b:	mov    0x8(%rsp),%rbx
  1b8540:	ja     1b886a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf9ea>
  1b8546:	imul   $0x660,(%rsp),%r9
  1b854e:	xor    %r13d,%r13d
  1b8551:	mov    %rbx,%r11
  1b8554:	sub    0x60(%rsp),%rbx
  1b8559:	cmovb  %r13,%rbx
  1b855d:	mov    %r11,%r13
  1b8560:	sub    %r12,%r13
  1b8563:	mov    $0x0,%r12d
  1b8569:	cmovb  %r12,%r13
  1b856d:	cmp    %r13,%rbx
  1b8570:	cmovb  %rbx,%r13
  1b8574:	mov    %r11,%rbx
  1b8577:	sub    %rbp,%rbx
  1b857a:	cmovb  %r12,%rbx
  1b857e:	cmp    %rbx,%r13
  1b8581:	cmovb  %r13,%rbx
  1b8585:	lea    (%r9,%rdi,1),%r13
  1b8589:	cmp    %rbx,%r10
  1b858c:	cmovb  %r10,%rbx
  1b8590:	lea    (%r15,%r13,1),%r11
  1b8594:	shl    $0x4,%rbx
  1b8598:	lea    (%rbx,%r11,1),%r12
  1b859c:	add    $0x8,%r12
  1b85a0:	lea    0x8(%r15,%r13,1),%r10
  1b85a5:	mov    %r10,0x50(%rsp)
  1b85aa:	lea    0x10(%rbx,%r11,1),%r10
  1b85af:	mov    %r10,0x60(%rsp)
  1b85b4:	lea    (%rsi,%rdi,1),%r10
  1b85b8:	lea    (%r15,%r10,1),%r13
  1b85bc:	lea    0x8(%rbx,%r13,1),%rbp
  1b85c1:	mov    %rbp,0x40(%rsp)
  1b85c6:	lea    0x8(%r15,%r10,1),%r10
  1b85cb:	mov    %r10,0xd0(%rsp)
  1b85d3:	lea    0x10(%rbx,%r13,1),%r10
  1b85d8:	mov    %r10,0x38(%rsp)
  1b85dd:	lea    (%r8,%rdi,1),%r10
  1b85e1:	mov    %r10,0xb0(%rsp)
  1b85e9:	add    %r15,%r10
  1b85ec:	lea    0x8(%rbx,%r10,1),%rbp
  1b85f1:	mov    %rbp,0x20(%rsp)
  1b85f6:	add    %r10,%rbx
  1b85f9:	add    $0x10,%rbx
  1b85fd:	mov    %rbx,0xe0(%rsp)
  1b8605:	cmp    0x60(%rsp),%r11
  1b860a:	setb   0x48(%rsp)
  1b860f:	cmp    %r12,0x50(%rsp)
  1b8614:	setb   0x100(%rsp)
  1b861c:	cmp    0x40(%rsp),%r11
  1b8621:	setb   0x58(%rsp)
  1b8626:	cmp    %r12,%r13
  1b8629:	setb   0x88(%rsp)
  1b8631:	cmp    0x38(%rsp),%r11
  1b8636:	setb   0x78(%rsp)
  1b863b:	mov    0xd0(%rsp),%rbp
  1b8643:	cmp    %r12,%rbp
  1b8646:	setb   0x80(%rsp)
  1b864e:	cmp    0x20(%rsp),%r11
  1b8653:	setb   0x98(%rsp)
  1b865b:	cmp    %r12,%r10
  1b865e:	setb   0xc8(%rsp)
  1b8666:	cmp    %rbx,%r11
  1b8669:	mov    0xb0(%rsp),%r11
  1b8671:	lea    0x8(%r15,%r11,1),%rbx
  1b8676:	setb   0xb0(%rsp)
  1b867e:	cmp    %r12,%rbx
  1b8681:	setb   0xa8(%rsp)
  1b8689:	mov    0x50(%rsp),%r12
  1b868e:	cmp    0x40(%rsp),%r12
  1b8693:	setb   0x40(%rsp)
  1b8698:	mov    0x60(%rsp),%r11
  1b869d:	cmp    %r11,%r13
  1b86a0:	setb   0xf8(%rsp)
  1b86a8:	cmp    0x38(%rsp),%r12
  1b86ad:	setb   0x38(%rsp)
  1b86b2:	cmp    %r11,%rbp
  1b86b5:	setb   0xd0(%rsp)
  1b86bd:	cmp    0x20(%rsp),%r12
  1b86c2:	mov    %r12,%rbp
  1b86c5:	setb   0x20(%rsp)
  1b86ca:	cmp    %r11,%r10
  1b86cd:	mov    %r11,%r13
  1b86d0:	setb   %r12b
  1b86d4:	cmp    0xe0(%rsp),%rbp
  1b86dc:	setb   %r11b
  1b86e0:	cmp    %r13,%rbx
  1b86e3:	setb   %r10b
  1b86e7:	movzbl 0x100(%rsp),%ebx
  1b86ef:	test   %bl,0x48(%rsp)
  1b86f3:	jne    1b8865 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf9e5>
  1b86f9:	movzbl 0x88(%rsp),%ebx
  1b8701:	and    %bl,0x58(%rsp)
  1b8705:	jne    1b8865 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf9e5>
  1b870b:	movzbl 0x80(%rsp),%ebx
  1b8713:	and    %bl,0x78(%rsp)
  1b8717:	mov    0x8(%rsp),%rbx
  1b871c:	mov    0x10(%rsp),%r13
  1b8721:	jne    1b839b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf51b>
  1b8727:	movzbl 0xc8(%rsp),%ebp
  1b872f:	and    %bpl,0x98(%rsp)
  1b8737:	jne    1b839b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf51b>
  1b873d:	movzbl 0xa8(%rsp),%ebp
  1b8745:	and    %bpl,0xb0(%rsp)
  1b874d:	jne    1b839b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf51b>
  1b8753:	movzbl 0xf8(%rsp),%ebp
  1b875b:	and    %bpl,0x40(%rsp)
  1b8760:	jne    1b839b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf51b>
  1b8766:	mov    %r10d,%ebp
  1b8769:	movzbl 0xd0(%rsp),%r10d
  1b8772:	and    %r10b,0x38(%rsp)
  1b8777:	jne    1b839b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf51b>
  1b877d:	and    %r12b,0x20(%rsp)
  1b8782:	jne    1b839b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf51b>
  1b8788:	and    %bpl,%r11b
  1b878b:	mov    0x1d8(%rsp),%r10
  1b8793:	mov    0x30(%rsp),%r12
  1b8798:	jne    1bd246 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x143c6>
  1b879e:	and    $0xfffffffffffffffe,%rdx
  1b87a2:	add    %rdx,%r13
  1b87a5:	movsd  0x40(%r10),%xmm0
  1b87ab:	movsd  0x48(%r10),%xmm1
  1b87b1:	unpcklpd %xmm1,%xmm1
  1b87b5:	unpcklpd %xmm0,%xmm0
  1b87b9:	add    %r15,%rdi
  1b87bc:	mov    0x28(%rsp),%r11
  1b87c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b87d0:	movupd (%rdi,%rsi,1),%xmm3
  1b87d5:	movupd 0x10(%rdi,%rsi,1),%xmm4
  1b87db:	movapd %xmm3,%xmm2
  1b87df:	unpcklpd %xmm4,%xmm2
  1b87e3:	unpckhpd %xmm4,%xmm3
  1b87e7:	movapd %xmm1,%xmm4
  1b87eb:	mulpd  %xmm2,%xmm4
  1b87ef:	movapd %xmm0,%xmm5
  1b87f3:	mulpd  %xmm3,%xmm5
  1b87f7:	addpd  %xmm4,%xmm5
  1b87fb:	movupd (%rdi,%r8,1),%xmm4
  1b8801:	movupd 0x10(%rdi,%r8,1),%xmm6
  1b8808:	movapd %xmm4,%xmm7
  1b880c:	unpcklpd %xmm6,%xmm7
  1b8810:	unpckhpd %xmm6,%xmm4
  1b8814:	movapd %xmm7,%xmm6
  1b8818:	mulpd  %xmm5,%xmm6
  1b881c:	mulpd  %xmm0,%xmm2
  1b8820:	mulpd  %xmm1,%xmm3
  1b8824:	subpd  %xmm3,%xmm2
  1b8828:	mulpd  %xmm2,%xmm7
  1b882c:	mulpd  %xmm4,%xmm2
  1b8830:	addpd  %xmm6,%xmm2
  1b8834:	mulpd  %xmm5,%xmm4
  1b8838:	subpd  %xmm4,%xmm7
  1b883c:	movapd %xmm7,%xmm3
  1b8840:	unpcklpd %xmm2,%xmm3
  1b8844:	unpckhpd %xmm2,%xmm7
  1b8848:	movupd %xmm7,0x10(%rdi,%r9,1)
  1b884f:	movupd %xmm3,(%rdi,%r9,1)
  1b8855:	add    $0x20,%rdi
  1b8859:	add    $0xfffffffffffffffe,%rdx
  1b885d:	jne    1b87d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf950>
  1b8863:	jmp    1b8881 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfa01>
  1b8865:	mov    0x8(%rsp),%rbx
  1b886a:	mov    0x1d8(%rsp),%r10
  1b8872:	mov    0x28(%rsp),%r11
  1b8877:	mov    0x10(%rsp),%r13
  1b887c:	mov    0x30(%rsp),%r12
  1b8881:	mov    (%rsp),%rdi
  1b8885:	imul   $0x660,%rdi,%rdx
  1b888c:	mov    %r13,%rsi
  1b888f:	shl    $0x4,%rsi
  1b8893:	add    %r15,%rsi
  1b8896:	imul   $0x650,%rdi,%r8
  1b889d:	imul   $0x130,%rdi,%r9
  1b88a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b88b0:	lea    (%rcx,%r13,1),%rdi
  1b88b4:	cmp    %rbx,%rdi
  1b88b7:	jae    1bec9c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15e1c>
  1b88bd:	mov    0x18(%rsp),%rdi
  1b88c2:	add    %r13,%rdi
  1b88c5:	cmp    %rbx,%rdi
  1b88c8:	jae    1bec8c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15e0c>
  1b88ce:	lea    (%rax,%r13,1),%rdi
  1b88d2:	cmp    %rbx,%rdi
  1b88d5:	jae    1bec7c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15dfc>
  1b88db:	inc    %r13
  1b88de:	movupd 0x40(%r10),%xmm0
  1b88e4:	movupd (%rsi,%r9,1),%xmm1
  1b88ea:	movapd %xmm0,%xmm2
  1b88ee:	mulpd  %xmm1,%xmm2
  1b88f2:	movupd (%rsi,%r8,1),%xmm3
  1b88f8:	movapd %xmm2,%xmm4
  1b88fc:	unpcklpd %xmm2,%xmm4
  1b8900:	unpckhpd %xmm2,%xmm2
  1b8904:	subpd  %xmm2,%xmm4
  1b8908:	mulpd  %xmm3,%xmm4
  1b890c:	movapd %xmm1,%xmm2
  1b8910:	unpckhpd %xmm1,%xmm2
  1b8914:	mulsd  %xmm0,%xmm2
  1b8918:	unpckhpd %xmm0,%xmm0
  1b891c:	mulsd  %xmm1,%xmm0
  1b8920:	addsd  %xmm2,%xmm0
  1b8924:	unpcklpd %xmm0,%xmm0
  1b8928:	shufpd $0x1,%xmm3,%xmm3
  1b892d:	mulpd  %xmm0,%xmm3
  1b8931:	movapd %xmm4,%xmm0
  1b8935:	subpd  %xmm3,%xmm0
  1b8939:	addpd  %xmm4,%xmm3
  1b893d:	movsd  %xmm0,%xmm3
  1b8941:	movupd %xmm3,(%rsi,%rdx,1)
  1b8946:	add    $0x10,%rsi
  1b894a:	cmp    %r13,%r12
  1b894d:	jne    1b88b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfa30>
  1b8953:	xor    %eax,%eax
  1b8955:	mov    0x1b0(%rsp),%r9
  1b895d:	mov    0x1d0(%rsp),%rdx
  1b8965:	mov    0x90(%rsp),%rcx
  1b896d:	mov    0x1c8(%rsp),%r10
  1b8975:	data16 cs nopw 0x0(%rax,%rax,1)
  1b8980:	mov    (%r11,%rax,1),%rdi
  1b8984:	cmp    %rdx,%rdi
  1b8987:	jae    1bdc1b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14d9b>
  1b898d:	movq   $0x67,(%r10,%rdi,8)
  1b8995:	add    $0x8,%rax
  1b8999:	cmp    %rax,%r14
  1b899c:	jne    1b8980 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfb00>
  1b899e:	xor    %eax,%eax
  1b89a0:	xor    %r14d,%r14d
  1b89a3:	mov    0x110(%rsp),%rsi
  1b89ab:	jmp    1b89b9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfb39>
  1b89ad:	nopl   (%rax)
  1b89b0:	add    $0x8,%rax
  1b89b4:	cmp    %rax,%rcx
  1b89b7:	je     1b89df <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfb5f>
  1b89b9:	mov    (%rsi,%rax,1),%rdi
  1b89bd:	cmp    %rdx,%rdi
  1b89c0:	jae    1bd60a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1478a>
  1b89c6:	cmpq   $0x65,(%r10,%rdi,8)
  1b89cb:	jae    1b89b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfb30>
  1b89cd:	cmp    %r9,%r14
  1b89d0:	jae    1bda36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14bb6>
  1b89d6:	mov    %rdi,(%r11,%r14,8)
  1b89da:	inc    %r14
  1b89dd:	jmp    1b89b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfb30>
  1b89df:	cmp    %r9,%r14
  1b89e2:	ja     1bd2e2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14462>
  1b89e8:	test   %r14,%r14
  1b89eb:	je     1b8a26 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfba6>
  1b89ed:	mov    (%r11),%r12
  1b89f0:	lea    -0x1(%r14),%rax
  1b89f4:	mov    -0x8(%r11,%r14,8),%rcx
  1b89f9:	sub    %r12,%rcx
  1b89fc:	setae  %dl
  1b89ff:	cmp    %rax,%rcx
  1b8a02:	sete   %al
  1b8a05:	and    %dl,%al
  1b8a07:	cmp    $0x1,%al
  1b8a09:	jne    1b8a31 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfbb1>
  1b8a0b:	mov    %r12,%rax
  1b8a0e:	add    %r14,%rax
  1b8a11:	jb     1b8a31 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfbb1>
  1b8a13:	mov    %rax,0x60(%rsp)
  1b8a18:	mov    $0x1,%al
  1b8a1a:	mov    %rax,0x20(%rsp)
  1b8a1f:	mov    %r12,0x30(%rsp)
  1b8a24:	jmp    1b8a4c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfbcc>
  1b8a26:	xor    %r13d,%r13d
  1b8a29:	xor    %r12d,%r12d
  1b8a2c:	jmp    1b9044 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x101c4>
  1b8a31:	movq   $0x0,0x60(%rsp)
  1b8a3a:	movq   $0x0,0x30(%rsp)
  1b8a43:	movq   $0x0,0x20(%rsp)
  1b8a4c:	mov    0x1d0(%rsp),%rdx
  1b8a54:	mov    0x90(%rsp),%rcx
  1b8a5c:	shl    $0x3,%r14
  1b8a60:	mov    (%rsp),%rax
  1b8a64:	mov    %rax,%rdi
  1b8a67:	shl    $0x4,%rdi
  1b8a6b:	mov    %rdi,0x10(%rsp)
  1b8a70:	imul   $0x69,%rax,%rax
  1b8a74:	mov    %rax,0x18(%rsp)
  1b8a79:	xor    %ebp,%ebp
  1b8a7b:	movapd 0x1fdd57d(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b8a83:	xorpd  %xmm7,%xmm7
  1b8a87:	movsd  0x1fdec20(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b8a90:	movsd  0x1fdec1f(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b8a99:	movsd  0x1fdec26(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1b8aa2:	movapd 0x1fdd565(%rip),%xmm11        # 2196010 <_fini+0x530>
  1b8aab:	movsd  0x1fdec0c(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1b8ab4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b8ac0:	mov    (%r11,%rbp,1),%r13
  1b8ac4:	mov    0x10(%rsp),%rax
  1b8ac9:	lea    (%rax,%r13,1),%rdi
  1b8acd:	cmp    0x8(%rsp),%rdi
  1b8ad2:	jae    1bd8f1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14a71>
  1b8ad8:	mov    %r9,%rbx
  1b8adb:	shl    $0x4,%rdi
  1b8adf:	movupd (%r15,%rdi,1),%xmm0
  1b8ae5:	movapd %xmm0,%xmm2
  1b8ae9:	andpd  %xmm6,%xmm2
  1b8aed:	movapd %xmm0,%xmm1
  1b8af1:	unpckhpd %xmm0,%xmm1
  1b8af5:	movapd %xmm1,%xmm3
  1b8af9:	andpd  %xmm6,%xmm3
  1b8afd:	ucomisd %xmm7,%xmm0
  1b8b01:	je     1b8b60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfce0>
  1b8b03:	ucomisd %xmm7,%xmm1
  1b8b07:	je     1b8b60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfce0>
  1b8b09:	movapd %xmm2,%xmm4
  1b8b0d:	cmplesd %xmm3,%xmm4
  1b8b12:	movapd %xmm4,%xmm5
  1b8b16:	andpd  %xmm3,%xmm5
  1b8b1a:	andnpd %xmm2,%xmm4
  1b8b1e:	orpd   %xmm5,%xmm4
  1b8b22:	ucomisd %xmm8,%xmm4
  1b8b27:	jbe    1b8b60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfce0>
  1b8b29:	ucomisd %xmm4,%xmm9
  1b8b2e:	jbe    1b8b60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfce0>
  1b8b30:	movapd %xmm0,%xmm2
  1b8b34:	mulpd  %xmm0,%xmm2
  1b8b38:	movapd %xmm2,%xmm3
  1b8b3c:	unpckhpd %xmm2,%xmm3
  1b8b40:	addsd  %xmm2,%xmm3
  1b8b44:	movapd %xmm10,%xmm2
  1b8b49:	divsd  %xmm3,%xmm2
  1b8b4d:	mulsd  %xmm2,%xmm0
  1b8b51:	xorpd  %xmm11,%xmm1
  1b8b56:	mulsd  %xmm2,%xmm1
  1b8b5a:	jmp    1b8c05 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfd85>
  1b8b5f:	nop
  1b8b60:	ucomisd %xmm7,%xmm1
  1b8b64:	setnp  %al
  1b8b67:	sete   %cl
  1b8b6a:	and    %al,%cl
  1b8b6c:	movq   %xmm0,%rax
  1b8b71:	movabs $0x7fffffffffffffff,%r8
  1b8b7b:	and    %r8,%rax
  1b8b7e:	movabs $0x7ff0000000000000,%r9
  1b8b88:	cmp    %r9,%rax
  1b8b8b:	setl   %dl
  1b8b8e:	test   %dl,%cl
  1b8b90:	je     1b8bc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfd40>
  1b8b92:	movapd %xmm10,%xmm2
  1b8b97:	divsd  %xmm0,%xmm2
  1b8b9b:	xorpd  %xmm11,%xmm1
  1b8ba0:	movapd %xmm2,%xmm0
  1b8ba4:	mov    0x1d0(%rsp),%rdx
  1b8bac:	mov    0x90(%rsp),%rcx
  1b8bb4:	jmp    1b8c05 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfd85>
  1b8bb6:	cs nopw 0x0(%rax,%rax,1)
  1b8bc0:	ucomisd %xmm7,%xmm0
  1b8bc4:	setnp  %cl
  1b8bc7:	sete   %dl
  1b8bca:	and    %cl,%dl
  1b8bcc:	movq   %xmm1,%rcx
  1b8bd1:	and    %r8,%rcx
  1b8bd4:	cmp    %r9,%rcx
  1b8bd7:	setl   %sil
  1b8bdb:	test   %sil,%dl
  1b8bde:	je     1b8c3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfdbe>
  1b8be0:	movapd %xmm12,%xmm2
  1b8be5:	divsd  %xmm1,%xmm2
  1b8be9:	movapd %xmm2,%xmm1
  1b8bed:	mov    0x1d0(%rsp),%rdx
  1b8bf5:	mov    0x90(%rsp),%rcx
  1b8bfd:	mov    0x110(%rsp),%rsi
  1b8c05:	mov    %rbx,%r9
  1b8c08:	mov    0x8(%rsp),%rax
  1b8c0d:	add    0x18(%rsp),%r13
  1b8c12:	cmp    %rax,%r13
  1b8c15:	jae    1bd8dc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14a5c>
  1b8c1b:	shl    $0x4,%r13
  1b8c1f:	movsd  %xmm0,(%r15,%r13,1)
  1b8c25:	movsd  %xmm1,0x8(%r15,%r13,1)
  1b8c2c:	add    $0x8,%rbp
  1b8c30:	cmp    %rbp,%r14
  1b8c33:	jne    1b8ac0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfc40>
  1b8c39:	jmp    1b8d8a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xff0a>
  1b8c3e:	movabs $0x7fefffffffffffff,%rdx
  1b8c48:	cmp    %rdx,%rax
  1b8c4b:	setg   %al
  1b8c4e:	cmp    %rdx,%rcx
  1b8c51:	setg   %cl
  1b8c54:	or     %al,%cl
  1b8c56:	cmp    $0x1,%cl
  1b8c59:	jne    1b8cce <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfe4e>
  1b8c5b:	add    %r15,%rdi
  1b8c5e:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1b8c63:	movsd  0x1fdea54(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1b8c6c:	movapd 0x1fdd39b(%rip),%xmm11        # 2196010 <_fini+0x530>
  1b8c75:	movsd  0x1fdea4a(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1b8c7e:	movsd  0x1fdea31(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b8c87:	movsd  0x1fdea20(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b8c90:	xorpd  %xmm7,%xmm7
  1b8c94:	movapd 0x1fdd364(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b8c9c:	mov    0x1c8(%rsp),%r10
  1b8ca4:	mov    0x28(%rsp),%r11
  1b8ca9:	mov    0x1b0(%rsp),%r9
  1b8cb1:	mov    0x1d0(%rsp),%rdx
  1b8cb9:	mov    0x90(%rsp),%rcx
  1b8cc1:	mov    0x110(%rsp),%rsi
  1b8cc9:	jmp    1b8c08 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfd88>
  1b8cce:	mov    %rbx,%r9
  1b8cd1:	ucomisd %xmm7,%xmm1
  1b8cd5:	mov    0x1d0(%rsp),%rdx
  1b8cdd:	mov    0x110(%rsp),%rsi
  1b8ce5:	mov    0x8(%rsp),%rax
  1b8cea:	jne    1b8d0d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfe8d>
  1b8cec:	jp     1b8d0d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfe8d>
  1b8cee:	movapd %xmm10,%xmm2
  1b8cf3:	divsd  %xmm0,%xmm2
  1b8cf7:	xorpd  %xmm11,%xmm1
  1b8cfc:	movapd %xmm2,%xmm0
  1b8d00:	mov    0x90(%rsp),%rcx
  1b8d08:	jmp    1b8c0d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfd8d>
  1b8d0d:	ucomisd %xmm7,%xmm0
  1b8d11:	mov    0x90(%rsp),%rcx
  1b8d19:	jne    1b8d2f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfeaf>
  1b8d1b:	jp     1b8d2f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfeaf>
  1b8d1d:	movapd %xmm12,%xmm2
  1b8d22:	divsd  %xmm1,%xmm2
  1b8d26:	movapd %xmm2,%xmm1
  1b8d2a:	jmp    1b8c0d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfd8d>
  1b8d2f:	movapd %xmm3,%xmm1
  1b8d33:	cmplesd %xmm2,%xmm1
  1b8d38:	movapd %xmm1,%xmm4
  1b8d3c:	andpd  %xmm2,%xmm4
  1b8d40:	andnpd %xmm3,%xmm1
  1b8d44:	orpd   %xmm4,%xmm1
  1b8d48:	unpcklpd %xmm1,%xmm1
  1b8d4c:	divpd  %xmm1,%xmm0
  1b8d50:	movapd %xmm0,%xmm2
  1b8d54:	xorpd  %xmm11,%xmm2
  1b8d59:	movsd  %xmm0,%xmm2
  1b8d5d:	mulpd  %xmm0,%xmm0
  1b8d61:	movapd %xmm0,%xmm3
  1b8d65:	unpcklpd %xmm0,%xmm3
  1b8d69:	unpckhpd %xmm0,%xmm0
  1b8d6d:	addpd  %xmm3,%xmm0
  1b8d71:	divpd  %xmm0,%xmm2
  1b8d75:	divpd  %xmm1,%xmm2
  1b8d79:	movapd %xmm2,%xmm0
  1b8d7d:	movapd %xmm2,%xmm1
  1b8d81:	unpckhpd %xmm2,%xmm1
  1b8d85:	jmp    1b8c0d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfd8d>
  1b8d8a:	cmpb   $0x0,0x20(%rsp)
  1b8d8f:	je     1b8f44 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x100c4>
  1b8d95:	mov    0x60(%rsp),%r13
  1b8d9a:	mov    0x30(%rsp),%r12
  1b8d9f:	cmp    %r13,%r12
  1b8da2:	mov    0x8(%rsp),%rbx
  1b8da7:	jae    1b9044 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x101c4>
  1b8dad:	mov    (%rsp),%rax
  1b8db1:	lea    (%r12,%rax,2),%rdi
  1b8db5:	cmpq   $0x0,0x1e0(%rsp)
  1b8dbe:	je     1bf156 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x162d6>
  1b8dc4:	mov    (%rsp),%rcx
  1b8dc8:	lea    (%rcx,%rcx,1),%rax
  1b8dcc:	imul   $0x6a,%rcx,%rcx
  1b8dd0:	cmp    %rdi,%rbx
  1b8dd3:	cmova  %rbx,%rdi
  1b8dd7:	mov    %r12,%r10
  1b8dda:	add    %rax,%r12
  1b8ddd:	sub    %r12,%rdi
  1b8de0:	mov    0x18(%rsp),%rdx
  1b8de5:	lea    (%r10,%rdx,1),%r11
  1b8de9:	xor    %esi,%esi
  1b8deb:	mov    %rbx,%r8
  1b8dee:	sub    %r11,%r8
  1b8df1:	cmovb  %rsi,%r8
  1b8df5:	cmp    %r8,%rdi
  1b8df8:	cmovb  %rdi,%r8
  1b8dfc:	lea    (%r10,%rcx,1),%r13
  1b8e00:	mov    %rbx,%rdx
  1b8e03:	sub    %r13,%rdx
  1b8e06:	cmovb  %rsi,%rdx
  1b8e0a:	cmp    %rdx,%r8
  1b8e0d:	cmovb  %r8,%rdx
  1b8e11:	mov    %r10,%r14
  1b8e14:	not    %r14
  1b8e17:	add    0x60(%rsp),%r14
  1b8e1c:	cmp    %r14,%rdx
  1b8e1f:	cmovae %r14,%rdx
  1b8e23:	lea    0x1(%rdx),%rsi
  1b8e27:	mov    %r10,0x30(%rsp)
  1b8e2c:	cmp    $0x20,%rsi
  1b8e30:	ja     1b9ca9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10e29>
  1b8e36:	mov    (%rsp),%r9
  1b8e3a:	imul   $0x6a0,%r9,%rdx
  1b8e41:	mov    %r10,%rsi
  1b8e44:	shl    $0x4,%rsi
  1b8e48:	add    %r15,%rsi
  1b8e4b:	imul   $0x690,%r9,%r8
  1b8e52:	shl    $0x5,%r9
  1b8e56:	mov    0x1d8(%rsp),%r11
  1b8e5e:	mov    0x60(%rsp),%r13
  1b8e63:	mov    0x30(%rsp),%r12
  1b8e68:	nopl   0x0(%rax,%rax,1)
  1b8e70:	lea    (%rax,%r10,1),%rdi
  1b8e74:	cmp    %rbx,%rdi
  1b8e77:	jae    1bf15f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x162df>
  1b8e7d:	mov    0x18(%rsp),%rdi
  1b8e82:	add    %r10,%rdi
  1b8e85:	cmp    %rbx,%rdi
  1b8e88:	jae    1be82b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x159ab>
  1b8e8e:	lea    (%rcx,%r10,1),%rdi
  1b8e92:	cmp    %rbx,%rdi
  1b8e95:	jae    1be81b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1599b>
  1b8e9b:	inc    %r10
  1b8e9e:	movupd (%rsi,%r9,1),%xmm0
  1b8ea4:	movupd (%r11),%xmm1
  1b8ea9:	movapd %xmm0,%xmm2
  1b8ead:	mulpd  %xmm1,%xmm2
  1b8eb1:	movupd (%rsi,%r8,1),%xmm3
  1b8eb7:	movapd %xmm2,%xmm4
  1b8ebb:	unpcklpd %xmm2,%xmm4
  1b8ebf:	unpckhpd %xmm2,%xmm2
  1b8ec3:	subpd  %xmm2,%xmm4
  1b8ec7:	mulpd  %xmm3,%xmm4
  1b8ecb:	movapd %xmm1,%xmm2
  1b8ecf:	unpckhpd %xmm1,%xmm2
  1b8ed3:	mulsd  %xmm0,%xmm2
  1b8ed7:	unpckhpd %xmm0,%xmm0
  1b8edb:	mulsd  %xmm1,%xmm0
  1b8edf:	addsd  %xmm2,%xmm0
  1b8ee3:	unpcklpd %xmm0,%xmm0
  1b8ee7:	shufpd $0x1,%xmm3,%xmm3
  1b8eec:	mulpd  %xmm0,%xmm3
  1b8ef0:	movapd %xmm4,%xmm0
  1b8ef4:	subpd  %xmm3,%xmm0
  1b8ef8:	addpd  %xmm4,%xmm3
  1b8efc:	movsd  %xmm0,%xmm3
  1b8f00:	movupd %xmm3,(%rsi,%rdx,1)
  1b8f05:	add    $0x10,%rsi
  1b8f09:	cmp    %r10,%r13
  1b8f0c:	jne    1b8e70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfff0>
  1b8f12:	mov    0x1b0(%rsp),%r9
  1b8f1a:	mov    0x28(%rsp),%r11
  1b8f1f:	mov    0x1d0(%rsp),%rdx
  1b8f27:	mov    0x90(%rsp),%rcx
  1b8f2f:	mov    0x110(%rsp),%rsi
  1b8f37:	mov    0x1c8(%rsp),%r10
  1b8f3f:	jmp    1b9044 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x101c4>
  1b8f44:	mov    (%rsp),%rax
  1b8f48:	lea    (%rax,%rax,1),%rcx
  1b8f4c:	cmpq   $0x0,0x1e0(%rsp)
  1b8f55:	mov    0x8(%rsp),%rbx
  1b8f5a:	mov    0x60(%rsp),%r13
  1b8f5f:	je     1bf0d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16250>
  1b8f65:	imul   $0x6a,(%rsp),%rdx
  1b8f6a:	xor    %esi,%esi
  1b8f6c:	nopl   0x0(%rax)
  1b8f70:	mov    (%r11,%rsi,1),%rdi
  1b8f74:	lea    (%rdi,%rcx,1),%r12
  1b8f78:	cmp    %rbx,%r12
  1b8f7b:	jae    1bf0dc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1625c>
  1b8f81:	mov    0x18(%rsp),%rax
  1b8f86:	add    %rdi,%rax
  1b8f89:	cmp    %rbx,%rax
  1b8f8c:	jae    1be077 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x151f7>
  1b8f92:	add    %rdx,%rdi
  1b8f95:	cmp    %rbx,%rdi
  1b8f98:	jae    1be067 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x151e7>
  1b8f9e:	shl    $0x4,%r12
  1b8fa2:	shl    $0x4,%rax
  1b8fa6:	movupd (%r15,%r12,1),%xmm0
  1b8fac:	mov    0x1d8(%rsp),%r8
  1b8fb4:	movupd (%r8),%xmm1
  1b8fb9:	movapd %xmm0,%xmm2
  1b8fbd:	mulpd  %xmm1,%xmm2
  1b8fc1:	shl    $0x4,%rdi
  1b8fc5:	movupd (%r15,%rax,1),%xmm3
  1b8fcb:	movapd %xmm2,%xmm4
  1b8fcf:	unpcklpd %xmm2,%xmm4
  1b8fd3:	unpckhpd %xmm2,%xmm2
  1b8fd7:	subpd  %xmm2,%xmm4
  1b8fdb:	mulpd  %xmm3,%xmm4
  1b8fdf:	movapd %xmm1,%xmm2
  1b8fe3:	unpckhpd %xmm1,%xmm2
  1b8fe7:	mulsd  %xmm0,%xmm2
  1b8feb:	unpckhpd %xmm0,%xmm0
  1b8fef:	mulsd  %xmm1,%xmm0
  1b8ff3:	addsd  %xmm2,%xmm0
  1b8ff7:	unpcklpd %xmm0,%xmm0
  1b8ffb:	shufpd $0x1,%xmm3,%xmm3
  1b9000:	mulpd  %xmm0,%xmm3
  1b9004:	movapd %xmm4,%xmm0
  1b9008:	subpd  %xmm3,%xmm0
  1b900c:	addpd  %xmm4,%xmm3
  1b9010:	movsd  %xmm0,%xmm3
  1b9014:	movupd %xmm3,(%r15,%rdi,1)
  1b901a:	add    $0x8,%rsi
  1b901e:	cmp    %rsi,%r14
  1b9021:	jne    1b8f70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x100f0>
  1b9027:	mov    0x1d0(%rsp),%rdx
  1b902f:	mov    0x90(%rsp),%rcx
  1b9037:	mov    0x110(%rsp),%rsi
  1b903f:	mov    0x30(%rsp),%r12
  1b9044:	xor    %eax,%eax
  1b9046:	xor    %r14d,%r14d
  1b9049:	jmp    1b9059 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x101d9>
  1b904b:	nopl   0x0(%rax,%rax,1)
  1b9050:	add    $0x8,%rax
  1b9054:	cmp    %rax,%rcx
  1b9057:	je     1b907f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x101ff>
  1b9059:	mov    (%rsi,%rax,1),%rdi
  1b905d:	cmp    %rdx,%rdi
  1b9060:	jae    1bd61a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1479a>
  1b9066:	cmpq   $0x68,(%r10,%rdi,8)
  1b906b:	jae    1b9050 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x101d0>
  1b906d:	cmp    %r9,%r14
  1b9070:	jae    1bda49 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14bc9>
  1b9076:	mov    %rdi,(%r11,%r14,8)
  1b907a:	inc    %r14
  1b907d:	jmp    1b9050 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x101d0>
  1b907f:	cmp    %r9,%r14
  1b9082:	ja     1bd2f7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14477>
  1b9088:	test   %r14,%r14
  1b908b:	je     1bb12e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x122ae>
  1b9091:	mov    (%r11),%rsi
  1b9094:	lea    -0x1(%r14),%rax
  1b9098:	mov    -0x8(%r11,%r14,8),%rcx
  1b909d:	sub    %rsi,%rcx
  1b90a0:	setae  %dl
  1b90a3:	cmp    %rax,%rcx
  1b90a6:	sete   %al
  1b90a9:	mov    %rsi,%rcx
  1b90ac:	add    %r14,%rcx
  1b90af:	cmovb  %r13,%rcx
  1b90b3:	cmovb  %r12,%rsi
  1b90b7:	test   %al,%dl
  1b90b9:	cmove  %r13,%rcx
  1b90bd:	mov    %rcx,0x10(%rsp)
  1b90c2:	cmove  %r12,%rsi
  1b90c6:	mov    %rsi,0x18(%rsp)
  1b90cb:	lea    0x0(,%r14,8),%r12
  1b90d3:	mov    (%rsp),%r13
  1b90d7:	lea    0x0(,%r13,2),%rcx
  1b90df:	shl    $0x5,%r13
  1b90e3:	mov    %r13,0x40(%rsp)
  1b90e8:	mov    %rcx,0x38(%rsp)
  1b90ed:	sub    %rcx,%r13
  1b90f0:	xor    %ebp,%ebp
  1b90f2:	xorpd  %xmm1,%xmm1
  1b90f6:	jmp    1b912f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x102af>
  1b90f8:	nopl   0x0(%rax,%rax,1)
  1b9100:	mov    $0x6c,%r8d
  1b9106:	mov    %r15,%rdi
  1b9109:	mov    %rbx,%rsi
  1b910c:	mov    (%rsp),%rdx
  1b9110:	call   1a8d70 <oneloop::native::batch::copy_active_column::<f64>>
  1b9115:	add    $0x8,%rbp
  1b9119:	cmp    %rbp,%r12
  1b911c:	mov    0x28(%rsp),%r11
  1b9121:	mov    0x1c8(%rsp),%r10
  1b9129:	xorpd  %xmm1,%xmm1
  1b912d:	je     1b9170 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x102f0>
  1b912f:	mov    (%r11,%rbp,1),%rcx
  1b9133:	lea    (%rcx,%r13,1),%rdi
  1b9137:	cmp    %rbx,%rdi
  1b913a:	jae    1bd903 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14a83>
  1b9140:	shl    $0x4,%rdi
  1b9144:	movsd  (%r15,%rdi,1),%xmm0
  1b914a:	mov    $0x66,%r9d
  1b9150:	ucomisd %xmm1,%xmm0
  1b9154:	jne    1b9100 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10280>
  1b9156:	jp     1b9100 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10280>
  1b9158:	add    %r15,%rdi
  1b915b:	movsd  0x8(%rdi),%xmm0
  1b9160:	ucomisd %xmm1,%xmm0
  1b9164:	jne    1b9100 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10280>
  1b9166:	jp     1b9100 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10280>
  1b9168:	mov    $0x6a,%r9d
  1b916e:	jmp    1b9100 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10280>
  1b9170:	mov    (%rsp),%rbp
  1b9174:	imul   $0x6c,%rbp,%rcx
  1b9178:	xor    %edx,%edx
  1b917a:	xorpd  %xmm0,%xmm0
  1b917e:	xor    %esi,%esi
  1b9180:	mov    0x1d8(%rsp),%r9
  1b9188:	nopl   0x0(%rax,%rax,1)
  1b9190:	mov    (%r11,%rdx,8),%rdi
  1b9194:	lea    (%rdi,%rcx,1),%rax
  1b9198:	cmp    %rbx,%rax
  1b919b:	jae    1bd913 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14a93>
  1b91a1:	shl    $0x4,%rax
  1b91a5:	movsd  (%r15,%rax,1),%xmm1
  1b91ab:	ucomisd %xmm0,%xmm1
  1b91af:	jne    1b91f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10370>
  1b91b1:	jp     1b91f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10370>
  1b91b3:	add    %r15,%rax
  1b91b6:	movsd  0x8(%rax),%xmm1
  1b91bb:	ucomisd %xmm0,%xmm1
  1b91bf:	jne    1b91f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10370>
  1b91c1:	jp     1b91f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10370>
  1b91c3:	cmp    0x1d0(%rsp),%rdi
  1b91cb:	jae    1be2b4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15434>
  1b91d1:	movq   $0xa2,(%r10,%rdi,8)
  1b91d9:	inc    %rdx
  1b91dc:	cmp    %rdx,%r14
  1b91df:	jne    1b9190 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10310>
  1b91e1:	jmp    1b920d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1038d>
  1b91e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b91f0:	cmp    0x1b0(%rsp),%rsi
  1b91f8:	jae    1bdd43 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14ec3>
  1b91fe:	mov    %rdi,(%r11,%rsi,8)
  1b9202:	inc    %rsi
  1b9205:	inc    %rdx
  1b9208:	cmp    %rdx,%r14
  1b920b:	jne    1b9190 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10310>
  1b920d:	cmp    0x1b0(%rsp),%rsi
  1b9215:	ja     1bd3e7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14567>
  1b921b:	test   %rsi,%rsi
  1b921e:	mov    0x1d0(%rsp),%rdx
  1b9226:	mov    0x90(%rsp),%rcx
  1b922e:	je     1bb12e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x122ae>
  1b9234:	mov    (%r11),%r12
  1b9237:	lea    -0x1(%rsi),%rdx
  1b923b:	mov    -0x8(%r11,%rsi,8),%rax
  1b9240:	sub    %r12,%rax
  1b9243:	setae  %cl
  1b9246:	cmp    %rdx,%rax
  1b9249:	sete   %al
  1b924c:	lea    (%r12,%rsi,1),%rdi
  1b9250:	cmp    %r12,%rdi
  1b9253:	setae  %r8b
  1b9257:	and    %al,%r8b
  1b925a:	and    %cl,%r8b
  1b925d:	mov    %r8b,0x20(%rsp)
  1b9262:	cmp    $0x1,%r8b
  1b9266:	je     1b939e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1051e>
  1b926c:	cmpq   $0x2,0x1e0(%rsp)
  1b9275:	jb     1bf251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163d1>
  1b927b:	lea    0x0(,%rsi,8),%rdx
  1b9283:	lea    0x0(,%rbp,4),%rax
  1b928b:	imul   $0x6e,%rbp,%r14
  1b928f:	lea    (%rax,%rax,2),%rcx
  1b9293:	xor    %r8d,%r8d
  1b9296:	cs nopw 0x0(%rax,%rax,1)
  1b92a0:	mov    (%r11,%r8,1),%rdi
  1b92a4:	lea    (%rdi,%rcx,1),%rax
  1b92a8:	cmp    %rbx,%rax
  1b92ab:	jae    1be454 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x155d4>
  1b92b1:	add    %r14,%rdi
  1b92b4:	cmp    %rbx,%rdi
  1b92b7:	jae    1be444 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x155c4>
  1b92bd:	shl    $0x4,%rax
  1b92c1:	shl    $0x4,%rdi
  1b92c5:	movupd 0x10(%r9),%xmm0
  1b92cb:	movsd  (%r15,%rax,1),%xmm1
  1b92d1:	movsd  0x8(%r15,%rax,1),%xmm2
  1b92d8:	unpcklpd %xmm1,%xmm1
  1b92dc:	mulpd  %xmm0,%xmm1
  1b92e0:	shufpd $0x1,%xmm0,%xmm0
  1b92e5:	unpcklpd %xmm2,%xmm2
  1b92e9:	mulpd  %xmm0,%xmm2
  1b92ed:	movapd %xmm1,%xmm0
  1b92f1:	subpd  %xmm2,%xmm0
  1b92f5:	addpd  %xmm1,%xmm2
  1b92f9:	movsd  %xmm0,%xmm2
  1b92fd:	movupd %xmm2,(%r15,%rdi,1)
  1b9303:	add    $0x8,%r8
  1b9307:	cmp    %r8,%rdx
  1b930a:	jne    1b92a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10420>
  1b930c:	lea    0x0(,%rbp,4),%rax
  1b9314:	add    %rbp,%rax
  1b9317:	lea    (%rax,%rax,2),%r8
  1b931b:	imul   $0x6f,%rbp,%r12
  1b931f:	xor    %r9d,%r9d
  1b9322:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1b9330:	mov    (%r11,%r9,1),%rdi
  1b9334:	lea    (%rdi,%r8,1),%rax
  1b9338:	cmp    %rbx,%rax
  1b933b:	jae    1be48a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1560a>
  1b9341:	lea    (%rdi,%r14,1),%rcx
  1b9345:	cmp    %rbx,%rcx
  1b9348:	jae    1be477 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x155f7>
  1b934e:	add    %r12,%rdi
  1b9351:	cmp    %rbx,%rdi
  1b9354:	jae    1be467 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x155e7>
  1b935a:	shl    $0x4,%rax
  1b935e:	shl    $0x4,%rcx
  1b9362:	shl    $0x4,%rdi
  1b9366:	movupd (%r15,%rax,1),%xmm0
  1b936c:	movupd (%r15,%rcx,1),%xmm1
  1b9372:	addpd  %xmm0,%xmm1
  1b9376:	movupd %xmm1,(%r15,%rdi,1)
  1b937c:	add    $0x8,%r9
  1b9380:	cmp    %r9,%rdx
  1b9383:	jne    1b9330 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x104b0>
  1b9385:	mov    0x18(%rsp),%rax
  1b938a:	mov    %rax,0x60(%rsp)
  1b938f:	mov    0x10(%rsp),%rax
  1b9394:	mov    %rax,0x30(%rsp)
  1b9399:	jmp    1b9594 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10714>
  1b939e:	mov    %rdi,0x30(%rsp)
  1b93a3:	cmp    %rdi,%r12
  1b93a6:	mov    %r12,0x60(%rsp)
  1b93ab:	jae    1b9590 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10710>
  1b93b1:	mov    %rsi,0x50(%rsp)
  1b93b6:	cmpq   $0x2,0x1e0(%rsp)
  1b93bf:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b93c5:	lea    0x0(,%rbp,4),%rax
  1b93cd:	imul   $0x6e,%rbp,%rcx
  1b93d1:	lea    (%rax,%rax,2),%rdi
  1b93d5:	lea    (%r12,%rdi,1),%r14
  1b93d9:	xor    %r8d,%r8d
  1b93dc:	mov    %rbx,%rax
  1b93df:	sub    %r14,%rax
  1b93e2:	cmovb  %r8,%rax
  1b93e6:	mov    %r12,%rbp
  1b93e9:	add    %rcx,%r12
  1b93ec:	mov    %rbx,%rsi
  1b93ef:	sub    %r12,%rsi
  1b93f2:	cmovb  %r8,%rsi
  1b93f6:	cmp    %rsi,%rax
  1b93f9:	mov    %rsi,0x18(%rsp)
  1b93fe:	cmovae %rsi,%rax
  1b9402:	cmp    %rax,%rdx
  1b9405:	cmovb  %rdx,%rax
  1b9409:	lea    0x1(%rax),%r8
  1b940d:	mov    %rbp,%r10
  1b9410:	cmp    $0x1e,%r8
  1b9414:	ja     1ba99d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x11b1d>
  1b941a:	lea    (%r10,%rcx,1),%rax
  1b941e:	mov    (%rsp),%r11
  1b9422:	imul   $0x6e0,%r11,%r8
  1b9429:	mov    %r10,%r9
  1b942c:	shl    $0x4,%r9
  1b9430:	add    %r15,%r9
  1b9433:	add    %r10,%rdi
  1b9436:	shl    $0x6,%r11
  1b943a:	lea    (%r11,%r11,2),%r11
  1b943e:	sub    0x50(%rsp),%r10
  1b9443:	mov    0x1d8(%rsp),%rsi
  1b944b:	nopl   0x0(%rax,%rax,1)
  1b9450:	cmp    %rbx,%rdi
  1b9453:	jae    1bed12 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15e92>
  1b9459:	cmp    %rbx,%rax
  1b945c:	jae    1becff <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15e7f>
  1b9462:	movupd 0x10(%rsi),%xmm0
  1b9467:	movsd  (%r9,%r11,1),%xmm1
  1b946d:	movsd  0x8(%r9,%r11,1),%xmm2
  1b9474:	unpcklpd %xmm1,%xmm1
  1b9478:	mulpd  %xmm0,%xmm1
  1b947c:	shufpd $0x1,%xmm0,%xmm0
  1b9481:	unpcklpd %xmm2,%xmm2
  1b9485:	mulpd  %xmm0,%xmm2
  1b9489:	movapd %xmm1,%xmm0
  1b948d:	subpd  %xmm2,%xmm0
  1b9491:	addpd  %xmm1,%xmm2
  1b9495:	movsd  %xmm0,%xmm2
  1b9499:	movupd %xmm2,(%r9,%r8,1)
  1b949f:	inc    %rax
  1b94a2:	add    $0x10,%r9
  1b94a6:	inc    %rdi
  1b94a9:	inc    %r10
  1b94ac:	cmp    %r10,%rbp
  1b94af:	jne    1b9450 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x105d0>
  1b94b1:	mov    (%rsp),%rsi
  1b94b5:	lea    (%rsi,%rsi,4),%rax
  1b94b9:	lea    (%rax,%rax,2),%rax
  1b94bd:	mov    %rbp,%r13
  1b94c0:	imul   $0x6f,%rsi,%r12
  1b94c4:	add    %rax,%rbp
  1b94c7:	xor    %r9d,%r9d
  1b94ca:	mov    %rbx,%r10
  1b94cd:	sub    %rbp,%r10
  1b94d0:	cmovb  %r9,%r10
  1b94d4:	mov    0x18(%rsp),%rsi
  1b94d9:	cmp    %rsi,%r10
  1b94dc:	cmovae %rsi,%r10
  1b94e0:	lea    (%r12,%r13,1),%rsi
  1b94e4:	mov    %rbx,%rdi
  1b94e7:	sub    %rsi,%rdi
  1b94ea:	cmovb  %r9,%rdi
  1b94ee:	cmp    %rdi,%r10
  1b94f1:	cmovb  %r10,%rdi
  1b94f5:	cmp    %rdi,%rdx
  1b94f8:	cmovb  %rdx,%rdi
  1b94fc:	lea    0x1(%rdi),%r9
  1b9500:	mov    %r13,%r14
  1b9503:	cmp    $0x3e,%r9
  1b9507:	ja     1bac26 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x11da6>
  1b950d:	mov    (%rsp),%rbp
  1b9511:	imul   $0x6f0,%rbp,%rdx
  1b9518:	mov    %r14,%r13
  1b951b:	shl    $0x4,%r13
  1b951f:	add    %r15,%r13
  1b9522:	imul   $0xf0,%rbp,%r9
  1b9529:	mov    0x28(%rsp),%r11
  1b952e:	mov    0x1c8(%rsp),%r10
  1b9536:	mov    0x50(%rsp),%rsi
  1b953b:	nopl   0x0(%rax,%rax,1)
  1b9540:	lea    (%rax,%r14,1),%rdi
  1b9544:	cmp    %rbx,%rdi
  1b9547:	jae    1bed42 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ec2>
  1b954d:	lea    (%rcx,%r14,1),%rdi
  1b9551:	cmp    %rbx,%rdi
  1b9554:	jae    1bed32 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15eb2>
  1b955a:	lea    (%r12,%r14,1),%rdi
  1b955e:	cmp    %rbx,%rdi
  1b9561:	jae    1bed22 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ea2>
  1b9567:	inc    %r14
  1b956a:	movupd 0x0(%r13,%r9,1),%xmm0
  1b9571:	movupd 0x0(%r13,%r8,1),%xmm1
  1b9578:	addpd  %xmm0,%xmm1
  1b957c:	movupd %xmm1,0x0(%r13,%rdx,1)
  1b9583:	add    $0x10,%r13
  1b9587:	cmp    %r14,0x30(%rsp)
  1b958c:	jne    1b9540 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x106c0>
  1b958e:	jmp    1b9594 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10714>
  1b9590:	imul   $0x6f,%rbp,%r12
  1b9594:	mov    0x1b0(%rsp),%r9
  1b959c:	mov    %rsi,0x50(%rsp)
  1b95a1:	lea    0x0(,%rsi,8),%rsi
  1b95a9:	imul   $0x70,%rbp,%rax
  1b95ad:	xor    %r13d,%r13d
  1b95b0:	xorpd  %xmm8,%xmm8
  1b95b5:	movapd 0x1fdca43(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b95bd:	movsd  0x1fde0eb(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b95c5:	mov    %rax,0x10(%rsp)
  1b95ca:	mov    %rsi,0x18(%rsp)
  1b95cf:	nop
  1b95d0:	mov    (%r11,%r13,1),%r14
  1b95d4:	lea    (%r14,%r12,1),%rdi
  1b95d8:	cmp    %rbx,%rdi
  1b95db:	jae    1bdc51 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14dd1>
  1b95e1:	shl    $0x4,%rdi
  1b95e5:	movupd (%r15,%rdi,1),%xmm0
  1b95eb:	movapd %xmm0,%xmm1
  1b95ef:	unpckhpd %xmm0,%xmm1
  1b95f3:	ucomisd %xmm8,%xmm1
  1b95f8:	jne    1b9610 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10790>
  1b95fa:	jp     1b9610 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10790>
  1b95fc:	andpd  %xmm6,%xmm0
  1b9600:	jmp    1b96d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10850>
  1b9605:	data16 cs nopw 0x0(%rax,%rax,1)
  1b9610:	ucomisd %xmm8,%xmm0
  1b9615:	jne    1b9626 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x107a6>
  1b9617:	jp     1b9626 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x107a6>
  1b9619:	andpd  %xmm6,%xmm1
  1b961d:	movapd %xmm1,%xmm0
  1b9621:	jmp    1b96d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10850>
  1b9626:	movapd %xmm0,%xmm2
  1b962a:	andpd  %xmm6,%xmm2
  1b962e:	pshufd $0xee,%xmm2,%xmm3
  1b9633:	movapd %xmm2,%xmm4
  1b9637:	cmplesd %xmm3,%xmm4
  1b963c:	movapd %xmm4,%xmm5
  1b9640:	andpd  %xmm3,%xmm5
  1b9644:	andnpd %xmm2,%xmm4
  1b9648:	orpd   %xmm5,%xmm4
  1b964c:	movapd %xmm0,%xmm2
  1b9650:	cmpunordsd %xmm0,%xmm2
  1b9655:	movapd %xmm2,%xmm5
  1b9659:	andnpd %xmm4,%xmm5
  1b965d:	andpd  %xmm3,%xmm2
  1b9661:	orpd   %xmm5,%xmm2
  1b9665:	ucomisd %xmm7,%xmm2
  1b9669:	jbe    1b9692 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10812>
  1b966b:	movsd  0x1fde045(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b9673:	ucomisd %xmm2,%xmm3
  1b9677:	jbe    1b9692 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10812>
  1b9679:	mulpd  %xmm0,%xmm0
  1b967d:	movapd %xmm0,%xmm1
  1b9681:	unpckhpd %xmm0,%xmm1
  1b9685:	addsd  %xmm0,%xmm1
  1b9689:	xorps  %xmm0,%xmm0
  1b968c:	sqrtsd %xmm1,%xmm0
  1b9690:	jmp    1b96d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10850>
  1b9692:	call   *0x2512538(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1b9698:	xorpd  %xmm8,%xmm8
  1b969d:	movsd  0x1fde00b(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b96a5:	movapd 0x1fdc953(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b96ad:	mov    0x18(%rsp),%rsi
  1b96b2:	mov    0x10(%rsp),%rax
  1b96b7:	mov    0x1c8(%rsp),%r10
  1b96bf:	mov    0x28(%rsp),%r11
  1b96c4:	mov    0x1b0(%rsp),%r9
  1b96cc:	nopl   0x0(%rax)
  1b96d0:	add    %rax,%r14
  1b96d3:	cmp    %rbx,%r14
  1b96d6:	jae    1bdc3e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14dbe>
  1b96dc:	shl    $0x4,%r14
  1b96e0:	movsd  %xmm0,(%r15,%r14,1)
  1b96e6:	movq   $0x0,0x8(%r15,%r14,1)
  1b96ef:	add    $0x8,%r13
  1b96f3:	cmp    %r13,%rsi
  1b96f6:	jne    1b95d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10750>
  1b96fc:	cmpb   $0x0,0x20(%rsp)
  1b9701:	je     1b9819 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10999>
  1b9707:	mov    0x60(%rsp),%r13
  1b970c:	mov    0x30(%rsp),%rdx
  1b9711:	cmp    %rdx,%r13
  1b9714:	jae    1b988e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10a0e>
  1b971a:	mov    0x38(%rsp),%rax
  1b971f:	lea    (%rax,%rax,8),%rax
  1b9723:	imul   $0x6e,%rbp,%rcx
  1b9727:	imul   $0x71,%rbp,%r12
  1b972b:	mov    %r13,%r10
  1b972e:	not    %r10
  1b9731:	add    %rdx,%r10
  1b9734:	lea    (%rax,%r13,1),%r14
  1b9738:	xor    %esi,%esi
  1b973a:	mov    %rbx,%rdx
  1b973d:	sub    %r14,%rdx
  1b9740:	cmovb  %rsi,%rdx
  1b9744:	lea    (%rcx,%r13,1),%r8
  1b9748:	mov    %rbx,%rdi
  1b974b:	mov    %r8,0x38(%rsp)
  1b9750:	sub    %r8,%rdi
  1b9753:	cmovb  %rsi,%rdi
  1b9757:	cmp    %rdi,%rdx
  1b975a:	cmovb  %rdx,%rdi
  1b975e:	lea    (%r12,%r13,1),%rbp
  1b9762:	mov    %rbx,%rdx
  1b9765:	sub    %rbp,%rdx
  1b9768:	cmovb  %rsi,%rdx
  1b976c:	cmp    %rdx,%rdi
  1b976f:	cmovb  %rdi,%rdx
  1b9773:	cmp    %rdx,%r10
  1b9776:	cmovb  %r10,%rdx
  1b977a:	lea    0x1(%rdx),%rsi
  1b977e:	mov    %r13,%r11
  1b9781:	cmp    $0x4a,%rsi
  1b9785:	ja     1ba3d3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x11553>
  1b978b:	mov    (%rsp),%rbp
  1b978f:	imul   $0x710,%rbp,%rdx
  1b9796:	mov    %r11,%rsi
  1b9799:	shl    $0x4,%rsi
  1b979d:	add    %r15,%rsi
  1b97a0:	imul   $0x6e0,%rbp,%r8
  1b97a7:	mov    0x40(%rsp),%rdi
  1b97ac:	lea    (%rdi,%rdi,8),%r9
  1b97b0:	mov    0x8(%rsp),%rbx
  1b97b5:	mov    0x1c8(%rsp),%r10
  1b97bd:	nopl   (%rax)
  1b97c0:	lea    (%rax,%r11,1),%rdi
  1b97c4:	cmp    %rbx,%rdi
  1b97c7:	jae    1beccc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15e4c>
  1b97cd:	lea    (%rcx,%r11,1),%rdi
  1b97d1:	cmp    %rbx,%rdi
  1b97d4:	jae    1becbc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15e3c>
  1b97da:	lea    (%r12,%r11,1),%rdi
  1b97de:	cmp    %rbx,%rdi
  1b97e1:	jae    1becac <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15e2c>
  1b97e7:	inc    %r11
  1b97ea:	movupd (%rsi,%r9,1),%xmm0
  1b97f0:	movupd (%rsi,%r8,1),%xmm1
  1b97f6:	addpd  %xmm0,%xmm1
  1b97fa:	movupd %xmm1,(%rsi,%rdx,1)
  1b97ff:	add    $0x10,%rsi
  1b9803:	cmp    %r11,0x30(%rsp)
  1b9808:	jne    1b97c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10940>
  1b980a:	mov    0x1b0(%rsp),%r9
  1b9812:	mov    0x28(%rsp),%r11
  1b9817:	jmp    1b9887 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10a07>
  1b9819:	mov    0x38(%rsp),%rax
  1b981e:	lea    (%rax,%rax,8),%rdx
  1b9822:	imul   $0x6e,%rbp,%rsi
  1b9826:	imul   $0x71,%rbp,%r12
  1b982a:	xor    %r8d,%r8d
  1b982d:	nopl   (%rax)
  1b9830:	mov    (%r11,%r8,1),%rdi
  1b9834:	lea    (%rdi,%rdx,1),%rax
  1b9838:	cmp    %rbx,%rax
  1b983b:	jae    1be4c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15640>
  1b9841:	lea    (%rdi,%rsi,1),%rcx
  1b9845:	cmp    %rbx,%rcx
  1b9848:	jae    1be4ad <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1562d>
  1b984e:	add    %r12,%rdi
  1b9851:	cmp    %rbx,%rdi
  1b9854:	jae    1be49d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1561d>
  1b985a:	shl    $0x4,%rax
  1b985e:	shl    $0x4,%rcx
  1b9862:	shl    $0x4,%rdi
  1b9866:	movupd (%r15,%rax,1),%xmm0
  1b986c:	movupd (%r15,%rcx,1),%xmm1
  1b9872:	addpd  %xmm0,%xmm1
  1b9876:	movupd %xmm1,(%r15,%rdi,1)
  1b987c:	add    $0x8,%r8
  1b9880:	cmp    %r8,0x18(%rsp)
  1b9885:	jne    1b9830 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x109b0>
  1b9887:	mov    0x18(%rsp),%rsi
  1b988c:	jmp    1b9892 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10a12>
  1b988e:	imul   $0x71,%rbp,%r12
  1b9892:	imul   $0x72,%rbp,%r14
  1b9896:	xor    %ebp,%ebp
  1b9898:	xorpd  %xmm8,%xmm8
  1b989d:	nopl   (%rax)
  1b98a0:	mov    (%r11,%rbp,1),%r13
  1b98a4:	lea    (%r12,%r13,1),%rdi
  1b98a8:	cmp    %rbx,%rdi
  1b98ab:	jae    1bdc74 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14df4>
  1b98b1:	shl    $0x4,%rdi
  1b98b5:	movupd (%r15,%rdi,1),%xmm0
  1b98bb:	movapd %xmm0,%xmm1
  1b98bf:	unpckhpd %xmm0,%xmm1
  1b98c3:	ucomisd %xmm8,%xmm1
  1b98c8:	jne    1b98e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10a60>
  1b98ca:	jp     1b98e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10a60>
  1b98cc:	andpd  %xmm6,%xmm0
  1b98d0:	jmp    1b99a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10b20>
  1b98d5:	data16 cs nopw 0x0(%rax,%rax,1)
  1b98e0:	ucomisd %xmm8,%xmm0
  1b98e5:	jne    1b98f6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10a76>
  1b98e7:	jp     1b98f6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10a76>
  1b98e9:	andpd  %xmm6,%xmm1
  1b98ed:	movapd %xmm1,%xmm0
  1b98f1:	jmp    1b99a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10b20>
  1b98f6:	movapd %xmm0,%xmm2
  1b98fa:	andpd  %xmm6,%xmm2
  1b98fe:	pshufd $0xee,%xmm2,%xmm3
  1b9903:	movapd %xmm2,%xmm4
  1b9907:	cmplesd %xmm3,%xmm4
  1b990c:	movapd %xmm4,%xmm5
  1b9910:	andpd  %xmm3,%xmm5
  1b9914:	andnpd %xmm2,%xmm4
  1b9918:	orpd   %xmm5,%xmm4
  1b991c:	movapd %xmm0,%xmm2
  1b9920:	cmpunordsd %xmm0,%xmm2
  1b9925:	movapd %xmm2,%xmm5
  1b9929:	andnpd %xmm4,%xmm5
  1b992d:	andpd  %xmm3,%xmm2
  1b9931:	orpd   %xmm5,%xmm2
  1b9935:	ucomisd %xmm7,%xmm2
  1b9939:	jbe    1b9962 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10ae2>
  1b993b:	movsd  0x1fddd75(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1b9943:	ucomisd %xmm2,%xmm3
  1b9947:	jbe    1b9962 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10ae2>
  1b9949:	mulpd  %xmm0,%xmm0
  1b994d:	movapd %xmm0,%xmm1
  1b9951:	unpckhpd %xmm0,%xmm1
  1b9955:	addsd  %xmm0,%xmm1
  1b9959:	xorps  %xmm0,%xmm0
  1b995c:	sqrtsd %xmm1,%xmm0
  1b9960:	jmp    1b99a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10b20>
  1b9962:	call   *0x2512268(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1b9968:	xorpd  %xmm8,%xmm8
  1b996d:	movsd  0x1fddd3b(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1b9975:	movapd 0x1fdc683(%rip),%xmm6        # 2196000 <_fini+0x520>
  1b997d:	mov    0x18(%rsp),%rsi
  1b9982:	mov    0x1c8(%rsp),%r10
  1b998a:	mov    0x28(%rsp),%r11
  1b998f:	mov    0x1b0(%rsp),%r9
  1b9997:	nopw   0x0(%rax,%rax,1)
  1b99a0:	add    %r14,%r13
  1b99a3:	cmp    %rbx,%r13
  1b99a6:	jae    1bdc61 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14de1>
  1b99ac:	shl    $0x4,%r13
  1b99b0:	movsd  %xmm0,(%r15,%r13,1)
  1b99b6:	movq   $0x0,0x8(%r15,%r13,1)
  1b99bf:	add    $0x8,%rbp
  1b99c3:	cmp    %rbp,%rsi
  1b99c6:	jne    1b98a0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10a20>
  1b99cc:	cmpb   $0x0,0x20(%rsp)
  1b99d1:	je     1b9b01 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10c81>
  1b99d7:	mov    0x60(%rsp),%r12
  1b99dc:	cmp    0x30(%rsp),%r12
  1b99e1:	mov    (%rsp),%rbp
  1b99e5:	mov    0x50(%rsp),%r13
  1b99ea:	jae    1b9ba8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10d28>
  1b99f0:	cmpq   $0x2,0x1e0(%rsp)
  1b99f9:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b99ff:	imul   $0x73,%rbp,%rdi
  1b9a03:	mov    %r12,%r9
  1b9a06:	not    %r9
  1b9a09:	add    0x30(%rsp),%r9
  1b9a0e:	lea    (%r12,%r14,1),%r10
  1b9a12:	xor    %ecx,%ecx
  1b9a14:	mov    %rbx,%rdx
  1b9a17:	sub    %r10,%rdx
  1b9a1a:	cmovb  %rcx,%rdx
  1b9a1e:	lea    (%r12,%rdi,1),%r11
  1b9a22:	mov    %rbx,%rax
  1b9a25:	sub    %r11,%rax
  1b9a28:	cmovb  %rcx,%rax
  1b9a2c:	cmp    %rax,%rdx
  1b9a2f:	cmovb  %rdx,%rax
  1b9a33:	cmp    %rax,%r9
  1b9a36:	cmovb  %r9,%rax
  1b9a3a:	lea    0x1(%rax),%rcx
  1b9a3e:	mov    %r12,%r8
  1b9a41:	cmp    $0x22,%rcx
  1b9a45:	mov    %r12,0x60(%rsp)
  1b9a4a:	ja     1ba753 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x118d3>
  1b9a50:	add    %r8,%rdi
  1b9a53:	imul   $0x730,%rbp,%rax
  1b9a5a:	mov    %r8,%rcx
  1b9a5d:	shl    $0x4,%rcx
  1b9a61:	add    %r15,%rcx
  1b9a64:	add    %r8,%r14
  1b9a67:	imul   $0x720,%rbp,%rdx
  1b9a6e:	mov    0x30(%rsp),%rsi
  1b9a73:	sub    %r8,%rsi
  1b9a76:	mov    0x1d8(%rsp),%r8
  1b9a7e:	mov    0x1b0(%rsp),%r9
  1b9a86:	mov    0x28(%rsp),%r11
  1b9a8b:	mov    0x1c8(%rsp),%r10
  1b9a93:	mov    0x60(%rsp),%r12
  1b9a98:	nopl   0x0(%rax,%rax,1)
  1b9aa0:	cmp    %rbx,%r14
  1b9aa3:	jae    1becec <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15e6c>
  1b9aa9:	cmp    %rbx,%rdi
  1b9aac:	jae    1becdc <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15e5c>
  1b9ab2:	movupd 0x10(%r8),%xmm0
  1b9ab8:	movsd  (%rcx,%rdx,1),%xmm1
  1b9abd:	movsd  0x8(%rcx,%rdx,1),%xmm2
  1b9ac3:	unpcklpd %xmm1,%xmm1
  1b9ac7:	mulpd  %xmm0,%xmm1
  1b9acb:	shufpd $0x1,%xmm0,%xmm0
  1b9ad0:	unpcklpd %xmm2,%xmm2
  1b9ad4:	mulpd  %xmm0,%xmm2
  1b9ad8:	movapd %xmm1,%xmm0
  1b9adc:	subpd  %xmm2,%xmm0
  1b9ae0:	addpd  %xmm1,%xmm2
  1b9ae4:	movsd  %xmm0,%xmm2
  1b9ae8:	movupd %xmm2,(%rcx,%rax,1)
  1b9aed:	inc    %rdi
  1b9af0:	add    $0x10,%rcx
  1b9af4:	inc    %r14
  1b9af7:	dec    %rsi
  1b9afa:	jne    1b9aa0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10c20>
  1b9afc:	jmp    1b9b9d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10d1d>
  1b9b01:	cmpq   $0x2,0x1e0(%rsp)
  1b9b0a:	mov    (%rsp),%rbp
  1b9b0e:	mov    0x1d8(%rsp),%rsi
  1b9b16:	mov    0x50(%rsp),%r13
  1b9b1b:	mov    0x60(%rsp),%r12
  1b9b20:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1b9b26:	imul   $0x73,%rbp,%rcx
  1b9b2a:	xor    %edx,%edx
  1b9b2c:	nopl   0x0(%rax)
  1b9b30:	mov    (%r11,%rdx,1),%rdi
  1b9b34:	lea    (%rdi,%r14,1),%rax
  1b9b38:	cmp    %rbx,%rax
  1b9b3b:	jae    1be4e3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15663>
  1b9b41:	add    %rcx,%rdi
  1b9b44:	cmp    %rbx,%rdi
  1b9b47:	jae    1be4d3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15653>
  1b9b4d:	shl    $0x4,%rax
  1b9b51:	shl    $0x4,%rdi
  1b9b55:	movupd 0x10(%rsi),%xmm0
  1b9b5a:	movsd  (%r15,%rax,1),%xmm1
  1b9b60:	movsd  0x8(%r15,%rax,1),%xmm2
  1b9b67:	unpcklpd %xmm1,%xmm1
  1b9b6b:	mulpd  %xmm0,%xmm1
  1b9b6f:	shufpd $0x1,%xmm0,%xmm0
  1b9b74:	unpcklpd %xmm2,%xmm2
  1b9b78:	mulpd  %xmm0,%xmm2
  1b9b7c:	movapd %xmm1,%xmm0
  1b9b80:	subpd  %xmm2,%xmm0
  1b9b84:	addpd  %xmm1,%xmm2
  1b9b88:	movsd  %xmm0,%xmm2
  1b9b8c:	movupd %xmm2,(%r15,%rdi,1)
  1b9b92:	add    $0x8,%rdx
  1b9b96:	cmp    %rdx,0x18(%rsp)
  1b9b9b:	jne    1b9b30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10cb0>
  1b9b9d:	cmpb   $0x0,0x20(%rsp)
  1b9ba2:	je     1b9c30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10db0>
  1b9ba8:	mov    0x30(%rsp),%rcx
  1b9bad:	cmp    %rcx,%r12
  1b9bb0:	jae    1b9ca0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10e20>
  1b9bb6:	imul   $0x73,%rbp,%rax
  1b9bba:	imul   $0x74,%rbp,%rdx
  1b9bbe:	mov    %r12,%r10
  1b9bc1:	not    %r10
  1b9bc4:	add    %rcx,%r10
  1b9bc7:	mov    0x10(%rsp),%rcx
  1b9bcc:	lea    (%r12,%rcx,1),%r11
  1b9bd0:	xor    %esi,%esi
  1b9bd2:	mov    %rbx,%rcx
  1b9bd5:	sub    %r11,%rcx
  1b9bd8:	cmovb  %rsi,%rcx
  1b9bdc:	lea    (%r12,%rax,1),%r9
  1b9be0:	mov    %rbx,%rdi
  1b9be3:	sub    %r9,%rdi
  1b9be6:	cmovb  %rsi,%rdi
  1b9bea:	cmp    %rdi,%rcx
  1b9bed:	cmovb  %rcx,%rdi
  1b9bf1:	lea    (%r12,%rdx,1),%r14
  1b9bf5:	mov    %rbx,%rcx
  1b9bf8:	sub    %r14,%rcx
  1b9bfb:	cmovb  %rsi,%rcx
  1b9bff:	cmp    %rcx,%rdi
  1b9c02:	cmovb  %rdi,%rcx
  1b9c06:	cmp    %rcx,%r10
  1b9c09:	cmovb  %r10,%rcx
  1b9c0d:	lea    0x1(%rcx),%rsi
  1b9c11:	cmp    $0x4a,%rsi
  1b9c15:	ja     1ba088 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x11208>
  1b9c1b:	mov    0x28(%rsp),%r11
  1b9c20:	mov    0x1c8(%rsp),%r10
  1b9c28:	mov    %r12,%r14
  1b9c2b:	jmp    1bafde <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1215e>
  1b9c30:	imul   $0x73,%rbp,%rsi
  1b9c34:	imul   $0x74,%rbp,%rdx
  1b9c38:	xor    %r8d,%r8d
  1b9c3b:	nopl   0x0(%rax,%rax,1)
  1b9c40:	mov    (%r11,%r8,1),%rdi
  1b9c44:	mov    0x10(%rsp),%rax
  1b9c49:	add    %rdi,%rax
  1b9c4c:	cmp    %rbx,%rax
  1b9c4f:	jae    1be925 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15aa5>
  1b9c55:	lea    (%rdi,%rsi,1),%rcx
  1b9c59:	cmp    %rbx,%rcx
  1b9c5c:	jae    1be912 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15a92>
  1b9c62:	add    %rdx,%rdi
  1b9c65:	cmp    %rbx,%rdi
  1b9c68:	jae    1be902 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15a82>
  1b9c6e:	shl    $0x4,%rax
  1b9c72:	shl    $0x4,%rcx
  1b9c76:	shl    $0x4,%rdi
  1b9c7a:	movupd (%r15,%rax,1),%xmm0
  1b9c80:	movupd (%r15,%rcx,1),%xmm1
  1b9c86:	addpd  %xmm0,%xmm1
  1b9c8a:	movupd %xmm1,(%r15,%rdi,1)
  1b9c90:	add    $0x8,%r8
  1b9c94:	cmp    %r8,0x18(%rsp)
  1b9c99:	jne    1b9c40 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10dc0>
  1b9c9b:	jmp    1bb064 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x121e4>
  1b9ca0:	imul   $0x74,%rbp,%rdx
  1b9ca4:	jmp    1bb064 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x121e4>
  1b9ca9:	xor    %esi,%esi
  1b9cab:	mov    %rbx,%rdi
  1b9cae:	sub    %r12,%rdi
  1b9cb1:	cmovb  %rsi,%rdi
  1b9cb5:	mov    %rbx,%r8
  1b9cb8:	sub    %r11,%r8
  1b9cbb:	cmovb  %rsi,%r8
  1b9cbf:	cmp    %r8,%rdi
  1b9cc2:	cmovb  %rdi,%r8
  1b9cc6:	mov    %rbx,%r9
  1b9cc9:	sub    %r13,%r9
  1b9ccc:	cmovb  %rsi,%r9
  1b9cd0:	cmp    %r9,%r8
  1b9cd3:	cmovb  %r8,%r9
  1b9cd7:	cmp    %r14,%r9
  1b9cda:	cmovae %r14,%r9
  1b9cde:	mov    (%rsp),%rsi
  1b9ce2:	shl    $0x5,%rsi
  1b9ce6:	mov    0x30(%rsp),%r10
  1b9ceb:	mov    %r10,%rdi
  1b9cee:	shl    $0x4,%rdi
  1b9cf2:	lea    (%r15,%rsi,1),%r8
  1b9cf6:	lea    (%rdi,%r8,1),%rbx
  1b9cfa:	add    $0x8,%rbx
  1b9cfe:	add    %rdi,%r8
  1b9d01:	mov    %r9,%rbp
  1b9d04:	shl    $0x4,%rbp
  1b9d08:	add    %rbp,%r8
  1b9d0b:	add    $0x8,%r8
  1b9d0f:	cmp    %rbx,%r8
  1b9d12:	mov    0x8(%rsp),%rbx
  1b9d17:	jb     1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9d1d:	imul   $0x690,(%rsp),%r8
  1b9d25:	lea    (%r15,%r8,1),%r10
  1b9d29:	lea    (%rdi,%r10,1),%rbx
  1b9d2d:	add    $0x8,%rbx
  1b9d31:	add    %rdi,%r10
  1b9d34:	add    %r10,%rbp
  1b9d37:	add    $0x8,%rbp
  1b9d3b:	mov    0x30(%rsp),%r10
  1b9d40:	cmp    %rbx,%rbp
  1b9d43:	mov    0x8(%rsp),%rbx
  1b9d48:	jb     1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9d4e:	mov    0x30(%rsp),%r10
  1b9d53:	movabs $0xfffffffffffffff,%rbp
  1b9d5d:	cmp    %rbp,%r9
  1b9d60:	ja     1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9d66:	imul   $0x6a0,(%rsp),%r9
  1b9d6e:	xor    %r10d,%r10d
  1b9d71:	mov    0x8(%rsp),%rbx
  1b9d76:	sub    %r12,%rbx
  1b9d79:	cmovb  %r10,%rbx
  1b9d7d:	mov    0x8(%rsp),%r12
  1b9d82:	sub    %r11,%r12
  1b9d85:	cmovb  %r10,%r12
  1b9d89:	cmp    %r12,%rbx
  1b9d8c:	cmovb  %rbx,%r12
  1b9d90:	mov    0x8(%rsp),%rbx
  1b9d95:	sub    %r13,%rbx
  1b9d98:	cmovb  %r10,%rbx
  1b9d9c:	lea    (%r9,%rdi,1),%r13
  1b9da0:	cmp    %rbx,%r12
  1b9da3:	cmovb  %r12,%rbx
  1b9da7:	lea    (%r15,%r13,1),%r11
  1b9dab:	cmp    %r14,%rbx
  1b9dae:	cmovae %r14,%rbx
  1b9db2:	shl    $0x4,%rbx
  1b9db6:	lea    (%rbx,%r11,1),%r10
  1b9dba:	add    $0x8,%r10
  1b9dbe:	lea    0x8(%r15,%r13,1),%r13
  1b9dc3:	lea    0x10(%rbx,%r11,1),%r14
  1b9dc8:	lea    (%rsi,%rdi,1),%rbp
  1b9dcc:	lea    (%r15,%rbp,1),%r12
  1b9dd0:	lea    0x8(%r15,%rbp,1),%rbp
  1b9dd5:	mov    %rbp,0x50(%rsp)
  1b9dda:	mov    %r12,0xd0(%rsp)
  1b9de2:	lea    0x10(%rbx,%r12,1),%rbp
  1b9de7:	mov    %rbp,0x40(%rsp)
  1b9dec:	lea    0x8(%rbx,%r12,1),%rbp
  1b9df1:	mov    %rbp,0x38(%rsp)
  1b9df6:	lea    (%r8,%rdi,1),%r12
  1b9dfa:	mov    %r12,0xb0(%rsp)
  1b9e02:	lea    (%r15,%r12,1),%rbp
  1b9e06:	lea    0x8(%rbx,%rbp,1),%r12
  1b9e0b:	mov    %r12,0x20(%rsp)
  1b9e10:	add    %rbp,%rbx
  1b9e13:	add    $0x10,%rbx
  1b9e17:	mov    %rbx,0x10(%rsp)
  1b9e1c:	mov    0x8(%rsp),%rbx
  1b9e21:	cmp    %r14,%r11
  1b9e24:	setb   0x48(%rsp)
  1b9e29:	cmp    %r10,%r13
  1b9e2c:	setb   0x100(%rsp)
  1b9e34:	cmp    0x40(%rsp),%r11
  1b9e39:	setb   0xe0(%rsp)
  1b9e41:	cmp    %r10,0x50(%rsp)
  1b9e46:	setb   0x58(%rsp)
  1b9e4b:	cmp    0x38(%rsp),%r11
  1b9e50:	setb   0x88(%rsp)
  1b9e58:	mov    0xd0(%rsp),%r12
  1b9e60:	cmp    %r10,%r12
  1b9e63:	setb   0x78(%rsp)
  1b9e68:	cmp    0x20(%rsp),%r11
  1b9e6d:	setb   0x80(%rsp)
  1b9e75:	cmp    %r10,%rbp
  1b9e78:	setb   0x98(%rsp)
  1b9e80:	cmp    0x10(%rsp),%r11
  1b9e85:	mov    0xb0(%rsp),%r11
  1b9e8d:	lea    0x8(%r15,%r11,1),%r11
  1b9e92:	setb   0xb0(%rsp)
  1b9e9a:	cmp    %r10,%r11
  1b9e9d:	setb   0xc8(%rsp)
  1b9ea5:	cmp    0x40(%rsp),%r13
  1b9eaa:	setb   0x40(%rsp)
  1b9eaf:	cmp    %r14,0x50(%rsp)
  1b9eb4:	setb   0x50(%rsp)
  1b9eb9:	cmp    0x38(%rsp),%r13
  1b9ebe:	setb   0x38(%rsp)
  1b9ec3:	cmp    %r14,%r12
  1b9ec6:	setb   0xd0(%rsp)
  1b9ece:	cmp    0x20(%rsp),%r13
  1b9ed3:	setb   %r12b
  1b9ed7:	cmp    %r14,%rbp
  1b9eda:	setb   0x20(%rsp)
  1b9edf:	cmp    0x10(%rsp),%r13
  1b9ee4:	setb   %bpl
  1b9ee8:	cmp    %r14,%r11
  1b9eeb:	mov    0x30(%rsp),%r10
  1b9ef0:	setb   %r11b
  1b9ef4:	movzbl 0x100(%rsp),%r14d
  1b9efd:	test   %r14b,0x48(%rsp)
  1b9f02:	jne    1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9f08:	mov    0x30(%rsp),%r10
  1b9f0d:	movzbl 0x58(%rsp),%r14d
  1b9f13:	and    %r14b,0xe0(%rsp)
  1b9f1b:	jne    1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9f21:	mov    0x30(%rsp),%r10
  1b9f26:	movzbl 0x78(%rsp),%r14d
  1b9f2c:	and    %r14b,0x88(%rsp)
  1b9f34:	jne    1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9f3a:	mov    0x30(%rsp),%r10
  1b9f3f:	movzbl 0x98(%rsp),%r14d
  1b9f48:	and    %r14b,0x80(%rsp)
  1b9f50:	jne    1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9f56:	mov    0x30(%rsp),%r10
  1b9f5b:	movzbl 0xc8(%rsp),%r14d
  1b9f64:	and    %r14b,0xb0(%rsp)
  1b9f6c:	jne    1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9f72:	mov    0x30(%rsp),%r10
  1b9f77:	movzbl 0x50(%rsp),%r14d
  1b9f7d:	and    %r14b,0x40(%rsp)
  1b9f82:	jne    1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9f88:	mov    0x30(%rsp),%r10
  1b9f8d:	movzbl 0xd0(%rsp),%r14d
  1b9f96:	and    %r14b,0x38(%rsp)
  1b9f9b:	jne    1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9fa1:	mov    0x30(%rsp),%r10
  1b9fa6:	and    0x20(%rsp),%r12b
  1b9fab:	jne    1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9fb1:	mov    0x30(%rsp),%r10
  1b9fb6:	and    %r11b,%bpl
  1b9fb9:	jne    1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1b9fbf:	and    $0xfffffffffffffffe,%rdx
  1b9fc3:	mov    0x30(%rsp),%r10
  1b9fc8:	add    %rdx,%r10
  1b9fcb:	mov    0x1d8(%rsp),%r11
  1b9fd3:	movsd  (%r11),%xmm0
  1b9fd8:	movsd  0x8(%r11),%xmm1
  1b9fde:	unpcklpd %xmm0,%xmm0
  1b9fe2:	unpcklpd %xmm1,%xmm1
  1b9fe6:	add    %r15,%rdi
  1b9fe9:	nopl   0x0(%rax)
  1b9ff0:	movupd (%rdi,%rsi,1),%xmm2
  1b9ff5:	movupd 0x10(%rdi,%rsi,1),%xmm3
  1b9ffb:	movapd %xmm2,%xmm4
  1b9fff:	unpcklpd %xmm3,%xmm4
  1ba003:	unpckhpd %xmm3,%xmm2
  1ba007:	movapd %xmm2,%xmm3
  1ba00b:	mulpd  %xmm0,%xmm3
  1ba00f:	movapd %xmm0,%xmm5
  1ba013:	mulpd  %xmm4,%xmm5
  1ba017:	mulpd  %xmm1,%xmm4
  1ba01b:	addpd  %xmm3,%xmm4
  1ba01f:	movupd (%rdi,%r8,1),%xmm3
  1ba025:	movupd 0x10(%rdi,%r8,1),%xmm6
  1ba02c:	movapd %xmm3,%xmm7
  1ba030:	unpcklpd %xmm6,%xmm7
  1ba034:	unpckhpd %xmm6,%xmm3
  1ba038:	movapd %xmm7,%xmm6
  1ba03c:	mulpd  %xmm4,%xmm6
  1ba040:	mulpd  %xmm1,%xmm2
  1ba044:	subpd  %xmm2,%xmm5
  1ba048:	mulpd  %xmm5,%xmm7
  1ba04c:	mulpd  %xmm3,%xmm5
  1ba050:	addpd  %xmm6,%xmm5
  1ba054:	mulpd  %xmm4,%xmm3
  1ba058:	subpd  %xmm3,%xmm7
  1ba05c:	movapd %xmm7,%xmm2
  1ba060:	unpcklpd %xmm5,%xmm2
  1ba064:	unpckhpd %xmm5,%xmm7
  1ba068:	movupd %xmm7,0x10(%rdi,%r9,1)
  1ba06f:	movupd %xmm2,(%rdi,%r9,1)
  1ba075:	add    $0x20,%rdi
  1ba079:	add    $0xfffffffffffffffe,%rdx
  1ba07d:	jne    1b9ff0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x11170>
  1ba083:	jmp    1b8e36 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xffb6>
  1ba088:	xor    %esi,%esi
  1ba08a:	mov    %rbx,%rdi
  1ba08d:	sub    %r11,%rdi
  1ba090:	cmovb  %rsi,%rdi
  1ba094:	mov    %rbx,%r8
  1ba097:	mov    %r9,0x18(%rsp)
  1ba09c:	sub    %r9,%r8
  1ba09f:	cmovb  %rsi,%r8
  1ba0a3:	cmp    %r8,%rdi
  1ba0a6:	cmovb  %rdi,%r8
  1ba0aa:	mov    %rbx,%r9
  1ba0ad:	sub    %r14,%r9
  1ba0b0:	cmovb  %rsi,%r9
  1ba0b4:	cmp    %r9,%r8
  1ba0b7:	cmovb  %r8,%r9
  1ba0bb:	cmp    %r9,%r10
  1ba0be:	cmovb  %r10,%r9
  1ba0c2:	imul   $0x700,%rbp,%rsi
  1ba0c9:	mov    %r12,%rdi
  1ba0cc:	shl    $0x4,%rdi
  1ba0d0:	lea    (%r15,%rsi,1),%r8
  1ba0d4:	lea    (%rdi,%r8,1),%rbx
  1ba0d8:	add    $0x8,%rbx
  1ba0dc:	add    %rdi,%r8
  1ba0df:	mov    %r9,%r13
  1ba0e2:	shl    $0x4,%r13
  1ba0e6:	add    %r13,%r8
  1ba0e9:	add    $0x8,%r8
  1ba0ed:	cmp    %rbx,%r8
  1ba0f0:	jb     1bafa4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12124>
  1ba0f6:	imul   $0x730,%rbp,%r8
  1ba0fd:	lea    (%r15,%r8,1),%rbx
  1ba101:	lea    (%rdi,%rbx,1),%rbp
  1ba105:	add    $0x8,%rbp
  1ba109:	add    %rdi,%rbx
  1ba10c:	add    %r13,%rbx
  1ba10f:	add    $0x8,%rbx
  1ba113:	cmp    %rbp,%rbx
  1ba116:	jb     1bafab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1212b>
  1ba11c:	movabs $0xfffffffffffffff,%rbx
  1ba126:	cmp    %rbx,%r9
  1ba129:	mov    0x8(%rsp),%rbx
  1ba12e:	ja     1bafb0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12130>
  1ba134:	imul   $0x740,(%rsp),%r9
  1ba13c:	xor    %ebp,%ebp
  1ba13e:	mov    %rbx,%r13
  1ba141:	sub    %r11,%r13
  1ba144:	cmovb  %rbp,%r13
  1ba148:	mov    %rbx,%r11
  1ba14b:	sub    0x18(%rsp),%r11
  1ba150:	cmovb  %rbp,%r11
  1ba154:	cmp    %r11,%r13
  1ba157:	cmovb  %r13,%r11
  1ba15b:	sub    %r14,%rbx
  1ba15e:	cmovb  %rbp,%rbx
  1ba162:	cmp    %rbx,%r11
  1ba165:	cmovb  %r11,%rbx
  1ba169:	mov    %r9,0x130(%rsp)
  1ba171:	lea    (%r9,%rdi,1),%r14
  1ba175:	cmp    %rbx,%r10
  1ba178:	cmovb  %r10,%rbx
  1ba17c:	lea    (%r15,%r14,1),%rbp
  1ba180:	shl    $0x4,%rbx
  1ba184:	lea    (%rbx,%rbp,1),%r11
  1ba188:	add    $0x8,%r11
  1ba18c:	lea    0x8(%r15,%r14,1),%r13
  1ba191:	lea    0x10(%rbx,%rbp,1),%r9
  1ba196:	mov    %r9,0xe0(%rsp)
  1ba19e:	lea    (%rsi,%rdi,1),%r12
  1ba1a2:	lea    (%r15,%r12,1),%r14
  1ba1a6:	lea    0x8(%r15,%r12,1),%r12
  1ba1ab:	mov    %r12,0x18(%rsp)
  1ba1b0:	lea    0x10(%rbx,%r14,1),%r12
  1ba1b5:	mov    %r14,0xb0(%rsp)
  1ba1bd:	lea    (%r8,%rdi,1),%r10
  1ba1c1:	lea    (%r15,%r10,1),%r9
  1ba1c5:	mov    %r9,0x38(%rsp)
  1ba1ca:	lea    0x8(%r15,%r10,1),%r9
  1ba1cf:	mov    %r9,0x40(%rsp)
  1ba1d4:	mov    0x38(%rsp),%r9
  1ba1d9:	lea    0x10(%rbx,%r9,1),%r10
  1ba1de:	mov    %r10,0x58(%rsp)
  1ba1e3:	lea    0x8(%rbx,%r14,1),%r14
  1ba1e8:	mov    %r14,0xd0(%rsp)
  1ba1f0:	add    %r9,%rbx
  1ba1f3:	add    $0x8,%rbx
  1ba1f7:	mov    %rbx,0x20(%rsp)
  1ba1fc:	mov    0xe0(%rsp),%r14
  1ba204:	cmp    %r14,%rbp
  1ba207:	setb   0x48(%rsp)
  1ba20c:	cmp    %r11,%r13
  1ba20f:	setb   0x100(%rsp)
  1ba217:	cmp    %r12,%rbp
  1ba21a:	setb   0x88(%rsp)
  1ba222:	cmp    %r11,0x18(%rsp)
  1ba227:	setb   0x78(%rsp)
  1ba22c:	mov    0x58(%rsp),%r9
  1ba231:	cmp    %r9,%rbp
  1ba234:	setb   0x80(%rsp)
  1ba23c:	cmp    %r11,0x40(%rsp)
  1ba241:	setb   0x98(%rsp)
  1ba249:	mov    0xd0(%rsp),%r10
  1ba251:	cmp    %r10,%rbp
  1ba254:	setb   0xc8(%rsp)
  1ba25c:	mov    0xb0(%rsp),%rbx
  1ba264:	cmp    %r11,%rbx
  1ba267:	setb   0xa8(%rsp)
  1ba26f:	cmp    0x20(%rsp),%rbp
  1ba274:	setb   0xf8(%rsp)
  1ba27c:	mov    0x38(%rsp),%rbp
  1ba281:	cmp    %r11,%rbp
  1ba284:	setb   0x118(%rsp)
  1ba28c:	cmp    %r12,%r13
  1ba28f:	setb   0x120(%rsp)
  1ba297:	cmp    %r14,0x18(%rsp)
  1ba29c:	setb   0x18(%rsp)
  1ba2a1:	cmp    %r9,%r13
  1ba2a4:	setb   0x58(%rsp)
  1ba2a9:	cmp    %r14,0x40(%rsp)
  1ba2ae:	setb   0x40(%rsp)
  1ba2b3:	cmp    %r10,%r13
  1ba2b6:	setb   0xd0(%rsp)
  1ba2be:	cmp    %r14,%rbx
  1ba2c1:	setb   %r9b
  1ba2c5:	cmp    0x20(%rsp),%r13
  1ba2ca:	setb   %r11b
  1ba2ce:	cmp    %r14,%rbp
  1ba2d1:	setb   %r10b
  1ba2d5:	movzbl 0x100(%rsp),%ebx
  1ba2dd:	test   %bl,0x48(%rsp)
  1ba2e1:	jne    1bafab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1212b>
  1ba2e7:	movzbl 0x78(%rsp),%ebx
  1ba2ec:	and    %bl,0x88(%rsp)
  1ba2f3:	jne    1bafab <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1212b>
  1ba2f9:	movzbl 0x98(%rsp),%ebx
  1ba301:	and    %bl,0x80(%rsp)
  1ba308:	mov    0x8(%rsp),%rbx
  1ba30d:	mov    0x50(%rsp),%r13
  1ba312:	mov    0x60(%rsp),%r14
  1ba317:	jne    1bafcd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1214d>
  1ba31d:	movzbl 0xa8(%rsp),%r12d
  1ba326:	and    %r12b,0xc8(%rsp)
  1ba32e:	jne    1bafcd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1214d>
  1ba334:	movzbl 0x118(%rsp),%r12d
  1ba33d:	and    %r12b,0xf8(%rsp)
  1ba345:	jne    1bafcd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1214d>
  1ba34b:	movzbl 0x18(%rsp),%r12d
  1ba351:	and    %r12b,0x120(%rsp)
  1ba359:	jne    1bafcd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1214d>
  1ba35f:	movzbl 0x40(%rsp),%r12d
  1ba365:	and    %r12b,0x58(%rsp)
  1ba36a:	jne    1bafcd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1214d>
  1ba370:	and    %r9b,0xd0(%rsp)
  1ba378:	jne    1bafcd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1214d>
  1ba37e:	and    %r10b,%r11b
  1ba381:	mov    (%rsp),%rbp
  1ba385:	jne    1bafd1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12151>
  1ba38b:	and    $0xfffffffffffffffe,%rcx
  1ba38f:	add    %rcx,%r14
  1ba392:	add    %r15,%rdi
  1ba395:	mov    0x28(%rsp),%r11
  1ba39a:	mov    0x1c8(%rsp),%r10
  1ba3a2:	mov    0x130(%rsp),%r9
  1ba3aa:	nopw   0x0(%rax,%rax,1)
  1ba3b0:	movupd (%rdi,%rsi,1),%xmm0
  1ba3b5:	movupd (%rdi,%r8,1),%xmm1
  1ba3bb:	addpd  %xmm0,%xmm1
  1ba3bf:	movupd %xmm1,(%rdi,%r9,1)
  1ba3c5:	add    $0x10,%rdi
  1ba3c9:	dec    %rcx
  1ba3cc:	jne    1ba3b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x11530>
  1ba3ce:	jmp    1bafde <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1215e>
  1ba3d3:	xor    %esi,%esi
  1ba3d5:	mov    0x8(%rsp),%r9
  1ba3da:	mov    %r9,%rdi
  1ba3dd:	sub    %r14,%rdi
  1ba3e0:	cmovb  %rsi,%rdi
  1ba3e4:	mov    %r9,%r8
  1ba3e7:	sub    0x38(%rsp),%r8
  1ba3ec:	cmovb  %rsi,%r8
  1ba3f0:	cmp    %r8,%rdi
  1ba3f3:	cmovb  %rdi,%r8
  1ba3f7:	sub    %rbp,%r9
  1ba3fa:	cmovb  %rsi,%r9
  1ba3fe:	cmp    %r9,%r8
  1ba401:	cmovb  %r8,%r9
  1ba405:	cmp    %r9,%r10
  1ba408:	cmovb  %r10,%r9
  1ba40c:	mov    0x40(%rsp),%rsi
  1ba411:	lea    (%rsi,%rsi,8),%rsi
  1ba415:	mov    %r13,%rdi
  1ba418:	shl    $0x4,%rdi
  1ba41c:	mov    %rsi,0xd0(%rsp)
  1ba424:	lea    (%r15,%rsi,1),%r8
  1ba428:	lea    (%rdi,%r8,1),%rbx
  1ba42c:	add    $0x8,%rbx
  1ba430:	add    %rdi,%r8
  1ba433:	mov    %r9,%rsi
  1ba436:	shl    $0x4,%rsi
  1ba43a:	add    %rsi,%r8
  1ba43d:	add    $0x8,%r8
  1ba441:	mov    %r13,%r11
  1ba444:	cmp    %rbx,%r8
  1ba447:	jb     1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba44d:	imul   $0x6e0,(%rsp),%r8
  1ba455:	lea    (%r15,%r8,1),%r11
  1ba459:	lea    (%rdi,%r11,1),%rbx
  1ba45d:	add    $0x8,%rbx
  1ba461:	add    %rdi,%r11
  1ba464:	add    %r11,%rsi
  1ba467:	add    $0x8,%rsi
  1ba46b:	mov    %r13,%r11
  1ba46e:	cmp    %rbx,%rsi
  1ba471:	jb     1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba477:	mov    %r13,%r11
  1ba47a:	movabs $0xfffffffffffffff,%rsi
  1ba484:	cmp    %rsi,%r9
  1ba487:	ja     1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba48d:	mov    (%rsp),%rbx
  1ba491:	imul   $0x710,%rbx,%rsi
  1ba498:	mov    %rsi,0x148(%rsp)
  1ba4a0:	lea    (%rsi,%rdi,1),%r9
  1ba4a4:	xor    %r11d,%r11d
  1ba4a7:	mov    %r13,0x60(%rsp)
  1ba4ac:	mov    0x8(%rsp),%r13
  1ba4b1:	mov    %r13,%rsi
  1ba4b4:	sub    %r14,%rsi
  1ba4b7:	cmovb  %r11,%rsi
  1ba4bb:	mov    %r13,%r14
  1ba4be:	sub    0x38(%rsp),%r14
  1ba4c3:	cmovb  %r11,%r14
  1ba4c7:	lea    (%r15,%r9,1),%r11
  1ba4cb:	cmp    %r14,%rsi
  1ba4ce:	cmovb  %rsi,%r14
  1ba4d2:	sub    %rbp,%r13
  1ba4d5:	mov    $0x0,%esi
  1ba4da:	cmovb  %rsi,%r13
  1ba4de:	cmp    %r13,%r14
  1ba4e1:	cmovb  %r14,%r13
  1ba4e5:	cmp    %r13,%r10
  1ba4e8:	cmovb  %r10,%r13
  1ba4ec:	shl    $0x4,%r13
  1ba4f0:	lea    (%r11,%r13,1),%rsi
  1ba4f4:	add    $0x8,%rsi
  1ba4f8:	lea    0x8(%r15,%r9,1),%rbp
  1ba4fd:	lea    (%r11,%r13,1),%r9
  1ba501:	add    $0x10,%r9
  1ba505:	mov    %r9,0xb0(%rsp)
  1ba50d:	lea    (%rbx,%rbx,8),%r14
  1ba511:	shl    $0x5,%r14
  1ba515:	add    %rdi,%r14
  1ba518:	lea    (%r15,%r14,1),%r9
  1ba51c:	lea    (%r15,%r14,1),%rbx
  1ba520:	add    $0x8,%rbx
  1ba524:	mov    %rbx,0x38(%rsp)
  1ba529:	lea    0x10(%r13,%r9,1),%r10
  1ba52e:	mov    %r10,0x88(%rsp)
  1ba536:	mov    %r9,%rbx
  1ba539:	lea    (%r8,%rdi,1),%r9
  1ba53d:	lea    (%r15,%r9,1),%r14
  1ba541:	lea    0x8(%r15,%r9,1),%r9
  1ba546:	mov    %r9,0x100(%rsp)
  1ba54e:	lea    0x10(%r13,%r14,1),%r9
  1ba553:	mov    %r9,0x78(%rsp)
  1ba558:	lea    0x8(%r13,%rbx,1),%r9
  1ba55d:	mov    %r9,0x48(%rsp)
  1ba562:	lea    (%r14,%r13,1),%r9
  1ba566:	add    $0x8,%r9
  1ba56a:	mov    0x60(%rsp),%r13
  1ba56f:	cmp    0xb0(%rsp),%r11
  1ba577:	setb   0xe0(%rsp)
  1ba57f:	cmp    %rsi,%rbp
  1ba582:	setb   0x58(%rsp)
  1ba587:	cmp    %r10,%r11
  1ba58a:	setb   0x80(%rsp)
  1ba592:	cmp    %rsi,0x38(%rsp)
  1ba597:	setb   0x98(%rsp)
  1ba59f:	mov    0x78(%rsp),%r10
  1ba5a4:	cmp    %r10,%r11
  1ba5a7:	setb   0xc8(%rsp)
  1ba5af:	cmp    %rsi,0x100(%rsp)
  1ba5b7:	setb   0xa8(%rsp)
  1ba5bf:	cmp    0x48(%rsp),%r11
  1ba5c4:	setb   0xf8(%rsp)
  1ba5cc:	cmp    %rsi,%rbx
  1ba5cf:	setb   0x118(%rsp)
  1ba5d7:	cmp    %r9,%r11
  1ba5da:	setb   0x120(%rsp)
  1ba5e2:	cmp    %rsi,%r14
  1ba5e5:	setb   0x130(%rsp)
  1ba5ed:	cmp    0x88(%rsp),%rbp
  1ba5f5:	setb   0x88(%rsp)
  1ba5fd:	mov    0xb0(%rsp),%rsi
  1ba605:	cmp    %rsi,0x38(%rsp)
  1ba60a:	setb   0x38(%rsp)
  1ba60f:	cmp    %r10,%rbp
  1ba612:	setb   0x78(%rsp)
  1ba617:	cmp    %rsi,0x100(%rsp)
  1ba61f:	setb   0x100(%rsp)
  1ba627:	cmp    0x48(%rsp),%rbp
  1ba62c:	setb   0x140(%rsp)
  1ba634:	cmp    %rsi,%rbx
  1ba637:	mov    %rsi,%r10
  1ba63a:	setb   0x48(%rsp)
  1ba63f:	cmp    %r9,%rbp
  1ba642:	setb   %sil
  1ba646:	cmp    %r10,%r14
  1ba649:	mov    %r13,%r11
  1ba64c:	setb   %r10b
  1ba650:	movzbl 0x58(%rsp),%ebx
  1ba655:	test   %bl,0xe0(%rsp)
  1ba65c:	jne    1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba662:	mov    %r13,%r11
  1ba665:	movzbl 0x98(%rsp),%ebp
  1ba66d:	and    %bpl,0x80(%rsp)
  1ba675:	jne    1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba67b:	mov    %r13,%r11
  1ba67e:	movzbl 0xa8(%rsp),%ebp
  1ba686:	and    %bpl,0xc8(%rsp)
  1ba68e:	jne    1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba694:	mov    %r13,%r11
  1ba697:	movzbl 0x118(%rsp),%ebp
  1ba69f:	and    %bpl,0xf8(%rsp)
  1ba6a7:	jne    1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba6ad:	mov    %r13,%r11
  1ba6b0:	movzbl 0x130(%rsp),%ebp
  1ba6b8:	and    %bpl,0x120(%rsp)
  1ba6c0:	jne    1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba6c6:	mov    %r13,%r11
  1ba6c9:	movzbl 0x38(%rsp),%ebp
  1ba6ce:	and    %bpl,0x88(%rsp)
  1ba6d6:	jne    1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba6dc:	mov    %r13,%r11
  1ba6df:	movzbl 0x100(%rsp),%ebp
  1ba6e7:	and    %bpl,0x78(%rsp)
  1ba6ec:	jne    1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba6f2:	mov    %r13,%r11
  1ba6f5:	movzbl 0x140(%rsp),%r9d
  1ba6fe:	and    0x48(%rsp),%r9b
  1ba703:	jne    1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba709:	mov    %r13,%r11
  1ba70c:	and    %r10b,%sil
  1ba70f:	jne    1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba715:	and    $0xfffffffffffffffe,%rdx
  1ba719:	lea    (%rdx,%r13,1),%r11
  1ba71d:	add    %r15,%rdi
  1ba720:	mov    0xd0(%rsp),%rsi
  1ba728:	mov    0x148(%rsp),%r9
  1ba730:	movupd (%rdi,%rsi,1),%xmm0
  1ba735:	movupd (%rdi,%r8,1),%xmm1
  1ba73b:	addpd  %xmm0,%xmm1
  1ba73f:	movupd %xmm1,(%rdi,%r9,1)
  1ba745:	add    $0x10,%rdi
  1ba749:	dec    %rdx
  1ba74c:	jne    1ba730 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x118b0>
  1ba74e:	jmp    1b978b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1090b>
  1ba753:	xor    %ecx,%ecx
  1ba755:	mov    %rbx,%rdx
  1ba758:	sub    %r10,%rdx
  1ba75b:	cmovb  %rcx,%rdx
  1ba75f:	mov    %rbx,%rsi
  1ba762:	sub    %r11,%rsi
  1ba765:	cmovb  %rcx,%rsi
  1ba769:	cmp    %rsi,%rdx
  1ba76c:	cmovb  %rdx,%rsi
  1ba770:	cmp    %rsi,%r9
  1ba773:	cmovb  %r9,%rsi
  1ba777:	imul   $0x720,%rbp,%rcx
  1ba77e:	mov    %r10,0x38(%rsp)
  1ba783:	mov    0x60(%rsp),%r10
  1ba788:	mov    %r10,%rdx
  1ba78b:	shl    $0x4,%rdx
  1ba78f:	lea    (%r15,%rcx,1),%r8
  1ba793:	lea    (%rdx,%r8,1),%rbx
  1ba797:	add    $0x8,%rbx
  1ba79b:	add    %rdx,%r8
  1ba79e:	mov    %rsi,%r12
  1ba7a1:	shl    $0x4,%r12
  1ba7a5:	add    %r8,%r12
  1ba7a8:	add    $0x8,%r12
  1ba7ac:	mov    %r10,%r8
  1ba7af:	mov    0x38(%rsp),%r10
  1ba7b4:	cmp    %rbx,%r12
  1ba7b7:	mov    0x8(%rsp),%rbx
  1ba7bc:	jb     1b9a50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10bd0>
  1ba7c2:	mov    0x60(%rsp),%r8
  1ba7c7:	movabs $0xfffffffffffffff,%r12
  1ba7d1:	cmp    %r12,%rsi
  1ba7d4:	ja     1b9a50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10bd0>
  1ba7da:	imul   $0x730,%rbp,%rsi
  1ba7e1:	xor    %r8d,%r8d
  1ba7e4:	mov    0x8(%rsp),%rbx
  1ba7e9:	sub    %r10,%rbx
  1ba7ec:	cmovb  %r8,%rbx
  1ba7f0:	mov    0x8(%rsp),%r10
  1ba7f5:	sub    %r11,%r10
  1ba7f8:	cmovb  %r8,%r10
  1ba7fc:	cmp    %r10,%rbx
  1ba7ff:	cmovb  %rbx,%r10
  1ba803:	lea    (%rsi,%rdx,1),%r8
  1ba807:	cmp    %r10,%r9
  1ba80a:	cmovb  %r9,%r10
  1ba80e:	lea    (%r15,%r8,1),%r9
  1ba812:	shl    $0x4,%r10
  1ba816:	lea    (%r10,%r9,1),%r11
  1ba81a:	add    $0x8,%r11
  1ba81e:	lea    0x8(%r15,%r8,1),%r8
  1ba823:	lea    0x10(%r10,%r9,1),%rbx
  1ba828:	lea    (%rcx,%rdx,1),%r12
  1ba82c:	lea    (%r15,%r12,1),%rbp
  1ba830:	lea    (%r10,%rbp,1),%r13
  1ba834:	add    $0x8,%r13
  1ba838:	add    %rbp,%r10
  1ba83b:	add    $0x10,%r10
  1ba83f:	cmp    %rbx,%r9
  1ba842:	setb   0x38(%rsp)
  1ba847:	cmp    %r11,%r8
  1ba84a:	setb   0x40(%rsp)
  1ba84f:	cmp    %r13,%r9
  1ba852:	setb   0x48(%rsp)
  1ba857:	cmp    %r11,%rbp
  1ba85a:	setb   0x100(%rsp)
  1ba862:	cmp    %r10,%r9
  1ba865:	lea    0x8(%r15,%r12,1),%r9
  1ba86a:	setb   %r12b
  1ba86e:	cmp    %r11,%r9
  1ba871:	setb   0xb0(%rsp)
  1ba879:	cmp    %r13,%r8
  1ba87c:	mov    0x50(%rsp),%r13
  1ba881:	setb   %r11b
  1ba885:	cmp    %rbx,%rbp
  1ba888:	mov    (%rsp),%rbp
  1ba88c:	setb   0xd0(%rsp)
  1ba894:	cmp    %r10,%r8
  1ba897:	setb   %r10b
  1ba89b:	cmp    %rbx,%r9
  1ba89e:	mov    0x8(%rsp),%rbx
  1ba8a3:	setb   0xe0(%rsp)
  1ba8ab:	mov    0x60(%rsp),%r8
  1ba8b0:	movzbl 0x40(%rsp),%r9d
  1ba8b6:	test   %r9b,0x38(%rsp)
  1ba8bb:	jne    1b9a50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10bd0>
  1ba8c1:	mov    0x60(%rsp),%r8
  1ba8c6:	movzbl 0x100(%rsp),%r9d
  1ba8cf:	and    %r9b,0x48(%rsp)
  1ba8d4:	jne    1b9a50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10bd0>
  1ba8da:	mov    0x60(%rsp),%r8
  1ba8df:	and    0xb0(%rsp),%r12b
  1ba8e7:	jne    1b9a50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10bd0>
  1ba8ed:	mov    0x60(%rsp),%r8
  1ba8f2:	and    0xd0(%rsp),%r11b
  1ba8fa:	jne    1b9a50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10bd0>
  1ba900:	mov    0x60(%rsp),%r8
  1ba905:	and    0xe0(%rsp),%r10b
  1ba90d:	jne    1b9a50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10bd0>
  1ba913:	and    $0xfffffffffffffffe,%rax
  1ba917:	mov    0x60(%rsp),%r8
  1ba91c:	add    %rax,%r8
  1ba91f:	mov    0x1d8(%rsp),%r9
  1ba927:	movsd  0x10(%r9),%xmm0
  1ba92d:	movsd  0x18(%r9),%xmm1
  1ba933:	unpcklpd %xmm1,%xmm1
  1ba937:	unpcklpd %xmm0,%xmm0
  1ba93b:	add    %r15,%rdx
  1ba93e:	xchg   %ax,%ax
  1ba940:	movupd (%rdx,%rcx,1),%xmm2
  1ba945:	movupd 0x10(%rdx,%rcx,1),%xmm3
  1ba94b:	movapd %xmm2,%xmm4
  1ba94f:	unpcklpd %xmm3,%xmm4
  1ba953:	unpckhpd %xmm3,%xmm2
  1ba957:	movapd %xmm1,%xmm3
  1ba95b:	mulpd  %xmm4,%xmm3
  1ba95f:	movapd %xmm0,%xmm5
  1ba963:	mulpd  %xmm2,%xmm5
  1ba967:	addpd  %xmm3,%xmm5
  1ba96b:	mulpd  %xmm0,%xmm4
  1ba96f:	mulpd  %xmm1,%xmm2
  1ba973:	subpd  %xmm2,%xmm4
  1ba977:	movapd %xmm4,%xmm2
  1ba97b:	unpcklpd %xmm5,%xmm2
  1ba97f:	unpckhpd %xmm5,%xmm4
  1ba983:	movupd %xmm4,0x10(%rdx,%rsi,1)
  1ba989:	movupd %xmm2,(%rdx,%rsi,1)
  1ba98e:	add    $0x20,%rdx
  1ba992:	add    $0xfffffffffffffffe,%rax
  1ba996:	jne    1ba940 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x11ac0>
  1ba998:	jmp    1b9a50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x10bd0>
  1ba99d:	xor    %r8d,%r8d
  1ba9a0:	mov    %rbx,%r9
  1ba9a3:	sub    %r14,%r9
  1ba9a6:	cmovb  %r8,%r9
  1ba9aa:	mov    %rbx,%r11
  1ba9ad:	sub    %r12,%r11
  1ba9b0:	cmovb  %r8,%r11
  1ba9b4:	cmp    %r11,%r9
  1ba9b7:	cmovb  %r9,%r11
  1ba9bb:	cmp    %r11,%rdx
  1ba9be:	cmovb  %rdx,%r11
  1ba9c2:	mov    (%rsp),%r8
  1ba9c6:	shl    $0x6,%r8
  1ba9ca:	lea    (%r8,%r8,2),%r8
  1ba9ce:	mov    %rbp,%r9
  1ba9d1:	shl    $0x4,%r9
  1ba9d5:	lea    (%r15,%r8,1),%r10
  1ba9d9:	lea    (%r9,%r10,1),%rbx
  1ba9dd:	add    $0x8,%rbx
  1ba9e1:	add    %r9,%r10
  1ba9e4:	mov    %r11,%r13
  1ba9e7:	shl    $0x4,%r13
  1ba9eb:	add    %r10,%r13
  1ba9ee:	add    $0x8,%r13
  1ba9f2:	mov    %rbp,%r10
  1ba9f5:	cmp    %rbx,%r13
  1ba9f8:	mov    0x8(%rsp),%rbx
  1ba9fd:	jb     1b941a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1059a>
  1baa03:	mov    %rbp,%r10
  1baa06:	movabs $0xfffffffffffffff,%rsi
  1baa10:	cmp    %rsi,%r11
  1baa13:	ja     1b941a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1059a>
  1baa19:	mov    (%rsp),%rsi
  1baa1d:	imul   $0x6e0,%rsi,%r11
  1baa24:	lea    (%r11,%r9,1),%r10
  1baa28:	xor    %ebx,%ebx
  1baa2a:	mov    0x8(%rsp),%r13
  1baa2f:	sub    %r14,%r13
  1baa32:	cmovb  %rbx,%r13
  1baa36:	mov    0x8(%rsp),%r14
  1baa3b:	sub    %r12,%r14
  1baa3e:	cmovb  %rbx,%r14
  1baa42:	lea    (%r15,%r10,1),%rbx
  1baa46:	cmp    %r14,%r13
  1baa49:	cmovb  %r13,%r14
  1baa4d:	add    %r15,%r10
  1baa50:	add    $0x8,%r10
  1baa54:	mov    %r10,0xb0(%rsp)
  1baa5c:	cmp    %r14,%rdx
  1baa5f:	cmovb  %rdx,%r14
  1baa63:	shl    $0x4,%r14
  1baa67:	lea    (%r14,%rbx,1),%r10
  1baa6b:	add    $0x8,%r10
  1baa6f:	mov    %r10,0x58(%rsp)
  1baa74:	lea    (%r14,%rbx,1),%r10
  1baa78:	add    $0x10,%r10
  1baa7c:	mov    %r10,0xd0(%rsp)
  1baa84:	lea    (%rsi,%rsi,2),%r13
  1baa88:	shl    $0x6,%r13
  1baa8c:	add    %r9,%r13
  1baa8f:	lea    (%r15,%r13,1),%rsi
  1baa93:	lea    (%r14,%rsi,1),%r12
  1baa97:	add    $0x8,%r12
  1baa9b:	mov    %r12,0xe0(%rsp)
  1baaa3:	add    %rsi,%r14
  1baaa6:	add    $0x10,%r14
  1baaaa:	mov    %r14,0x10(%rsp)
  1baaaf:	cmp    %r10,%rbx
  1baab2:	setb   0x48(%rsp)
  1baab7:	mov    0xb0(%rsp),%r14
  1baabf:	mov    0x58(%rsp),%r12
  1baac4:	cmp    %r12,%r14
  1baac7:	setb   0x100(%rsp)
  1baacf:	mov    0xe0(%rsp),%r10
  1baad7:	cmp    %r10,%rbx
  1baada:	setb   0x88(%rsp)
  1baae2:	cmp    %r12,%rsi
  1baae5:	setb   0x78(%rsp)
  1baaea:	cmp    0x10(%rsp),%rbx
  1baaef:	lea    0x8(%r15,%r13,1),%rbx
  1baaf4:	setb   %r13b
  1baaf8:	cmp    %r12,%rbx
  1baafb:	setb   0x58(%rsp)
  1bab00:	cmp    %r10,%r14
  1bab03:	setb   0xe0(%rsp)
  1bab0b:	mov    0xd0(%rsp),%r10
  1bab13:	cmp    %r10,%rsi
  1bab16:	setb   0x80(%rsp)
  1bab1e:	cmp    0x10(%rsp),%r14
  1bab23:	setb   %sil
  1bab27:	cmp    %r10,%rbx
  1bab2a:	mov    0x8(%rsp),%rbx
  1bab2f:	setb   %r14b
  1bab33:	mov    %rbp,%r10
  1bab36:	movzbl 0x100(%rsp),%r12d
  1bab3f:	test   %r12b,0x48(%rsp)
  1bab44:	jne    1b941a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1059a>
  1bab4a:	mov    %rbp,%r10
  1bab4d:	movzbl 0x78(%rsp),%r12d
  1bab53:	and    %r12b,0x88(%rsp)
  1bab5b:	jne    1b941a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1059a>
  1bab61:	mov    %rbp,%r10
  1bab64:	and    0x58(%rsp),%r13b
  1bab69:	jne    1b941a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1059a>
  1bab6f:	mov    %rbp,%r10
  1bab72:	movzbl 0x80(%rsp),%r12d
  1bab7b:	and    %r12b,0xe0(%rsp)
  1bab83:	jne    1b941a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1059a>
  1bab89:	mov    %rbp,%r10
  1bab8c:	and    %r14b,%sil
  1bab8f:	jne    1b941a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1059a>
  1bab95:	and    $0xfffffffffffffffe,%rax
  1bab99:	lea    (%rax,%rbp,1),%r10
  1bab9d:	mov    0x1d8(%rsp),%rsi
  1baba5:	movsd  0x10(%rsi),%xmm0
  1babaa:	movsd  0x18(%rsi),%xmm1
  1babaf:	unpcklpd %xmm1,%xmm1
  1babb3:	unpcklpd %xmm0,%xmm0
  1babb7:	add    %r15,%r9
  1babba:	nopw   0x0(%rax,%rax,1)
  1babc0:	movupd (%r9,%r8,1),%xmm2
  1babc6:	movupd 0x10(%r9,%r8,1),%xmm3
  1babcd:	movapd %xmm2,%xmm4
  1babd1:	unpcklpd %xmm3,%xmm4
  1babd5:	unpckhpd %xmm3,%xmm2
  1babd9:	movapd %xmm1,%xmm3
  1babdd:	mulpd  %xmm4,%xmm3
  1babe1:	movapd %xmm0,%xmm5
  1babe5:	mulpd  %xmm2,%xmm5
  1babe9:	addpd  %xmm3,%xmm5
  1babed:	mulpd  %xmm0,%xmm4
  1babf1:	mulpd  %xmm1,%xmm2
  1babf5:	subpd  %xmm2,%xmm4
  1babf9:	movapd %xmm4,%xmm2
  1babfd:	unpcklpd %xmm5,%xmm2
  1bac01:	unpckhpd %xmm5,%xmm4
  1bac05:	movupd %xmm4,0x10(%r9,%r11,1)
  1bac0c:	movupd %xmm2,(%r9,%r11,1)
  1bac12:	add    $0x20,%r9
  1bac16:	add    $0xfffffffffffffffe,%rax
  1bac1a:	jne    1babc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x11d40>
  1bac1c:	mov    0x60(%rsp),%rbp
  1bac21:	jmp    1b941a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1059a>
  1bac26:	xor    %r9d,%r9d
  1bac29:	mov    %rbx,%r10
  1bac2c:	sub    %rbp,%r10
  1bac2f:	cmovb  %r9,%r10
  1bac33:	mov    0x18(%rsp),%r11
  1bac38:	cmp    %r11,%r10
  1bac3b:	cmovae %r11,%r10
  1bac3f:	mov    %rbx,%r11
  1bac42:	sub    %rsi,%r11
  1bac45:	cmovb  %r9,%r11
  1bac49:	cmp    %r11,%r10
  1bac4c:	cmovb  %r10,%r11
  1bac50:	cmp    %r11,%rdx
  1bac53:	cmovb  %rdx,%r11
  1bac57:	imul   $0xf0,(%rsp),%r9
  1bac5f:	mov    %r13,%r10
  1bac62:	shl    $0x4,%r10
  1bac66:	mov    %r9,0x10(%rsp)
  1bac6b:	lea    (%r15,%r9,1),%rbx
  1bac6f:	mov    %rbp,0x48(%rsp)
  1bac74:	lea    (%r10,%rbx,1),%rbp
  1bac78:	add    $0x8,%rbp
  1bac7c:	add    %r10,%rbx
  1bac7f:	mov    %r11,%r9
  1bac82:	shl    $0x4,%r9
  1bac86:	add    %r9,%rbx
  1bac89:	add    $0x8,%rbx
  1bac8d:	mov    %r13,%r14
  1bac90:	cmp    %rbp,%rbx
  1bac93:	mov    0x8(%rsp),%rbx
  1bac98:	jb     1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1bac9e:	lea    (%r15,%r8,1),%rbx
  1baca2:	lea    (%r10,%rbx,1),%rbp
  1baca6:	add    $0x8,%rbp
  1bacaa:	add    %r10,%rbx
  1bacad:	add    %rbx,%r9
  1bacb0:	add    $0x8,%r9
  1bacb4:	mov    0x8(%rsp),%rbx
  1bacb9:	mov    %r13,%r14
  1bacbc:	cmp    %rbp,%r9
  1bacbf:	mov    0x48(%rsp),%rbp
  1bacc4:	jb     1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1bacca:	mov    %r13,%r14
  1baccd:	movabs $0xfffffffffffffff,%r9
  1bacd7:	cmp    %r9,%r11
  1bacda:	ja     1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1bace0:	imul   $0x6f0,(%rsp),%r11
  1bace8:	xor    %r9d,%r9d
  1baceb:	mov    0x8(%rsp),%rbx
  1bacf0:	sub    %rbp,%rbx
  1bacf3:	cmovb  %r9,%rbx
  1bacf7:	mov    0x18(%rsp),%r14
  1bacfc:	cmp    %r14,%rbx
  1bacff:	cmovae %r14,%rbx
  1bad03:	mov    0x8(%rsp),%r14
  1bad08:	sub    %rsi,%r14
  1bad0b:	cmovb  %r9,%r14
  1bad0f:	lea    (%r11,%r10,1),%r9
  1bad13:	cmp    %r14,%rbx
  1bad16:	cmovb  %rbx,%r14
  1bad1a:	lea    (%r15,%r9,1),%rsi
  1bad1e:	cmp    %r14,%rdx
  1bad21:	cmovb  %rdx,%r14
  1bad25:	lea    (%r15,%r9,1),%rdx
  1bad29:	add    $0x8,%rdx
  1bad2d:	mov    %rdx,0xb0(%rsp)
  1bad35:	shl    $0x4,%r14
  1bad39:	lea    (%r14,%rsi,1),%r9
  1bad3d:	add    $0x8,%r9
  1bad41:	lea    0x10(%r14,%rsi,1),%rdx
  1bad46:	mov    %rdx,0x18(%rsp)
  1bad4b:	mov    0x10(%rsp),%rdx
  1bad50:	add    %r10,%rdx
  1bad53:	lea    (%r15,%rdx,1),%rbx
  1bad57:	add    $0x8,%rbx
  1bad5b:	mov    %rbx,0x80(%rsp)
  1bad63:	add    %r15,%rdx
  1bad66:	lea    (%r14,%rdx,1),%rbx
  1bad6a:	add    $0x10,%rbx
  1bad6e:	mov    %rbx,0xd0(%rsp)
  1bad76:	lea    (%r8,%r10,1),%rbp
  1bad7a:	lea    (%r15,%rbp,1),%rbx
  1bad7e:	add    $0x8,%rbx
  1bad82:	mov    %rbx,0x100(%rsp)
  1bad8a:	add    %r15,%rbp
  1bad8d:	lea    (%r14,%rbp,1),%rbx
  1bad91:	add    $0x10,%rbx
  1bad95:	mov    %rbx,0x58(%rsp)
  1bad9a:	lea    0x8(%r14,%rdx,1),%rbx
  1bad9f:	mov    %rbx,0xe0(%rsp)
  1bada7:	add    %rbp,%r14
  1badaa:	add    $0x8,%r14
  1badae:	mov    %r14,0x48(%rsp)
  1badb3:	cmp    0x18(%rsp),%rsi
  1badb8:	setb   0x88(%rsp)
  1badc0:	cmp    %r9,0xb0(%rsp)
  1badc8:	setb   0x78(%rsp)
  1badcd:	cmp    0xd0(%rsp),%rsi
  1badd5:	setb   0x98(%rsp)
  1baddd:	mov    0x80(%rsp),%r14
  1bade5:	cmp    %r9,%r14
  1bade8:	setb   0xc8(%rsp)
  1badf0:	cmp    0x58(%rsp),%rsi
  1badf5:	setb   0xa8(%rsp)
  1badfd:	cmp    %r9,0x100(%rsp)
  1bae05:	setb   0xf8(%rsp)
  1bae0d:	cmp    0xe0(%rsp),%rsi
  1bae15:	setb   0x118(%rsp)
  1bae1d:	cmp    %r9,%rdx
  1bae20:	setb   0x120(%rsp)
  1bae28:	cmp    0x48(%rsp),%rsi
  1bae2d:	setb   0x130(%rsp)
  1bae35:	cmp    %r9,%rbp
  1bae38:	setb   0x140(%rsp)
  1bae40:	mov    0xb0(%rsp),%rbx
  1bae48:	cmp    0xd0(%rsp),%rbx
  1bae50:	setb   0xd0(%rsp)
  1bae58:	mov    0x18(%rsp),%r9
  1bae5d:	cmp    %r9,%r14
  1bae60:	setb   0x80(%rsp)
  1bae68:	cmp    0x58(%rsp),%rbx
  1bae6d:	setb   0x58(%rsp)
  1bae72:	cmp    %r9,0x100(%rsp)
  1bae7a:	setb   0x100(%rsp)
  1bae82:	cmp    0xe0(%rsp),%rbx
  1bae8a:	setb   %sil
  1bae8e:	cmp    %r9,%rdx
  1bae91:	mov    %r9,%r14
  1bae94:	setb   %r9b
  1bae98:	cmp    0x48(%rsp),%rbx
  1bae9d:	mov    0x8(%rsp),%rbx
  1baea2:	setb   %dl
  1baea5:	cmp    %r14,%rbp
  1baea8:	mov    %r13,%r14
  1baeab:	setb   0x18(%rsp)
  1baeb0:	movzbl 0x78(%rsp),%ebp
  1baeb5:	test   %bpl,0x88(%rsp)
  1baebd:	jne    1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1baec3:	mov    %r13,%r14
  1baec6:	movzbl 0xc8(%rsp),%ebp
  1baece:	and    %bpl,0x98(%rsp)
  1baed6:	jne    1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1baedc:	mov    %r13,%r14
  1baedf:	movzbl 0xf8(%rsp),%ebp
  1baee7:	and    %bpl,0xa8(%rsp)
  1baeef:	jne    1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1baef5:	mov    %r13,%r14
  1baef8:	movzbl 0x120(%rsp),%ebp
  1baf00:	and    %bpl,0x118(%rsp)
  1baf08:	jne    1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1baf0e:	mov    %r13,%r14
  1baf11:	movzbl 0x140(%rsp),%ebp
  1baf19:	and    %bpl,0x130(%rsp)
  1baf21:	jne    1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1baf27:	mov    %r13,%r14
  1baf2a:	movzbl 0x80(%rsp),%ebp
  1baf32:	and    %bpl,0xd0(%rsp)
  1baf3a:	jne    1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1baf40:	mov    %r13,%r14
  1baf43:	movzbl 0x100(%rsp),%ebp
  1baf4b:	and    %bpl,0x58(%rsp)
  1baf50:	jne    1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1baf56:	mov    %r13,%r14
  1baf59:	and    %r9b,%sil
  1baf5c:	jne    1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1baf62:	mov    %r13,%r14
  1baf65:	and    0x18(%rsp),%dl
  1baf69:	jne    1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1baf6f:	and    $0xfffffffffffffffe,%rdi
  1baf73:	lea    (%rdi,%r13,1),%r14
  1baf77:	add    %r15,%r10
  1baf7a:	mov    0x10(%rsp),%rdx
  1baf7f:	nop
  1baf80:	movupd (%r10,%rdx,1),%xmm0
  1baf86:	movupd (%r10,%r8,1),%xmm1
  1baf8c:	addpd  %xmm0,%xmm1
  1baf90:	movupd %xmm1,(%r10,%r11,1)
  1baf96:	add    $0x10,%r10
  1baf9a:	dec    %rdi
  1baf9d:	jne    1baf80 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12100>
  1baf9f:	jmp    1b950d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1068d>
  1bafa4:	mov    0x8(%rsp),%rbx
  1bafa9:	jmp    1bafb4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12134>
  1bafab:	mov    0x8(%rsp),%rbx
  1bafb0:	mov    (%rsp),%rbp
  1bafb4:	mov    0x28(%rsp),%r11
  1bafb9:	mov    0x1c8(%rsp),%r10
  1bafc1:	mov    0x50(%rsp),%r13
  1bafc6:	mov    0x60(%rsp),%r14
  1bafcb:	jmp    1bafde <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1215e>
  1bafcd:	mov    (%rsp),%rbp
  1bafd1:	mov    0x28(%rsp),%r11
  1bafd6:	mov    0x1c8(%rsp),%r10
  1bafde:	imul   $0x740,%rbp,%rcx
  1bafe5:	mov    %r14,%rsi
  1bafe8:	shl    $0x4,%rsi
  1bafec:	add    %r15,%rsi
  1bafef:	imul   $0x730,%rbp,%r8
  1baff6:	imul   $0x700,%rbp,%r9
  1baffd:	mov    0x30(%rsp),%r12
  1bb002:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1bb010:	mov    0x10(%rsp),%rdi
  1bb015:	add    %r14,%rdi
  1bb018:	cmp    %rbx,%rdi
  1bb01b:	jae    1beb71 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15cf1>
  1bb021:	lea    (%rax,%r14,1),%rdi
  1bb025:	cmp    %rbx,%rdi
  1bb028:	jae    1beb61 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ce1>
  1bb02e:	lea    (%rdx,%r14,1),%rdi
  1bb032:	cmp    %rbx,%rdi
  1bb035:	jae    1beb51 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15cd1>
  1bb03b:	inc    %r14
  1bb03e:	movupd (%rsi,%r9,1),%xmm0
  1bb044:	movupd (%rsi,%r8,1),%xmm1
  1bb04a:	addpd  %xmm0,%xmm1
  1bb04e:	movupd %xmm1,(%rsi,%rcx,1)
  1bb053:	add    $0x10,%rsi
  1bb057:	cmp    %r14,%r12
  1bb05a:	jne    1bb010 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12190>
  1bb05c:	mov    0x1b0(%rsp),%r9
  1bb064:	xor    %ecx,%ecx
  1bb066:	xorpd  %xmm0,%xmm0
  1bb06a:	xor    %esi,%esi
  1bb06c:	nopl   0x0(%rax)
  1bb070:	mov    (%r11,%rcx,8),%rdi
  1bb074:	lea    (%rdi,%rdx,1),%rax
  1bb078:	cmp    %rbx,%rax
  1bb07b:	jae    1bdc84 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14e04>
  1bb081:	shl    $0x4,%rax
  1bb085:	movsd  (%r15,%rax,1),%xmm1
  1bb08b:	ucomisd %xmm0,%xmm1
  1bb08f:	jne    1bb0d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12250>
  1bb091:	jp     1bb0d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12250>
  1bb093:	add    %r15,%rax
  1bb096:	movsd  0x8(%rax),%xmm1
  1bb09b:	ucomisd %xmm0,%xmm1
  1bb09f:	jne    1bb0d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12250>
  1bb0a1:	jp     1bb0d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12250>
  1bb0a3:	cmp    0x1d0(%rsp),%rdi
  1bb0ab:	jae    1be8b7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15a37>
  1bb0b1:	movq   $0x73,(%r10,%rdi,8)
  1bb0b9:	inc    %rcx
  1bb0bc:	cmp    %rcx,%r13
  1bb0bf:	jne    1bb070 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x121f0>
  1bb0c1:	jmp    1bb0e8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12268>
  1bb0c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1bb0d0:	cmp    %r9,%rsi
  1bb0d3:	jae    1be303 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15483>
  1bb0d9:	mov    %rdi,(%r11,%rsi,8)
  1bb0dd:	inc    %rsi
  1bb0e0:	inc    %rcx
  1bb0e3:	cmp    %rcx,%r13
  1bb0e6:	jne    1bb070 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x121f0>
  1bb0e8:	cmp    %r9,%rsi
  1bb0eb:	ja     1bd43f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x145bf>
  1bb0f1:	test   %rsi,%rsi
  1bb0f4:	mov    0x1d0(%rsp),%rdx
  1bb0fc:	mov    0x90(%rsp),%rcx
  1bb104:	je     1bb12e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x122ae>
  1bb106:	shl    $0x3,%rsi
  1bb10a:	xor    %eax,%eax
  1bb10c:	nopl   0x0(%rax)
  1bb110:	mov    (%r11,%rax,1),%rdi
  1bb114:	cmp    %rdx,%rdi
  1bb117:	jae    1be2c9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15449>
  1bb11d:	movq   $0x74,(%r10,%rdi,8)
  1bb125:	add    $0x8,%rax
  1bb129:	cmp    %rax,%rsi
  1bb12c:	jne    1bb110 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12290>
  1bb12e:	xor    %eax,%eax
  1bb130:	xor    %esi,%esi
  1bb132:	mov    0x1b0(%rsp),%r9
  1bb13a:	mov    0x110(%rsp),%rbx
  1bb142:	jmp    1bb159 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x122d9>
  1bb144:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1bb150:	add    $0x8,%rax
  1bb154:	cmp    %rax,%rcx
  1bb157:	je     1bb17f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x122ff>
  1bb159:	mov    (%rbx,%rax,1),%rdi
  1bb15d:	cmp    %rdx,%rdi
  1bb160:	jae    1bd62a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x147aa>
  1bb166:	cmpq   $0x74,(%r10,%rdi,8)
  1bb16b:	jae    1bb150 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x122d0>
  1bb16d:	cmp    %r9,%rsi
  1bb170:	jae    1bda5c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14bdc>
  1bb176:	mov    %rdi,(%r11,%rsi,8)
  1bb17a:	inc    %rsi
  1bb17d:	jmp    1bb150 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x122d0>
  1bb17f:	cmp    %r9,%rsi
  1bb182:	ja     1bd30c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1448c>
  1bb188:	test   %rsi,%rsi
  1bb18b:	je     1bb1bf <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1233f>
  1bb18d:	mov    (%r11),%r8
  1bb190:	lea    -0x1(%rsi),%rax
  1bb194:	mov    -0x8(%r11,%rsi,8),%rcx
  1bb199:	sub    %r8,%rcx
  1bb19c:	setae  %dl
  1bb19f:	cmp    %rax,%rcx
  1bb1a2:	sete   %al
  1bb1a5:	and    %dl,%al
  1bb1a7:	cmp    $0x1,%al
  1bb1a9:	jne    1bb1c6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12346>
  1bb1ab:	add    %r8,%rsi
  1bb1ae:	mov    0x1d0(%rsp),%rdx
  1bb1b6:	jae    1bb1d3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12353>
  1bb1b8:	xor    %esi,%esi
  1bb1ba:	xor    %r8d,%r8d
  1bb1bd:	jmp    1bb1d3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12353>
  1bb1bf:	xor    %esi,%esi
  1bb1c1:	xor    %r8d,%r8d
  1bb1c4:	jmp    1bb1db <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1235b>
  1bb1c6:	xor    %esi,%esi
  1bb1c8:	xor    %r8d,%r8d
  1bb1cb:	mov    0x1d0(%rsp),%rdx
  1bb1d3:	mov    0x90(%rsp),%rcx
  1bb1db:	xor    %eax,%eax
  1bb1dd:	xor    %r13d,%r13d
  1bb1e0:	jmp    1bb1f9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12379>
  1bb1e2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1bb1f0:	add    $0x8,%rax
  1bb1f4:	cmp    %rax,%rcx
  1bb1f7:	je     1bb21f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1239f>
  1bb1f9:	mov    (%rbx,%rax,1),%rdi
  1bb1fd:	cmp    %rdx,%rdi
  1bb200:	jae    1bd63a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x147ba>
  1bb206:	cmpq   $0x75,(%r10,%rdi,8)
  1bb20b:	jae    1bb1f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12370>
  1bb20d:	cmp    %r9,%r13
  1bb210:	jae    1bda6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14bef>
  1bb216:	mov    %rdi,(%r11,%r13,8)
  1bb21a:	inc    %r13
  1bb21d:	jmp    1bb1f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12370>
  1bb21f:	cmp    %r9,%r13
  1bb222:	ja     1bd31e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1449e>
  1bb228:	test   %r13,%r13
  1bb22b:	je     1bc806 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13986>
  1bb231:	mov    (%r11),%rax
  1bb234:	lea    -0x1(%r13),%rcx
  1bb238:	mov    -0x8(%r11,%r13,8),%rdx
  1bb23d:	sub    %rax,%rdx
  1bb240:	setae  %dil
  1bb244:	cmp    %rcx,%rdx
  1bb247:	sete   %cl
  1bb24a:	and    %dil,%cl
  1bb24d:	cmp    $0x1,%cl
  1bb250:	jne    1bb26c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x123ec>
  1bb252:	mov    %rax,%rcx
  1bb255:	add    %r13,%rcx
  1bb258:	jb     1bb26c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x123ec>
  1bb25a:	mov    $0x1,%dl
  1bb25c:	mov    %edx,0x20(%rsp)
  1bb260:	mov    %rcx,0x30(%rsp)
  1bb265:	mov    %rax,0x60(%rsp)
  1bb26a:	jmp    1bb27e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x123fe>
  1bb26c:	mov    %r8,0x60(%rsp)
  1bb271:	mov    %rsi,0x30(%rsp)
  1bb276:	movl   $0x0,0x20(%rsp)
  1bb27e:	mov    0x110(%rsp),%rbx
  1bb286:	lea    0x0(,%r13,8),%rbp
  1bb28e:	mov    (%rsp),%rax
  1bb292:	imul   $0x74,%rax,%r14
  1bb296:	imul   $0x79,%rax,%rax
  1bb29a:	mov    %rax,0x18(%rsp)
  1bb29f:	xor    %r12d,%r12d
  1bb2a2:	xorpd  %xmm1,%xmm1
  1bb2a6:	jmp    1bb2ef <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1246f>
  1bb2a8:	nopl   0x0(%rax,%rax,1)
  1bb2b0:	mov    $0x79,%r8d
  1bb2b6:	mov    $0x74,%r9d
  1bb2bc:	mov    %r15,%rdi
  1bb2bf:	mov    0x8(%rsp),%rsi
  1bb2c4:	mov    (%rsp),%rdx
  1bb2c8:	call   1a8d70 <oneloop::native::batch::copy_active_column::<f64>>
  1bb2cd:	xorpd  %xmm1,%xmm1
  1bb2d1:	mov    0x110(%rsp),%rbx
  1bb2d9:	mov    0x28(%rsp),%r11
  1bb2de:	mov    0x1b0(%rsp),%r9
  1bb2e6:	add    $0x8,%r12
  1bb2ea:	cmp    %r12,%rbp
  1bb2ed:	je     1bb363 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x124e3>
  1bb2ef:	mov    (%r11,%r12,1),%rcx
  1bb2f3:	lea    (%rcx,%r14,1),%rdi
  1bb2f7:	cmp    0x8(%rsp),%rdi
  1bb2fc:	jae    1bd926 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14aa6>
  1bb302:	shl    $0x4,%rdi
  1bb306:	movsd  (%r15,%rdi,1),%xmm0
  1bb30c:	ucomisd %xmm1,%xmm0
  1bb310:	jne    1bb2b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12430>
  1bb312:	jp     1bb2b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12430>
  1bb314:	add    %r15,%rdi
  1bb317:	movsd  0x8(%rdi),%xmm0
  1bb31c:	ucomisd %xmm1,%xmm0
  1bb320:	jne    1bb2b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12430>
  1bb322:	jp     1bb2b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12430>
  1bb324:	add    0x18(%rsp),%rcx
  1bb329:	cmp    0x8(%rsp),%rcx
  1bb32e:	jae    1be2d9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15459>
  1bb334:	cmpq   $0x3,0x1e0(%rsp)
  1bb33d:	jbe    1bd65a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x147da>
  1bb343:	shl    $0x4,%rcx
  1bb347:	mov    0x1d8(%rsp),%rax
  1bb34f:	movupd 0x30(%rax),%xmm0
  1bb354:	movupd %xmm0,(%r15,%rcx,1)
  1bb35a:	add    $0x8,%r12
  1bb35e:	cmp    %r12,%rbp
  1bb361:	jne    1bb2ef <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1246f>
  1bb363:	imul   $0x7a,(%rsp),%r8
  1bb368:	xor    %r12d,%r12d
  1bb36b:	xorpd  %xmm8,%xmm8
  1bb370:	movapd 0x1fdac87(%rip),%xmm9        # 2196000 <_fini+0x520>
  1bb379:	movsd  0x1fdc32f(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1bb381:	movsd  0x1fdc32f(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1bb389:	mov    %r8,0x10(%rsp)
  1bb38e:	xchg   %ax,%ax
  1bb390:	mov    (%r11,%r12,1),%r14
  1bb394:	mov    0x18(%rsp),%rax
  1bb399:	lea    (%r14,%rax,1),%rdi
  1bb39d:	cmp    0x8(%rsp),%rdi
  1bb3a2:	jae    1bd94d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14acd>
  1bb3a8:	shl    $0x4,%rdi
  1bb3ac:	movupd (%r15,%rdi,1),%xmm0
  1bb3b2:	movapd %xmm0,%xmm1
  1bb3b6:	unpckhpd %xmm0,%xmm1
  1bb3ba:	ucomisd %xmm8,%xmm1
  1bb3bf:	jne    1bb3d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12550>
  1bb3c1:	jp     1bb3d0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12550>
  1bb3c3:	andpd  %xmm9,%xmm0
  1bb3c8:	jmp    1bb490 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12610>
  1bb3cd:	nopl   (%rax)
  1bb3d0:	ucomisd %xmm8,%xmm0
  1bb3d5:	jne    1bb3e7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12567>
  1bb3d7:	jp     1bb3e7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12567>
  1bb3d9:	andpd  %xmm9,%xmm1
  1bb3de:	movapd %xmm1,%xmm0
  1bb3e2:	jmp    1bb490 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12610>
  1bb3e7:	movapd %xmm0,%xmm2
  1bb3eb:	andpd  %xmm9,%xmm2
  1bb3f0:	pshufd $0xee,%xmm2,%xmm3
  1bb3f5:	movapd %xmm2,%xmm4
  1bb3f9:	cmplesd %xmm3,%xmm4
  1bb3fe:	movapd %xmm4,%xmm5
  1bb402:	andpd  %xmm3,%xmm5
  1bb406:	andnpd %xmm2,%xmm4
  1bb40a:	orpd   %xmm5,%xmm4
  1bb40e:	movapd %xmm0,%xmm2
  1bb412:	cmpunordsd %xmm0,%xmm2
  1bb417:	movapd %xmm2,%xmm5
  1bb41b:	andnpd %xmm4,%xmm5
  1bb41f:	andpd  %xmm3,%xmm2
  1bb423:	orpd   %xmm5,%xmm2
  1bb427:	ucomisd %xmm6,%xmm2
  1bb42b:	jbe    1bb44c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x125cc>
  1bb42d:	ucomisd %xmm2,%xmm7
  1bb431:	jbe    1bb44c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x125cc>
  1bb433:	mulpd  %xmm0,%xmm0
  1bb437:	movapd %xmm0,%xmm1
  1bb43b:	unpckhpd %xmm0,%xmm1
  1bb43f:	addsd  %xmm0,%xmm1
  1bb443:	xorps  %xmm0,%xmm0
  1bb446:	sqrtsd %xmm1,%xmm0
  1bb44a:	jmp    1bb490 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12610>
  1bb44c:	call   *0x251077e(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1bb452:	movapd 0x1fdaba5(%rip),%xmm9        # 2196000 <_fini+0x520>
  1bb45b:	xorpd  %xmm8,%xmm8
  1bb460:	mov    0x10(%rsp),%r8
  1bb465:	movsd  0x1fdc24b(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1bb46d:	movsd  0x1fdc23b(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1bb475:	mov    0x110(%rsp),%rbx
  1bb47d:	mov    0x28(%rsp),%r11
  1bb482:	mov    0x1b0(%rsp),%r9
  1bb48a:	nopw   0x0(%rax,%rax,1)
  1bb490:	add    %r8,%r14
  1bb493:	cmp    0x8(%rsp),%r14
  1bb498:	jae    1bd938 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14ab8>
  1bb49e:	shl    $0x4,%r14
  1bb4a2:	movsd  %xmm0,(%r15,%r14,1)
  1bb4a8:	movq   $0x0,0x8(%r15,%r14,1)
  1bb4b1:	add    $0x8,%r12
  1bb4b5:	cmp    %r12,%rbp
  1bb4b8:	jne    1bb390 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12510>
  1bb4be:	cmpb   $0x0,0x20(%rsp)
  1bb4c3:	je     1bb6d8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12858>
  1bb4c9:	mov    0x30(%rsp),%rdi
  1bb4ce:	cmp    %rdi,0x60(%rsp)
  1bb4d3:	jae    1bb7e7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12967>
  1bb4d9:	cmpq   $0x2,0x1e0(%rsp)
  1bb4e2:	mov    (%rsp),%rbp
  1bb4e6:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1bb4ec:	imul   $0x7b,%rbp,%rax
  1bb4f0:	mov    0x60(%rsp),%rsi
  1bb4f5:	lea    (%rsi,%r8,1),%r11
  1bb4f9:	xor    %ecx,%ecx
  1bb4fb:	mov    0x8(%rsp),%rbx
  1bb500:	mov    %rbx,%rdx
  1bb503:	sub    %r11,%rdx
  1bb506:	cmovb  %rcx,%rdx
  1bb50a:	lea    (%rsi,%rax,1),%r14
  1bb50e:	mov    %rbx,%r8
  1bb511:	sub    %r14,%r8
  1bb514:	cmovb  %rcx,%r8
  1bb518:	cmp    %r8,%rdx
  1bb51b:	mov    %r8,0x20(%rsp)
  1bb520:	cmovae %r8,%rdx
  1bb524:	mov    %rsi,%rcx
  1bb527:	not    %rcx
  1bb52a:	add    %rdi,%rcx
  1bb52d:	cmp    %rcx,%rdx
  1bb530:	cmovae %rcx,%rdx
  1bb534:	lea    0x1(%rdx),%rdi
  1bb538:	mov    %rsi,%r10
  1bb53b:	cmp    $0x22,%rdi
  1bb53f:	ja     1bbd29 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12ea9>
  1bb545:	mov    %rbx,%rsi
  1bb548:	imul   $0x7b0,%rbp,%r8
  1bb54f:	mov    %r10,%rdx
  1bb552:	shl    $0x4,%rdx
  1bb556:	add    %r15,%rdx
  1bb559:	imul   $0x7a0,%rbp,%r9
  1bb560:	mov    0x1d8(%rsp),%r11
  1bb568:	mov    0x30(%rsp),%rbx
  1bb56d:	nopl   (%rax)
  1bb570:	mov    0x10(%rsp),%rdi
  1bb575:	add    %r10,%rdi
  1bb578:	mov    %rsi,%r14
  1bb57b:	cmp    %rsi,%rdi
  1bb57e:	jae    1be848 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x159c8>
  1bb584:	lea    (%rax,%r10,1),%rdi
  1bb588:	cmp    %r14,%rdi
  1bb58b:	jae    1be83b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x159bb>
  1bb591:	inc    %r10
  1bb594:	movupd 0x10(%r11),%xmm0
  1bb59a:	movsd  (%rdx,%r9,1),%xmm1
  1bb5a0:	movsd  0x8(%rdx,%r9,1),%xmm2
  1bb5a7:	unpcklpd %xmm1,%xmm1
  1bb5ab:	mulpd  %xmm0,%xmm1
  1bb5af:	shufpd $0x1,%xmm0,%xmm0
  1bb5b4:	unpcklpd %xmm2,%xmm2
  1bb5b8:	mulpd  %xmm0,%xmm2
  1bb5bc:	movapd %xmm1,%xmm0
  1bb5c0:	subpd  %xmm2,%xmm0
  1bb5c4:	addpd  %xmm1,%xmm2
  1bb5c8:	movsd  %xmm0,%xmm2
  1bb5cc:	movupd %xmm2,(%rdx,%r8,1)
  1bb5d2:	add    $0x10,%rdx
  1bb5d6:	cmp    %r10,%rbx
  1bb5d9:	jne    1bb570 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x126f0>
  1bb5db:	imul   $0x7c,%rbp,%rdx
  1bb5df:	mov    0x60(%rsp),%rbp
  1bb5e4:	mov    0x18(%rsp),%rdi
  1bb5e9:	lea    (%rdi,%rbp,1),%r12
  1bb5ed:	xor    %r9d,%r9d
  1bb5f0:	mov    %rsi,%rbx
  1bb5f3:	mov    %rsi,%r10
  1bb5f6:	sub    %r12,%r10
  1bb5f9:	cmovb  %r9,%r10
  1bb5fd:	mov    0x20(%rsp),%rsi
  1bb602:	cmp    %rsi,%r10
  1bb605:	cmovae %rsi,%r10
  1bb609:	lea    (%rdx,%rbp,1),%r11
  1bb60d:	mov    %rbx,%rdi
  1bb610:	mov    %r11,0x10(%rsp)
  1bb615:	sub    %r11,%rdi
  1bb618:	cmovb  %r9,%rdi
  1bb61c:	cmp    %rdi,%r10
  1bb61f:	cmovb  %r10,%rdi
  1bb623:	cmp    %rcx,%rdi
  1bb626:	cmovae %rcx,%rdi
  1bb62a:	lea    0x1(%rdi),%r9
  1bb62e:	mov    %rbp,%r14
  1bb631:	cmp    $0x42,%r9
  1bb635:	ja     1bbf91 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13111>
  1bb63b:	mov    (%rsp),%r10
  1bb63f:	imul   $0x7c0,%r10,%rcx
  1bb646:	mov    %r14,%r12
  1bb649:	shl    $0x4,%r12
  1bb64d:	add    %r15,%r12
  1bb650:	imul   $0x790,%r10,%r9
  1bb657:	mov    0x28(%rsp),%r11
  1bb65c:	mov    0x30(%rsp),%rbx
  1bb661:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1bb670:	mov    0x18(%rsp),%rsi
  1bb675:	lea    (%rsi,%r14,1),%rdi
  1bb679:	mov    0x8(%rsp),%rsi
  1bb67e:	cmp    %rsi,%rdi
  1bb681:	jae    1be877 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x159f7>
  1bb687:	lea    (%rax,%r14,1),%rdi
  1bb68b:	cmp    %rsi,%rdi
  1bb68e:	jae    1be86a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x159ea>
  1bb694:	lea    (%rdx,%r14,1),%rdi
  1bb698:	cmp    %rsi,%rdi
  1bb69b:	jae    1be858 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x159d8>
  1bb6a1:	inc    %r14
  1bb6a4:	movupd (%r12,%r9,1),%xmm0
  1bb6aa:	movupd (%r12,%r8,1),%xmm1
  1bb6b0:	addpd  %xmm0,%xmm1
  1bb6b4:	movupd %xmm1,(%r12,%rcx,1)
  1bb6ba:	add    $0x10,%r12
  1bb6be:	cmp    %r14,%rbx
  1bb6c1:	jne    1bb670 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127f0>
  1bb6c3:	mov    0x1b0(%rsp),%r9
  1bb6cb:	mov    0x110(%rsp),%rbx
  1bb6d3:	jmp    1bb7ef <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1296f>
  1bb6d8:	cmpq   $0x2,0x1e0(%rsp)
  1bb6e1:	mov    0x1d8(%rsp),%rdx
  1bb6e9:	mov    0x8(%rsp),%rsi
  1bb6ee:	jb     1bedee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15f6e>
  1bb6f4:	imul   $0x7b,(%rsp),%r10
  1bb6f9:	xor    %ecx,%ecx
  1bb6fb:	nopl   0x0(%rax,%rax,1)
  1bb700:	mov    (%r11,%rcx,1),%rdi
  1bb704:	lea    (%rdi,%r8,1),%rax
  1bb708:	cmp    %rsi,%rax
  1bb70b:	jae    1be097 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15217>
  1bb711:	add    %r10,%rdi
  1bb714:	cmp    %rsi,%rdi
  1bb717:	jae    1be08a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1520a>
  1bb71d:	shl    $0x4,%rax
  1bb721:	shl    $0x4,%rdi
  1bb725:	movupd 0x10(%rdx),%xmm0
  1bb72a:	movsd  (%r15,%rax,1),%xmm1
  1bb730:	movsd  0x8(%r15,%rax,1),%xmm2
  1bb737:	unpcklpd %xmm1,%xmm1
  1bb73b:	mulpd  %xmm0,%xmm1
  1bb73f:	shufpd $0x1,%xmm0,%xmm0
  1bb744:	unpcklpd %xmm2,%xmm2
  1bb748:	mulpd  %xmm0,%xmm2
  1bb74c:	movapd %xmm1,%xmm0
  1bb750:	subpd  %xmm2,%xmm0
  1bb754:	addpd  %xmm1,%xmm2
  1bb758:	movsd  %xmm0,%xmm2
  1bb75c:	movupd %xmm2,(%r15,%rdi,1)
  1bb762:	add    $0x8,%rcx
  1bb766:	cmp    %rcx,%rbp
  1bb769:	jne    1bb700 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12880>
  1bb76b:	imul   $0x7c,(%rsp),%rdx
  1bb770:	xor    %r8d,%r8d
  1bb773:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1bb780:	mov    (%r11,%r8,1),%rdi
  1bb784:	mov    0x18(%rsp),%rax
  1bb789:	add    %rdi,%rax
  1bb78c:	cmp    %rsi,%rax
  1bb78f:	jae    1be0c4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15244>
  1bb795:	lea    (%rdi,%r10,1),%rcx
  1bb799:	cmp    %rsi,%rcx
  1bb79c:	jae    1be0b4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15234>
  1bb7a2:	add    %rdx,%rdi
  1bb7a5:	cmp    %rsi,%rdi
  1bb7a8:	jae    1be0a7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15227>
  1bb7ae:	shl    $0x4,%rax
  1bb7b2:	shl    $0x4,%rcx
  1bb7b6:	shl    $0x4,%rdi
  1bb7ba:	movupd (%r15,%rax,1),%xmm0
  1bb7c0:	movupd (%r15,%rcx,1),%xmm1
  1bb7c6:	addpd  %xmm0,%xmm1
  1bb7ca:	movupd %xmm1,(%r15,%rdi,1)
  1bb7d0:	add    $0x8,%r8
  1bb7d4:	cmp    %r8,%rbp
  1bb7d7:	jne    1bb780 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12900>
  1bb7d9:	mov    (%rsp),%r10
  1bb7dd:	mov    0x110(%rsp),%rbx
  1bb7e5:	jmp    1bb7ef <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1296f>
  1bb7e7:	mov    (%rsp),%r10
  1bb7eb:	imul   $0x7c,%r10,%rdx
  1bb7ef:	xor    %ecx,%ecx
  1bb7f1:	xorpd  %xmm0,%xmm0
  1bb7f5:	xor    %r14d,%r14d
  1bb7f8:	nopl   0x0(%rax,%rax,1)
  1bb800:	mov    (%r11,%rcx,8),%rdi
  1bb804:	lea    (%rdi,%rdx,1),%rax
  1bb808:	cmp    0x8(%rsp),%rax
  1bb80d:	jae    1bd95f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14adf>
  1bb813:	shl    $0x4,%rax
  1bb817:	movsd  (%r15,%rax,1),%xmm1
  1bb81d:	ucomisd %xmm0,%xmm1
  1bb821:	jne    1bb860 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x129e0>
  1bb823:	jp     1bb860 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x129e0>
  1bb825:	add    %r15,%rax
  1bb828:	movsd  0x8(%rax),%xmm1
  1bb82d:	ucomisd %xmm0,%xmm1
  1bb831:	jne    1bb860 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x129e0>
  1bb833:	jp     1bb860 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x129e0>
  1bb835:	cmp    0x1d0(%rsp),%rdi
  1bb83d:	jae    1be2ee <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1546e>
  1bb843:	mov    0x1c8(%rsp),%rax
  1bb84b:	movq   $0x7d,(%rax,%rdi,8)
  1bb853:	inc    %rcx
  1bb856:	cmp    %rcx,%r13
  1bb859:	jne    1bb800 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12980>
  1bb85b:	jmp    1bb878 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x129f8>
  1bb85d:	nopl   (%rax)
  1bb860:	cmp    %r9,%r14
  1bb863:	jae    1bdd5b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14edb>
  1bb869:	mov    %rdi,(%r11,%r14,8)
  1bb86d:	inc    %r14
  1bb870:	inc    %rcx
  1bb873:	cmp    %rcx,%r13
  1bb876:	jne    1bb800 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12980>
  1bb878:	cmp    %r9,%r14
  1bb87b:	ja     1bd3fe <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1457e>
  1bb881:	test   %r14,%r14
  1bb884:	mov    0x1d0(%rsp),%rdx
  1bb88c:	mov    0x90(%rsp),%rcx
  1bb894:	je     1bc806 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13986>
  1bb89a:	mov    (%r11),%rax
  1bb89d:	lea    -0x1(%r14),%rcx
  1bb8a1:	mov    -0x8(%r11,%r14,8),%rdx
  1bb8a6:	sub    %rax,%rdx
  1bb8a9:	setae  %sil
  1bb8ad:	cmp    %rcx,%rdx
  1bb8b0:	sete   %cl
  1bb8b3:	and    %sil,%cl
  1bb8b6:	cmp    $0x1,%cl
  1bb8b9:	jne    1bb8e8 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12a68>
  1bb8bb:	mov    %rax,%rcx
  1bb8be:	add    %r14,%rcx
  1bb8c1:	movabs $0x7fffffffffffffff,%rsi
  1bb8cb:	mov    0x8(%rsp),%rbx
  1bb8d0:	jb     1bd4da <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1465a>
  1bb8d6:	mov    $0x1,%dl
  1bb8d8:	mov    %edx,0x10(%rsp)
  1bb8dc:	mov    %rcx,0x30(%rsp)
  1bb8e1:	mov    %rax,0x60(%rsp)
  1bb8e6:	jmp    1bb8ff <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12a7f>
  1bb8e8:	movl   $0x0,0x10(%rsp)
  1bb8f0:	movabs $0x7fffffffffffffff,%rsi
  1bb8fa:	mov    0x8(%rsp),%rbx
  1bb8ff:	shl    $0x3,%r14
  1bb903:	mov    %r10,%r12
  1bb906:	shl    $0x7,%r12
  1bb90a:	mov    %r12,0x18(%rsp)
  1bb90f:	sub    %r10,%r12
  1bb912:	sub    %r10,%r12
  1bb915:	xor    %ebp,%ebp
  1bb917:	movapd 0x1fda6e0(%rip),%xmm8        # 2196000 <_fini+0x520>
  1bb920:	xorpd  %xmm9,%xmm9
  1bb925:	movsd  0x1fdbd9a(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1bb92e:	movapd 0x1fda6d9(%rip),%xmm11        # 2196010 <_fini+0x530>
  1bb937:	movsd  0x1fdbd80(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1bb940:	movabs $0x7ff0000000000000,%r8
  1bb94a:	nopw   0x0(%rax,%rax,1)
  1bb950:	mov    (%r11,%rbp,1),%r13
  1bb954:	cmp    %rbx,%r13
  1bb957:	jae    1bdcd7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14e57>
  1bb95d:	mov    %r13,%rdi
  1bb960:	shl    $0x4,%rdi
  1bb964:	movupd (%r15,%rdi,1),%xmm0
  1bb96a:	movapd %xmm0,%xmm2
  1bb96e:	andpd  %xmm8,%xmm2
  1bb973:	movapd %xmm0,%xmm1
  1bb977:	unpckhpd %xmm0,%xmm1
  1bb97b:	movapd %xmm1,%xmm3
  1bb97f:	andpd  %xmm8,%xmm3
  1bb984:	ucomisd %xmm9,%xmm0
  1bb989:	je     1bb9f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12b70>
  1bb98b:	ucomisd %xmm9,%xmm1
  1bb990:	je     1bb9f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12b70>
  1bb992:	movapd %xmm2,%xmm4
  1bb996:	cmplesd %xmm3,%xmm4
  1bb99b:	movapd %xmm4,%xmm5
  1bb99f:	andpd  %xmm3,%xmm5
  1bb9a3:	andnpd %xmm2,%xmm4
  1bb9a7:	orpd   %xmm5,%xmm4
  1bb9ab:	ucomisd %xmm6,%xmm4
  1bb9af:	jbe    1bb9f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12b70>
  1bb9b1:	ucomisd %xmm4,%xmm7
  1bb9b5:	jbe    1bb9f0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12b70>
  1bb9b7:	movapd %xmm0,%xmm2
  1bb9bb:	mulpd  %xmm0,%xmm2
  1bb9bf:	movapd %xmm2,%xmm3
  1bb9c3:	unpckhpd %xmm2,%xmm3
  1bb9c7:	addsd  %xmm2,%xmm3
  1bb9cb:	movapd %xmm10,%xmm2
  1bb9d0:	divsd  %xmm3,%xmm2
  1bb9d4:	mulsd  %xmm2,%xmm0
  1bb9d8:	xorpd  %xmm11,%xmm1
  1bb9dd:	mulsd  %xmm2,%xmm1
  1bb9e1:	jmp    1bbae3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12c63>
  1bb9e6:	cs nopw 0x0(%rax,%rax,1)
  1bb9f0:	ucomisd %xmm9,%xmm1
  1bb9f5:	setnp  %al
  1bb9f8:	sete   %cl
  1bb9fb:	and    %al,%cl
  1bb9fd:	movq   %xmm0,%rax
  1bba02:	and    %rsi,%rax
  1bba05:	cmp    %r8,%rax
  1bba08:	setl   %dl
  1bba0b:	test   %dl,%cl
  1bba0d:	je     1bba30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12bb0>
  1bba0f:	movapd %xmm10,%xmm2
  1bba14:	divsd  %xmm0,%xmm2
  1bba18:	xorpd  %xmm11,%xmm1
  1bba1d:	movapd %xmm2,%xmm0
  1bba21:	jmp    1bbae3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12c63>
  1bba26:	cs nopw 0x0(%rax,%rax,1)
  1bba30:	ucomisd %xmm9,%xmm0
  1bba35:	setnp  %cl
  1bba38:	sete   %dl
  1bba3b:	and    %cl,%dl
  1bba3d:	movq   %xmm1,%rcx
  1bba42:	and    %rsi,%rcx
  1bba45:	cmp    %r8,%rcx
  1bba48:	setl   %sil
  1bba4c:	test   %sil,%dl
  1bba4f:	je     1bba60 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12be0>
  1bba51:	movapd %xmm12,%xmm2
  1bba56:	divsd  %xmm1,%xmm2
  1bba5a:	movapd %xmm2,%xmm1
  1bba5e:	jmp    1bbad9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12c59>
  1bba60:	movabs $0x7fefffffffffffff,%rdx
  1bba6a:	cmp    %rdx,%rax
  1bba6d:	setg   %al
  1bba70:	cmp    %rdx,%rcx
  1bba73:	setg   %cl
  1bba76:	or     %al,%cl
  1bba78:	cmp    $0x1,%cl
  1bba7b:	jne    1bbb12 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12c92>
  1bba81:	add    %r15,%rdi
  1bba84:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1bba89:	movsd  0x1fdbc2e(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1bba92:	movapd 0x1fda575(%rip),%xmm11        # 2196010 <_fini+0x530>
  1bba9b:	movsd  0x1fdbc24(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1bbaa4:	xorpd  %xmm9,%xmm9
  1bbaa9:	movapd 0x1fda54e(%rip),%xmm8        # 2196000 <_fini+0x520>
  1bbab2:	movsd  0x1fdbbfe(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1bbaba:	movsd  0x1fdbbee(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1bbac2:	movabs $0x7ff0000000000000,%r8
  1bbacc:	mov    0x28(%rsp),%r11
  1bbad1:	mov    0x1b0(%rsp),%r9
  1bbad9:	movabs $0x7fffffffffffffff,%rsi
  1bbae3:	add    %r12,%r13
  1bbae6:	cmp    %rbx,%r13
  1bbae9:	jae    1bdcc4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14e44>
  1bbaef:	shl    $0x4,%r13
  1bbaf3:	movsd  %xmm0,(%r15,%r13,1)
  1bbaf9:	movsd  %xmm1,0x8(%r15,%r13,1)
  1bbb00:	add    $0x8,%rbp
  1bbb04:	cmp    %rbp,%r14
  1bbb07:	jne    1bb950 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12ad0>
  1bbb0d:	jmp    1bbb9c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12d1c>
  1bbb12:	ucomisd %xmm9,%xmm1
  1bbb17:	movabs $0x7fffffffffffffff,%rsi
  1bbb21:	jne    1bbb29 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12ca9>
  1bbb23:	jnp    1bba0f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12b8f>
  1bbb29:	ucomisd %xmm9,%xmm0
  1bbb2e:	jne    1bbb41 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12cc1>
  1bbb30:	jp     1bbb41 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12cc1>
  1bbb32:	movapd %xmm12,%xmm2
  1bbb37:	divsd  %xmm1,%xmm2
  1bbb3b:	movapd %xmm2,%xmm1
  1bbb3f:	jmp    1bbae3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12c63>
  1bbb41:	movapd %xmm3,%xmm1
  1bbb45:	cmplesd %xmm2,%xmm1
  1bbb4a:	movapd %xmm1,%xmm4
  1bbb4e:	andpd  %xmm2,%xmm4
  1bbb52:	andnpd %xmm3,%xmm1
  1bbb56:	orpd   %xmm4,%xmm1
  1bbb5a:	unpcklpd %xmm1,%xmm1
  1bbb5e:	divpd  %xmm1,%xmm0
  1bbb62:	movapd %xmm0,%xmm2
  1bbb66:	xorpd  %xmm11,%xmm2
  1bbb6b:	movsd  %xmm0,%xmm2
  1bbb6f:	mulpd  %xmm0,%xmm0
  1bbb73:	movapd %xmm0,%xmm3
  1bbb77:	unpcklpd %xmm0,%xmm3
  1bbb7b:	unpckhpd %xmm0,%xmm0
  1bbb7f:	addpd  %xmm3,%xmm0
  1bbb83:	divpd  %xmm0,%xmm2
  1bbb87:	divpd  %xmm1,%xmm2
  1bbb8b:	movapd %xmm2,%xmm0
  1bbb8f:	movapd %xmm2,%xmm1
  1bbb93:	unpckhpd %xmm2,%xmm1
  1bbb97:	jmp    1bbae3 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12c63>
  1bbb9c:	cmpb   $0x0,0x10(%rsp)
  1bbba1:	je     1bbc47 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12dc7>
  1bbba7:	mov    0x60(%rsp),%rbp
  1bbbac:	cmp    0x30(%rsp),%rbp
  1bbbb1:	mov    (%rsp),%r10
  1bbbb5:	mov    0x18(%rsp),%rdi
  1bbbba:	jae    1bc7b9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13939>
  1bbbc0:	cmpq   $0x5,0x1e0(%rsp)
  1bbbc9:	jb     1bf06b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161eb>
  1bbbcf:	imul   $0x71,%r10,%rax
  1bbbd3:	sub    %r10,%rdi
  1bbbd6:	mov    %rbp,%r9
  1bbbd9:	not    %r9
  1bbbdc:	add    0x30(%rsp),%r9
  1bbbe1:	lea    (%rax,%rbp,1),%r8
  1bbbe5:	xor    %edx,%edx
  1bbbe7:	mov    %rbx,%rcx
  1bbbea:	sub    %r8,%rcx
  1bbbed:	cmovb  %rdx,%rcx
  1bbbf1:	lea    (%r12,%rbp,1),%r11
  1bbbf5:	mov    %rbx,%rsi
  1bbbf8:	sub    %r11,%rsi
  1bbbfb:	cmovb  %rdx,%rsi
  1bbbff:	cmp    %rsi,%rcx
  1bbc02:	cmovb  %rcx,%rsi
  1bbc06:	mov    %rdi,0x18(%rsp)
  1bbc0b:	lea    (%rdi,%rbp,1),%r13
  1bbc0f:	mov    %rbx,%rcx
  1bbc12:	sub    %r13,%rcx
  1bbc15:	cmovb  %rdx,%rcx
  1bbc19:	cmp    %rcx,%rsi
  1bbc1c:	cmovb  %rsi,%rcx
  1bbc20:	cmp    %rcx,%r9
  1bbc23:	cmovb  %r9,%rcx
  1bbc27:	lea    0x1(%rcx),%rdx
  1bbc2b:	cmp    $0x22,%rdx
  1bbc2f:	ja     1bc2e4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13464>
  1bbc35:	mov    0x1b0(%rsp),%r9
  1bbc3d:	mov    0x28(%rsp),%r11
  1bbc42:	jmp    1bc6dd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1385d>
  1bbc47:	cmpq   $0x5,0x1e0(%rsp)
  1bbc50:	mov    (%rsp),%rax
  1bbc54:	mov    0x18(%rsp),%r10
  1bbc59:	jb     1bf06b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x161eb>
  1bbc5f:	imul   $0x71,%rax,%rdx
  1bbc63:	sub    %rax,%r10
  1bbc66:	xor    %esi,%esi
  1bbc68:	nopl   0x0(%rax,%rax,1)
  1bbc70:	mov    (%r11,%rsi,1),%rdi
  1bbc74:	lea    (%rdi,%rdx,1),%rax
  1bbc78:	cmp    %rbx,%rax
  1bbc7b:	jae    1be519 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15699>
  1bbc81:	lea    (%rdi,%r12,1),%rcx
  1bbc85:	cmp    %rbx,%rcx
  1bbc88:	jae    1be506 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15686>
  1bbc8e:	add    %r10,%rdi
  1bbc91:	cmp    %rbx,%rdi
  1bbc94:	jae    1be4f6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15676>
  1bbc9a:	shl    $0x4,%rax
  1bbc9e:	shl    $0x4,%rcx
  1bbca2:	mov    0x1d8(%rsp),%r8
  1bbcaa:	movupd 0x40(%r8),%xmm0
  1bbcb0:	movupd (%r15,%rax,1),%xmm1
  1bbcb6:	movapd %xmm0,%xmm2
  1bbcba:	mulpd  %xmm1,%xmm2
  1bbcbe:	shl    $0x4,%rdi
  1bbcc2:	movupd (%r15,%rcx,1),%xmm3
  1bbcc8:	movapd %xmm2,%xmm4
  1bbccc:	unpcklpd %xmm2,%xmm4
  1bbcd0:	unpckhpd %xmm2,%xmm2
  1bbcd4:	subpd  %xmm2,%xmm4
  1bbcd8:	mulpd  %xmm3,%xmm4
  1bbcdc:	movapd %xmm0,%xmm2
  1bbce0:	unpckhpd %xmm0,%xmm2
  1bbce4:	mulsd  %xmm1,%xmm2
  1bbce8:	unpckhpd %xmm1,%xmm1
  1bbcec:	mulsd  %xmm0,%xmm1
  1bbcf0:	addsd  %xmm2,%xmm1
  1bbcf4:	unpcklpd %xmm1,%xmm1
  1bbcf8:	shufpd $0x1,%xmm3,%xmm3
  1bbcfd:	mulpd  %xmm1,%xmm3
  1bbd01:	movapd %xmm4,%xmm0
  1bbd05:	subpd  %xmm3,%xmm0
  1bbd09:	addpd  %xmm4,%xmm3
  1bbd0d:	movsd  %xmm0,%xmm3
  1bbd11:	movupd %xmm3,(%r15,%rdi,1)
  1bbd17:	add    $0x8,%rsi
  1bbd1b:	cmp    %rsi,%r14
  1bbd1e:	jne    1bbc70 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12df0>
  1bbd24:	jmp    1bc7b9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13939>
  1bbd29:	xor    %edi,%edi
  1bbd2b:	mov    %rbx,%r8
  1bbd2e:	sub    %r11,%r8
  1bbd31:	cmovb  %rdi,%r8
  1bbd35:	mov    %rbx,%r9
  1bbd38:	sub    %r14,%r9
  1bbd3b:	cmovb  %rdi,%r9
  1bbd3f:	cmp    %r9,%r8
  1bbd42:	cmovb  %r8,%r9
  1bbd46:	cmp    %rcx,%r9
  1bbd49:	cmovae %rcx,%r9
  1bbd4d:	imul   $0x7a0,%rbp,%rdi
  1bbd54:	mov    %rsi,%r8
  1bbd57:	shl    $0x4,%r8
  1bbd5b:	lea    (%r15,%rdi,1),%r10
  1bbd5f:	lea    (%r8,%r10,1),%rbx
  1bbd63:	add    $0x8,%rbx
  1bbd67:	add    %r8,%r10
  1bbd6a:	mov    %r9,%r12
  1bbd6d:	shl    $0x4,%r12
  1bbd71:	add    %r10,%r12
  1bbd74:	add    $0x8,%r12
  1bbd78:	mov    %rsi,%r10
  1bbd7b:	cmp    %rbx,%r12
  1bbd7e:	mov    0x8(%rsp),%rbx
  1bbd83:	jb     1bb545 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x126c5>
  1bbd89:	mov    %rsi,%r10
  1bbd8c:	movabs $0xfffffffffffffff,%r12
  1bbd96:	cmp    %r12,%r9
  1bbd99:	ja     1bb545 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x126c5>
  1bbd9f:	imul   $0x7b0,%rbp,%r9
  1bbda6:	xor    %r10d,%r10d
  1bbda9:	mov    0x8(%rsp),%rbx
  1bbdae:	sub    %r11,%rbx
  1bbdb1:	cmovb  %r10,%rbx
  1bbdb5:	mov    0x8(%rsp),%r11
  1bbdba:	sub    %r14,%r11
  1bbdbd:	cmovb  %r10,%r11
  1bbdc1:	cmp    %r11,%rbx
  1bbdc4:	cmovb  %rbx,%r11
  1bbdc8:	lea    (%r9,%r8,1),%r10
  1bbdcc:	cmp    %rcx,%r11
  1bbdcf:	cmovae %rcx,%r11
  1bbdd3:	lea    (%r15,%r10,1),%rbx
  1bbdd7:	shl    $0x4,%r11
  1bbddb:	lea    (%r11,%rbx,1),%r12
  1bbddf:	add    $0x8,%r12
  1bbde3:	lea    0x8(%r15,%r10,1),%r10
  1bbde8:	mov    %r10,0x100(%rsp)
  1bbdf0:	lea    0x10(%r11,%rbx,1),%r14
  1bbdf5:	mov    %r14,0x40(%rsp)
  1bbdfa:	lea    (%rdi,%r8,1),%r10
  1bbdfe:	mov    %r10,0x48(%rsp)
  1bbe03:	add    %r15,%r10
  1bbe06:	lea    (%r11,%r10,1),%rbp
  1bbe0a:	add    $0x8,%rbp
  1bbe0e:	mov    %rbp,0xb0(%rsp)
  1bbe16:	lea    (%r11,%r10,1),%rbp
  1bbe1a:	add    $0x10,%rbp
  1bbe1e:	cmp    %r14,%rbx
  1bbe21:	setb   0x50(%rsp)
  1bbe26:	mov    0x100(%rsp),%r14
  1bbe2e:	cmp    %r12,%r14
  1bbe31:	setb   0x38(%rsp)
  1bbe36:	mov    0xb0(%rsp),%r11
  1bbe3e:	cmp    %r11,%rbx
  1bbe41:	setb   0xd0(%rsp)
  1bbe49:	cmp    %r12,%r10
  1bbe4c:	setb   0xe0(%rsp)
  1bbe54:	cmp    %rbp,%rbx
  1bbe57:	mov    0x48(%rsp),%rbx
  1bbe5c:	lea    0x8(%r15,%rbx,1),%rbx
  1bbe61:	setb   0x48(%rsp)
  1bbe66:	cmp    %r12,%rbx
  1bbe69:	setb   0x58(%rsp)
  1bbe6e:	cmp    %r11,%r14
  1bbe71:	mov    %r14,%r12
  1bbe74:	setb   %r14b
  1bbe78:	mov    0x40(%rsp),%r11
  1bbe7d:	cmp    %r11,%r10
  1bbe80:	setb   0xb0(%rsp)
  1bbe88:	cmp    %rbp,%r12
  1bbe8b:	setb   %r12b
  1bbe8f:	cmp    %r11,%rbx
  1bbe92:	mov    (%rsp),%rbp
  1bbe96:	mov    0x8(%rsp),%rbx
  1bbe9b:	setb   0x40(%rsp)
  1bbea0:	mov    %rsi,%r10
  1bbea3:	movzbl 0x38(%rsp),%r11d
  1bbea9:	test   %r11b,0x50(%rsp)
  1bbeae:	jne    1bb545 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x126c5>
  1bbeb4:	mov    %rsi,%r10
  1bbeb7:	movzbl 0xe0(%rsp),%r11d
  1bbec0:	and    %r11b,0xd0(%rsp)
  1bbec8:	jne    1bb545 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x126c5>
  1bbece:	mov    %rsi,%r10
  1bbed1:	movzbl 0x58(%rsp),%r11d
  1bbed7:	and    %r11b,0x48(%rsp)
  1bbedc:	jne    1bb545 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x126c5>
  1bbee2:	mov    %rsi,%r10
  1bbee5:	and    0xb0(%rsp),%r14b
  1bbeed:	jne    1bb545 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x126c5>
  1bbef3:	mov    %rsi,%r10
  1bbef6:	and    0x40(%rsp),%r12b
  1bbefb:	jne    1bb545 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x126c5>
  1bbf01:	and    $0xfffffffffffffffe,%rdx
  1bbf05:	lea    (%rsi,%rdx,1),%r10
  1bbf09:	mov    0x1d8(%rsp),%r11
  1bbf11:	movsd  0x10(%r11),%xmm0
  1bbf17:	movsd  0x18(%r11),%xmm1
  1bbf1d:	unpcklpd %xmm1,%xmm1
  1bbf21:	unpcklpd %xmm0,%xmm0
  1bbf25:	add    %r15,%r8
  1bbf28:	nopl   0x0(%rax,%rax,1)
  1bbf30:	movupd (%r8,%rdi,1),%xmm2
  1bbf36:	movupd 0x10(%r8,%rdi,1),%xmm3
  1bbf3d:	movapd %xmm2,%xmm4
  1bbf41:	unpcklpd %xmm3,%xmm4
  1bbf45:	unpckhpd %xmm3,%xmm2
  1bbf49:	movapd %xmm1,%xmm3
  1bbf4d:	mulpd  %xmm4,%xmm3
  1bbf51:	movapd %xmm0,%xmm5
  1bbf55:	mulpd  %xmm2,%xmm5
  1bbf59:	addpd  %xmm3,%xmm5
  1bbf5d:	mulpd  %xmm0,%xmm4
  1bbf61:	mulpd  %xmm1,%xmm2
  1bbf65:	subpd  %xmm2,%xmm4
  1bbf69:	movapd %xmm4,%xmm2
  1bbf6d:	unpcklpd %xmm5,%xmm2
  1bbf71:	unpckhpd %xmm5,%xmm4
  1bbf75:	movupd %xmm4,0x10(%r8,%r9,1)
  1bbf7c:	movupd %xmm2,(%r8,%r9,1)
  1bbf82:	add    $0x20,%r8
  1bbf86:	add    $0xfffffffffffffffe,%rdx
  1bbf8a:	jne    1bbf30 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x130b0>
  1bbf8c:	jmp    1bb545 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x126c5>
  1bbf91:	xor    %r9d,%r9d
  1bbf94:	mov    %rbx,%r10
  1bbf97:	sub    %r12,%r10
  1bbf9a:	cmovb  %r9,%r10
  1bbf9e:	cmp    %rsi,%r10
  1bbfa1:	cmovae %rsi,%r10
  1bbfa5:	mov    %rbx,%r11
  1bbfa8:	sub    0x10(%rsp),%r11
  1bbfad:	cmovb  %r9,%r11
  1bbfb1:	cmp    %r11,%r10
  1bbfb4:	cmovb  %r10,%r11
  1bbfb8:	cmp    %rcx,%r11
  1bbfbb:	cmovae %rcx,%r11
  1bbfbf:	imul   $0x790,(%rsp),%r9
  1bbfc7:	mov    %rbp,%r10
  1bbfca:	shl    $0x4,%r10
  1bbfce:	mov    %r9,0x38(%rsp)
  1bbfd3:	lea    (%r15,%r9,1),%rbx
  1bbfd7:	mov    %r12,0x50(%rsp)
  1bbfdc:	lea    (%r10,%rbx,1),%r12
  1bbfe0:	add    $0x8,%r12
  1bbfe4:	add    %r10,%rbx
  1bbfe7:	mov    %r11,%r9
  1bbfea:	shl    $0x4,%r9
  1bbfee:	add    %r9,%rbx
  1bbff1:	add    $0x8,%rbx
  1bbff5:	mov    %rbp,%r14
  1bbff8:	cmp    %r12,%rbx
  1bbffb:	jb     1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc001:	lea    (%r15,%r8,1),%rbx
  1bc005:	lea    (%r10,%rbx,1),%r12
  1bc009:	add    $0x8,%r12
  1bc00d:	add    %r10,%rbx
  1bc010:	add    %rbx,%r9
  1bc013:	add    $0x8,%r9
  1bc017:	mov    %rbp,%r14
  1bc01a:	cmp    %r12,%r9
  1bc01d:	mov    0x50(%rsp),%r12
  1bc022:	jb     1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc028:	mov    %rbp,%r14
  1bc02b:	movabs $0xfffffffffffffff,%r9
  1bc035:	cmp    %r9,%r11
  1bc038:	ja     1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc03e:	imul   $0x7c0,(%rsp),%r11
  1bc046:	xor    %r9d,%r9d
  1bc049:	mov    0x8(%rsp),%rbx
  1bc04e:	sub    %r12,%rbx
  1bc051:	cmovb  %r9,%rbx
  1bc055:	cmp    %rsi,%rbx
  1bc058:	cmovae %rsi,%rbx
  1bc05c:	mov    0x8(%rsp),%rsi
  1bc061:	sub    0x10(%rsp),%rsi
  1bc066:	cmovb  %r9,%rsi
  1bc06a:	mov    %r11,0x120(%rsp)
  1bc072:	lea    (%r11,%r10,1),%r14
  1bc076:	cmp    %rsi,%rbx
  1bc079:	cmovb  %rbx,%rsi
  1bc07d:	lea    (%r15,%r14,1),%r9
  1bc081:	cmp    %rcx,%rsi
  1bc084:	cmovae %rcx,%rsi
  1bc088:	shl    $0x4,%rsi
  1bc08c:	lea    (%rsi,%r9,1),%rcx
  1bc090:	add    $0x8,%rcx
  1bc094:	lea    0x8(%r15,%r14,1),%r14
  1bc099:	lea    0x10(%rsi,%r9,1),%r11
  1bc09e:	mov    %r11,0x10(%rsp)
  1bc0a3:	mov    0x38(%rsp),%r11
  1bc0a8:	lea    (%r11,%r10,1),%r12
  1bc0ac:	lea    (%r15,%r12,1),%r11
  1bc0b0:	lea    0x8(%r15,%r12,1),%rbx
  1bc0b5:	mov    %rbx,0xd0(%rsp)
  1bc0bd:	lea    0x10(%rsi,%r11,1),%rbx
  1bc0c2:	mov    %rbx,0x50(%rsp)
  1bc0c7:	mov    %r11,%rbx
  1bc0ca:	mov    %r11,0x40(%rsp)
  1bc0cf:	lea    (%r8,%r10,1),%r11
  1bc0d3:	lea    (%r15,%r11,1),%r12
  1bc0d7:	lea    0x8(%r15,%r11,1),%r11
  1bc0dc:	mov    %r11,0x48(%rsp)
  1bc0e1:	lea    0x10(%rsi,%r12,1),%r11
  1bc0e6:	mov    %r11,0x58(%rsp)
  1bc0eb:	lea    0x8(%rsi,%rbx,1),%rbx
  1bc0f0:	mov    %rbx,0xe0(%rsp)
  1bc0f8:	add    %r12,%rsi
  1bc0fb:	add    $0x8,%rsi
  1bc0ff:	mov    %rsi,0x20(%rsp)
  1bc104:	cmp    0x10(%rsp),%r9
  1bc109:	setb   0x100(%rsp)
  1bc111:	cmp    %rcx,%r14
  1bc114:	setb   0xb0(%rsp)
  1bc11c:	cmp    0x50(%rsp),%r9
  1bc121:	setb   0x88(%rsp)
  1bc129:	mov    0xd0(%rsp),%rsi
  1bc131:	cmp    %rcx,%rsi
  1bc134:	setb   0x78(%rsp)
  1bc139:	mov    0x58(%rsp),%rbx
  1bc13e:	cmp    %rbx,%r9
  1bc141:	setb   0x80(%rsp)
  1bc149:	cmp    %rcx,0x48(%rsp)
  1bc14e:	setb   0x98(%rsp)
  1bc156:	mov    0xe0(%rsp),%r11
  1bc15e:	cmp    %r11,%r9
  1bc161:	setb   0xc8(%rsp)
  1bc169:	cmp    %rcx,0x40(%rsp)
  1bc16e:	setb   0xa8(%rsp)
  1bc176:	cmp    0x20(%rsp),%r9
  1bc17b:	setb   0xf8(%rsp)
  1bc183:	cmp    %rcx,%r12
  1bc186:	setb   0x118(%rsp)
  1bc18e:	cmp    0x50(%rsp),%r14
  1bc193:	setb   0x50(%rsp)
  1bc198:	mov    0x10(%rsp),%rcx
  1bc19d:	cmp    %rcx,%rsi
  1bc1a0:	setb   0xd0(%rsp)
  1bc1a8:	cmp    %rbx,%r14
  1bc1ab:	setb   0x58(%rsp)
  1bc1b0:	cmp    %rcx,0x48(%rsp)
  1bc1b5:	setb   0x48(%rsp)
  1bc1ba:	cmp    %r11,%r14
  1bc1bd:	setb   0xe0(%rsp)
  1bc1c5:	cmp    %rcx,0x40(%rsp)
  1bc1ca:	mov    %rcx,%r11
  1bc1cd:	setb   %sil
  1bc1d1:	cmp    0x20(%rsp),%r14
  1bc1d6:	setb   %cl
  1bc1d9:	cmp    %r11,%r12
  1bc1dc:	mov    %rbp,%r14
  1bc1df:	setb   %r11b
  1bc1e3:	movzbl 0xb0(%rsp),%r12d
  1bc1ec:	test   %r12b,0x100(%rsp)
  1bc1f4:	jne    1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc1fa:	mov    %rbp,%r14
  1bc1fd:	movzbl 0x78(%rsp),%r12d
  1bc203:	and    %r12b,0x88(%rsp)
  1bc20b:	jne    1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc211:	mov    %rbp,%r14
  1bc214:	movzbl 0x98(%rsp),%r12d
  1bc21d:	and    %r12b,0x80(%rsp)
  1bc225:	jne    1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc22b:	mov    %rbp,%r14
  1bc22e:	movzbl 0xa8(%rsp),%r12d
  1bc237:	and    %r12b,0xc8(%rsp)
  1bc23f:	jne    1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc245:	mov    %rbp,%r14
  1bc248:	movzbl 0x118(%rsp),%r12d
  1bc251:	and    %r12b,0xf8(%rsp)
  1bc259:	jne    1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc25f:	mov    %rbp,%r14
  1bc262:	movzbl 0xd0(%rsp),%r12d
  1bc26b:	and    %r12b,0x50(%rsp)
  1bc270:	jne    1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc276:	mov    %rbp,%r14
  1bc279:	movzbl 0x48(%rsp),%r12d
  1bc27f:	and    %r12b,0x58(%rsp)
  1bc284:	jne    1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc28a:	mov    %rbp,%r14
  1bc28d:	and    %sil,0xe0(%rsp)
  1bc295:	jne    1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc29b:	mov    %rbp,%r14
  1bc29e:	and    %r11b,%cl
  1bc2a1:	jne    1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc2a7:	and    $0xfffffffffffffffe,%rdi
  1bc2ab:	lea    (%rdi,%rbp,1),%r14
  1bc2af:	add    %r15,%r10
  1bc2b2:	mov    0x38(%rsp),%rcx
  1bc2b7:	mov    0x120(%rsp),%rsi
  1bc2bf:	nop
  1bc2c0:	movupd (%r10,%rcx,1),%xmm0
  1bc2c6:	movupd (%r10,%r8,1),%xmm1
  1bc2cc:	addpd  %xmm0,%xmm1
  1bc2d0:	movupd %xmm1,(%r10,%rsi,1)
  1bc2d6:	add    $0x10,%r10
  1bc2da:	dec    %rdi
  1bc2dd:	jne    1bc2c0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13440>
  1bc2df:	jmp    1bb63b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x127bb>
  1bc2e4:	xor    %edx,%edx
  1bc2e6:	mov    %rbx,%rsi
  1bc2e9:	mov    %r8,0x10(%rsp)
  1bc2ee:	sub    %r8,%rsi
  1bc2f1:	cmovb  %rdx,%rsi
  1bc2f5:	mov    %rbx,%rdi
  1bc2f8:	sub    %r11,%rdi
  1bc2fb:	cmovb  %rdx,%rdi
  1bc2ff:	cmp    %rdi,%rsi
  1bc302:	cmovb  %rsi,%rdi
  1bc306:	mov    %rbx,%r8
  1bc309:	sub    %r13,%r8
  1bc30c:	cmovb  %rdx,%r8
  1bc310:	cmp    %r8,%rdi
  1bc313:	cmovb  %rdi,%r8
  1bc317:	cmp    %r8,%r9
  1bc31a:	cmovb  %r9,%r8
  1bc31e:	imul   $0x710,%r10,%rdx
  1bc325:	mov    %rbp,%rsi
  1bc328:	shl    $0x4,%rsi
  1bc32c:	lea    (%r15,%rdx,1),%rdi
  1bc330:	lea    (%rsi,%rdi,1),%rbx
  1bc334:	add    $0x8,%rbx
  1bc338:	add    %rsi,%rdi
  1bc33b:	mov    %r8,%rbp
  1bc33e:	shl    $0x4,%rbp
  1bc342:	add    %rbp,%rdi
  1bc345:	add    $0x8,%rdi
  1bc349:	cmp    %rbx,%rdi
  1bc34c:	jb     1bc6bb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1383b>
  1bc352:	imul   $0x7e0,%r10,%rdi
  1bc359:	lea    (%r15,%rdi,1),%rbx
  1bc35d:	lea    (%rsi,%rbx,1),%r10
  1bc361:	add    $0x8,%r10
  1bc365:	add    %rsi,%rbx
  1bc368:	add    %rbp,%rbx
  1bc36b:	add    $0x8,%rbx
  1bc36f:	cmp    %r10,%rbx
  1bc372:	jb     1bc6c2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13842>
  1bc378:	movabs $0xfffffffffffffff,%r10
  1bc382:	cmp    %r10,%r8
  1bc385:	mov    0x8(%rsp),%rbx
  1bc38a:	ja     1bc6c7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13847>
  1bc390:	imul   $0x7f0,(%rsp),%r8
  1bc398:	xor    %ebp,%ebp
  1bc39a:	mov    %rbx,%r10
  1bc39d:	sub    0x10(%rsp),%rbx
  1bc3a2:	cmovb  %rbp,%rbx
  1bc3a6:	mov    %r10,%rbp
  1bc3a9:	sub    %r11,%rbp
  1bc3ac:	mov    $0x0,%r11d
  1bc3b2:	cmovb  %r11,%rbp
  1bc3b6:	cmp    %rbp,%rbx
  1bc3b9:	cmovb  %rbx,%rbp
  1bc3bd:	mov    %r10,%rbx
  1bc3c0:	sub    %r13,%rbx
  1bc3c3:	cmovb  %r11,%rbx
  1bc3c7:	cmp    %rbx,%rbp
  1bc3ca:	cmovb  %rbp,%rbx
  1bc3ce:	lea    (%r8,%rsi,1),%r13
  1bc3d2:	cmp    %rbx,%r9
  1bc3d5:	cmovb  %r9,%rbx
  1bc3d9:	lea    (%r15,%r13,1),%r10
  1bc3dd:	shl    $0x4,%rbx
  1bc3e1:	lea    (%rbx,%r10,1),%r11
  1bc3e5:	add    $0x8,%r11
  1bc3e9:	lea    0x8(%r15,%r13,1),%r9
  1bc3ee:	mov    %r9,0x50(%rsp)
  1bc3f3:	lea    0x10(%rbx,%r10,1),%r9
  1bc3f8:	mov    %r9,0x10(%rsp)
  1bc3fd:	lea    (%rdx,%rsi,1),%r9
  1bc401:	lea    (%r15,%r9,1),%r13
  1bc405:	lea    0x8(%rbx,%r13,1),%rbp
  1bc40a:	mov    %rbp,0x40(%rsp)
  1bc40f:	lea    0x8(%r15,%r9,1),%r9
  1bc414:	mov    %r9,0xd0(%rsp)
  1bc41c:	lea    0x10(%rbx,%r13,1),%r9
  1bc421:	mov    %r9,0x38(%rsp)
  1bc426:	lea    (%rdi,%rsi,1),%r9
  1bc42a:	mov    %r9,0xb0(%rsp)
  1bc432:	add    %r15,%r9
  1bc435:	lea    0x8(%rbx,%r9,1),%rbp
  1bc43a:	mov    %rbp,0x20(%rsp)
  1bc43f:	add    %r9,%rbx
  1bc442:	add    $0x10,%rbx
  1bc446:	mov    %rbx,0xe0(%rsp)
  1bc44e:	cmp    0x10(%rsp),%r10
  1bc453:	setb   0x48(%rsp)
  1bc458:	cmp    %r11,0x50(%rsp)
  1bc45d:	setb   0x100(%rsp)
  1bc465:	cmp    0x40(%rsp),%r10
  1bc46a:	setb   0x58(%rsp)
  1bc46f:	cmp    %r11,%r13
  1bc472:	setb   0x88(%rsp)
  1bc47a:	cmp    0x38(%rsp),%r10
  1bc47f:	setb   0x78(%rsp)
  1bc484:	mov    0xd0(%rsp),%rbp
  1bc48c:	cmp    %r11,%rbp
  1bc48f:	setb   0x80(%rsp)
  1bc497:	cmp    0x20(%rsp),%r10
  1bc49c:	setb   0x98(%rsp)
  1bc4a4:	cmp    %r11,%r9
  1bc4a7:	setb   0xc8(%rsp)
  1bc4af:	cmp    %rbx,%r10
  1bc4b2:	mov    0xb0(%rsp),%r10
  1bc4ba:	lea    0x8(%r15,%r10,1),%rbx
  1bc4bf:	setb   0xb0(%rsp)
  1bc4c7:	cmp    %r11,%rbx
  1bc4ca:	setb   0xa8(%rsp)
  1bc4d2:	mov    0x50(%rsp),%r11
  1bc4d7:	cmp    0x40(%rsp),%r11
  1bc4dc:	setb   0x40(%rsp)
  1bc4e1:	mov    0x10(%rsp),%r10
  1bc4e6:	cmp    %r10,%r13
  1bc4e9:	setb   0xf8(%rsp)
  1bc4f1:	cmp    0x38(%rsp),%r11
  1bc4f6:	setb   0x38(%rsp)
  1bc4fb:	cmp    %r10,%rbp
  1bc4fe:	setb   0xd0(%rsp)
  1bc506:	cmp    0x20(%rsp),%r11
  1bc50b:	mov    %r11,%rbp
  1bc50e:	setb   0x20(%rsp)
  1bc513:	cmp    %r10,%r9
  1bc516:	mov    %r10,%r13
  1bc519:	setb   %r11b
  1bc51d:	cmp    0xe0(%rsp),%rbp
  1bc525:	setb   %r10b
  1bc529:	cmp    %r13,%rbx
  1bc52c:	setb   %r9b
  1bc530:	movzbl 0x100(%rsp),%ebx
  1bc538:	test   %bl,0x48(%rsp)
  1bc53c:	jne    1bc6c2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13842>
  1bc542:	movzbl 0x88(%rsp),%ebx
  1bc54a:	and    %bl,0x58(%rsp)
  1bc54e:	jne    1bc6c2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13842>
  1bc554:	movzbl 0x80(%rsp),%ebx
  1bc55c:	and    %bl,0x78(%rsp)
  1bc560:	mov    0x8(%rsp),%rbx
  1bc565:	mov    0x18(%rsp),%r13
  1bc56a:	jne    1bd264 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x143e4>
  1bc570:	movzbl 0xc8(%rsp),%ebp
  1bc578:	and    %bpl,0x98(%rsp)
  1bc580:	jne    1bd264 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x143e4>
  1bc586:	movzbl 0xa8(%rsp),%ebp
  1bc58e:	and    %bpl,0xb0(%rsp)
  1bc596:	jne    1bd264 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x143e4>
  1bc59c:	movzbl 0xf8(%rsp),%ebp
  1bc5a4:	and    %bpl,0x40(%rsp)
  1bc5a9:	jne    1bd264 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x143e4>
  1bc5af:	mov    %r9d,%ebp
  1bc5b2:	movzbl 0xd0(%rsp),%r9d
  1bc5bb:	and    %r9b,0x38(%rsp)
  1bc5c0:	jne    1bd264 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x143e4>
  1bc5c6:	and    %r11b,0x20(%rsp)
  1bc5cb:	mov    0x1b0(%rsp),%r9
  1bc5d3:	jne    1bd25e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x143de>
  1bc5d9:	and    %bpl,%r10b
  1bc5dc:	mov    0x28(%rsp),%r11
  1bc5e1:	jne    1bd250 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x143d0>
  1bc5e7:	and    $0xfffffffffffffffe,%rcx
  1bc5eb:	mov    0x60(%rsp),%rbp
  1bc5f0:	add    %rcx,%rbp
  1bc5f3:	mov    0x1d8(%rsp),%r9
  1bc5fb:	movsd  0x40(%r9),%xmm0
  1bc601:	movsd  0x48(%r9),%xmm1
  1bc607:	unpcklpd %xmm1,%xmm1
  1bc60b:	unpcklpd %xmm0,%xmm0
  1bc60f:	add    %r15,%rsi
  1bc612:	mov    (%rsp),%r10
  1bc616:	cs nopw 0x0(%rax,%rax,1)
  1bc620:	movupd (%rsi,%rdx,1),%xmm3
  1bc625:	movupd 0x10(%rsi,%rdx,1),%xmm4
  1bc62b:	movapd %xmm3,%xmm2
  1bc62f:	unpcklpd %xmm4,%xmm2
  1bc633:	unpckhpd %xmm4,%xmm3
  1bc637:	movapd %xmm1,%xmm4
  1bc63b:	mulpd  %xmm2,%xmm4
  1bc63f:	movapd %xmm0,%xmm5
  1bc643:	mulpd  %xmm3,%xmm5
  1bc647:	addpd  %xmm4,%xmm5
  1bc64b:	movupd (%rsi,%rdi,1),%xmm4
  1bc650:	movupd 0x10(%rsi,%rdi,1),%xmm6
  1bc656:	movapd %xmm4,%xmm7
  1bc65a:	unpcklpd %xmm6,%xmm7
  1bc65e:	unpckhpd %xmm6,%xmm4
  1bc662:	movapd %xmm7,%xmm6
  1bc666:	mulpd  %xmm5,%xmm6
  1bc66a:	mulpd  %xmm0,%xmm2
  1bc66e:	mulpd  %xmm1,%xmm3
  1bc672:	subpd  %xmm3,%xmm2
  1bc676:	mulpd  %xmm2,%xmm7
  1bc67a:	mulpd  %xmm4,%xmm2
  1bc67e:	addpd  %xmm6,%xmm2
  1bc682:	mulpd  %xmm5,%xmm4
  1bc686:	subpd  %xmm4,%xmm7
  1bc68a:	movapd %xmm7,%xmm3
  1bc68e:	unpcklpd %xmm2,%xmm3
  1bc692:	unpckhpd %xmm2,%xmm7
  1bc696:	movupd %xmm7,0x10(%rsi,%r8,1)
  1bc69d:	movupd %xmm3,(%rsi,%r8,1)
  1bc6a3:	add    $0x20,%rsi
  1bc6a7:	add    $0xfffffffffffffffe,%rcx
  1bc6ab:	jne    1bc620 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x137a0>
  1bc6b1:	mov    0x1b0(%rsp),%r9
  1bc6b9:	jmp    1bc6e2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13862>
  1bc6bb:	mov    0x8(%rsp),%rbx
  1bc6c0:	jmp    1bc6cb <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1384b>
  1bc6c2:	mov    0x8(%rsp),%rbx
  1bc6c7:	mov    (%rsp),%r10
  1bc6cb:	mov    0x1b0(%rsp),%r9
  1bc6d3:	mov    0x28(%rsp),%r11
  1bc6d8:	mov    0x60(%rsp),%rbp
  1bc6dd:	mov    0x18(%rsp),%r13
  1bc6e2:	imul   $0x7f0,%r10,%rcx
  1bc6e9:	mov    %rbp,%rdx
  1bc6ec:	shl    $0x4,%rdx
  1bc6f0:	add    %r15,%rdx
  1bc6f3:	imul   $0x7e0,%r10,%rsi
  1bc6fa:	imul   $0x710,%r10,%r8
  1bc701:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1bc710:	lea    (%rax,%rbp,1),%rdi
  1bc714:	cmp    %rbx,%rdi
  1bc717:	jae    1bed72 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ef2>
  1bc71d:	lea    (%r12,%rbp,1),%rdi
  1bc721:	cmp    %rbx,%rdi
  1bc724:	jae    1bed62 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ee2>
  1bc72a:	mov    %r13,%rdi
  1bc72d:	add    %rbp,%rdi
  1bc730:	cmp    %rbx,%rdi
  1bc733:	jae    1bed52 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15ed2>
  1bc739:	inc    %rbp
  1bc73c:	mov    0x1d8(%rsp),%rdi
  1bc744:	movupd 0x40(%rdi),%xmm0
  1bc749:	movupd (%rdx,%r8,1),%xmm1
  1bc74f:	movapd %xmm0,%xmm2
  1bc753:	mulpd  %xmm1,%xmm2
  1bc757:	movupd (%rdx,%rsi,1),%xmm3
  1bc75c:	movapd %xmm2,%xmm4
  1bc760:	unpcklpd %xmm2,%xmm4
  1bc764:	unpckhpd %xmm2,%xmm2
  1bc768:	subpd  %xmm2,%xmm4
  1bc76c:	mulpd  %xmm3,%xmm4
  1bc770:	movapd %xmm1,%xmm2
  1bc774:	unpckhpd %xmm1,%xmm2
  1bc778:	mulsd  %xmm0,%xmm2
  1bc77c:	unpckhpd %xmm0,%xmm0
  1bc780:	mulsd  %xmm1,%xmm0
  1bc784:	addsd  %xmm2,%xmm0
  1bc788:	unpcklpd %xmm0,%xmm0
  1bc78c:	shufpd $0x1,%xmm3,%xmm3
  1bc791:	mulpd  %xmm0,%xmm3
  1bc795:	movapd %xmm4,%xmm0
  1bc799:	subpd  %xmm3,%xmm0
  1bc79d:	addpd  %xmm4,%xmm3
  1bc7a1:	movsd  %xmm0,%xmm3
  1bc7a5:	movupd %xmm3,(%rdx,%rcx,1)
  1bc7aa:	add    $0x10,%rdx
  1bc7ae:	cmp    %rbp,0x30(%rsp)
  1bc7b3:	jne    1bc710 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13890>
  1bc7b9:	xor    %eax,%eax
  1bc7bb:	mov    0x1d0(%rsp),%rdx
  1bc7c3:	mov    0x90(%rsp),%rcx
  1bc7cb:	mov    0x110(%rsp),%rbx
  1bc7d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1bc7e0:	mov    (%r11,%rax,1),%rdi
  1bc7e4:	cmp    %rdx,%rdi
  1bc7e7:	jae    1bdcea <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14e6a>
  1bc7ed:	mov    0x1c8(%rsp),%r8
  1bc7f5:	movq   $0x80,(%r8,%rdi,8)
  1bc7fd:	add    $0x8,%rax
  1bc801:	cmp    %rax,%r14
  1bc804:	jne    1bc7e0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13960>
  1bc806:	xor    %eax,%eax
  1bc808:	xor    %ebp,%ebp
  1bc80a:	mov    0x1c0(%rsp),%r13
  1bc812:	mov    0x1c8(%rsp),%r8
  1bc81a:	mov    $0x1,%r14d
  1bc820:	movabs $0x7ff0000000000000,%r10
  1bc82a:	jmp    1bc840 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x139c0>
  1bc82c:	nopl   0x0(%rax)
  1bc830:	mov    %rdi,(%r11,%rbp,8)
  1bc834:	inc    %rbp
  1bc837:	add    $0x8,%rax
  1bc83b:	cmp    %rax,%rcx
  1bc83e:	je     1bc86c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x139ec>
  1bc840:	mov    (%rbx,%rax,1),%rdi
  1bc844:	cmp    %rdx,%rdi
  1bc847:	jae    1bd64a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x147ca>
  1bc84d:	cmpq   $0x7e,(%r8,%rdi,8)
  1bc852:	jae    1bc837 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x139b7>
  1bc854:	cmp    %r9,%rbp
  1bc857:	jb     1bc830 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x139b0>
  1bc859:	lea    0x2466b48(%rip),%rdx        # 26233a8 <__gmpfr_one+0xbc28>
  1bc860:	mov    %rbp,%rdi
  1bc863:	mov    %r9,%rsi
  1bc866:	call   *0x2512694(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bc86c:	cmp    %r9,%rbp
  1bc86f:	ja     1bd333 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x144b3>
  1bc875:	test   %rbp,%rbp
  1bc878:	je     1bc8c9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13a49>
  1bc87a:	mov    (%r11),%r12
  1bc87d:	lea    -0x1(%rbp),%rax
  1bc881:	mov    -0x8(%r11,%rbp,8),%rcx
  1bc886:	sub    %r12,%rcx
  1bc889:	setae  %dl
  1bc88c:	cmp    %rax,%rcx
  1bc88f:	sete   %al
  1bc892:	and    %dl,%al
  1bc894:	cmp    $0x1,%al
  1bc896:	jne    1bc8d6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13a56>
  1bc898:	mov    %r12,%rax
  1bc89b:	add    %rbp,%rax
  1bc89e:	mov    %rax,0x18(%rsp)
  1bc8a3:	movabs $0x7fffffffffffffff,%rsi
  1bc8ad:	mov    0x8(%rsp),%rbx
  1bc8b2:	jb     1bd47c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x145fc>
  1bc8b8:	mov    $0x1,%al
  1bc8ba:	mov    %rax,0x10(%rsp)
  1bc8bf:	mov    %r12,0x90(%rsp)
  1bc8c7:	jmp    1bc903 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13a83>
  1bc8c9:	xor    %r15d,%r15d
  1bc8cc:	xor    %r12d,%r12d
  1bc8cf:	xor    %ebp,%ebp
  1bc8d1:	jmp    1bce65 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13fe5>
  1bc8d6:	movq   $0x0,0x18(%rsp)
  1bc8df:	movq   $0x0,0x90(%rsp)
  1bc8eb:	movq   $0x0,0x10(%rsp)
  1bc8f4:	movabs $0x7fffffffffffffff,%rsi
  1bc8fe:	mov    0x8(%rsp),%rbx
  1bc903:	mov    %rbp,0x30(%rsp)
  1bc908:	lea    0x0(,%rbp,8),%rbp
  1bc910:	mov    (%rsp),%rcx
  1bc914:	imul   $0x6f,%rcx,%r9
  1bc918:	mov    %rcx,%rax
  1bc91b:	shl    $0x7,%rax
  1bc91f:	lea    (%rax,%rcx,2),%r8
  1bc923:	xor    %r14d,%r14d
  1bc926:	movapd 0x1fd96d2(%rip),%xmm6        # 2196000 <_fini+0x520>
  1bc92e:	xorpd  %xmm7,%xmm7
  1bc932:	movsd  0x1fdad75(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1bc93b:	movsd  0x1fdad74(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1bc944:	movsd  0x1fdad7b(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1bc94d:	movapd 0x1fd96ba(%rip),%xmm11        # 2196010 <_fini+0x530>
  1bc956:	movsd  0x1fdad61(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1bc95f:	mov    %r8,0x110(%rsp)
  1bc967:	nopw   0x0(%rax,%rax,1)
  1bc970:	mov    (%r11,%r14,1),%r13
  1bc974:	lea    (%r9,%r13,1),%rdi
  1bc978:	cmp    %rbx,%rdi
  1bc97b:	jae    1bd987 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14b07>
  1bc981:	shl    $0x4,%rdi
  1bc985:	movupd (%r15,%rdi,1),%xmm0
  1bc98b:	movapd %xmm0,%xmm2
  1bc98f:	andpd  %xmm6,%xmm2
  1bc993:	movapd %xmm0,%xmm1
  1bc997:	unpckhpd %xmm0,%xmm1
  1bc99b:	movapd %xmm1,%xmm3
  1bc99f:	andpd  %xmm6,%xmm3
  1bc9a3:	ucomisd %xmm7,%xmm0
  1bc9a7:	je     1bca10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13b90>
  1bc9a9:	ucomisd %xmm7,%xmm1
  1bc9ad:	je     1bca10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13b90>
  1bc9af:	movapd %xmm2,%xmm4
  1bc9b3:	cmplesd %xmm3,%xmm4
  1bc9b8:	movapd %xmm4,%xmm5
  1bc9bc:	andpd  %xmm3,%xmm5
  1bc9c0:	andnpd %xmm2,%xmm4
  1bc9c4:	orpd   %xmm5,%xmm4
  1bc9c8:	ucomisd %xmm8,%xmm4
  1bc9cd:	jbe    1bca10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13b90>
  1bc9cf:	ucomisd %xmm4,%xmm9
  1bc9d4:	jbe    1bca10 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13b90>
  1bc9d6:	movapd %xmm0,%xmm2
  1bc9da:	mulpd  %xmm0,%xmm2
  1bc9de:	movapd %xmm2,%xmm3
  1bc9e2:	unpckhpd %xmm2,%xmm3
  1bc9e6:	addsd  %xmm2,%xmm3
  1bc9ea:	movapd %xmm10,%xmm2
  1bc9ef:	divsd  %xmm3,%xmm2
  1bc9f3:	mulsd  %xmm2,%xmm0
  1bc9f7:	xorpd  %xmm11,%xmm1
  1bc9fc:	mulsd  %xmm2,%xmm1
  1bca00:	jmp    1bcb16 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13c96>
  1bca05:	data16 cs nopw 0x0(%rax,%rax,1)
  1bca10:	ucomisd %xmm7,%xmm1
  1bca14:	setnp  %al
  1bca17:	sete   %cl
  1bca1a:	and    %al,%cl
  1bca1c:	movq   %xmm0,%rax
  1bca21:	and    %rsi,%rax
  1bca24:	cmp    %r10,%rax
  1bca27:	setl   %dl
  1bca2a:	test   %dl,%cl
  1bca2c:	je     1bca50 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13bd0>
  1bca2e:	movapd %xmm10,%xmm2
  1bca33:	divsd  %xmm0,%xmm2
  1bca37:	xorpd  %xmm11,%xmm1
  1bca3c:	movapd %xmm2,%xmm0
  1bca40:	jmp    1bcb16 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13c96>
  1bca45:	data16 cs nopw 0x0(%rax,%rax,1)
  1bca50:	ucomisd %xmm7,%xmm0
  1bca54:	setnp  %cl
  1bca57:	sete   %dl
  1bca5a:	and    %cl,%dl
  1bca5c:	movq   %xmm1,%rcx
  1bca61:	and    %rsi,%rcx
  1bca64:	cmp    %r10,%rcx
  1bca67:	setl   %sil
  1bca6b:	test   %sil,%dl
  1bca6e:	je     1bca82 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13c02>
  1bca70:	movapd %xmm12,%xmm2
  1bca75:	divsd  %xmm1,%xmm2
  1bca79:	movapd %xmm2,%xmm1
  1bca7d:	jmp    1bcb0c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13c8c>
  1bca82:	movabs $0x7fefffffffffffff,%rdx
  1bca8c:	cmp    %rdx,%rax
  1bca8f:	setg   %al
  1bca92:	cmp    %rdx,%rcx
  1bca95:	setg   %cl
  1bca98:	or     %al,%cl
  1bca9a:	cmp    $0x1,%cl
  1bca9d:	jne    1bcb45 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13cc5>
  1bcaa3:	add    %r15,%rdi
  1bcaa6:	mov    %rbp,%rbx
  1bcaa9:	mov    %r9,%rbp
  1bcaac:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1bcab1:	movsd  0x1fdac06(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1bcaba:	movapd 0x1fd954d(%rip),%xmm11        # 2196010 <_fini+0x530>
  1bcac3:	movsd  0x1fdabfc(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1bcacc:	movsd  0x1fdabe3(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1bcad5:	movsd  0x1fdabd2(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1bcade:	xorpd  %xmm7,%xmm7
  1bcae2:	movapd 0x1fd9516(%rip),%xmm6        # 2196000 <_fini+0x520>
  1bcaea:	mov    %rbp,%r9
  1bcaed:	mov    %rbx,%rbp
  1bcaf0:	mov    0x8(%rsp),%rbx
  1bcaf5:	mov    0x110(%rsp),%r8
  1bcafd:	movabs $0x7ff0000000000000,%r10
  1bcb07:	mov    0x28(%rsp),%r11
  1bcb0c:	movabs $0x7fffffffffffffff,%rsi
  1bcb16:	add    %r8,%r13
  1bcb19:	cmp    %rbx,%r13
  1bcb1c:	jae    1bd974 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14af4>
  1bcb22:	shl    $0x4,%r13
  1bcb26:	movsd  %xmm0,(%r15,%r13,1)
  1bcb2c:	movsd  %xmm1,0x8(%r15,%r13,1)
  1bcb33:	add    $0x8,%r14
  1bcb37:	cmp    %r14,%rbp
  1bcb3a:	jne    1bc970 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13af0>
  1bcb40:	jmp    1bcbcd <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13d4d>
  1bcb45:	ucomisd %xmm7,%xmm1
  1bcb49:	movabs $0x7fffffffffffffff,%rsi
  1bcb53:	jne    1bcb5b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13cdb>
  1bcb55:	jnp    1bca2e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13bae>
  1bcb5b:	ucomisd %xmm7,%xmm0
  1bcb5f:	jne    1bcb72 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13cf2>
  1bcb61:	jp     1bcb72 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13cf2>
  1bcb63:	movapd %xmm12,%xmm2
  1bcb68:	divsd  %xmm1,%xmm2
  1bcb6c:	movapd %xmm2,%xmm1
  1bcb70:	jmp    1bcb16 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13c96>
  1bcb72:	movapd %xmm3,%xmm1
  1bcb76:	cmplesd %xmm2,%xmm1
  1bcb7b:	movapd %xmm1,%xmm4
  1bcb7f:	andpd  %xmm2,%xmm4
  1bcb83:	andnpd %xmm3,%xmm1
  1bcb87:	orpd   %xmm4,%xmm1
  1bcb8b:	unpcklpd %xmm1,%xmm1
  1bcb8f:	divpd  %xmm1,%xmm0
  1bcb93:	movapd %xmm0,%xmm2
  1bcb97:	xorpd  %xmm11,%xmm2
  1bcb9c:	movsd  %xmm0,%xmm2
  1bcba0:	mulpd  %xmm0,%xmm0
  1bcba4:	movapd %xmm0,%xmm3
  1bcba8:	unpcklpd %xmm0,%xmm3
  1bcbac:	unpckhpd %xmm0,%xmm0
  1bcbb0:	addpd  %xmm3,%xmm0
  1bcbb4:	divpd  %xmm0,%xmm2
  1bcbb8:	divpd  %xmm1,%xmm2
  1bcbbc:	movapd %xmm2,%xmm0
  1bcbc0:	movapd %xmm2,%xmm1
  1bcbc4:	unpckhpd %xmm2,%xmm1
  1bcbc8:	jmp    1bcb16 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13c96>
  1bcbcd:	cmpb   $0x0,0x10(%rsp)
  1bcbd2:	je     1bcd69 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13ee9>
  1bcbd8:	mov    0x18(%rsp),%r12
  1bcbdd:	mov    0x90(%rsp),%rbp
  1bcbe5:	cmp    %r12,%rbp
  1bcbe8:	mov    0x1c0(%rsp),%r13
  1bcbf0:	jae    1bce5a <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13fda>
  1bcbf6:	cmpq   $0x0,0x1e0(%rsp)
  1bcbff:	je     1bf171 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x162f1>
  1bcc05:	mov    (%rsp),%rdi
  1bcc09:	imul   $0x83,%rdi,%rax
  1bcc10:	lea    (%r8,%rbp,1),%r10
  1bcc14:	xor    %edx,%edx
  1bcc16:	mov    %rbx,%rcx
  1bcc19:	sub    %r10,%rcx
  1bcc1c:	cmovb  %rdx,%rcx
  1bcc20:	lea    (%rax,%rbp,1),%r14
  1bcc24:	mov    %rbx,%rsi
  1bcc27:	sub    %r14,%rsi
  1bcc2a:	cmovb  %rdx,%rsi
  1bcc2e:	cmp    %rsi,%rcx
  1bcc31:	cmovb  %rcx,%rsi
  1bcc35:	mov    %rbp,%r11
  1bcc38:	not    %r11
  1bcc3b:	add    %r12,%r11
  1bcc3e:	cmp    %r11,%rsi
  1bcc41:	cmovae %r11,%rsi
  1bcc45:	lea    (%rdi,%rbp,1),%r13
  1bcc49:	mov    %rbx,%rcx
  1bcc4c:	sub    %r13,%rcx
  1bcc4f:	cmovb  %rdx,%rcx
  1bcc53:	cmp    %rcx,%rsi
  1bcc56:	cmovb  %rsi,%rcx
  1bcc5a:	mov    %rbp,%r8
  1bcc5d:	cmp    $0x1f,%rcx
  1bcc61:	mov    %rbp,0x90(%rsp)
  1bcc69:	ja     1bce8e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1400e>
  1bcc6f:	mov    (%rsp),%r10
  1bcc73:	imul   $0x830,%r10,%rcx
  1bcc7a:	add    %r15,%rcx
  1bcc7d:	mov    %r8,%rdx
  1bcc80:	shl    $0x4,%rdx
  1bcc84:	imul   $0x820,%r10,%rsi
  1bcc8b:	add    %r15,%rsi
  1bcc8e:	mov    %r10,%r9
  1bcc91:	shl    $0x4,%r9
  1bcc95:	add    %r15,%r9
  1bcc98:	mov    0x1c0(%rsp),%r13
  1bcca0:	mov    0x1d8(%rsp),%r11
  1bcca8:	mov    $0x1,%r14d
  1bccae:	mov    0x30(%rsp),%r15
  1bccb3:	mov    0x18(%rsp),%r12
  1bccb8:	mov    0x90(%rsp),%rbp
  1bccc0:	lea    (%r10,%r8,1),%rdi
  1bccc4:	cmp    %rbx,%rdi
  1bccc7:	jae    1bf181 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16301>
  1bcccd:	mov    0x110(%rsp),%rdi
  1bccd5:	add    %r8,%rdi
  1bccd8:	cmp    %rbx,%rdi
  1bccdb:	jae    1be894 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15a14>
  1bcce1:	lea    (%rax,%r8,1),%rdi
  1bcce5:	cmp    %rbx,%rdi
  1bcce8:	jae    1be884 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15a04>
  1bccee:	inc    %r8
  1bccf1:	movupd (%r9,%rdx,1),%xmm0
  1bccf7:	movupd (%r11),%xmm1
  1bccfc:	movapd %xmm0,%xmm2
  1bcd00:	mulpd  %xmm1,%xmm2
  1bcd04:	movupd (%rsi,%rdx,1),%xmm3
  1bcd09:	movapd %xmm2,%xmm4
  1bcd0d:	unpcklpd %xmm2,%xmm4
  1bcd11:	unpckhpd %xmm2,%xmm2
  1bcd15:	subpd  %xmm2,%xmm4
  1bcd19:	mulpd  %xmm3,%xmm4
  1bcd1d:	movapd %xmm1,%xmm2
  1bcd21:	unpckhpd %xmm1,%xmm2
  1bcd25:	mulsd  %xmm0,%xmm2
  1bcd29:	unpckhpd %xmm0,%xmm0
  1bcd2d:	mulsd  %xmm1,%xmm0
  1bcd31:	addsd  %xmm2,%xmm0
  1bcd35:	unpcklpd %xmm0,%xmm0
  1bcd39:	shufpd $0x1,%xmm3,%xmm3
  1bcd3e:	mulpd  %xmm0,%xmm3
  1bcd42:	movapd %xmm4,%xmm0
  1bcd46:	subpd  %xmm3,%xmm0
  1bcd4a:	addpd  %xmm4,%xmm3
  1bcd4e:	movsd  %xmm0,%xmm3
  1bcd52:	movupd %xmm3,(%rcx,%rdx,1)
  1bcd57:	add    $0x10,%rdx
  1bcd5b:	cmp    %r8,%r12
  1bcd5e:	jne    1bccc0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13e40>
  1bcd64:	jmp    1bce65 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13fe5>
  1bcd69:	cmpq   $0x0,0x1e0(%rsp)
  1bcd72:	mov    0x1c0(%rsp),%r13
  1bcd7a:	je     1bf0f1 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16271>
  1bcd80:	imul   $0x83,(%rsp),%rcx
  1bcd88:	xor    %r14d,%r14d
  1bcd8b:	xor    %edx,%edx
  1bcd8d:	nopl   (%rax)
  1bcd90:	mov    (%r11,%rdx,1),%rdi
  1bcd94:	mov    (%rsp),%rax
  1bcd98:	lea    (%rdi,%rax,1),%r12
  1bcd9c:	cmp    %rbx,%r12
  1bcd9f:	jae    1bf0fe <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1627e>
  1bcda5:	lea    (%rdi,%r8,1),%rax
  1bcda9:	cmp    %rbx,%rax
  1bcdac:	jae    1be0e4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15264>
  1bcdb2:	add    %rcx,%rdi
  1bcdb5:	cmp    %rbx,%rdi
  1bcdb8:	jae    1be0d4 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15254>
  1bcdbe:	shl    $0x4,%r12
  1bcdc2:	shl    $0x4,%rax
  1bcdc6:	movupd (%r15,%r12,1),%xmm0
  1bcdcc:	mov    0x1d8(%rsp),%rsi
  1bcdd4:	movupd (%rsi),%xmm1
  1bcdd8:	movapd %xmm0,%xmm2
  1bcddc:	mulpd  %xmm1,%xmm2
  1bcde0:	shl    $0x4,%rdi
  1bcde4:	movupd (%r15,%rax,1),%xmm3
  1bcdea:	movapd %xmm2,%xmm4
  1bcdee:	unpcklpd %xmm2,%xmm4
  1bcdf2:	unpckhpd %xmm2,%xmm2
  1bcdf6:	subpd  %xmm2,%xmm4
  1bcdfa:	mulpd  %xmm3,%xmm4
  1bcdfe:	movapd %xmm1,%xmm2
  1bce02:	unpckhpd %xmm1,%xmm2
  1bce06:	mulsd  %xmm0,%xmm2
  1bce0a:	unpckhpd %xmm0,%xmm0
  1bce0e:	mulsd  %xmm1,%xmm0
  1bce12:	addsd  %xmm2,%xmm0
  1bce16:	unpcklpd %xmm0,%xmm0
  1bce1a:	shufpd $0x1,%xmm3,%xmm3
  1bce1f:	mulpd  %xmm0,%xmm3
  1bce23:	movapd %xmm4,%xmm0
  1bce27:	subpd  %xmm3,%xmm0
  1bce2b:	addpd  %xmm4,%xmm3
  1bce2f:	movsd  %xmm0,%xmm3
  1bce33:	movupd %xmm3,(%r15,%rdi,1)
  1bce39:	add    $0x8,%rdx
  1bce3d:	cmp    %rdx,%rbp
  1bce40:	jne    1bcd90 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13f10>
  1bce46:	mov    0x30(%rsp),%r15
  1bce4b:	mov    0x18(%rsp),%r12
  1bce50:	mov    0x90(%rsp),%rbp
  1bce58:	jmp    1bce65 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13fe5>
  1bce5a:	mov    $0x1,%r14d
  1bce60:	mov    0x30(%rsp),%r15
  1bce65:	mov    0x1b8(%rsp),%rax
  1bce6d:	mov    %r15,(%rax)
  1bce70:	mov    %r14,0x0(%r13)
  1bce74:	mov    %rbp,0x8(%r13)
  1bce78:	mov    %r12,0x10(%r13)
  1bce7c:	add    $0x178,%rsp
  1bce83:	pop    %rbx
  1bce84:	pop    %r12
  1bce86:	pop    %r13
  1bce88:	pop    %r14
  1bce8a:	pop    %r15
  1bce8c:	pop    %rbp
  1bce8d:	ret
  1bce8e:	xor    %edx,%edx
  1bce90:	mov    %rbx,%rsi
  1bce93:	sub    %r10,%rsi
  1bce96:	cmovb  %rdx,%rsi
  1bce9a:	mov    %rbx,%r8
  1bce9d:	sub    %r14,%r8
  1bcea0:	cmovb  %rdx,%r8
  1bcea4:	cmp    %r8,%rsi
  1bcea7:	cmovb  %rsi,%r8
  1bceab:	cmp    %r11,%r8
  1bceae:	cmovae %r11,%r8
  1bceb2:	mov    %rbx,%rdi
  1bceb5:	sub    %r13,%rdi
  1bceb8:	cmovb  %rdx,%rdi
  1bcebc:	cmp    %rdi,%r8
  1bcebf:	cmovb  %r8,%rdi
  1bcec3:	mov    %r13,%rbp
  1bcec6:	shl    $0x4,%rbp
  1bceca:	lea    (%r15,%rbp,1),%rdx
  1bcece:	lea    (%r15,%rbp,1),%rsi
  1bced2:	add    $0x8,%rsi
  1bced6:	shl    $0x4,%rdi
  1bceda:	mov    %rdx,0x28(%rsp)
  1bcedf:	add    %rdi,%rdx
  1bcee2:	add    $0x8,%rdx
  1bcee6:	mov    0x90(%rsp),%r8
  1bceee:	mov    %rsi,0x10(%rsp)
  1bcef3:	cmp    %rsi,%rdx
  1bcef6:	jb     1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bcefc:	imul   $0x820,(%rsp),%rdx
  1bcf04:	mov    0x90(%rsp),%r12
  1bcf0c:	mov    %r12,%rsi
  1bcf0f:	shl    $0x4,%rsi
  1bcf13:	lea    (%r15,%rdx,1),%r8
  1bcf17:	lea    (%rsi,%r8,1),%r9
  1bcf1b:	add    $0x8,%r9
  1bcf1f:	add    %rsi,%r8
  1bcf22:	add    %r8,%rdi
  1bcf25:	add    $0x8,%rdi
  1bcf29:	mov    %r12,%r8
  1bcf2c:	cmp    %r9,%rdi
  1bcf2f:	jb     1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bcf35:	imul   $0x830,(%rsp),%rdi
  1bcf3d:	lea    (%rdi,%rsi,1),%r8
  1bcf41:	xor    %r9d,%r9d
  1bcf44:	mov    0x8(%rsp),%rbx
  1bcf49:	sub    %r10,%rbx
  1bcf4c:	cmovb  %r9,%rbx
  1bcf50:	mov    0x8(%rsp),%r10
  1bcf55:	sub    %r14,%r10
  1bcf58:	cmovb  %r9,%r10
  1bcf5c:	lea    (%r15,%r8,1),%r14
  1bcf60:	cmp    %r10,%rbx
  1bcf63:	cmovb  %rbx,%r10
  1bcf67:	cmp    %r11,%r10
  1bcf6a:	cmovae %r11,%r10
  1bcf6e:	mov    0x8(%rsp),%rbx
  1bcf73:	sub    %r13,%rbx
  1bcf76:	cmovb  %r9,%rbx
  1bcf7a:	cmp    %rbx,%r10
  1bcf7d:	cmovb  %r10,%rbx
  1bcf81:	shl    $0x4,%rbx
  1bcf85:	lea    (%rbx,%r14,1),%r9
  1bcf89:	add    $0x8,%r9
  1bcf8d:	lea    (%r15,%r8,1),%r13
  1bcf91:	add    $0x8,%r13
  1bcf95:	lea    (%rbx,%r14,1),%r8
  1bcf99:	add    $0x10,%r8
  1bcf9d:	add    %rbx,%rbp
  1bcfa0:	lea    (%r15,%rbp,1),%r10
  1bcfa4:	add    $0x10,%r10
  1bcfa8:	mov    %r10,0x48(%rsp)
  1bcfad:	lea    0x8(%r15,%rbp,1),%r11
  1bcfb2:	mov    %r11,0x40(%rsp)
  1bcfb7:	lea    (%rdx,%rsi,1),%r12
  1bcfbb:	mov    %r12,0x38(%rsp)
  1bcfc0:	lea    (%r15,%r12,1),%rbp
  1bcfc4:	lea    0x8(%rbx,%rbp,1),%r12
  1bcfc9:	add    %rbp,%rbx
  1bcfcc:	add    $0x10,%rbx
  1bcfd0:	mov    %rbx,0x60(%rsp)
  1bcfd5:	mov    0x8(%rsp),%rbx
  1bcfda:	cmp    %r8,%r14
  1bcfdd:	setb   0x20(%rsp)
  1bcfe2:	cmp    %r9,%r13
  1bcfe5:	setb   0x50(%rsp)
  1bcfea:	cmp    %r10,%r14
  1bcfed:	setb   0x100(%rsp)
  1bcff5:	cmp    %r9,0x10(%rsp)
  1bcffa:	setb   0xb0(%rsp)
  1bd002:	cmp    %r11,%r14
  1bd005:	setb   0xd0(%rsp)
  1bd00d:	cmp    %r9,0x28(%rsp)
  1bd012:	setb   0xe0(%rsp)
  1bd01a:	cmp    %r12,%r14
  1bd01d:	mov    %r12,%r10
  1bd020:	setb   0x58(%rsp)
  1bd025:	cmp    %r9,%rbp
  1bd028:	setb   0x88(%rsp)
  1bd030:	cmp    0x60(%rsp),%r14
  1bd035:	mov    0x38(%rsp),%r11
  1bd03a:	lea    0x8(%r15,%r11,1),%r12
  1bd03f:	setb   0x78(%rsp)
  1bd044:	cmp    %r9,%r12
  1bd047:	setb   0x38(%rsp)
  1bd04c:	cmp    0x48(%rsp),%r13
  1bd051:	setb   0x48(%rsp)
  1bd056:	cmp    %r8,0x10(%rsp)
  1bd05b:	setb   0x10(%rsp)
  1bd060:	cmp    0x40(%rsp),%r13
  1bd065:	setb   %r11b
  1bd069:	cmp    %r8,0x28(%rsp)
  1bd06e:	setb   0x28(%rsp)
  1bd073:	cmp    %r10,%r13
  1bd076:	setb   %r9b
  1bd07a:	cmp    %r8,%rbp
  1bd07d:	setb   %r10b
  1bd081:	cmp    0x60(%rsp),%r13
  1bd086:	setb   %r13b
  1bd08a:	cmp    %r8,%r12
  1bd08d:	mov    0x90(%rsp),%r8
  1bd095:	setb   %bpl
  1bd099:	movzbl 0x50(%rsp),%r12d
  1bd09f:	test   %r12b,0x20(%rsp)
  1bd0a4:	jne    1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bd0aa:	mov    0x90(%rsp),%r8
  1bd0b2:	movzbl 0xb0(%rsp),%r12d
  1bd0bb:	and    %r12b,0x100(%rsp)
  1bd0c3:	jne    1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bd0c9:	mov    0x90(%rsp),%r8
  1bd0d1:	movzbl 0xe0(%rsp),%r12d
  1bd0da:	and    %r12b,0xd0(%rsp)
  1bd0e2:	jne    1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bd0e8:	mov    0x90(%rsp),%r8
  1bd0f0:	movzbl 0x88(%rsp),%r12d
  1bd0f9:	and    %r12b,0x58(%rsp)
  1bd0fe:	jne    1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bd104:	mov    0x90(%rsp),%r8
  1bd10c:	movzbl 0x78(%rsp),%r14d
  1bd112:	and    0x38(%rsp),%r14b
  1bd117:	jne    1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bd11d:	mov    0x90(%rsp),%r8
  1bd125:	movzbl 0x10(%rsp),%r14d
  1bd12b:	and    %r14b,0x48(%rsp)
  1bd130:	jne    1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bd136:	mov    0x90(%rsp),%r8
  1bd13e:	and    0x28(%rsp),%r11b
  1bd143:	jne    1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bd149:	mov    0x90(%rsp),%r8
  1bd151:	and    %r10b,%r9b
  1bd154:	jne    1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bd15a:	mov    0x90(%rsp),%r8
  1bd162:	and    %bpl,%r13b
  1bd165:	jne    1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bd16b:	movabs $0x7fffffffffffffe,%r8
  1bd175:	and    %r8,%rcx
  1bd178:	mov    0x90(%rsp),%r8
  1bd180:	add    %rcx,%r8
  1bd183:	mov    0x1d8(%rsp),%r9
  1bd18b:	movsd  (%r9),%xmm0
  1bd190:	movsd  0x8(%r9),%xmm1
  1bd196:	unpcklpd %xmm0,%xmm0
  1bd19a:	unpcklpd %xmm1,%xmm1
  1bd19e:	add    %r15,%rsi
  1bd1a1:	mov    (%rsp),%r9
  1bd1a5:	shl    $0x4,%r9
  1bd1a9:	nopl   0x0(%rax)
  1bd1b0:	movupd (%rsi,%r9,1),%xmm2
  1bd1b6:	movupd 0x10(%rsi,%r9,1),%xmm3
  1bd1bd:	movapd %xmm2,%xmm4
  1bd1c1:	unpcklpd %xmm3,%xmm4
  1bd1c5:	unpckhpd %xmm3,%xmm2
  1bd1c9:	movapd %xmm2,%xmm3
  1bd1cd:	mulpd  %xmm0,%xmm3
  1bd1d1:	movapd %xmm0,%xmm5
  1bd1d5:	mulpd  %xmm4,%xmm5
  1bd1d9:	mulpd  %xmm1,%xmm4
  1bd1dd:	addpd  %xmm3,%xmm4
  1bd1e1:	movupd (%rsi,%rdx,1),%xmm3
  1bd1e6:	movupd 0x10(%rsi,%rdx,1),%xmm6
  1bd1ec:	movapd %xmm3,%xmm7
  1bd1f0:	unpcklpd %xmm6,%xmm7
  1bd1f4:	unpckhpd %xmm6,%xmm3
  1bd1f8:	movapd %xmm7,%xmm6
  1bd1fc:	mulpd  %xmm4,%xmm6
  1bd200:	mulpd  %xmm1,%xmm2
  1bd204:	subpd  %xmm2,%xmm5
  1bd208:	mulpd  %xmm5,%xmm7
  1bd20c:	mulpd  %xmm3,%xmm5
  1bd210:	addpd  %xmm6,%xmm5
  1bd214:	mulpd  %xmm4,%xmm3
  1bd218:	subpd  %xmm3,%xmm7
  1bd21c:	movapd %xmm7,%xmm2
  1bd220:	unpcklpd %xmm5,%xmm2
  1bd224:	unpckhpd %xmm5,%xmm7
  1bd228:	movupd %xmm7,0x10(%rsi,%rdi,1)
  1bd22e:	movupd %xmm2,(%rsi,%rdi,1)
  1bd233:	add    $0x20,%rsi
  1bd237:	add    $0xfffffffffffffffe,%rcx
  1bd23b:	jne    1bd1b0 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x14330>
  1bd241:	jmp    1bcc6f <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13def>
  1bd246:	mov    0x28(%rsp),%r11
  1bd24b:	jmp    1b8881 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xfa01>
  1bd250:	mov    (%rsp),%r10
  1bd254:	mov    0x60(%rsp),%rbp
  1bd259:	jmp    1bc6e2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13862>
  1bd25e:	mov    (%rsp),%r10
  1bd262:	jmp    1bd270 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x143f0>
  1bd264:	mov    (%rsp),%r10
  1bd268:	mov    0x1b0(%rsp),%r9
  1bd270:	mov    0x28(%rsp),%r11
  1bd275:	mov    0x60(%rsp),%rbp
  1bd27a:	jmp    1bc6e2 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13862>
  1bd27f:	lea    0x2466452(%rip),%rcx        # 26236d8 <__gmpfr_one+0xbf58>
  1bd286:	xor    %edi,%edi
  1bd288:	mov    %r9,%rdx
  1bd28b:	call   *0x2513bf7(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd291:	lea    0x2466428(%rip),%rcx        # 26236c0 <__gmpfr_one+0xbf40>
  1bd298:	xor    %edi,%edi
  1bd29a:	mov    %r13,%rsi
  1bd29d:	mov    %r9,%rdx
  1bd2a0:	call   *0x2513be2(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd2a6:	lea    0x24663fb(%rip),%rcx        # 26236a8 <__gmpfr_one+0xbf28>
  1bd2ad:	xor    %edi,%edi
  1bd2af:	mov    %r14,%rsi
  1bd2b2:	mov    %r9,%rdx
  1bd2b5:	call   *0x2513bcd(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd2bb:	lea    0x24663ce(%rip),%rcx        # 2623690 <__gmpfr_one+0xbf10>
  1bd2c2:	xor    %edi,%edi
  1bd2c4:	mov    %r9,%rdx
  1bd2c7:	call   *0x2513bbb(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd2cd:	lea    0x24663a4(%rip),%rcx        # 2623678 <__gmpfr_one+0xbef8>
  1bd2d4:	xor    %edi,%edi
  1bd2d6:	mov    %r12,%rsi
  1bd2d9:	mov    %r9,%rdx
  1bd2dc:	call   *0x2513ba6(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd2e2:	lea    0x2466317(%rip),%rcx        # 2623600 <__gmpfr_one+0xbe80>
  1bd2e9:	xor    %edi,%edi
  1bd2eb:	mov    %r14,%rsi
  1bd2ee:	mov    %r9,%rdx
  1bd2f1:	call   *0x2513b91(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd2f7:	lea    0x24662ea(%rip),%rcx        # 26235e8 <__gmpfr_one+0xbe68>
  1bd2fe:	xor    %edi,%edi
  1bd300:	mov    %r14,%rsi
  1bd303:	mov    %r9,%rdx
  1bd306:	call   *0x2513b7c(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd30c:	lea    0x24661fd(%rip),%rcx        # 2623510 <__gmpfr_one+0xbd90>
  1bd313:	xor    %edi,%edi
  1bd315:	mov    %r9,%rdx
  1bd318:	call   *0x2513b6a(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd31e:	lea    0x24661d3(%rip),%rcx        # 26234f8 <__gmpfr_one+0xbd78>
  1bd325:	xor    %edi,%edi
  1bd327:	mov    %r13,%rsi
  1bd32a:	mov    %r9,%rdx
  1bd32d:	call   *0x2513b55(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd333:	lea    0x2466146(%rip),%rcx        # 2623480 <__gmpfr_one+0xbd00>
  1bd33a:	xor    %edi,%edi
  1bd33c:	mov    %rbp,%rsi
  1bd33f:	mov    %r9,%rdx
  1bd342:	call   *0x2513b40(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd348:	lea    0x2466809(%rip),%rcx        # 2623b58 <__gmpfr_one+0xc3d8>
  1bd34f:	xor    %edi,%edi
  1bd351:	mov    %rax,%rsi
  1bd354:	mov    %r9,%rdx
  1bd357:	call   *0x2513b2b(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd35d:	lea    0x24666a4(%rip),%rcx        # 2623a08 <__gmpfr_one+0xc288>
  1bd364:	xor    %edi,%edi
  1bd366:	mov    %r14,%rsi
  1bd369:	mov    %r9,%rdx
  1bd36c:	call   *0x2513b16(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd372:	lea    0x24665ff(%rip),%rcx        # 2623978 <__gmpfr_one+0xc1f8>
  1bd379:	xor    %edi,%edi
  1bd37b:	mov    %r9,%rdx
  1bd37e:	call   *0x2513b04(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd384:	lea    0x24664fd(%rip),%rcx        # 2623888 <__gmpfr_one+0xc108>
  1bd38b:	xor    %edi,%edi
  1bd38d:	mov    %r14,%rsi
  1bd390:	mov    %r9,%rdx
  1bd393:	call   *0x2513aef(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd399:	lea    0x2466458(%rip),%rcx        # 26237f8 <__gmpfr_one+0xc078>
  1bd3a0:	xor    %edi,%edi
  1bd3a2:	mov    %r9,%rdx
  1bd3a5:	call   *0x2513add(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd3ab:	lea    0x24663b6(%rip),%rcx        # 2623768 <__gmpfr_one+0xbfe8>
  1bd3b2:	xor    %edi,%edi
  1bd3b4:	mov    %r14,%rsi
  1bd3b7:	mov    %r9,%rdx
  1bd3ba:	call   *0x2513ac8(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd3c0:	lea    0x2466329(%rip),%rcx        # 26236f0 <__gmpfr_one+0xbf70>
  1bd3c7:	xor    %edi,%edi
  1bd3c9:	mov    %r9,%rdx
  1bd3cc:	call   *0x2513ab6(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd3d2:	lea    0x246623f(%rip),%rcx        # 2623618 <__gmpfr_one+0xbe98>
  1bd3d9:	xor    %edi,%edi
  1bd3db:	mov    %r14,%rsi
  1bd3de:	mov    %r9,%rdx
  1bd3e1:	call   *0x2513aa1(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd3e7:	lea    0x246619a(%rip),%rcx        # 2623588 <__gmpfr_one+0xbe08>
  1bd3ee:	xor    %edi,%edi
  1bd3f0:	mov    0x1b0(%rsp),%rdx
  1bd3f8:	call   *0x2513a8a(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd3fe:	lea    0x2466093(%rip),%rcx        # 2623498 <__gmpfr_one+0xbd18>
  1bd405:	xor    %edi,%edi
  1bd407:	mov    %r14,%rsi
  1bd40a:	mov    %r9,%rdx
  1bd40d:	call   *0x2513a75(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd413:	lea    0x24666de(%rip),%rcx        # 2623af8 <__gmpfr_one+0xc378>
  1bd41a:	xor    %edi,%edi
  1bd41c:	mov    %r14,%rsi
  1bd41f:	mov    0x1b0(%rsp),%rdx
  1bd427:	call   *0x2513a5b(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd42d:	lea    0x24664e4(%rip),%rcx        # 2623918 <__gmpfr_one+0xc198>
  1bd434:	xor    %edi,%edi
  1bd436:	mov    %r9,%rdx
  1bd439:	call   *0x2513a49(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd43f:	lea    0x24660e2(%rip),%rcx        # 2623528 <__gmpfr_one+0xbda8>
  1bd446:	xor    %edi,%edi
  1bd448:	mov    %r9,%rdx
  1bd44b:	call   *0x2513a37(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd451:	lea    0x2466640(%rip),%rcx        # 2623a98 <__gmpfr_one+0xc318>
  1bd458:	xor    %edi,%edi
  1bd45a:	mov    %r9,%rdx
  1bd45d:	call   *0x2513a25(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  1bd463:	xor    %esi,%esi
  1bd465:	xor    %edi,%edi
  1bd467:	jmp    1b1824 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x89a4>
  1bd46c:	xor    %esi,%esi
  1bd46e:	movq   $0x0,0x30(%rsp)
  1bd477:	jmp    1b5db6 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xcf36>
  1bd47c:	movq   $0x0,0x18(%rsp)
  1bd485:	movq   $0x0,0x90(%rsp)
  1bd491:	movq   $0x0,0x10(%rsp)
  1bd49a:	jmp    1bc903 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x13a83>
  1bd49f:	mov    0x8(%rsp),%rbx
  1bd4a4:	mov    0x28(%rsp),%r11
  1bd4a9:	mov    0x10(%rsp),%r13
  1bd4ae:	jmp    1b7c2d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xedad>
  1bd4b3:	movl   $0x0,0x20(%rsp)
  1bd4bb:	jmp    1ae032 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x51b2>
  1bd4c0:	movl   $0x0,0x20(%rsp)
  1bd4c8:	jmp    1b1f9c <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x911c>
  1bd4cd:	movl   $0x0,0x60(%rsp)
  1bd4d5:	jmp    1b8077 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0xf1f7>
  1bd4da:	movl   $0x0,0x10(%rsp)
  1bd4e2:	jmp    1bb8ff <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x12a7f>
  1bd4e7:	lea    0x24666e2(%rip),%rdx        # 2623bd0 <__gmpfr_one+0xc450>
  1bd4ee:	mov    %r9,%rdi
  1bd4f1:	mov    %r9,%rsi
  1bd4f4:	call   *0x2511a06(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd4fa:	lea    0x24666e7(%rip),%rdx        # 2623be8 <__gmpfr_one+0xc468>
  1bd501:	mov    %rbx,%rsi
  1bd504:	call   *0x25119f6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd50a:	mov    %rdx,%rsi
  1bd50d:	lea    0x24643c4(%rip),%rdx        # 26218d8 <__gmpfr_one+0xa158>
  1bd514:	call   *0x25119e6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd51a:	mov    %rdx,%rsi
  1bd51d:	lea    0x24643e4(%rip),%rdx        # 2621908 <__gmpfr_one+0xa188>
  1bd524:	call   *0x25119d6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd52a:	mov    %rdx,%rsi
  1bd52d:	lea    0x246462c(%rip),%rdx        # 2621b60 <__gmpfr_one+0xa3e0>
  1bd534:	call   *0x25119c6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd53a:	mov    %rdx,%rsi
  1bd53d:	lea    0x246470c(%rip),%rdx        # 2621c50 <__gmpfr_one+0xa4d0>
  1bd544:	call   *0x25119b6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd54a:	mov    %rdx,%rsi
  1bd54d:	lea    0x2464a2c(%rip),%rdx        # 2621f80 <__gmpfr_one+0xa800>
  1bd554:	call   *0x25119a6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd55a:	mov    %rdx,%rsi
  1bd55d:	lea    0x2464a4c(%rip),%rdx        # 2621fb0 <__gmpfr_one+0xa830>
  1bd564:	call   *0x2511996(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd56a:	mov    %rdx,%rsi
  1bd56d:	lea    0x2464c94(%rip),%rdx        # 2622208 <__gmpfr_one+0xaa88>
  1bd574:	call   *0x2511986(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd57a:	mov    %rdx,%rsi
  1bd57d:	lea    0x2464d74(%rip),%rdx        # 26222f8 <__gmpfr_one+0xab78>
  1bd584:	call   *0x2511976(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd58a:	mov    %rdx,%rsi
  1bd58d:	lea    0x2464e84(%rip),%rdx        # 2622418 <__gmpfr_one+0xac98>
  1bd594:	call   *0x2511966(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd59a:	mov    %rdx,%rsi
  1bd59d:	lea    0x2464ea4(%rip),%rdx        # 2622448 <__gmpfr_one+0xacc8>
  1bd5a4:	call   *0x2511956(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd5aa:	mov    %rdx,%rsi
  1bd5ad:	lea    0x246505c(%rip),%rdx        # 2622610 <__gmpfr_one+0xae90>
  1bd5b4:	call   *0x2511946(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd5ba:	mov    %rdx,%rsi
  1bd5bd:	lea    0x24651b4(%rip),%rdx        # 2622778 <__gmpfr_one+0xaff8>
  1bd5c4:	call   *0x2511936(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd5ca:	mov    %rdx,%rsi
  1bd5cd:	lea    0x24651d4(%rip),%rdx        # 26227a8 <__gmpfr_one+0xb028>
  1bd5d4:	call   *0x2511926(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd5da:	mov    %rdx,%rsi
  1bd5dd:	lea    0x24654ac(%rip),%rdx        # 2622a90 <__gmpfr_one+0xb310>
  1bd5e4:	call   *0x2511916(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd5ea:	mov    %rdx,%rsi
  1bd5ed:	lea    0x246558c(%rip),%rdx        # 2622b80 <__gmpfr_one+0xb400>
  1bd5f4:	call   *0x2511906(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd5fa:	mov    %rdx,%rsi
  1bd5fd:	lea    0x24655ac(%rip),%rdx        # 2622bb0 <__gmpfr_one+0xb430>
  1bd604:	call   *0x25118f6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd60a:	mov    %rdx,%rsi
  1bd60d:	lea    0x24656d4(%rip),%rdx        # 2622ce8 <__gmpfr_one+0xb568>
  1bd614:	call   *0x25118e6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd61a:	mov    %rdx,%rsi
  1bd61d:	lea    0x24657b4(%rip),%rdx        # 2622dd8 <__gmpfr_one+0xb658>
  1bd624:	call   *0x25118d6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd62a:	mov    %rdx,%rsi
  1bd62d:	lea    0x2465ad4(%rip),%rdx        # 2623108 <__gmpfr_one+0xb988>
  1bd634:	call   *0x25118c6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd63a:	mov    %rdx,%rsi
  1bd63d:	lea    0x2465af4(%rip),%rdx        # 2623138 <__gmpfr_one+0xb9b8>
  1bd644:	call   *0x25118b6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd64a:	mov    %rdx,%rsi
  1bd64d:	lea    0x2465d3c(%rip),%rdx        # 2623390 <__gmpfr_one+0xbc10>
  1bd654:	call   *0x25118a6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd65a:	lea    0x2463b3f(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bd661:	mov    $0x3,%edi
  1bd666:	mov    0x1e0(%rsp),%rsi
  1bd66e:	call   *0x251188c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd674:	lea    0x24664f5(%rip),%rdx        # 2623b70 <__gmpfr_one+0xc3f0>
  1bd67b:	mov    %rcx,%rdi
  1bd67e:	mov    %rbx,%rsi
  1bd681:	call   *0x2511879(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd687:	lea    0x24642aa(%rip),%rdx        # 2621938 <__gmpfr_one+0xa1b8>
  1bd68e:	mov    %rbx,%rsi
  1bd691:	call   *0x2511869(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd697:	lea    0x24642e2(%rip),%rdx        # 2621980 <__gmpfr_one+0xa200>
  1bd69e:	mov    %r14,%rdi
  1bd6a1:	mov    %rbx,%rsi
  1bd6a4:	call   *0x2511856(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd6aa:	lea    0x24642b7(%rip),%rdx        # 2621968 <__gmpfr_one+0xa1e8>
  1bd6b1:	mov    %rbx,%rsi
  1bd6b4:	call   *0x2511846(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd6ba:	lea    0x246635f(%rip),%rdx        # 2623a20 <__gmpfr_one+0xc2a0>
  1bd6c1:	mov    %rax,%rdi
  1bd6c4:	mov    %rbx,%rsi
  1bd6c7:	call   *0x2511833(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd6cd:	lea    0x24644d4(%rip),%rdx        # 2621ba8 <__gmpfr_one+0xa428>
  1bd6d4:	mov    %r12,%rdi
  1bd6d7:	mov    %rbx,%rsi
  1bd6da:	call   *0x2511820(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd6e0:	lea    0x24644a9(%rip),%rdx        # 2621b90 <__gmpfr_one+0xa410>
  1bd6e7:	mov    %r12,%rdi
  1bd6ea:	mov    %rbx,%rsi
  1bd6ed:	call   *0x251180d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd6f3:	lea    0x2464586(%rip),%rdx        # 2621c80 <__gmpfr_one+0xa500>
  1bd6fa:	mov    %rbx,%rsi
  1bd6fd:	call   *0x25117fd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd703:	lea    0x2466286(%rip),%rdx        # 2623990 <__gmpfr_one+0xc210>
  1bd70a:	mov    %rax,%rdi
  1bd70d:	mov    %rbx,%rsi
  1bd710:	call   *0x25117ea(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd716:	lea    0x24648c3(%rip),%rdx        # 2621fe0 <__gmpfr_one+0xa860>
  1bd71d:	mov    0x8(%rsp),%rsi
  1bd722:	call   *0x25117d8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd728:	lea    0x24648f9(%rip),%rdx        # 2622028 <__gmpfr_one+0xa8a8>
  1bd72f:	mov    %r14,%rdi
  1bd732:	mov    0x8(%rsp),%rsi
  1bd737:	call   *0x25117c3(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd73d:	lea    0x24648cc(%rip),%rdx        # 2622010 <__gmpfr_one+0xa890>
  1bd744:	mov    0x8(%rsp),%rsi
  1bd749:	call   *0x25117b1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd74f:	lea    0x246614a(%rip),%rdx        # 26238a0 <__gmpfr_one+0xc120>
  1bd756:	mov    %rax,%rdi
  1bd759:	mov    0x8(%rsp),%rsi
  1bd75e:	call   *0x251179c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd764:	lea    0x2464ae5(%rip),%rdx        # 2622250 <__gmpfr_one+0xaad0>
  1bd76b:	mov    %r12,%rdi
  1bd76e:	mov    0x8(%rsp),%rsi
  1bd773:	call   *0x2511787(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd779:	lea    0x2464ab8(%rip),%rdx        # 2622238 <__gmpfr_one+0xaab8>
  1bd780:	mov    %r12,%rdi
  1bd783:	mov    0x8(%rsp),%rsi
  1bd788:	call   *0x2511772(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd78e:	lea    0x2464b93(%rip),%rdx        # 2622328 <__gmpfr_one+0xaba8>
  1bd795:	mov    %rbx,%rsi
  1bd798:	call   *0x2511762(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd79e:	lea    0x2464bb3(%rip),%rdx        # 2622358 <__gmpfr_one+0xabd8>
  1bd7a5:	mov    %r14,%rdi
  1bd7a8:	mov    %rbx,%rsi
  1bd7ab:	call   *0x251174f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd7b1:	lea    0x2464b88(%rip),%rdx        # 2622340 <__gmpfr_one+0xabc0>
  1bd7b8:	mov    %rbx,%rsi
  1bd7bb:	call   *0x251173f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd7c1:	lea    0x2466048(%rip),%rdx        # 2623810 <__gmpfr_one+0xc090>
  1bd7c8:	mov    %rax,%rdi
  1bd7cb:	mov    %rbx,%rsi
  1bd7ce:	call   *0x251172c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd7d4:	lea    0x2464c9d(%rip),%rdx        # 2622478 <__gmpfr_one+0xacf8>
  1bd7db:	mov    %rbx,%rsi
  1bd7de:	call   *0x251171c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd7e4:	lea    0x2464cd5(%rip),%rdx        # 26224c0 <__gmpfr_one+0xad40>
  1bd7eb:	mov    %rbx,%rsi
  1bd7ee:	call   *0x251170c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd7f4:	lea    0x2464cad(%rip),%rdx        # 26224a8 <__gmpfr_one+0xad28>
  1bd7fb:	mov    %rax,%rdi
  1bd7fe:	mov    %rbx,%rsi
  1bd801:	call   *0x25116f9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd807:	lea    0x2465f72(%rip),%rdx        # 2623780 <__gmpfr_one+0xc000>
  1bd80e:	mov    %rax,%rdi
  1bd811:	mov    %rbx,%rsi
  1bd814:	call   *0x25116e6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd81a:	lea    0x24663f7(%rip),%rdx        # 2623c18 <__gmpfr_one+0xc498>
  1bd821:	mov    %rsi,%rdi
  1bd824:	mov    %r9,%rsi
  1bd827:	call   *0x25116d3(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd82d:	lea    0x2464e24(%rip),%rdx        # 2622658 <__gmpfr_one+0xaed8>
  1bd834:	mov    %r14,%rdi
  1bd837:	mov    %rbx,%rsi
  1bd83a:	call   *0x25116c0(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd840:	lea    0x2464df9(%rip),%rdx        # 2622640 <__gmpfr_one+0xaec0>
  1bd847:	mov    %rbx,%rsi
  1bd84a:	call   *0x25116b0(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd850:	lea    0x2465eb1(%rip),%rdx        # 2623708 <__gmpfr_one+0xbf88>
  1bd857:	mov    %rax,%rdi
  1bd85a:	mov    %rbx,%rsi
  1bd85d:	call   *0x251169d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd863:	lea    0x2464f6e(%rip),%rdx        # 26227d8 <__gmpfr_one+0xb058>
  1bd86a:	mov    %rax,%rdi
  1bd86d:	mov    %rbx,%rsi
  1bd870:	call   *0x251168a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd876:	lea    0x246510b(%rip),%rdx        # 2622988 <__gmpfr_one+0xb208>
  1bd87d:	mov    %r14,%rdi
  1bd880:	mov    %rbx,%rsi
  1bd883:	call   *0x2511677(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd889:	lea    0x24650e0(%rip),%rdx        # 2622970 <__gmpfr_one+0xb1f0>
  1bd890:	mov    %rbx,%rsi
  1bd893:	call   *0x2511667(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd899:	lea    0x2465220(%rip),%rdx        # 2622ac0 <__gmpfr_one+0xb340>
  1bd8a0:	mov    %rbx,%rsi
  1bd8a3:	call   *0x2511657(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd8a9:	mov    %rdx,%rsi
  1bd8ac:	lea    0x24652b5(%rip),%rdx        # 2622b68 <__gmpfr_one+0xb3e8>
  1bd8b3:	call   *0x2511647(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd8b9:	lea    0x2465320(%rip),%rdx        # 2622be0 <__gmpfr_one+0xb460>
  1bd8c0:	mov    %rbx,%rsi
  1bd8c3:	call   *0x2511637(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd8c9:	lea    0x2465d60(%rip),%rdx        # 2623630 <__gmpfr_one+0xbeb0>
  1bd8d0:	mov    %rax,%rdi
  1bd8d3:	mov    %rbx,%rsi
  1bd8d6:	call   *0x2511624(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd8dc:	lea    0x246544d(%rip),%rdx        # 2622d30 <__gmpfr_one+0xb5b0>
  1bd8e3:	mov    %r13,%rdi
  1bd8e6:	mov    0x8(%rsp),%rsi
  1bd8eb:	call   *0x251160f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd8f1:	lea    0x2465420(%rip),%rdx        # 2622d18 <__gmpfr_one+0xb598>
  1bd8f8:	mov    0x8(%rsp),%rsi
  1bd8fd:	call   *0x25115fd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd903:	lea    0x24654fe(%rip),%rdx        # 2622e08 <__gmpfr_one+0xb688>
  1bd90a:	mov    %rbx,%rsi
  1bd90d:	call   *0x25115ed(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd913:	lea    0x2465c86(%rip),%rdx        # 26235a0 <__gmpfr_one+0xbe20>
  1bd91a:	mov    %rax,%rdi
  1bd91d:	mov    %rbx,%rsi
  1bd920:	call   *0x25115da(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd926:	lea    0x246583b(%rip),%rdx        # 2623168 <__gmpfr_one+0xb9e8>
  1bd92d:	mov    0x8(%rsp),%rsi
  1bd932:	call   *0x25115c8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd938:	lea    0x2465871(%rip),%rdx        # 26231b0 <__gmpfr_one+0xba30>
  1bd93f:	mov    %r14,%rdi
  1bd942:	mov    0x8(%rsp),%rsi
  1bd947:	call   *0x25115b3(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd94d:	lea    0x2465844(%rip),%rdx        # 2623198 <__gmpfr_one+0xba18>
  1bd954:	mov    0x8(%rsp),%rsi
  1bd959:	call   *0x25115a1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd95f:	lea    0x2465b4a(%rip),%rdx        # 26234b0 <__gmpfr_one+0xbd30>
  1bd966:	mov    %rax,%rdi
  1bd969:	mov    0x8(%rsp),%rsi
  1bd96e:	call   *0x251158c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd974:	lea    0x2465a5d(%rip),%rdx        # 26233d8 <__gmpfr_one+0xbc58>
  1bd97b:	mov    %r13,%rdi
  1bd97e:	mov    %rbx,%rsi
  1bd981:	call   *0x2511579(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd987:	lea    0x2465a32(%rip),%rdx        # 26233c0 <__gmpfr_one+0xbc40>
  1bd98e:	mov    %rbx,%rsi
  1bd991:	call   *0x2511569(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd997:	lea    0x2463f52(%rip),%rdx        # 26218f0 <__gmpfr_one+0xa170>
  1bd99e:	mov    %rsi,%rdi
  1bd9a1:	mov    %r9,%rsi
  1bd9a4:	call   *0x2511556(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd9aa:	lea    0x2463f6f(%rip),%rdx        # 2621920 <__gmpfr_one+0xa1a0>
  1bd9b1:	mov    %r13,%rdi
  1bd9b4:	mov    %r9,%rsi
  1bd9b7:	call   *0x2511543(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd9bd:	lea    0x24641b4(%rip),%rdx        # 2621b78 <__gmpfr_one+0xa3f8>
  1bd9c4:	mov    %r14,%rdi
  1bd9c7:	mov    %r9,%rsi
  1bd9ca:	call   *0x2511530(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd9d0:	lea    0x24645c1(%rip),%rdx        # 2621f98 <__gmpfr_one+0xa818>
  1bd9d7:	mov    %rsi,%rdi
  1bd9da:	mov    %r9,%rsi
  1bd9dd:	call   *0x251151d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd9e3:	lea    0x24645de(%rip),%rdx        # 2621fc8 <__gmpfr_one+0xa848>
  1bd9ea:	mov    %r13,%rdi
  1bd9ed:	mov    %r9,%rsi
  1bd9f0:	call   *0x251150a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bd9f6:	lea    0x2464a33(%rip),%rdx        # 2622430 <__gmpfr_one+0xacb0>
  1bd9fd:	mov    %rsi,%rdi
  1bda00:	mov    %r9,%rsi
  1bda03:	call   *0x25114f7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bda09:	lea    0x2464c18(%rip),%rdx        # 2622628 <__gmpfr_one+0xaea8>
  1bda10:	mov    %r12,%rdi
  1bda13:	mov    %r9,%rsi
  1bda16:	call   *0x25114e4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bda1c:	lea    0x246377d(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bda23:	mov    $0x3,%edi
  1bda28:	mov    0x1e0(%rsp),%rsi
  1bda30:	call   *0x25114ca(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bda36:	lea    0x24652c3(%rip),%rdx        # 2622d00 <__gmpfr_one+0xb580>
  1bda3d:	mov    %r14,%rdi
  1bda40:	mov    %r9,%rsi
  1bda43:	call   *0x25114b7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bda49:	lea    0x24653a0(%rip),%rdx        # 2622df0 <__gmpfr_one+0xb670>
  1bda50:	mov    %r14,%rdi
  1bda53:	mov    %r9,%rsi
  1bda56:	call   *0x25114a4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bda5c:	lea    0x24656bd(%rip),%rdx        # 2623120 <__gmpfr_one+0xb9a0>
  1bda63:	mov    %rsi,%rdi
  1bda66:	mov    %r9,%rsi
  1bda69:	call   *0x2511491(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bda6f:	lea    0x24656da(%rip),%rdx        # 2623150 <__gmpfr_one+0xb9d0>
  1bda76:	mov    %r13,%rdi
  1bda79:	mov    %r9,%rsi
  1bda7c:	call   *0x251147e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bda82:	lea    0x2466177(%rip),%rdx        # 2623c00 <__gmpfr_one+0xc480>
  1bda89:	mov    0x1d0(%rsp),%rsi
  1bda91:	call   *0x2511469(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bda97:	lea    0x2466072(%rip),%rdx        # 2623b10 <__gmpfr_one+0xc390>
  1bda9e:	mov    %rcx,%rdi
  1bdaa1:	mov    %rbx,%rsi
  1bdaa4:	call   *0x2511456(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdaaa:	lea    0x2463fef(%rip),%rdx        # 2621aa0 <__gmpfr_one+0xa320>
  1bdab1:	mov    %r12,%rdi
  1bdab4:	mov    %rbx,%rsi
  1bdab7:	call   *0x2511443(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdabd:	lea    0x2463fc4(%rip),%rdx        # 2621a88 <__gmpfr_one+0xa308>
  1bdac4:	mov    %rbx,%rsi
  1bdac7:	call   *0x2511433(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdacd:	mov    %rdx,%rsi
  1bdad0:	lea    0x2464071(%rip),%rdx        # 2621b48 <__gmpfr_one+0xa3c8>
  1bdad7:	call   *0x2511423(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdadd:	lea    0x24642bc(%rip),%rdx        # 2621da0 <__gmpfr_one+0xa620>
  1bdae4:	mov    %r14,%rdi
  1bdae7:	mov    %rbx,%rsi
  1bdaea:	call   *0x2511410(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdaf0:	lea    0x2464291(%rip),%rdx        # 2621d88 <__gmpfr_one+0xa608>
  1bdaf7:	mov    %rbx,%rsi
  1bdafa:	call   *0x2511400(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdb00:	lea    0x2464359(%rip),%rdx        # 2621e60 <__gmpfr_one+0xa6e0>
  1bdb07:	mov    %r13,%rdi
  1bdb0a:	mov    %rbx,%rsi
  1bdb0d:	call   *0x25113ed(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdb13:	lea    0x246432e(%rip),%rdx        # 2621e48 <__gmpfr_one+0xa6c8>
  1bdb1a:	mov    %rbx,%rsi
  1bdb1d:	call   *0x25113dd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdb23:	lea    0x2465e06(%rip),%rdx        # 2623930 <__gmpfr_one+0xc1b0>
  1bdb2a:	mov    %rax,%rdi
  1bdb2d:	mov    %rbx,%rsi
  1bdb30:	call   *0x25113ca(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdb36:	lea    0x246460b(%rip),%rdx        # 2622148 <__gmpfr_one+0xa9c8>
  1bdb3d:	mov    %r12,%rdi
  1bdb40:	mov    %rbx,%rsi
  1bdb43:	call   *0x25113b7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdb49:	lea    0x24645e0(%rip),%rdx        # 2622130 <__gmpfr_one+0xa9b0>
  1bdb50:	mov    %rbx,%rsi
  1bdb53:	call   *0x25113a7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdb59:	mov    %rdx,%rsi
  1bdb5c:	lea    0x246468d(%rip),%rdx        # 26221f0 <__gmpfr_one+0xaa70>
  1bdb63:	call   *0x2511397(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdb69:	mov    %rdx,%rsi
  1bdb6c:	lea    0x246488d(%rip),%rdx        # 2622400 <__gmpfr_one+0xac80>
  1bdb73:	call   *0x2511387(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdb79:	lea    0x2464a60(%rip),%rdx        # 26225e0 <__gmpfr_one+0xae60>
  1bdb80:	mov    %r12,%rdi
  1bdb83:	mov    %rbx,%rsi
  1bdb86:	call   *0x2511374(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdb8c:	lea    0x2464a35(%rip),%rdx        # 26225c8 <__gmpfr_one+0xae48>
  1bdb93:	mov    %rbx,%rsi
  1bdb96:	call   *0x2511364(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdb9c:	mov    %rdx,%rsi
  1bdb9f:	lea    0x2464a52(%rip),%rdx        # 26225f8 <__gmpfr_one+0xae78>
  1bdba6:	call   *0x2511354(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdbac:	lea    0x2465fed(%rip),%rdx        # 2623ba0 <__gmpfr_one+0xc420>
  1bdbb3:	mov    %rax,%rdi
  1bdbb6:	mov    %r9,%rsi
  1bdbb9:	call   *0x2511341(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdbbf:	mov    %rdx,%rsi
  1bdbc2:	lea    0x2464b97(%rip),%rdx        # 2622760 <__gmpfr_one+0xafe0>
  1bdbc9:	call   *0x2511331(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdbcf:	lea    0x2465e7a(%rip),%rdx        # 2623a50 <__gmpfr_one+0xc2d0>
  1bdbd6:	mov    %r14,%rdi
  1bdbd9:	mov    %r9,%rsi
  1bdbdc:	call   *0x251131e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdbe2:	lea    0x2465dd7(%rip),%rdx        # 26239c0 <__gmpfr_one+0xc240>
  1bdbe9:	mov    %rsi,%rdi
  1bdbec:	mov    %r9,%rsi
  1bdbef:	call   *0x251130b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdbf5:	lea    0x246502c(%rip),%rdx        # 2622c28 <__gmpfr_one+0xb4a8>
  1bdbfc:	mov    %r12,%rdi
  1bdbff:	mov    %rbx,%rsi
  1bdc02:	call   *0x25112f8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdc08:	lea    0x2465001(%rip),%rdx        # 2622c10 <__gmpfr_one+0xb490>
  1bdc0f:	mov    %r12,%rdi
  1bdc12:	mov    %rbx,%rsi
  1bdc15:	call   *0x25112e5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdc1b:	mov    %rdx,%rsi
  1bdc1e:	lea    0x24650ab(%rip),%rdx        # 2622cd0 <__gmpfr_one+0xb550>
  1bdc25:	call   *0x25112d5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdc2b:	lea    0x2465c9e(%rip),%rdx        # 26238d0 <__gmpfr_one+0xc150>
  1bdc32:	mov    %r14,%rdi
  1bdc35:	mov    %r9,%rsi
  1bdc38:	call   *0x25112c2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdc3e:	lea    0x24652e3(%rip),%rdx        # 2622f28 <__gmpfr_one+0xb7a8>
  1bdc45:	mov    %r14,%rdi
  1bdc48:	mov    %rbx,%rsi
  1bdc4b:	call   *0x25112af(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdc51:	lea    0x24652b8(%rip),%rdx        # 2622f10 <__gmpfr_one+0xb790>
  1bdc58:	mov    %rbx,%rsi
  1bdc5b:	call   *0x251129f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdc61:	lea    0x2465380(%rip),%rdx        # 2622fe8 <__gmpfr_one+0xb868>
  1bdc68:	mov    %r13,%rdi
  1bdc6b:	mov    %rbx,%rsi
  1bdc6e:	call   *0x251128c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdc74:	lea    0x2465355(%rip),%rdx        # 2622fd0 <__gmpfr_one+0xb850>
  1bdc7b:	mov    %rbx,%rsi
  1bdc7e:	call   *0x251127c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdc84:	lea    0x24658b5(%rip),%rdx        # 2623540 <__gmpfr_one+0xbdc0>
  1bdc8b:	mov    %rax,%rdi
  1bdc8e:	mov    %rbx,%rsi
  1bdc91:	call   *0x2511269(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdc97:	lea    0x2463502(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bdc9e:	mov    $0x5,%edi
  1bdca3:	mov    0x1e0(%rsp),%rsi
  1bdcab:	call   *0x251124f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdcb1:	lea    0x2465b88(%rip),%rdx        # 2623840 <__gmpfr_one+0xc0c0>
  1bdcb8:	mov    %rsi,%rdi
  1bdcbb:	mov    %r9,%rsi
  1bdcbe:	call   *0x251123c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdcc4:	lea    0x2465605(%rip),%rdx        # 26232d0 <__gmpfr_one+0xbb50>
  1bdccb:	mov    %r13,%rdi
  1bdcce:	mov    %rbx,%rsi
  1bdcd1:	call   *0x2511229(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdcd7:	lea    0x24655da(%rip),%rdx        # 26232b8 <__gmpfr_one+0xbb38>
  1bdcde:	mov    %r13,%rdi
  1bdce1:	mov    %rbx,%rsi
  1bdce4:	call   *0x2511216(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdcea:	mov    %rdx,%rsi
  1bdced:	lea    0x2465684(%rip),%rdx        # 2623378 <__gmpfr_one+0xbbf8>
  1bdcf4:	call   *0x2511206(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdcfa:	lea    0x2465aaf(%rip),%rdx        # 26237b0 <__gmpfr_one+0xc030>
  1bdd01:	mov    %r14,%rdi
  1bdd04:	mov    %r9,%rsi
  1bdd07:	call   *0x25111f3(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdd0d:	lea    0x2465a24(%rip),%rdx        # 2623738 <__gmpfr_one+0xbfb8>
  1bdd14:	mov    %rsi,%rdi
  1bdd17:	mov    %r9,%rsi
  1bdd1a:	call   *0x25111e0(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdd20:	lea    0x2464ae1(%rip),%rdx        # 2622808 <__gmpfr_one+0xb088>
  1bdd27:	mov    %rbx,%rsi
  1bdd2a:	call   *0x25111d0(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdd30:	lea    0x2465929(%rip),%rdx        # 2623660 <__gmpfr_one+0xbee0>
  1bdd37:	mov    %r14,%rdi
  1bdd3a:	mov    %r9,%rsi
  1bdd3d:	call   *0x25111bd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdd43:	lea    0x2465886(%rip),%rdx        # 26235d0 <__gmpfr_one+0xbe50>
  1bdd4a:	mov    %rsi,%rdi
  1bdd4d:	mov    0x1b0(%rsp),%rsi
  1bdd55:	call   *0x25111a5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdd5b:	lea    0x246577e(%rip),%rdx        # 26234e0 <__gmpfr_one+0xbd60>
  1bdd62:	mov    %r14,%rdi
  1bdd65:	mov    %r9,%rsi
  1bdd68:	call   *0x2511192(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdd6e:	lea    0x2463c6b(%rip),%rdx        # 26219e0 <__gmpfr_one+0xa260>
  1bdd75:	mov    %rbx,%rsi
  1bdd78:	call   *0x2511182(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdd7e:	lea    0x2463c43(%rip),%rdx        # 26219c8 <__gmpfr_one+0xa248>
  1bdd85:	mov    %rax,%rdi
  1bdd88:	mov    %rbx,%rsi
  1bdd8b:	call   *0x251116f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdd91:	lea    0x2463cd8(%rip),%rdx        # 2621a70 <__gmpfr_one+0xa2f0>
  1bdd98:	mov    %rbx,%rsi
  1bdd9b:	call   *0x251115f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdda1:	lea    0x2463cb0(%rip),%rdx        # 2621a58 <__gmpfr_one+0xa2d8>
  1bdda8:	mov    %rcx,%rdi
  1bddab:	mov    %rbx,%rsi
  1bddae:	call   *0x251114c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bddb4:	lea    0x2463c85(%rip),%rdx        # 2621a40 <__gmpfr_one+0xa2c0>
  1bddbb:	mov    %rax,%rdi
  1bddbe:	mov    %rbx,%rsi
  1bddc1:	call   *0x2511139(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bddc7:	lea    0x2463e6a(%rip),%rdx        # 2621c38 <__gmpfr_one+0xa4b8>
  1bddce:	mov    %rbx,%rsi
  1bddd1:	call   *0x2511129(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bddd7:	lea    0x2463e42(%rip),%rdx        # 2621c20 <__gmpfr_one+0xa4a0>
  1bddde:	mov    %rcx,%rdi
  1bdde1:	mov    %rbx,%rsi
  1bdde4:	call   *0x2511116(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bddea:	lea    0x2463e17(%rip),%rdx        # 2621c08 <__gmpfr_one+0xa488>
  1bddf1:	mov    %rax,%rdi
  1bddf4:	mov    %rbx,%rsi
  1bddf7:	call   *0x2511103(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bddfd:	lea    0x2464284(%rip),%rdx        # 2622088 <__gmpfr_one+0xa908>
  1bde04:	call   *0x25110f6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bde0a:	lea    0x246425f(%rip),%rdx        # 2622070 <__gmpfr_one+0xa8f0>
  1bde11:	mov    %rax,%rdi
  1bde14:	call   *0x25110e6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bde1a:	lea    0x24642f7(%rip),%rdx        # 2622118 <__gmpfr_one+0xa998>
  1bde21:	call   *0x25110d9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bde27:	lea    0x24642d2(%rip),%rdx        # 2622100 <__gmpfr_one+0xa980>
  1bde2e:	mov    %rcx,%rdi
  1bde31:	call   *0x25110c9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bde37:	lea    0x24642aa(%rip),%rdx        # 26220e8 <__gmpfr_one+0xa968>
  1bde3e:	mov    %rax,%rdi
  1bde41:	call   *0x25110b9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bde47:	lea    0x2464492(%rip),%rdx        # 26222e0 <__gmpfr_one+0xab60>
  1bde4e:	call   *0x25110ac(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bde54:	lea    0x246446d(%rip),%rdx        # 26222c8 <__gmpfr_one+0xab48>
  1bde5b:	mov    %rcx,%rdi
  1bde5e:	call   *0x251109c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bde64:	lea    0x2464445(%rip),%rdx        # 26222b0 <__gmpfr_one+0xab30>
  1bde6b:	mov    %rax,%rdi
  1bde6e:	call   *0x251108c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bde74:	lea    0x246456d(%rip),%rdx        # 26223e8 <__gmpfr_one+0xac68>
  1bde7b:	mov    %rbx,%rsi
  1bde7e:	call   *0x251107c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bde84:	lea    0x2464545(%rip),%rdx        # 26223d0 <__gmpfr_one+0xac50>
  1bde8b:	mov    %rcx,%rdi
  1bde8e:	mov    %rbx,%rsi
  1bde91:	call   *0x2511069(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bde97:	lea    0x246451a(%rip),%rdx        # 26223b8 <__gmpfr_one+0xac38>
  1bde9e:	mov    %rax,%rdi
  1bdea1:	mov    %rbx,%rsi
  1bdea4:	call   *0x2511056(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdeaa:	lea    0x246466f(%rip),%rdx        # 2622520 <__gmpfr_one+0xada0>
  1bdeb1:	mov    %rbx,%rsi
  1bdeb4:	call   *0x2511046(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdeba:	lea    0x2464647(%rip),%rdx        # 2622508 <__gmpfr_one+0xad88>
  1bdec1:	mov    %rax,%rdi
  1bdec4:	mov    %rbx,%rsi
  1bdec7:	call   *0x2511033(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdecd:	lea    0x24646dc(%rip),%rdx        # 26225b0 <__gmpfr_one+0xae30>
  1bded4:	mov    %rbx,%rsi
  1bded7:	call   *0x2511023(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdedd:	lea    0x24646b4(%rip),%rdx        # 2622598 <__gmpfr_one+0xae18>
  1bdee4:	mov    %rcx,%rdi
  1bdee7:	mov    %rbx,%rsi
  1bdeea:	call   *0x2511010(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdef0:	lea    0x2464689(%rip),%rdx        # 2622580 <__gmpfr_one+0xae00>
  1bdef7:	mov    %rax,%rdi
  1bdefa:	mov    %rbx,%rsi
  1bdefd:	call   *0x2510ffd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdf03:	lea    0x24647ae(%rip),%rdx        # 26226b8 <__gmpfr_one+0xaf38>
  1bdf0a:	mov    %rbx,%rsi
  1bdf0d:	call   *0x2510fed(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdf13:	lea    0x2464786(%rip),%rdx        # 26226a0 <__gmpfr_one+0xaf20>
  1bdf1a:	mov    %rax,%rdi
  1bdf1d:	mov    %rbx,%rsi
  1bdf20:	call   *0x2510fda(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdf26:	lea    0x246481b(%rip),%rdx        # 2622748 <__gmpfr_one+0xafc8>
  1bdf2d:	mov    %rbx,%rsi
  1bdf30:	call   *0x2510fca(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdf36:	lea    0x24647f3(%rip),%rdx        # 2622730 <__gmpfr_one+0xafb0>
  1bdf3d:	mov    %rcx,%rdi
  1bdf40:	mov    %rbx,%rsi
  1bdf43:	call   *0x2510fb7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdf49:	lea    0x24647c8(%rip),%rdx        # 2622718 <__gmpfr_one+0xaf98>
  1bdf50:	mov    %rax,%rdi
  1bdf53:	mov    %rbx,%rsi
  1bdf56:	call   *0x2510fa4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdf5c:	lea    0x2464905(%rip),%rdx        # 2622868 <__gmpfr_one+0xb0e8>
  1bdf63:	mov    %rbx,%rsi
  1bdf66:	call   *0x2510f94(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdf6c:	lea    0x24648dd(%rip),%rdx        # 2622850 <__gmpfr_one+0xb0d0>
  1bdf73:	mov    %rax,%rdi
  1bdf76:	mov    %rbx,%rsi
  1bdf79:	call   *0x2510f81(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdf7f:	lea    0x2464942(%rip),%rdx        # 26228c8 <__gmpfr_one+0xb148>
  1bdf86:	mov    %rbx,%rsi
  1bdf89:	call   *0x2510f71(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdf8f:	lea    0x246491a(%rip),%rdx        # 26228b0 <__gmpfr_one+0xb130>
  1bdf96:	mov    %rax,%rdi
  1bdf99:	mov    %rbx,%rsi
  1bdf9c:	call   *0x2510f5e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdfa2:	lea    0x24649af(%rip),%rdx        # 2622958 <__gmpfr_one+0xb1d8>
  1bdfa9:	mov    %rbx,%rsi
  1bdfac:	call   *0x2510f4e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdfb2:	lea    0x2464987(%rip),%rdx        # 2622940 <__gmpfr_one+0xb1c0>
  1bdfb9:	mov    %rcx,%rdi
  1bdfbc:	mov    %rbx,%rsi
  1bdfbf:	call   *0x2510f3b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdfc5:	lea    0x246495c(%rip),%rdx        # 2622928 <__gmpfr_one+0xb1a8>
  1bdfcc:	mov    %rax,%rdi
  1bdfcf:	mov    %rbx,%rsi
  1bdfd2:	call   *0x2510f28(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdfd8:	lea    0x2464a09(%rip),%rdx        # 26229e8 <__gmpfr_one+0xb268>
  1bdfdf:	mov    %rbx,%rsi
  1bdfe2:	call   *0x2510f18(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdfe8:	lea    0x24649e1(%rip),%rdx        # 26229d0 <__gmpfr_one+0xb250>
  1bdfef:	mov    %rax,%rdi
  1bdff2:	mov    %rbx,%rsi
  1bdff5:	call   *0x2510f05(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bdffb:	lea    0x2464a76(%rip),%rdx        # 2622a78 <__gmpfr_one+0xb2f8>
  1be002:	mov    %rbx,%rsi
  1be005:	call   *0x2510ef5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be00b:	lea    0x2464a4e(%rip),%rdx        # 2622a60 <__gmpfr_one+0xb2e0>
  1be012:	mov    %rcx,%rdi
  1be015:	mov    %rbx,%rsi
  1be018:	call   *0x2510ee2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be01e:	lea    0x2464a23(%rip),%rdx        # 2622a48 <__gmpfr_one+0xb2c8>
  1be025:	mov    %rax,%rdi
  1be028:	mov    %rbx,%rsi
  1be02b:	call   *0x2510ecf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be031:	lea    0x2464b18(%rip),%rdx        # 2622b50 <__gmpfr_one+0xb3d0>
  1be038:	mov    %rbx,%rsi
  1be03b:	call   *0x2510ebf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be041:	lea    0x2464af0(%rip),%rdx        # 2622b38 <__gmpfr_one+0xb3b8>
  1be048:	mov    %rcx,%rdi
  1be04b:	mov    %rbx,%rsi
  1be04e:	call   *0x2510eac(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be054:	lea    0x2464ac5(%rip),%rdx        # 2622b20 <__gmpfr_one+0xb3a0>
  1be05b:	mov    %rax,%rdi
  1be05e:	mov    %rbx,%rsi
  1be061:	call   *0x2510e99(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be067:	lea    0x2464d52(%rip),%rdx        # 2622dc0 <__gmpfr_one+0xb640>
  1be06e:	mov    %rbx,%rsi
  1be071:	call   *0x2510e89(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be077:	lea    0x2464d2a(%rip),%rdx        # 2622da8 <__gmpfr_one+0xb628>
  1be07e:	mov    %rax,%rdi
  1be081:	mov    %rbx,%rsi
  1be084:	call   *0x2510e76(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be08a:	lea    0x246517f(%rip),%rdx        # 2623210 <__gmpfr_one+0xba90>
  1be091:	call   *0x2510e69(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be097:	lea    0x246515a(%rip),%rdx        # 26231f8 <__gmpfr_one+0xba78>
  1be09e:	mov    %rax,%rdi
  1be0a1:	call   *0x2510e59(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be0a7:	lea    0x24651f2(%rip),%rdx        # 26232a0 <__gmpfr_one+0xbb20>
  1be0ae:	call   *0x2510e4c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be0b4:	lea    0x24651cd(%rip),%rdx        # 2623288 <__gmpfr_one+0xbb08>
  1be0bb:	mov    %rcx,%rdi
  1be0be:	call   *0x2510e3c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be0c4:	lea    0x24651a5(%rip),%rdx        # 2623270 <__gmpfr_one+0xbaf0>
  1be0cb:	mov    %rax,%rdi
  1be0ce:	call   *0x2510e2c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be0d4:	lea    0x246538d(%rip),%rdx        # 2623468 <__gmpfr_one+0xbce8>
  1be0db:	mov    %rbx,%rsi
  1be0de:	call   *0x2510e1c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be0e4:	lea    0x2465365(%rip),%rdx        # 2623450 <__gmpfr_one+0xbcd0>
  1be0eb:	mov    %rax,%rdi
  1be0ee:	mov    %rbx,%rsi
  1be0f1:	call   *0x2510e09(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be0f7:	lea    0x2465a8a(%rip),%rdx        # 2623b88 <__gmpfr_one+0xc408>
  1be0fe:	mov    0x1d0(%rsp),%rsi
  1be106:	call   *0x2510df4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be10c:	lea    0x24634c5(%rip),%rdx        # 26215d8 <__gmpfr_one+0x9e58>
  1be113:	mov    %r14,%rdi
  1be116:	mov    %rbx,%rsi
  1be119:	call   *0x2510de1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be11f:	lea    0x246349a(%rip),%rdx        # 26215c0 <__gmpfr_one+0x9e40>
  1be126:	mov    %rbx,%rsi
  1be129:	call   *0x2510dd1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be12f:	lea    0x2463562(%rip),%rdx        # 2621698 <__gmpfr_one+0x9f18>
  1be136:	mov    %r14,%rdi
  1be139:	mov    %rbx,%rsi
  1be13c:	call   *0x2510dbe(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be142:	lea    0x2463537(%rip),%rdx        # 2621680 <__gmpfr_one+0x9f00>
  1be149:	mov    %rbx,%rsi
  1be14c:	call   *0x2510dae(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be152:	lea    0x24637f7(%rip),%rdx        # 2621950 <__gmpfr_one+0xa1d0>
  1be159:	mov    %rcx,%rdi
  1be15c:	mov    %rbx,%rsi
  1be15f:	call   *0x2510d9b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be165:	lea    0x246364c(%rip),%rdx        # 26217b8 <__gmpfr_one+0xa038>
  1be16c:	mov    %r12,%rdi
  1be16f:	mov    %rbx,%rsi
  1be172:	call   *0x2510d88(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be178:	lea    0x2463621(%rip),%rdx        # 26217a0 <__gmpfr_one+0xa020>
  1be17f:	mov    %rbx,%rsi
  1be182:	call   *0x2510d78(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be188:	lea    0x2465921(%rip),%rdx        # 2623ab0 <__gmpfr_one+0xc330>
  1be18f:	mov    %rax,%rdi
  1be192:	mov    %rbx,%rsi
  1be195:	call   *0x2510d65(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be19b:	lea    0x2465896(%rip),%rdx        # 2623a38 <__gmpfr_one+0xc2b8>
  1be1a2:	mov    0x1d0(%rsp),%rsi
  1be1aa:	call   *0x2510d50(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be1b0:	lea    0x24657f1(%rip),%rdx        # 26239a8 <__gmpfr_one+0xc228>
  1be1b7:	mov    0x1d0(%rsp),%rsi
  1be1bf:	call   *0x2510d3b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be1c5:	mov    %rdx,%rsi
  1be1c8:	lea    0x2463d99(%rip),%rdx        # 2621f68 <__gmpfr_one+0xa7e8>
  1be1cf:	call   *0x2510d2b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be1d5:	lea    0x2463e1c(%rip),%rdx        # 2621ff8 <__gmpfr_one+0xa878>
  1be1dc:	mov    %rcx,%rdi
  1be1df:	mov    0x8(%rsp),%rsi
  1be1e4:	call   *0x2510d16(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be1ea:	lea    0x24656c7(%rip),%rdx        # 26238b8 <__gmpfr_one+0xc138>
  1be1f1:	mov    0x1d0(%rsp),%rsi
  1be1f9:	call   *0x2510d01(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be1ff:	lea    0x2465622(%rip),%rdx        # 2623828 <__gmpfr_one+0xc0a8>
  1be206:	mov    0x1d0(%rsp),%rsi
  1be20e:	call   *0x2510cec(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be214:	lea    0x2464275(%rip),%rdx        # 2622490 <__gmpfr_one+0xad10>
  1be21b:	mov    %rcx,%rdi
  1be21e:	mov    %rbx,%rsi
  1be221:	call   *0x2510cd9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be227:	lea    0x246556a(%rip),%rdx        # 2623798 <__gmpfr_one+0xc018>
  1be22e:	mov    0x1d0(%rsp),%rsi
  1be236:	call   *0x2510cc4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be23c:	lea    0x24654dd(%rip),%rdx        # 2623720 <__gmpfr_one+0xbfa0>
  1be243:	mov    0x1d0(%rsp),%rsi
  1be24b:	call   *0x2510caf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be251:	lea    0x24658e8(%rip),%rdx        # 2623b40 <__gmpfr_one+0xc3c0>
  1be258:	mov    %r14,%rdi
  1be25b:	mov    0x1b0(%rsp),%rsi
  1be263:	call   *0x2510c97(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be269:	lea    0x2464580(%rip),%rdx        # 26227f0 <__gmpfr_one+0xb070>
  1be270:	mov    %rbx,%rsi
  1be273:	call   *0x2510c87(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be279:	lea    0x2464978(%rip),%rdx        # 2622bf8 <__gmpfr_one+0xb478>
  1be280:	mov    %rcx,%rdi
  1be283:	mov    %rbx,%rsi
  1be286:	call   *0x2510c74(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be28c:	lea    0x24653b5(%rip),%rdx        # 2623648 <__gmpfr_one+0xbec8>
  1be293:	mov    0x1d0(%rsp),%rsi
  1be29b:	call   *0x2510c5f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be2a1:	lea    0x24656b8(%rip),%rdx        # 2623960 <__gmpfr_one+0xc1e0>
  1be2a8:	mov    %rsi,%rdi
  1be2ab:	mov    %r9,%rsi
  1be2ae:	call   *0x2510c4c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be2b4:	lea    0x24652fd(%rip),%rdx        # 26235b8 <__gmpfr_one+0xbe38>
  1be2bb:	mov    0x1d0(%rsp),%rsi
  1be2c3:	call   *0x2510c37(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be2c9:	mov    %rdx,%rsi
  1be2cc:	lea    0x2464e1d(%rip),%rdx        # 26230f0 <__gmpfr_one+0xb970>
  1be2d3:	call   *0x2510c27(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be2d9:	lea    0x2464ea0(%rip),%rdx        # 2623180 <__gmpfr_one+0xba00>
  1be2e0:	mov    %rcx,%rdi
  1be2e3:	mov    0x8(%rsp),%rsi
  1be2e8:	call   *0x2510c12(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be2ee:	lea    0x24651d3(%rip),%rdx        # 26234c8 <__gmpfr_one+0xbd48>
  1be2f5:	mov    0x1d0(%rsp),%rsi
  1be2fd:	call   *0x2510bfd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be303:	lea    0x2465266(%rip),%rdx        # 2623570 <__gmpfr_one+0xbdf0>
  1be30a:	mov    %rsi,%rdi
  1be30d:	mov    %r9,%rsi
  1be310:	call   *0x2510bea(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be316:	lea    0x2463813(%rip),%rdx        # 2621b30 <__gmpfr_one+0xa3b0>
  1be31d:	mov    %rbx,%rsi
  1be320:	call   *0x2510bda(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be326:	lea    0x24637eb(%rip),%rdx        # 2621b18 <__gmpfr_one+0xa398>
  1be32d:	mov    %rax,%rdi
  1be330:	mov    %rbx,%rsi
  1be333:	call   *0x2510bc7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be339:	lea    0x24639a0(%rip),%rdx        # 2621ce0 <__gmpfr_one+0xa560>
  1be340:	mov    %rbx,%rsi
  1be343:	call   *0x2510bb7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be349:	lea    0x2463978(%rip),%rdx        # 2621cc8 <__gmpfr_one+0xa548>
  1be350:	mov    %rax,%rdi
  1be353:	mov    %rbx,%rsi
  1be356:	call   *0x2510ba4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be35c:	lea    0x2463a0d(%rip),%rdx        # 2621d70 <__gmpfr_one+0xa5f0>
  1be363:	mov    %rbx,%rsi
  1be366:	call   *0x2510b94(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be36c:	lea    0x24639e5(%rip),%rdx        # 2621d58 <__gmpfr_one+0xa5d8>
  1be373:	mov    %rcx,%rdi
  1be376:	mov    %rbx,%rsi
  1be379:	call   *0x2510b81(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be37f:	lea    0x24639ba(%rip),%rdx        # 2621d40 <__gmpfr_one+0xa5c0>
  1be386:	mov    %rax,%rdi
  1be389:	mov    %rbx,%rsi
  1be38c:	call   *0x2510b6e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be392:	lea    0x2463a97(%rip),%rdx        # 2621e30 <__gmpfr_one+0xa6b0>
  1be399:	mov    %rbx,%rsi
  1be39c:	call   *0x2510b5e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be3a2:	lea    0x2463a6f(%rip),%rdx        # 2621e18 <__gmpfr_one+0xa698>
  1be3a9:	mov    %rcx,%rdi
  1be3ac:	mov    %rbx,%rsi
  1be3af:	call   *0x2510b4b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be3b5:	lea    0x2463a44(%rip),%rdx        # 2621e00 <__gmpfr_one+0xa680>
  1be3bc:	mov    %rax,%rdi
  1be3bf:	mov    %rbx,%rsi
  1be3c2:	call   *0x2510b38(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be3c8:	lea    0x2463af1(%rip),%rdx        # 2621ec0 <__gmpfr_one+0xa740>
  1be3cf:	mov    %rbx,%rsi
  1be3d2:	call   *0x2510b28(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be3d8:	lea    0x2463ac9(%rip),%rdx        # 2621ea8 <__gmpfr_one+0xa728>
  1be3df:	mov    %rax,%rdi
  1be3e2:	mov    %rbx,%rsi
  1be3e5:	call   *0x2510b15(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be3eb:	lea    0x2463de6(%rip),%rdx        # 26221d8 <__gmpfr_one+0xaa58>
  1be3f2:	mov    %rbx,%rsi
  1be3f5:	call   *0x2510b05(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be3fb:	lea    0x2463dbe(%rip),%rdx        # 26221c0 <__gmpfr_one+0xaa40>
  1be402:	mov    %rax,%rdi
  1be405:	mov    %rbx,%rsi
  1be408:	call   *0x2510af2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be40e:	lea    0x24648a3(%rip),%rdx        # 2622cb8 <__gmpfr_one+0xb538>
  1be415:	mov    %rbx,%rsi
  1be418:	call   *0x2510ae2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be41e:	lea    0x246487b(%rip),%rdx        # 2622ca0 <__gmpfr_one+0xb520>
  1be425:	mov    %rcx,%rdi
  1be428:	mov    %rbx,%rsi
  1be42b:	call   *0x2510acf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be431:	lea    0x2464850(%rip),%rdx        # 2622c88 <__gmpfr_one+0xb508>
  1be438:	mov    %rax,%rdi
  1be43b:	mov    %rbx,%rsi
  1be43e:	call   *0x2510abc(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be444:	lea    0x2464a1d(%rip),%rdx        # 2622e68 <__gmpfr_one+0xb6e8>
  1be44b:	mov    %rbx,%rsi
  1be44e:	call   *0x2510aac(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be454:	lea    0x24649f5(%rip),%rdx        # 2622e50 <__gmpfr_one+0xb6d0>
  1be45b:	mov    %rax,%rdi
  1be45e:	mov    %rbx,%rsi
  1be461:	call   *0x2510a99(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be467:	lea    0x2464a8a(%rip),%rdx        # 2622ef8 <__gmpfr_one+0xb778>
  1be46e:	mov    %rbx,%rsi
  1be471:	call   *0x2510a89(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be477:	lea    0x2464a62(%rip),%rdx        # 2622ee0 <__gmpfr_one+0xb760>
  1be47e:	mov    %rcx,%rdi
  1be481:	mov    %rbx,%rsi
  1be484:	call   *0x2510a76(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be48a:	lea    0x2464a37(%rip),%rdx        # 2622ec8 <__gmpfr_one+0xb748>
  1be491:	mov    %rax,%rdi
  1be494:	mov    %rbx,%rsi
  1be497:	call   *0x2510a63(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be49d:	lea    0x2464b14(%rip),%rdx        # 2622fb8 <__gmpfr_one+0xb838>
  1be4a4:	mov    %rbx,%rsi
  1be4a7:	call   *0x2510a53(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be4ad:	lea    0x2464aec(%rip),%rdx        # 2622fa0 <__gmpfr_one+0xb820>
  1be4b4:	mov    %rcx,%rdi
  1be4b7:	mov    %rbx,%rsi
  1be4ba:	call   *0x2510a40(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be4c0:	lea    0x2464ac1(%rip),%rdx        # 2622f88 <__gmpfr_one+0xb808>
  1be4c7:	mov    %rax,%rdi
  1be4ca:	mov    %rbx,%rsi
  1be4cd:	call   *0x2510a2d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be4d3:	lea    0x2464b6e(%rip),%rdx        # 2623048 <__gmpfr_one+0xb8c8>
  1be4da:	mov    %rbx,%rsi
  1be4dd:	call   *0x2510a1d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be4e3:	lea    0x2464b46(%rip),%rdx        # 2623030 <__gmpfr_one+0xb8b0>
  1be4ea:	mov    %rax,%rdi
  1be4ed:	mov    %rbx,%rsi
  1be4f0:	call   *0x2510a0a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be4f6:	lea    0x2464e63(%rip),%rdx        # 2623360 <__gmpfr_one+0xbbe0>
  1be4fd:	mov    %rbx,%rsi
  1be500:	call   *0x25109fa(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be506:	lea    0x2464e3b(%rip),%rdx        # 2623348 <__gmpfr_one+0xbbc8>
  1be50d:	mov    %rcx,%rdi
  1be510:	mov    %rbx,%rsi
  1be513:	call   *0x25109e7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be519:	lea    0x2464e10(%rip),%rdx        # 2623330 <__gmpfr_one+0xbbb0>
  1be520:	mov    %rax,%rdi
  1be523:	mov    %rbx,%rsi
  1be526:	call   *0x25109d4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be52c:	lea    0x246347d(%rip),%rdx        # 26219b0 <__gmpfr_one+0xa230>
  1be533:	mov    %rbx,%rsi
  1be536:	call   *0x25109c4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be53c:	lea    0x2463455(%rip),%rdx        # 2621998 <__gmpfr_one+0xa218>
  1be543:	mov    %rbx,%rsi
  1be546:	call   *0x25109b4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be54c:	lea    0x24634d5(%rip),%rdx        # 2621a28 <__gmpfr_one+0xa2a8>
  1be553:	mov    %rbx,%rsi
  1be556:	call   *0x25109a4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be55c:	lea    0x24634ad(%rip),%rdx        # 2621a10 <__gmpfr_one+0xa290>
  1be563:	mov    %rbx,%rsi
  1be566:	call   *0x2510994(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be56c:	lea    0x2463485(%rip),%rdx        # 26219f8 <__gmpfr_one+0xa278>
  1be573:	mov    %rbx,%rsi
  1be576:	call   *0x2510984(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be57c:	lea    0x246366d(%rip),%rdx        # 2621bf0 <__gmpfr_one+0xa470>
  1be583:	mov    %rbx,%rsi
  1be586:	call   *0x2510974(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be58c:	lea    0x2463645(%rip),%rdx        # 2621bd8 <__gmpfr_one+0xa458>
  1be593:	mov    %rbx,%rsi
  1be596:	call   *0x2510964(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be59c:	lea    0x246361d(%rip),%rdx        # 2621bc0 <__gmpfr_one+0xa440>
  1be5a3:	mov    %rbx,%rsi
  1be5a6:	call   *0x2510954(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be5ac:	lea    0x2463aa5(%rip),%rdx        # 2622058 <__gmpfr_one+0xa8d8>
  1be5b3:	call   *0x2510947(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be5b9:	lea    0x2463a80(%rip),%rdx        # 2622040 <__gmpfr_one+0xa8c0>
  1be5c0:	mov    %r14,%rsi
  1be5c3:	call   *0x2510937(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be5c9:	lea    0x2463b00(%rip),%rdx        # 26220d0 <__gmpfr_one+0xa950>
  1be5d0:	mov    0x8(%rsp),%rsi
  1be5d5:	call   *0x2510925(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be5db:	lea    0x2463ad6(%rip),%rdx        # 26220b8 <__gmpfr_one+0xa938>
  1be5e2:	call   *0x2510918(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be5e8:	lea    0x2463ab1(%rip),%rdx        # 26220a0 <__gmpfr_one+0xa920>
  1be5ef:	call   *0x251090b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be5f5:	lea    0x2463c9c(%rip),%rdx        # 2622298 <__gmpfr_one+0xab18>
  1be5fc:	call   *0x25108fe(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be602:	lea    0x2463c77(%rip),%rdx        # 2622280 <__gmpfr_one+0xab00>
  1be609:	call   *0x25108f1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be60f:	lea    0x2463c52(%rip),%rdx        # 2622268 <__gmpfr_one+0xaae8>
  1be616:	call   *0x25108e4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be61c:	lea    0x2463d7d(%rip),%rdx        # 26223a0 <__gmpfr_one+0xac20>
  1be623:	mov    %rbx,%rsi
  1be626:	call   *0x25108d4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be62c:	lea    0x2463d55(%rip),%rdx        # 2622388 <__gmpfr_one+0xac08>
  1be633:	mov    %rbx,%rsi
  1be636:	call   *0x25108c4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be63c:	lea    0x2463d2d(%rip),%rdx        # 2622370 <__gmpfr_one+0xabf0>
  1be643:	mov    %rbx,%rsi
  1be646:	call   *0x25108b4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be64c:	lea    0x2463e9d(%rip),%rdx        # 26224f0 <__gmpfr_one+0xad70>
  1be653:	mov    %rbx,%rsi
  1be656:	call   *0x25108a4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be65c:	lea    0x2463e75(%rip),%rdx        # 26224d8 <__gmpfr_one+0xad58>
  1be663:	mov    %rbx,%rsi
  1be666:	call   *0x2510894(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be66c:	lea    0x2463ef5(%rip),%rdx        # 2622568 <__gmpfr_one+0xade8>
  1be673:	mov    %rbx,%rsi
  1be676:	call   *0x2510884(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be67c:	lea    0x2463ecd(%rip),%rdx        # 2622550 <__gmpfr_one+0xadd0>
  1be683:	mov    %rbx,%rsi
  1be686:	call   *0x2510874(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be68c:	lea    0x2463ea5(%rip),%rdx        # 2622538 <__gmpfr_one+0xadb8>
  1be693:	mov    %rbx,%rsi
  1be696:	call   *0x2510864(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be69c:	lea    0x2465485(%rip),%rdx        # 2623b28 <__gmpfr_one+0xc3a8>
  1be6a3:	mov    0x1d0(%rsp),%rsi
  1be6ab:	call   *0x251084f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be6b1:	lea    0x2463fd0(%rip),%rdx        # 2622688 <__gmpfr_one+0xaf08>
  1be6b8:	mov    %rbx,%rsi
  1be6bb:	call   *0x251083f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be6c1:	lea    0x2463fa8(%rip),%rdx        # 2622670 <__gmpfr_one+0xaef0>
  1be6c8:	mov    %rbx,%rsi
  1be6cb:	call   *0x251082f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be6d1:	lea    0x2464028(%rip),%rdx        # 2622700 <__gmpfr_one+0xaf80>
  1be6d8:	mov    %rbx,%rsi
  1be6db:	call   *0x251081f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be6e1:	lea    0x2464000(%rip),%rdx        # 26226e8 <__gmpfr_one+0xaf68>
  1be6e8:	mov    %rbx,%rsi
  1be6eb:	call   *0x251080f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be6f1:	lea    0x2463fd8(%rip),%rdx        # 26226d0 <__gmpfr_one+0xaf50>
  1be6f8:	mov    %rbx,%rsi
  1be6fb:	call   *0x25107ff(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be701:	lea    0x24631b8(%rip),%rdx        # 26218c0 <__gmpfr_one+0xa140>
  1be708:	mov    0x1d0(%rsp),%rsi
  1be710:	call   *0x25107ea(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be716:	lea    0x246411b(%rip),%rdx        # 2622838 <__gmpfr_one+0xb0b8>
  1be71d:	mov    %rax,%rsi
  1be720:	call   *0x25107da(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be726:	lea    0x24640f3(%rip),%rdx        # 2622820 <__gmpfr_one+0xb0a0>
  1be72d:	mov    %rax,%rsi
  1be730:	call   *0x25107ca(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be736:	lea    0x246415b(%rip),%rdx        # 2622898 <__gmpfr_one+0xb118>
  1be73d:	mov    %rbx,%rsi
  1be740:	call   *0x25107ba(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be746:	lea    0x2464133(%rip),%rdx        # 2622880 <__gmpfr_one+0xb100>
  1be74d:	mov    %rbx,%rsi
  1be750:	call   *0x25107aa(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be756:	lea    0x24641b3(%rip),%rdx        # 2622910 <__gmpfr_one+0xb190>
  1be75d:	mov    %rbx,%rsi
  1be760:	call   *0x251079a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be766:	lea    0x246418b(%rip),%rdx        # 26228f8 <__gmpfr_one+0xb178>
  1be76d:	mov    %rbx,%rsi
  1be770:	call   *0x251078a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be776:	lea    0x2464163(%rip),%rdx        # 26228e0 <__gmpfr_one+0xb160>
  1be77d:	mov    %rbx,%rsi
  1be780:	call   *0x251077a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be786:	lea    0x246422b(%rip),%rdx        # 26229b8 <__gmpfr_one+0xb238>
  1be78d:	mov    %rbx,%rsi
  1be790:	call   *0x251076a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be796:	lea    0x2464203(%rip),%rdx        # 26229a0 <__gmpfr_one+0xb220>
  1be79d:	mov    %rbx,%rsi
  1be7a0:	call   *0x251075a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be7a6:	lea    0x2464283(%rip),%rdx        # 2622a30 <__gmpfr_one+0xb2b0>
  1be7ad:	mov    %rbx,%rsi
  1be7b0:	call   *0x251074a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be7b6:	lea    0x246425b(%rip),%rdx        # 2622a18 <__gmpfr_one+0xb298>
  1be7bd:	mov    %rbx,%rsi
  1be7c0:	call   *0x251073a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be7c6:	lea    0x2464233(%rip),%rdx        # 2622a00 <__gmpfr_one+0xb280>
  1be7cd:	mov    %rbx,%rsi
  1be7d0:	call   *0x251072a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be7d6:	lea    0x246432b(%rip),%rdx        # 2622b08 <__gmpfr_one+0xb388>
  1be7dd:	mov    %rbx,%rsi
  1be7e0:	call   *0x251071a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be7e6:	lea    0x2464303(%rip),%rdx        # 2622af0 <__gmpfr_one+0xb370>
  1be7ed:	mov    %rbx,%rsi
  1be7f0:	call   *0x251070a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be7f6:	lea    0x24642db(%rip),%rdx        # 2622ad8 <__gmpfr_one+0xb358>
  1be7fd:	mov    %rbx,%rsi
  1be800:	call   *0x25106fa(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be806:	lea    0x246513b(%rip),%rdx        # 2623948 <__gmpfr_one+0xc1c8>
  1be80d:	mov    0x1d0(%rsp),%rsi
  1be815:	call   *0x25106e5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be81b:	lea    0x2464556(%rip),%rdx        # 2622d78 <__gmpfr_one+0xb5f8>
  1be822:	mov    %rbx,%rsi
  1be825:	call   *0x25106d5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be82b:	lea    0x246452e(%rip),%rdx        # 2622d60 <__gmpfr_one+0xb5e0>
  1be832:	mov    %rbx,%rsi
  1be835:	call   *0x25106c5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be83b:	lea    0x246499e(%rip),%rdx        # 26231e0 <__gmpfr_one+0xba60>
  1be842:	call   *0x25106b8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be848:	lea    0x2464979(%rip),%rdx        # 26231c8 <__gmpfr_one+0xba48>
  1be84f:	mov    %r14,%rsi
  1be852:	call   *0x25106a8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be858:	lea    0x24649f9(%rip),%rdx        # 2623258 <__gmpfr_one+0xbad8>
  1be85f:	mov    0x8(%rsp),%rsi
  1be864:	call   *0x2510696(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be86a:	lea    0x24649cf(%rip),%rdx        # 2623240 <__gmpfr_one+0xbac0>
  1be871:	call   *0x2510689(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be877:	lea    0x24649aa(%rip),%rdx        # 2623228 <__gmpfr_one+0xbaa8>
  1be87e:	call   *0x251067c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be884:	lea    0x2464b95(%rip),%rdx        # 2623420 <__gmpfr_one+0xbca0>
  1be88b:	mov    %rbx,%rsi
  1be88e:	call   *0x251066c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be894:	lea    0x2464b6d(%rip),%rdx        # 2623408 <__gmpfr_one+0xbc88>
  1be89b:	mov    %rbx,%rsi
  1be89e:	call   *0x251065c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be8a4:	lea    0x2465235(%rip),%rdx        # 2623ae0 <__gmpfr_one+0xc360>
  1be8ab:	mov    %rsi,%rdi
  1be8ae:	mov    %r9,%rsi
  1be8b1:	call   *0x2510649(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be8b7:	lea    0x2464c9a(%rip),%rdx        # 2623558 <__gmpfr_one+0xbdd8>
  1be8be:	mov    0x1d0(%rsp),%rsi
  1be8c6:	call   *0x2510634(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be8cc:	lea    0x246367d(%rip),%rdx        # 2621f50 <__gmpfr_one+0xa7d0>
  1be8d3:	mov    %rbx,%rsi
  1be8d6:	call   *0x2510624(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be8dc:	lea    0x2463655(%rip),%rdx        # 2621f38 <__gmpfr_one+0xa7b8>
  1be8e3:	mov    %rcx,%rdi
  1be8e6:	mov    %rbx,%rsi
  1be8e9:	call   *0x2510611(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be8ef:	lea    0x246362a(%rip),%rdx        # 2621f20 <__gmpfr_one+0xa7a0>
  1be8f6:	mov    %rax,%rdi
  1be8f9:	mov    %rbx,%rsi
  1be8fc:	call   *0x25105fe(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be902:	lea    0x24647cf(%rip),%rdx        # 26230d8 <__gmpfr_one+0xb958>
  1be909:	mov    %rbx,%rsi
  1be90c:	call   *0x25105ee(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be912:	lea    0x24647a7(%rip),%rdx        # 26230c0 <__gmpfr_one+0xb940>
  1be919:	mov    %rcx,%rdi
  1be91c:	mov    %rbx,%rsi
  1be91f:	call   *0x25105db(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be925:	lea    0x246477c(%rip),%rdx        # 26230a8 <__gmpfr_one+0xb928>
  1be92c:	mov    %rax,%rdi
  1be92f:	mov    %rbx,%rsi
  1be932:	call   *0x25105c8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be938:	lea    0x24628a9(%rip),%rdx        # 26211e8 <__gmpfr_one+0x9a68>
  1be93f:	mov    %rbx,%rsi
  1be942:	call   *0x25105b8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be948:	lea    0x2462959(%rip),%rdx        # 26212a8 <__gmpfr_one+0x9b28>
  1be94f:	mov    %rsi,%rdi
  1be952:	mov    %rbx,%rsi
  1be955:	call   *0x25105a5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be95b:	lea    0x246292e(%rip),%rdx        # 2621290 <__gmpfr_one+0x9b10>
  1be962:	mov    %rcx,%rdi
  1be965:	mov    %rbx,%rsi
  1be968:	call   *0x2510592(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be96e:	lea    0x2462903(%rip),%rdx        # 2621278 <__gmpfr_one+0x9af8>
  1be975:	mov    %rax,%rdi
  1be978:	mov    %rbx,%rsi
  1be97b:	call   *0x251057f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be981:	lea    0x24628d8(%rip),%rdx        # 2621260 <__gmpfr_one+0x9ae0>
  1be988:	mov    %rbx,%rsi
  1be98b:	call   *0x251056f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be991:	lea    0x2462970(%rip),%rdx        # 2621308 <__gmpfr_one+0x9b88>
  1be998:	mov    %rbx,%rsi
  1be99b:	call   *0x251055f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be9a1:	lea    0x2462948(%rip),%rdx        # 26212f0 <__gmpfr_one+0x9b70>
  1be9a8:	mov    %rax,%rdi
  1be9ab:	mov    %rbx,%rsi
  1be9ae:	call   *0x251054c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be9b4:	lea    0x24629dd(%rip),%rdx        # 2621398 <__gmpfr_one+0x9c18>
  1be9bb:	mov    %rbx,%rsi
  1be9be:	call   *0x251053c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be9c4:	mov    %rsi,0x20(%rsp)
  1be9c9:	lea    0x2462998(%rip),%rdx        # 2621368 <__gmpfr_one+0x9be8>
  1be9d0:	mov    0x20(%rsp),%rdi
  1be9d5:	mov    0x8(%rsp),%rsi
  1be9da:	call   *0x2510520(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be9e0:	lea    0x2462a11(%rip),%rdx        # 26213f8 <__gmpfr_one+0x9c78>
  1be9e7:	mov    %rbx,%rsi
  1be9ea:	call   *0x2510510(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1be9f0:	lea    0x24629e9(%rip),%rdx        # 26213e0 <__gmpfr_one+0x9c60>
  1be9f7:	mov    %rax,%rdi
  1be9fa:	mov    %rbx,%rsi
  1be9fd:	call   *0x25104fd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bea03:	lea    0x2462aae(%rip),%rdx        # 26214b8 <__gmpfr_one+0x9d38>
  1bea0a:	mov    %rbx,%rsi
  1bea0d:	call   *0x25104ed(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bea13:	lea    0x2462a86(%rip),%rdx        # 26214a0 <__gmpfr_one+0x9d20>
  1bea1a:	mov    %rsi,%rdi
  1bea1d:	mov    %rbx,%rsi
  1bea20:	call   *0x25104da(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bea26:	lea    0x2462a5b(%rip),%rdx        # 2621488 <__gmpfr_one+0x9d08>
  1bea2d:	mov    %rcx,%rdi
  1bea30:	mov    %rbx,%rsi
  1bea33:	call   *0x25104c7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bea39:	lea    0x2462a30(%rip),%rdx        # 2621470 <__gmpfr_one+0x9cf0>
  1bea40:	mov    %rax,%rdi
  1bea43:	mov    %rbx,%rsi
  1bea46:	call   *0x25104b4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bea4c:	lea    0x2462ac5(%rip),%rdx        # 2621518 <__gmpfr_one+0x9d98>
  1bea53:	mov    %rbx,%rsi
  1bea56:	call   *0x25104a4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bea5c:	lea    0x2462a9d(%rip),%rdx        # 2621500 <__gmpfr_one+0x9d80>
  1bea63:	mov    %rax,%rdi
  1bea66:	mov    %rbx,%rsi
  1bea69:	call   *0x2510491(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bea6f:	lea    0x2462b32(%rip),%rdx        # 26215a8 <__gmpfr_one+0x9e28>
  1bea76:	mov    %rbx,%rsi
  1bea79:	call   *0x2510481(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bea7f:	lea    0x2462b0a(%rip),%rdx        # 2621590 <__gmpfr_one+0x9e10>
  1bea86:	mov    %rcx,%rdi
  1bea89:	mov    %rbx,%rsi
  1bea8c:	call   *0x251046e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bea92:	lea    0x2462adf(%rip),%rdx        # 2621578 <__gmpfr_one+0x9df8>
  1bea99:	mov    %rax,%rdi
  1bea9c:	mov    %rbx,%rsi
  1bea9f:	call   *0x251045b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beaa5:	lea    0x2462bbc(%rip),%rdx        # 2621668 <__gmpfr_one+0x9ee8>
  1beaac:	mov    %rbx,%rsi
  1beaaf:	call   *0x251044b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beab5:	lea    0x2462b94(%rip),%rdx        # 2621650 <__gmpfr_one+0x9ed0>
  1beabc:	mov    %rcx,%rdi
  1beabf:	mov    %rbx,%rsi
  1beac2:	call   *0x2510438(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beac8:	lea    0x2462b69(%rip),%rdx        # 2621638 <__gmpfr_one+0x9eb8>
  1beacf:	mov    %rax,%rdi
  1bead2:	mov    %rbx,%rsi
  1bead5:	call   *0x2510425(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beadb:	lea    0x2462c16(%rip),%rdx        # 26216f8 <__gmpfr_one+0x9f78>
  1beae2:	mov    %rbx,%rsi
  1beae5:	call   *0x2510415(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beaeb:	lea    0x2462bee(%rip),%rdx        # 26216e0 <__gmpfr_one+0x9f60>
  1beaf2:	mov    %rax,%rdi
  1beaf5:	mov    %rbx,%rsi
  1beaf8:	call   *0x2510402(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beafe:	lea    0x2462d13(%rip),%rdx        # 2621818 <__gmpfr_one+0xa098>
  1beb05:	mov    %rbx,%rsi
  1beb08:	call   *0x25103f2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beb0e:	lea    0x2462ceb(%rip),%rdx        # 2621800 <__gmpfr_one+0xa080>
  1beb15:	mov    %rax,%rdi
  1beb18:	mov    %rbx,%rsi
  1beb1b:	call   *0x25103df(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beb21:	lea    0x24633e0(%rip),%rdx        # 2621f08 <__gmpfr_one+0xa788>
  1beb28:	mov    %rbx,%rsi
  1beb2b:	call   *0x25103cf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beb31:	lea    0x24633b8(%rip),%rdx        # 2621ef0 <__gmpfr_one+0xa770>
  1beb38:	mov    %rbx,%rsi
  1beb3b:	call   *0x25103bf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beb41:	lea    0x2463390(%rip),%rdx        # 2621ed8 <__gmpfr_one+0xa758>
  1beb48:	mov    %rbx,%rsi
  1beb4b:	call   *0x25103af(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beb51:	lea    0x2464538(%rip),%rdx        # 2623090 <__gmpfr_one+0xb910>
  1beb58:	mov    %rbx,%rsi
  1beb5b:	call   *0x251039f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beb61:	lea    0x2464510(%rip),%rdx        # 2623078 <__gmpfr_one+0xb8f8>
  1beb68:	mov    %rbx,%rsi
  1beb6b:	call   *0x251038f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beb71:	lea    0x24644e8(%rip),%rdx        # 2623060 <__gmpfr_one+0xb8e0>
  1beb78:	mov    %rbx,%rsi
  1beb7b:	call   *0x251037f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beb81:	lea    0x2462f60(%rip),%rdx        # 2621ae8 <__gmpfr_one+0xa368>
  1beb88:	mov    %rbx,%rsi
  1beb8b:	call   *0x251036f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beb91:	lea    0x2462f38(%rip),%rdx        # 2621ad0 <__gmpfr_one+0xa350>
  1beb98:	mov    %rbx,%rsi
  1beb9b:	call   *0x251035f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beba1:	lea    0x2463240(%rip),%rdx        # 2621de8 <__gmpfr_one+0xa668>
  1beba8:	mov    %rbx,%rsi
  1bebab:	call   *0x251034f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bebb1:	lea    0x2463218(%rip),%rdx        # 2621dd0 <__gmpfr_one+0xa650>
  1bebb8:	mov    %rbx,%rsi
  1bebbb:	call   *0x251033f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bebc1:	lea    0x24631f0(%rip),%rdx        # 2621db8 <__gmpfr_one+0xa638>
  1bebc8:	mov    %rbx,%rsi
  1bebcb:	call   *0x251032f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bebd1:	lea    0x24632b8(%rip),%rdx        # 2621e90 <__gmpfr_one+0xa710>
  1bebd8:	mov    %rbx,%rsi
  1bebdb:	call   *0x251031f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bebe1:	lea    0x2463290(%rip),%rdx        # 2621e78 <__gmpfr_one+0xa6f8>
  1bebe8:	mov    %r14,%rdi
  1bebeb:	mov    %rbx,%rsi
  1bebee:	call   *0x251030c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bebf4:	lea    0x24630b5(%rip),%rdx        # 2621cb0 <__gmpfr_one+0xa530>
  1bebfb:	mov    %rax,%rdi
  1bebfe:	mov    %rbx,%rsi
  1bec01:	call   *0x25102f9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bec07:	lea    0x246308a(%rip),%rdx        # 2621c98 <__gmpfr_one+0xa518>
  1bec0e:	mov    %rbx,%rsi
  1bec11:	call   *0x25102e9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bec17:	lea    0x246310a(%rip),%rdx        # 2621d28 <__gmpfr_one+0xa5a8>
  1bec1e:	mov    %rbx,%rsi
  1bec21:	call   *0x25102d9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bec27:	lea    0x24630e2(%rip),%rdx        # 2621d10 <__gmpfr_one+0xa590>
  1bec2e:	mov    %rbx,%rsi
  1bec31:	call   *0x25102c9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bec37:	lea    0x24630ba(%rip),%rdx        # 2621cf8 <__gmpfr_one+0xa578>
  1bec3e:	mov    %rbx,%rsi
  1bec41:	call   *0x25102b9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bec47:	lea    0x2463542(%rip),%rdx        # 2622190 <__gmpfr_one+0xaa10>
  1bec4e:	mov    %rbx,%rsi
  1bec51:	call   *0x25102a9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bec57:	lea    0x246351a(%rip),%rdx        # 2622178 <__gmpfr_one+0xa9f8>
  1bec5e:	mov    %rbx,%rsi
  1bec61:	call   *0x2510299(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bec67:	lea    0x2464e5a(%rip),%rdx        # 2623ac8 <__gmpfr_one+0xc348>
  1bec6e:	mov    0x1d0(%rsp),%rsi
  1bec76:	call   *0x2510284(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bec7c:	lea    0x2463fed(%rip),%rdx        # 2622c70 <__gmpfr_one+0xb4f0>
  1bec83:	mov    %rbx,%rsi
  1bec86:	call   *0x2510274(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bec8c:	lea    0x2463fc5(%rip),%rdx        # 2622c58 <__gmpfr_one+0xb4d8>
  1bec93:	mov    %rbx,%rsi
  1bec96:	call   *0x2510264(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bec9c:	lea    0x2463f9d(%rip),%rdx        # 2622c40 <__gmpfr_one+0xb4c0>
  1beca3:	mov    %rbx,%rsi
  1beca6:	call   *0x2510254(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1becac:	lea    0x24642bd(%rip),%rdx        # 2622f70 <__gmpfr_one+0xb7f0>
  1becb3:	mov    %rbx,%rsi
  1becb6:	call   *0x2510244(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1becbc:	lea    0x2464295(%rip),%rdx        # 2622f58 <__gmpfr_one+0xb7d8>
  1becc3:	mov    %rbx,%rsi
  1becc6:	call   *0x2510234(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beccc:	lea    0x246426d(%rip),%rdx        # 2622f40 <__gmpfr_one+0xb7c0>
  1becd3:	mov    %rbx,%rsi
  1becd6:	call   *0x2510224(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1becdc:	lea    0x2464335(%rip),%rdx        # 2623018 <__gmpfr_one+0xb898>
  1bece3:	mov    %rbx,%rsi
  1bece6:	call   *0x2510214(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1becec:	lea    0x246430d(%rip),%rdx        # 2623000 <__gmpfr_one+0xb880>
  1becf3:	mov    %r14,%rdi
  1becf6:	mov    %rbx,%rsi
  1becf9:	call   *0x2510201(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1becff:	lea    0x2464132(%rip),%rdx        # 2622e38 <__gmpfr_one+0xb6b8>
  1bed06:	mov    %rax,%rdi
  1bed09:	mov    %rbx,%rsi
  1bed0c:	call   *0x25101ee(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bed12:	lea    0x2464107(%rip),%rdx        # 2622e20 <__gmpfr_one+0xb6a0>
  1bed19:	mov    %rbx,%rsi
  1bed1c:	call   *0x25101de(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bed22:	lea    0x2464187(%rip),%rdx        # 2622eb0 <__gmpfr_one+0xb730>
  1bed29:	mov    %rbx,%rsi
  1bed2c:	call   *0x25101ce(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bed32:	lea    0x246415f(%rip),%rdx        # 2622e98 <__gmpfr_one+0xb718>
  1bed39:	mov    %rbx,%rsi
  1bed3c:	call   *0x25101be(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bed42:	lea    0x2464137(%rip),%rdx        # 2622e80 <__gmpfr_one+0xb700>
  1bed49:	mov    %rbx,%rsi
  1bed4c:	call   *0x25101ae(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bed52:	lea    0x24645bf(%rip),%rdx        # 2623318 <__gmpfr_one+0xbb98>
  1bed59:	mov    %rbx,%rsi
  1bed5c:	call   *0x251019e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bed62:	lea    0x2464597(%rip),%rdx        # 2623300 <__gmpfr_one+0xbb80>
  1bed69:	mov    %rbx,%rsi
  1bed6c:	call   *0x251018e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bed72:	lea    0x246456f(%rip),%rdx        # 26232e8 <__gmpfr_one+0xbb68>
  1bed79:	mov    %rbx,%rsi
  1bed7c:	call   *0x251017e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bed82:	lea    0x24629ff(%rip),%rdx        # 2621788 <__gmpfr_one+0xa008>
  1bed89:	mov    %rbx,%rsi
  1bed8c:	call   *0x251016e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bed92:	lea    0x24629d7(%rip),%rdx        # 2621770 <__gmpfr_one+0x9ff0>
  1bed99:	mov    %rcx,%rdi
  1bed9c:	mov    %rbx,%rsi
  1bed9f:	call   *0x251015b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beda5:	lea    0x24629ac(%rip),%rdx        # 2621758 <__gmpfr_one+0x9fd8>
  1bedac:	mov    %rax,%rdi
  1bedaf:	mov    %rbx,%rsi
  1bedb2:	call   *0x2510148(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bedb8:	lea    0x2462ae9(%rip),%rdx        # 26218a8 <__gmpfr_one+0xa128>
  1bedbf:	mov    %rbx,%rsi
  1bedc2:	call   *0x2510138(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bedc8:	lea    0x2462ac1(%rip),%rdx        # 2621890 <__gmpfr_one+0xa110>
  1bedcf:	mov    %rcx,%rdi
  1bedd2:	mov    %rbx,%rsi
  1bedd5:	call   *0x2510125(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beddb:	lea    0x2462a96(%rip),%rdx        # 2621878 <__gmpfr_one+0xa0f8>
  1bede2:	mov    %rax,%rdi
  1bede5:	mov    %rbx,%rsi
  1bede8:	call   *0x2510112(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bedee:	lea    0x24623ab(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bedf5:	mov    $0x1,%edi
  1bedfa:	mov    0x1e0(%rsp),%rsi
  1bee02:	call   *0x25100f8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bee08:	lea    0x2462931(%rip),%rdx        # 2621740 <__gmpfr_one+0x9fc0>
  1bee0f:	mov    %rbx,%rsi
  1bee12:	call   *0x25100e8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bee18:	lea    0x2462909(%rip),%rdx        # 2621728 <__gmpfr_one+0x9fa8>
  1bee1f:	mov    %rbx,%rsi
  1bee22:	call   *0x25100d8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bee28:	lea    0x24628e1(%rip),%rdx        # 2621710 <__gmpfr_one+0x9f90>
  1bee2f:	mov    %rbx,%rsi
  1bee32:	call   *0x25100c8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bee38:	lea    0x2462a21(%rip),%rdx        # 2621860 <__gmpfr_one+0xa0e0>
  1bee3f:	mov    %rbx,%rsi
  1bee42:	call   *0x25100b8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bee48:	lea    0x24629f9(%rip),%rdx        # 2621848 <__gmpfr_one+0xa0c8>
  1bee4f:	mov    %rbx,%rsi
  1bee52:	call   *0x25100a8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bee58:	lea    0x24629d1(%rip),%rdx        # 2621830 <__gmpfr_one+0xa0b0>
  1bee5f:	mov    %rbx,%rsi
  1bee62:	call   *0x2510098(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bee68:	lea    0x2462349(%rip),%rdx        # 26211b8 <__gmpfr_one+0x9a38>
  1bee6f:	mov    %rsi,%rdi
  1bee72:	mov    %rbx,%rsi
  1bee75:	call   *0x2510085(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bee7b:	lea    0x246279e(%rip),%rdx        # 2621620 <__gmpfr_one+0x9ea0>
  1bee82:	mov    %rbx,%rsi
  1bee85:	call   *0x2510075(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bee8b:	lea    0x2462776(%rip),%rdx        # 2621608 <__gmpfr_one+0x9e88>
  1bee92:	mov    %rbx,%rsi
  1bee95:	call   *0x2510065(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bee9b:	lea    0x246274e(%rip),%rdx        # 26215f0 <__gmpfr_one+0x9e70>
  1beea2:	mov    %rbx,%rsi
  1beea5:	call   *0x2510055(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beeab:	lea    0x2462396(%rip),%rdx        # 2621248 <__gmpfr_one+0x9ac8>
  1beeb2:	mov    %rsi,%rdi
  1beeb5:	mov    %rbx,%rsi
  1beeb8:	call   *0x2510042(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beebe:	lea    0x246236b(%rip),%rdx        # 2621230 <__gmpfr_one+0x9ab0>
  1beec5:	mov    %rsi,%rdi
  1beec8:	mov    %rbx,%rsi
  1beecb:	call   *0x251002f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beed1:	lea    0x2462340(%rip),%rdx        # 2621218 <__gmpfr_one+0x9a98>
  1beed8:	mov    %rsi,%rdi
  1beedb:	mov    %rbx,%rsi
  1beede:	call   *0x251001c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beee4:	lea    0x2462315(%rip),%rdx        # 2621200 <__gmpfr_one+0x9a80>
  1beeeb:	mov    %rcx,%rdi
  1beeee:	mov    %rbx,%rsi
  1beef1:	call   *0x2510009(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beef7:	lea    0x24623da(%rip),%rdx        # 26212d8 <__gmpfr_one+0x9b58>
  1beefe:	mov    %rcx,%rdi
  1bef01:	mov    %rbx,%rsi
  1bef04:	call   *0x250fff6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bef0a:	lea    0x24623af(%rip),%rdx        # 26212c0 <__gmpfr_one+0x9b40>
  1bef11:	mov    %rax,%rdi
  1bef14:	mov    %rbx,%rsi
  1bef17:	call   *0x250ffe3(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bef1d:	lea    0x24627a4(%rip),%rdx        # 26216c8 <__gmpfr_one+0x9f48>
  1bef24:	mov    %rbx,%rsi
  1bef27:	call   *0x250ffd3(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bef2d:	lea    0x246277c(%rip),%rdx        # 26216b0 <__gmpfr_one+0x9f30>
  1bef34:	mov    %r12,%rdi
  1bef37:	mov    %rbx,%rsi
  1bef3a:	call   *0x250ffc0(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bef40:	lea    0x2462409(%rip),%rdx        # 2621350 <__gmpfr_one+0x9bd0>
  1bef47:	mov    %rbx,%rsi
  1bef4a:	call   *0x250ffb0(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bef50:	mov    %r11,0x20(%rsp)
  1bef55:	lea    0x24623c4(%rip),%rdx        # 2621320 <__gmpfr_one+0x9ba0>
  1bef5c:	mov    0x20(%rsp),%rdi
  1bef61:	mov    0x8(%rsp),%rsi
  1bef66:	call   *0x250ff94(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bef6c:	lea    0x2462455(%rip),%rdx        # 26213c8 <__gmpfr_one+0x9c48>
  1bef73:	mov    %rax,%rdi
  1bef76:	mov    %rbx,%rsi
  1bef79:	call   *0x250ff81(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bef7f:	lea    0x246242a(%rip),%rdx        # 26213b0 <__gmpfr_one+0x9c30>
  1bef86:	mov    %rbx,%rsi
  1bef89:	call   *0x250ff71(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bef8f:	lea    0x2462852(%rip),%rdx        # 26217e8 <__gmpfr_one+0xa068>
  1bef96:	mov    %rbx,%rsi
  1bef99:	call   *0x250ff61(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bef9f:	lea    0x246282a(%rip),%rdx        # 26217d0 <__gmpfr_one+0xa050>
  1befa6:	mov    %r14,%rdi
  1befa9:	mov    %rbx,%rsi
  1befac:	call   *0x250ff4e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1befb2:	lea    0x246249f(%rip),%rdx        # 2621458 <__gmpfr_one+0x9cd8>
  1befb9:	mov    %rax,%rdi
  1befbc:	mov    %rbx,%rsi
  1befbf:	call   *0x250ff3b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1befc5:	lea    0x2462474(%rip),%rdx        # 2621440 <__gmpfr_one+0x9cc0>
  1befcc:	mov    %rax,%rdi
  1befcf:	mov    %rbx,%rsi
  1befd2:	call   *0x250ff28(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1befd8:	lea    0x2462449(%rip),%rdx        # 2621428 <__gmpfr_one+0x9ca8>
  1befdf:	mov    %rax,%rdi
  1befe2:	mov    %rbx,%rsi
  1befe5:	call   *0x250ff15(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1befeb:	lea    0x246241e(%rip),%rdx        # 2621410 <__gmpfr_one+0x9c90>
  1beff2:	mov    %rax,%rdi
  1beff5:	mov    %rbx,%rsi
  1beff8:	call   *0x250ff02(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1beffe:	lea    0x24624e3(%rip),%rdx        # 26214e8 <__gmpfr_one+0x9d68>
  1bf005:	mov    %rax,%rdi
  1bf008:	mov    %rbx,%rsi
  1bf00b:	call   *0x250feef(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf011:	lea    0x24624b8(%rip),%rdx        # 26214d0 <__gmpfr_one+0x9d50>
  1bf018:	mov    %rbx,%rsi
  1bf01b:	call   *0x250fedf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf021:	lea    0x2462538(%rip),%rdx        # 2621560 <__gmpfr_one+0x9de0>
  1bf028:	mov    %rbx,%rsi
  1bf02b:	call   *0x250fecf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf031:	lea    0x2462510(%rip),%rdx        # 2621548 <__gmpfr_one+0x9dc8>
  1bf038:	mov    %rbx,%rsi
  1bf03b:	call   *0x250febf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf041:	lea    0x24624e8(%rip),%rdx        # 2621530 <__gmpfr_one+0x9db0>
  1bf048:	mov    %rbx,%rsi
  1bf04b:	call   *0x250feaf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf051:	lea    0x2462148(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bf058:	mov    $0x4,%edi
  1bf05d:	mov    0x1e0(%rsp),%rsi
  1bf065:	call   *0x250fe95(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf06b:	lea    0x246212e(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bf072:	mov    $0x4,%edi
  1bf077:	mov    0x1e0(%rsp),%rsi
  1bf07f:	call   *0x250fe7b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf085:	lea    0x2462114(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bf08c:	mov    $0x6,%edi
  1bf091:	mov    0x1e0(%rsp),%rsi
  1bf099:	call   *0x250fe61(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf09f:	lea    0x24620fa(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bf0a6:	mov    $0x7,%edi
  1bf0ab:	mov    0x1e0(%rsp),%rsi
  1bf0b3:	call   *0x250fe47(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf0b9:	lea    0x24620e0(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bf0c0:	mov    $0x8,%edi
  1bf0c5:	mov    $0x8,%esi
  1bf0ca:	call   *0x250fe30(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf0d0:	add    %rcx,%r12
  1bf0d3:	cmp    %rbx,%r12
  1bf0d6:	jb     1bf21d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1639d>
  1bf0dc:	lea    0x2463cad(%rip),%rdx        # 2622d90 <__gmpfr_one+0xb610>
  1bf0e3:	mov    %r12,%rdi
  1bf0e6:	mov    0x8(%rsp),%rsi
  1bf0eb:	call   *0x250fe0f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf0f1:	add    (%rsp),%r12
  1bf0f5:	cmp    %rbx,%r12
  1bf0f8:	jb     1bf21d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1639d>
  1bf0fe:	lea    0x2464333(%rip),%rdx        # 2623438 <__gmpfr_one+0xbcb8>
  1bf105:	mov    %r12,%rdi
  1bf108:	mov    0x8(%rsp),%rsi
  1bf10d:	call   *0x250fded(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf113:	add    %rcx,%r13
  1bf116:	cmp    %rbx,%r13
  1bf119:	jb     1bf21d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1639d>
  1bf11f:	lea    0x24629da(%rip),%rdx        # 2621b00 <__gmpfr_one+0xa380>
  1bf126:	mov    %r13,%rdi
  1bf129:	mov    0x8(%rsp),%rsi
  1bf12e:	call   *0x250fdcc(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf134:	add    (%rsp),%r13
  1bf138:	cmp    %rbx,%r13
  1bf13b:	jb     1bf21d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1639d>
  1bf141:	lea    0x2463060(%rip),%rdx        # 26221a8 <__gmpfr_one+0xaa28>
  1bf148:	mov    %r13,%rdi
  1bf14b:	mov    0x8(%rsp),%rsi
  1bf150:	call   *0x250fdaa(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf156:	cmp    %rbx,%rdi
  1bf159:	jb     1bf21d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1639d>
  1bf15f:	lea    0x2463be2(%rip),%rdx        # 2622d48 <__gmpfr_one+0xb5c8>
  1bf166:	mov    0x8(%rsp),%rsi
  1bf16b:	call   *0x250fd8f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf171:	add    (%rsp),%rbp
  1bf175:	mov    %rbp,%rdi
  1bf178:	cmp    %rbx,%rbp
  1bf17b:	jb     1bf21d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1639d>
  1bf181:	lea    0x2464268(%rip),%rdx        # 26233f0 <__gmpfr_one+0xbc70>
  1bf188:	mov    0x8(%rsp),%rsi
  1bf18d:	call   *0x250fd6d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf193:	mov    0x20(%rsp),%rcx
  1bf198:	add    (%rsp),%rcx
  1bf19c:	mov    %rcx,%rax
  1bf19f:	cmp    %rbx,%rcx
  1bf1a2:	jb     1bf251 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163d1>
  1bf1a8:	lea    0x2462021(%rip),%rdx        # 26211d0 <__gmpfr_one+0x9a50>
  1bf1af:	mov    %rax,%rdi
  1bf1b2:	mov    0x8(%rsp),%rsi
  1bf1b7:	call   *0x250fd43(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf1bd:	cmp    %rbx,0x20(%rsp)
  1bf1c2:	jae    1be9c9 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x15b49>
  1bf1c8:	mov    0x20(%rsp),%rcx
  1bf1cd:	add    (%rsp),%rcx
  1bf1d1:	mov    %rcx,%rax
  1bf1d4:	cmp    0x8(%rsp),%rcx
  1bf1d9:	jb     1bf290 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16410>
  1bf1df:	lea    0x246219a(%rip),%rdx        # 2621380 <__gmpfr_one+0x9c00>
  1bf1e6:	mov    %rax,%rdi
  1bf1e9:	mov    0x8(%rsp),%rsi
  1bf1ee:	call   *0x250fd0c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf1f4:	add    %rax,%r13
  1bf1f7:	mov    %r13,%rdi
  1bf1fa:	cmp    %rbx,%r13
  1bf1fd:	jb     1bf21d <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x1639d>
  1bf1ff:	lea    0x24628b2(%rip),%rdx        # 2621ab8 <__gmpfr_one+0xa338>
  1bf206:	mov    0x8(%rsp),%rsi
  1bf20b:	call   *0x250fcef(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf211:	add    (%rsp),%r13
  1bf215:	mov    %r13,%rdi
  1bf218:	cmp    %rbx,%r13
  1bf21b:	jae    1bf22e <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163ae>
  1bf21d:	lea    0x2461f7c(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bf224:	xor    %edi,%edi
  1bf226:	xor    %esi,%esi
  1bf228:	call   *0x250fcd2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf22e:	lea    0x2462f2b(%rip),%rdx        # 2622160 <__gmpfr_one+0xa9e0>
  1bf235:	mov    0x8(%rsp),%rsi
  1bf23a:	call   *0x250fcc0(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf240:	mov    0x20(%rsp),%rax
  1bf245:	add    (%rsp),%rax
  1bf249:	mov    %rax,%rcx
  1bf24c:	cmp    %rbx,%rax
  1bf24f:	jae    1bf26b <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x163eb>
  1bf251:	lea    0x2461f48(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bf258:	mov    $0x1,%edi
  1bf25d:	mov    0x1e0(%rsp),%rsi
  1bf265:	call   *0x250fc95(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf26b:	lea    0x2461f16(%rip),%rdx        # 2621188 <__gmpfr_one+0x9a08>
  1bf272:	mov    %rcx,%rdi
  1bf275:	mov    0x8(%rsp),%rsi
  1bf27a:	call   *0x250fc80(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf280:	cmp    %rbx,%r8
  1bf283:	jae    1bef55 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x160d5>
  1bf289:	cmp    0x8(%rsp),%rdi
  1bf28e:	jae    1bf2a7 <native_dense_fixed_b0::generated::candidate::batch_block_0::<f64>+0x16427>
  1bf290:	lea    0x2461f09(%rip),%rdx        # 26211a0 <__gmpfr_one+0x9a20>
  1bf297:	mov    $0x2,%edi
  1bf29c:	mov    $0x2,%esi
  1bf2a1:	call   *0x250fc59(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1bf2a7:	lea    0x246208a(%rip),%rdx        # 2621338 <__gmpfr_one+0x9bb8>
  1bf2ae:	mov    0x8(%rsp),%rsi
  1bf2b3:	call   *0x250fc47(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
