
target/native-dense-span/probe-fixed-b0:     file format elf64-x86-64


Disassembly of section .text:

00000000001fa280 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>>:
  1fa280:	push   %rbp
  1fa281:	push   %r15
  1fa283:	push   %r14
  1fa285:	push   %r13
  1fa287:	push   %r12
  1fa289:	push   %rbx
  1fa28a:	sub    $0xb8,%rsp
  1fa291:	mov    %r8,%r15
  1fa294:	mov    %rcx,0x38(%rsp)
  1fa299:	mov    %rsi,%rbx
  1fa29c:	mov    %rdi,%rbp
  1fa29f:	mov    0x110(%rsp),%r10
  1fa2a7:	mov    0x108(%rsp),%r11
  1fa2af:	mov    0x100(%rsp),%r8
  1fa2b7:	mov    0xf8(%rsp),%rax
  1fa2bf:	mov    0xf0(%rsp),%r12
  1fa2c7:	mov    (%rax),%rcx
  1fa2ca:	test   %rcx,%rcx
  1fa2cd:	mov    %rdx,0x8(%rsp)
  1fa2d2:	mov    %r9,0x10(%rsp)
  1fa2d7:	je     1fb19e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf1e>
  1fa2dd:	xor    %eax,%eax
  1fa2df:	xorpd  %xmm0,%xmm0
  1fa2e3:	xor    %r14d,%r14d
  1fa2e6:	jmp    1fa2f8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x78>
  1fa2e8:	nopl   0x0(%rax,%rax,1)
  1fa2f0:	inc    %r14
  1fa2f3:	cmp    %r14,%rcx
  1fa2f6:	je     1fa362 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xe2>
  1fa2f8:	cmp    %r14,%r12
  1fa2fb:	je     200790 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6510>
  1fa301:	mov    (%r9,%r14,8),%rdi
  1fa305:	cmp    %rbx,%rdi
  1fa308:	jae    2007a3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6523>
  1fa30e:	mov    %rdi,%rsi
  1fa311:	shl    $0x4,%rsi
  1fa315:	movsd  0x0(%rbp,%rsi,1),%xmm1
  1fa31b:	ucomisd %xmm0,%xmm1
  1fa31f:	jne    1fa350 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xd0>
  1fa321:	jp     1fa350 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xd0>
  1fa323:	add    %rbp,%rsi
  1fa326:	movsd  0x8(%rsi),%xmm1
  1fa32b:	ucomisd %xmm0,%xmm1
  1fa32f:	jne    1fa350 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xd0>
  1fa331:	jp     1fa350 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xd0>
  1fa333:	cmp    %r11,%rdi
  1fa336:	jae    201057 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6dd7>
  1fa33c:	movq   $0x16c,(%r8,%rdi,8)
  1fa344:	jmp    1fa2f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x70>
  1fa346:	cs nopw 0x0(%rax,%rax,1)
  1fa350:	cmp    %r12,%rax
  1fa353:	jae    200d0e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6a8e>
  1fa359:	mov    %rdi,(%r9,%rax,8)
  1fa35d:	inc    %rax
  1fa360:	jmp    1fa2f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x70>
  1fa362:	test   %rax,%rax
  1fa365:	je     1fb19e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf1e>
  1fa36b:	xor    %edi,%edi
  1fa36d:	xorpd  %xmm0,%xmm0
  1fa371:	xor    %r14d,%r14d
  1fa374:	jmp    1fa398 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x118>
  1fa376:	cs nopw 0x0(%rax,%rax,1)
  1fa380:	cmp    %r12,%rdi
  1fa383:	jae    2012cd <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x704d>
  1fa389:	mov    %rcx,(%r9,%rdi,8)
  1fa38d:	inc    %rdi
  1fa390:	inc    %r14
  1fa393:	cmp    %r14,%rax
  1fa396:	je     1fa3ed <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x16d>
  1fa398:	cmp    %r14,%r12
  1fa39b:	je     200915 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6695>
  1fa3a1:	mov    (%r9,%r14,8),%rcx
  1fa3a5:	lea    (%rcx,%rdx,1),%rsi
  1fa3a9:	cmp    %rbx,%rsi
  1fa3ac:	jae    200928 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x66a8>
  1fa3b2:	shl    $0x4,%rsi
  1fa3b6:	movsd  0x0(%rbp,%rsi,1),%xmm1
  1fa3bc:	ucomisd %xmm0,%xmm1
  1fa3c0:	jne    1fa380 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x100>
  1fa3c2:	jp     1fa380 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x100>
  1fa3c4:	add    %rbp,%rsi
  1fa3c7:	movsd  0x8(%rsi),%xmm1
  1fa3cc:	ucomisd %xmm0,%xmm1
  1fa3d0:	jne    1fa380 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x100>
  1fa3d2:	jp     1fa380 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x100>
  1fa3d4:	cmp    %r11,%rcx
  1fa3d7:	jae    201590 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7310>
  1fa3dd:	movq   $0x119,(%r8,%rcx,8)
  1fa3e5:	inc    %r14
  1fa3e8:	cmp    %r14,%rax
  1fa3eb:	jne    1fa398 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x118>
  1fa3ed:	test   %rdi,%rdi
  1fa3f0:	je     1fb19e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf1e>
  1fa3f6:	lea    (%rdx,%rdx,1),%r14
  1fa3fa:	xor    %esi,%esi
  1fa3fc:	xorpd  %xmm0,%xmm0
  1fa400:	xor    %r13d,%r13d
  1fa403:	jmp    1fa429 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1a9>
  1fa405:	data16 cs nopw 0x0(%rax,%rax,1)
  1fa410:	cmp    %r11,%rax
  1fa413:	jae    2019dc <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x775c>
  1fa419:	movq   $0xc6,(%r8,%rax,8)
  1fa421:	inc    %r13
  1fa424:	cmp    %r13,%rdi
  1fa427:	je     1fa47d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1fd>
  1fa429:	cmp    %r13,%r12
  1fa42c:	je     201067 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6de7>
  1fa432:	mov    (%r9,%r13,8),%rax
  1fa436:	lea    (%rax,%r14,1),%rcx
  1fa43a:	cmp    %rbx,%rcx
  1fa43d:	jae    20107a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6dfa>
  1fa443:	shl    $0x4,%rcx
  1fa447:	movsd  0x0(%rbp,%rcx,1),%xmm1
  1fa44d:	ucomisd %xmm0,%xmm1
  1fa451:	jne    1fa465 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1e5>
  1fa453:	jp     1fa465 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1e5>
  1fa455:	add    %rbp,%rcx
  1fa458:	movsd  0x8(%rcx),%xmm1
  1fa45d:	ucomisd %xmm0,%xmm1
  1fa461:	jne    1fa465 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1e5>
  1fa463:	jnp    1fa410 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x190>
  1fa465:	cmp    %r12,%rsi
  1fa468:	jae    201923 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x76a3>
  1fa46e:	mov    %rax,(%r9,%rsi,8)
  1fa472:	inc    %rsi
  1fa475:	inc    %r13
  1fa478:	cmp    %r13,%rdi
  1fa47b:	jne    1fa429 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1a9>
  1fa47d:	cmp    %r12,%rsi
  1fa480:	ja     200561 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x62e1>
  1fa486:	test   %rsi,%rsi
  1fa489:	je     1fb19e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf1e>
  1fa48f:	mov    0x118(%rsp),%r11
  1fa497:	cmp    $0x2,%r11
  1fa49b:	jb     201b46 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x78c6>
  1fa4a1:	lea    0x0(,%rsi,8),%r13
  1fa4a9:	mov    0x8(%rsp),%rax
  1fa4ae:	lea    0x0(,%rax,8),%r8
  1fa4b6:	mov    %r8,%rdx
  1fa4b9:	sub    %rax,%rdx
  1fa4bc:	xor    %ecx,%ecx
  1fa4be:	mov    %r14,%r12
  1fa4c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fa4d0:	mov    (%r9,%rcx,1),%rdi
  1fa4d4:	mov    0x8(%rsp),%rax
  1fa4d9:	add    %rdi,%rax
  1fa4dc:	cmp    %rbx,%rax
  1fa4df:	jae    201b70 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x78f0>
  1fa4e5:	add    %rdx,%rdi
  1fa4e8:	cmp    %rbx,%rdi
  1fa4eb:	jae    2015c6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7346>
  1fa4f1:	shl    $0x4,%rax
  1fa4f5:	movupd 0x10(%r10),%xmm2
  1fa4fb:	shl    $0x4,%rdi
  1fa4ff:	movupd 0x0(%rbp,%rax,1),%xmm3
  1fa505:	movapd %xmm2,%xmm0
  1fa509:	unpcklpd %xmm2,%xmm0
  1fa50d:	movapd %xmm0,%xmm4
  1fa511:	mulpd  %xmm3,%xmm4
  1fa515:	shufpd $0x1,%xmm3,%xmm3
  1fa51a:	movapd %xmm2,%xmm1
  1fa51e:	unpckhpd %xmm2,%xmm1
  1fa522:	mulpd  %xmm1,%xmm3
  1fa526:	movapd %xmm4,%xmm5
  1fa52a:	subpd  %xmm3,%xmm5
  1fa52e:	addpd  %xmm4,%xmm3
  1fa532:	movsd  %xmm5,%xmm3
  1fa536:	movupd %xmm3,0x0(%rbp,%rdi,1)
  1fa53c:	add    $0x8,%rcx
  1fa540:	cmp    %rcx,%r13
  1fa543:	jne    1fa4d0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x250>
  1fa545:	xor    %r10d,%r10d
  1fa548:	nopl   0x0(%rax,%rax,1)
  1fa550:	mov    (%r9,%r10,1),%rdi
  1fa554:	cmp    %rbx,%rdi
  1fa557:	jae    20160f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x738f>
  1fa55d:	lea    (%rdi,%r12,1),%rax
  1fa561:	cmp    %rbx,%rax
  1fa564:	jae    2015fc <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x737c>
  1fa56a:	lea    (%rdi,%rdx,1),%rcx
  1fa56e:	cmp    %rbx,%rcx
  1fa571:	jae    2015e9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7369>
  1fa577:	lea    (%rdi,%r8,1),%r14
  1fa57b:	cmp    %rbx,%r14
  1fa57e:	jae    2015d6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7356>
  1fa584:	shl    $0x4,%rdi
  1fa588:	shl    $0x4,%rax
  1fa58c:	shl    $0x4,%rcx
  1fa590:	shl    $0x4,%r14
  1fa594:	movupd 0x0(%rbp,%rdi,1),%xmm3
  1fa59a:	movupd 0x0(%rbp,%rax,1),%xmm4
  1fa5a0:	addpd  %xmm3,%xmm4
  1fa5a4:	movupd 0x0(%rbp,%rcx,1),%xmm3
  1fa5aa:	addpd  %xmm4,%xmm3
  1fa5ae:	movupd %xmm3,0x0(%rbp,%r14,1)
  1fa5b5:	add    $0x8,%r10
  1fa5b9:	cmp    %r10,%r13
  1fa5bc:	jne    1fa550 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2d0>
  1fa5be:	mov    0x8(%rsp),%rax
  1fa5c3:	lea    (%rax,%rax,8),%r14
  1fa5c7:	movapd %xmm2,%xmm3
  1fa5cb:	shufpd $0x1,%xmm2,%xmm3
  1fa5d0:	xor    %ecx,%ecx
  1fa5d2:	mov    0x110(%rsp),%r10
  1fa5da:	nopw   0x0(%rax,%rax,1)
  1fa5e0:	mov    (%r9,%rcx,1),%rdi
  1fa5e4:	lea    (%rdi,%r8,1),%rax
  1fa5e8:	cmp    %rbx,%rax
  1fa5eb:	jae    20162f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x73af>
  1fa5f1:	add    %r14,%rdi
  1fa5f4:	cmp    %rbx,%rdi
  1fa5f7:	jae    20161f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x739f>
  1fa5fd:	shl    $0x4,%rax
  1fa601:	shl    $0x4,%rdi
  1fa605:	movsd  0x0(%rbp,%rax,1),%xmm4
  1fa60b:	movsd  0x8(%rbp,%rax,1),%xmm5
  1fa611:	unpcklpd %xmm4,%xmm4
  1fa615:	mulpd  %xmm2,%xmm4
  1fa619:	unpcklpd %xmm5,%xmm5
  1fa61d:	mulpd  %xmm3,%xmm5
  1fa621:	movapd %xmm4,%xmm6
  1fa625:	subpd  %xmm5,%xmm6
  1fa629:	addpd  %xmm4,%xmm5
  1fa62d:	movsd  %xmm6,%xmm5
  1fa631:	movupd %xmm5,0x0(%rbp,%rdi,1)
  1fa637:	add    $0x8,%rcx
  1fa63b:	cmp    %rcx,%r13
  1fa63e:	jne    1fa5e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x360>
  1fa640:	cmp    $0x2,%r11
  1fa644:	je     201b83 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7903>
  1fa64a:	lea    (%r12,%r12,4),%r8
  1fa64e:	xor    %r11d,%r11d
  1fa651:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fa660:	mov    (%r9,%r11,1),%rax
  1fa664:	cmp    %rbx,%rax
  1fa667:	jae    201baf <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x792f>
  1fa66d:	mov    0x8(%rsp),%rcx
  1fa672:	add    %rax,%rcx
  1fa675:	cmp    %rbx,%rcx
  1fa678:	jae    201bc2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7942>
  1fa67e:	lea    (%rax,%r8,1),%rdi
  1fa682:	cmp    %rbx,%rdi
  1fa685:	jae    201642 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x73c2>
  1fa68b:	shl    $0x4,%rcx
  1fa68f:	shl    $0x4,%rax
  1fa693:	movupd 0x0(%rbp,%rcx,1),%xmm2
  1fa699:	movupd 0x0(%rbp,%rax,1),%xmm3
  1fa69f:	movapd %xmm2,%xmm4
  1fa6a3:	mulpd  %xmm3,%xmm4
  1fa6a7:	shl    $0x4,%rdi
  1fa6ab:	movupd 0x20(%r10),%xmm5
  1fa6b1:	movapd %xmm4,%xmm6
  1fa6b5:	unpcklpd %xmm4,%xmm6
  1fa6b9:	unpckhpd %xmm4,%xmm4
  1fa6bd:	subpd  %xmm4,%xmm6
  1fa6c1:	mulpd  %xmm5,%xmm6
  1fa6c5:	movapd %xmm3,%xmm4
  1fa6c9:	unpckhpd %xmm3,%xmm4
  1fa6cd:	mulsd  %xmm2,%xmm4
  1fa6d1:	unpckhpd %xmm2,%xmm2
  1fa6d5:	mulsd  %xmm3,%xmm2
  1fa6d9:	addsd  %xmm4,%xmm2
  1fa6dd:	unpcklpd %xmm2,%xmm2
  1fa6e1:	shufpd $0x1,%xmm5,%xmm5
  1fa6e6:	mulpd  %xmm2,%xmm5
  1fa6ea:	movapd %xmm6,%xmm2
  1fa6ee:	subpd  %xmm5,%xmm2
  1fa6f2:	addpd  %xmm6,%xmm5
  1fa6f6:	movsd  %xmm2,%xmm5
  1fa6fa:	movupd %xmm5,0x0(%rbp,%rdi,1)
  1fa700:	add    $0x8,%r11
  1fa704:	cmp    %r11,%r13
  1fa707:	jne    1fa660 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3e0>
  1fa70d:	mov    0x8(%rsp),%rax
  1fa712:	lea    (%rax,%rax,4),%rcx
  1fa716:	mov    %rcx,0x50(%rsp)
  1fa71b:	lea    (%rax,%rcx,2),%r10
  1fa71f:	xor    %ecx,%ecx
  1fa721:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fa730:	mov    (%r9,%rcx,1),%rax
  1fa734:	cmp    %rbx,%rax
  1fa737:	jae    201662 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x73e2>
  1fa73d:	lea    (%rax,%r10,1),%rdi
  1fa741:	cmp    %rbx,%rdi
  1fa744:	jae    201652 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x73d2>
  1fa74a:	shl    $0x4,%rax
  1fa74e:	shl    $0x4,%rdi
  1fa752:	movupd 0x0(%rbp,%rax,1),%xmm2
  1fa758:	movapd %xmm0,%xmm3
  1fa75c:	mulpd  %xmm2,%xmm3
  1fa760:	shufpd $0x1,%xmm2,%xmm2
  1fa765:	mulpd  %xmm1,%xmm2
  1fa769:	movapd %xmm3,%xmm4
  1fa76d:	subpd  %xmm2,%xmm4
  1fa771:	addpd  %xmm3,%xmm2
  1fa775:	movsd  %xmm4,%xmm2
  1fa779:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fa77f:	add    $0x8,%rcx
  1fa783:	cmp    %rcx,%r13
  1fa786:	jne    1fa730 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4b0>
  1fa788:	mov    %r14,0x48(%rsp)
  1fa78d:	mov    %rsi,0x58(%rsp)
  1fa792:	mov    0x8(%rsp),%rax
  1fa797:	lea    0x0(,%rax,4),%r9
  1fa79f:	lea    (%r9,%r9,2),%r14
  1fa7a3:	xor    %r11d,%r11d
  1fa7a6:	cs nopw 0x0(%rax,%rax,1)
  1fa7b0:	mov    0x10(%rsp),%rax
  1fa7b5:	mov    (%rax,%r11,1),%rdi
  1fa7b9:	lea    (%rdi,%r12,1),%rax
  1fa7bd:	cmp    %rbx,%rax
  1fa7c0:	jae    2016ab <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x742b>
  1fa7c6:	lea    (%rdi,%rdx,1),%rcx
  1fa7ca:	cmp    %rbx,%rcx
  1fa7cd:	jae    201698 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7418>
  1fa7d3:	lea    (%rdi,%r10,1),%rsi
  1fa7d7:	cmp    %rbx,%rsi
  1fa7da:	jae    201685 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7405>
  1fa7e0:	add    %r14,%rdi
  1fa7e3:	cmp    %rbx,%rdi
  1fa7e6:	jae    201675 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x73f5>
  1fa7ec:	shl    $0x4,%rax
  1fa7f0:	shl    $0x4,%rcx
  1fa7f4:	shl    $0x4,%rsi
  1fa7f8:	shl    $0x4,%rdi
  1fa7fc:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fa802:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fa808:	addpd  %xmm0,%xmm1
  1fa80c:	movupd 0x0(%rbp,%rsi,1),%xmm0
  1fa812:	addpd  %xmm1,%xmm0
  1fa816:	movupd %xmm0,0x0(%rbp,%rdi,1)
  1fa81c:	add    $0x8,%r11
  1fa820:	cmp    %r11,%r13
  1fa823:	jne    1fa7b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x530>
  1fa825:	mov    %r9,0x60(%rsp)
  1fa82a:	mov    0x8(%rsp),%rcx
  1fa82f:	lea    (%rcx,%rcx,2),%rax
  1fa833:	lea    (%rcx,%rax,4),%rdx
  1fa837:	xor    %ecx,%ecx
  1fa839:	mov    0x10(%rsp),%r9
  1fa83e:	mov    0x110(%rsp),%r10
  1fa846:	cs nopw 0x0(%rax,%rax,1)
  1fa850:	mov    (%r9,%rcx,1),%rdi
  1fa854:	lea    (%rdi,%r14,1),%rax
  1fa858:	cmp    %rbx,%rax
  1fa85b:	jae    2016ce <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x744e>
  1fa861:	add    %rdx,%rdi
  1fa864:	cmp    %rbx,%rdi
  1fa867:	jae    2016be <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x743e>
  1fa86d:	shl    $0x4,%rax
  1fa871:	movsd  0x0(%rbp,%rax,1),%xmm0
  1fa877:	movsd  0x8(%rbp,%rax,1),%xmm1
  1fa87d:	movapd %xmm0,%xmm2
  1fa881:	mulsd  %xmm1,%xmm2
  1fa885:	addsd  %xmm2,%xmm2
  1fa889:	mulsd  %xmm0,%xmm0
  1fa88d:	mulsd  %xmm1,%xmm1
  1fa891:	subsd  %xmm1,%xmm0
  1fa895:	shl    $0x4,%rdi
  1fa899:	movsd  %xmm0,0x0(%rbp,%rdi,1)
  1fa89f:	movsd  %xmm2,0x8(%rbp,%rdi,1)
  1fa8a5:	add    $0x8,%rcx
  1fa8a9:	cmp    %rcx,%r13
  1fa8ac:	jne    1fa850 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5d0>
  1fa8ae:	mov    0x8(%rsp),%rax
  1fa8b3:	shl    $0x4,%rax
  1fa8b7:	mov    %rax,0x18(%rsp)
  1fa8bc:	mov    %rax,%r11
  1fa8bf:	sub    %r12,%r11
  1fa8c2:	xor    %esi,%esi
  1fa8c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fa8d0:	mov    (%r9,%rsi,1),%rdi
  1fa8d4:	lea    (%rdi,%r8,1),%rax
  1fa8d8:	cmp    %rbx,%rax
  1fa8db:	jae    201704 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7484>
  1fa8e1:	lea    (%rdi,%rdx,1),%rcx
  1fa8e5:	cmp    %rbx,%rcx
  1fa8e8:	jae    2016f1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7471>
  1fa8ee:	add    %r11,%rdi
  1fa8f1:	cmp    %rbx,%rdi
  1fa8f4:	jae    2016e1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7461>
  1fa8fa:	shl    $0x4,%rax
  1fa8fe:	shl    $0x4,%rcx
  1fa902:	shl    $0x4,%rdi
  1fa906:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fa90c:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fa912:	addpd  %xmm0,%xmm1
  1fa916:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fa91c:	add    $0x8,%rsi
  1fa920:	cmp    %rsi,%r13
  1fa923:	jne    1fa8d0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x650>
  1fa925:	mov    %r12,0x68(%rsp)
  1fa92a:	mov    %r11,%r12
  1fa92d:	mov    %r15,0x30(%rsp)
  1fa932:	mov    0x50(%rsp),%rax
  1fa937:	lea    (%rax,%rax,2),%r11
  1fa93b:	xor    %r15d,%r15d
  1fa93e:	xorpd  %xmm8,%xmm8
  1fa943:	movapd 0x1f9b6b5(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fa94b:	movapd 0x1f9b6bc(%rip),%xmm9        # 2196010 <_fini+0x530>
  1fa954:	movsd  0x1f9cd93(%rip),%xmm10        # 21976f0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3e0>
  1fa95d:	movsd  0x1f9cd4b(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fa965:	mov    %r11,0x40(%rsp)
  1fa96a:	mov    0x18(%rsp),%r8
  1fa96f:	nop
  1fa970:	mov    (%r9,%r15,1),%r14
  1fa974:	lea    (%r14,%r12,1),%rdi
  1fa978:	cmp    %rbx,%rdi
  1fa97b:	jae    20172a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x74aa>
  1fa981:	shl    $0x4,%rdi
  1fa985:	movupd 0x0(%rbp,%rdi,1),%xmm13
  1fa98c:	movapd %xmm13,%xmm12
  1fa991:	unpckhpd %xmm13,%xmm12
  1fa996:	movapd %xmm12,%xmm11
  1fa99b:	ucomisd %xmm8,%xmm12
  1fa9a0:	movapd %xmm13,%xmm0
  1fa9a5:	andpd  %xmm6,%xmm0
  1fa9a9:	jne    1fa9e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x760>
  1fa9ab:	jp     1fa9e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x760>
  1fa9ad:	sqrtsd %xmm0,%xmm0
  1fa9b1:	ucomisd %xmm13,%xmm8
  1fa9b6:	jbe    1fabd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x950>
  1fa9bc:	movq   %xmm12,%rax
  1fa9c1:	test   %rax,%rax
  1fa9c4:	jns    1fa9cb <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x74b>
  1fa9c6:	xorpd  %xmm9,%xmm0
  1fa9cb:	movapd %xmm0,%xmm11
  1fa9d0:	xorpd  %xmm0,%xmm0
  1fa9d4:	jmp    1fabd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x950>
  1fa9d9:	nopl   0x0(%rax)
  1fa9e0:	andpd  %xmm6,%xmm11
  1fa9e5:	movapd %xmm11,%xmm14
  1fa9ea:	cmplesd %xmm0,%xmm14
  1fa9f0:	movapd %xmm14,%xmm1
  1fa9f5:	andpd  %xmm0,%xmm1
  1fa9f9:	andnpd %xmm11,%xmm14
  1fa9fe:	orpd   %xmm1,%xmm14
  1faa03:	movapd %xmm14,%xmm1
  1faa08:	unpcklpd %xmm14,%xmm1
  1faa0d:	movapd %xmm13,%xmm0
  1faa12:	divpd  %xmm1,%xmm0
  1faa16:	movapd %xmm0,%xmm1
  1faa1a:	unpckhpd %xmm0,%xmm1
  1faa1e:	ucomisd %xmm8,%xmm1
  1faa23:	jne    1faa39 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7b9>
  1faa25:	jp     1faa39 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7b9>
  1faa27:	unpcklpd %xmm0,%xmm0
  1faa2b:	andpd  %xmm6,%xmm0
  1faa2f:	movapd %xmm0,%xmm15
  1faa34:	jmp    1fab60 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x8e0>
  1faa39:	ucomisd %xmm8,%xmm0
  1faa3e:	movapd %xmm0,%xmm15
  1faa43:	andpd  %xmm6,%xmm15
  1faa48:	jne    1faa50 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7d0>
  1faa4a:	jnp    1fab60 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x8e0>
  1faa50:	pshufd $0xee,%xmm15,%xmm3
  1faa56:	movapd %xmm15,%xmm4
  1faa5b:	cmplesd %xmm3,%xmm4
  1faa60:	movapd %xmm4,%xmm2
  1faa64:	andpd  %xmm3,%xmm2
  1faa68:	andnpd %xmm15,%xmm4
  1faa6d:	orpd   %xmm2,%xmm4
  1faa71:	movapd %xmm0,%xmm2
  1faa75:	cmpunordsd %xmm0,%xmm2
  1faa7a:	movapd %xmm2,%xmm5
  1faa7e:	andnpd %xmm4,%xmm5
  1faa82:	andpd  %xmm3,%xmm2
  1faa86:	orpd   %xmm5,%xmm2
  1faa8a:	ucomisd %xmm7,%xmm2
  1faa8e:	jbe    1faaba <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x83a>
  1faa90:	movsd  0x1f9cc20(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1faa98:	ucomisd %xmm2,%xmm3
  1faa9c:	jbe    1faaba <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x83a>
  1faa9e:	mulpd  %xmm0,%xmm0
  1faaa2:	movapd %xmm0,%xmm1
  1faaa6:	unpckhpd %xmm0,%xmm1
  1faaaa:	addsd  %xmm0,%xmm1
  1faaae:	xorps  %xmm0,%xmm0
  1faab1:	sqrtsd %xmm1,%xmm0
  1faab5:	jmp    1fab55 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x8d5>
  1faaba:	movapd %xmm11,0x20(%rsp)
  1faac1:	movapd %xmm12,0xa0(%rsp)
  1faacb:	movapd %xmm13,0x90(%rsp)
  1faad5:	movapd %xmm14,0x80(%rsp)
  1faadf:	movaps %xmm15,0x70(%rsp)
  1faae5:	call   *0x24d10e5(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1faaeb:	movapd 0x70(%rsp),%xmm15
  1faaf2:	movapd 0x80(%rsp),%xmm14
  1faafc:	movapd 0x90(%rsp),%xmm13
  1fab06:	movapd 0xa0(%rsp),%xmm12
  1fab10:	movapd 0x20(%rsp),%xmm11
  1fab17:	movsd  0x1f9cbd0(%rip),%xmm10        # 21976f0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3e0>
  1fab20:	movapd 0x1f9b4e7(%rip),%xmm9        # 2196010 <_fini+0x530>
  1fab29:	xorpd  %xmm8,%xmm8
  1fab2e:	mov    0x18(%rsp),%r8
  1fab33:	mov    0x40(%rsp),%r11
  1fab38:	movsd  0x1f9cb70(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fab40:	movapd 0x1f9b4b8(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fab48:	mov    0x110(%rsp),%r10
  1fab50:	mov    0x10(%rsp),%r9
  1fab55:	unpcklpd %xmm0,%xmm15
  1fab5a:	nopw   0x0(%rax,%rax,1)
  1fab60:	xorps  %xmm0,%xmm0
  1fab63:	sqrtsd %xmm14,%xmm0
  1fab68:	movapd %xmm15,%xmm1
  1fab6d:	unpckhpd %xmm15,%xmm1
  1fab72:	addsd  %xmm15,%xmm1
  1fab77:	mulsd  %xmm10,%xmm1
  1fab7c:	sqrtsd %xmm1,%xmm1
  1fab80:	mulsd  %xmm0,%xmm1
  1fab84:	ucomisd %xmm8,%xmm13
  1fab89:	jae    1fabb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x930>
  1fab8b:	divsd  %xmm1,%xmm11
  1fab90:	movapd %xmm11,%xmm0
  1fab95:	mulsd  %xmm10,%xmm0
  1fab9a:	movq   %xmm12,%rax
  1fab9f:	test   %rax,%rax
  1faba2:	jns    1faba9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x929>
  1faba4:	xorpd  %xmm9,%xmm1
  1faba9:	movapd %xmm1,%xmm11
  1fabae:	jmp    1fabd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x950>
  1fabb0:	divsd  %xmm1,%xmm12
  1fabb5:	mulsd  %xmm10,%xmm12
  1fabba:	movapd %xmm1,%xmm0
  1fabbe:	movapd %xmm12,%xmm11
  1fabc3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fabd0:	add    %r11,%r14
  1fabd3:	cmp    %rbx,%r14
  1fabd6:	jae    201717 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7497>
  1fabdc:	shl    $0x4,%r14
  1fabe0:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fabe7:	movsd  %xmm11,0x8(%rbp,%r14,1)
  1fabee:	add    $0x8,%r15
  1fabf2:	cmp    %r15,%r13
  1fabf5:	jne    1fa970 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6f0>
  1fabfb:	xor    %edx,%edx
  1fabfd:	mov    0x48(%rsp),%rsi
  1fac02:	mov    0x68(%rsp),%r12
  1fac07:	nopw   0x0(%rax,%rax,1)
  1fac10:	mov    (%r9,%rdx,1),%rdi
  1fac14:	lea    (%rdi,%rsi,1),%rax
  1fac18:	cmp    %rbx,%rax
  1fac1b:	jae    20175d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x74dd>
  1fac21:	lea    (%rdi,%r11,1),%rcx
  1fac25:	cmp    %rbx,%rcx
  1fac28:	jae    20174a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x74ca>
  1fac2e:	add    %r8,%rdi
  1fac31:	cmp    %rbx,%rdi
  1fac34:	jae    20173a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x74ba>
  1fac3a:	shl    $0x4,%rax
  1fac3e:	shl    $0x4,%rcx
  1fac42:	shl    $0x4,%rdi
  1fac46:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fac4c:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fac52:	addpd  %xmm0,%xmm1
  1fac56:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fac5c:	add    $0x8,%rdx
  1fac60:	cmp    %rdx,%r13
  1fac63:	jne    1fac10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x990>
  1fac65:	mov    0x8(%rsp),%rax
  1fac6a:	add    %r8,%rax
  1fac6d:	xor    %r15d,%r15d
  1fac70:	xorpd  %xmm8,%xmm8
  1fac75:	mov    %rax,0x20(%rsp)
  1fac7a:	nopw   0x0(%rax,%rax,1)
  1fac80:	mov    (%r9,%r15,1),%r14
  1fac84:	lea    (%r14,%r8,1),%rdi
  1fac88:	cmp    %rbx,%rdi
  1fac8b:	jae    201783 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7503>
  1fac91:	shl    $0x4,%rdi
  1fac95:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fac9b:	movapd %xmm0,%xmm1
  1fac9f:	unpckhpd %xmm0,%xmm1
  1faca3:	ucomisd %xmm8,%xmm1
  1faca8:	jne    1facc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xa40>
  1facaa:	jp     1facc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xa40>
  1facac:	andpd  %xmm6,%xmm0
  1facb0:	jmp    1fad80 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xb00>
  1facb5:	data16 cs nopw 0x0(%rax,%rax,1)
  1facc0:	ucomisd %xmm8,%xmm0
  1facc5:	jne    1facd6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xa56>
  1facc7:	jp     1facd6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xa56>
  1facc9:	andpd  %xmm6,%xmm1
  1faccd:	movapd %xmm1,%xmm0
  1facd1:	jmp    1fad80 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xb00>
  1facd6:	movapd %xmm0,%xmm2
  1facda:	andpd  %xmm6,%xmm2
  1facde:	pshufd $0xee,%xmm2,%xmm3
  1face3:	movapd %xmm2,%xmm4
  1face7:	cmplesd %xmm3,%xmm4
  1facec:	movapd %xmm4,%xmm5
  1facf0:	andpd  %xmm3,%xmm5
  1facf4:	andnpd %xmm2,%xmm4
  1facf8:	orpd   %xmm5,%xmm4
  1facfc:	movapd %xmm0,%xmm2
  1fad00:	cmpunordsd %xmm0,%xmm2
  1fad05:	movapd %xmm2,%xmm5
  1fad09:	andnpd %xmm4,%xmm5
  1fad0d:	andpd  %xmm3,%xmm2
  1fad11:	orpd   %xmm5,%xmm2
  1fad15:	ucomisd %xmm7,%xmm2
  1fad19:	jbe    1fad42 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xac2>
  1fad1b:	movsd  0x1f9c995(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fad23:	ucomisd %xmm2,%xmm3
  1fad27:	jbe    1fad42 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xac2>
  1fad29:	mulpd  %xmm0,%xmm0
  1fad2d:	movapd %xmm0,%xmm1
  1fad31:	unpckhpd %xmm0,%xmm1
  1fad35:	addsd  %xmm0,%xmm1
  1fad39:	xorps  %xmm0,%xmm0
  1fad3c:	sqrtsd %xmm1,%xmm0
  1fad40:	jmp    1fad80 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xb00>
  1fad42:	call   *0x24d0e88(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1fad48:	xorpd  %xmm8,%xmm8
  1fad4d:	mov    0x20(%rsp),%rax
  1fad52:	mov    0x18(%rsp),%r8
  1fad57:	mov    0x40(%rsp),%r11
  1fad5c:	movsd  0x1f9c94c(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fad64:	movapd 0x1f9b294(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fad6c:	mov    0x110(%rsp),%r10
  1fad74:	mov    0x10(%rsp),%r9
  1fad79:	nopl   0x0(%rax)
  1fad80:	add    %rax,%r14
  1fad83:	cmp    %rbx,%r14
  1fad86:	jae    201770 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x74f0>
  1fad8c:	shl    $0x4,%r14
  1fad90:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fad97:	movq   $0x0,0x8(%rbp,%r14,1)
  1fada0:	add    $0x8,%r15
  1fada4:	cmp    %r15,%r13
  1fada7:	jne    1fac80 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xa00>
  1fadad:	lea    (%r12,%r12,8),%rdx
  1fadb1:	xor    %ecx,%ecx
  1fadb3:	mov    0x48(%rsp),%r8
  1fadb8:	nopl   0x0(%rax,%rax,1)
  1fadc0:	mov    (%r9,%rcx,1),%rdi
  1fadc4:	lea    (%rdi,%r11,1),%rax
  1fadc8:	cmp    %rbx,%rax
  1fadcb:	jae    2017a3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7523>
  1fadd1:	add    %rdx,%rdi
  1fadd4:	cmp    %rbx,%rdi
  1fadd7:	jae    201793 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7513>
  1faddd:	shl    $0x4,%rax
  1fade1:	shl    $0x4,%rdi
  1fade5:	movupd 0x10(%r10),%xmm0
  1fadeb:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fadf1:	movsd  0x8(%rbp,%rax,1),%xmm2
  1fadf7:	unpcklpd %xmm1,%xmm1
  1fadfb:	mulpd  %xmm0,%xmm1
  1fadff:	shufpd $0x1,%xmm0,%xmm0
  1fae04:	unpcklpd %xmm2,%xmm2
  1fae08:	mulpd  %xmm0,%xmm2
  1fae0c:	movapd %xmm1,%xmm0
  1fae10:	subpd  %xmm2,%xmm0
  1fae14:	addpd  %xmm1,%xmm2
  1fae18:	movsd  %xmm0,%xmm2
  1fae1c:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fae22:	add    $0x8,%rcx
  1fae26:	cmp    %rcx,%r13
  1fae29:	jne    1fadc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xb40>
  1fae2b:	mov    0x8(%rsp),%rax
  1fae30:	lea    (%rax,%r8,2),%r15
  1fae34:	xor    %esi,%esi
  1fae36:	cs nopw 0x0(%rax,%rax,1)
  1fae40:	mov    (%r9,%rsi,1),%rdi
  1fae44:	lea    (%rdi,%r8,1),%rax
  1fae48:	cmp    %rbx,%rax
  1fae4b:	jae    2017d9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7559>
  1fae51:	lea    (%rdi,%rdx,1),%rcx
  1fae55:	cmp    %rbx,%rcx
  1fae58:	jae    2017c6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7546>
  1fae5e:	add    %r15,%rdi
  1fae61:	cmp    %rbx,%rdi
  1fae64:	jae    2017b6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7536>
  1fae6a:	shl    $0x4,%rax
  1fae6e:	shl    $0x4,%rcx
  1fae72:	shl    $0x4,%rdi
  1fae76:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fae7c:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fae82:	addpd  %xmm0,%xmm1
  1fae86:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fae8c:	add    $0x8,%rsi
  1fae90:	cmp    %rsi,%r13
  1fae93:	jne    1fae40 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xbc0>
  1fae95:	mov    0x60(%rsp),%rax
  1fae9a:	lea    (%rax,%rax,4),%r8
  1fae9e:	xor    %r12d,%r12d
  1faea1:	xorpd  %xmm8,%xmm8
  1faea6:	mov    0x20(%rsp),%rdx
  1faeab:	mov    %r8,0x18(%rsp)
  1faeb0:	mov    (%r9,%r12,1),%r14
  1faeb4:	lea    (%r14,%r15,1),%rdi
  1faeb8:	cmp    %rbx,%rdi
  1faebb:	jae    2017ff <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x757f>
  1faec1:	shl    $0x4,%rdi
  1faec5:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1faecb:	movapd %xmm0,%xmm1
  1faecf:	unpckhpd %xmm0,%xmm1
  1faed3:	ucomisd %xmm8,%xmm1
  1faed8:	jne    1faef0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xc70>
  1faeda:	jp     1faef0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xc70>
  1faedc:	andpd  %xmm6,%xmm0
  1faee0:	jmp    1fafb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xd30>
  1faee5:	data16 cs nopw 0x0(%rax,%rax,1)
  1faef0:	ucomisd %xmm8,%xmm0
  1faef5:	jne    1faf06 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xc86>
  1faef7:	jp     1faf06 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xc86>
  1faef9:	andpd  %xmm6,%xmm1
  1faefd:	movapd %xmm1,%xmm0
  1faf01:	jmp    1fafb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xd30>
  1faf06:	movapd %xmm0,%xmm2
  1faf0a:	andpd  %xmm6,%xmm2
  1faf0e:	pshufd $0xee,%xmm2,%xmm3
  1faf13:	movapd %xmm2,%xmm4
  1faf17:	cmplesd %xmm3,%xmm4
  1faf1c:	movapd %xmm4,%xmm5
  1faf20:	andpd  %xmm3,%xmm5
  1faf24:	andnpd %xmm2,%xmm4
  1faf28:	orpd   %xmm5,%xmm4
  1faf2c:	movapd %xmm0,%xmm2
  1faf30:	cmpunordsd %xmm0,%xmm2
  1faf35:	movapd %xmm2,%xmm5
  1faf39:	andnpd %xmm4,%xmm5
  1faf3d:	andpd  %xmm3,%xmm2
  1faf41:	orpd   %xmm5,%xmm2
  1faf45:	ucomisd %xmm7,%xmm2
  1faf49:	jbe    1faf72 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xcf2>
  1faf4b:	movsd  0x1f9c765(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1faf53:	ucomisd %xmm2,%xmm3
  1faf57:	jbe    1faf72 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xcf2>
  1faf59:	mulpd  %xmm0,%xmm0
  1faf5d:	movapd %xmm0,%xmm1
  1faf61:	unpckhpd %xmm0,%xmm1
  1faf65:	addsd  %xmm0,%xmm1
  1faf69:	xorps  %xmm0,%xmm0
  1faf6c:	sqrtsd %xmm1,%xmm0
  1faf70:	jmp    1fafb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xd30>
  1faf72:	call   *0x24d0c58(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1faf78:	xorpd  %xmm8,%xmm8
  1faf7d:	mov    0x18(%rsp),%r8
  1faf82:	mov    0x20(%rsp),%rdx
  1faf87:	movsd  0x1f9c721(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1faf8f:	movapd 0x1f9b069(%rip),%xmm6        # 2196000 <_fini+0x520>
  1faf97:	mov    0x110(%rsp),%r10
  1faf9f:	mov    0x10(%rsp),%r9
  1fafa4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fafb0:	add    %r8,%r14
  1fafb3:	cmp    %rbx,%r14
  1fafb6:	jae    2017ec <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x756c>
  1fafbc:	shl    $0x4,%r14
  1fafc0:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fafc7:	movq   $0x0,0x8(%rbp,%r14,1)
  1fafd0:	add    $0x8,%r12
  1fafd4:	cmp    %r12,%r13
  1fafd7:	jne    1faeb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xc30>
  1fafdd:	mov    0x8(%rsp),%rax
  1fafe2:	mov    0x50(%rsp),%rcx
  1fafe7:	lea    (%rax,%rcx,4),%rsi
  1fafeb:	xor    %ecx,%ecx
  1fafed:	mov    0xf0(%rsp),%r12
  1faff5:	mov    0x108(%rsp),%r11
  1faffd:	mov    0x30(%rsp),%r15
  1fb002:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fb010:	mov    (%r9,%rcx,1),%rdi
  1fb014:	lea    (%rdi,%r8,1),%rax
  1fb018:	cmp    %rbx,%rax
  1fb01b:	jae    20181f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x759f>
  1fb021:	add    %rsi,%rdi
  1fb024:	cmp    %rbx,%rdi
  1fb027:	jae    20180f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x758f>
  1fb02d:	shl    $0x4,%rax
  1fb031:	shl    $0x4,%rdi
  1fb035:	movupd 0x10(%r10),%xmm0
  1fb03b:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fb041:	movsd  0x8(%rbp,%rax,1),%xmm2
  1fb047:	unpcklpd %xmm1,%xmm1
  1fb04b:	mulpd  %xmm0,%xmm1
  1fb04f:	shufpd $0x1,%xmm0,%xmm0
  1fb054:	unpcklpd %xmm2,%xmm2
  1fb058:	mulpd  %xmm0,%xmm2
  1fb05c:	movapd %xmm1,%xmm0
  1fb060:	subpd  %xmm2,%xmm0
  1fb064:	addpd  %xmm1,%xmm2
  1fb068:	movsd  %xmm0,%xmm2
  1fb06c:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fb072:	add    $0x8,%rcx
  1fb076:	cmp    %rcx,%r13
  1fb079:	jne    1fb010 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xd90>
  1fb07b:	mov    0x8(%rsp),%rax
  1fb080:	lea    (%rax,%rsi,1),%r14
  1fb084:	xor    %r8d,%r8d
  1fb087:	nopw   0x0(%rax,%rax,1)
  1fb090:	mov    (%r9,%r8,1),%rdi
  1fb094:	lea    (%rdi,%rdx,1),%rax
  1fb098:	cmp    %rbx,%rax
  1fb09b:	jae    201855 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x75d5>
  1fb0a1:	lea    (%rdi,%rsi,1),%rcx
  1fb0a5:	cmp    %rbx,%rcx
  1fb0a8:	jae    201842 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x75c2>
  1fb0ae:	add    %r14,%rdi
  1fb0b1:	cmp    %rbx,%rdi
  1fb0b4:	jae    201832 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x75b2>
  1fb0ba:	shl    $0x4,%rax
  1fb0be:	shl    $0x4,%rcx
  1fb0c2:	shl    $0x4,%rdi
  1fb0c6:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fb0cc:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fb0d2:	addpd  %xmm0,%xmm1
  1fb0d6:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fb0dc:	add    $0x8,%r8
  1fb0e0:	cmp    %r8,%r13
  1fb0e3:	jne    1fb090 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xe10>
  1fb0e5:	xor    %ecx,%ecx
  1fb0e7:	xorpd  %xmm0,%xmm0
  1fb0eb:	xor    %esi,%esi
  1fb0ed:	mov    0x100(%rsp),%r8
  1fb0f5:	mov    0x58(%rsp),%r13
  1fb0fa:	jmp    1fb119 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xe99>
  1fb0fc:	nopl   0x0(%rax)
  1fb100:	cmp    %r11,%rdi
  1fb103:	jae    201a32 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x77b2>
  1fb109:	movq   $0x15,(%r8,%rdi,8)
  1fb111:	inc    %rcx
  1fb114:	cmp    %rcx,%r13
  1fb117:	je     1fb164 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xee4>
  1fb119:	mov    (%r9,%rcx,8),%rdi
  1fb11d:	lea    (%rdi,%r14,1),%rax
  1fb121:	cmp    %rbx,%rax
  1fb124:	jae    201868 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x75e8>
  1fb12a:	shl    $0x4,%rax
  1fb12e:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fb134:	ucomisd %xmm0,%xmm1
  1fb138:	jne    1fb14c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xecc>
  1fb13a:	jp     1fb14c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xecc>
  1fb13c:	add    %rbp,%rax
  1fb13f:	movsd  0x8(%rax),%xmm1
  1fb144:	ucomisd %xmm0,%xmm1
  1fb148:	jne    1fb14c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xecc>
  1fb14a:	jnp    1fb100 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xe80>
  1fb14c:	cmp    %r12,%rsi
  1fb14f:	jae    201a0f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x778f>
  1fb155:	mov    %rdi,(%r9,%rsi,8)
  1fb159:	inc    %rsi
  1fb15c:	inc    %rcx
  1fb15f:	cmp    %rcx,%r13
  1fb162:	jne    1fb119 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xe99>
  1fb164:	cmp    %r12,%rsi
  1fb167:	ja     2006a1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6421>
  1fb16d:	test   %rsi,%rsi
  1fb170:	je     1fb19e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf1e>
  1fb172:	shl    $0x3,%rsi
  1fb176:	xor    %eax,%eax
  1fb178:	nopl   0x0(%rax,%rax,1)
  1fb180:	mov    (%r9,%rax,1),%rdi
  1fb184:	cmp    %r11,%rdi
  1fb187:	jae    2019ef <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x776f>
  1fb18d:	movq   $0x16,(%r8,%rdi,8)
  1fb195:	add    $0x8,%rax
  1fb199:	cmp    %rax,%rsi
  1fb19c:	jne    1fb180 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf00>
  1fb19e:	test   %r15,%r15
  1fb1a1:	je     200463 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x61e3>
  1fb1a7:	shl    $0x3,%r15
  1fb1ab:	xor    %ecx,%ecx
  1fb1ad:	xor    %edi,%edi
  1fb1af:	mov    0x38(%rsp),%r13
  1fb1b4:	jmp    1fb1d0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf50>
  1fb1b6:	cs nopw 0x0(%rax,%rax,1)
  1fb1c0:	mov    %rax,(%r9,%rdi,8)
  1fb1c4:	inc    %rdi
  1fb1c7:	add    $0x8,%rcx
  1fb1cb:	cmp    %rcx,%r15
  1fb1ce:	je     1fb1fa <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf7a>
  1fb1d0:	mov    0x0(%r13,%rcx,1),%rax
  1fb1d5:	cmp    %r11,%rax
  1fb1d8:	jae    2007b3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6533>
  1fb1de:	cmpq   $0x16,(%r8,%rax,8)
  1fb1e3:	jae    1fb1c7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf47>
  1fb1e5:	cmp    %r12,%rdi
  1fb1e8:	jb     1fb1c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf40>
  1fb1ea:	lea    0x2430557(%rip),%rdx        # 262b748 <__gmpfr_one+0x13fc8>
  1fb1f1:	mov    %r12,%rsi
  1fb1f4:	call   *0x24d3d06(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fb1fa:	xor    %eax,%eax
  1fb1fc:	xor    %esi,%esi
  1fb1fe:	jmp    1fb210 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf90>
  1fb200:	mov    %rdi,(%r9,%rsi,8)
  1fb204:	inc    %rsi
  1fb207:	add    $0x8,%rax
  1fb20b:	cmp    %rax,%r15
  1fb20e:	je     1fb23d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xfbd>
  1fb210:	mov    0x0(%r13,%rax,1),%rdi
  1fb215:	cmp    %r11,%rdi
  1fb218:	jae    2007c6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6546>
  1fb21e:	cmpq   $0x17,(%r8,%rdi,8)
  1fb223:	jae    1fb207 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf87>
  1fb225:	cmp    %r12,%rsi
  1fb228:	jb     1fb200 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0xf80>
  1fb22a:	lea    0x2430547(%rip),%rdx        # 262b778 <__gmpfr_one+0x13ff8>
  1fb231:	mov    %rsi,%rdi
  1fb234:	mov    %r12,%rsi
  1fb237:	call   *0x24d3cc3(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fb23d:	cmp    %r12,%rsi
  1fb240:	ja     200573 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x62f3>
  1fb246:	test   %rsi,%rsi
  1fb249:	mov    %r15,0x30(%rsp)
  1fb24e:	je     1fba3e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x17be>
  1fb254:	mov    %rsi,0x40(%rsp)
  1fb259:	lea    0x0(,%rsi,8),%r15
  1fb261:	mov    0x8(%rsp),%r13
  1fb266:	lea    0x0(,%r13,4),%rax
  1fb26e:	add    %r13,%rax
  1fb271:	lea    0x0(,%rax,4),%r14
  1fb279:	add    %r13,%r14
  1fb27c:	add    %r13,%r14
  1fb27f:	lea    0x0(,%r13,8),%rax
  1fb287:	add    %r13,%rax
  1fb28a:	mov    %rax,0x50(%rsp)
  1fb28f:	lea    (%rax,%rax,2),%rax
  1fb293:	mov    %rax,0x20(%rsp)
  1fb298:	xor    %r12d,%r12d
  1fb29b:	xorpd  %xmm1,%xmm1
  1fb29f:	jmp    1fb2e4 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1064>
  1fb2a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fb2b0:	mov    $0x1b,%r8d
  1fb2b6:	mov    $0x16,%r9d
  1fb2bc:	mov    %rbp,%rdi
  1fb2bf:	mov    %rbx,%rsi
  1fb2c2:	mov    %r13,%rdx
  1fb2c5:	call   1fa170 <oneloop::native::batch::copy_active_column::<f64>>
  1fb2ca:	xorpd  %xmm1,%xmm1
  1fb2ce:	mov    0x110(%rsp),%r10
  1fb2d6:	mov    0x10(%rsp),%r9
  1fb2db:	add    $0x8,%r12
  1fb2df:	cmp    %r12,%r15
  1fb2e2:	je     1fb34d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x10cd>
  1fb2e4:	mov    (%r9,%r12,1),%rcx
  1fb2e8:	lea    (%rcx,%r14,1),%rdi
  1fb2ec:	cmp    %rbx,%rdi
  1fb2ef:	jae    20093b <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x66bb>
  1fb2f5:	shl    $0x4,%rdi
  1fb2f9:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1fb2ff:	ucomisd %xmm1,%xmm0
  1fb303:	jne    1fb2b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1030>
  1fb305:	jp     1fb2b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1030>
  1fb307:	add    %rbp,%rdi
  1fb30a:	movsd  0x8(%rdi),%xmm0
  1fb30f:	ucomisd %xmm1,%xmm0
  1fb313:	jne    1fb2b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1030>
  1fb315:	jp     1fb2b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1030>
  1fb317:	add    0x20(%rsp),%rcx
  1fb31c:	cmp    %rbx,%rcx
  1fb31f:	jae    2015a3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7323>
  1fb325:	cmpq   $0x3,0x118(%rsp)
  1fb32e:	jbe    20100e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6d8e>
  1fb334:	shl    $0x4,%rcx
  1fb338:	movupd 0x30(%r10),%xmm0
  1fb33e:	movupd %xmm0,0x0(%rbp,%rcx,1)
  1fb344:	add    $0x8,%r12
  1fb348:	cmp    %r12,%r15
  1fb34b:	jne    1fb2e4 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1064>
  1fb34d:	mov    0x20(%rsp),%rax
  1fb352:	lea    (%rax,%r13,1),%rdx
  1fb356:	xor    %r13d,%r13d
  1fb359:	xorpd  %xmm8,%xmm8
  1fb35e:	movapd 0x1f9ac99(%rip),%xmm9        # 2196000 <_fini+0x520>
  1fb367:	movsd  0x1f9c341(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fb36f:	movsd  0x1f9c341(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fb377:	nopw   0x0(%rax,%rax,1)
  1fb380:	mov    (%r9,%r13,1),%r14
  1fb384:	mov    0x20(%rsp),%rax
  1fb389:	lea    (%r14,%rax,1),%rdi
  1fb38d:	cmp    %rbx,%rdi
  1fb390:	jae    20095e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x66de>
  1fb396:	shl    $0x4,%rdi
  1fb39a:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fb3a0:	movapd %xmm0,%xmm1
  1fb3a4:	unpckhpd %xmm0,%xmm1
  1fb3a8:	ucomisd %xmm8,%xmm1
  1fb3ad:	jne    1fb3c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1140>
  1fb3af:	jp     1fb3c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1140>
  1fb3b1:	andpd  %xmm9,%xmm0
  1fb3b6:	jmp    1fb480 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1200>
  1fb3bb:	nopl   0x0(%rax,%rax,1)
  1fb3c0:	ucomisd %xmm8,%xmm0
  1fb3c5:	jne    1fb3d7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1157>
  1fb3c7:	jp     1fb3d7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1157>
  1fb3c9:	andpd  %xmm9,%xmm1
  1fb3ce:	movapd %xmm1,%xmm0
  1fb3d2:	jmp    1fb480 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1200>
  1fb3d7:	movapd %xmm0,%xmm2
  1fb3db:	andpd  %xmm9,%xmm2
  1fb3e0:	pshufd $0xee,%xmm2,%xmm3
  1fb3e5:	movapd %xmm2,%xmm4
  1fb3e9:	cmplesd %xmm3,%xmm4
  1fb3ee:	movapd %xmm4,%xmm5
  1fb3f2:	andpd  %xmm3,%xmm5
  1fb3f6:	andnpd %xmm2,%xmm4
  1fb3fa:	orpd   %xmm5,%xmm4
  1fb3fe:	movapd %xmm0,%xmm2
  1fb402:	cmpunordsd %xmm0,%xmm2
  1fb407:	movapd %xmm2,%xmm5
  1fb40b:	andnpd %xmm4,%xmm5
  1fb40f:	andpd  %xmm3,%xmm2
  1fb413:	orpd   %xmm5,%xmm2
  1fb417:	ucomisd %xmm6,%xmm2
  1fb41b:	jbe    1fb43c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x11bc>
  1fb41d:	ucomisd %xmm2,%xmm7
  1fb421:	jbe    1fb43c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x11bc>
  1fb423:	mulpd  %xmm0,%xmm0
  1fb427:	movapd %xmm0,%xmm1
  1fb42b:	unpckhpd %xmm0,%xmm1
  1fb42f:	addsd  %xmm0,%xmm1
  1fb433:	xorps  %xmm0,%xmm0
  1fb436:	sqrtsd %xmm1,%xmm0
  1fb43a:	jmp    1fb480 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1200>
  1fb43c:	mov    %rdx,%r12
  1fb43f:	call   *0x24d078b(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1fb445:	movapd 0x1f9abb2(%rip),%xmm9        # 2196000 <_fini+0x520>
  1fb44e:	xorpd  %xmm8,%xmm8
  1fb453:	mov    %r12,%rdx
  1fb456:	movsd  0x1f9c25a(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fb45e:	movsd  0x1f9c24a(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fb466:	mov    0x110(%rsp),%r10
  1fb46e:	mov    0x10(%rsp),%r9
  1fb473:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fb480:	add    %rdx,%r14
  1fb483:	cmp    %rbx,%r14
  1fb486:	jae    20094b <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x66cb>
  1fb48c:	shl    $0x4,%r14
  1fb490:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fb497:	movq   $0x0,0x8(%rbp,%r14,1)
  1fb4a0:	add    $0x8,%r13
  1fb4a4:	cmp    %r13,%r15
  1fb4a7:	jne    1fb380 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1100>
  1fb4ad:	cmpq   $0x2,0x118(%rsp)
  1fb4b6:	jb     201b56 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x78d6>
  1fb4bc:	mov    0x8(%rsp),%r11
  1fb4c1:	lea    (%r11,%r11,1),%rcx
  1fb4c5:	mov    %rcx,0x48(%rsp)
  1fb4ca:	mov    0x20(%rsp),%rax
  1fb4cf:	lea    (%rcx,%rax,1),%rsi
  1fb4d3:	xor    %ecx,%ecx
  1fb4d5:	mov    0xf0(%rsp),%r12
  1fb4dd:	nopl   (%rax)
  1fb4e0:	mov    (%r9,%rcx,1),%rdi
  1fb4e4:	lea    (%rdi,%rdx,1),%rax
  1fb4e8:	cmp    %rbx,%rax
  1fb4eb:	jae    20097e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x66fe>
  1fb4f1:	add    %rsi,%rdi
  1fb4f4:	cmp    %rbx,%rdi
  1fb4f7:	jae    20096e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x66ee>
  1fb4fd:	shl    $0x4,%rax
  1fb501:	shl    $0x4,%rdi
  1fb505:	movupd 0x10(%r10),%xmm0
  1fb50b:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fb511:	movsd  0x8(%rbp,%rax,1),%xmm2
  1fb517:	unpcklpd %xmm1,%xmm1
  1fb51b:	mulpd  %xmm0,%xmm1
  1fb51f:	shufpd $0x1,%xmm0,%xmm0
  1fb524:	unpcklpd %xmm2,%xmm2
  1fb528:	mulpd  %xmm0,%xmm2
  1fb52c:	movapd %xmm1,%xmm0
  1fb530:	subpd  %xmm2,%xmm0
  1fb534:	addpd  %xmm1,%xmm2
  1fb538:	movsd  %xmm0,%xmm2
  1fb53c:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fb542:	add    $0x8,%rcx
  1fb546:	cmp    %rcx,%r15
  1fb549:	jne    1fb4e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1260>
  1fb54b:	mov    %r11,%rdx
  1fb54e:	shl    $0x5,%rdx
  1fb552:	mov    %rdx,0x18(%rsp)
  1fb557:	sub    0x48(%rsp),%rdx
  1fb55c:	xor    %r8d,%r8d
  1fb55f:	nop
  1fb560:	mov    (%r9,%r8,1),%rdi
  1fb564:	mov    0x20(%rsp),%rax
  1fb569:	add    %rdi,%rax
  1fb56c:	cmp    %rbx,%rax
  1fb56f:	jae    2009b4 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6734>
  1fb575:	lea    (%rdi,%rsi,1),%rcx
  1fb579:	cmp    %rbx,%rcx
  1fb57c:	jae    2009a1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6721>
  1fb582:	add    %rdx,%rdi
  1fb585:	cmp    %rbx,%rdi
  1fb588:	jae    200991 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6711>
  1fb58e:	shl    $0x4,%rax
  1fb592:	shl    $0x4,%rcx
  1fb596:	shl    $0x4,%rdi
  1fb59a:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fb5a0:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fb5a6:	addpd  %xmm0,%xmm1
  1fb5aa:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fb5b0:	add    $0x8,%r8
  1fb5b4:	cmp    %r8,%r15
  1fb5b7:	jne    1fb560 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x12e0>
  1fb5b9:	xor    %ecx,%ecx
  1fb5bb:	xorpd  %xmm0,%xmm0
  1fb5bf:	xor    %r14d,%r14d
  1fb5c2:	mov    0x108(%rsp),%r11
  1fb5ca:	mov    0x30(%rsp),%r15
  1fb5cf:	mov    0x38(%rsp),%r13
  1fb5d4:	mov    0x100(%rsp),%r8
  1fb5dc:	jmp    1fb5ea <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x136a>
  1fb5de:	xchg   %ax,%ax
  1fb5e0:	inc    %rcx
  1fb5e3:	cmp    %rcx,0x40(%rsp)
  1fb5e8:	je     1fb642 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x13c2>
  1fb5ea:	mov    (%r9,%rcx,8),%rdi
  1fb5ee:	lea    (%rdi,%rdx,1),%rax
  1fb5f2:	cmp    %rbx,%rax
  1fb5f5:	jae    2009c7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6747>
  1fb5fb:	shl    $0x4,%rax
  1fb5ff:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fb605:	ucomisd %xmm0,%xmm1
  1fb609:	jne    1fb630 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x13b0>
  1fb60b:	jp     1fb630 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x13b0>
  1fb60d:	add    %rbp,%rax
  1fb610:	movsd  0x8(%rax),%xmm1
  1fb615:	ucomisd %xmm0,%xmm1
  1fb619:	jne    1fb630 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x13b0>
  1fb61b:	jp     1fb630 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x13b0>
  1fb61d:	cmp    %r11,%rdi
  1fb620:	jae    2015b6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7336>
  1fb626:	movq   $0x1f,(%r8,%rdi,8)
  1fb62e:	jmp    1fb5e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1360>
  1fb630:	cmp    %r12,%r14
  1fb633:	jae    2012dd <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x705d>
  1fb639:	mov    %rdi,(%r9,%r14,8)
  1fb63d:	inc    %r14
  1fb640:	jmp    1fb5e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1360>
  1fb642:	cmp    %r12,%r14
  1fb645:	ja     2006b3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6433>
  1fb64b:	test   %r14,%r14
  1fb64e:	je     1fba3e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x17be>
  1fb654:	shl    $0x3,%r14
  1fb658:	mov    0x8(%rsp),%rax
  1fb65d:	mov    0x50(%rsp),%rcx
  1fb662:	lea    (%rax,%rcx,2),%rax
  1fb666:	mov    %rax,0x20(%rsp)
  1fb66b:	xor    %r15d,%r15d
  1fb66e:	movapd 0x1f9a989(%rip),%xmm8        # 2196000 <_fini+0x520>
  1fb677:	xorpd  %xmm9,%xmm9
  1fb67c:	movsd  0x1f9c043(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fb685:	movapd 0x1f9a982(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fb68e:	movsd  0x1f9c029(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fb697:	movabs $0x7fffffffffffffff,%r11
  1fb6a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fb6b0:	mov    (%r9,%r15,1),%r13
  1fb6b4:	mov    0x20(%rsp),%rax
  1fb6b9:	lea    (%rax,%r13,1),%rdi
  1fb6bd:	cmp    %rbx,%rdi
  1fb6c0:	jae    20108d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6e0d>
  1fb6c6:	shl    $0x4,%rdi
  1fb6ca:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fb6d0:	movapd %xmm0,%xmm2
  1fb6d4:	andpd  %xmm8,%xmm2
  1fb6d9:	movapd %xmm0,%xmm1
  1fb6dd:	unpckhpd %xmm0,%xmm1
  1fb6e1:	movapd %xmm1,%xmm3
  1fb6e5:	andpd  %xmm8,%xmm3
  1fb6ea:	ucomisd %xmm9,%xmm0
  1fb6ef:	je     1fb760 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x14e0>
  1fb6f1:	ucomisd %xmm9,%xmm1
  1fb6f6:	je     1fb760 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x14e0>
  1fb6f8:	movapd %xmm2,%xmm4
  1fb6fc:	cmplesd %xmm3,%xmm4
  1fb701:	movapd %xmm4,%xmm5
  1fb705:	andpd  %xmm3,%xmm5
  1fb709:	andnpd %xmm2,%xmm4
  1fb70d:	orpd   %xmm5,%xmm4
  1fb711:	ucomisd %xmm6,%xmm4
  1fb715:	jbe    1fb760 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x14e0>
  1fb717:	ucomisd %xmm4,%xmm7
  1fb71b:	jbe    1fb760 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x14e0>
  1fb71d:	movapd %xmm0,%xmm2
  1fb721:	mulpd  %xmm0,%xmm2
  1fb725:	movapd %xmm2,%xmm3
  1fb729:	unpckhpd %xmm2,%xmm3
  1fb72d:	addsd  %xmm2,%xmm3
  1fb731:	movapd %xmm10,%xmm2
  1fb736:	divsd  %xmm3,%xmm2
  1fb73a:	mulsd  %xmm2,%xmm0
  1fb73e:	xorpd  %xmm11,%xmm1
  1fb743:	mulsd  %xmm2,%xmm1
  1fb747:	add    0x18(%rsp),%r13
  1fb74c:	cmp    %rbx,%r13
  1fb74f:	jb     1fb880 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1600>
  1fb755:	jmp    1fb922 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x16a2>
  1fb75a:	nopw   0x0(%rax,%rax,1)
  1fb760:	ucomisd %xmm9,%xmm1
  1fb765:	setnp  %al
  1fb768:	sete   %cl
  1fb76b:	and    %al,%cl
  1fb76d:	movq   %xmm0,%rax
  1fb772:	and    %r11,%rax
  1fb775:	movabs $0x7ff0000000000000,%rsi
  1fb77f:	cmp    %rsi,%rax
  1fb782:	setl   %dl
  1fb785:	test   %dl,%cl
  1fb787:	je     1fb7b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1530>
  1fb789:	movapd %xmm10,%xmm2
  1fb78e:	divsd  %xmm0,%xmm2
  1fb792:	xorpd  %xmm11,%xmm1
  1fb797:	movapd %xmm2,%xmm0
  1fb79b:	add    0x18(%rsp),%r13
  1fb7a0:	cmp    %rbx,%r13
  1fb7a3:	jb     1fb880 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1600>
  1fb7a9:	jmp    1fb922 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x16a2>
  1fb7ae:	xchg   %ax,%ax
  1fb7b0:	ucomisd %xmm9,%xmm0
  1fb7b5:	setnp  %cl
  1fb7b8:	sete   %dl
  1fb7bb:	and    %cl,%dl
  1fb7bd:	movq   %xmm1,%rcx
  1fb7c2:	and    %r11,%rcx
  1fb7c5:	cmp    %rsi,%rcx
  1fb7c8:	setl   %sil
  1fb7cc:	test   %sil,%dl
  1fb7cf:	je     1fb7f1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1571>
  1fb7d1:	movapd %xmm12,%xmm2
  1fb7d6:	divsd  %xmm1,%xmm2
  1fb7da:	movapd %xmm2,%xmm1
  1fb7de:	add    0x18(%rsp),%r13
  1fb7e3:	cmp    %rbx,%r13
  1fb7e6:	jb     1fb880 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1600>
  1fb7ec:	jmp    1fb922 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x16a2>
  1fb7f1:	movabs $0x7fefffffffffffff,%rdx
  1fb7fb:	cmp    %rdx,%rax
  1fb7fe:	setg   %al
  1fb801:	cmp    %rdx,%rcx
  1fb804:	setg   %cl
  1fb807:	or     %al,%cl
  1fb809:	cmp    $0x1,%cl
  1fb80c:	jne    1fb8a4 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1624>
  1fb812:	add    %rbp,%rdi
  1fb815:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1fb81a:	movsd  0x1f9be9d(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fb823:	movapd 0x1f9a7e4(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fb82c:	movsd  0x1f9be93(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fb835:	xorpd  %xmm9,%xmm9
  1fb83a:	movapd 0x1f9a7bd(%rip),%xmm8        # 2196000 <_fini+0x520>
  1fb843:	movsd  0x1f9be6d(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fb84b:	movsd  0x1f9be5d(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fb853:	movabs $0x7fffffffffffffff,%r11
  1fb85d:	mov    0x100(%rsp),%r8
  1fb865:	mov    0x110(%rsp),%r10
  1fb86d:	mov    0x10(%rsp),%r9
  1fb872:	add    0x18(%rsp),%r13
  1fb877:	cmp    %rbx,%r13
  1fb87a:	jae    1fb922 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x16a2>
  1fb880:	shl    $0x4,%r13
  1fb884:	movsd  %xmm0,0x0(%rbp,%r13,1)
  1fb88b:	movsd  %xmm1,0x8(%rbp,%r13,1)
  1fb892:	add    $0x8,%r15
  1fb896:	cmp    %r15,%r14
  1fb899:	jne    1fb6b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1430>
  1fb89f:	jmp    1fb935 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x16b5>
  1fb8a4:	ucomisd %xmm9,%xmm1
  1fb8a9:	jne    1fb8b1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1631>
  1fb8ab:	jnp    1fb789 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1509>
  1fb8b1:	ucomisd %xmm9,%xmm0
  1fb8b6:	jne    1fb8be <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x163e>
  1fb8b8:	jnp    1fb7d1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1551>
  1fb8be:	movapd %xmm3,%xmm1
  1fb8c2:	cmplesd %xmm2,%xmm1
  1fb8c7:	movapd %xmm1,%xmm4
  1fb8cb:	andpd  %xmm2,%xmm4
  1fb8cf:	andnpd %xmm3,%xmm1
  1fb8d3:	orpd   %xmm4,%xmm1
  1fb8d7:	unpcklpd %xmm1,%xmm1
  1fb8db:	divpd  %xmm1,%xmm0
  1fb8df:	movapd %xmm0,%xmm2
  1fb8e3:	xorpd  %xmm11,%xmm2
  1fb8e8:	movsd  %xmm0,%xmm2
  1fb8ec:	mulpd  %xmm0,%xmm0
  1fb8f0:	movapd %xmm0,%xmm3
  1fb8f4:	unpcklpd %xmm0,%xmm3
  1fb8f8:	unpckhpd %xmm0,%xmm0
  1fb8fc:	addpd  %xmm3,%xmm0
  1fb900:	divpd  %xmm0,%xmm2
  1fb904:	divpd  %xmm1,%xmm2
  1fb908:	movapd %xmm2,%xmm0
  1fb90c:	movapd %xmm2,%xmm1
  1fb910:	unpckhpd %xmm2,%xmm1
  1fb914:	add    0x18(%rsp),%r13
  1fb919:	cmp    %rbx,%r13
  1fb91c:	jb     1fb880 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1600>
  1fb922:	lea    0x242ff57(%rip),%rdx        # 262b880 <__gmpfr_one+0x14100>
  1fb929:	mov    %r13,%rdi
  1fb92c:	mov    %rbx,%rsi
  1fb92f:	call   *0x24d35cb(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fb935:	mov    0x8(%rsp),%r13
  1fb93a:	mov    0x18(%rsp),%rax
  1fb93f:	lea    (%rax,%r13,1),%rdx
  1fb943:	xor    %esi,%esi
  1fb945:	mov    0x108(%rsp),%r11
  1fb94d:	mov    0x30(%rsp),%r15
  1fb952:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fb960:	mov    (%r9,%rsi,1),%rdi
  1fb964:	mov    0x48(%rsp),%rax
  1fb969:	lea    (%rdi,%rax,1),%rcx
  1fb96d:	cmp    %rbx,%rcx
  1fb970:	jae    2010c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6e40>
  1fb976:	mov    0x18(%rsp),%rax
  1fb97b:	add    %rdi,%rax
  1fb97e:	cmp    %rbx,%rax
  1fb981:	jae    2010ad <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6e2d>
  1fb987:	add    %rdx,%rdi
  1fb98a:	cmp    %rbx,%rdi
  1fb98d:	jae    20109d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6e1d>
  1fb993:	shl    $0x4,%rcx
  1fb997:	shl    $0x4,%rax
  1fb99b:	movupd 0x0(%rbp,%rcx,1),%xmm0
  1fb9a1:	movupd (%r10),%xmm1
  1fb9a6:	movapd %xmm0,%xmm2
  1fb9aa:	mulpd  %xmm1,%xmm2
  1fb9ae:	shl    $0x4,%rdi
  1fb9b2:	movupd 0x0(%rbp,%rax,1),%xmm3
  1fb9b8:	movapd %xmm2,%xmm4
  1fb9bc:	unpcklpd %xmm2,%xmm4
  1fb9c0:	unpckhpd %xmm2,%xmm2
  1fb9c4:	subpd  %xmm2,%xmm4
  1fb9c8:	mulpd  %xmm3,%xmm4
  1fb9cc:	movapd %xmm1,%xmm2
  1fb9d0:	unpckhpd %xmm1,%xmm2
  1fb9d4:	mulsd  %xmm0,%xmm2
  1fb9d8:	unpckhpd %xmm0,%xmm0
  1fb9dc:	mulsd  %xmm1,%xmm0
  1fb9e0:	addsd  %xmm2,%xmm0
  1fb9e4:	unpcklpd %xmm0,%xmm0
  1fb9e8:	shufpd $0x1,%xmm3,%xmm3
  1fb9ed:	mulpd  %xmm0,%xmm3
  1fb9f1:	movapd %xmm4,%xmm0
  1fb9f5:	subpd  %xmm3,%xmm0
  1fb9f9:	addpd  %xmm4,%xmm3
  1fb9fd:	movsd  %xmm0,%xmm3
  1fba01:	movupd %xmm3,0x0(%rbp,%rdi,1)
  1fba07:	add    $0x8,%rsi
  1fba0b:	cmp    %rsi,%r14
  1fba0e:	jne    1fb960 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x16e0>
  1fba14:	xor    %eax,%eax
  1fba16:	mov    0x38(%rsp),%r13
  1fba1b:	nopl   0x0(%rax,%rax,1)
  1fba20:	mov    (%r9,%rax,1),%rdi
  1fba24:	cmp    %r11,%rdi
  1fba27:	jae    2010d3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6e53>
  1fba2d:	movq   $0x22,(%r8,%rdi,8)
  1fba35:	add    $0x8,%rax
  1fba39:	cmp    %rax,%r14
  1fba3c:	jne    1fba20 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x17a0>
  1fba3e:	xor    %eax,%eax
  1fba40:	xor    %r14d,%r14d
  1fba43:	jmp    1fba60 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x17e0>
  1fba45:	data16 cs nopw 0x0(%rax,%rax,1)
  1fba50:	mov    %rdi,(%r9,%r14,8)
  1fba54:	inc    %r14
  1fba57:	add    $0x8,%rax
  1fba5b:	cmp    %rax,%r15
  1fba5e:	je     1fba8d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x180d>
  1fba60:	mov    0x0(%r13,%rax,1),%rdi
  1fba65:	cmp    %r11,%rdi
  1fba68:	jae    2007d6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6556>
  1fba6e:	cmpq   $0x20,(%r8,%rdi,8)
  1fba73:	jae    1fba57 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x17d7>
  1fba75:	cmp    %r12,%r14
  1fba78:	jb     1fba50 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x17d0>
  1fba7a:	lea    0x242fe8f(%rip),%rdx        # 262b910 <__gmpfr_one+0x14190>
  1fba81:	mov    %r14,%rdi
  1fba84:	mov    %r12,%rsi
  1fba87:	call   *0x24d3473(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fba8d:	cmp    %r12,%r14
  1fba90:	ja     200585 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6305>
  1fba96:	test   %r14,%r14
  1fba99:	mov    0x8(%rsp),%r13
  1fba9e:	je     1fbea0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1c20>
  1fbaa4:	shl    $0x3,%r14
  1fbaa8:	lea    0x0(,%r13,4),%rax
  1fbab0:	lea    (%rax,%rax,8),%rax
  1fbab4:	mov    %rax,0x20(%rsp)
  1fbab9:	xor    %r15d,%r15d
  1fbabc:	movapd 0x1f9a53c(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fbac4:	xorpd  %xmm7,%xmm7
  1fbac8:	movsd  0x1f9bbdf(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fbad1:	movsd  0x1f9bbde(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fbada:	movsd  0x1f9bbe5(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fbae3:	movapd 0x1f9a524(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fbaec:	movsd  0x1f9bbcb(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fbaf5:	movabs $0x7fffffffffffffff,%r8
  1fbaff:	movabs $0x7ff0000000000000,%r11
  1fbb09:	nopl   0x0(%rax)
  1fbb10:	mov    (%r9,%r15,1),%r13
  1fbb14:	cmp    %rbx,%r13
  1fbb17:	jae    2009da <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x675a>
  1fbb1d:	mov    %r13,%rdi
  1fbb20:	shl    $0x4,%rdi
  1fbb24:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fbb2a:	movapd %xmm0,%xmm2
  1fbb2e:	andpd  %xmm6,%xmm2
  1fbb32:	movapd %xmm0,%xmm1
  1fbb36:	unpckhpd %xmm0,%xmm1
  1fbb3a:	movapd %xmm1,%xmm3
  1fbb3e:	andpd  %xmm6,%xmm3
  1fbb42:	ucomisd %xmm7,%xmm0
  1fbb46:	je     1fbbc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1940>
  1fbb48:	ucomisd %xmm7,%xmm1
  1fbb4c:	je     1fbbc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1940>
  1fbb4e:	movapd %xmm2,%xmm4
  1fbb52:	cmplesd %xmm3,%xmm4
  1fbb57:	movapd %xmm4,%xmm5
  1fbb5b:	andpd  %xmm3,%xmm5
  1fbb5f:	andnpd %xmm2,%xmm4
  1fbb63:	orpd   %xmm5,%xmm4
  1fbb67:	ucomisd %xmm8,%xmm4
  1fbb6c:	jbe    1fbbc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1940>
  1fbb6e:	ucomisd %xmm4,%xmm9
  1fbb73:	jbe    1fbbc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1940>
  1fbb75:	movapd %xmm0,%xmm2
  1fbb79:	mulpd  %xmm0,%xmm2
  1fbb7d:	movapd %xmm2,%xmm3
  1fbb81:	unpckhpd %xmm2,%xmm3
  1fbb85:	addsd  %xmm2,%xmm3
  1fbb89:	movapd %xmm10,%xmm2
  1fbb8e:	divsd  %xmm3,%xmm2
  1fbb92:	mulsd  %xmm2,%xmm0
  1fbb96:	xorpd  %xmm11,%xmm1
  1fbb9b:	mulsd  %xmm2,%xmm1
  1fbb9f:	add    0x20(%rsp),%r13
  1fbba4:	cmp    %rbx,%r13
  1fbba7:	jb     1fbcf0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1a70>
  1fbbad:	jmp    1fbd90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1b10>
  1fbbb2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fbbc0:	ucomisd %xmm7,%xmm1
  1fbbc4:	setnp  %al
  1fbbc7:	sete   %cl
  1fbbca:	and    %al,%cl
  1fbbcc:	movq   %xmm0,%rax
  1fbbd1:	and    %r8,%rax
  1fbbd4:	cmp    %r11,%rax
  1fbbd7:	setl   %dl
  1fbbda:	test   %dl,%cl
  1fbbdc:	je     1fbc10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1990>
  1fbbde:	movapd %xmm10,%xmm2
  1fbbe3:	divsd  %xmm0,%xmm2
  1fbbe7:	xorpd  %xmm11,%xmm1
  1fbbec:	movapd %xmm2,%xmm0
  1fbbf0:	add    0x20(%rsp),%r13
  1fbbf5:	cmp    %rbx,%r13
  1fbbf8:	jb     1fbcf0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1a70>
  1fbbfe:	jmp    1fbd90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1b10>
  1fbc03:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fbc10:	ucomisd %xmm7,%xmm0
  1fbc14:	setnp  %cl
  1fbc17:	sete   %dl
  1fbc1a:	and    %cl,%dl
  1fbc1c:	movq   %xmm1,%rcx
  1fbc21:	and    %r8,%rcx
  1fbc24:	cmp    %r11,%rcx
  1fbc27:	setl   %sil
  1fbc2b:	test   %sil,%dl
  1fbc2e:	je     1fbc50 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x19d0>
  1fbc30:	movapd %xmm12,%xmm2
  1fbc35:	divsd  %xmm1,%xmm2
  1fbc39:	movapd %xmm2,%xmm1
  1fbc3d:	add    0x20(%rsp),%r13
  1fbc42:	cmp    %rbx,%r13
  1fbc45:	jb     1fbcf0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1a70>
  1fbc4b:	jmp    1fbd90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1b10>
  1fbc50:	movabs $0x7fefffffffffffff,%rdx
  1fbc5a:	cmp    %rdx,%rax
  1fbc5d:	setg   %al
  1fbc60:	cmp    %rdx,%rcx
  1fbc63:	setg   %cl
  1fbc66:	or     %al,%cl
  1fbc68:	cmp    $0x1,%cl
  1fbc6b:	jne    1fbd14 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1a94>
  1fbc71:	add    %rbp,%rdi
  1fbc74:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1fbc79:	movsd  0x1f9ba3e(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fbc82:	movapd 0x1f9a385(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fbc8b:	movsd  0x1f9ba34(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fbc94:	movsd  0x1f9ba1b(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fbc9d:	movsd  0x1f9ba0a(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fbca6:	xorpd  %xmm7,%xmm7
  1fbcaa:	movapd 0x1f9a34e(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fbcb2:	movabs $0x7ff0000000000000,%r11
  1fbcbc:	movabs $0x7fffffffffffffff,%r8
  1fbcc6:	mov    0x110(%rsp),%r10
  1fbcce:	mov    0x10(%rsp),%r9
  1fbcd3:	add    0x20(%rsp),%r13
  1fbcd8:	cmp    %rbx,%r13
  1fbcdb:	jae    1fbd90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1b10>
  1fbce1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fbcf0:	shl    $0x4,%r13
  1fbcf4:	movsd  %xmm0,0x0(%rbp,%r13,1)
  1fbcfb:	movsd  %xmm1,0x8(%rbp,%r13,1)
  1fbd02:	add    $0x8,%r15
  1fbd06:	cmp    %r15,%r14
  1fbd09:	jne    1fbb10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1890>
  1fbd0f:	jmp    1fbda3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1b23>
  1fbd14:	ucomisd %xmm7,%xmm1
  1fbd18:	jne    1fbd20 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1aa0>
  1fbd1a:	jnp    1fbbde <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x195e>
  1fbd20:	ucomisd %xmm7,%xmm0
  1fbd24:	jne    1fbd2c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1aac>
  1fbd26:	jnp    1fbc30 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x19b0>
  1fbd2c:	movapd %xmm3,%xmm1
  1fbd30:	cmplesd %xmm2,%xmm1
  1fbd35:	movapd %xmm1,%xmm4
  1fbd39:	andpd  %xmm2,%xmm4
  1fbd3d:	andnpd %xmm3,%xmm1
  1fbd41:	orpd   %xmm4,%xmm1
  1fbd45:	unpcklpd %xmm1,%xmm1
  1fbd49:	divpd  %xmm1,%xmm0
  1fbd4d:	movapd %xmm0,%xmm2
  1fbd51:	xorpd  %xmm11,%xmm2
  1fbd56:	movsd  %xmm0,%xmm2
  1fbd5a:	mulpd  %xmm0,%xmm0
  1fbd5e:	movapd %xmm0,%xmm3
  1fbd62:	unpcklpd %xmm0,%xmm3
  1fbd66:	unpckhpd %xmm0,%xmm0
  1fbd6a:	addpd  %xmm3,%xmm0
  1fbd6e:	divpd  %xmm0,%xmm2
  1fbd72:	divpd  %xmm1,%xmm2
  1fbd76:	movapd %xmm2,%xmm0
  1fbd7a:	movapd %xmm2,%xmm1
  1fbd7e:	unpckhpd %xmm2,%xmm1
  1fbd82:	add    0x20(%rsp),%r13
  1fbd87:	cmp    %rbx,%r13
  1fbd8a:	jb     1fbcf0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1a70>
  1fbd90:	lea    0x242fba9(%rip),%rdx        # 262b940 <__gmpfr_one+0x141c0>
  1fbd97:	mov    %r13,%rdi
  1fbd9a:	mov    %rbx,%rsi
  1fbd9d:	call   *0x24d315d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fbda3:	cmpq   $0x5,0x118(%rsp)
  1fbdac:	jb     201a5c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x77dc>
  1fbdb2:	mov    0x8(%rsp),%r13
  1fbdb7:	mov    %r13,%rdx
  1fbdba:	shl    $0x4,%rdx
  1fbdbe:	lea    0x0(,%r13,8),%rax
  1fbdc6:	add    %r13,%rax
  1fbdc9:	lea    0x0(,%rax,4),%rsi
  1fbdd1:	add    %r13,%rsi
  1fbdd4:	xor    %r8d,%r8d
  1fbdd7:	mov    0x108(%rsp),%r11
  1fbddf:	mov    0x30(%rsp),%r15
  1fbde4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fbdf0:	mov    (%r9,%r8,1),%rdi
  1fbdf4:	lea    (%rdi,%rdx,1),%rax
  1fbdf8:	cmp    %rbx,%rax
  1fbdfb:	jae    200a10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6790>
  1fbe01:	mov    0x20(%rsp),%rcx
  1fbe06:	add    %rdi,%rcx
  1fbe09:	cmp    %rbx,%rcx
  1fbe0c:	jae    2009fd <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x677d>
  1fbe12:	add    %rsi,%rdi
  1fbe15:	cmp    %rbx,%rdi
  1fbe18:	jae    2009ed <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x676d>
  1fbe1e:	shl    $0x4,%rax
  1fbe22:	shl    $0x4,%rcx
  1fbe26:	movupd 0x40(%r10),%xmm0
  1fbe2c:	movupd 0x0(%rbp,%rax,1),%xmm1
  1fbe32:	movapd %xmm0,%xmm2
  1fbe36:	mulpd  %xmm1,%xmm2
  1fbe3a:	shl    $0x4,%rdi
  1fbe3e:	movupd 0x0(%rbp,%rcx,1),%xmm3
  1fbe44:	movapd %xmm2,%xmm4
  1fbe48:	unpcklpd %xmm2,%xmm4
  1fbe4c:	unpckhpd %xmm2,%xmm2
  1fbe50:	subpd  %xmm2,%xmm4
  1fbe54:	mulpd  %xmm3,%xmm4
  1fbe58:	movapd %xmm0,%xmm2
  1fbe5c:	unpckhpd %xmm0,%xmm2
  1fbe60:	mulsd  %xmm1,%xmm2
  1fbe64:	unpckhpd %xmm1,%xmm1
  1fbe68:	mulsd  %xmm0,%xmm1
  1fbe6c:	addsd  %xmm2,%xmm1
  1fbe70:	unpcklpd %xmm1,%xmm1
  1fbe74:	shufpd $0x1,%xmm3,%xmm3
  1fbe79:	mulpd  %xmm1,%xmm3
  1fbe7d:	movapd %xmm4,%xmm0
  1fbe81:	subpd  %xmm3,%xmm0
  1fbe85:	addpd  %xmm4,%xmm3
  1fbe89:	movsd  %xmm0,%xmm3
  1fbe8d:	movupd %xmm3,0x0(%rbp,%rdi,1)
  1fbe93:	add    $0x8,%r8
  1fbe97:	cmp    %r8,%r14
  1fbe9a:	jne    1fbdf0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1b70>
  1fbea0:	xor    %eax,%eax
  1fbea2:	xor    %r14d,%r14d
  1fbea5:	mov    0x38(%rsp),%rcx
  1fbeaa:	mov    0x100(%rsp),%r8
  1fbeb2:	jmp    1fbec9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1c49>
  1fbeb4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fbec0:	add    $0x8,%rax
  1fbec4:	cmp    %rax,%r15
  1fbec7:	je     1fbeef <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1c6f>
  1fbec9:	mov    (%rcx,%rax,1),%rdi
  1fbecd:	cmp    %r11,%rdi
  1fbed0:	jae    2007e6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6566>
  1fbed6:	cmpq   $0x23,(%r8,%rdi,8)
  1fbedb:	jae    1fbec0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1c40>
  1fbedd:	cmp    %r12,%r14
  1fbee0:	jae    200faf <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6d2f>
  1fbee6:	mov    %rdi,(%r9,%r14,8)
  1fbeea:	inc    %r14
  1fbeed:	jmp    1fbec0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1c40>
  1fbeef:	cmp    %r12,%r14
  1fbef2:	ja     20059a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x631a>
  1fbef8:	test   %r14,%r14
  1fbefb:	je     1fc62e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x23ae>
  1fbf01:	lea    0x0(,%r14,8),%r15
  1fbf09:	lea    0x0(,%r13,2),%rcx
  1fbf11:	mov    %r13,%r12
  1fbf14:	shl    $0x5,%r12
  1fbf18:	mov    %rcx,0x48(%rsp)
  1fbf1d:	sub    %rcx,%r12
  1fbf20:	xor    %r13d,%r13d
  1fbf23:	xorpd  %xmm1,%xmm1
  1fbf27:	jmp    1fbf68 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1ce8>
  1fbf29:	nopl   0x0(%rax)
  1fbf30:	mov    $0x27,%r8d
  1fbf36:	mov    %rbp,%rdi
  1fbf39:	mov    %rbx,%rsi
  1fbf3c:	mov    0x8(%rsp),%rdx
  1fbf41:	call   1fa170 <oneloop::native::batch::copy_active_column::<f64>>
  1fbf46:	add    $0x8,%r13
  1fbf4a:	cmp    %r13,%r15
  1fbf4d:	mov    0x10(%rsp),%r9
  1fbf52:	mov    0x110(%rsp),%r10
  1fbf5a:	mov    0x100(%rsp),%r8
  1fbf62:	xorpd  %xmm1,%xmm1
  1fbf66:	je     1fbfa9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1d29>
  1fbf68:	mov    (%r9,%r13,1),%rcx
  1fbf6c:	lea    (%rcx,%r12,1),%rdi
  1fbf70:	cmp    %rbx,%rdi
  1fbf73:	jae    200a23 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x67a3>
  1fbf79:	shl    $0x4,%rdi
  1fbf7d:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1fbf83:	mov    $0x21,%r9d
  1fbf89:	ucomisd %xmm1,%xmm0
  1fbf8d:	jne    1fbf30 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1cb0>
  1fbf8f:	jp     1fbf30 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1cb0>
  1fbf91:	add    %rbp,%rdi
  1fbf94:	movsd  0x8(%rdi),%xmm0
  1fbf99:	ucomisd %xmm1,%xmm0
  1fbf9d:	jne    1fbf30 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1cb0>
  1fbf9f:	jp     1fbf30 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1cb0>
  1fbfa1:	mov    $0x25,%r9d
  1fbfa7:	jmp    1fbf30 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1cb0>
  1fbfa9:	mov    0x8(%rsp),%r13
  1fbfae:	imul   $0x27,%r13,%rcx
  1fbfb2:	xor    %edx,%edx
  1fbfb4:	xorpd  %xmm0,%xmm0
  1fbfb8:	xor    %esi,%esi
  1fbfba:	mov    0xf0(%rsp),%r12
  1fbfc2:	mov    0x108(%rsp),%r11
  1fbfca:	mov    0x30(%rsp),%r15
  1fbfcf:	jmp    1fbfe8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1d68>
  1fbfd1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fbfe0:	inc    %rdx
  1fbfe3:	cmp    %rdx,%r14
  1fbfe6:	je     1fc042 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1dc2>
  1fbfe8:	mov    (%r9,%rdx,8),%rdi
  1fbfec:	lea    (%rdi,%rcx,1),%rax
  1fbff0:	cmp    %rbx,%rax
  1fbff3:	jae    200a33 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x67b3>
  1fbff9:	shl    $0x4,%rax
  1fbffd:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fc003:	ucomisd %xmm0,%xmm1
  1fc007:	jne    1fc030 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1db0>
  1fc009:	jp     1fc030 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1db0>
  1fc00b:	add    %rbp,%rax
  1fc00e:	movsd  0x8(%rax),%xmm1
  1fc013:	ucomisd %xmm0,%xmm1
  1fc017:	jne    1fc030 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1db0>
  1fc019:	jp     1fc030 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1db0>
  1fc01b:	cmp    %r11,%rdi
  1fc01e:	jae    20187b <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x75fb>
  1fc024:	movq   $0x5d,(%r8,%rdi,8)
  1fc02c:	jmp    1fbfe0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1d60>
  1fc02e:	xchg   %ax,%ax
  1fc030:	cmp    %r12,%rsi
  1fc033:	jae    201349 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x70c9>
  1fc039:	mov    %rdi,(%r9,%rsi,8)
  1fc03d:	inc    %rsi
  1fc040:	jmp    1fbfe0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1d60>
  1fc042:	cmp    %r12,%rsi
  1fc045:	ja     2006c8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6448>
  1fc04b:	test   %rsi,%rsi
  1fc04e:	je     1fc62e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x23ae>
  1fc054:	mov    %rsi,0x20(%rsp)
  1fc059:	mov    0x118(%rsp),%rsi
  1fc061:	cmp    $0x2,%rsi
  1fc065:	jb     201b22 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x78a2>
  1fc06b:	mov    0x20(%rsp),%rax
  1fc070:	lea    0x0(,%rax,8),%r15
  1fc078:	lea    0x0(,%r13,4),%rax
  1fc080:	lea    (%rax,%rax,2),%rdx
  1fc084:	lea    0x0(,%r13,4),%rcx
  1fc08c:	add    %r13,%rcx
  1fc08f:	lea    0x0(,%rcx,8),%r12
  1fc097:	add    %r13,%r12
  1fc09a:	xor    %esi,%esi
  1fc09c:	nopl   0x0(%rax)
  1fc0a0:	mov    (%r9,%rsi,1),%rdi
  1fc0a4:	lea    (%rdi,%rdx,1),%rax
  1fc0a8:	cmp    %rbx,%rax
  1fc0ab:	jae    2010f3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6e73>
  1fc0b1:	add    %r12,%rdi
  1fc0b4:	cmp    %rbx,%rdi
  1fc0b7:	jae    2010e3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6e63>
  1fc0bd:	shl    $0x4,%rax
  1fc0c1:	shl    $0x4,%rdi
  1fc0c5:	movupd 0x10(%r10),%xmm0
  1fc0cb:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fc0d1:	movsd  0x8(%rbp,%rax,1),%xmm2
  1fc0d7:	unpcklpd %xmm1,%xmm1
  1fc0db:	mulpd  %xmm0,%xmm1
  1fc0df:	shufpd $0x1,%xmm0,%xmm0
  1fc0e4:	unpcklpd %xmm2,%xmm2
  1fc0e8:	mulpd  %xmm0,%xmm2
  1fc0ec:	movapd %xmm1,%xmm0
  1fc0f0:	subpd  %xmm2,%xmm0
  1fc0f4:	addpd  %xmm1,%xmm2
  1fc0f8:	movsd  %xmm0,%xmm2
  1fc0fc:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fc102:	add    $0x8,%rsi
  1fc106:	cmp    %rsi,%r15
  1fc109:	jne    1fc0a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1e20>
  1fc10b:	lea    (%rcx,%rcx,2),%rdx
  1fc10f:	imul   $0x2a,%r13,%r8
  1fc113:	xor    %esi,%esi
  1fc115:	data16 cs nopw 0x0(%rax,%rax,1)
  1fc120:	mov    (%r9,%rsi,1),%rdi
  1fc124:	lea    (%rdi,%rdx,1),%rax
  1fc128:	cmp    %rbx,%rax
  1fc12b:	jae    201129 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6ea9>
  1fc131:	lea    (%rdi,%r12,1),%rcx
  1fc135:	cmp    %rbx,%rcx
  1fc138:	jae    201116 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6e96>
  1fc13e:	add    %r8,%rdi
  1fc141:	cmp    %rbx,%rdi
  1fc144:	jae    201106 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6e86>
  1fc14a:	shl    $0x4,%rax
  1fc14e:	shl    $0x4,%rcx
  1fc152:	shl    $0x4,%rdi
  1fc156:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fc15c:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fc162:	addpd  %xmm0,%xmm1
  1fc166:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fc16c:	add    $0x8,%rsi
  1fc170:	cmp    %rsi,%r15
  1fc173:	jne    1fc120 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1ea0>
  1fc175:	imul   $0x2b,%r13,%r11
  1fc179:	xor    %r13d,%r13d
  1fc17c:	xorpd  %xmm8,%xmm8
  1fc181:	movapd 0x1f99e77(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fc189:	movsd  0x1f9b51f(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fc191:	mov    %r11,0x18(%rsp)
  1fc196:	mov    %r8,0x40(%rsp)
  1fc19b:	nopl   0x0(%rax,%rax,1)
  1fc1a0:	mov    (%r9,%r13,1),%r14
  1fc1a4:	lea    (%r14,%r8,1),%rdi
  1fc1a8:	cmp    %rbx,%rdi
  1fc1ab:	jae    20114f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6ecf>
  1fc1b1:	shl    $0x4,%rdi
  1fc1b5:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fc1bb:	movapd %xmm0,%xmm1
  1fc1bf:	unpckhpd %xmm0,%xmm1
  1fc1c3:	ucomisd %xmm8,%xmm1
  1fc1c8:	jne    1fc1e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1f60>
  1fc1ca:	jp     1fc1e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1f60>
  1fc1cc:	andpd  %xmm6,%xmm0
  1fc1d0:	jmp    1fc2a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2020>
  1fc1d5:	data16 cs nopw 0x0(%rax,%rax,1)
  1fc1e0:	ucomisd %xmm8,%xmm0
  1fc1e5:	jne    1fc1f6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1f76>
  1fc1e7:	jp     1fc1f6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1f76>
  1fc1e9:	andpd  %xmm6,%xmm1
  1fc1ed:	movapd %xmm1,%xmm0
  1fc1f1:	jmp    1fc2a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2020>
  1fc1f6:	movapd %xmm0,%xmm2
  1fc1fa:	andpd  %xmm6,%xmm2
  1fc1fe:	pshufd $0xee,%xmm2,%xmm3
  1fc203:	movapd %xmm2,%xmm4
  1fc207:	cmplesd %xmm3,%xmm4
  1fc20c:	movapd %xmm4,%xmm5
  1fc210:	andpd  %xmm3,%xmm5
  1fc214:	andnpd %xmm2,%xmm4
  1fc218:	orpd   %xmm5,%xmm4
  1fc21c:	movapd %xmm0,%xmm2
  1fc220:	cmpunordsd %xmm0,%xmm2
  1fc225:	movapd %xmm2,%xmm5
  1fc229:	andnpd %xmm4,%xmm5
  1fc22d:	andpd  %xmm3,%xmm2
  1fc231:	orpd   %xmm5,%xmm2
  1fc235:	ucomisd %xmm7,%xmm2
  1fc239:	jbe    1fc262 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1fe2>
  1fc23b:	movsd  0x1f9b475(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fc243:	ucomisd %xmm2,%xmm3
  1fc247:	jbe    1fc262 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1fe2>
  1fc249:	mulpd  %xmm0,%xmm0
  1fc24d:	movapd %xmm0,%xmm1
  1fc251:	unpckhpd %xmm0,%xmm1
  1fc255:	addsd  %xmm0,%xmm1
  1fc259:	xorps  %xmm0,%xmm0
  1fc25c:	sqrtsd %xmm1,%xmm0
  1fc260:	jmp    1fc2a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2020>
  1fc262:	call   *0x24cf968(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1fc268:	xorpd  %xmm8,%xmm8
  1fc26d:	mov    0x40(%rsp),%r8
  1fc272:	movsd  0x1f9b436(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fc27a:	movapd 0x1f99d7e(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fc282:	mov    0x18(%rsp),%r11
  1fc287:	mov    0x110(%rsp),%r10
  1fc28f:	mov    0x10(%rsp),%r9
  1fc294:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fc2a0:	add    %r11,%r14
  1fc2a3:	cmp    %rbx,%r14
  1fc2a6:	jae    20113c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6ebc>
  1fc2ac:	shl    $0x4,%r14
  1fc2b0:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fc2b7:	movq   $0x0,0x8(%rbp,%r14,1)
  1fc2c0:	add    $0x8,%r13
  1fc2c4:	cmp    %r13,%r15
  1fc2c7:	jne    1fc1a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x1f20>
  1fc2cd:	mov    0x48(%rsp),%rax
  1fc2d2:	lea    (%rax,%rax,8),%rdx
  1fc2d6:	imul   $0x2c,0x8(%rsp),%r13
  1fc2dc:	xor    %esi,%esi
  1fc2de:	xchg   %ax,%ax
  1fc2e0:	mov    (%r9,%rsi,1),%rdi
  1fc2e4:	lea    (%rdi,%rdx,1),%rax
  1fc2e8:	cmp    %rbx,%rax
  1fc2eb:	jae    201182 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6f02>
  1fc2f1:	lea    (%rdi,%r12,1),%rcx
  1fc2f5:	cmp    %rbx,%rcx
  1fc2f8:	jae    20116f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6eef>
  1fc2fe:	add    %r13,%rdi
  1fc301:	cmp    %rbx,%rdi
  1fc304:	jae    20115f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6edf>
  1fc30a:	shl    $0x4,%rax
  1fc30e:	shl    $0x4,%rcx
  1fc312:	shl    $0x4,%rdi
  1fc316:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fc31c:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fc322:	addpd  %xmm0,%xmm1
  1fc326:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fc32c:	add    $0x8,%rsi
  1fc330:	cmp    %rsi,%r15
  1fc333:	jne    1fc2e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2060>
  1fc335:	mov    0x8(%rsp),%rax
  1fc33a:	lea    (%rax,%rax,8),%rax
  1fc33e:	lea    (%rax,%rax,4),%rdx
  1fc342:	xor    %r12d,%r12d
  1fc345:	xorpd  %xmm8,%xmm8
  1fc34a:	mov    %rdx,0x40(%rsp)
  1fc34f:	nop
  1fc350:	mov    (%r9,%r12,1),%r14
  1fc354:	lea    (%r14,%r13,1),%rdi
  1fc358:	cmp    %rbx,%rdi
  1fc35b:	jae    2011a8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6f28>
  1fc361:	shl    $0x4,%rdi
  1fc365:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fc36b:	movapd %xmm0,%xmm1
  1fc36f:	unpckhpd %xmm0,%xmm1
  1fc373:	ucomisd %xmm8,%xmm1
  1fc378:	jne    1fc390 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2110>
  1fc37a:	jp     1fc390 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2110>
  1fc37c:	andpd  %xmm6,%xmm0
  1fc380:	jmp    1fc450 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x21d0>
  1fc385:	data16 cs nopw 0x0(%rax,%rax,1)
  1fc390:	ucomisd %xmm8,%xmm0
  1fc395:	jne    1fc3a6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2126>
  1fc397:	jp     1fc3a6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2126>
  1fc399:	andpd  %xmm6,%xmm1
  1fc39d:	movapd %xmm1,%xmm0
  1fc3a1:	jmp    1fc450 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x21d0>
  1fc3a6:	movapd %xmm0,%xmm2
  1fc3aa:	andpd  %xmm6,%xmm2
  1fc3ae:	pshufd $0xee,%xmm2,%xmm3
  1fc3b3:	movapd %xmm2,%xmm4
  1fc3b7:	cmplesd %xmm3,%xmm4
  1fc3bc:	movapd %xmm4,%xmm5
  1fc3c0:	andpd  %xmm3,%xmm5
  1fc3c4:	andnpd %xmm2,%xmm4
  1fc3c8:	orpd   %xmm5,%xmm4
  1fc3cc:	movapd %xmm0,%xmm2
  1fc3d0:	cmpunordsd %xmm0,%xmm2
  1fc3d5:	movapd %xmm2,%xmm5
  1fc3d9:	andnpd %xmm4,%xmm5
  1fc3dd:	andpd  %xmm3,%xmm2
  1fc3e1:	orpd   %xmm5,%xmm2
  1fc3e5:	ucomisd %xmm7,%xmm2
  1fc3e9:	jbe    1fc412 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2192>
  1fc3eb:	movsd  0x1f9b2c5(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fc3f3:	ucomisd %xmm2,%xmm3
  1fc3f7:	jbe    1fc412 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2192>
  1fc3f9:	mulpd  %xmm0,%xmm0
  1fc3fd:	movapd %xmm0,%xmm1
  1fc401:	unpckhpd %xmm0,%xmm1
  1fc405:	addsd  %xmm0,%xmm1
  1fc409:	xorps  %xmm0,%xmm0
  1fc40c:	sqrtsd %xmm1,%xmm0
  1fc410:	jmp    1fc450 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x21d0>
  1fc412:	call   *0x24cf7b8(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1fc418:	xorpd  %xmm8,%xmm8
  1fc41d:	mov    0x40(%rsp),%rdx
  1fc422:	movsd  0x1f9b286(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fc42a:	movapd 0x1f99bce(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fc432:	mov    0x18(%rsp),%r11
  1fc437:	mov    0x110(%rsp),%r10
  1fc43f:	mov    0x10(%rsp),%r9
  1fc444:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fc450:	add    %rdx,%r14
  1fc453:	cmp    %rbx,%r14
  1fc456:	jae    201195 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6f15>
  1fc45c:	shl    $0x4,%r14
  1fc460:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fc467:	movq   $0x0,0x8(%rbp,%r14,1)
  1fc470:	add    $0x8,%r12
  1fc474:	cmp    %r12,%r15
  1fc477:	jne    1fc350 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x20d0>
  1fc47d:	mov    0x8(%rsp),%r13
  1fc482:	imul   $0x2e,%r13,%rsi
  1fc486:	xor    %ecx,%ecx
  1fc488:	mov    0xf0(%rsp),%r12
  1fc490:	mov    (%r9,%rcx,1),%rdi
  1fc494:	lea    (%rdi,%rdx,1),%rax
  1fc498:	cmp    %rbx,%rax
  1fc49b:	jae    2011c8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6f48>
  1fc4a1:	add    %rsi,%rdi
  1fc4a4:	cmp    %rbx,%rdi
  1fc4a7:	jae    2011b8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6f38>
  1fc4ad:	shl    $0x4,%rax
  1fc4b1:	shl    $0x4,%rdi
  1fc4b5:	movupd 0x10(%r10),%xmm0
  1fc4bb:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fc4c1:	movsd  0x8(%rbp,%rax,1),%xmm2
  1fc4c7:	unpcklpd %xmm1,%xmm1
  1fc4cb:	mulpd  %xmm0,%xmm1
  1fc4cf:	shufpd $0x1,%xmm0,%xmm0
  1fc4d4:	unpcklpd %xmm2,%xmm2
  1fc4d8:	mulpd  %xmm0,%xmm2
  1fc4dc:	movapd %xmm1,%xmm0
  1fc4e0:	subpd  %xmm2,%xmm0
  1fc4e4:	addpd  %xmm1,%xmm2
  1fc4e8:	movsd  %xmm0,%xmm2
  1fc4ec:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fc4f2:	add    $0x8,%rcx
  1fc4f6:	cmp    %rcx,%r15
  1fc4f9:	jne    1fc490 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2210>
  1fc4fb:	imul   $0x2f,%r13,%rdx
  1fc4ff:	xor    %r8d,%r8d
  1fc502:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fc510:	mov    (%r9,%r8,1),%rdi
  1fc514:	lea    (%rdi,%r11,1),%rax
  1fc518:	cmp    %rbx,%rax
  1fc51b:	jae    2011fe <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6f7e>
  1fc521:	lea    (%rdi,%rsi,1),%rcx
  1fc525:	cmp    %rbx,%rcx
  1fc528:	jae    2011eb <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6f6b>
  1fc52e:	add    %rdx,%rdi
  1fc531:	cmp    %rbx,%rdi
  1fc534:	jae    2011db <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6f5b>
  1fc53a:	shl    $0x4,%rax
  1fc53e:	shl    $0x4,%rcx
  1fc542:	shl    $0x4,%rdi
  1fc546:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fc54c:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fc552:	addpd  %xmm0,%xmm1
  1fc556:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fc55c:	add    $0x8,%r8
  1fc560:	cmp    %r8,%r15
  1fc563:	jne    1fc510 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2290>
  1fc565:	xor    %ecx,%ecx
  1fc567:	xorpd  %xmm0,%xmm0
  1fc56b:	xor    %esi,%esi
  1fc56d:	mov    0x108(%rsp),%r11
  1fc575:	mov    0x30(%rsp),%r15
  1fc57a:	mov    0x100(%rsp),%r8
  1fc582:	jmp    1fc59a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x231a>
  1fc584:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fc590:	inc    %rcx
  1fc593:	cmp    %rcx,0x20(%rsp)
  1fc598:	je     1fc5f2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2372>
  1fc59a:	mov    (%r9,%rcx,8),%rdi
  1fc59e:	lea    (%rdi,%rdx,1),%rax
  1fc5a2:	cmp    %rbx,%rax
  1fc5a5:	jae    201211 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6f91>
  1fc5ab:	shl    $0x4,%rax
  1fc5af:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fc5b5:	ucomisd %xmm0,%xmm1
  1fc5b9:	jne    1fc5e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2360>
  1fc5bb:	jp     1fc5e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2360>
  1fc5bd:	add    %rbp,%rax
  1fc5c0:	movsd  0x8(%rax),%xmm1
  1fc5c5:	ucomisd %xmm0,%xmm1
  1fc5c9:	jne    1fc5e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2360>
  1fc5cb:	jp     1fc5e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2360>
  1fc5cd:	cmp    %r11,%rdi
  1fc5d0:	jae    2019ff <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x777f>
  1fc5d6:	movq   $0x2e,(%r8,%rdi,8)
  1fc5de:	jmp    1fc590 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2310>
  1fc5e0:	cmp    %r12,%rsi
  1fc5e3:	jae    201969 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x76e9>
  1fc5e9:	mov    %rdi,(%r9,%rsi,8)
  1fc5ed:	inc    %rsi
  1fc5f0:	jmp    1fc590 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2310>
  1fc5f2:	cmp    %r12,%rsi
  1fc5f5:	ja     20076c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x64ec>
  1fc5fb:	test   %rsi,%rsi
  1fc5fe:	je     1fc62e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x23ae>
  1fc600:	shl    $0x3,%rsi
  1fc604:	xor    %eax,%eax
  1fc606:	cs nopw 0x0(%rax,%rax,1)
  1fc610:	mov    (%r9,%rax,1),%rdi
  1fc614:	cmp    %r11,%rdi
  1fc617:	jae    20189e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x761e>
  1fc61d:	movq   $0x2f,(%r8,%rdi,8)
  1fc625:	add    $0x8,%rax
  1fc629:	cmp    %rax,%rsi
  1fc62c:	jne    1fc610 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2390>
  1fc62e:	xor    %ecx,%ecx
  1fc630:	xor    %edi,%edi
  1fc632:	mov    0x38(%rsp),%r13
  1fc637:	jmp    1fc650 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x23d0>
  1fc639:	nopl   0x0(%rax)
  1fc640:	mov    %rax,(%r9,%rdi,8)
  1fc644:	inc    %rdi
  1fc647:	add    $0x8,%rcx
  1fc64b:	cmp    %rcx,%r15
  1fc64e:	je     1fc67a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x23fa>
  1fc650:	mov    0x0(%r13,%rcx,1),%rax
  1fc655:	cmp    %r11,%rax
  1fc658:	jae    2007f6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6576>
  1fc65e:	cmpq   $0x2f,(%r8,%rax,8)
  1fc663:	jae    1fc647 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x23c7>
  1fc665:	cmp    %r12,%rdi
  1fc668:	jb     1fc640 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x23c0>
  1fc66a:	lea    0x242f53f(%rip),%rdx        # 262bbb0 <__gmpfr_one+0x14430>
  1fc671:	mov    %r12,%rsi
  1fc674:	call   *0x24d2886(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fc67a:	xor    %eax,%eax
  1fc67c:	xor    %esi,%esi
  1fc67e:	jmp    1fc689 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2409>
  1fc680:	add    $0x8,%rax
  1fc684:	cmp    %rax,%r15
  1fc687:	je     1fc6b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2430>
  1fc689:	mov    0x0(%r13,%rax,1),%rdi
  1fc68e:	cmp    %r11,%rdi
  1fc691:	jae    200809 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6589>
  1fc697:	cmpq   $0x30,(%r8,%rdi,8)
  1fc69c:	jae    1fc680 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2400>
  1fc69e:	cmp    %r12,%rsi
  1fc6a1:	jae    200fc2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6d42>
  1fc6a7:	mov    %rdi,(%r9,%rsi,8)
  1fc6ab:	inc    %rsi
  1fc6ae:	jmp    1fc680 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2400>
  1fc6b0:	cmp    %r12,%rsi
  1fc6b3:	ja     2005af <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x632f>
  1fc6b9:	test   %rsi,%rsi
  1fc6bc:	je     1fce5e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2bde>
  1fc6c2:	mov    %rsi,0x18(%rsp)
  1fc6c7:	lea    0x0(,%rsi,8),%r15
  1fc6cf:	mov    0x8(%rsp),%r13
  1fc6d4:	imul   $0x2f,%r13,%r14
  1fc6d8:	imul   $0x34,%r13,%rax
  1fc6dc:	mov    %rax,0x20(%rsp)
  1fc6e1:	xor    %r12d,%r12d
  1fc6e4:	xorpd  %xmm1,%xmm1
  1fc6e8:	jmp    1fc724 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x24a4>
  1fc6ea:	nopw   0x0(%rax,%rax,1)
  1fc6f0:	mov    $0x34,%r8d
  1fc6f6:	mov    $0x2f,%r9d
  1fc6fc:	mov    %rbp,%rdi
  1fc6ff:	mov    %rbx,%rsi
  1fc702:	mov    %r13,%rdx
  1fc705:	call   1fa170 <oneloop::native::batch::copy_active_column::<f64>>
  1fc70a:	xorpd  %xmm1,%xmm1
  1fc70e:	mov    0x110(%rsp),%r10
  1fc716:	mov    0x10(%rsp),%r9
  1fc71b:	add    $0x8,%r12
  1fc71f:	cmp    %r12,%r15
  1fc722:	je     1fc78d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x250d>
  1fc724:	mov    (%r9,%r12,1),%rcx
  1fc728:	lea    (%rcx,%r14,1),%rdi
  1fc72c:	cmp    %rbx,%rdi
  1fc72f:	jae    200a46 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x67c6>
  1fc735:	shl    $0x4,%rdi
  1fc739:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1fc73f:	ucomisd %xmm1,%xmm0
  1fc743:	jne    1fc6f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2470>
  1fc745:	jp     1fc6f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2470>
  1fc747:	add    %rbp,%rdi
  1fc74a:	movsd  0x8(%rdi),%xmm0
  1fc74f:	ucomisd %xmm1,%xmm0
  1fc753:	jne    1fc6f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2470>
  1fc755:	jp     1fc6f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2470>
  1fc757:	add    0x20(%rsp),%rcx
  1fc75c:	cmp    %rbx,%rcx
  1fc75f:	jae    20188b <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x760b>
  1fc765:	cmpq   $0x3,0x118(%rsp)
  1fc76e:	jbe    20100e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6d8e>
  1fc774:	shl    $0x4,%rcx
  1fc778:	movupd 0x30(%r10),%xmm0
  1fc77e:	movupd %xmm0,0x0(%rbp,%rcx,1)
  1fc784:	add    $0x8,%r12
  1fc788:	cmp    %r12,%r15
  1fc78b:	jne    1fc724 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x24a4>
  1fc78d:	imul   $0x35,%r13,%rdx
  1fc791:	xor    %r13d,%r13d
  1fc794:	xorpd  %xmm8,%xmm8
  1fc799:	movapd 0x1f9985e(%rip),%xmm9        # 2196000 <_fini+0x520>
  1fc7a2:	movsd  0x1f9af06(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fc7aa:	movsd  0x1f9af06(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fc7b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fc7c0:	mov    (%r9,%r13,1),%r14
  1fc7c4:	mov    0x20(%rsp),%rax
  1fc7c9:	lea    (%r14,%rax,1),%rdi
  1fc7cd:	cmp    %rbx,%rdi
  1fc7d0:	jae    200a69 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x67e9>
  1fc7d6:	shl    $0x4,%rdi
  1fc7da:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fc7e0:	movapd %xmm0,%xmm1
  1fc7e4:	unpckhpd %xmm0,%xmm1
  1fc7e8:	ucomisd %xmm8,%xmm1
  1fc7ed:	jne    1fc800 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2580>
  1fc7ef:	jp     1fc800 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2580>
  1fc7f1:	andpd  %xmm9,%xmm0
  1fc7f6:	jmp    1fc8c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2640>
  1fc7fb:	nopl   0x0(%rax,%rax,1)
  1fc800:	ucomisd %xmm8,%xmm0
  1fc805:	jne    1fc817 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2597>
  1fc807:	jp     1fc817 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2597>
  1fc809:	andpd  %xmm9,%xmm1
  1fc80e:	movapd %xmm1,%xmm0
  1fc812:	jmp    1fc8c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2640>
  1fc817:	movapd %xmm0,%xmm2
  1fc81b:	andpd  %xmm9,%xmm2
  1fc820:	pshufd $0xee,%xmm2,%xmm3
  1fc825:	movapd %xmm2,%xmm4
  1fc829:	cmplesd %xmm3,%xmm4
  1fc82e:	movapd %xmm4,%xmm5
  1fc832:	andpd  %xmm3,%xmm5
  1fc836:	andnpd %xmm2,%xmm4
  1fc83a:	orpd   %xmm5,%xmm4
  1fc83e:	movapd %xmm0,%xmm2
  1fc842:	cmpunordsd %xmm0,%xmm2
  1fc847:	movapd %xmm2,%xmm5
  1fc84b:	andnpd %xmm4,%xmm5
  1fc84f:	andpd  %xmm3,%xmm2
  1fc853:	orpd   %xmm5,%xmm2
  1fc857:	ucomisd %xmm6,%xmm2
  1fc85b:	jbe    1fc87c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x25fc>
  1fc85d:	ucomisd %xmm2,%xmm7
  1fc861:	jbe    1fc87c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x25fc>
  1fc863:	mulpd  %xmm0,%xmm0
  1fc867:	movapd %xmm0,%xmm1
  1fc86b:	unpckhpd %xmm0,%xmm1
  1fc86f:	addsd  %xmm0,%xmm1
  1fc873:	xorps  %xmm0,%xmm0
  1fc876:	sqrtsd %xmm1,%xmm0
  1fc87a:	jmp    1fc8c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2640>
  1fc87c:	mov    %rdx,%r12
  1fc87f:	call   *0x24cf34b(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1fc885:	movapd 0x1f99772(%rip),%xmm9        # 2196000 <_fini+0x520>
  1fc88e:	xorpd  %xmm8,%xmm8
  1fc893:	mov    %r12,%rdx
  1fc896:	movsd  0x1f9ae1a(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fc89e:	movsd  0x1f9ae0a(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fc8a6:	mov    0x110(%rsp),%r10
  1fc8ae:	mov    0x10(%rsp),%r9
  1fc8b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fc8c0:	add    %rdx,%r14
  1fc8c3:	cmp    %rbx,%r14
  1fc8c6:	jae    200a56 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x67d6>
  1fc8cc:	shl    $0x4,%r14
  1fc8d0:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fc8d7:	movq   $0x0,0x8(%rbp,%r14,1)
  1fc8e0:	add    $0x8,%r13
  1fc8e4:	cmp    %r13,%r15
  1fc8e7:	jne    1fc7c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2540>
  1fc8ed:	cmpq   $0x2,0x118(%rsp)
  1fc8f6:	jb     201b56 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x78d6>
  1fc8fc:	mov    0x8(%rsp),%r11
  1fc901:	imul   $0x36,%r11,%rsi
  1fc905:	xor    %ecx,%ecx
  1fc907:	mov    0xf0(%rsp),%r12
  1fc90f:	nop
  1fc910:	mov    (%r9,%rcx,1),%rdi
  1fc914:	lea    (%rdi,%rdx,1),%rax
  1fc918:	cmp    %rbx,%rax
  1fc91b:	jae    200a89 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6809>
  1fc921:	add    %rsi,%rdi
  1fc924:	cmp    %rbx,%rdi
  1fc927:	jae    200a79 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x67f9>
  1fc92d:	shl    $0x4,%rax
  1fc931:	shl    $0x4,%rdi
  1fc935:	movupd 0x10(%r10),%xmm0
  1fc93b:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fc941:	movsd  0x8(%rbp,%rax,1),%xmm2
  1fc947:	unpcklpd %xmm1,%xmm1
  1fc94b:	mulpd  %xmm0,%xmm1
  1fc94f:	shufpd $0x1,%xmm0,%xmm0
  1fc954:	unpcklpd %xmm2,%xmm2
  1fc958:	mulpd  %xmm0,%xmm2
  1fc95c:	movapd %xmm1,%xmm0
  1fc960:	subpd  %xmm2,%xmm0
  1fc964:	addpd  %xmm1,%xmm2
  1fc968:	movsd  %xmm0,%xmm2
  1fc96c:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fc972:	add    $0x8,%rcx
  1fc976:	cmp    %rcx,%r15
  1fc979:	jne    1fc910 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2690>
  1fc97b:	imul   $0x37,%r11,%rdx
  1fc97f:	xor    %r8d,%r8d
  1fc982:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fc990:	mov    (%r9,%r8,1),%rdi
  1fc994:	mov    0x20(%rsp),%rax
  1fc999:	add    %rdi,%rax
  1fc99c:	cmp    %rbx,%rax
  1fc99f:	jae    200abf <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x683f>
  1fc9a5:	lea    (%rdi,%rsi,1),%rcx
  1fc9a9:	cmp    %rbx,%rcx
  1fc9ac:	jae    200aac <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x682c>
  1fc9b2:	add    %rdx,%rdi
  1fc9b5:	cmp    %rbx,%rdi
  1fc9b8:	jae    200a9c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x681c>
  1fc9be:	shl    $0x4,%rax
  1fc9c2:	shl    $0x4,%rcx
  1fc9c6:	shl    $0x4,%rdi
  1fc9ca:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fc9d0:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fc9d6:	addpd  %xmm0,%xmm1
  1fc9da:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fc9e0:	add    $0x8,%r8
  1fc9e4:	cmp    %r8,%r15
  1fc9e7:	jne    1fc990 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2710>
  1fc9e9:	xor    %ecx,%ecx
  1fc9eb:	xorpd  %xmm0,%xmm0
  1fc9ef:	xor    %r14d,%r14d
  1fc9f2:	mov    0x108(%rsp),%r11
  1fc9fa:	mov    0x30(%rsp),%r15
  1fc9ff:	mov    0x38(%rsp),%r13
  1fca04:	mov    0x100(%rsp),%r8
  1fca0c:	jmp    1fca2b <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x27ab>
  1fca0e:	xchg   %ax,%ax
  1fca10:	cmp    %r11,%rdi
  1fca13:	jae    2018ae <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x762e>
  1fca19:	movq   $0x38,(%r8,%rdi,8)
  1fca21:	inc    %rcx
  1fca24:	cmp    %rcx,0x18(%rsp)
  1fca29:	je     1fca78 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x27f8>
  1fca2b:	mov    (%r9,%rcx,8),%rdi
  1fca2f:	lea    (%rdi,%rdx,1),%rax
  1fca33:	cmp    %rbx,%rax
  1fca36:	jae    200ad2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6852>
  1fca3c:	shl    $0x4,%rax
  1fca40:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fca46:	ucomisd %xmm0,%xmm1
  1fca4a:	jne    1fca5e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x27de>
  1fca4c:	jp     1fca5e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x27de>
  1fca4e:	add    %rbp,%rax
  1fca51:	movsd  0x8(%rax),%xmm1
  1fca56:	ucomisd %xmm0,%xmm1
  1fca5a:	jne    1fca5e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x27de>
  1fca5c:	jnp    1fca10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2790>
  1fca5e:	cmp    %r12,%r14
  1fca61:	jae    20149d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x721d>
  1fca67:	mov    %rdi,(%r9,%r14,8)
  1fca6b:	inc    %r14
  1fca6e:	inc    %rcx
  1fca71:	cmp    %rcx,0x18(%rsp)
  1fca76:	jne    1fca2b <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x27ab>
  1fca78:	cmp    %r12,%r14
  1fca7b:	ja     2006da <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x645a>
  1fca81:	test   %r14,%r14
  1fca84:	je     1fce5e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2bde>
  1fca8a:	shl    $0x3,%r14
  1fca8e:	mov    0x8(%rsp),%rax
  1fca93:	imul   $0x2c,%rax,%rcx
  1fca97:	mov    %rcx,0x18(%rsp)
  1fca9c:	imul   $0x39,%rax,%rax
  1fcaa0:	mov    %rax,0x20(%rsp)
  1fcaa5:	xor    %r15d,%r15d
  1fcaa8:	movapd 0x1f9954f(%rip),%xmm8        # 2196000 <_fini+0x520>
  1fcab1:	xorpd  %xmm9,%xmm9
  1fcab6:	movsd  0x1f9ac09(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fcabf:	movapd 0x1f99548(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fcac8:	movsd  0x1f9abef(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fcad1:	movabs $0x7fffffffffffffff,%r11
  1fcadb:	nopl   0x0(%rax,%rax,1)
  1fcae0:	mov    (%r9,%r15,1),%r13
  1fcae4:	mov    0x18(%rsp),%rax
  1fcae9:	lea    (%rax,%r13,1),%rdi
  1fcaed:	cmp    %rbx,%rdi
  1fcaf0:	jae    201224 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6fa4>
  1fcaf6:	shl    $0x4,%rdi
  1fcafa:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fcb00:	movapd %xmm0,%xmm2
  1fcb04:	andpd  %xmm8,%xmm2
  1fcb09:	movapd %xmm0,%xmm1
  1fcb0d:	unpckhpd %xmm0,%xmm1
  1fcb11:	movapd %xmm1,%xmm3
  1fcb15:	andpd  %xmm8,%xmm3
  1fcb1a:	ucomisd %xmm9,%xmm0
  1fcb1f:	je     1fcb90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2910>
  1fcb21:	ucomisd %xmm9,%xmm1
  1fcb26:	je     1fcb90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2910>
  1fcb28:	movapd %xmm2,%xmm4
  1fcb2c:	cmplesd %xmm3,%xmm4
  1fcb31:	movapd %xmm4,%xmm5
  1fcb35:	andpd  %xmm3,%xmm5
  1fcb39:	andnpd %xmm2,%xmm4
  1fcb3d:	orpd   %xmm5,%xmm4
  1fcb41:	ucomisd %xmm6,%xmm4
  1fcb45:	jbe    1fcb90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2910>
  1fcb47:	ucomisd %xmm4,%xmm7
  1fcb4b:	jbe    1fcb90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2910>
  1fcb4d:	movapd %xmm0,%xmm2
  1fcb51:	mulpd  %xmm0,%xmm2
  1fcb55:	movapd %xmm2,%xmm3
  1fcb59:	unpckhpd %xmm2,%xmm3
  1fcb5d:	addsd  %xmm2,%xmm3
  1fcb61:	movapd %xmm10,%xmm2
  1fcb66:	divsd  %xmm3,%xmm2
  1fcb6a:	mulsd  %xmm2,%xmm0
  1fcb6e:	xorpd  %xmm11,%xmm1
  1fcb73:	mulsd  %xmm2,%xmm1
  1fcb77:	add    0x20(%rsp),%r13
  1fcb7c:	cmp    %rbx,%r13
  1fcb7f:	jb     1fccb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2a30>
  1fcb85:	jmp    1fcd52 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2ad2>
  1fcb8a:	nopw   0x0(%rax,%rax,1)
  1fcb90:	ucomisd %xmm9,%xmm1
  1fcb95:	setnp  %al
  1fcb98:	sete   %cl
  1fcb9b:	and    %al,%cl
  1fcb9d:	movq   %xmm0,%rax
  1fcba2:	and    %r11,%rax
  1fcba5:	movabs $0x7ff0000000000000,%rsi
  1fcbaf:	cmp    %rsi,%rax
  1fcbb2:	setl   %dl
  1fcbb5:	test   %dl,%cl
  1fcbb7:	je     1fcbe0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2960>
  1fcbb9:	movapd %xmm10,%xmm2
  1fcbbe:	divsd  %xmm0,%xmm2
  1fcbc2:	xorpd  %xmm11,%xmm1
  1fcbc7:	movapd %xmm2,%xmm0
  1fcbcb:	add    0x20(%rsp),%r13
  1fcbd0:	cmp    %rbx,%r13
  1fcbd3:	jb     1fccb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2a30>
  1fcbd9:	jmp    1fcd52 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2ad2>
  1fcbde:	xchg   %ax,%ax
  1fcbe0:	ucomisd %xmm9,%xmm0
  1fcbe5:	setnp  %cl
  1fcbe8:	sete   %dl
  1fcbeb:	and    %cl,%dl
  1fcbed:	movq   %xmm1,%rcx
  1fcbf2:	and    %r11,%rcx
  1fcbf5:	cmp    %rsi,%rcx
  1fcbf8:	setl   %sil
  1fcbfc:	test   %sil,%dl
  1fcbff:	je     1fcc21 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x29a1>
  1fcc01:	movapd %xmm12,%xmm2
  1fcc06:	divsd  %xmm1,%xmm2
  1fcc0a:	movapd %xmm2,%xmm1
  1fcc0e:	add    0x20(%rsp),%r13
  1fcc13:	cmp    %rbx,%r13
  1fcc16:	jb     1fccb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2a30>
  1fcc1c:	jmp    1fcd52 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2ad2>
  1fcc21:	movabs $0x7fefffffffffffff,%rdx
  1fcc2b:	cmp    %rdx,%rax
  1fcc2e:	setg   %al
  1fcc31:	cmp    %rdx,%rcx
  1fcc34:	setg   %cl
  1fcc37:	or     %al,%cl
  1fcc39:	cmp    $0x1,%cl
  1fcc3c:	jne    1fccd4 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2a54>
  1fcc42:	add    %rbp,%rdi
  1fcc45:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1fcc4a:	movsd  0x1f9aa6d(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fcc53:	movapd 0x1f993b4(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fcc5c:	movsd  0x1f9aa63(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fcc65:	xorpd  %xmm9,%xmm9
  1fcc6a:	movapd 0x1f9938d(%rip),%xmm8        # 2196000 <_fini+0x520>
  1fcc73:	movsd  0x1f9aa3d(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fcc7b:	movsd  0x1f9aa2d(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fcc83:	movabs $0x7fffffffffffffff,%r11
  1fcc8d:	mov    0x100(%rsp),%r8
  1fcc95:	mov    0x110(%rsp),%r10
  1fcc9d:	mov    0x10(%rsp),%r9
  1fcca2:	add    0x20(%rsp),%r13
  1fcca7:	cmp    %rbx,%r13
  1fccaa:	jae    1fcd52 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2ad2>
  1fccb0:	shl    $0x4,%r13
  1fccb4:	movsd  %xmm0,0x0(%rbp,%r13,1)
  1fccbb:	movsd  %xmm1,0x8(%rbp,%r13,1)
  1fccc2:	add    $0x8,%r15
  1fccc6:	cmp    %r15,%r14
  1fccc9:	jne    1fcae0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2860>
  1fcccf:	jmp    1fcd65 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2ae5>
  1fccd4:	ucomisd %xmm9,%xmm1
  1fccd9:	jne    1fcce1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2a61>
  1fccdb:	jnp    1fcbb9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2939>
  1fcce1:	ucomisd %xmm9,%xmm0
  1fcce6:	jne    1fccee <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2a6e>
  1fcce8:	jnp    1fcc01 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2981>
  1fccee:	movapd %xmm3,%xmm1
  1fccf2:	cmplesd %xmm2,%xmm1
  1fccf7:	movapd %xmm1,%xmm4
  1fccfb:	andpd  %xmm2,%xmm4
  1fccff:	andnpd %xmm3,%xmm1
  1fcd03:	orpd   %xmm4,%xmm1
  1fcd07:	unpcklpd %xmm1,%xmm1
  1fcd0b:	divpd  %xmm1,%xmm0
  1fcd0f:	movapd %xmm0,%xmm2
  1fcd13:	xorpd  %xmm11,%xmm2
  1fcd18:	movsd  %xmm0,%xmm2
  1fcd1c:	mulpd  %xmm0,%xmm0
  1fcd20:	movapd %xmm0,%xmm3
  1fcd24:	unpcklpd %xmm0,%xmm3
  1fcd28:	unpckhpd %xmm0,%xmm0
  1fcd2c:	addpd  %xmm3,%xmm0
  1fcd30:	divpd  %xmm0,%xmm2
  1fcd34:	divpd  %xmm1,%xmm2
  1fcd38:	movapd %xmm2,%xmm0
  1fcd3c:	movapd %xmm2,%xmm1
  1fcd40:	unpckhpd %xmm2,%xmm1
  1fcd44:	add    0x20(%rsp),%r13
  1fcd49:	cmp    %rbx,%r13
  1fcd4c:	jb     1fccb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2a30>
  1fcd52:	lea    0x242ef8f(%rip),%rdx        # 262bce8 <__gmpfr_one+0x14568>
  1fcd59:	mov    %r13,%rdi
  1fcd5c:	mov    %rbx,%rsi
  1fcd5f:	call   *0x24d219b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fcd65:	mov    0x8(%rsp),%r13
  1fcd6a:	imul   $0x3a,%r13,%rdx
  1fcd6e:	xor    %esi,%esi
  1fcd70:	mov    0x108(%rsp),%r11
  1fcd78:	mov    0x30(%rsp),%r15
  1fcd7d:	nopl   (%rax)
  1fcd80:	mov    (%r9,%rsi,1),%rdi
  1fcd84:	lea    (%rdi,%r13,1),%rcx
  1fcd88:	cmp    %rbx,%rcx
  1fcd8b:	jae    201257 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6fd7>
  1fcd91:	mov    0x20(%rsp),%rax
  1fcd96:	add    %rdi,%rax
  1fcd99:	cmp    %rbx,%rax
  1fcd9c:	jae    201244 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6fc4>
  1fcda2:	add    %rdx,%rdi
  1fcda5:	cmp    %rbx,%rdi
  1fcda8:	jae    201234 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6fb4>
  1fcdae:	shl    $0x4,%rcx
  1fcdb2:	shl    $0x4,%rax
  1fcdb6:	movupd 0x0(%rbp,%rcx,1),%xmm0
  1fcdbc:	movupd (%r10),%xmm1
  1fcdc1:	movapd %xmm0,%xmm2
  1fcdc5:	mulpd  %xmm1,%xmm2
  1fcdc9:	shl    $0x4,%rdi
  1fcdcd:	movupd 0x0(%rbp,%rax,1),%xmm3
  1fcdd3:	movapd %xmm2,%xmm4
  1fcdd7:	unpcklpd %xmm2,%xmm4
  1fcddb:	unpckhpd %xmm2,%xmm2
  1fcddf:	subpd  %xmm2,%xmm4
  1fcde3:	mulpd  %xmm3,%xmm4
  1fcde7:	movapd %xmm1,%xmm2
  1fcdeb:	unpckhpd %xmm1,%xmm2
  1fcdef:	mulsd  %xmm0,%xmm2
  1fcdf3:	unpckhpd %xmm0,%xmm0
  1fcdf7:	mulsd  %xmm1,%xmm0
  1fcdfb:	addsd  %xmm2,%xmm0
  1fcdff:	unpcklpd %xmm0,%xmm0
  1fce03:	shufpd $0x1,%xmm3,%xmm3
  1fce08:	mulpd  %xmm0,%xmm3
  1fce0c:	movapd %xmm4,%xmm0
  1fce10:	subpd  %xmm3,%xmm0
  1fce14:	addpd  %xmm4,%xmm3
  1fce18:	movsd  %xmm0,%xmm3
  1fce1c:	movupd %xmm3,0x0(%rbp,%rdi,1)
  1fce22:	add    $0x8,%rsi
  1fce26:	cmp    %rsi,%r14
  1fce29:	jne    1fcd80 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2b00>
  1fce2f:	xor    %eax,%eax
  1fce31:	mov    0x38(%rsp),%r13
  1fce36:	cs nopw 0x0(%rax,%rax,1)
  1fce40:	mov    (%r9,%rax,1),%rdi
  1fce44:	cmp    %r11,%rdi
  1fce47:	jae    20126a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6fea>
  1fce4d:	movq   $0x3b,(%r8,%rdi,8)
  1fce55:	add    $0x8,%rax
  1fce59:	cmp    %rax,%r14
  1fce5c:	jne    1fce40 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2bc0>
  1fce5e:	xor    %eax,%eax
  1fce60:	xor    %r14d,%r14d
  1fce63:	jmp    1fce80 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2c00>
  1fce65:	data16 cs nopw 0x0(%rax,%rax,1)
  1fce70:	mov    %rdi,(%r9,%r14,8)
  1fce74:	inc    %r14
  1fce77:	add    $0x8,%rax
  1fce7b:	cmp    %rax,%r15
  1fce7e:	je     1fcead <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2c2d>
  1fce80:	mov    0x0(%r13,%rax,1),%rdi
  1fce85:	cmp    %r11,%rdi
  1fce88:	jae    200819 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6599>
  1fce8e:	cmpq   $0x39,(%r8,%rdi,8)
  1fce93:	jae    1fce77 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2bf7>
  1fce95:	cmp    %r12,%r14
  1fce98:	jb     1fce70 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2bf0>
  1fce9a:	lea    0x242eed7(%rip),%rdx        # 262bd78 <__gmpfr_one+0x145f8>
  1fcea1:	mov    %r14,%rdi
  1fcea4:	mov    %r12,%rsi
  1fcea7:	call   *0x24d2053(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fcead:	cmp    %r12,%r14
  1fceb0:	ja     2005c1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6341>
  1fceb6:	test   %r14,%r14
  1fceb9:	je     1fd2a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3020>
  1fcebf:	shl    $0x3,%r14
  1fcec3:	imul   $0x3d,0x8(%rsp),%rax
  1fcec9:	mov    %rax,0x20(%rsp)
  1fcece:	xor    %r15d,%r15d
  1fced1:	movapd 0x1f99127(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fced9:	xorpd  %xmm7,%xmm7
  1fcedd:	movsd  0x1f9a7ca(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fcee6:	movsd  0x1f9a7c9(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fceef:	movsd  0x1f9a7d0(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fcef8:	movapd 0x1f9910f(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fcf01:	movsd  0x1f9a7b6(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fcf0a:	movabs $0x7fffffffffffffff,%r8
  1fcf14:	movabs $0x7ff0000000000000,%r11
  1fcf1e:	xchg   %ax,%ax
  1fcf20:	mov    (%r9,%r15,1),%r13
  1fcf24:	cmp    %rbx,%r13
  1fcf27:	jae    200ae5 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6865>
  1fcf2d:	mov    %r13,%rdi
  1fcf30:	shl    $0x4,%rdi
  1fcf34:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fcf3a:	movapd %xmm0,%xmm2
  1fcf3e:	andpd  %xmm6,%xmm2
  1fcf42:	movapd %xmm0,%xmm1
  1fcf46:	unpckhpd %xmm0,%xmm1
  1fcf4a:	movapd %xmm1,%xmm3
  1fcf4e:	andpd  %xmm6,%xmm3
  1fcf52:	ucomisd %xmm7,%xmm0
  1fcf56:	je     1fcfd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2d50>
  1fcf58:	ucomisd %xmm7,%xmm1
  1fcf5c:	je     1fcfd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2d50>
  1fcf5e:	movapd %xmm2,%xmm4
  1fcf62:	cmplesd %xmm3,%xmm4
  1fcf67:	movapd %xmm4,%xmm5
  1fcf6b:	andpd  %xmm3,%xmm5
  1fcf6f:	andnpd %xmm2,%xmm4
  1fcf73:	orpd   %xmm5,%xmm4
  1fcf77:	ucomisd %xmm8,%xmm4
  1fcf7c:	jbe    1fcfd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2d50>
  1fcf7e:	ucomisd %xmm4,%xmm9
  1fcf83:	jbe    1fcfd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2d50>
  1fcf85:	movapd %xmm0,%xmm2
  1fcf89:	mulpd  %xmm0,%xmm2
  1fcf8d:	movapd %xmm2,%xmm3
  1fcf91:	unpckhpd %xmm2,%xmm3
  1fcf95:	addsd  %xmm2,%xmm3
  1fcf99:	movapd %xmm10,%xmm2
  1fcf9e:	divsd  %xmm3,%xmm2
  1fcfa2:	mulsd  %xmm2,%xmm0
  1fcfa6:	xorpd  %xmm11,%xmm1
  1fcfab:	mulsd  %xmm2,%xmm1
  1fcfaf:	add    0x20(%rsp),%r13
  1fcfb4:	cmp    %rbx,%r13
  1fcfb7:	jb     1fd100 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2e80>
  1fcfbd:	jmp    1fd1a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2f20>
  1fcfc2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fcfd0:	ucomisd %xmm7,%xmm1
  1fcfd4:	setnp  %al
  1fcfd7:	sete   %cl
  1fcfda:	and    %al,%cl
  1fcfdc:	movq   %xmm0,%rax
  1fcfe1:	and    %r8,%rax
  1fcfe4:	cmp    %r11,%rax
  1fcfe7:	setl   %dl
  1fcfea:	test   %dl,%cl
  1fcfec:	je     1fd020 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2da0>
  1fcfee:	movapd %xmm10,%xmm2
  1fcff3:	divsd  %xmm0,%xmm2
  1fcff7:	xorpd  %xmm11,%xmm1
  1fcffc:	movapd %xmm2,%xmm0
  1fd000:	add    0x20(%rsp),%r13
  1fd005:	cmp    %rbx,%r13
  1fd008:	jb     1fd100 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2e80>
  1fd00e:	jmp    1fd1a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2f20>
  1fd013:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fd020:	ucomisd %xmm7,%xmm0
  1fd024:	setnp  %cl
  1fd027:	sete   %dl
  1fd02a:	and    %cl,%dl
  1fd02c:	movq   %xmm1,%rcx
  1fd031:	and    %r8,%rcx
  1fd034:	cmp    %r11,%rcx
  1fd037:	setl   %sil
  1fd03b:	test   %sil,%dl
  1fd03e:	je     1fd060 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2de0>
  1fd040:	movapd %xmm12,%xmm2
  1fd045:	divsd  %xmm1,%xmm2
  1fd049:	movapd %xmm2,%xmm1
  1fd04d:	add    0x20(%rsp),%r13
  1fd052:	cmp    %rbx,%r13
  1fd055:	jb     1fd100 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2e80>
  1fd05b:	jmp    1fd1a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2f20>
  1fd060:	movabs $0x7fefffffffffffff,%rdx
  1fd06a:	cmp    %rdx,%rax
  1fd06d:	setg   %al
  1fd070:	cmp    %rdx,%rcx
  1fd073:	setg   %cl
  1fd076:	or     %al,%cl
  1fd078:	cmp    $0x1,%cl
  1fd07b:	jne    1fd124 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2ea4>
  1fd081:	add    %rbp,%rdi
  1fd084:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1fd089:	movsd  0x1f9a62e(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fd092:	movapd 0x1f98f75(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fd09b:	movsd  0x1f9a624(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fd0a4:	movsd  0x1f9a60b(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fd0ad:	movsd  0x1f9a5fa(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fd0b6:	xorpd  %xmm7,%xmm7
  1fd0ba:	movapd 0x1f98f3e(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fd0c2:	movabs $0x7ff0000000000000,%r11
  1fd0cc:	movabs $0x7fffffffffffffff,%r8
  1fd0d6:	mov    0x110(%rsp),%r10
  1fd0de:	mov    0x10(%rsp),%r9
  1fd0e3:	add    0x20(%rsp),%r13
  1fd0e8:	cmp    %rbx,%r13
  1fd0eb:	jae    1fd1a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2f20>
  1fd0f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fd100:	shl    $0x4,%r13
  1fd104:	movsd  %xmm0,0x0(%rbp,%r13,1)
  1fd10b:	movsd  %xmm1,0x8(%rbp,%r13,1)
  1fd112:	add    $0x8,%r15
  1fd116:	cmp    %r15,%r14
  1fd119:	jne    1fcf20 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2ca0>
  1fd11f:	jmp    1fd1b3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2f33>
  1fd124:	ucomisd %xmm7,%xmm1
  1fd128:	jne    1fd130 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2eb0>
  1fd12a:	jnp    1fcfee <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2d6e>
  1fd130:	ucomisd %xmm7,%xmm0
  1fd134:	jne    1fd13c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2ebc>
  1fd136:	jnp    1fd040 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2dc0>
  1fd13c:	movapd %xmm3,%xmm1
  1fd140:	cmplesd %xmm2,%xmm1
  1fd145:	movapd %xmm1,%xmm4
  1fd149:	andpd  %xmm2,%xmm4
  1fd14d:	andnpd %xmm3,%xmm1
  1fd151:	orpd   %xmm4,%xmm1
  1fd155:	unpcklpd %xmm1,%xmm1
  1fd159:	divpd  %xmm1,%xmm0
  1fd15d:	movapd %xmm0,%xmm2
  1fd161:	xorpd  %xmm11,%xmm2
  1fd166:	movsd  %xmm0,%xmm2
  1fd16a:	mulpd  %xmm0,%xmm0
  1fd16e:	movapd %xmm0,%xmm3
  1fd172:	unpcklpd %xmm0,%xmm3
  1fd176:	unpckhpd %xmm0,%xmm0
  1fd17a:	addpd  %xmm3,%xmm0
  1fd17e:	divpd  %xmm0,%xmm2
  1fd182:	divpd  %xmm1,%xmm2
  1fd186:	movapd %xmm2,%xmm0
  1fd18a:	movapd %xmm2,%xmm1
  1fd18e:	unpckhpd %xmm2,%xmm1
  1fd192:	add    0x20(%rsp),%r13
  1fd197:	cmp    %rbx,%r13
  1fd19a:	jb     1fd100 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2e80>
  1fd1a0:	lea    0x242ec01(%rip),%rdx        # 262bda8 <__gmpfr_one+0x14628>
  1fd1a7:	mov    %r13,%rdi
  1fd1aa:	mov    %rbx,%rsi
  1fd1ad:	call   *0x24d1d4d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fd1b3:	cmpq   $0x5,0x118(%rsp)
  1fd1bc:	jb     201a5c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x77dc>
  1fd1c2:	mov    0x8(%rsp),%rsi
  1fd1c7:	imul   $0x2a,%rsi,%rdx
  1fd1cb:	lea    (%rsi,%rsi,1),%rax
  1fd1cf:	shl    $0x6,%rsi
  1fd1d3:	sub    %rax,%rsi
  1fd1d6:	xor    %r8d,%r8d
  1fd1d9:	mov    0x108(%rsp),%r11
  1fd1e1:	mov    0x30(%rsp),%r15
  1fd1e6:	cs nopw 0x0(%rax,%rax,1)
  1fd1f0:	mov    (%r9,%r8,1),%rdi
  1fd1f4:	lea    (%rdi,%rdx,1),%rax
  1fd1f8:	cmp    %rbx,%rax
  1fd1fb:	jae    200b1b <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x689b>
  1fd201:	mov    0x20(%rsp),%rcx
  1fd206:	add    %rdi,%rcx
  1fd209:	cmp    %rbx,%rcx
  1fd20c:	jae    200b08 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6888>
  1fd212:	add    %rsi,%rdi
  1fd215:	cmp    %rbx,%rdi
  1fd218:	jae    200af8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6878>
  1fd21e:	shl    $0x4,%rax
  1fd222:	shl    $0x4,%rcx
  1fd226:	movupd 0x40(%r10),%xmm0
  1fd22c:	movupd 0x0(%rbp,%rax,1),%xmm1
  1fd232:	movapd %xmm0,%xmm2
  1fd236:	mulpd  %xmm1,%xmm2
  1fd23a:	shl    $0x4,%rdi
  1fd23e:	movupd 0x0(%rbp,%rcx,1),%xmm3
  1fd244:	movapd %xmm2,%xmm4
  1fd248:	unpcklpd %xmm2,%xmm4
  1fd24c:	unpckhpd %xmm2,%xmm2
  1fd250:	subpd  %xmm2,%xmm4
  1fd254:	mulpd  %xmm3,%xmm4
  1fd258:	movapd %xmm0,%xmm2
  1fd25c:	unpckhpd %xmm0,%xmm2
  1fd260:	mulsd  %xmm1,%xmm2
  1fd264:	unpckhpd %xmm1,%xmm1
  1fd268:	mulsd  %xmm0,%xmm1
  1fd26c:	addsd  %xmm2,%xmm1
  1fd270:	unpcklpd %xmm1,%xmm1
  1fd274:	shufpd $0x1,%xmm3,%xmm3
  1fd279:	mulpd  %xmm1,%xmm3
  1fd27d:	movapd %xmm4,%xmm0
  1fd281:	subpd  %xmm3,%xmm0
  1fd285:	addpd  %xmm4,%xmm3
  1fd289:	movsd  %xmm0,%xmm3
  1fd28d:	movupd %xmm3,0x0(%rbp,%rdi,1)
  1fd293:	add    $0x8,%r8
  1fd297:	cmp    %r8,%r14
  1fd29a:	jne    1fd1f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x2f70>
  1fd2a0:	xor    %eax,%eax
  1fd2a2:	xor    %esi,%esi
  1fd2a4:	mov    0x38(%rsp),%rcx
  1fd2a9:	mov    0x100(%rsp),%r8
  1fd2b1:	jmp    1fd2d0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3050>
  1fd2b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fd2c0:	mov    %rdi,(%r9,%rsi,8)
  1fd2c4:	inc    %rsi
  1fd2c7:	add    $0x8,%rax
  1fd2cb:	cmp    %rax,%r15
  1fd2ce:	je     1fd2fc <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x307c>
  1fd2d0:	mov    (%rcx,%rax,1),%rdi
  1fd2d4:	cmp    %r11,%rdi
  1fd2d7:	jae    200829 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x65a9>
  1fd2dd:	cmpq   $0x3c,(%r8,%rdi,8)
  1fd2e2:	jae    1fd2c7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3047>
  1fd2e4:	cmp    %r12,%rsi
  1fd2e7:	jb     1fd2c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3040>
  1fd2e9:	lea    0x242eb30(%rip),%rdx        # 262be20 <__gmpfr_one+0x146a0>
  1fd2f0:	mov    %rsi,%rdi
  1fd2f3:	mov    %r12,%rsi
  1fd2f6:	call   *0x24d1c04(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fd2fc:	cmp    %r12,%rsi
  1fd2ff:	ja     2005d6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6356>
  1fd305:	test   %rsi,%rsi
  1fd308:	je     1fd7de <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x355e>
  1fd30e:	mov    %rsi,0x40(%rsp)
  1fd313:	lea    0x0(,%rsi,8),%rax
  1fd31b:	mov    %rax,0x20(%rsp)
  1fd320:	imul   $0x37,0x8(%rsp),%r14
  1fd326:	xor    %r15d,%r15d
  1fd329:	xorpd  %xmm1,%xmm1
  1fd32d:	jmp    1fd362 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x30e2>
  1fd32f:	nop
  1fd330:	mov    $0x40,%r8d
  1fd336:	mov    %rbp,%rdi
  1fd339:	mov    %rbx,%rsi
  1fd33c:	mov    0x8(%rsp),%rdx
  1fd341:	call   1fa170 <oneloop::native::batch::copy_active_column::<f64>>
  1fd346:	add    $0x8,%r15
  1fd34a:	cmp    %r15,0x20(%rsp)
  1fd34f:	mov    0x10(%rsp),%r9
  1fd354:	mov    0x110(%rsp),%r10
  1fd35c:	xorpd  %xmm1,%xmm1
  1fd360:	je     1fd3a3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3123>
  1fd362:	mov    (%r9,%r15,1),%rcx
  1fd366:	lea    (%rcx,%r14,1),%rdi
  1fd36a:	cmp    %rbx,%rdi
  1fd36d:	jae    200b2e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x68ae>
  1fd373:	shl    $0x4,%rdi
  1fd377:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1fd37d:	mov    $0x3a,%r9d
  1fd383:	ucomisd %xmm1,%xmm0
  1fd387:	jne    1fd330 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x30b0>
  1fd389:	jp     1fd330 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x30b0>
  1fd38b:	add    %rbp,%rdi
  1fd38e:	movsd  0x8(%rdi),%xmm0
  1fd393:	ucomisd %xmm1,%xmm0
  1fd397:	jne    1fd330 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x30b0>
  1fd399:	jp     1fd330 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x30b0>
  1fd39b:	mov    $0x3e,%r9d
  1fd3a1:	jmp    1fd330 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x30b0>
  1fd3a3:	mov    0x8(%rsp),%rax
  1fd3a8:	mov    %rax,%rsi
  1fd3ab:	shl    $0x6,%rsi
  1fd3af:	add    %rsi,%rax
  1fd3b2:	mov    %rax,0x18(%rsp)
  1fd3b7:	xor    %r15d,%r15d
  1fd3ba:	movapd 0x1f98c3e(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fd3c2:	xorpd  %xmm7,%xmm7
  1fd3c6:	movsd  0x1f9a2e1(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fd3cf:	movsd  0x1f9a2e0(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fd3d8:	movsd  0x1f9a2e7(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fd3e1:	movapd 0x1f98c26(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fd3ea:	movsd  0x1f9a2cd(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fd3f3:	movabs $0x7fffffffffffffff,%r8
  1fd3fd:	movabs $0x7ff0000000000000,%r11
  1fd407:	nopw   0x0(%rax,%rax,1)
  1fd410:	mov    (%r9,%r15,1),%r14
  1fd414:	lea    (%r14,%rsi,1),%rdi
  1fd418:	cmp    %rbx,%rdi
  1fd41b:	jae    200b51 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x68d1>
  1fd421:	shl    $0x4,%rdi
  1fd425:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fd42b:	movapd %xmm0,%xmm2
  1fd42f:	andpd  %xmm6,%xmm2
  1fd433:	movapd %xmm0,%xmm1
  1fd437:	unpckhpd %xmm0,%xmm1
  1fd43b:	movapd %xmm1,%xmm3
  1fd43f:	andpd  %xmm6,%xmm3
  1fd443:	ucomisd %xmm7,%xmm0
  1fd447:	je     1fd4b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3230>
  1fd449:	ucomisd %xmm7,%xmm1
  1fd44d:	je     1fd4b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3230>
  1fd44f:	movapd %xmm2,%xmm4
  1fd453:	cmplesd %xmm3,%xmm4
  1fd458:	movapd %xmm4,%xmm5
  1fd45c:	andpd  %xmm3,%xmm5
  1fd460:	andnpd %xmm2,%xmm4
  1fd464:	orpd   %xmm5,%xmm4
  1fd468:	ucomisd %xmm8,%xmm4
  1fd46d:	jbe    1fd4b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3230>
  1fd46f:	ucomisd %xmm4,%xmm9
  1fd474:	jbe    1fd4b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3230>
  1fd476:	movapd %xmm0,%xmm2
  1fd47a:	mulpd  %xmm0,%xmm2
  1fd47e:	movapd %xmm2,%xmm3
  1fd482:	unpckhpd %xmm2,%xmm3
  1fd486:	addsd  %xmm2,%xmm3
  1fd48a:	movapd %xmm10,%xmm2
  1fd48f:	divsd  %xmm3,%xmm2
  1fd493:	mulsd  %xmm2,%xmm0
  1fd497:	xorpd  %xmm11,%xmm1
  1fd49c:	mulsd  %xmm2,%xmm1
  1fd4a0:	jmp    1fd5b1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3331>
  1fd4a5:	data16 cs nopw 0x0(%rax,%rax,1)
  1fd4b0:	ucomisd %xmm7,%xmm1
  1fd4b4:	setnp  %al
  1fd4b7:	sete   %cl
  1fd4ba:	and    %al,%cl
  1fd4bc:	movq   %xmm0,%rax
  1fd4c1:	and    %r8,%rax
  1fd4c4:	cmp    %r11,%rax
  1fd4c7:	setl   %dl
  1fd4ca:	test   %dl,%cl
  1fd4cc:	je     1fd4f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3270>
  1fd4ce:	movapd %xmm10,%xmm2
  1fd4d3:	divsd  %xmm0,%xmm2
  1fd4d7:	xorpd  %xmm11,%xmm1
  1fd4dc:	movapd %xmm2,%xmm0
  1fd4e0:	jmp    1fd5b1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3331>
  1fd4e5:	data16 cs nopw 0x0(%rax,%rax,1)
  1fd4f0:	mov    %r12,%r13
  1fd4f3:	mov    %rsi,%r12
  1fd4f6:	ucomisd %xmm7,%xmm0
  1fd4fa:	setnp  %cl
  1fd4fd:	sete   %dl
  1fd500:	and    %cl,%dl
  1fd502:	movq   %xmm1,%rcx
  1fd507:	and    %r8,%rcx
  1fd50a:	cmp    %r11,%rcx
  1fd50d:	setl   %sil
  1fd511:	test   %sil,%dl
  1fd514:	je     1fd528 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x32a8>
  1fd516:	movapd %xmm12,%xmm2
  1fd51b:	divsd  %xmm1,%xmm2
  1fd51f:	movapd %xmm2,%xmm1
  1fd523:	jmp    1fd5ab <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x332b>
  1fd528:	movabs $0x7fefffffffffffff,%rdx
  1fd532:	cmp    %rdx,%rax
  1fd535:	setg   %al
  1fd538:	cmp    %rdx,%rcx
  1fd53b:	setg   %cl
  1fd53e:	or     %al,%cl
  1fd540:	cmp    $0x1,%cl
  1fd543:	jne    1fd5e5 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3365>
  1fd549:	add    %rbp,%rdi
  1fd54c:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1fd551:	movsd  0x1f9a166(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fd55a:	movapd 0x1f98aad(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fd563:	movsd  0x1f9a15c(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fd56c:	movsd  0x1f9a143(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fd575:	movsd  0x1f9a132(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fd57e:	xorpd  %xmm7,%xmm7
  1fd582:	movapd 0x1f98a76(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fd58a:	movabs $0x7ff0000000000000,%r11
  1fd594:	movabs $0x7fffffffffffffff,%r8
  1fd59e:	mov    0x110(%rsp),%r10
  1fd5a6:	mov    0x10(%rsp),%r9
  1fd5ab:	mov    %r12,%rsi
  1fd5ae:	mov    %r13,%r12
  1fd5b1:	add    0x18(%rsp),%r14
  1fd5b6:	cmp    %rbx,%r14
  1fd5b9:	jae    200b3e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x68be>
  1fd5bf:	shl    $0x4,%r14
  1fd5c3:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fd5ca:	movsd  %xmm1,0x8(%rbp,%r14,1)
  1fd5d1:	add    $0x8,%r15
  1fd5d5:	cmp    %r15,0x20(%rsp)
  1fd5da:	jne    1fd410 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3190>
  1fd5e0:	jmp    1fd679 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x33f9>
  1fd5e5:	ucomisd %xmm7,%xmm1
  1fd5e9:	mov    %r12,%rsi
  1fd5ec:	jne    1fd604 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3384>
  1fd5ee:	jp     1fd604 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3384>
  1fd5f0:	movapd %xmm10,%xmm2
  1fd5f5:	divsd  %xmm0,%xmm2
  1fd5f9:	xorpd  %xmm11,%xmm1
  1fd5fe:	movapd %xmm2,%xmm0
  1fd602:	jmp    1fd5ae <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x332e>
  1fd604:	ucomisd %xmm7,%xmm0
  1fd608:	mov    %r13,%r12
  1fd60b:	jne    1fd61e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x339e>
  1fd60d:	jp     1fd61e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x339e>
  1fd60f:	movapd %xmm12,%xmm2
  1fd614:	divsd  %xmm1,%xmm2
  1fd618:	movapd %xmm2,%xmm1
  1fd61c:	jmp    1fd5b1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3331>
  1fd61e:	movapd %xmm3,%xmm1
  1fd622:	cmplesd %xmm2,%xmm1
  1fd627:	movapd %xmm1,%xmm4
  1fd62b:	andpd  %xmm2,%xmm4
  1fd62f:	andnpd %xmm3,%xmm1
  1fd633:	orpd   %xmm4,%xmm1
  1fd637:	unpcklpd %xmm1,%xmm1
  1fd63b:	divpd  %xmm1,%xmm0
  1fd63f:	movapd %xmm0,%xmm2
  1fd643:	xorpd  %xmm11,%xmm2
  1fd648:	movsd  %xmm0,%xmm2
  1fd64c:	mulpd  %xmm0,%xmm0
  1fd650:	movapd %xmm0,%xmm3
  1fd654:	unpcklpd %xmm0,%xmm3
  1fd658:	unpckhpd %xmm0,%xmm0
  1fd65c:	addpd  %xmm3,%xmm0
  1fd660:	divpd  %xmm0,%xmm2
  1fd664:	divpd  %xmm1,%xmm2
  1fd668:	movapd %xmm2,%xmm0
  1fd66c:	movapd %xmm2,%xmm1
  1fd670:	unpckhpd %xmm2,%xmm1
  1fd674:	jmp    1fd5b1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3331>
  1fd679:	mov    0x8(%rsp),%rax
  1fd67e:	mov    %rsi,%rcx
  1fd681:	imul   $0x27,%rax,%rsi
  1fd685:	lea    (%rcx,%rax,2),%rdx
  1fd689:	xor    %r8d,%r8d
  1fd68c:	mov    0x108(%rsp),%r11
  1fd694:	mov    0x30(%rsp),%r15
  1fd699:	mov    0x40(%rsp),%r14
  1fd69e:	xchg   %ax,%ax
  1fd6a0:	mov    (%r9,%r8,1),%rdi
  1fd6a4:	lea    (%rdi,%rsi,1),%rax
  1fd6a8:	cmp    %rbx,%rax
  1fd6ab:	jae    200b84 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6904>
  1fd6b1:	mov    0x18(%rsp),%rcx
  1fd6b6:	add    %rdi,%rcx
  1fd6b9:	cmp    %rbx,%rcx
  1fd6bc:	jae    200b71 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x68f1>
  1fd6c2:	add    %rdx,%rdi
  1fd6c5:	cmp    %rbx,%rdi
  1fd6c8:	jae    200b61 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x68e1>
  1fd6ce:	shl    $0x4,%rax
  1fd6d2:	shl    $0x4,%rcx
  1fd6d6:	shl    $0x4,%rdi
  1fd6da:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fd6e0:	movsd  0x0(%rbp,%rcx,1),%xmm1
  1fd6e6:	movsd  0x8(%rbp,%rcx,1),%xmm2
  1fd6ec:	unpcklpd %xmm1,%xmm1
  1fd6f0:	mulpd  %xmm0,%xmm1
  1fd6f4:	shufpd $0x1,%xmm0,%xmm0
  1fd6f9:	unpcklpd %xmm2,%xmm2
  1fd6fd:	mulpd  %xmm0,%xmm2
  1fd701:	movapd %xmm1,%xmm0
  1fd705:	subpd  %xmm2,%xmm0
  1fd709:	addpd  %xmm1,%xmm2
  1fd70d:	movsd  %xmm0,%xmm2
  1fd711:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fd717:	add    $0x8,%r8
  1fd71b:	cmp    %r8,0x20(%rsp)
  1fd720:	jne    1fd6a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3420>
  1fd726:	xor    %ecx,%ecx
  1fd728:	xorpd  %xmm0,%xmm0
  1fd72c:	xor    %esi,%esi
  1fd72e:	mov    0x100(%rsp),%r8
  1fd736:	jmp    1fd758 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x34d8>
  1fd738:	nopl   0x0(%rax,%rax,1)
  1fd740:	cmp    %r12,%rsi
  1fd743:	jae    201509 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7289>
  1fd749:	mov    %rdi,(%r9,%rsi,8)
  1fd74d:	inc    %rsi
  1fd750:	inc    %rcx
  1fd753:	cmp    %rcx,%r14
  1fd756:	je     1fd7a4 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3524>
  1fd758:	mov    (%r9,%rcx,8),%rdi
  1fd75c:	lea    (%rdi,%rdx,1),%rax
  1fd760:	cmp    %rbx,%rax
  1fd763:	jae    200b97 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6917>
  1fd769:	shl    $0x4,%rax
  1fd76d:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fd773:	ucomisd %xmm0,%xmm1
  1fd777:	jne    1fd740 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x34c0>
  1fd779:	jp     1fd740 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x34c0>
  1fd77b:	add    %rbp,%rax
  1fd77e:	movsd  0x8(%rax),%xmm1
  1fd783:	ucomisd %xmm0,%xmm1
  1fd787:	jne    1fd740 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x34c0>
  1fd789:	jp     1fd740 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x34c0>
  1fd78b:	cmp    %r11,%rdi
  1fd78e:	jae    2018be <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x763e>
  1fd794:	movq   $0x41,(%r8,%rdi,8)
  1fd79c:	inc    %rcx
  1fd79f:	cmp    %rcx,%r14
  1fd7a2:	jne    1fd758 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x34d8>
  1fd7a4:	cmp    %r12,%rsi
  1fd7a7:	ja     2006ef <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x646f>
  1fd7ad:	test   %rsi,%rsi
  1fd7b0:	je     1fd7de <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x355e>
  1fd7b2:	shl    $0x3,%rsi
  1fd7b6:	xor    %eax,%eax
  1fd7b8:	nopl   0x0(%rax,%rax,1)
  1fd7c0:	mov    (%r9,%rax,1),%rdi
  1fd7c4:	cmp    %r11,%rdi
  1fd7c7:	jae    20127a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6ffa>
  1fd7cd:	movq   $0x42,(%r8,%rdi,8)
  1fd7d5:	add    $0x8,%rax
  1fd7d9:	cmp    %rax,%rsi
  1fd7dc:	jne    1fd7c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3540>
  1fd7de:	xor    %ecx,%ecx
  1fd7e0:	xor    %edi,%edi
  1fd7e2:	mov    0x38(%rsp),%rsi
  1fd7e7:	jmp    1fd800 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3580>
  1fd7e9:	nopl   0x0(%rax)
  1fd7f0:	mov    %rax,(%r9,%rdi,8)
  1fd7f4:	inc    %rdi
  1fd7f7:	add    $0x8,%rcx
  1fd7fb:	cmp    %rcx,%r15
  1fd7fe:	je     1fd829 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x35a9>
  1fd800:	mov    (%rsi,%rcx,1),%rax
  1fd804:	cmp    %r11,%rax
  1fd807:	jae    200839 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x65b9>
  1fd80d:	cmpq   $0x42,(%r8,%rax,8)
  1fd812:	jae    1fd7f7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3577>
  1fd814:	cmp    %r12,%rdi
  1fd817:	jb     1fd7f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3570>
  1fd819:	lea    0x242e6d8(%rip),%rdx        # 262bef8 <__gmpfr_one+0x14778>
  1fd820:	mov    %r12,%rsi
  1fd823:	call   *0x24d16d7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fd829:	xor    %eax,%eax
  1fd82b:	xor    %r14d,%r14d
  1fd82e:	jmp    1fd840 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x35c0>
  1fd830:	mov    %rdi,(%r9,%r14,8)
  1fd834:	inc    %r14
  1fd837:	add    $0x8,%rax
  1fd83b:	cmp    %rax,%r15
  1fd83e:	je     1fd86c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x35ec>
  1fd840:	mov    (%rsi,%rax,1),%rdi
  1fd844:	cmp    %r11,%rdi
  1fd847:	jae    20084c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x65cc>
  1fd84d:	cmpq   $0x43,(%r8,%rdi,8)
  1fd852:	jae    1fd837 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x35b7>
  1fd854:	cmp    %r12,%r14
  1fd857:	jb     1fd830 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x35b0>
  1fd859:	lea    0x242e6c8(%rip),%rdx        # 262bf28 <__gmpfr_one+0x147a8>
  1fd860:	mov    %r14,%rdi
  1fd863:	mov    %r12,%rsi
  1fd866:	call   *0x24d1694(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fd86c:	cmp    %r12,%r14
  1fd86f:	ja     2005e8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6368>
  1fd875:	test   %r14,%r14
  1fd878:	je     1fdc3e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x39be>
  1fd87e:	lea    0x0(,%r14,8),%r13
  1fd886:	mov    0x8(%rsp),%rcx
  1fd88b:	mov    %rcx,%rax
  1fd88e:	shl    $0x6,%rax
  1fd892:	lea    (%rax,%rcx,2),%r12
  1fd896:	imul   $0x47,%rcx,%rax
  1fd89a:	mov    %rax,0x20(%rsp)
  1fd89f:	xor    %r15d,%r15d
  1fd8a2:	xorpd  %xmm1,%xmm1
  1fd8a6:	jmp    1fd8e6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3666>
  1fd8a8:	nopl   0x0(%rax,%rax,1)
  1fd8b0:	mov    $0x47,%r8d
  1fd8b6:	mov    $0x42,%r9d
  1fd8bc:	mov    %rbp,%rdi
  1fd8bf:	mov    %rbx,%rsi
  1fd8c2:	mov    0x8(%rsp),%rdx
  1fd8c7:	call   1fa170 <oneloop::native::batch::copy_active_column::<f64>>
  1fd8cc:	xorpd  %xmm1,%xmm1
  1fd8d0:	mov    0x110(%rsp),%r10
  1fd8d8:	mov    0x10(%rsp),%r9
  1fd8dd:	add    $0x8,%r15
  1fd8e1:	cmp    %r15,%r13
  1fd8e4:	je     1fd94f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x36cf>
  1fd8e6:	mov    (%r9,%r15,1),%rcx
  1fd8ea:	lea    (%rcx,%r12,1),%rdi
  1fd8ee:	cmp    %rbx,%rdi
  1fd8f1:	jae    200baa <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x692a>
  1fd8f7:	shl    $0x4,%rdi
  1fd8fb:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1fd901:	ucomisd %xmm1,%xmm0
  1fd905:	jne    1fd8b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3630>
  1fd907:	jp     1fd8b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3630>
  1fd909:	add    %rbp,%rdi
  1fd90c:	movsd  0x8(%rdi),%xmm0
  1fd911:	ucomisd %xmm1,%xmm0
  1fd915:	jne    1fd8b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3630>
  1fd917:	jp     1fd8b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3630>
  1fd919:	add    0x20(%rsp),%rcx
  1fd91e:	cmp    %rbx,%rcx
  1fd921:	jae    2018ce <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x764e>
  1fd927:	cmpq   $0x3,0x118(%rsp)
  1fd930:	jbe    20103d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6dbd>
  1fd936:	shl    $0x4,%rcx
  1fd93a:	movupd 0x30(%r10),%xmm0
  1fd940:	movupd %xmm0,0x0(%rbp,%rcx,1)
  1fd946:	add    $0x8,%r15
  1fd94a:	cmp    %r15,%r13
  1fd94d:	jne    1fd8e6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3666>
  1fd94f:	mov    0x8(%rsp),%rax
  1fd954:	lea    0x0(,%rax,8),%rax
  1fd95c:	lea    (%rax,%rax,8),%rcx
  1fd960:	xor    %edx,%edx
  1fd962:	movabs $0x8000000000000000,%rsi
  1fd96c:	mov    0xf0(%rsp),%r12
  1fd974:	mov    0x108(%rsp),%r11
  1fd97c:	mov    0x30(%rsp),%r15
  1fd981:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fd990:	mov    (%r9,%rdx,1),%rdi
  1fd994:	mov    0x20(%rsp),%rax
  1fd999:	add    %rdi,%rax
  1fd99c:	cmp    %rbx,%rax
  1fd99f:	jae    200bca <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x694a>
  1fd9a5:	add    %rcx,%rdi
  1fd9a8:	cmp    %rbx,%rdi
  1fd9ab:	jae    200bba <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x693a>
  1fd9b1:	shl    $0x4,%rax
  1fd9b5:	movsd  0x0(%rbp,%rax,1),%xmm0
  1fd9bb:	shl    $0x4,%rdi
  1fd9bf:	mov    0x8(%rbp,%rax,1),%rax
  1fd9c4:	xor    %rsi,%rax
  1fd9c7:	movsd  %xmm0,0x0(%rbp,%rdi,1)
  1fd9cd:	mov    %rax,0x8(%rbp,%rdi,1)
  1fd9d2:	add    $0x8,%rdx
  1fd9d6:	cmp    %rdx,%r13
  1fd9d9:	jne    1fd990 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3710>
  1fd9db:	cmpq   $0x2,0x118(%rsp)
  1fd9e4:	jb     201a42 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x77c2>
  1fd9ea:	mov    0x8(%rsp),%rdx
  1fd9ef:	lea    (%rdx,%rdx,8),%rax
  1fd9f3:	lea    (%rdx,%rax,8),%rsi
  1fd9f7:	xor    %edx,%edx
  1fd9f9:	nopl   0x0(%rax)
  1fda00:	mov    (%r9,%rdx,1),%rdi
  1fda04:	lea    (%rdi,%rcx,1),%rax
  1fda08:	cmp    %rbx,%rax
  1fda0b:	jae    200bed <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x696d>
  1fda11:	add    %rsi,%rdi
  1fda14:	cmp    %rbx,%rdi
  1fda17:	jae    200bdd <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x695d>
  1fda1d:	shl    $0x4,%rax
  1fda21:	shl    $0x4,%rdi
  1fda25:	movupd 0x10(%r10),%xmm0
  1fda2b:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fda31:	movsd  0x8(%rbp,%rax,1),%xmm2
  1fda37:	unpcklpd %xmm1,%xmm1
  1fda3b:	mulpd  %xmm0,%xmm1
  1fda3f:	shufpd $0x1,%xmm0,%xmm0
  1fda44:	unpcklpd %xmm2,%xmm2
  1fda48:	mulpd  %xmm0,%xmm2
  1fda4c:	movapd %xmm1,%xmm0
  1fda50:	subpd  %xmm2,%xmm0
  1fda54:	addpd  %xmm1,%xmm2
  1fda58:	movsd  %xmm0,%xmm2
  1fda5c:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fda62:	add    $0x8,%rdx
  1fda66:	cmp    %rdx,%r13
  1fda69:	jne    1fda00 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3780>
  1fda6b:	imul   $0x4a,0x8(%rsp),%rdx
  1fda71:	xor    %r8d,%r8d
  1fda74:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fda80:	mov    (%r9,%r8,1),%rdi
  1fda84:	mov    0x20(%rsp),%rax
  1fda89:	add    %rdi,%rax
  1fda8c:	cmp    %rbx,%rax
  1fda8f:	jae    200c23 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x69a3>
  1fda95:	lea    (%rdi,%rsi,1),%rcx
  1fda99:	cmp    %rbx,%rcx
  1fda9c:	jae    200c10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6990>
  1fdaa2:	add    %rdx,%rdi
  1fdaa5:	cmp    %rbx,%rdi
  1fdaa8:	jae    200c00 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6980>
  1fdaae:	shl    $0x4,%rax
  1fdab2:	shl    $0x4,%rcx
  1fdab6:	shl    $0x4,%rdi
  1fdaba:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fdac0:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fdac6:	addpd  %xmm0,%xmm1
  1fdaca:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fdad0:	add    $0x8,%r8
  1fdad4:	cmp    %r8,%r13
  1fdad7:	jne    1fda80 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3800>
  1fdad9:	xor    %ecx,%ecx
  1fdadb:	xorpd  %xmm0,%xmm0
  1fdadf:	xor    %r13d,%r13d
  1fdae2:	mov    0x38(%rsp),%rsi
  1fdae7:	mov    0x100(%rsp),%r8
  1fdaef:	jmp    1fdb18 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3898>
  1fdaf1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fdb00:	cmp    %r12,%r13
  1fdb03:	jae    20151c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x729c>
  1fdb09:	mov    %rdi,(%r9,%r13,8)
  1fdb0d:	inc    %r13
  1fdb10:	inc    %rcx
  1fdb13:	cmp    %rcx,%r14
  1fdb16:	je     1fdb64 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x38e4>
  1fdb18:	mov    (%r9,%rcx,8),%rdi
  1fdb1c:	lea    (%rdi,%rdx,1),%rax
  1fdb20:	cmp    %rbx,%rax
  1fdb23:	jae    200c36 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x69b6>
  1fdb29:	shl    $0x4,%rax
  1fdb2d:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fdb33:	ucomisd %xmm0,%xmm1
  1fdb37:	jne    1fdb00 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3880>
  1fdb39:	jp     1fdb00 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3880>
  1fdb3b:	add    %rbp,%rax
  1fdb3e:	movsd  0x8(%rax),%xmm1
  1fdb43:	ucomisd %xmm0,%xmm1
  1fdb47:	jne    1fdb00 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3880>
  1fdb49:	jp     1fdb00 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3880>
  1fdb4b:	cmp    %r11,%rdi
  1fdb4e:	jae    2018e1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7661>
  1fdb54:	movq   $0x4a,(%r8,%rdi,8)
  1fdb5c:	inc    %rcx
  1fdb5f:	cmp    %rcx,%r14
  1fdb62:	jne    1fdb18 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3898>
  1fdb64:	cmp    %r12,%r13
  1fdb67:	ja     200701 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6481>
  1fdb6d:	test   %r13,%r13
  1fdb70:	je     1fdc3e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x39be>
  1fdb76:	shl    $0x3,%r13
  1fdb7a:	imul   $0x4c,0x8(%rsp),%r15
  1fdb80:	xor    %r12d,%r12d
  1fdb83:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fdb90:	mov    (%r9,%r12,1),%r14
  1fdb94:	mov    0x20(%rsp),%rax
  1fdb99:	lea    (%r14,%rax,1),%rdi
  1fdb9d:	cmp    %rbx,%rdi
  1fdba0:	jae    20129d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x701d>
  1fdba6:	shl    $0x4,%rdi
  1fdbaa:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1fdbb0:	movsd  0x8(%rbp,%rdi,1),%xmm1
  1fdbb6:	call   1f9e60 <oneloop::native::primitives::log::<f64>>
  1fdbbb:	add    %r15,%r14
  1fdbbe:	cmp    %rbx,%r14
  1fdbc1:	jae    20128a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x700a>
  1fdbc7:	shl    $0x4,%r14
  1fdbcb:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fdbd2:	movsd  %xmm1,0x8(%rbp,%r14,1)
  1fdbd9:	add    $0x8,%r12
  1fdbdd:	cmp    %r12,%r13
  1fdbe0:	mov    0x10(%rsp),%r9
  1fdbe5:	mov    0x110(%rsp),%r10
  1fdbed:	mov    0x38(%rsp),%rsi
  1fdbf2:	mov    0x100(%rsp),%r8
  1fdbfa:	jne    1fdb90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3910>
  1fdbfc:	xor    %eax,%eax
  1fdbfe:	mov    0xf0(%rsp),%r12
  1fdc06:	mov    0x108(%rsp),%r11
  1fdc0e:	mov    0x30(%rsp),%r15
  1fdc13:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fdc20:	mov    (%r9,%rax,1),%rdi
  1fdc24:	cmp    %r11,%rdi
  1fdc27:	jae    2012ad <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x702d>
  1fdc2d:	movq   $0x59,(%r8,%rdi,8)
  1fdc35:	add    $0x8,%rax
  1fdc39:	cmp    %rax,%r13
  1fdc3c:	jne    1fdc20 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x39a0>
  1fdc3e:	xor    %eax,%eax
  1fdc40:	xor    %r14d,%r14d
  1fdc43:	mov    0x8(%rsp),%rcx
  1fdc48:	jmp    1fdc59 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x39d9>
  1fdc4a:	nopw   0x0(%rax,%rax,1)
  1fdc50:	add    $0x8,%rax
  1fdc54:	cmp    %rax,%r15
  1fdc57:	je     1fdc7f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x39ff>
  1fdc59:	mov    (%rsi,%rax,1),%rdi
  1fdc5d:	cmp    %r11,%rdi
  1fdc60:	jae    20085c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x65dc>
  1fdc66:	cmpq   $0x4b,(%r8,%rdi,8)
  1fdc6b:	jae    1fdc50 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x39d0>
  1fdc6d:	cmp    %r12,%r14
  1fdc70:	jae    200fd5 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6d55>
  1fdc76:	mov    %rdi,(%r9,%r14,8)
  1fdc7a:	inc    %r14
  1fdc7d:	jmp    1fdc50 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x39d0>
  1fdc7f:	cmp    %r12,%r14
  1fdc82:	ja     2005fd <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x637d>
  1fdc88:	test   %r14,%r14
  1fdc8b:	je     1fdfce <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3d4e>
  1fdc91:	lea    0x0(,%r14,8),%r15
  1fdc99:	imul   $0x47,%rcx,%r11
  1fdc9d:	imul   $0x4f,%rcx,%r8
  1fdca1:	xor    %r12d,%r12d
  1fdca4:	xorpd  %xmm6,%xmm6
  1fdca8:	movapd 0x1f98350(%rip),%xmm7        # 2196000 <_fini+0x520>
  1fdcb0:	movsd  0x1f999f7(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fdcb9:	mov    %r11,0x20(%rsp)
  1fdcbe:	mov    %r8,0x18(%rsp)
  1fdcc3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fdcd0:	mov    (%r9,%r12,1),%r13
  1fdcd4:	lea    (%r11,%r13,1),%rdi
  1fdcd8:	cmp    %rbx,%rdi
  1fdcdb:	jae    200c5c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x69dc>
  1fdce1:	shl    $0x4,%rdi
  1fdce5:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fdceb:	movapd %xmm0,%xmm1
  1fdcef:	unpckhpd %xmm0,%xmm1
  1fdcf3:	ucomisd %xmm6,%xmm1
  1fdcf7:	jne    1fdd10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3a90>
  1fdcf9:	jp     1fdd10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3a90>
  1fdcfb:	andpd  %xmm7,%xmm0
  1fdcff:	jmp    1fddd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3b50>
  1fdd04:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fdd10:	ucomisd %xmm6,%xmm0
  1fdd14:	jne    1fdd25 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3aa5>
  1fdd16:	jp     1fdd25 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3aa5>
  1fdd18:	andpd  %xmm7,%xmm1
  1fdd1c:	movapd %xmm1,%xmm0
  1fdd20:	jmp    1fddd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3b50>
  1fdd25:	movapd %xmm0,%xmm2
  1fdd29:	andpd  %xmm7,%xmm2
  1fdd2d:	pshufd $0xee,%xmm2,%xmm3
  1fdd32:	movapd %xmm2,%xmm4
  1fdd36:	cmplesd %xmm3,%xmm4
  1fdd3b:	movapd %xmm4,%xmm5
  1fdd3f:	andpd  %xmm3,%xmm5
  1fdd43:	andnpd %xmm2,%xmm4
  1fdd47:	orpd   %xmm5,%xmm4
  1fdd4b:	movapd %xmm0,%xmm2
  1fdd4f:	cmpunordsd %xmm0,%xmm2
  1fdd54:	movapd %xmm2,%xmm5
  1fdd58:	andnpd %xmm4,%xmm5
  1fdd5c:	andpd  %xmm3,%xmm2
  1fdd60:	orpd   %xmm5,%xmm2
  1fdd64:	ucomisd %xmm8,%xmm2
  1fdd69:	jbe    1fdd92 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3b12>
  1fdd6b:	movsd  0x1f99945(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fdd73:	ucomisd %xmm2,%xmm3
  1fdd77:	jbe    1fdd92 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3b12>
  1fdd79:	mulpd  %xmm0,%xmm0
  1fdd7d:	movapd %xmm0,%xmm1
  1fdd81:	unpckhpd %xmm0,%xmm1
  1fdd85:	addsd  %xmm0,%xmm1
  1fdd89:	xorps  %xmm0,%xmm0
  1fdd8c:	sqrtsd %xmm1,%xmm0
  1fdd90:	jmp    1fddd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3b50>
  1fdd92:	call   *0x24cde38(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1fdd98:	movsd  0x1f9990f(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fdda1:	movapd 0x1f98257(%rip),%xmm7        # 2196000 <_fini+0x520>
  1fdda9:	xorpd  %xmm6,%xmm6
  1fddad:	mov    0x18(%rsp),%r8
  1fddb2:	mov    0x20(%rsp),%r11
  1fddb7:	mov    0x110(%rsp),%r10
  1fddbf:	mov    0x10(%rsp),%r9
  1fddc4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fddd0:	add    %r8,%r13
  1fddd3:	cmp    %rbx,%r13
  1fddd6:	jae    200c49 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x69c9>
  1fdddc:	shl    $0x4,%r13
  1fdde0:	movsd  %xmm0,0x0(%rbp,%r13,1)
  1fdde7:	movq   $0x0,0x8(%rbp,%r13,1)
  1fddf0:	add    $0x8,%r12
  1fddf4:	cmp    %r12,%r15
  1fddf7:	jne    1fdcd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3a50>
  1fddfd:	cmpq   $0x2,0x118(%rsp)
  1fde06:	jb     201a42 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x77c2>
  1fde0c:	mov    0x8(%rsp),%rdx
  1fde11:	mov    %rdx,%rax
  1fde14:	shl    $0x4,%rax
  1fde18:	lea    (%rax,%rax,4),%rsi
  1fde1c:	xor    %ecx,%ecx
  1fde1e:	mov    0xf0(%rsp),%r12
  1fde26:	cs nopw 0x0(%rax,%rax,1)
  1fde30:	mov    (%r9,%rcx,1),%rdi
  1fde34:	lea    (%rdi,%r8,1),%rax
  1fde38:	cmp    %rbx,%rax
  1fde3b:	jae    200c7c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x69fc>
  1fde41:	add    %rsi,%rdi
  1fde44:	cmp    %rbx,%rdi
  1fde47:	jae    200c6c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x69ec>
  1fde4d:	shl    $0x4,%rax
  1fde51:	shl    $0x4,%rdi
  1fde55:	movupd 0x10(%r10),%xmm0
  1fde5b:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fde61:	movsd  0x8(%rbp,%rax,1),%xmm2
  1fde67:	unpcklpd %xmm1,%xmm1
  1fde6b:	mulpd  %xmm0,%xmm1
  1fde6f:	shufpd $0x1,%xmm0,%xmm0
  1fde74:	unpcklpd %xmm2,%xmm2
  1fde78:	mulpd  %xmm0,%xmm2
  1fde7c:	movapd %xmm1,%xmm0
  1fde80:	subpd  %xmm2,%xmm0
  1fde84:	addpd  %xmm1,%xmm2
  1fde88:	movsd  %xmm0,%xmm2
  1fde8c:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fde92:	add    $0x8,%rcx
  1fde96:	cmp    %rcx,%r15
  1fde99:	jne    1fde30 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3bb0>
  1fde9b:	lea    (%rdx,%rdx,8),%rax
  1fde9f:	lea    (%rax,%rax,8),%rdx
  1fdea3:	xor    %r8d,%r8d
  1fdea6:	cs nopw 0x0(%rax,%rax,1)
  1fdeb0:	mov    (%r9,%r8,1),%rdi
  1fdeb4:	lea    (%rdi,%r11,1),%rax
  1fdeb8:	cmp    %rbx,%rax
  1fdebb:	jae    200cb2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6a32>
  1fdec1:	lea    (%rdi,%rsi,1),%rcx
  1fdec5:	cmp    %rbx,%rcx
  1fdec8:	jae    200c9f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6a1f>
  1fdece:	add    %rdx,%rdi
  1fded1:	cmp    %rbx,%rdi
  1fded4:	jae    200c8f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6a0f>
  1fdeda:	shl    $0x4,%rax
  1fdede:	shl    $0x4,%rcx
  1fdee2:	shl    $0x4,%rdi
  1fdee6:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fdeec:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fdef2:	addpd  %xmm0,%xmm1
  1fdef6:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fdefc:	add    $0x8,%r8
  1fdf00:	cmp    %r8,%r15
  1fdf03:	jne    1fdeb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3c30>
  1fdf05:	xor    %ecx,%ecx
  1fdf07:	xorpd  %xmm0,%xmm0
  1fdf0b:	xor    %esi,%esi
  1fdf0d:	mov    0x108(%rsp),%r11
  1fdf15:	mov    0x30(%rsp),%r15
  1fdf1a:	mov    0x100(%rsp),%r8
  1fdf22:	jmp    1fdf49 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3cc9>
  1fdf24:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fdf30:	cmp    %r11,%rdi
  1fdf33:	jae    2018f1 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7671>
  1fdf39:	movq   $0x50,(%r8,%rdi,8)
  1fdf41:	inc    %rcx
  1fdf44:	cmp    %rcx,%r14
  1fdf47:	je     1fdf94 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3d14>
  1fdf49:	mov    (%r9,%rcx,8),%rdi
  1fdf4d:	lea    (%rdi,%rdx,1),%rax
  1fdf51:	cmp    %rbx,%rax
  1fdf54:	jae    200cc5 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6a45>
  1fdf5a:	shl    $0x4,%rax
  1fdf5e:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fdf64:	ucomisd %xmm0,%xmm1
  1fdf68:	jne    1fdf7c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3cfc>
  1fdf6a:	jp     1fdf7c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3cfc>
  1fdf6c:	add    %rbp,%rax
  1fdf6f:	movsd  0x8(%rax),%xmm1
  1fdf74:	ucomisd %xmm0,%xmm1
  1fdf78:	jne    1fdf7c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3cfc>
  1fdf7a:	jnp    1fdf30 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3cb0>
  1fdf7c:	cmp    %r12,%rsi
  1fdf7f:	jae    20152f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x72af>
  1fdf85:	mov    %rdi,(%r9,%rsi,8)
  1fdf89:	inc    %rsi
  1fdf8c:	inc    %rcx
  1fdf8f:	cmp    %rcx,%r14
  1fdf92:	jne    1fdf49 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3cc9>
  1fdf94:	cmp    %r12,%rsi
  1fdf97:	ja     200716 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6496>
  1fdf9d:	test   %rsi,%rsi
  1fdfa0:	je     1fdfce <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3d4e>
  1fdfa2:	shl    $0x3,%rsi
  1fdfa6:	xor    %eax,%eax
  1fdfa8:	nopl   0x0(%rax,%rax,1)
  1fdfb0:	mov    (%r9,%rax,1),%rdi
  1fdfb4:	cmp    %r11,%rdi
  1fdfb7:	jae    2012bd <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x703d>
  1fdfbd:	movq   $0x51,(%r8,%rdi,8)
  1fdfc5:	add    $0x8,%rax
  1fdfc9:	cmp    %rax,%rsi
  1fdfcc:	jne    1fdfb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3d30>
  1fdfce:	xor    %ecx,%ecx
  1fdfd0:	xor    %edi,%edi
  1fdfd2:	mov    0x38(%rsp),%rdx
  1fdfd7:	jmp    1fdff0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3d70>
  1fdfd9:	nopl   0x0(%rax)
  1fdfe0:	mov    %rax,(%r9,%rdi,8)
  1fdfe4:	inc    %rdi
  1fdfe7:	add    $0x8,%rcx
  1fdfeb:	cmp    %rcx,%r15
  1fdfee:	je     1fe019 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3d99>
  1fdff0:	mov    (%rdx,%rcx,1),%rax
  1fdff4:	cmp    %r11,%rax
  1fdff7:	jae    20086c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x65ec>
  1fdffd:	cmpq   $0x51,(%r8,%rax,8)
  1fe002:	jae    1fdfe7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3d67>
  1fe004:	cmp    %r12,%rdi
  1fe007:	jb     1fdfe0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3d60>
  1fe009:	lea    0x242e158(%rip),%rdx        # 262c168 <__gmpfr_one+0x149e8>
  1fe010:	mov    %r12,%rsi
  1fe013:	call   *0x24d0ee7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fe019:	xor    %eax,%eax
  1fe01b:	xor    %r13d,%r13d
  1fe01e:	jmp    1fe029 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3da9>
  1fe020:	add    $0x8,%rax
  1fe024:	cmp    %rax,%r15
  1fe027:	je     1fe04f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3dcf>
  1fe029:	mov    (%rdx,%rax,1),%rdi
  1fe02d:	cmp    %r11,%rdi
  1fe030:	jae    20087f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x65ff>
  1fe036:	cmpq   $0x52,(%r8,%rdi,8)
  1fe03b:	jae    1fe020 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3da0>
  1fe03d:	cmp    %r12,%r13
  1fe040:	jae    200fe8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6d68>
  1fe046:	mov    %rdi,(%r9,%r13,8)
  1fe04a:	inc    %r13
  1fe04d:	jmp    1fe020 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3da0>
  1fe04f:	cmp    %r12,%r13
  1fe052:	ja     200612 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6392>
  1fe058:	test   %r13,%r13
  1fe05b:	je     1fe459 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x41d9>
  1fe061:	shl    $0x3,%r13
  1fe065:	mov    0x8(%rsp),%rdx
  1fe06a:	lea    (%rdx,%rdx,8),%rax
  1fe06e:	lea    (%rax,%rax,8),%rcx
  1fe072:	imul   $0x56,%rdx,%r11
  1fe076:	xor    %edx,%edx
  1fe078:	xorpd  %xmm0,%xmm0
  1fe07c:	mov    0x118(%rsp),%rsi
  1fe084:	jmp    1fe0a9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3e29>
  1fe086:	cs nopw 0x0(%rax,%rax,1)
  1fe090:	shl    $0x4,%rdi
  1fe094:	movupd 0x50(%r10),%xmm1
  1fe09a:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fe0a0:	add    $0x8,%rdx
  1fe0a4:	cmp    %rdx,%r13
  1fe0a7:	je     1fe128 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3ea8>
  1fe0a9:	mov    (%r9,%rdx,1),%rdi
  1fe0ad:	lea    (%rdi,%rcx,1),%rax
  1fe0b1:	cmp    %rbx,%rax
  1fe0b4:	jae    200cd8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6a58>
  1fe0ba:	shl    $0x4,%rax
  1fe0be:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fe0c4:	ucomisd %xmm0,%xmm1
  1fe0c8:	jne    1fe100 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3e80>
  1fe0ca:	jp     1fe100 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3e80>
  1fe0cc:	add    %rbp,%rax
  1fe0cf:	movsd  0x8(%rax),%xmm1
  1fe0d4:	ucomisd %xmm0,%xmm1
  1fe0d8:	jne    1fe100 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3e80>
  1fe0da:	jp     1fe100 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3e80>
  1fe0dc:	add    %r11,%rdi
  1fe0df:	cmp    %rbx,%rdi
  1fe0e2:	jae    201913 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7693>
  1fe0e8:	cmp    $0x3,%rsi
  1fe0ec:	jbe    201901 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7681>
  1fe0f2:	shl    $0x4,%rdi
  1fe0f6:	movupd 0x30(%r10),%xmm1
  1fe0fc:	jmp    1fe09a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3e1a>
  1fe0fe:	xchg   %ax,%ax
  1fe100:	add    %r11,%rdi
  1fe103:	cmp    %rbx,%rdi
  1fe106:	jae    201542 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x72c2>
  1fe10c:	cmp    $0x5,%rsi
  1fe110:	ja     1fe090 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3e10>
  1fe116:	lea    0x242d223(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  1fe11d:	mov    $0x5,%edi
  1fe122:	call   *0x24d0dd8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fe128:	cmp    $0x7,%rsi
  1fe12c:	jb     201a90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7810>
  1fe132:	imul   $0x57,0x8(%rsp),%rcx
  1fe138:	xor    %edx,%edx
  1fe13a:	nopw   0x0(%rax,%rax,1)
  1fe140:	mov    (%r9,%rdx,1),%rdi
  1fe144:	lea    (%rdi,%r11,1),%rax
  1fe148:	cmp    %rbx,%rax
  1fe14b:	jae    200cfb <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6a7b>
  1fe151:	add    %rcx,%rdi
  1fe154:	cmp    %rbx,%rdi
  1fe157:	jae    200ceb <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6a6b>
  1fe15d:	shl    $0x4,%rax
  1fe161:	shl    $0x4,%rdi
  1fe165:	movupd 0x60(%r10),%xmm0
  1fe16b:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fe171:	movsd  0x8(%rbp,%rax,1),%xmm2
  1fe177:	unpcklpd %xmm1,%xmm1
  1fe17b:	mulpd  %xmm0,%xmm1
  1fe17f:	shufpd $0x1,%xmm0,%xmm0
  1fe184:	unpcklpd %xmm2,%xmm2
  1fe188:	mulpd  %xmm0,%xmm2
  1fe18c:	movapd %xmm1,%xmm0
  1fe190:	subpd  %xmm2,%xmm0
  1fe194:	addpd  %xmm1,%xmm2
  1fe198:	movsd  %xmm0,%xmm2
  1fe19c:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fe1a2:	add    $0x8,%rdx
  1fe1a6:	cmp    %rdx,%r13
  1fe1a9:	jne    1fe140 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3ec0>
  1fe1ab:	imul   $0x58,0x8(%rsp),%rdx
  1fe1b1:	xor    %esi,%esi
  1fe1b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fe1c0:	mov    (%r9,%rsi,1),%rdi
  1fe1c4:	lea    (%rdi,%rcx,1),%rax
  1fe1c8:	cmp    %rbx,%rax
  1fe1cb:	jae    200d31 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6ab1>
  1fe1d1:	add    %rdx,%rdi
  1fe1d4:	cmp    %rbx,%rdi
  1fe1d7:	jae    200d21 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6aa1>
  1fe1dd:	shl    $0x4,%rax
  1fe1e1:	shl    $0x4,%rdi
  1fe1e5:	movupd 0x50(%r10),%xmm0
  1fe1eb:	movupd 0x0(%rbp,%rax,1),%xmm1
  1fe1f1:	addpd  %xmm0,%xmm1
  1fe1f5:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fe1fb:	add    $0x8,%rsi
  1fe1ff:	cmp    %rsi,%r13
  1fe202:	jne    1fe1c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3f40>
  1fe204:	mov    0x8(%rsp),%rax
  1fe209:	imul   $0x47,%rax,%rsi
  1fe20d:	imul   $0x59,%rax,%r12
  1fe211:	xor    %r8d,%r8d
  1fe214:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fe220:	mov    (%r9,%r8,1),%rdi
  1fe224:	lea    (%rdi,%rsi,1),%rax
  1fe228:	cmp    %rbx,%rax
  1fe22b:	jae    200d67 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6ae7>
  1fe231:	lea    (%rdi,%rdx,1),%rcx
  1fe235:	cmp    %rbx,%rcx
  1fe238:	jae    200d54 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6ad4>
  1fe23e:	add    %r12,%rdi
  1fe241:	cmp    %rbx,%rdi
  1fe244:	jae    200d44 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6ac4>
  1fe24a:	shl    $0x4,%rax
  1fe24e:	shl    $0x4,%rcx
  1fe252:	shl    $0x4,%rdi
  1fe256:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fe25c:	movsd  0x0(%rbp,%rcx,1),%xmm1
  1fe262:	movsd  0x8(%rbp,%rcx,1),%xmm2
  1fe268:	unpcklpd %xmm1,%xmm1
  1fe26c:	mulpd  %xmm0,%xmm1
  1fe270:	shufpd $0x1,%xmm0,%xmm0
  1fe275:	unpcklpd %xmm2,%xmm2
  1fe279:	mulpd  %xmm0,%xmm2
  1fe27d:	movapd %xmm1,%xmm0
  1fe281:	subpd  %xmm2,%xmm0
  1fe285:	addpd  %xmm1,%xmm2
  1fe289:	movsd  %xmm0,%xmm2
  1fe28d:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fe293:	add    $0x8,%r8
  1fe297:	cmp    %r8,%r13
  1fe29a:	jne    1fe220 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x3fa0>
  1fe29c:	mov    %r11,0x18(%rsp)
  1fe2a1:	imul   $0x5a,0x8(%rsp),%rax
  1fe2a7:	mov    %rax,0x20(%rsp)
  1fe2ac:	xor    %r15d,%r15d
  1fe2af:	nop
  1fe2b0:	mov    (%r9,%r15,1),%r14
  1fe2b4:	lea    (%r14,%r12,1),%rdi
  1fe2b8:	cmp    %rbx,%rdi
  1fe2bb:	jae    200d8d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6b0d>
  1fe2c1:	shl    $0x4,%rdi
  1fe2c5:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1fe2cb:	movsd  0x8(%rbp,%rdi,1),%xmm1
  1fe2d1:	call   1f9e60 <oneloop::native::primitives::log::<f64>>
  1fe2d6:	add    0x20(%rsp),%r14
  1fe2db:	cmp    %rbx,%r14
  1fe2de:	jae    200d7a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6afa>
  1fe2e4:	shl    $0x4,%r14
  1fe2e8:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fe2ef:	movsd  %xmm1,0x8(%rbp,%r14,1)
  1fe2f6:	add    $0x8,%r15
  1fe2fa:	cmp    %r15,%r13
  1fe2fd:	mov    0x10(%rsp),%r9
  1fe302:	mov    0x110(%rsp),%r10
  1fe30a:	jne    1fe2b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4030>
  1fe30c:	mov    0x118(%rsp),%rax
  1fe314:	cmp    $0x7,%rax
  1fe318:	je     201aa2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7822>
  1fe31e:	cmp    $0x8,%rax
  1fe322:	mov    0xf0(%rsp),%r12
  1fe32a:	mov    0x108(%rsp),%r11
  1fe332:	mov    0x30(%rsp),%r15
  1fe337:	mov    0x18(%rsp),%rsi
  1fe33c:	je     201ab9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7839>
  1fe342:	imul   $0x5b,0x8(%rsp),%rdx
  1fe348:	xor    %ecx,%ecx
  1fe34a:	nopw   0x0(%rax,%rax,1)
  1fe350:	mov    (%r9,%rcx,1),%rdi
  1fe354:	lea    (%rdi,%rsi,1),%rax
  1fe358:	cmp    %rbx,%rax
  1fe35b:	jae    200dad <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6b2d>
  1fe361:	add    %rdx,%rdi
  1fe364:	cmp    %rbx,%rdi
  1fe367:	jae    200d9d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6b1d>
  1fe36d:	shl    $0x4,%rax
  1fe371:	movupd 0x70(%r10),%xmm0
  1fe377:	movupd 0x80(%r10),%xmm1
  1fe380:	movapd %xmm0,%xmm2
  1fe384:	mulpd  %xmm1,%xmm2
  1fe388:	shl    $0x4,%rdi
  1fe38c:	movupd 0x0(%rbp,%rax,1),%xmm3
  1fe392:	movapd %xmm2,%xmm4
  1fe396:	unpcklpd %xmm2,%xmm4
  1fe39a:	unpckhpd %xmm2,%xmm2
  1fe39e:	subpd  %xmm2,%xmm4
  1fe3a2:	mulpd  %xmm3,%xmm4
  1fe3a6:	movapd %xmm1,%xmm2
  1fe3aa:	unpckhpd %xmm1,%xmm2
  1fe3ae:	mulsd  %xmm0,%xmm2
  1fe3b2:	unpckhpd %xmm0,%xmm0
  1fe3b6:	mulsd  %xmm1,%xmm0
  1fe3ba:	addsd  %xmm2,%xmm0
  1fe3be:	unpcklpd %xmm0,%xmm0
  1fe3c2:	shufpd $0x1,%xmm3,%xmm3
  1fe3c7:	mulpd  %xmm0,%xmm3
  1fe3cb:	movapd %xmm4,%xmm0
  1fe3cf:	subpd  %xmm3,%xmm0
  1fe3d3:	addpd  %xmm4,%xmm3
  1fe3d7:	movsd  %xmm0,%xmm3
  1fe3db:	movupd %xmm3,0x0(%rbp,%rdi,1)
  1fe3e1:	add    $0x8,%rcx
  1fe3e5:	cmp    %rcx,%r13
  1fe3e8:	jne    1fe350 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x40d0>
  1fe3ee:	imul   $0x5c,0x8(%rsp),%rsi
  1fe3f4:	xor    %r8d,%r8d
  1fe3f7:	nopw   0x0(%rax,%rax,1)
  1fe400:	mov    (%r9,%r8,1),%rdi
  1fe404:	mov    0x20(%rsp),%rax
  1fe409:	add    %rdi,%rax
  1fe40c:	cmp    %rbx,%rax
  1fe40f:	jae    200de3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6b63>
  1fe415:	lea    (%rdi,%rdx,1),%rcx
  1fe419:	cmp    %rbx,%rcx
  1fe41c:	jae    200dd0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6b50>
  1fe422:	add    %rsi,%rdi
  1fe425:	cmp    %rbx,%rdi
  1fe428:	jae    200dc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6b40>
  1fe42e:	shl    $0x4,%rax
  1fe432:	shl    $0x4,%rcx
  1fe436:	shl    $0x4,%rdi
  1fe43a:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fe440:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1fe446:	addpd  %xmm0,%xmm1
  1fe44a:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1fe450:	add    $0x8,%r8
  1fe454:	cmp    %r8,%r13
  1fe457:	jne    1fe400 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4180>
  1fe459:	xor    %eax,%eax
  1fe45b:	xor    %r14d,%r14d
  1fe45e:	mov    0x8(%rsp),%r13
  1fe463:	mov    0x38(%rsp),%rsi
  1fe468:	mov    0x100(%rsp),%r8
  1fe470:	jmp    1fe490 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4210>
  1fe472:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fe480:	mov    %rdi,(%r9,%r14,8)
  1fe484:	inc    %r14
  1fe487:	add    $0x8,%rax
  1fe48b:	cmp    %rax,%r15
  1fe48e:	je     1fe4bc <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x423c>
  1fe490:	mov    (%rsi,%rax,1),%rdi
  1fe494:	cmp    %r11,%rdi
  1fe497:	jae    20088f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x660f>
  1fe49d:	cmpq   $0x5a,(%r8,%rdi,8)
  1fe4a2:	jae    1fe487 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4207>
  1fe4a4:	cmp    %r12,%r14
  1fe4a7:	jb     1fe480 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4200>
  1fe4a9:	lea    0x242deb0(%rip),%rdx        # 262c360 <__gmpfr_one+0x14be0>
  1fe4b0:	mov    %r14,%rdi
  1fe4b3:	mov    %r12,%rsi
  1fe4b6:	call   *0x24d0a44(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fe4bc:	cmp    %r12,%r14
  1fe4bf:	ja     200627 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x63a7>
  1fe4c5:	test   %r14,%r14
  1fe4c8:	je     1fe62e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x43ae>
  1fe4ce:	shl    $0x3,%r14
  1fe4d2:	imul   $0x4a,%r13,%r15
  1fe4d6:	xor    %r12d,%r12d
  1fe4d9:	xorpd  %xmm1,%xmm1
  1fe4dd:	jmp    1fe506 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4286>
  1fe4df:	nop
  1fe4e0:	mov    $0x5e,%r8d
  1fe4e6:	mov    %rbp,%rdi
  1fe4e9:	mov    %rbx,%rsi
  1fe4ec:	mov    %r13,%rdx
  1fe4ef:	call   1fa170 <oneloop::native::batch::copy_active_column::<f64>>
  1fe4f4:	add    $0x8,%r12
  1fe4f8:	cmp    %r12,%r14
  1fe4fb:	mov    0x10(%rsp),%r9
  1fe500:	xorpd  %xmm1,%xmm1
  1fe504:	je     1fe547 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x42c7>
  1fe506:	mov    (%r9,%r12,1),%rcx
  1fe50a:	lea    (%rcx,%r15,1),%rdi
  1fe50e:	cmp    %rbx,%rdi
  1fe511:	jae    200df6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6b76>
  1fe517:	shl    $0x4,%rdi
  1fe51b:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1fe521:	mov    $0x4c,%r9d
  1fe527:	ucomisd %xmm1,%xmm0
  1fe52b:	jne    1fe4e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4260>
  1fe52d:	jp     1fe4e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4260>
  1fe52f:	add    %rbp,%rdi
  1fe532:	movsd  0x8(%rdi),%xmm0
  1fe537:	ucomisd %xmm1,%xmm0
  1fe53b:	jne    1fe4e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4260>
  1fe53d:	jp     1fe4e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4260>
  1fe53f:	mov    $0x5c,%r9d
  1fe545:	jmp    1fe4e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4260>
  1fe547:	imul   $0x27,%r13,%rdx
  1fe54b:	imul   $0x5e,%r13,%rsi
  1fe54f:	imul   $0x5f,%r13,%r8
  1fe553:	xor    %r10d,%r10d
  1fe556:	mov    0xf0(%rsp),%r12
  1fe55e:	mov    0x108(%rsp),%r11
  1fe566:	mov    0x30(%rsp),%r15
  1fe56b:	nopl   0x0(%rax,%rax,1)
  1fe570:	mov    (%r9,%r10,1),%rdi
  1fe574:	lea    (%rdi,%rdx,1),%rax
  1fe578:	cmp    %rbx,%rax
  1fe57b:	jae    200e29 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6ba9>
  1fe581:	lea    (%rdi,%rsi,1),%rcx
  1fe585:	cmp    %rbx,%rcx
  1fe588:	jae    200e16 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6b96>
  1fe58e:	add    %r8,%rdi
  1fe591:	cmp    %rbx,%rdi
  1fe594:	jae    200e06 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6b86>
  1fe59a:	shl    $0x4,%rax
  1fe59e:	shl    $0x4,%rcx
  1fe5a2:	shl    $0x4,%rdi
  1fe5a6:	movupd 0x0(%rbp,%rax,1),%xmm0
  1fe5ac:	movsd  0x0(%rbp,%rcx,1),%xmm1
  1fe5b2:	movsd  0x8(%rbp,%rcx,1),%xmm2
  1fe5b8:	unpcklpd %xmm1,%xmm1
  1fe5bc:	mulpd  %xmm0,%xmm1
  1fe5c0:	shufpd $0x1,%xmm0,%xmm0
  1fe5c5:	unpcklpd %xmm2,%xmm2
  1fe5c9:	mulpd  %xmm0,%xmm2
  1fe5cd:	movapd %xmm1,%xmm0
  1fe5d1:	subpd  %xmm2,%xmm0
  1fe5d5:	addpd  %xmm1,%xmm2
  1fe5d9:	movsd  %xmm0,%xmm2
  1fe5dd:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1fe5e3:	add    $0x8,%r10
  1fe5e7:	cmp    %r10,%r14
  1fe5ea:	jne    1fe570 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x42f0>
  1fe5ec:	xor    %eax,%eax
  1fe5ee:	mov    0x110(%rsp),%r10
  1fe5f6:	mov    0x38(%rsp),%rsi
  1fe5fb:	mov    0x100(%rsp),%r8
  1fe603:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fe610:	mov    (%r9,%rax,1),%rdi
  1fe614:	cmp    %r11,%rdi
  1fe617:	jae    200e3c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6bbc>
  1fe61d:	movq   $0x5e,(%r8,%rdi,8)
  1fe625:	add    $0x8,%rax
  1fe629:	cmp    %rax,%r14
  1fe62c:	jne    1fe610 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4390>
  1fe62e:	xor    %ecx,%ecx
  1fe630:	xor    %edi,%edi
  1fe632:	jmp    1fe650 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x43d0>
  1fe634:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fe640:	mov    %rax,(%r9,%rdi,8)
  1fe644:	inc    %rdi
  1fe647:	add    $0x8,%rcx
  1fe64b:	cmp    %rcx,%r15
  1fe64e:	je     1fe679 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x43f9>
  1fe650:	mov    (%rsi,%rcx,1),%rax
  1fe654:	cmp    %r11,%rax
  1fe657:	jae    20089f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x661f>
  1fe65d:	cmpq   $0x5e,(%r8,%rax,8)
  1fe662:	jae    1fe647 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x43c7>
  1fe664:	cmp    %r12,%rdi
  1fe667:	jb     1fe640 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x43c0>
  1fe669:	lea    0x242dd98(%rip),%rdx        # 262c408 <__gmpfr_one+0x14c88>
  1fe670:	mov    %r12,%rsi
  1fe673:	call   *0x24d0887(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fe679:	xor    %eax,%eax
  1fe67b:	xor    %r14d,%r14d
  1fe67e:	jmp    1fe690 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4410>
  1fe680:	mov    %rdi,(%r9,%r14,8)
  1fe684:	inc    %r14
  1fe687:	add    $0x8,%rax
  1fe68b:	cmp    %rax,%r15
  1fe68e:	je     1fe6bc <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x443c>
  1fe690:	mov    (%rsi,%rax,1),%rdi
  1fe694:	cmp    %r11,%rdi
  1fe697:	jae    2008b2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6632>
  1fe69d:	cmpq   $0x5f,(%r8,%rdi,8)
  1fe6a2:	jae    1fe687 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4407>
  1fe6a4:	cmp    %r12,%r14
  1fe6a7:	jb     1fe680 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4400>
  1fe6a9:	lea    0x242dd88(%rip),%rdx        # 262c438 <__gmpfr_one+0x14cb8>
  1fe6b0:	mov    %r14,%rdi
  1fe6b3:	mov    %r12,%rsi
  1fe6b6:	call   *0x24d0844(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fe6bc:	cmp    %r12,%r14
  1fe6bf:	ja     20063c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x63bc>
  1fe6c5:	test   %r14,%r14
  1fe6c8:	je     1fec6e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x49ee>
  1fe6ce:	lea    0x0(,%r14,8),%r15
  1fe6d6:	mov    0x8(%rsp),%rax
  1fe6db:	imul   $0x27,%rax,%r12
  1fe6df:	imul   $0x63,%rax,%rax
  1fe6e3:	mov    %rax,0x20(%rsp)
  1fe6e8:	xor    %r13d,%r13d
  1fe6eb:	xorpd  %xmm1,%xmm1
  1fe6ef:	jmp    1fe743 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x44c3>
  1fe6f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fe700:	mov    $0x63,%r8d
  1fe706:	mov    $0x5f,%r9d
  1fe70c:	mov    %rbp,%rdi
  1fe70f:	mov    %rbx,%rsi
  1fe712:	mov    0x8(%rsp),%rdx
  1fe717:	call   1fa170 <oneloop::native::batch::copy_active_column::<f64>>
  1fe71c:	xorpd  %xmm1,%xmm1
  1fe720:	mov    0x100(%rsp),%r8
  1fe728:	mov    0x38(%rsp),%rsi
  1fe72d:	mov    0x110(%rsp),%r10
  1fe735:	mov    0x10(%rsp),%r9
  1fe73a:	add    $0x8,%r13
  1fe73e:	cmp    %r13,%r15
  1fe741:	je     1fe7ac <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x452c>
  1fe743:	mov    (%r9,%r13,1),%rcx
  1fe747:	lea    (%rcx,%r12,1),%rdi
  1fe74b:	cmp    %rbx,%rdi
  1fe74e:	jae    200e4c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6bcc>
  1fe754:	shl    $0x4,%rdi
  1fe758:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1fe75e:	ucomisd %xmm1,%xmm0
  1fe762:	jne    1fe700 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4480>
  1fe764:	jp     1fe700 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4480>
  1fe766:	add    %rbp,%rdi
  1fe769:	movsd  0x8(%rdi),%xmm0
  1fe76e:	ucomisd %xmm1,%xmm0
  1fe772:	jne    1fe700 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4480>
  1fe774:	jp     1fe700 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4480>
  1fe776:	add    0x20(%rsp),%rcx
  1fe77b:	cmp    %rbx,%rcx
  1fe77e:	jae    201936 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x76b6>
  1fe784:	cmpq   $0x3,0x118(%rsp)
  1fe78d:	jbe    20103d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6dbd>
  1fe793:	shl    $0x4,%rcx
  1fe797:	movupd 0x30(%r10),%xmm0
  1fe79d:	movupd %xmm0,0x0(%rbp,%rcx,1)
  1fe7a3:	add    $0x8,%r13
  1fe7a7:	cmp    %r13,%r15
  1fe7aa:	jne    1fe743 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x44c3>
  1fe7ac:	mov    0x8(%rsp),%rcx
  1fe7b1:	lea    (%rcx,%rcx,1),%rax
  1fe7b5:	shl    $0x5,%rcx
  1fe7b9:	sub    %rax,%rcx
  1fe7bc:	xor    %edx,%edx
  1fe7be:	xorpd  %xmm0,%xmm0
  1fe7c2:	xor    %r13d,%r13d
  1fe7c5:	mov    0xf0(%rsp),%r12
  1fe7cd:	mov    0x108(%rsp),%r11
  1fe7d5:	mov    0x30(%rsp),%r15
  1fe7da:	jmp    1fe7f9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4579>
  1fe7dc:	nopl   0x0(%rax)
  1fe7e0:	cmp    %r11,%rdi
  1fe7e3:	jae    201949 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x76c9>
  1fe7e9:	movq   $0x64,(%r8,%rdi,8)
  1fe7f1:	inc    %rdx
  1fe7f4:	cmp    %rdx,%r14
  1fe7f7:	je     1fe844 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x45c4>
  1fe7f9:	mov    (%r9,%rdx,8),%rdi
  1fe7fd:	lea    (%rdi,%rcx,1),%rax
  1fe801:	cmp    %rbx,%rax
  1fe804:	jae    200e5c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6bdc>
  1fe80a:	shl    $0x4,%rax
  1fe80e:	movsd  0x0(%rbp,%rax,1),%xmm1
  1fe814:	ucomisd %xmm0,%xmm1
  1fe818:	jne    1fe82c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x45ac>
  1fe81a:	jp     1fe82c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x45ac>
  1fe81c:	add    %rbp,%rax
  1fe81f:	movsd  0x8(%rax),%xmm1
  1fe824:	ucomisd %xmm0,%xmm1
  1fe828:	jne    1fe82c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x45ac>
  1fe82a:	jnp    1fe7e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4560>
  1fe82c:	cmp    %r12,%r13
  1fe82f:	jae    201552 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x72d2>
  1fe835:	mov    %rdi,(%r9,%r13,8)
  1fe839:	inc    %r13
  1fe83c:	inc    %rdx
  1fe83f:	cmp    %rdx,%r14
  1fe842:	jne    1fe7f9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4579>
  1fe844:	cmp    %r12,%r13
  1fe847:	ja     200728 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x64a8>
  1fe84d:	test   %r13,%r13
  1fe850:	je     1fec6e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x49ee>
  1fe856:	shl    $0x3,%r13
  1fe85a:	imul   $0x65,0x8(%rsp),%rax
  1fe860:	mov    %rax,0x20(%rsp)
  1fe865:	xor    %r15d,%r15d
  1fe868:	movapd 0x1f97790(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fe870:	xorpd  %xmm7,%xmm7
  1fe874:	movsd  0x1f98e33(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fe87d:	movsd  0x1f98e32(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fe886:	movsd  0x1f98e39(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fe88f:	movapd 0x1f97778(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fe898:	movsd  0x1f98e1f(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fe8a1:	movabs $0x7fffffffffffffff,%r8
  1fe8ab:	movabs $0x7ff0000000000000,%r11
  1fe8b5:	data16 cs nopw 0x0(%rax,%rax,1)
  1fe8c0:	mov    (%r9,%r15,1),%r14
  1fe8c4:	cmp    %rbx,%r14
  1fe8c7:	jae    2012f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7070>
  1fe8cd:	mov    %r14,%rdi
  1fe8d0:	shl    $0x4,%rdi
  1fe8d4:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fe8da:	movapd %xmm0,%xmm2
  1fe8de:	andpd  %xmm6,%xmm2
  1fe8e2:	movapd %xmm0,%xmm1
  1fe8e6:	unpckhpd %xmm0,%xmm1
  1fe8ea:	movapd %xmm1,%xmm3
  1fe8ee:	andpd  %xmm6,%xmm3
  1fe8f2:	ucomisd %xmm7,%xmm0
  1fe8f6:	je     1fe970 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x46f0>
  1fe8f8:	ucomisd %xmm7,%xmm1
  1fe8fc:	je     1fe970 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x46f0>
  1fe8fe:	movapd %xmm2,%xmm4
  1fe902:	cmplesd %xmm3,%xmm4
  1fe907:	movapd %xmm4,%xmm5
  1fe90b:	andpd  %xmm3,%xmm5
  1fe90f:	andnpd %xmm2,%xmm4
  1fe913:	orpd   %xmm5,%xmm4
  1fe917:	ucomisd %xmm8,%xmm4
  1fe91c:	jbe    1fe970 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x46f0>
  1fe91e:	ucomisd %xmm4,%xmm9
  1fe923:	jbe    1fe970 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x46f0>
  1fe925:	movapd %xmm0,%xmm2
  1fe929:	mulpd  %xmm0,%xmm2
  1fe92d:	movapd %xmm2,%xmm3
  1fe931:	unpckhpd %xmm2,%xmm3
  1fe935:	addsd  %xmm2,%xmm3
  1fe939:	movapd %xmm10,%xmm2
  1fe93e:	divsd  %xmm3,%xmm2
  1fe942:	mulsd  %xmm2,%xmm0
  1fe946:	xorpd  %xmm11,%xmm1
  1fe94b:	mulsd  %xmm2,%xmm1
  1fe94f:	add    0x20(%rsp),%r14
  1fe954:	cmp    %rbx,%r14
  1fe957:	jb     1feaa0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4820>
  1fe95d:	jmp    1feb40 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x48c0>
  1fe962:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fe970:	ucomisd %xmm7,%xmm1
  1fe974:	setnp  %al
  1fe977:	sete   %cl
  1fe97a:	and    %al,%cl
  1fe97c:	movq   %xmm0,%rax
  1fe981:	and    %r8,%rax
  1fe984:	cmp    %r11,%rax
  1fe987:	setl   %dl
  1fe98a:	test   %dl,%cl
  1fe98c:	je     1fe9c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4740>
  1fe98e:	movapd %xmm10,%xmm2
  1fe993:	divsd  %xmm0,%xmm2
  1fe997:	xorpd  %xmm11,%xmm1
  1fe99c:	movapd %xmm2,%xmm0
  1fe9a0:	add    0x20(%rsp),%r14
  1fe9a5:	cmp    %rbx,%r14
  1fe9a8:	jb     1feaa0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4820>
  1fe9ae:	jmp    1feb40 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x48c0>
  1fe9b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fe9c0:	ucomisd %xmm7,%xmm0
  1fe9c4:	setnp  %cl
  1fe9c7:	sete   %dl
  1fe9ca:	and    %cl,%dl
  1fe9cc:	movq   %xmm1,%rcx
  1fe9d1:	and    %r8,%rcx
  1fe9d4:	cmp    %r11,%rcx
  1fe9d7:	setl   %sil
  1fe9db:	test   %sil,%dl
  1fe9de:	je     1fea00 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4780>
  1fe9e0:	movapd %xmm12,%xmm2
  1fe9e5:	divsd  %xmm1,%xmm2
  1fe9e9:	movapd %xmm2,%xmm1
  1fe9ed:	add    0x20(%rsp),%r14
  1fe9f2:	cmp    %rbx,%r14
  1fe9f5:	jb     1feaa0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4820>
  1fe9fb:	jmp    1feb40 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x48c0>
  1fea00:	movabs $0x7fefffffffffffff,%rdx
  1fea0a:	cmp    %rdx,%rax
  1fea0d:	setg   %al
  1fea10:	cmp    %rdx,%rcx
  1fea13:	setg   %cl
  1fea16:	or     %al,%cl
  1fea18:	cmp    $0x1,%cl
  1fea1b:	jne    1feac4 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4844>
  1fea21:	add    %rbp,%rdi
  1fea24:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1fea29:	movsd  0x1f98c8e(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fea32:	movapd 0x1f975d5(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fea3b:	movsd  0x1f98c84(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fea44:	movsd  0x1f98c6b(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fea4d:	movsd  0x1f98c5a(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1fea56:	xorpd  %xmm7,%xmm7
  1fea5a:	movapd 0x1f9759e(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fea62:	movabs $0x7ff0000000000000,%r11
  1fea6c:	movabs $0x7fffffffffffffff,%r8
  1fea76:	mov    0x110(%rsp),%r10
  1fea7e:	mov    0x10(%rsp),%r9
  1fea83:	add    0x20(%rsp),%r14
  1fea88:	cmp    %rbx,%r14
  1fea8b:	jae    1feb40 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x48c0>
  1fea91:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1feaa0:	shl    $0x4,%r14
  1feaa4:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1feaab:	movsd  %xmm1,0x8(%rbp,%r14,1)
  1feab2:	add    $0x8,%r15
  1feab6:	cmp    %r15,%r13
  1feab9:	jne    1fe8c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4640>
  1feabf:	jmp    1feb53 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x48d3>
  1feac4:	ucomisd %xmm7,%xmm1
  1feac8:	jne    1fead0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4850>
  1feaca:	jnp    1fe98e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x470e>
  1fead0:	ucomisd %xmm7,%xmm0
  1fead4:	jne    1feadc <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x485c>
  1fead6:	jnp    1fe9e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4760>
  1feadc:	movapd %xmm3,%xmm1
  1feae0:	cmplesd %xmm2,%xmm1
  1feae5:	movapd %xmm1,%xmm4
  1feae9:	andpd  %xmm2,%xmm4
  1feaed:	andnpd %xmm3,%xmm1
  1feaf1:	orpd   %xmm4,%xmm1
  1feaf5:	unpcklpd %xmm1,%xmm1
  1feaf9:	divpd  %xmm1,%xmm0
  1feafd:	movapd %xmm0,%xmm2
  1feb01:	xorpd  %xmm11,%xmm2
  1feb06:	movsd  %xmm0,%xmm2
  1feb0a:	mulpd  %xmm0,%xmm0
  1feb0e:	movapd %xmm0,%xmm3
  1feb12:	unpcklpd %xmm0,%xmm3
  1feb16:	unpckhpd %xmm0,%xmm0
  1feb1a:	addpd  %xmm3,%xmm0
  1feb1e:	divpd  %xmm0,%xmm2
  1feb22:	divpd  %xmm1,%xmm2
  1feb26:	movapd %xmm2,%xmm0
  1feb2a:	movapd %xmm2,%xmm1
  1feb2e:	unpckhpd %xmm2,%xmm1
  1feb32:	add    0x20(%rsp),%r14
  1feb37:	cmp    %rbx,%r14
  1feb3a:	jb     1feaa0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4820>
  1feb40:	lea    0x242d951(%rip),%rdx        # 262c498 <__gmpfr_one+0x14d18>
  1feb47:	mov    %r14,%rdi
  1feb4a:	mov    %rbx,%rsi
  1feb4d:	call   *0x24d03ad(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1feb53:	cmpq   $0x5,0x118(%rsp)
  1feb5c:	jb     201a76 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x77f6>
  1feb62:	mov    0x8(%rsp),%rcx
  1feb67:	imul   $0x66,%rcx,%rdx
  1feb6b:	lea    (%rcx,%rcx,8),%rax
  1feb6f:	lea    (%rcx,%rax,2),%rsi
  1feb73:	xor    %r8d,%r8d
  1feb76:	mov    0x108(%rsp),%r11
  1feb7e:	mov    0x30(%rsp),%r15
  1feb83:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1feb90:	mov    (%r9,%r8,1),%rdi
  1feb94:	lea    (%rdi,%rsi,1),%rax
  1feb98:	cmp    %rbx,%rax
  1feb9b:	jae    201326 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x70a6>
  1feba1:	mov    0x20(%rsp),%rcx
  1feba6:	add    %rdi,%rcx
  1feba9:	cmp    %rbx,%rcx
  1febac:	jae    201313 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7093>
  1febb2:	add    %rdx,%rdi
  1febb5:	cmp    %rbx,%rdi
  1febb8:	jae    201303 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7083>
  1febbe:	shl    $0x4,%rax
  1febc2:	shl    $0x4,%rcx
  1febc6:	movupd 0x40(%r10),%xmm0
  1febcc:	movupd 0x0(%rbp,%rax,1),%xmm1
  1febd2:	movapd %xmm0,%xmm2
  1febd6:	mulpd  %xmm1,%xmm2
  1febda:	shl    $0x4,%rdi
  1febde:	movupd 0x0(%rbp,%rcx,1),%xmm3
  1febe4:	movapd %xmm2,%xmm4
  1febe8:	unpcklpd %xmm2,%xmm4
  1febec:	unpckhpd %xmm2,%xmm2
  1febf0:	subpd  %xmm2,%xmm4
  1febf4:	mulpd  %xmm3,%xmm4
  1febf8:	movapd %xmm0,%xmm2
  1febfc:	unpckhpd %xmm0,%xmm2
  1fec00:	mulsd  %xmm1,%xmm2
  1fec04:	unpckhpd %xmm1,%xmm1
  1fec08:	mulsd  %xmm0,%xmm1
  1fec0c:	addsd  %xmm2,%xmm1
  1fec10:	unpcklpd %xmm1,%xmm1
  1fec14:	shufpd $0x1,%xmm3,%xmm3
  1fec19:	mulpd  %xmm1,%xmm3
  1fec1d:	movapd %xmm4,%xmm0
  1fec21:	subpd  %xmm3,%xmm0
  1fec25:	addpd  %xmm4,%xmm3
  1fec29:	movsd  %xmm0,%xmm3
  1fec2d:	movupd %xmm3,0x0(%rbp,%rdi,1)
  1fec33:	add    $0x8,%r8
  1fec37:	cmp    %r8,%r13
  1fec3a:	jne    1feb90 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4910>
  1fec40:	xor    %eax,%eax
  1fec42:	mov    0x38(%rsp),%rsi
  1fec47:	mov    0x100(%rsp),%r8
  1fec4f:	nop
  1fec50:	mov    (%r9,%rax,1),%rdi
  1fec54:	cmp    %r11,%rdi
  1fec57:	jae    201339 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x70b9>
  1fec5d:	movq   $0x67,(%r8,%rdi,8)
  1fec65:	add    $0x8,%rax
  1fec69:	cmp    %rax,%r13
  1fec6c:	jne    1fec50 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x49d0>
  1fec6e:	xor    %eax,%eax
  1fec70:	xor    %r14d,%r14d
  1fec73:	mov    0x8(%rsp),%r10
  1fec78:	jmp    1fec89 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4a09>
  1fec7a:	nopw   0x0(%rax,%rax,1)
  1fec80:	add    $0x8,%rax
  1fec84:	cmp    %rax,%r15
  1fec87:	je     1fecaf <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4a2f>
  1fec89:	mov    (%rsi,%rax,1),%rdi
  1fec8d:	cmp    %r11,%rdi
  1fec90:	jae    2008c2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6642>
  1fec96:	cmpq   $0x65,(%r8,%rdi,8)
  1fec9b:	jae    1fec80 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4a00>
  1fec9d:	cmp    %r12,%r14
  1feca0:	jae    200ffb <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6d7b>
  1feca6:	mov    %rdi,(%r9,%r14,8)
  1fecaa:	inc    %r14
  1fecad:	jmp    1fec80 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4a00>
  1fecaf:	cmp    %r12,%r14
  1fecb2:	ja     200651 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x63d1>
  1fecb8:	test   %r14,%r14
  1fecbb:	je     1ff0a6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4e26>
  1fecc1:	shl    $0x3,%r14
  1fecc5:	mov    %r10,%r11
  1fecc8:	shl    $0x4,%r11
  1feccc:	imul   $0x69,%r10,%rax
  1fecd0:	mov    %rax,0x20(%rsp)
  1fecd5:	xor    %r15d,%r15d
  1fecd8:	movapd 0x1f97320(%rip),%xmm6        # 2196000 <_fini+0x520>
  1fece0:	xorpd  %xmm7,%xmm7
  1fece4:	movsd  0x1f989c3(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1feced:	movsd  0x1f989c2(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1fecf6:	movsd  0x1f989c9(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1fecff:	movapd 0x1f97308(%rip),%xmm11        # 2196010 <_fini+0x530>
  1fed08:	movsd  0x1f989af(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1fed11:	movabs $0x7fffffffffffffff,%r8
  1fed1b:	movabs $0x7ff0000000000000,%r10
  1fed25:	data16 cs nopw 0x0(%rax,%rax,1)
  1fed30:	mov    (%r9,%r15,1),%r13
  1fed34:	lea    (%r11,%r13,1),%rdi
  1fed38:	cmp    %rbx,%rdi
  1fed3b:	jae    200e6f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6bef>
  1fed41:	shl    $0x4,%rdi
  1fed45:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1fed4b:	movapd %xmm0,%xmm2
  1fed4f:	andpd  %xmm6,%xmm2
  1fed53:	movapd %xmm0,%xmm1
  1fed57:	unpckhpd %xmm0,%xmm1
  1fed5b:	movapd %xmm1,%xmm3
  1fed5f:	andpd  %xmm6,%xmm3
  1fed63:	ucomisd %xmm7,%xmm0
  1fed67:	je     1fede0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4b60>
  1fed69:	ucomisd %xmm7,%xmm1
  1fed6d:	je     1fede0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4b60>
  1fed6f:	movapd %xmm2,%xmm4
  1fed73:	cmplesd %xmm3,%xmm4
  1fed78:	movapd %xmm4,%xmm5
  1fed7c:	andpd  %xmm3,%xmm5
  1fed80:	andnpd %xmm2,%xmm4
  1fed84:	orpd   %xmm5,%xmm4
  1fed88:	ucomisd %xmm8,%xmm4
  1fed8d:	jbe    1fede0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4b60>
  1fed8f:	ucomisd %xmm4,%xmm9
  1fed94:	jbe    1fede0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4b60>
  1fed96:	movapd %xmm0,%xmm2
  1fed9a:	mulpd  %xmm0,%xmm2
  1fed9e:	movapd %xmm2,%xmm3
  1feda2:	unpckhpd %xmm2,%xmm3
  1feda6:	addsd  %xmm2,%xmm3
  1fedaa:	movapd %xmm10,%xmm2
  1fedaf:	divsd  %xmm3,%xmm2
  1fedb3:	mulsd  %xmm2,%xmm0
  1fedb7:	xorpd  %xmm11,%xmm1
  1fedbc:	mulsd  %xmm2,%xmm1
  1fedc0:	add    0x20(%rsp),%r13
  1fedc5:	cmp    %rbx,%r13
  1fedc8:	jb     1fef10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4c90>
  1fedce:	jmp    1fefb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4d30>
  1fedd3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fede0:	ucomisd %xmm7,%xmm1
  1fede4:	setnp  %al
  1fede7:	sete   %cl
  1fedea:	and    %al,%cl
  1fedec:	movq   %xmm0,%rax
  1fedf1:	and    %r8,%rax
  1fedf4:	cmp    %r10,%rax
  1fedf7:	setl   %dl
  1fedfa:	test   %dl,%cl
  1fedfc:	je     1fee30 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4bb0>
  1fedfe:	movapd %xmm10,%xmm2
  1fee03:	divsd  %xmm0,%xmm2
  1fee07:	xorpd  %xmm11,%xmm1
  1fee0c:	movapd %xmm2,%xmm0
  1fee10:	add    0x20(%rsp),%r13
  1fee15:	cmp    %rbx,%r13
  1fee18:	jb     1fef10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4c90>
  1fee1e:	jmp    1fefb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4d30>
  1fee23:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1fee30:	ucomisd %xmm7,%xmm0
  1fee34:	setnp  %cl
  1fee37:	sete   %dl
  1fee3a:	and    %cl,%dl
  1fee3c:	movq   %xmm1,%rcx
  1fee41:	and    %r8,%rcx
  1fee44:	cmp    %r10,%rcx
  1fee47:	setl   %sil
  1fee4b:	test   %sil,%dl
  1fee4e:	je     1fee70 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4bf0>
  1fee50:	movapd %xmm12,%xmm2
  1fee55:	divsd  %xmm1,%xmm2
  1fee59:	movapd %xmm2,%xmm1
  1fee5d:	add    0x20(%rsp),%r13
  1fee62:	cmp    %rbx,%r13
  1fee65:	jb     1fef10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4c90>
  1fee6b:	jmp    1fefb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4d30>
  1fee70:	movabs $0x7fefffffffffffff,%rdx
  1fee7a:	cmp    %rdx,%rax
  1fee7d:	setg   %al
  1fee80:	cmp    %rdx,%rcx
  1fee83:	setg   %cl
  1fee86:	or     %al,%cl
  1fee88:	cmp    $0x1,%cl
  1fee8b:	jne    1fef34 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4cb4>
  1fee91:	add    %rbp,%rdi
  1fee94:	mov    %r11,%r12
  1fee97:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1fee9c:	movsd  0x1f9881b(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1feea5:	movapd 0x1f97162(%rip),%xmm11        # 2196010 <_fini+0x530>
  1feeae:	movsd  0x1f98811(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1feeb7:	movsd  0x1f987f8(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1feec0:	movsd  0x1f987e7(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1feec9:	xorpd  %xmm7,%xmm7
  1feecd:	movapd 0x1f9712b(%rip),%xmm6        # 2196000 <_fini+0x520>
  1feed5:	mov    %r12,%r11
  1feed8:	mov    0xf0(%rsp),%r12
  1feee0:	movabs $0x7ff0000000000000,%r10
  1feeea:	movabs $0x7fffffffffffffff,%r8
  1feef4:	mov    0x10(%rsp),%r9
  1feef9:	add    0x20(%rsp),%r13
  1feefe:	cmp    %rbx,%r13
  1fef01:	jae    1fefb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4d30>
  1fef07:	nopw   0x0(%rax,%rax,1)
  1fef10:	shl    $0x4,%r13
  1fef14:	movsd  %xmm0,0x0(%rbp,%r13,1)
  1fef1b:	movsd  %xmm1,0x8(%rbp,%r13,1)
  1fef22:	add    $0x8,%r15
  1fef26:	cmp    %r15,%r14
  1fef29:	jne    1fed30 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4ab0>
  1fef2f:	jmp    1fefc3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4d43>
  1fef34:	ucomisd %xmm7,%xmm1
  1fef38:	jne    1fef40 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4cc0>
  1fef3a:	jnp    1fedfe <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4b7e>
  1fef40:	ucomisd %xmm7,%xmm0
  1fef44:	jne    1fef4c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4ccc>
  1fef46:	jnp    1fee50 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4bd0>
  1fef4c:	movapd %xmm3,%xmm1
  1fef50:	cmplesd %xmm2,%xmm1
  1fef55:	movapd %xmm1,%xmm4
  1fef59:	andpd  %xmm2,%xmm4
  1fef5d:	andnpd %xmm3,%xmm1
  1fef61:	orpd   %xmm4,%xmm1
  1fef65:	unpcklpd %xmm1,%xmm1
  1fef69:	divpd  %xmm1,%xmm0
  1fef6d:	movapd %xmm0,%xmm2
  1fef71:	xorpd  %xmm11,%xmm2
  1fef76:	movsd  %xmm0,%xmm2
  1fef7a:	mulpd  %xmm0,%xmm0
  1fef7e:	movapd %xmm0,%xmm3
  1fef82:	unpcklpd %xmm0,%xmm3
  1fef86:	unpckhpd %xmm0,%xmm0
  1fef8a:	addpd  %xmm3,%xmm0
  1fef8e:	divpd  %xmm0,%xmm2
  1fef92:	divpd  %xmm1,%xmm2
  1fef96:	movapd %xmm2,%xmm0
  1fef9a:	movapd %xmm2,%xmm1
  1fef9e:	unpckhpd %xmm2,%xmm1
  1fefa2:	add    0x20(%rsp),%r13
  1fefa7:	cmp    %rbx,%r13
  1fefaa:	jb     1fef10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4c90>
  1fefb0:	lea    0x242d5a1(%rip),%rdx        # 262c558 <__gmpfr_one+0x14dd8>
  1fefb7:	mov    %r13,%rdi
  1fefba:	mov    %rbx,%rsi
  1fefbd:	call   *0x24cff3d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fefc3:	mov    0x8(%rsp),%r10
  1fefc8:	lea    (%r10,%r10,1),%rdx
  1fefcc:	cmpq   $0x0,0x118(%rsp)
  1fefd5:	je     201ad0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7850>
  1fefdb:	imul   $0x6a,%r10,%rsi
  1fefdf:	xor    %r8d,%r8d
  1fefe2:	mov    0x108(%rsp),%r11
  1fefea:	mov    0x30(%rsp),%r15
  1fefef:	nop
  1feff0:	mov    (%r9,%r8,1),%rdi
  1feff4:	lea    (%rdi,%rdx,1),%rax
  1feff8:	cmp    %rbx,%rax
  1feffb:	jae    201adb <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x785b>
  1ff001:	mov    0x20(%rsp),%rcx
  1ff006:	add    %rdi,%rcx
  1ff009:	cmp    %rbx,%rcx
  1ff00c:	jae    200e8f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6c0f>
  1ff012:	add    %rsi,%rdi
  1ff015:	cmp    %rbx,%rdi
  1ff018:	jae    200e7f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6bff>
  1ff01e:	shl    $0x4,%rax
  1ff022:	shl    $0x4,%rcx
  1ff026:	movupd 0x0(%rbp,%rax,1),%xmm0
  1ff02c:	mov    0x110(%rsp),%rax
  1ff034:	movupd (%rax),%xmm1
  1ff038:	movapd %xmm0,%xmm2
  1ff03c:	mulpd  %xmm1,%xmm2
  1ff040:	shl    $0x4,%rdi
  1ff044:	movupd 0x0(%rbp,%rcx,1),%xmm3
  1ff04a:	movapd %xmm2,%xmm4
  1ff04e:	unpcklpd %xmm2,%xmm4
  1ff052:	unpckhpd %xmm2,%xmm2
  1ff056:	subpd  %xmm2,%xmm4
  1ff05a:	mulpd  %xmm3,%xmm4
  1ff05e:	movapd %xmm1,%xmm2
  1ff062:	unpckhpd %xmm1,%xmm2
  1ff066:	mulsd  %xmm0,%xmm2
  1ff06a:	unpckhpd %xmm0,%xmm0
  1ff06e:	mulsd  %xmm1,%xmm0
  1ff072:	addsd  %xmm2,%xmm0
  1ff076:	unpcklpd %xmm0,%xmm0
  1ff07a:	shufpd $0x1,%xmm3,%xmm3
  1ff07f:	mulpd  %xmm0,%xmm3
  1ff083:	movapd %xmm4,%xmm0
  1ff087:	subpd  %xmm3,%xmm0
  1ff08b:	addpd  %xmm4,%xmm3
  1ff08f:	movsd  %xmm0,%xmm3
  1ff093:	movupd %xmm3,0x0(%rbp,%rdi,1)
  1ff099:	add    $0x8,%r8
  1ff09d:	cmp    %r8,%r14
  1ff0a0:	jne    1feff0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4d70>
  1ff0a6:	xor    %eax,%eax
  1ff0a8:	xor    %r14d,%r14d
  1ff0ab:	mov    0x38(%rsp),%rcx
  1ff0b0:	mov    0x100(%rsp),%rdx
  1ff0b8:	jmp    1ff0d0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4e50>
  1ff0ba:	nopw   0x0(%rax,%rax,1)
  1ff0c0:	mov    %rdi,(%r9,%r14,8)
  1ff0c4:	inc    %r14
  1ff0c7:	add    $0x8,%rax
  1ff0cb:	cmp    %rax,%r15
  1ff0ce:	je     1ff0fc <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4e7c>
  1ff0d0:	mov    (%rcx,%rax,1),%rdi
  1ff0d4:	cmp    %r11,%rdi
  1ff0d7:	jae    2008d2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6652>
  1ff0dd:	cmpq   $0x68,(%rdx,%rdi,8)
  1ff0e2:	jae    1ff0c7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4e47>
  1ff0e4:	cmp    %r12,%r14
  1ff0e7:	jb     1ff0c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4e40>
  1ff0e9:	lea    0x242d4e0(%rip),%rdx        # 262c5d0 <__gmpfr_one+0x14e50>
  1ff0f0:	mov    %r14,%rdi
  1ff0f3:	mov    %r12,%rsi
  1ff0f6:	call   *0x24cfe04(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1ff0fc:	cmp    %r12,%r14
  1ff0ff:	ja     200666 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x63e6>
  1ff105:	test   %r14,%r14
  1ff108:	je     1ff846 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x55c6>
  1ff10e:	lea    0x0(,%r14,8),%r15
  1ff116:	lea    (%r10,%r10,1),%rcx
  1ff11a:	mov    %r10,%r12
  1ff11d:	shl    $0x5,%r12
  1ff121:	mov    %rcx,0x18(%rsp)
  1ff126:	sub    %rcx,%r12
  1ff129:	xor    %r13d,%r13d
  1ff12c:	xorpd  %xmm1,%xmm1
  1ff130:	jmp    1ff168 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4ee8>
  1ff132:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ff140:	mov    $0x6c,%r8d
  1ff146:	mov    %rbp,%rdi
  1ff149:	mov    %rbx,%rsi
  1ff14c:	mov    0x8(%rsp),%rdx
  1ff151:	call   1fa170 <oneloop::native::batch::copy_active_column::<f64>>
  1ff156:	add    $0x8,%r13
  1ff15a:	cmp    %r13,%r15
  1ff15d:	mov    0x10(%rsp),%r9
  1ff162:	xorpd  %xmm1,%xmm1
  1ff166:	je     1ff1a9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4f29>
  1ff168:	mov    (%r9,%r13,1),%rcx
  1ff16c:	lea    (%rcx,%r12,1),%rdi
  1ff170:	cmp    %rbx,%rdi
  1ff173:	jae    200ea2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6c22>
  1ff179:	shl    $0x4,%rdi
  1ff17d:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1ff183:	mov    $0x66,%r9d
  1ff189:	ucomisd %xmm1,%xmm0
  1ff18d:	jne    1ff140 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4ec0>
  1ff18f:	jp     1ff140 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4ec0>
  1ff191:	add    %rbp,%rdi
  1ff194:	movsd  0x8(%rdi),%xmm0
  1ff199:	ucomisd %xmm1,%xmm0
  1ff19d:	jne    1ff140 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4ec0>
  1ff19f:	jp     1ff140 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4ec0>
  1ff1a1:	mov    $0x6a,%r9d
  1ff1a7:	jmp    1ff140 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4ec0>
  1ff1a9:	mov    0x8(%rsp),%r8
  1ff1ae:	imul   $0x6c,%r8,%rcx
  1ff1b2:	xor    %edx,%edx
  1ff1b4:	xorpd  %xmm0,%xmm0
  1ff1b8:	xor    %r13d,%r13d
  1ff1bb:	mov    0xf0(%rsp),%r12
  1ff1c3:	mov    0x108(%rsp),%r11
  1ff1cb:	mov    0x30(%rsp),%r15
  1ff1d0:	jmp    1ff201 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4f81>
  1ff1d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ff1e0:	cmp    %r11,%rdi
  1ff1e3:	jae    201959 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x76d9>
  1ff1e9:	mov    0x100(%rsp),%rax
  1ff1f1:	movq   $0xa2,(%rax,%rdi,8)
  1ff1f9:	inc    %rdx
  1ff1fc:	cmp    %rdx,%r14
  1ff1ff:	je     1ff24c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4fcc>
  1ff201:	mov    (%r9,%rdx,8),%rdi
  1ff205:	lea    (%rdi,%rcx,1),%rax
  1ff209:	cmp    %rbx,%rax
  1ff20c:	jae    200eb2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6c32>
  1ff212:	shl    $0x4,%rax
  1ff216:	movsd  0x0(%rbp,%rax,1),%xmm1
  1ff21c:	ucomisd %xmm0,%xmm1
  1ff220:	jne    1ff234 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4fb4>
  1ff222:	jp     1ff234 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4fb4>
  1ff224:	add    %rbp,%rax
  1ff227:	movsd  0x8(%rax),%xmm1
  1ff22c:	ucomisd %xmm0,%xmm1
  1ff230:	jne    1ff234 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4fb4>
  1ff232:	jnp    1ff1e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4f60>
  1ff234:	cmp    %r12,%r13
  1ff237:	jae    201565 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x72e5>
  1ff23d:	mov    %rdi,(%r9,%r13,8)
  1ff241:	inc    %r13
  1ff244:	inc    %rdx
  1ff247:	cmp    %rdx,%r14
  1ff24a:	jne    1ff201 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x4f81>
  1ff24c:	cmp    %r12,%r13
  1ff24f:	ja     20073d <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x64bd>
  1ff255:	test   %r13,%r13
  1ff258:	je     1ff846 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x55c6>
  1ff25e:	mov    0x118(%rsp),%rsi
  1ff266:	cmp    $0x2,%rsi
  1ff26a:	jb     201b34 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x78b4>
  1ff270:	lea    0x0(,%r13,8),%r15
  1ff278:	lea    0x0(,%r8,4),%rax
  1ff280:	imul   $0x6e,%r8,%r11
  1ff284:	lea    (%rax,%rax,2),%rcx
  1ff288:	xor    %edx,%edx
  1ff28a:	mov    0x110(%rsp),%r10
  1ff292:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ff2a0:	mov    (%r9,%rdx,1),%rdi
  1ff2a4:	lea    (%rdi,%rcx,1),%rax
  1ff2a8:	cmp    %rbx,%rax
  1ff2ab:	jae    20136c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x70ec>
  1ff2b1:	add    %r11,%rdi
  1ff2b4:	cmp    %rbx,%rdi
  1ff2b7:	jae    20135c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x70dc>
  1ff2bd:	shl    $0x4,%rax
  1ff2c1:	shl    $0x4,%rdi
  1ff2c5:	movupd 0x10(%r10),%xmm0
  1ff2cb:	movsd  0x0(%rbp,%rax,1),%xmm1
  1ff2d1:	movsd  0x8(%rbp,%rax,1),%xmm2
  1ff2d7:	unpcklpd %xmm1,%xmm1
  1ff2db:	mulpd  %xmm0,%xmm1
  1ff2df:	shufpd $0x1,%xmm0,%xmm0
  1ff2e4:	unpcklpd %xmm2,%xmm2
  1ff2e8:	mulpd  %xmm0,%xmm2
  1ff2ec:	movapd %xmm1,%xmm0
  1ff2f0:	subpd  %xmm2,%xmm0
  1ff2f4:	addpd  %xmm1,%xmm2
  1ff2f8:	movsd  %xmm0,%xmm2
  1ff2fc:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1ff302:	add    $0x8,%rdx
  1ff306:	cmp    %rdx,%r15
  1ff309:	jne    1ff2a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5020>
  1ff30b:	mov    %r13,0x48(%rsp)
  1ff310:	lea    (%r8,%r8,4),%rax
  1ff314:	lea    (%rax,%rax,2),%rdx
  1ff318:	imul   $0x6f,%r8,%r13
  1ff31c:	xor    %esi,%esi
  1ff31e:	xchg   %ax,%ax
  1ff320:	mov    (%r9,%rsi,1),%rdi
  1ff324:	lea    (%rdi,%rdx,1),%rax
  1ff328:	cmp    %rbx,%rax
  1ff32b:	jae    2013a2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7122>
  1ff331:	lea    (%rdi,%r11,1),%rcx
  1ff335:	cmp    %rbx,%rcx
  1ff338:	jae    20138f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x710f>
  1ff33e:	add    %r13,%rdi
  1ff341:	cmp    %rbx,%rdi
  1ff344:	jae    20137f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x70ff>
  1ff34a:	shl    $0x4,%rax
  1ff34e:	shl    $0x4,%rcx
  1ff352:	shl    $0x4,%rdi
  1ff356:	movupd 0x0(%rbp,%rax,1),%xmm0
  1ff35c:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1ff362:	addpd  %xmm0,%xmm1
  1ff366:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1ff36c:	add    $0x8,%rsi
  1ff370:	cmp    %rsi,%r15
  1ff373:	jne    1ff320 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x50a0>
  1ff375:	mov    %r11,0x40(%rsp)
  1ff37a:	imul   $0x70,0x8(%rsp),%r11
  1ff380:	xor    %r12d,%r12d
  1ff383:	xorpd  %xmm8,%xmm8
  1ff388:	movapd 0x1f96c70(%rip),%xmm6        # 2196000 <_fini+0x520>
  1ff390:	movsd  0x1f98318(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1ff398:	mov    %r11,0x20(%rsp)
  1ff39d:	nopl   (%rax)
  1ff3a0:	mov    (%r9,%r12,1),%r14
  1ff3a4:	lea    (%r14,%r13,1),%rdi
  1ff3a8:	cmp    %rbx,%rdi
  1ff3ab:	jae    2013c8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7148>
  1ff3b1:	shl    $0x4,%rdi
  1ff3b5:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1ff3bb:	movapd %xmm0,%xmm1
  1ff3bf:	unpckhpd %xmm0,%xmm1
  1ff3c3:	ucomisd %xmm8,%xmm1
  1ff3c8:	jne    1ff3e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5160>
  1ff3ca:	jp     1ff3e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5160>
  1ff3cc:	andpd  %xmm6,%xmm0
  1ff3d0:	jmp    1ff490 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5210>
  1ff3d5:	data16 cs nopw 0x0(%rax,%rax,1)
  1ff3e0:	ucomisd %xmm8,%xmm0
  1ff3e5:	jne    1ff3f6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5176>
  1ff3e7:	jp     1ff3f6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5176>
  1ff3e9:	andpd  %xmm6,%xmm1
  1ff3ed:	movapd %xmm1,%xmm0
  1ff3f1:	jmp    1ff490 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5210>
  1ff3f6:	movapd %xmm0,%xmm2
  1ff3fa:	andpd  %xmm6,%xmm2
  1ff3fe:	pshufd $0xee,%xmm2,%xmm3
  1ff403:	movapd %xmm2,%xmm4
  1ff407:	cmplesd %xmm3,%xmm4
  1ff40c:	movapd %xmm4,%xmm5
  1ff410:	andpd  %xmm3,%xmm5
  1ff414:	andnpd %xmm2,%xmm4
  1ff418:	orpd   %xmm5,%xmm4
  1ff41c:	movapd %xmm0,%xmm2
  1ff420:	cmpunordsd %xmm0,%xmm2
  1ff425:	movapd %xmm2,%xmm5
  1ff429:	andnpd %xmm4,%xmm5
  1ff42d:	andpd  %xmm3,%xmm2
  1ff431:	orpd   %xmm5,%xmm2
  1ff435:	ucomisd %xmm7,%xmm2
  1ff439:	jbe    1ff462 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x51e2>
  1ff43b:	movsd  0x1f98275(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1ff443:	ucomisd %xmm2,%xmm3
  1ff447:	jbe    1ff462 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x51e2>
  1ff449:	mulpd  %xmm0,%xmm0
  1ff44d:	movapd %xmm0,%xmm1
  1ff451:	unpckhpd %xmm0,%xmm1
  1ff455:	addsd  %xmm0,%xmm1
  1ff459:	xorps  %xmm0,%xmm0
  1ff45c:	sqrtsd %xmm1,%xmm0
  1ff460:	jmp    1ff490 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5210>
  1ff462:	call   *0x24cc768(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1ff468:	xorpd  %xmm8,%xmm8
  1ff46d:	movsd  0x1f9823b(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1ff475:	movapd 0x1f96b83(%rip),%xmm6        # 2196000 <_fini+0x520>
  1ff47d:	mov    0x20(%rsp),%r11
  1ff482:	mov    0x110(%rsp),%r10
  1ff48a:	mov    0x10(%rsp),%r9
  1ff48f:	nop
  1ff490:	add    %r11,%r14
  1ff493:	cmp    %rbx,%r14
  1ff496:	jae    2013b5 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7135>
  1ff49c:	shl    $0x4,%r14
  1ff4a0:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1ff4a7:	movq   $0x0,0x8(%rbp,%r14,1)
  1ff4b0:	add    $0x8,%r12
  1ff4b4:	cmp    %r12,%r15
  1ff4b7:	jne    1ff3a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5120>
  1ff4bd:	mov    0x18(%rsp),%rax
  1ff4c2:	lea    (%rax,%rax,8),%rdx
  1ff4c6:	imul   $0x71,0x8(%rsp),%r13
  1ff4cc:	xor    %esi,%esi
  1ff4ce:	mov    0x40(%rsp),%r8
  1ff4d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ff4e0:	mov    (%r9,%rsi,1),%rdi
  1ff4e4:	lea    (%rdi,%rdx,1),%rax
  1ff4e8:	cmp    %rbx,%rax
  1ff4eb:	jae    2013fb <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x717b>
  1ff4f1:	lea    (%rdi,%r8,1),%rcx
  1ff4f5:	cmp    %rbx,%rcx
  1ff4f8:	jae    2013e8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7168>
  1ff4fe:	add    %r13,%rdi
  1ff501:	cmp    %rbx,%rdi
  1ff504:	jae    2013d8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7158>
  1ff50a:	shl    $0x4,%rax
  1ff50e:	shl    $0x4,%rcx
  1ff512:	shl    $0x4,%rdi
  1ff516:	movupd 0x0(%rbp,%rax,1),%xmm0
  1ff51c:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1ff522:	addpd  %xmm0,%xmm1
  1ff526:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1ff52c:	add    $0x8,%rsi
  1ff530:	cmp    %rsi,%r15
  1ff533:	jne    1ff4e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5260>
  1ff535:	imul   $0x72,0x8(%rsp),%r8
  1ff53b:	xor    %r12d,%r12d
  1ff53e:	xorpd  %xmm8,%xmm8
  1ff543:	mov    %r8,0x18(%rsp)
  1ff548:	nopl   0x0(%rax,%rax,1)
  1ff550:	mov    (%r9,%r12,1),%r14
  1ff554:	lea    (%r14,%r13,1),%rdi
  1ff558:	cmp    %rbx,%rdi
  1ff55b:	jae    201421 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x71a1>
  1ff561:	shl    $0x4,%rdi
  1ff565:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1ff56b:	movapd %xmm0,%xmm1
  1ff56f:	unpckhpd %xmm0,%xmm1
  1ff573:	ucomisd %xmm8,%xmm1
  1ff578:	jne    1ff590 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5310>
  1ff57a:	jp     1ff590 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5310>
  1ff57c:	andpd  %xmm6,%xmm0
  1ff580:	jmp    1ff650 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x53d0>
  1ff585:	data16 cs nopw 0x0(%rax,%rax,1)
  1ff590:	ucomisd %xmm8,%xmm0
  1ff595:	jne    1ff5a6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5326>
  1ff597:	jp     1ff5a6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5326>
  1ff599:	andpd  %xmm6,%xmm1
  1ff59d:	movapd %xmm1,%xmm0
  1ff5a1:	jmp    1ff650 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x53d0>
  1ff5a6:	movapd %xmm0,%xmm2
  1ff5aa:	andpd  %xmm6,%xmm2
  1ff5ae:	pshufd $0xee,%xmm2,%xmm3
  1ff5b3:	movapd %xmm2,%xmm4
  1ff5b7:	cmplesd %xmm3,%xmm4
  1ff5bc:	movapd %xmm4,%xmm5
  1ff5c0:	andpd  %xmm3,%xmm5
  1ff5c4:	andnpd %xmm2,%xmm4
  1ff5c8:	orpd   %xmm5,%xmm4
  1ff5cc:	movapd %xmm0,%xmm2
  1ff5d0:	cmpunordsd %xmm0,%xmm2
  1ff5d5:	movapd %xmm2,%xmm5
  1ff5d9:	andnpd %xmm4,%xmm5
  1ff5dd:	andpd  %xmm3,%xmm2
  1ff5e1:	orpd   %xmm5,%xmm2
  1ff5e5:	ucomisd %xmm7,%xmm2
  1ff5e9:	jbe    1ff612 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5392>
  1ff5eb:	movsd  0x1f980c5(%rip),%xmm3        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1ff5f3:	ucomisd %xmm2,%xmm3
  1ff5f7:	jbe    1ff612 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5392>
  1ff5f9:	mulpd  %xmm0,%xmm0
  1ff5fd:	movapd %xmm0,%xmm1
  1ff601:	unpckhpd %xmm0,%xmm1
  1ff605:	addsd  %xmm0,%xmm1
  1ff609:	xorps  %xmm0,%xmm0
  1ff60c:	sqrtsd %xmm1,%xmm0
  1ff610:	jmp    1ff650 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x53d0>
  1ff612:	call   *0x24cc5b8(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1ff618:	xorpd  %xmm8,%xmm8
  1ff61d:	mov    0x18(%rsp),%r8
  1ff622:	movsd  0x1f98086(%rip),%xmm7        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1ff62a:	movapd 0x1f969ce(%rip),%xmm6        # 2196000 <_fini+0x520>
  1ff632:	mov    0x20(%rsp),%r11
  1ff637:	mov    0x110(%rsp),%r10
  1ff63f:	mov    0x10(%rsp),%r9
  1ff644:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ff650:	add    %r8,%r14
  1ff653:	cmp    %rbx,%r14
  1ff656:	jae    20140e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x718e>
  1ff65c:	shl    $0x4,%r14
  1ff660:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1ff667:	movq   $0x0,0x8(%rbp,%r14,1)
  1ff670:	add    $0x8,%r12
  1ff674:	cmp    %r12,%r15
  1ff677:	jne    1ff550 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x52d0>
  1ff67d:	mov    0x8(%rsp),%rdx
  1ff682:	imul   $0x73,%rdx,%rsi
  1ff686:	xor    %ecx,%ecx
  1ff688:	mov    0xf0(%rsp),%r12
  1ff690:	mov    0x48(%rsp),%r14
  1ff695:	data16 cs nopw 0x0(%rax,%rax,1)
  1ff6a0:	mov    (%r9,%rcx,1),%rdi
  1ff6a4:	lea    (%rdi,%r8,1),%rax
  1ff6a8:	cmp    %rbx,%rax
  1ff6ab:	jae    201441 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x71c1>
  1ff6b1:	add    %rsi,%rdi
  1ff6b4:	cmp    %rbx,%rdi
  1ff6b7:	jae    201431 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x71b1>
  1ff6bd:	shl    $0x4,%rax
  1ff6c1:	shl    $0x4,%rdi
  1ff6c5:	movupd 0x10(%r10),%xmm0
  1ff6cb:	movsd  0x0(%rbp,%rax,1),%xmm1
  1ff6d1:	movsd  0x8(%rbp,%rax,1),%xmm2
  1ff6d7:	unpcklpd %xmm1,%xmm1
  1ff6db:	mulpd  %xmm0,%xmm1
  1ff6df:	shufpd $0x1,%xmm0,%xmm0
  1ff6e4:	unpcklpd %xmm2,%xmm2
  1ff6e8:	mulpd  %xmm0,%xmm2
  1ff6ec:	movapd %xmm1,%xmm0
  1ff6f0:	subpd  %xmm2,%xmm0
  1ff6f4:	addpd  %xmm1,%xmm2
  1ff6f8:	movsd  %xmm0,%xmm2
  1ff6fc:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1ff702:	add    $0x8,%rcx
  1ff706:	cmp    %rcx,%r15
  1ff709:	jne    1ff6a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5420>
  1ff70b:	imul   $0x74,%rdx,%rdx
  1ff70f:	xor    %r8d,%r8d
  1ff712:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ff720:	mov    (%r9,%r8,1),%rdi
  1ff724:	lea    (%rdi,%r11,1),%rax
  1ff728:	cmp    %rbx,%rax
  1ff72b:	jae    201477 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x71f7>
  1ff731:	lea    (%rdi,%rsi,1),%rcx
  1ff735:	cmp    %rbx,%rcx
  1ff738:	jae    201464 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x71e4>
  1ff73e:	add    %rdx,%rdi
  1ff741:	cmp    %rbx,%rdi
  1ff744:	jae    201454 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x71d4>
  1ff74a:	shl    $0x4,%rax
  1ff74e:	shl    $0x4,%rcx
  1ff752:	shl    $0x4,%rdi
  1ff756:	movupd 0x0(%rbp,%rax,1),%xmm0
  1ff75c:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1ff762:	addpd  %xmm0,%xmm1
  1ff766:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1ff76c:	add    $0x8,%r8
  1ff770:	cmp    %r8,%r15
  1ff773:	jne    1ff720 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x54a0>
  1ff775:	xor    %ecx,%ecx
  1ff777:	xorpd  %xmm0,%xmm0
  1ff77b:	xor    %esi,%esi
  1ff77d:	mov    0x108(%rsp),%r11
  1ff785:	mov    0x30(%rsp),%r15
  1ff78a:	mov    0x100(%rsp),%r8
  1ff792:	jmp    1ff7b9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5539>
  1ff794:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ff7a0:	cmp    %r11,%rdi
  1ff7a3:	jae    201a22 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x77a2>
  1ff7a9:	movq   $0x73,(%r8,%rdi,8)
  1ff7b1:	inc    %rcx
  1ff7b4:	cmp    %rcx,%r14
  1ff7b7:	je     1ff804 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5584>
  1ff7b9:	mov    (%r9,%rcx,8),%rdi
  1ff7bd:	lea    (%rdi,%rdx,1),%rax
  1ff7c1:	cmp    %rbx,%rax
  1ff7c4:	jae    20148a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x720a>
  1ff7ca:	shl    $0x4,%rax
  1ff7ce:	movsd  0x0(%rbp,%rax,1),%xmm1
  1ff7d4:	ucomisd %xmm0,%xmm1
  1ff7d8:	jne    1ff7ec <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x556c>
  1ff7da:	jp     1ff7ec <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x556c>
  1ff7dc:	add    %rbp,%rax
  1ff7df:	movsd  0x8(%rax),%xmm1
  1ff7e4:	ucomisd %xmm0,%xmm1
  1ff7e8:	jne    1ff7ec <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x556c>
  1ff7ea:	jnp    1ff7a0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5520>
  1ff7ec:	cmp    %r12,%rsi
  1ff7ef:	jae    2019c9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7749>
  1ff7f5:	mov    %rdi,(%r9,%rsi,8)
  1ff7f9:	inc    %rsi
  1ff7fc:	inc    %rcx
  1ff7ff:	cmp    %rcx,%r14
  1ff802:	jne    1ff7b9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5539>
  1ff804:	cmp    %r12,%rsi
  1ff807:	ja     20077e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x64fe>
  1ff80d:	test   %rsi,%rsi
  1ff810:	je     1ff846 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x55c6>
  1ff812:	shl    $0x3,%rsi
  1ff816:	xor    %eax,%eax
  1ff818:	nopl   0x0(%rax,%rax,1)
  1ff820:	mov    (%r9,%rax,1),%rdi
  1ff824:	cmp    %r11,%rdi
  1ff827:	jae    2019a9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7729>
  1ff82d:	mov    0x100(%rsp),%rcx
  1ff835:	movq   $0x74,(%rcx,%rdi,8)
  1ff83d:	add    $0x8,%rax
  1ff841:	cmp    %rax,%rsi
  1ff844:	jne    1ff820 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x55a0>
  1ff846:	xor    %ecx,%ecx
  1ff848:	xor    %edi,%edi
  1ff84a:	mov    0x38(%rsp),%r12
  1ff84f:	mov    0x100(%rsp),%r8
  1ff857:	jmp    1ff869 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x55e9>
  1ff859:	nopl   0x0(%rax)
  1ff860:	add    $0x8,%rcx
  1ff864:	cmp    %rcx,%r15
  1ff867:	je     1ff894 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5614>
  1ff869:	mov    (%r12,%rcx,1),%rax
  1ff86d:	cmp    %r11,%rax
  1ff870:	jae    2008e2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6662>
  1ff876:	cmpq   $0x74,(%r8,%rax,8)
  1ff87b:	jae    1ff860 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x55e0>
  1ff87d:	cmp    0xf0(%rsp),%rdi
  1ff885:	jae    201028 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6da8>
  1ff88b:	mov    %rax,(%r9,%rdi,8)
  1ff88f:	inc    %rdi
  1ff892:	jmp    1ff860 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x55e0>
  1ff894:	xor    %eax,%eax
  1ff896:	xor    %esi,%esi
  1ff898:	mov    0x110(%rsp),%r10
  1ff8a0:	jmp    1ff8c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5640>
  1ff8a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ff8b0:	mov    %rdi,(%r9,%rsi,8)
  1ff8b4:	inc    %rsi
  1ff8b7:	add    $0x8,%rax
  1ff8bb:	cmp    %rax,%r15
  1ff8be:	je     1ff8f6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5676>
  1ff8c0:	mov    (%r12,%rax,1),%rdi
  1ff8c4:	cmp    %r11,%rdi
  1ff8c7:	jae    2008f5 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6675>
  1ff8cd:	cmpq   $0x75,(%r8,%rdi,8)
  1ff8d2:	jae    1ff8b7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5637>
  1ff8d4:	cmp    0xf0(%rsp),%rsi
  1ff8dc:	jb     1ff8b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5630>
  1ff8de:	lea    0x242cf13(%rip),%rdx        # 262c7f8 <__gmpfr_one+0x15078>
  1ff8e5:	mov    %rsi,%rdi
  1ff8e8:	mov    0xf0(%rsp),%rsi
  1ff8f0:	call   *0x24cf60a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1ff8f6:	cmp    0xf0(%rsp),%rsi
  1ff8fe:	ja     20067b <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x63fb>
  1ff904:	test   %rsi,%rsi
  1ff907:	je     2000de <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5e5e>
  1ff90d:	mov    %rsi,0x18(%rsp)
  1ff912:	lea    0x0(,%rsi,8),%r15
  1ff91a:	mov    0x8(%rsp),%r13
  1ff91f:	imul   $0x74,%r13,%r14
  1ff923:	imul   $0x79,%r13,%r11
  1ff927:	xor    %r12d,%r12d
  1ff92a:	xorpd  %xmm1,%xmm1
  1ff92e:	mov    %r11,0x20(%rsp)
  1ff933:	jmp    1ff979 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x56f9>
  1ff935:	data16 cs nopw 0x0(%rax,%rax,1)
  1ff940:	mov    $0x79,%r8d
  1ff946:	mov    $0x74,%r9d
  1ff94c:	mov    %rbp,%rdi
  1ff94f:	mov    %rbx,%rsi
  1ff952:	mov    %r13,%rdx
  1ff955:	call   1fa170 <oneloop::native::batch::copy_active_column::<f64>>
  1ff95a:	xorpd  %xmm1,%xmm1
  1ff95e:	mov    0x20(%rsp),%r11
  1ff963:	mov    0x110(%rsp),%r10
  1ff96b:	mov    0x10(%rsp),%r9
  1ff970:	add    $0x8,%r12
  1ff974:	cmp    %r12,%r15
  1ff977:	je     1ff9e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5760>
  1ff979:	mov    (%r9,%r12,1),%rcx
  1ff97d:	lea    (%rcx,%r14,1),%rdi
  1ff981:	cmp    %rbx,%rdi
  1ff984:	jae    200ec5 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6c45>
  1ff98a:	shl    $0x4,%rdi
  1ff98e:	movsd  0x0(%rbp,%rdi,1),%xmm0
  1ff994:	ucomisd %xmm1,%xmm0
  1ff998:	jne    1ff940 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x56c0>
  1ff99a:	jp     1ff940 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x56c0>
  1ff99c:	add    %rbp,%rdi
  1ff99f:	movsd  0x8(%rdi),%xmm0
  1ff9a4:	ucomisd %xmm1,%xmm0
  1ff9a8:	jne    1ff940 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x56c0>
  1ff9aa:	jp     1ff940 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x56c0>
  1ff9ac:	add    %r11,%rcx
  1ff9af:	cmp    %rbx,%rcx
  1ff9b2:	jae    201996 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7716>
  1ff9b8:	cmpq   $0x3,0x118(%rsp)
  1ff9c1:	jbe    20197c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x76fc>
  1ff9c7:	shl    $0x4,%rcx
  1ff9cb:	movupd 0x30(%r10),%xmm0
  1ff9d1:	movupd %xmm0,0x0(%rbp,%rcx,1)
  1ff9d7:	add    $0x8,%r12
  1ff9db:	cmp    %r12,%r15
  1ff9de:	jne    1ff979 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x56f9>
  1ff9e0:	imul   $0x7a,%r13,%r14
  1ff9e4:	xor    %r12d,%r12d
  1ff9e7:	xorpd  %xmm8,%xmm8
  1ff9ec:	movapd 0x1f9660b(%rip),%xmm9        # 2196000 <_fini+0x520>
  1ff9f5:	movsd  0x1f97cb3(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1ff9fd:	movsd  0x1f97cb3(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1ffa05:	data16 cs nopw 0x0(%rax,%rax,1)
  1ffa10:	mov    (%r9,%r12,1),%r13
  1ffa14:	lea    (%r11,%r13,1),%rdi
  1ffa18:	cmp    %rbx,%rdi
  1ffa1b:	jae    200ee8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6c68>
  1ffa21:	shl    $0x4,%rdi
  1ffa25:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1ffa2b:	movapd %xmm0,%xmm1
  1ffa2f:	unpckhpd %xmm0,%xmm1
  1ffa33:	ucomisd %xmm8,%xmm1
  1ffa38:	jne    1ffa50 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x57d0>
  1ffa3a:	jp     1ffa50 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x57d0>
  1ffa3c:	andpd  %xmm9,%xmm0
  1ffa41:	jmp    1ffb10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5890>
  1ffa46:	cs nopw 0x0(%rax,%rax,1)
  1ffa50:	ucomisd %xmm8,%xmm0
  1ffa55:	jne    1ffa67 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x57e7>
  1ffa57:	jp     1ffa67 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x57e7>
  1ffa59:	andpd  %xmm9,%xmm1
  1ffa5e:	movapd %xmm1,%xmm0
  1ffa62:	jmp    1ffb10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5890>
  1ffa67:	movapd %xmm0,%xmm2
  1ffa6b:	andpd  %xmm9,%xmm2
  1ffa70:	pshufd $0xee,%xmm2,%xmm3
  1ffa75:	movapd %xmm2,%xmm4
  1ffa79:	cmplesd %xmm3,%xmm4
  1ffa7e:	movapd %xmm4,%xmm5
  1ffa82:	andpd  %xmm3,%xmm5
  1ffa86:	andnpd %xmm2,%xmm4
  1ffa8a:	orpd   %xmm5,%xmm4
  1ffa8e:	movapd %xmm0,%xmm2
  1ffa92:	cmpunordsd %xmm0,%xmm2
  1ffa97:	movapd %xmm2,%xmm5
  1ffa9b:	andnpd %xmm4,%xmm5
  1ffa9f:	andpd  %xmm3,%xmm2
  1ffaa3:	orpd   %xmm5,%xmm2
  1ffaa7:	ucomisd %xmm6,%xmm2
  1ffaab:	jbe    1ffacc <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x584c>
  1ffaad:	ucomisd %xmm2,%xmm7
  1ffab1:	jbe    1ffacc <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x584c>
  1ffab3:	mulpd  %xmm0,%xmm0
  1ffab7:	movapd %xmm0,%xmm1
  1ffabb:	unpckhpd %xmm0,%xmm1
  1ffabf:	addsd  %xmm0,%xmm1
  1ffac3:	xorps  %xmm0,%xmm0
  1ffac6:	sqrtsd %xmm1,%xmm0
  1ffaca:	jmp    1ffb10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5890>
  1ffacc:	call   *0x24cc0fe(%rip)        # 26cbbd0 <hypot@GLIBC_2.35>
  1ffad2:	movapd 0x1f96525(%rip),%xmm9        # 2196000 <_fini+0x520>
  1ffadb:	xorpd  %xmm8,%xmm8
  1ffae0:	mov    0x20(%rsp),%r11
  1ffae5:	movsd  0x1f97bcb(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1ffaed:	movsd  0x1f97bbb(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1ffaf5:	mov    0x110(%rsp),%r10
  1ffafd:	mov    0x10(%rsp),%r9
  1ffb02:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ffb10:	add    %r14,%r13
  1ffb13:	cmp    %rbx,%r13
  1ffb16:	jae    200ed5 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6c55>
  1ffb1c:	shl    $0x4,%r13
  1ffb20:	movsd  %xmm0,0x0(%rbp,%r13,1)
  1ffb27:	movq   $0x0,0x8(%rbp,%r13,1)
  1ffb30:	add    $0x8,%r12
  1ffb34:	cmp    %r12,%r15
  1ffb37:	jne    1ffa10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5790>
  1ffb3d:	cmpq   $0x2,0x118(%rsp)
  1ffb46:	jb     201a42 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x77c2>
  1ffb4c:	mov    0x8(%rsp),%rdx
  1ffb51:	imul   $0x7b,%rdx,%rsi
  1ffb55:	xor    %ecx,%ecx
  1ffb57:	nopw   0x0(%rax,%rax,1)
  1ffb60:	mov    (%r9,%rcx,1),%rdi
  1ffb64:	lea    (%rdi,%r14,1),%rax
  1ffb68:	cmp    %rbx,%rax
  1ffb6b:	jae    200f08 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6c88>
  1ffb71:	add    %rsi,%rdi
  1ffb74:	cmp    %rbx,%rdi
  1ffb77:	jae    200ef8 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6c78>
  1ffb7d:	shl    $0x4,%rax
  1ffb81:	shl    $0x4,%rdi
  1ffb85:	movupd 0x10(%r10),%xmm0
  1ffb8b:	movsd  0x0(%rbp,%rax,1),%xmm1
  1ffb91:	movsd  0x8(%rbp,%rax,1),%xmm2
  1ffb97:	unpcklpd %xmm1,%xmm1
  1ffb9b:	mulpd  %xmm0,%xmm1
  1ffb9f:	shufpd $0x1,%xmm0,%xmm0
  1ffba4:	unpcklpd %xmm2,%xmm2
  1ffba8:	mulpd  %xmm0,%xmm2
  1ffbac:	movapd %xmm1,%xmm0
  1ffbb0:	subpd  %xmm2,%xmm0
  1ffbb4:	addpd  %xmm1,%xmm2
  1ffbb8:	movsd  %xmm0,%xmm2
  1ffbbc:	movupd %xmm2,0x0(%rbp,%rdi,1)
  1ffbc2:	add    $0x8,%rcx
  1ffbc6:	cmp    %rcx,%r15
  1ffbc9:	jne    1ffb60 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x58e0>
  1ffbcb:	imul   $0x7c,%rdx,%rdx
  1ffbcf:	xor    %r8d,%r8d
  1ffbd2:	mov    0x18(%rsp),%r14
  1ffbd7:	nopw   0x0(%rax,%rax,1)
  1ffbe0:	mov    (%r9,%r8,1),%rdi
  1ffbe4:	lea    (%rdi,%r11,1),%rax
  1ffbe8:	cmp    %rbx,%rax
  1ffbeb:	jae    200f3e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6cbe>
  1ffbf1:	lea    (%rdi,%rsi,1),%rcx
  1ffbf5:	cmp    %rbx,%rcx
  1ffbf8:	jae    200f2b <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6cab>
  1ffbfe:	add    %rdx,%rdi
  1ffc01:	cmp    %rbx,%rdi
  1ffc04:	jae    200f1b <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6c9b>
  1ffc0a:	shl    $0x4,%rax
  1ffc0e:	shl    $0x4,%rcx
  1ffc12:	shl    $0x4,%rdi
  1ffc16:	movupd 0x0(%rbp,%rax,1),%xmm0
  1ffc1c:	movupd 0x0(%rbp,%rcx,1),%xmm1
  1ffc22:	addpd  %xmm0,%xmm1
  1ffc26:	movupd %xmm1,0x0(%rbp,%rdi,1)
  1ffc2c:	add    $0x8,%r8
  1ffc30:	cmp    %r8,%r15
  1ffc33:	jne    1ffbe0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5960>
  1ffc35:	xor    %ecx,%ecx
  1ffc37:	xorpd  %xmm0,%xmm0
  1ffc3b:	xor    %r13d,%r13d
  1ffc3e:	mov    0x108(%rsp),%r11
  1ffc46:	mov    0x30(%rsp),%r15
  1ffc4b:	mov    0x38(%rsp),%r12
  1ffc50:	mov    0x100(%rsp),%r8
  1ffc58:	jmp    1ffc68 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x59e8>
  1ffc5a:	nopw   0x0(%rax,%rax,1)
  1ffc60:	inc    %rcx
  1ffc63:	cmp    %rcx,%r14
  1ffc66:	je     1ffcd7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5a57>
  1ffc68:	cmp    %rcx,0xf0(%rsp)
  1ffc70:	je     200f51 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6cd1>
  1ffc76:	mov    (%r9,%rcx,8),%rdi
  1ffc7a:	lea    (%rdi,%rdx,1),%rax
  1ffc7e:	cmp    %rbx,%rax
  1ffc81:	jae    200f69 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6ce9>
  1ffc87:	shl    $0x4,%rax
  1ffc8b:	movsd  0x0(%rbp,%rax,1),%xmm1
  1ffc91:	ucomisd %xmm0,%xmm1
  1ffc95:	jne    1ffcc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5a40>
  1ffc97:	jp     1ffcc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5a40>
  1ffc99:	add    %rbp,%rax
  1ffc9c:	movsd  0x8(%rax),%xmm1
  1ffca1:	ucomisd %xmm0,%xmm1
  1ffca5:	jne    1ffcc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5a40>
  1ffca7:	jp     1ffcc0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5a40>
  1ffca9:	cmp    %r11,%rdi
  1ffcac:	jae    2019b9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7739>
  1ffcb2:	movq   $0x7d,(%r8,%rdi,8)
  1ffcba:	jmp    1ffc60 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x59e0>
  1ffcbc:	nopl   0x0(%rax)
  1ffcc0:	cmp    0xf0(%rsp),%r13
  1ffcc8:	jae    201578 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x72f8>
  1ffcce:	mov    %rdi,(%r9,%r13,8)
  1ffcd2:	inc    %r13
  1ffcd5:	jmp    1ffc60 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x59e0>
  1ffcd7:	cmp    0xf0(%rsp),%r13
  1ffcdf:	ja     200752 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x64d2>
  1ffce5:	test   %r13,%r13
  1ffce8:	je     2000de <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5e5e>
  1ffcee:	shl    $0x3,%r13
  1ffcf2:	mov    0x8(%rsp),%r12
  1ffcf7:	lea    (%r12,%r12,1),%rax
  1ffcfb:	shl    $0x7,%r12
  1ffcff:	mov    %r12,0x20(%rsp)
  1ffd04:	sub    %rax,%r12
  1ffd07:	xor    %r15d,%r15d
  1ffd0a:	movapd 0x1f962ed(%rip),%xmm8        # 2196000 <_fini+0x520>
  1ffd13:	xorpd  %xmm9,%xmm9
  1ffd18:	movsd  0x1f979a7(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1ffd21:	movapd 0x1f962e6(%rip),%xmm11        # 2196010 <_fini+0x530>
  1ffd2a:	movsd  0x1f9798d(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1ffd33:	movabs $0x7fffffffffffffff,%r11
  1ffd3d:	nopl   (%rax)
  1ffd40:	mov    (%r9,%r15,1),%r14
  1ffd44:	cmp    %rbx,%r14
  1ffd47:	jae    2014b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7230>
  1ffd4d:	mov    %r14,%rdi
  1ffd50:	shl    $0x4,%rdi
  1ffd54:	movupd 0x0(%rbp,%rdi,1),%xmm0
  1ffd5a:	movapd %xmm0,%xmm2
  1ffd5e:	andpd  %xmm8,%xmm2
  1ffd63:	movapd %xmm0,%xmm1
  1ffd67:	unpckhpd %xmm0,%xmm1
  1ffd6b:	movapd %xmm1,%xmm3
  1ffd6f:	andpd  %xmm8,%xmm3
  1ffd74:	ucomisd %xmm9,%xmm0
  1ffd79:	je     1ffdf0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5b70>
  1ffd7b:	ucomisd %xmm9,%xmm1
  1ffd80:	je     1ffdf0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5b70>
  1ffd82:	movapd %xmm2,%xmm4
  1ffd86:	cmplesd %xmm3,%xmm4
  1ffd8b:	movapd %xmm4,%xmm5
  1ffd8f:	andpd  %xmm3,%xmm5
  1ffd93:	andnpd %xmm2,%xmm4
  1ffd97:	orpd   %xmm5,%xmm4
  1ffd9b:	ucomisd %xmm6,%xmm4
  1ffd9f:	jbe    1ffdf0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5b70>
  1ffda1:	ucomisd %xmm4,%xmm7
  1ffda5:	jbe    1ffdf0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5b70>
  1ffda7:	movapd %xmm0,%xmm2
  1ffdab:	mulpd  %xmm0,%xmm2
  1ffdaf:	movapd %xmm2,%xmm3
  1ffdb3:	unpckhpd %xmm2,%xmm3
  1ffdb7:	addsd  %xmm2,%xmm3
  1ffdbb:	movapd %xmm10,%xmm2
  1ffdc0:	divsd  %xmm3,%xmm2
  1ffdc4:	mulsd  %xmm2,%xmm0
  1ffdc8:	xorpd  %xmm11,%xmm1
  1ffdcd:	mulsd  %xmm2,%xmm1
  1ffdd1:	add    %r12,%r14
  1ffdd4:	cmp    %rbx,%r14
  1ffdd7:	jb     1fff10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5c90>
  1ffddd:	jmp    1fffb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5d30>
  1ffde2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ffdf0:	ucomisd %xmm9,%xmm1
  1ffdf5:	setnp  %al
  1ffdf8:	sete   %cl
  1ffdfb:	and    %al,%cl
  1ffdfd:	movq   %xmm0,%rax
  1ffe02:	and    %r11,%rax
  1ffe05:	movabs $0x7ff0000000000000,%rsi
  1ffe0f:	cmp    %rsi,%rax
  1ffe12:	setl   %dl
  1ffe15:	test   %dl,%cl
  1ffe17:	je     1ffe40 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5bc0>
  1ffe19:	movapd %xmm10,%xmm2
  1ffe1e:	divsd  %xmm0,%xmm2
  1ffe22:	xorpd  %xmm11,%xmm1
  1ffe27:	movapd %xmm2,%xmm0
  1ffe2b:	add    %r12,%r14
  1ffe2e:	cmp    %rbx,%r14
  1ffe31:	jb     1fff10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5c90>
  1ffe37:	jmp    1fffb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5d30>
  1ffe3c:	nopl   0x0(%rax)
  1ffe40:	ucomisd %xmm9,%xmm0
  1ffe45:	setnp  %cl
  1ffe48:	sete   %dl
  1ffe4b:	and    %cl,%dl
  1ffe4d:	movq   %xmm1,%rcx
  1ffe52:	and    %r11,%rcx
  1ffe55:	cmp    %rsi,%rcx
  1ffe58:	setl   %sil
  1ffe5c:	test   %sil,%dl
  1ffe5f:	je     1ffe7f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5bff>
  1ffe61:	movapd %xmm12,%xmm2
  1ffe66:	divsd  %xmm1,%xmm2
  1ffe6a:	movapd %xmm2,%xmm1
  1ffe6e:	add    %r12,%r14
  1ffe71:	cmp    %rbx,%r14
  1ffe74:	jb     1fff10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5c90>
  1ffe7a:	jmp    1fffb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5d30>
  1ffe7f:	movabs $0x7fefffffffffffff,%rdx
  1ffe89:	cmp    %rdx,%rax
  1ffe8c:	setg   %al
  1ffe8f:	cmp    %rdx,%rcx
  1ffe92:	setg   %cl
  1ffe95:	or     %al,%cl
  1ffe97:	cmp    $0x1,%cl
  1ffe9a:	jne    1fff34 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5cb4>
  1ffea0:	add    %rbp,%rdi
  1ffea3:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  1ffea8:	movsd  0x1f9780f(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  1ffeb1:	movapd 0x1f96156(%rip),%xmm11        # 2196010 <_fini+0x530>
  1ffeba:	movsd  0x1f97805(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  1ffec3:	xorpd  %xmm9,%xmm9
  1ffec8:	movapd 0x1f9612f(%rip),%xmm8        # 2196000 <_fini+0x520>
  1ffed1:	movsd  0x1f977df(%rip),%xmm7        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  1ffed9:	movsd  0x1f977cf(%rip),%xmm6        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  1ffee1:	movabs $0x7fffffffffffffff,%r11
  1ffeeb:	mov    0x100(%rsp),%r8
  1ffef3:	mov    0x110(%rsp),%r10
  1ffefb:	mov    0x10(%rsp),%r9
  1fff00:	add    %r12,%r14
  1fff03:	cmp    %rbx,%r14
  1fff06:	jae    1fffb0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5d30>
  1fff0c:	nopl   0x0(%rax)
  1fff10:	shl    $0x4,%r14
  1fff14:	movsd  %xmm0,0x0(%rbp,%r14,1)
  1fff1b:	movsd  %xmm1,0x8(%rbp,%r14,1)
  1fff22:	add    $0x8,%r15
  1fff26:	cmp    %r15,%r13
  1fff29:	jne    1ffd40 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5ac0>
  1fff2f:	jmp    1fffc3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5d43>
  1fff34:	ucomisd %xmm9,%xmm1
  1fff39:	jne    1fff41 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5cc1>
  1fff3b:	jnp    1ffe19 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5b99>
  1fff41:	ucomisd %xmm9,%xmm0
  1fff46:	jne    1fff4e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5cce>
  1fff48:	jnp    1ffe61 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5be1>
  1fff4e:	movapd %xmm3,%xmm1
  1fff52:	cmplesd %xmm2,%xmm1
  1fff57:	movapd %xmm1,%xmm4
  1fff5b:	andpd  %xmm2,%xmm4
  1fff5f:	andnpd %xmm3,%xmm1
  1fff63:	orpd   %xmm4,%xmm1
  1fff67:	unpcklpd %xmm1,%xmm1
  1fff6b:	divpd  %xmm1,%xmm0
  1fff6f:	movapd %xmm0,%xmm2
  1fff73:	xorpd  %xmm11,%xmm2
  1fff78:	movsd  %xmm0,%xmm2
  1fff7c:	mulpd  %xmm0,%xmm0
  1fff80:	movapd %xmm0,%xmm3
  1fff84:	unpcklpd %xmm0,%xmm3
  1fff88:	unpckhpd %xmm0,%xmm0
  1fff8c:	addpd  %xmm3,%xmm0
  1fff90:	divpd  %xmm0,%xmm2
  1fff94:	divpd  %xmm1,%xmm2
  1fff98:	movapd %xmm2,%xmm0
  1fff9c:	movapd %xmm2,%xmm1
  1fffa0:	unpckhpd %xmm2,%xmm1
  1fffa4:	add    %r12,%r14
  1fffa7:	cmp    %rbx,%r14
  1fffaa:	jb     1fff10 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5c90>
  1fffb0:	lea    0x242c949(%rip),%rdx        # 262c900 <__gmpfr_one+0x15180>
  1fffb7:	mov    %r14,%rdi
  1fffba:	mov    %rbx,%rsi
  1fffbd:	call   *0x24cef3d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  1fffc3:	cmpq   $0x5,0x118(%rsp)
  1fffcc:	jb     201a76 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x77f6>
  1fffd2:	mov    0x8(%rsp),%rax
  1fffd7:	imul   $0x71,%rax,%rdx
  1fffdb:	mov    0x20(%rsp),%r14
  1fffe0:	sub    %rax,%r14
  1fffe3:	xor    %esi,%esi
  1fffe5:	mov    0x108(%rsp),%r11
  1fffed:	mov    0x30(%rsp),%r15
  1ffff2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  200000:	mov    (%r9,%rsi,1),%rdi
  200004:	lea    (%rdi,%rdx,1),%rax
  200008:	cmp    %rbx,%rax
  20000b:	jae    2014e6 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7266>
  200011:	lea    (%rdi,%r12,1),%rcx
  200015:	cmp    %rbx,%rcx
  200018:	jae    2014d3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7253>
  20001e:	add    %r14,%rdi
  200021:	cmp    %rbx,%rdi
  200024:	jae    2014c3 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7243>
  20002a:	shl    $0x4,%rax
  20002e:	shl    $0x4,%rcx
  200032:	movupd 0x40(%r10),%xmm0
  200038:	movupd 0x0(%rbp,%rax,1),%xmm1
  20003e:	movapd %xmm0,%xmm2
  200042:	mulpd  %xmm1,%xmm2
  200046:	shl    $0x4,%rdi
  20004a:	movupd 0x0(%rbp,%rcx,1),%xmm3
  200050:	movapd %xmm2,%xmm4
  200054:	unpcklpd %xmm2,%xmm4
  200058:	unpckhpd %xmm2,%xmm2
  20005c:	subpd  %xmm2,%xmm4
  200060:	mulpd  %xmm3,%xmm4
  200064:	movapd %xmm0,%xmm2
  200068:	unpckhpd %xmm0,%xmm2
  20006c:	mulsd  %xmm1,%xmm2
  200070:	unpckhpd %xmm1,%xmm1
  200074:	mulsd  %xmm0,%xmm1
  200078:	addsd  %xmm2,%xmm1
  20007c:	unpcklpd %xmm1,%xmm1
  200080:	shufpd $0x1,%xmm3,%xmm3
  200085:	mulpd  %xmm1,%xmm3
  200089:	movapd %xmm4,%xmm0
  20008d:	subpd  %xmm3,%xmm0
  200091:	addpd  %xmm4,%xmm3
  200095:	movsd  %xmm0,%xmm3
  200099:	movupd %xmm3,0x0(%rbp,%rdi,1)
  20009f:	add    $0x8,%rsi
  2000a3:	cmp    %rsi,%r13
  2000a6:	jne    200000 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5d80>
  2000ac:	xor    %eax,%eax
  2000ae:	mov    0x38(%rsp),%r12
  2000b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2000c0:	mov    (%r9,%rax,1),%rdi
  2000c4:	cmp    %r11,%rdi
  2000c7:	jae    2014f9 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7279>
  2000cd:	movq   $0x80,(%r8,%rdi,8)
  2000d5:	add    $0x8,%rax
  2000d9:	cmp    %rax,%r13
  2000dc:	jne    2000c0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5e40>
  2000de:	xor    %eax,%eax
  2000e0:	xor    %esi,%esi
  2000e2:	mov    0x8(%rsp),%rcx
  2000e7:	jmp    200100 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5e80>
  2000e9:	nopl   0x0(%rax)
  2000f0:	mov    %rdi,(%r9,%rsi,8)
  2000f4:	inc    %rsi
  2000f7:	add    $0x8,%rax
  2000fb:	cmp    %rax,%r15
  2000fe:	je     200136 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5eb6>
  200100:	mov    (%r12,%rax,1),%rdi
  200104:	cmp    %r11,%rdi
  200107:	jae    200905 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6685>
  20010d:	cmpq   $0x7e,(%r8,%rdi,8)
  200112:	jae    2000f7 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5e77>
  200114:	cmp    0xf0(%rsp),%rsi
  20011c:	jb     2000f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5e70>
  20011e:	lea    0x242c86b(%rip),%rdx        # 262c990 <__gmpfr_one+0x15210>
  200125:	mov    %rsi,%rdi
  200128:	mov    0xf0(%rsp),%rsi
  200130:	call   *0x24cedca(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200136:	mov    0xf0(%rsp),%rdx
  20013e:	cmp    %rdx,%rsi
  200141:	ja     200692 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6412>
  200147:	test   %rsi,%rsi
  20014a:	je     200463 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x61e3>
  200150:	mov    %rsi,0x18(%rsp)
  200155:	lea    0x0(,%rsi,8),%r12
  20015d:	imul   $0x6f,%rcx,%r14
  200161:	mov    %rcx,%rax
  200164:	shl    $0x7,%rax
  200168:	lea    (%rax,%rcx,2),%rax
  20016c:	mov    %rax,0x20(%rsp)
  200171:	xor    %r13d,%r13d
  200174:	movapd 0x1f95e84(%rip),%xmm6        # 2196000 <_fini+0x520>
  20017c:	xorpd  %xmm7,%xmm7
  200180:	movsd  0x1f97527(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  200189:	movsd  0x1f97526(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  200192:	movsd  0x1f9752d(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  20019b:	movapd 0x1f95e6c(%rip),%xmm11        # 2196010 <_fini+0x530>
  2001a4:	movsd  0x1f97513(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  2001ad:	movabs $0x7fffffffffffffff,%r8
  2001b7:	movabs $0x7ff0000000000000,%r11
  2001c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2001d0:	mov    (%r9,%r13,1),%r15
  2001d4:	lea    (%r15,%r14,1),%rdi
  2001d8:	cmp    %rbx,%rdi
  2001db:	jae    200f7c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6cfc>
  2001e1:	shl    $0x4,%rdi
  2001e5:	movupd 0x0(%rbp,%rdi,1),%xmm0
  2001eb:	movapd %xmm0,%xmm2
  2001ef:	andpd  %xmm6,%xmm2
  2001f3:	movapd %xmm0,%xmm1
  2001f7:	unpckhpd %xmm0,%xmm1
  2001fb:	movapd %xmm1,%xmm3
  2001ff:	andpd  %xmm6,%xmm3
  200203:	ucomisd %xmm7,%xmm0
  200207:	je     200280 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6000>
  200209:	ucomisd %xmm7,%xmm1
  20020d:	je     200280 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6000>
  20020f:	movapd %xmm2,%xmm4
  200213:	cmplesd %xmm3,%xmm4
  200218:	movapd %xmm4,%xmm5
  20021c:	andpd  %xmm3,%xmm5
  200220:	andnpd %xmm2,%xmm4
  200224:	orpd   %xmm5,%xmm4
  200228:	ucomisd %xmm8,%xmm4
  20022d:	jbe    200280 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6000>
  20022f:	ucomisd %xmm4,%xmm9
  200234:	jbe    200280 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6000>
  200236:	movapd %xmm0,%xmm2
  20023a:	mulpd  %xmm0,%xmm2
  20023e:	movapd %xmm2,%xmm3
  200242:	unpckhpd %xmm2,%xmm3
  200246:	addsd  %xmm2,%xmm3
  20024a:	movapd %xmm10,%xmm2
  20024f:	divsd  %xmm3,%xmm2
  200253:	mulsd  %xmm2,%xmm0
  200257:	xorpd  %xmm11,%xmm1
  20025c:	mulsd  %xmm2,%xmm1
  200260:	add    0x20(%rsp),%r15
  200265:	cmp    %rbx,%r15
  200268:	jb     2003b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6130>
  20026e:	jmp    200450 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x61d0>
  200273:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  200280:	ucomisd %xmm7,%xmm1
  200284:	setnp  %al
  200287:	sete   %cl
  20028a:	and    %al,%cl
  20028c:	movq   %xmm0,%rax
  200291:	and    %r8,%rax
  200294:	cmp    %r11,%rax
  200297:	setl   %dl
  20029a:	test   %dl,%cl
  20029c:	je     2002d0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6050>
  20029e:	movapd %xmm10,%xmm2
  2002a3:	divsd  %xmm0,%xmm2
  2002a7:	xorpd  %xmm11,%xmm1
  2002ac:	movapd %xmm2,%xmm0
  2002b0:	add    0x20(%rsp),%r15
  2002b5:	cmp    %rbx,%r15
  2002b8:	jb     2003b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6130>
  2002be:	jmp    200450 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x61d0>
  2002c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2002d0:	ucomisd %xmm7,%xmm0
  2002d4:	setnp  %cl
  2002d7:	sete   %dl
  2002da:	and    %cl,%dl
  2002dc:	movq   %xmm1,%rcx
  2002e1:	and    %r8,%rcx
  2002e4:	cmp    %r11,%rcx
  2002e7:	setl   %sil
  2002eb:	test   %sil,%dl
  2002ee:	je     200310 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6090>
  2002f0:	movapd %xmm12,%xmm2
  2002f5:	divsd  %xmm1,%xmm2
  2002f9:	movapd %xmm2,%xmm1
  2002fd:	add    0x20(%rsp),%r15
  200302:	cmp    %rbx,%r15
  200305:	jb     2003b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6130>
  20030b:	jmp    200450 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x61d0>
  200310:	movabs $0x7fefffffffffffff,%rdx
  20031a:	cmp    %rdx,%rax
  20031d:	setg   %al
  200320:	cmp    %rdx,%rcx
  200323:	setg   %cl
  200326:	or     %al,%cl
  200328:	cmp    $0x1,%cl
  20032b:	jne    2003d4 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6154>
  200331:	add    %rbp,%rdi
  200334:	call   2b1800 <<numerica::domains::float::complex::Complex<f64> as numerica::domains::float::FloatLike>::inv>
  200339:	movsd  0x1f9737e(%rip),%xmm12        # 21976c0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b0>
  200342:	movapd 0x1f95cc5(%rip),%xmm11        # 2196010 <_fini+0x530>
  20034b:	movsd  0x1f97374(%rip),%xmm10        # 21976c8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3b8>
  200354:	movsd  0x1f9735b(%rip),%xmm9        # 21976b8 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a8>
  20035d:	movsd  0x1f9734a(%rip),%xmm8        # 21976b0 <anon.3a236dfbd549ac45bbe4a35c0f68539e.16.llvm.7802576793644093907+0x3a0>
  200366:	xorpd  %xmm7,%xmm7
  20036a:	movapd 0x1f95c8e(%rip),%xmm6        # 2196000 <_fini+0x520>
  200372:	movabs $0x7ff0000000000000,%r11
  20037c:	movabs $0x7fffffffffffffff,%r8
  200386:	mov    0x110(%rsp),%r10
  20038e:	mov    0x10(%rsp),%r9
  200393:	add    0x20(%rsp),%r15
  200398:	cmp    %rbx,%r15
  20039b:	jae    200450 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x61d0>
  2003a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2003b0:	shl    $0x4,%r15
  2003b4:	movsd  %xmm0,0x0(%rbp,%r15,1)
  2003bb:	movsd  %xmm1,0x8(%rbp,%r15,1)
  2003c2:	add    $0x8,%r13
  2003c6:	cmp    %r13,%r12
  2003c9:	jne    2001d0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x5f50>
  2003cf:	jmp    20046a <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x61ea>
  2003d4:	ucomisd %xmm7,%xmm1
  2003d8:	jne    2003e0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6160>
  2003da:	jnp    20029e <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x601e>
  2003e0:	ucomisd %xmm7,%xmm0
  2003e4:	jne    2003ec <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x616c>
  2003e6:	jnp    2002f0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6070>
  2003ec:	movapd %xmm3,%xmm1
  2003f0:	cmplesd %xmm2,%xmm1
  2003f5:	movapd %xmm1,%xmm4
  2003f9:	andpd  %xmm2,%xmm4
  2003fd:	andnpd %xmm3,%xmm1
  200401:	orpd   %xmm4,%xmm1
  200405:	unpcklpd %xmm1,%xmm1
  200409:	divpd  %xmm1,%xmm0
  20040d:	movapd %xmm0,%xmm2
  200411:	xorpd  %xmm11,%xmm2
  200416:	movsd  %xmm0,%xmm2
  20041a:	mulpd  %xmm0,%xmm0
  20041e:	movapd %xmm0,%xmm3
  200422:	unpcklpd %xmm0,%xmm3
  200426:	unpckhpd %xmm0,%xmm0
  20042a:	addpd  %xmm3,%xmm0
  20042e:	divpd  %xmm0,%xmm2
  200432:	divpd  %xmm1,%xmm2
  200436:	movapd %xmm2,%xmm0
  20043a:	movapd %xmm2,%xmm1
  20043e:	unpckhpd %xmm2,%xmm1
  200442:	add    0x20(%rsp),%r15
  200447:	cmp    %rbx,%r15
  20044a:	jb     2003b0 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6130>
  200450:	lea    0x242c569(%rip),%rdx        # 262c9c0 <__gmpfr_one+0x15240>
  200457:	mov    %r15,%rdi
  20045a:	mov    %rbx,%rsi
  20045d:	call   *0x24cea9d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200463:	xor    %ecx,%ecx
  200465:	jmp    200544 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x62c4>
  20046a:	cmpq   $0x0,0x118(%rsp)
  200473:	je     201aee <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x786e>
  200479:	mov    0x8(%rsp),%r8
  20047e:	imul   $0x83,%r8,%rdx
  200485:	xor    %esi,%esi
  200487:	nopw   0x0(%rax,%rax,1)
  200490:	mov    (%r9,%rsi,1),%rdi
  200494:	lea    (%rdi,%r8,1),%rax
  200498:	cmp    %rbx,%rax
  20049b:	jae    201b0f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x788f>
  2004a1:	mov    0x20(%rsp),%rcx
  2004a6:	add    %rdi,%rcx
  2004a9:	cmp    %rbx,%rcx
  2004ac:	jae    200f9c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6d1c>
  2004b2:	add    %rdx,%rdi
  2004b5:	cmp    %rbx,%rdi
  2004b8:	jae    200f8c <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6d0c>
  2004be:	shl    $0x4,%rax
  2004c2:	shl    $0x4,%rcx
  2004c6:	movupd 0x0(%rbp,%rax,1),%xmm0
  2004cc:	movupd (%r10),%xmm1
  2004d1:	movapd %xmm0,%xmm2
  2004d5:	mulpd  %xmm1,%xmm2
  2004d9:	shl    $0x4,%rdi
  2004dd:	movupd 0x0(%rbp,%rcx,1),%xmm3
  2004e3:	movapd %xmm2,%xmm4
  2004e7:	unpcklpd %xmm2,%xmm4
  2004eb:	unpckhpd %xmm2,%xmm2
  2004ef:	subpd  %xmm2,%xmm4
  2004f3:	mulpd  %xmm3,%xmm4
  2004f7:	movapd %xmm1,%xmm2
  2004fb:	unpckhpd %xmm1,%xmm2
  2004ff:	mulsd  %xmm0,%xmm2
  200503:	unpckhpd %xmm0,%xmm0
  200507:	mulsd  %xmm1,%xmm0
  20050b:	addsd  %xmm2,%xmm0
  20050f:	unpcklpd %xmm0,%xmm0
  200513:	shufpd $0x1,%xmm3,%xmm3
  200518:	mulpd  %xmm0,%xmm3
  20051c:	movapd %xmm4,%xmm0
  200520:	subpd  %xmm3,%xmm0
  200524:	addpd  %xmm4,%xmm3
  200528:	movsd  %xmm0,%xmm3
  20052c:	movupd %xmm3,0x0(%rbp,%rdi,1)
  200532:	add    $0x8,%rsi
  200536:	cmp    %rsi,%r12
  200539:	jne    200490 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x6210>
  20053f:	mov    0x18(%rsp),%rcx
  200544:	mov    0xf8(%rsp),%rax
  20054c:	mov    %rcx,(%rax)
  20054f:	add    $0xb8,%rsp
  200556:	pop    %rbx
  200557:	pop    %r12
  200559:	pop    %r13
  20055b:	pop    %r14
  20055d:	pop    %r15
  20055f:	pop    %rbp
  200560:	ret
  200561:	lea    0x242cab8(%rip),%rcx        # 262d020 <__gmpfr_one+0x158a0>
  200568:	xor    %edi,%edi
  20056a:	mov    %r12,%rdx
  20056d:	call   *0x24d0915(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200573:	lea    0x242ca2e(%rip),%rcx        # 262cfa8 <__gmpfr_one+0x15828>
  20057a:	xor    %edi,%edi
  20057c:	mov    %r12,%rdx
  20057f:	call   *0x24d0903(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200585:	lea    0x242c9a4(%rip),%rcx        # 262cf30 <__gmpfr_one+0x157b0>
  20058c:	xor    %edi,%edi
  20058e:	mov    %r14,%rsi
  200591:	mov    %r12,%rdx
  200594:	call   *0x24d08ee(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  20059a:	lea    0x242c977(%rip),%rcx        # 262cf18 <__gmpfr_one+0x15798>
  2005a1:	xor    %edi,%edi
  2005a3:	mov    %r14,%rsi
  2005a6:	mov    %r12,%rdx
  2005a9:	call   *0x24d08d9(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  2005af:	lea    0x242c88a(%rip),%rcx        # 262ce40 <__gmpfr_one+0x156c0>
  2005b6:	xor    %edi,%edi
  2005b8:	mov    %r12,%rdx
  2005bb:	call   *0x24d08c7(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  2005c1:	lea    0x242c800(%rip),%rcx        # 262cdc8 <__gmpfr_one+0x15648>
  2005c8:	xor    %edi,%edi
  2005ca:	mov    %r14,%rsi
  2005cd:	mov    %r12,%rdx
  2005d0:	call   *0x24d08b2(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  2005d6:	lea    0x242c7d3(%rip),%rcx        # 262cdb0 <__gmpfr_one+0x15630>
  2005dd:	xor    %edi,%edi
  2005df:	mov    %r12,%rdx
  2005e2:	call   *0x24d08a0(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  2005e8:	lea    0x242c749(%rip),%rcx        # 262cd38 <__gmpfr_one+0x155b8>
  2005ef:	xor    %edi,%edi
  2005f1:	mov    %r14,%rsi
  2005f4:	mov    %r12,%rdx
  2005f7:	call   *0x24d088b(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  2005fd:	lea    0x242c6bc(%rip),%rcx        # 262ccc0 <__gmpfr_one+0x15540>
  200604:	xor    %edi,%edi
  200606:	mov    %r14,%rsi
  200609:	mov    %r12,%rdx
  20060c:	call   *0x24d0876(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200612:	lea    0x242c62f(%rip),%rcx        # 262cc48 <__gmpfr_one+0x154c8>
  200619:	xor    %edi,%edi
  20061b:	mov    %r13,%rsi
  20061e:	mov    %r12,%rdx
  200621:	call   *0x24d0861(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200627:	lea    0x242c602(%rip),%rcx        # 262cc30 <__gmpfr_one+0x154b0>
  20062e:	xor    %edi,%edi
  200630:	mov    %r14,%rsi
  200633:	mov    %r12,%rdx
  200636:	call   *0x24d084c(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  20063c:	lea    0x242c5d5(%rip),%rcx        # 262cc18 <__gmpfr_one+0x15498>
  200643:	xor    %edi,%edi
  200645:	mov    %r14,%rsi
  200648:	mov    %r12,%rdx
  20064b:	call   *0x24d0837(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200651:	lea    0x242c548(%rip),%rcx        # 262cba0 <__gmpfr_one+0x15420>
  200658:	xor    %edi,%edi
  20065a:	mov    %r14,%rsi
  20065d:	mov    %r12,%rdx
  200660:	call   *0x24d0822(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200666:	lea    0x242c51b(%rip),%rcx        # 262cb88 <__gmpfr_one+0x15408>
  20066d:	xor    %edi,%edi
  20066f:	mov    %r14,%rsi
  200672:	mov    %r12,%rdx
  200675:	call   *0x24d080d(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  20067b:	lea    0x242c42e(%rip),%rcx        # 262cab0 <__gmpfr_one+0x15330>
  200682:	xor    %edi,%edi
  200684:	mov    0xf0(%rsp),%rdx
  20068c:	call   *0x24d07f6(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200692:	lea    0x242c387(%rip),%rcx        # 262ca20 <__gmpfr_one+0x152a0>
  200699:	xor    %edi,%edi
  20069b:	call   *0x24d07e7(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  2006a1:	lea    0x242c918(%rip),%rcx        # 262cfc0 <__gmpfr_one+0x15840>
  2006a8:	xor    %edi,%edi
  2006aa:	mov    %r12,%rdx
  2006ad:	call   *0x24d07d5(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  2006b3:	lea    0x242c88e(%rip),%rcx        # 262cf48 <__gmpfr_one+0x157c8>
  2006ba:	xor    %edi,%edi
  2006bc:	mov    %r14,%rsi
  2006bf:	mov    %r12,%rdx
  2006c2:	call   *0x24d07c0(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  2006c8:	lea    0x242c7e9(%rip),%rcx        # 262ceb8 <__gmpfr_one+0x15738>
  2006cf:	xor    %edi,%edi
  2006d1:	mov    %r12,%rdx
  2006d4:	call   *0x24d07ae(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  2006da:	lea    0x242c6ff(%rip),%rcx        # 262cde0 <__gmpfr_one+0x15660>
  2006e1:	xor    %edi,%edi
  2006e3:	mov    %r14,%rsi
  2006e6:	mov    %r12,%rdx
  2006e9:	call   *0x24d0799(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  2006ef:	lea    0x242c65a(%rip),%rcx        # 262cd50 <__gmpfr_one+0x155d0>
  2006f6:	xor    %edi,%edi
  2006f8:	mov    %r12,%rdx
  2006fb:	call   *0x24d0787(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200701:	lea    0x242c5d0(%rip),%rcx        # 262ccd8 <__gmpfr_one+0x15558>
  200708:	xor    %edi,%edi
  20070a:	mov    %r13,%rsi
  20070d:	mov    %r12,%rdx
  200710:	call   *0x24d0772(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200716:	lea    0x242c543(%rip),%rcx        # 262cc60 <__gmpfr_one+0x154e0>
  20071d:	xor    %edi,%edi
  20071f:	mov    %r12,%rdx
  200722:	call   *0x24d0760(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200728:	lea    0x242c489(%rip),%rcx        # 262cbb8 <__gmpfr_one+0x15438>
  20072f:	xor    %edi,%edi
  200731:	mov    %r13,%rsi
  200734:	mov    %r12,%rdx
  200737:	call   *0x24d074b(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  20073d:	lea    0x242c3e4(%rip),%rcx        # 262cb28 <__gmpfr_one+0x153a8>
  200744:	xor    %edi,%edi
  200746:	mov    %r13,%rsi
  200749:	mov    %r12,%rdx
  20074c:	call   *0x24d0736(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200752:	lea    0x242c2df(%rip),%rcx        # 262ca38 <__gmpfr_one+0x152b8>
  200759:	xor    %edi,%edi
  20075b:	mov    %r13,%rsi
  20075e:	mov    0xf0(%rsp),%rdx
  200766:	call   *0x24d071c(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  20076c:	lea    0x242c6e5(%rip),%rcx        # 262ce58 <__gmpfr_one+0x156d8>
  200773:	xor    %edi,%edi
  200775:	mov    %r12,%rdx
  200778:	call   *0x24d070a(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  20077e:	lea    0x242c343(%rip),%rcx        # 262cac8 <__gmpfr_one+0x15348>
  200785:	xor    %edi,%edi
  200787:	mov    %r12,%rdx
  20078a:	call   *0x24d06f8(%rip)        # 26d0e88 <_GLOBAL_OFFSET_TABLE_+0x59f8>
  200790:	lea    0x242c961(%rip),%rdx        # 262d0f8 <__gmpfr_one+0x15978>
  200797:	mov    %r12,%rdi
  20079a:	mov    %r12,%rsi
  20079d:	call   *0x24ce75d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2007a3:	lea    0x242c966(%rip),%rdx        # 262d110 <__gmpfr_one+0x15990>
  2007aa:	mov    %rbx,%rsi
  2007ad:	call   *0x24ce74d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2007b3:	lea    0x242af76(%rip),%rdx        # 262b730 <__gmpfr_one+0x13fb0>
  2007ba:	mov    %rax,%rdi
  2007bd:	mov    %r11,%rsi
  2007c0:	call   *0x24ce73a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2007c6:	lea    0x242af93(%rip),%rdx        # 262b760 <__gmpfr_one+0x13fe0>
  2007cd:	mov    %r11,%rsi
  2007d0:	call   *0x24ce72a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2007d6:	lea    0x242b11b(%rip),%rdx        # 262b8f8 <__gmpfr_one+0x14178>
  2007dd:	mov    %r11,%rsi
  2007e0:	call   *0x24ce71a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2007e6:	lea    0x242b1b3(%rip),%rdx        # 262b9a0 <__gmpfr_one+0x14220>
  2007ed:	mov    %r11,%rsi
  2007f0:	call   *0x24ce70a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2007f6:	lea    0x242b39b(%rip),%rdx        # 262bb98 <__gmpfr_one+0x14418>
  2007fd:	mov    %rax,%rdi
  200800:	mov    %r11,%rsi
  200803:	call   *0x24ce6f7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200809:	lea    0x242b3b8(%rip),%rdx        # 262bbc8 <__gmpfr_one+0x14448>
  200810:	mov    %r11,%rsi
  200813:	call   *0x24ce6e7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200819:	lea    0x242b540(%rip),%rdx        # 262bd60 <__gmpfr_one+0x145e0>
  200820:	mov    %r11,%rsi
  200823:	call   *0x24ce6d7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200829:	lea    0x242b5d8(%rip),%rdx        # 262be08 <__gmpfr_one+0x14688>
  200830:	mov    %r11,%rsi
  200833:	call   *0x24ce6c7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200839:	lea    0x242b6a0(%rip),%rdx        # 262bee0 <__gmpfr_one+0x14760>
  200840:	mov    %rax,%rdi
  200843:	mov    %r11,%rsi
  200846:	call   *0x24ce6b4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20084c:	lea    0x242b6bd(%rip),%rdx        # 262bf10 <__gmpfr_one+0x14790>
  200853:	mov    %r11,%rsi
  200856:	call   *0x24ce6a4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20085c:	lea    0x242b7fd(%rip),%rdx        # 262c060 <__gmpfr_one+0x148e0>
  200863:	mov    %r11,%rsi
  200866:	call   *0x24ce694(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20086c:	lea    0x242b8dd(%rip),%rdx        # 262c150 <__gmpfr_one+0x149d0>
  200873:	mov    %rax,%rdi
  200876:	mov    %r11,%rsi
  200879:	call   *0x24ce681(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20087f:	lea    0x242b8fa(%rip),%rdx        # 262c180 <__gmpfr_one+0x14a00>
  200886:	mov    %r11,%rsi
  200889:	call   *0x24ce671(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20088f:	lea    0x242bab2(%rip),%rdx        # 262c348 <__gmpfr_one+0x14bc8>
  200896:	mov    %r11,%rsi
  200899:	call   *0x24ce661(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20089f:	lea    0x242bb4a(%rip),%rdx        # 262c3f0 <__gmpfr_one+0x14c70>
  2008a6:	mov    %rax,%rdi
  2008a9:	mov    %r11,%rsi
  2008ac:	call   *0x24ce64e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2008b2:	lea    0x242bb67(%rip),%rdx        # 262c420 <__gmpfr_one+0x14ca0>
  2008b9:	mov    %r11,%rsi
  2008bc:	call   *0x24ce63e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2008c2:	lea    0x242bc47(%rip),%rdx        # 262c510 <__gmpfr_one+0x14d90>
  2008c9:	mov    %r11,%rsi
  2008cc:	call   *0x24ce62e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2008d2:	lea    0x242bcdf(%rip),%rdx        # 262c5b8 <__gmpfr_one+0x14e38>
  2008d9:	mov    %r11,%rsi
  2008dc:	call   *0x24ce61e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2008e2:	lea    0x242bec7(%rip),%rdx        # 262c7b0 <__gmpfr_one+0x15030>
  2008e9:	mov    %rax,%rdi
  2008ec:	mov    %r11,%rsi
  2008ef:	call   *0x24ce60b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2008f5:	lea    0x242bee4(%rip),%rdx        # 262c7e0 <__gmpfr_one+0x15060>
  2008fc:	mov    %r11,%rsi
  2008ff:	call   *0x24ce5fb(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200905:	lea    0x242c06c(%rip),%rdx        # 262c978 <__gmpfr_one+0x151f8>
  20090c:	mov    %r11,%rsi
  20090f:	call   *0x24ce5eb(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200915:	lea    0x242c77c(%rip),%rdx        # 262d098 <__gmpfr_one+0x15918>
  20091c:	mov    %r12,%rdi
  20091f:	mov    %r12,%rsi
  200922:	call   *0x24ce5d8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200928:	lea    0x242c781(%rip),%rdx        # 262d0b0 <__gmpfr_one+0x15930>
  20092f:	mov    %rsi,%rdi
  200932:	mov    %rbx,%rsi
  200935:	call   *0x24ce5c5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20093b:	lea    0x242ae4e(%rip),%rdx        # 262b790 <__gmpfr_one+0x14010>
  200942:	mov    %rbx,%rsi
  200945:	call   *0x24ce5b5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20094b:	lea    0x242ae86(%rip),%rdx        # 262b7d8 <__gmpfr_one+0x14058>
  200952:	mov    %r14,%rdi
  200955:	mov    %rbx,%rsi
  200958:	call   *0x24ce5a2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20095e:	lea    0x242ae5b(%rip),%rdx        # 262b7c0 <__gmpfr_one+0x14040>
  200965:	mov    %rbx,%rsi
  200968:	call   *0x24ce592(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20096e:	lea    0x242ae93(%rip),%rdx        # 262b808 <__gmpfr_one+0x14088>
  200975:	mov    %rbx,%rsi
  200978:	call   *0x24ce582(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20097e:	lea    0x242ae6b(%rip),%rdx        # 262b7f0 <__gmpfr_one+0x14070>
  200985:	mov    %rax,%rdi
  200988:	mov    %rbx,%rsi
  20098b:	call   *0x24ce56f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200991:	lea    0x242aeb8(%rip),%rdx        # 262b850 <__gmpfr_one+0x140d0>
  200998:	mov    %rbx,%rsi
  20099b:	call   *0x24ce55f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2009a1:	lea    0x242ae90(%rip),%rdx        # 262b838 <__gmpfr_one+0x140b8>
  2009a8:	mov    %rcx,%rdi
  2009ab:	mov    %rbx,%rsi
  2009ae:	call   *0x24ce54c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2009b4:	lea    0x242ae65(%rip),%rdx        # 262b820 <__gmpfr_one+0x140a0>
  2009bb:	mov    %rax,%rdi
  2009be:	mov    %rbx,%rsi
  2009c1:	call   *0x24ce539(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2009c7:	lea    0x242c592(%rip),%rdx        # 262cf60 <__gmpfr_one+0x157e0>
  2009ce:	mov    %rax,%rdi
  2009d1:	mov    %rbx,%rsi
  2009d4:	call   *0x24ce526(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2009da:	lea    0x242af47(%rip),%rdx        # 262b928 <__gmpfr_one+0x141a8>
  2009e1:	mov    %r13,%rdi
  2009e4:	mov    %rbx,%rsi
  2009e7:	call   *0x24ce513(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2009ed:	lea    0x242af94(%rip),%rdx        # 262b988 <__gmpfr_one+0x14208>
  2009f4:	mov    %rbx,%rsi
  2009f7:	call   *0x24ce503(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2009fd:	lea    0x242af6c(%rip),%rdx        # 262b970 <__gmpfr_one+0x141f0>
  200a04:	mov    %rcx,%rdi
  200a07:	mov    %rbx,%rsi
  200a0a:	call   *0x24ce4f0(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200a10:	lea    0x242af41(%rip),%rdx        # 262b958 <__gmpfr_one+0x141d8>
  200a17:	mov    %rax,%rdi
  200a1a:	mov    %rbx,%rsi
  200a1d:	call   *0x24ce4dd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200a23:	lea    0x242afa6(%rip),%rdx        # 262b9d0 <__gmpfr_one+0x14250>
  200a2a:	mov    %rbx,%rsi
  200a2d:	call   *0x24ce4cd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200a33:	lea    0x242c496(%rip),%rdx        # 262ced0 <__gmpfr_one+0x15750>
  200a3a:	mov    %rax,%rdi
  200a3d:	mov    %rbx,%rsi
  200a40:	call   *0x24ce4ba(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200a46:	lea    0x242b1ab(%rip),%rdx        # 262bbf8 <__gmpfr_one+0x14478>
  200a4d:	mov    %rbx,%rsi
  200a50:	call   *0x24ce4aa(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200a56:	lea    0x242b1e3(%rip),%rdx        # 262bc40 <__gmpfr_one+0x144c0>
  200a5d:	mov    %r14,%rdi
  200a60:	mov    %rbx,%rsi
  200a63:	call   *0x24ce497(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200a69:	lea    0x242b1b8(%rip),%rdx        # 262bc28 <__gmpfr_one+0x144a8>
  200a70:	mov    %rbx,%rsi
  200a73:	call   *0x24ce487(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200a79:	lea    0x242b1f0(%rip),%rdx        # 262bc70 <__gmpfr_one+0x144f0>
  200a80:	mov    %rbx,%rsi
  200a83:	call   *0x24ce477(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200a89:	lea    0x242b1c8(%rip),%rdx        # 262bc58 <__gmpfr_one+0x144d8>
  200a90:	mov    %rax,%rdi
  200a93:	mov    %rbx,%rsi
  200a96:	call   *0x24ce464(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200a9c:	lea    0x242b215(%rip),%rdx        # 262bcb8 <__gmpfr_one+0x14538>
  200aa3:	mov    %rbx,%rsi
  200aa6:	call   *0x24ce454(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200aac:	lea    0x242b1ed(%rip),%rdx        # 262bca0 <__gmpfr_one+0x14520>
  200ab3:	mov    %rcx,%rdi
  200ab6:	mov    %rbx,%rsi
  200ab9:	call   *0x24ce441(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200abf:	lea    0x242b1c2(%rip),%rdx        # 262bc88 <__gmpfr_one+0x14508>
  200ac6:	mov    %rax,%rdi
  200ac9:	mov    %rbx,%rsi
  200acc:	call   *0x24ce42e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200ad2:	lea    0x242c31f(%rip),%rdx        # 262cdf8 <__gmpfr_one+0x15678>
  200ad9:	mov    %rax,%rdi
  200adc:	mov    %rbx,%rsi
  200adf:	call   *0x24ce41b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200ae5:	lea    0x242b2a4(%rip),%rdx        # 262bd90 <__gmpfr_one+0x14610>
  200aec:	mov    %r13,%rdi
  200aef:	mov    %rbx,%rsi
  200af2:	call   *0x24ce408(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200af8:	lea    0x242b2f1(%rip),%rdx        # 262bdf0 <__gmpfr_one+0x14670>
  200aff:	mov    %rbx,%rsi
  200b02:	call   *0x24ce3f8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200b08:	lea    0x242b2c9(%rip),%rdx        # 262bdd8 <__gmpfr_one+0x14658>
  200b0f:	mov    %rcx,%rdi
  200b12:	mov    %rbx,%rsi
  200b15:	call   *0x24ce3e5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200b1b:	lea    0x242b29e(%rip),%rdx        # 262bdc0 <__gmpfr_one+0x14640>
  200b22:	mov    %rax,%rdi
  200b25:	mov    %rbx,%rsi
  200b28:	call   *0x24ce3d2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200b2e:	lea    0x242b303(%rip),%rdx        # 262be38 <__gmpfr_one+0x146b8>
  200b35:	mov    %rbx,%rsi
  200b38:	call   *0x24ce3c2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200b3e:	lea    0x242b323(%rip),%rdx        # 262be68 <__gmpfr_one+0x146e8>
  200b45:	mov    %r14,%rdi
  200b48:	mov    %rbx,%rsi
  200b4b:	call   *0x24ce3af(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200b51:	lea    0x242b2f8(%rip),%rdx        # 262be50 <__gmpfr_one+0x146d0>
  200b58:	mov    %rbx,%rsi
  200b5b:	call   *0x24ce39f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200b61:	lea    0x242b348(%rip),%rdx        # 262beb0 <__gmpfr_one+0x14730>
  200b68:	mov    %rbx,%rsi
  200b6b:	call   *0x24ce38f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200b71:	lea    0x242b320(%rip),%rdx        # 262be98 <__gmpfr_one+0x14718>
  200b78:	mov    %rcx,%rdi
  200b7b:	mov    %rbx,%rsi
  200b7e:	call   *0x24ce37c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200b84:	lea    0x242b2f5(%rip),%rdx        # 262be80 <__gmpfr_one+0x14700>
  200b8b:	mov    %rax,%rdi
  200b8e:	mov    %rbx,%rsi
  200b91:	call   *0x24ce369(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200b97:	lea    0x242c1ca(%rip),%rdx        # 262cd68 <__gmpfr_one+0x155e8>
  200b9e:	mov    %rax,%rdi
  200ba1:	mov    %rbx,%rsi
  200ba4:	call   *0x24ce356(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200baa:	lea    0x242b38f(%rip),%rdx        # 262bf40 <__gmpfr_one+0x147c0>
  200bb1:	mov    %rbx,%rsi
  200bb4:	call   *0x24ce346(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200bba:	lea    0x242b3c7(%rip),%rdx        # 262bf88 <__gmpfr_one+0x14808>
  200bc1:	mov    %rbx,%rsi
  200bc4:	call   *0x24ce336(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200bca:	lea    0x242b39f(%rip),%rdx        # 262bf70 <__gmpfr_one+0x147f0>
  200bd1:	mov    %rax,%rdi
  200bd4:	mov    %rbx,%rsi
  200bd7:	call   *0x24ce323(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200bdd:	lea    0x242b3d4(%rip),%rdx        # 262bfb8 <__gmpfr_one+0x14838>
  200be4:	mov    %rbx,%rsi
  200be7:	call   *0x24ce313(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200bed:	lea    0x242b3ac(%rip),%rdx        # 262bfa0 <__gmpfr_one+0x14820>
  200bf4:	mov    %rax,%rdi
  200bf7:	mov    %rbx,%rsi
  200bfa:	call   *0x24ce300(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200c00:	lea    0x242b3f9(%rip),%rdx        # 262c000 <__gmpfr_one+0x14880>
  200c07:	mov    %rbx,%rsi
  200c0a:	call   *0x24ce2f0(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200c10:	lea    0x242b3d1(%rip),%rdx        # 262bfe8 <__gmpfr_one+0x14868>
  200c17:	mov    %rcx,%rdi
  200c1a:	mov    %rbx,%rsi
  200c1d:	call   *0x24ce2dd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200c23:	lea    0x242b3a6(%rip),%rdx        # 262bfd0 <__gmpfr_one+0x14850>
  200c2a:	mov    %rax,%rdi
  200c2d:	mov    %rbx,%rsi
  200c30:	call   *0x24ce2ca(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200c36:	lea    0x242c0b3(%rip),%rdx        # 262ccf0 <__gmpfr_one+0x15570>
  200c3d:	mov    %rax,%rdi
  200c40:	mov    %rbx,%rsi
  200c43:	call   *0x24ce2b7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200c49:	lea    0x242b458(%rip),%rdx        # 262c0a8 <__gmpfr_one+0x14928>
  200c50:	mov    %r13,%rdi
  200c53:	mov    %rbx,%rsi
  200c56:	call   *0x24ce2a4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200c5c:	lea    0x242b42d(%rip),%rdx        # 262c090 <__gmpfr_one+0x14910>
  200c63:	mov    %rbx,%rsi
  200c66:	call   *0x24ce294(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200c6c:	lea    0x242b465(%rip),%rdx        # 262c0d8 <__gmpfr_one+0x14958>
  200c73:	mov    %rbx,%rsi
  200c76:	call   *0x24ce284(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200c7c:	lea    0x242b43d(%rip),%rdx        # 262c0c0 <__gmpfr_one+0x14940>
  200c83:	mov    %rax,%rdi
  200c86:	mov    %rbx,%rsi
  200c89:	call   *0x24ce271(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200c8f:	lea    0x242b48a(%rip),%rdx        # 262c120 <__gmpfr_one+0x149a0>
  200c96:	mov    %rbx,%rsi
  200c99:	call   *0x24ce261(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200c9f:	lea    0x242b462(%rip),%rdx        # 262c108 <__gmpfr_one+0x14988>
  200ca6:	mov    %rcx,%rdi
  200ca9:	mov    %rbx,%rsi
  200cac:	call   *0x24ce24e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200cb2:	lea    0x242b437(%rip),%rdx        # 262c0f0 <__gmpfr_one+0x14970>
  200cb9:	mov    %rax,%rdi
  200cbc:	mov    %rbx,%rsi
  200cbf:	call   *0x24ce23b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200cc5:	lea    0x242bfac(%rip),%rdx        # 262cc78 <__gmpfr_one+0x154f8>
  200ccc:	mov    %rax,%rdi
  200ccf:	mov    %rbx,%rsi
  200cd2:	call   *0x24ce228(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200cd8:	lea    0x242b4d1(%rip),%rdx        # 262c1b0 <__gmpfr_one+0x14a30>
  200cdf:	mov    %rax,%rdi
  200ce2:	mov    %rbx,%rsi
  200ce5:	call   *0x24ce215(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200ceb:	lea    0x242b51e(%rip),%rdx        # 262c210 <__gmpfr_one+0x14a90>
  200cf2:	mov    %rbx,%rsi
  200cf5:	call   *0x24ce205(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200cfb:	lea    0x242b4f6(%rip),%rdx        # 262c1f8 <__gmpfr_one+0x14a78>
  200d02:	mov    %rax,%rdi
  200d05:	mov    %rbx,%rsi
  200d08:	call   *0x24ce1f2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200d0e:	lea    0x242c42b(%rip),%rdx        # 262d140 <__gmpfr_one+0x159c0>
  200d15:	mov    %rax,%rdi
  200d18:	mov    %r12,%rsi
  200d1b:	call   *0x24ce1df(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200d21:	lea    0x242b518(%rip),%rdx        # 262c240 <__gmpfr_one+0x14ac0>
  200d28:	mov    %rbx,%rsi
  200d2b:	call   *0x24ce1cf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200d31:	lea    0x242b4f0(%rip),%rdx        # 262c228 <__gmpfr_one+0x14aa8>
  200d38:	mov    %rax,%rdi
  200d3b:	mov    %rbx,%rsi
  200d3e:	call   *0x24ce1bc(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200d44:	lea    0x242b53d(%rip),%rdx        # 262c288 <__gmpfr_one+0x14b08>
  200d4b:	mov    %rbx,%rsi
  200d4e:	call   *0x24ce1ac(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200d54:	lea    0x242b515(%rip),%rdx        # 262c270 <__gmpfr_one+0x14af0>
  200d5b:	mov    %rcx,%rdi
  200d5e:	mov    %rbx,%rsi
  200d61:	call   *0x24ce199(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200d67:	lea    0x242b4ea(%rip),%rdx        # 262c258 <__gmpfr_one+0x14ad8>
  200d6e:	mov    %rax,%rdi
  200d71:	mov    %rbx,%rsi
  200d74:	call   *0x24ce186(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200d7a:	lea    0x242b537(%rip),%rdx        # 262c2b8 <__gmpfr_one+0x14b38>
  200d81:	mov    %r14,%rdi
  200d84:	mov    %rbx,%rsi
  200d87:	call   *0x24ce173(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200d8d:	lea    0x242b50c(%rip),%rdx        # 262c2a0 <__gmpfr_one+0x14b20>
  200d94:	mov    %rbx,%rsi
  200d97:	call   *0x24ce163(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200d9d:	lea    0x242b544(%rip),%rdx        # 262c2e8 <__gmpfr_one+0x14b68>
  200da4:	mov    %rbx,%rsi
  200da7:	call   *0x24ce153(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200dad:	lea    0x242b51c(%rip),%rdx        # 262c2d0 <__gmpfr_one+0x14b50>
  200db4:	mov    %rax,%rdi
  200db7:	mov    %rbx,%rsi
  200dba:	call   *0x24ce140(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200dc0:	lea    0x242b569(%rip),%rdx        # 262c330 <__gmpfr_one+0x14bb0>
  200dc7:	mov    %rbx,%rsi
  200dca:	call   *0x24ce130(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200dd0:	lea    0x242b541(%rip),%rdx        # 262c318 <__gmpfr_one+0x14b98>
  200dd7:	mov    %rcx,%rdi
  200dda:	mov    %rbx,%rsi
  200ddd:	call   *0x24ce11d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200de3:	lea    0x242b516(%rip),%rdx        # 262c300 <__gmpfr_one+0x14b80>
  200dea:	mov    %rax,%rdi
  200ded:	mov    %rbx,%rsi
  200df0:	call   *0x24ce10a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200df6:	lea    0x242b57b(%rip),%rdx        # 262c378 <__gmpfr_one+0x14bf8>
  200dfd:	mov    %rbx,%rsi
  200e00:	call   *0x24ce0fa(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200e06:	lea    0x242b5b3(%rip),%rdx        # 262c3c0 <__gmpfr_one+0x14c40>
  200e0d:	mov    %rbx,%rsi
  200e10:	call   *0x24ce0ea(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200e16:	lea    0x242b58b(%rip),%rdx        # 262c3a8 <__gmpfr_one+0x14c28>
  200e1d:	mov    %rcx,%rdi
  200e20:	mov    %rbx,%rsi
  200e23:	call   *0x24ce0d7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200e29:	lea    0x242b560(%rip),%rdx        # 262c390 <__gmpfr_one+0x14c10>
  200e30:	mov    %rax,%rdi
  200e33:	mov    %rbx,%rsi
  200e36:	call   *0x24ce0c4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200e3c:	lea    0x242b595(%rip),%rdx        # 262c3d8 <__gmpfr_one+0x14c58>
  200e43:	mov    %r11,%rsi
  200e46:	call   *0x24ce0b4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200e4c:	lea    0x242b5fd(%rip),%rdx        # 262c450 <__gmpfr_one+0x14cd0>
  200e53:	mov    %rbx,%rsi
  200e56:	call   *0x24ce0a4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200e5c:	lea    0x242bd6d(%rip),%rdx        # 262cbd0 <__gmpfr_one+0x15450>
  200e63:	mov    %rax,%rdi
  200e66:	mov    %rbx,%rsi
  200e69:	call   *0x24ce091(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200e6f:	lea    0x242b6ca(%rip),%rdx        # 262c540 <__gmpfr_one+0x14dc0>
  200e76:	mov    %rbx,%rsi
  200e79:	call   *0x24ce081(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200e7f:	lea    0x242b71a(%rip),%rdx        # 262c5a0 <__gmpfr_one+0x14e20>
  200e86:	mov    %rbx,%rsi
  200e89:	call   *0x24ce071(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200e8f:	lea    0x242b6f2(%rip),%rdx        # 262c588 <__gmpfr_one+0x14e08>
  200e96:	mov    %rcx,%rdi
  200e99:	mov    %rbx,%rsi
  200e9c:	call   *0x24ce05e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200ea2:	lea    0x242b73f(%rip),%rdx        # 262c5e8 <__gmpfr_one+0x14e68>
  200ea9:	mov    %rbx,%rsi
  200eac:	call   *0x24ce04e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200eb2:	lea    0x242bc87(%rip),%rdx        # 262cb40 <__gmpfr_one+0x153c0>
  200eb9:	mov    %rax,%rdi
  200ebc:	mov    %rbx,%rsi
  200ebf:	call   *0x24ce03b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200ec5:	lea    0x242b944(%rip),%rdx        # 262c810 <__gmpfr_one+0x15090>
  200ecc:	mov    %rbx,%rsi
  200ecf:	call   *0x24ce02b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200ed5:	lea    0x242b97c(%rip),%rdx        # 262c858 <__gmpfr_one+0x150d8>
  200edc:	mov    %r13,%rdi
  200edf:	mov    %rbx,%rsi
  200ee2:	call   *0x24ce018(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200ee8:	lea    0x242b951(%rip),%rdx        # 262c840 <__gmpfr_one+0x150c0>
  200eef:	mov    %rbx,%rsi
  200ef2:	call   *0x24ce008(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200ef8:	lea    0x242b989(%rip),%rdx        # 262c888 <__gmpfr_one+0x15108>
  200eff:	mov    %rbx,%rsi
  200f02:	call   *0x24cdff8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200f08:	lea    0x242b961(%rip),%rdx        # 262c870 <__gmpfr_one+0x150f0>
  200f0f:	mov    %rax,%rdi
  200f12:	mov    %rbx,%rsi
  200f15:	call   *0x24cdfe5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200f1b:	lea    0x242b9ae(%rip),%rdx        # 262c8d0 <__gmpfr_one+0x15150>
  200f22:	mov    %rbx,%rsi
  200f25:	call   *0x24cdfd5(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200f2b:	lea    0x242b986(%rip),%rdx        # 262c8b8 <__gmpfr_one+0x15138>
  200f32:	mov    %rcx,%rdi
  200f35:	mov    %rbx,%rsi
  200f38:	call   *0x24cdfc2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200f3e:	lea    0x242b95b(%rip),%rdx        # 262c8a0 <__gmpfr_one+0x15120>
  200f45:	mov    %rax,%rdi
  200f48:	mov    %rbx,%rsi
  200f4b:	call   *0x24cdfaf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200f51:	lea    0x242baf8(%rip),%rdx        # 262ca50 <__gmpfr_one+0x152d0>
  200f58:	mov    0xf0(%rsp),%rdi
  200f60:	mov    %rdi,%rsi
  200f63:	call   *0x24cdf97(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200f69:	lea    0x242baf8(%rip),%rdx        # 262ca68 <__gmpfr_one+0x152e8>
  200f70:	mov    %rax,%rdi
  200f73:	mov    %rbx,%rsi
  200f76:	call   *0x24cdf84(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200f7c:	lea    0x242ba25(%rip),%rdx        # 262c9a8 <__gmpfr_one+0x15228>
  200f83:	mov    %rbx,%rsi
  200f86:	call   *0x24cdf74(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200f8c:	lea    0x242ba75(%rip),%rdx        # 262ca08 <__gmpfr_one+0x15288>
  200f93:	mov    %rbx,%rsi
  200f96:	call   *0x24cdf64(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200f9c:	lea    0x242ba4d(%rip),%rdx        # 262c9f0 <__gmpfr_one+0x15270>
  200fa3:	mov    %rcx,%rdi
  200fa6:	mov    %rbx,%rsi
  200fa9:	call   *0x24cdf51(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200faf:	lea    0x242aa02(%rip),%rdx        # 262b9b8 <__gmpfr_one+0x14238>
  200fb6:	mov    %r14,%rdi
  200fb9:	mov    %r12,%rsi
  200fbc:	call   *0x24cdf3e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200fc2:	lea    0x242ac17(%rip),%rdx        # 262bbe0 <__gmpfr_one+0x14460>
  200fc9:	mov    %rsi,%rdi
  200fcc:	mov    %r12,%rsi
  200fcf:	call   *0x24cdf2b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200fd5:	lea    0x242b09c(%rip),%rdx        # 262c078 <__gmpfr_one+0x148f8>
  200fdc:	mov    %r14,%rdi
  200fdf:	mov    %r12,%rsi
  200fe2:	call   *0x24cdf18(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200fe8:	lea    0x242b1a9(%rip),%rdx        # 262c198 <__gmpfr_one+0x14a18>
  200fef:	mov    %r13,%rdi
  200ff2:	mov    %r12,%rsi
  200ff5:	call   *0x24cdf05(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  200ffb:	lea    0x242b526(%rip),%rdx        # 262c528 <__gmpfr_one+0x14da8>
  201002:	mov    %r14,%rdi
  201005:	mov    %r12,%rsi
  201008:	call   *0x24cdef2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20100e:	lea    0x242a32b(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201015:	mov    $0x3,%edi
  20101a:	mov    0x118(%rsp),%rsi
  201022:	call   *0x24cded8(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201028:	lea    0x242b799(%rip),%rdx        # 262c7c8 <__gmpfr_one+0x15048>
  20102f:	mov    0xf0(%rsp),%rsi
  201037:	call   *0x24cdec3(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20103d:	lea    0x242a2fc(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201044:	mov    $0x3,%edi
  201049:	mov    0x118(%rsp),%rsi
  201051:	call   *0x24cdea9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201057:	lea    0x242c0ca(%rip),%rdx        # 262d128 <__gmpfr_one+0x159a8>
  20105e:	mov    %r11,%rsi
  201061:	call   *0x24cde99(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201067:	lea    0x242bfca(%rip),%rdx        # 262d038 <__gmpfr_one+0x158b8>
  20106e:	mov    %r12,%rdi
  201071:	mov    %r12,%rsi
  201074:	call   *0x24cde86(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20107a:	lea    0x242bfcf(%rip),%rdx        # 262d050 <__gmpfr_one+0x158d0>
  201081:	mov    %rcx,%rdi
  201084:	mov    %rbx,%rsi
  201087:	call   *0x24cde73(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20108d:	lea    0x242a7d4(%rip),%rdx        # 262b868 <__gmpfr_one+0x140e8>
  201094:	mov    %rbx,%rsi
  201097:	call   *0x24cde63(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20109d:	lea    0x242a824(%rip),%rdx        # 262b8c8 <__gmpfr_one+0x14148>
  2010a4:	mov    %rbx,%rsi
  2010a7:	call   *0x24cde53(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2010ad:	lea    0x242a7fc(%rip),%rdx        # 262b8b0 <__gmpfr_one+0x14130>
  2010b4:	mov    %rax,%rdi
  2010b7:	mov    %rbx,%rsi
  2010ba:	call   *0x24cde40(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2010c0:	lea    0x242a7d1(%rip),%rdx        # 262b898 <__gmpfr_one+0x14118>
  2010c7:	mov    %rcx,%rdi
  2010ca:	mov    %rbx,%rsi
  2010cd:	call   *0x24cde2d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2010d3:	lea    0x242a806(%rip),%rdx        # 262b8e0 <__gmpfr_one+0x14160>
  2010da:	mov    %r11,%rsi
  2010dd:	call   *0x24cde1d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2010e3:	lea    0x242a916(%rip),%rdx        # 262ba00 <__gmpfr_one+0x14280>
  2010ea:	mov    %rbx,%rsi
  2010ed:	call   *0x24cde0d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2010f3:	lea    0x242a8ee(%rip),%rdx        # 262b9e8 <__gmpfr_one+0x14268>
  2010fa:	mov    %rax,%rdi
  2010fd:	mov    %rbx,%rsi
  201100:	call   *0x24cddfa(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201106:	lea    0x242a93b(%rip),%rdx        # 262ba48 <__gmpfr_one+0x142c8>
  20110d:	mov    %rbx,%rsi
  201110:	call   *0x24cddea(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201116:	lea    0x242a913(%rip),%rdx        # 262ba30 <__gmpfr_one+0x142b0>
  20111d:	mov    %rcx,%rdi
  201120:	mov    %rbx,%rsi
  201123:	call   *0x24cddd7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201129:	lea    0x242a8e8(%rip),%rdx        # 262ba18 <__gmpfr_one+0x14298>
  201130:	mov    %rax,%rdi
  201133:	mov    %rbx,%rsi
  201136:	call   *0x24cddc4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20113c:	lea    0x242a935(%rip),%rdx        # 262ba78 <__gmpfr_one+0x142f8>
  201143:	mov    %r14,%rdi
  201146:	mov    %rbx,%rsi
  201149:	call   *0x24cddb1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20114f:	lea    0x242a90a(%rip),%rdx        # 262ba60 <__gmpfr_one+0x142e0>
  201156:	mov    %rbx,%rsi
  201159:	call   *0x24cdda1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20115f:	lea    0x242a95a(%rip),%rdx        # 262bac0 <__gmpfr_one+0x14340>
  201166:	mov    %rbx,%rsi
  201169:	call   *0x24cdd91(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20116f:	lea    0x242a932(%rip),%rdx        # 262baa8 <__gmpfr_one+0x14328>
  201176:	mov    %rcx,%rdi
  201179:	mov    %rbx,%rsi
  20117c:	call   *0x24cdd7e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201182:	lea    0x242a907(%rip),%rdx        # 262ba90 <__gmpfr_one+0x14310>
  201189:	mov    %rax,%rdi
  20118c:	mov    %rbx,%rsi
  20118f:	call   *0x24cdd6b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201195:	lea    0x242a954(%rip),%rdx        # 262baf0 <__gmpfr_one+0x14370>
  20119c:	mov    %r14,%rdi
  20119f:	mov    %rbx,%rsi
  2011a2:	call   *0x24cdd58(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2011a8:	lea    0x242a929(%rip),%rdx        # 262bad8 <__gmpfr_one+0x14358>
  2011af:	mov    %rbx,%rsi
  2011b2:	call   *0x24cdd48(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2011b8:	lea    0x242a961(%rip),%rdx        # 262bb20 <__gmpfr_one+0x143a0>
  2011bf:	mov    %rbx,%rsi
  2011c2:	call   *0x24cdd38(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2011c8:	lea    0x242a939(%rip),%rdx        # 262bb08 <__gmpfr_one+0x14388>
  2011cf:	mov    %rax,%rdi
  2011d2:	mov    %rbx,%rsi
  2011d5:	call   *0x24cdd25(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2011db:	lea    0x242a986(%rip),%rdx        # 262bb68 <__gmpfr_one+0x143e8>
  2011e2:	mov    %rbx,%rsi
  2011e5:	call   *0x24cdd15(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2011eb:	lea    0x242a95e(%rip),%rdx        # 262bb50 <__gmpfr_one+0x143d0>
  2011f2:	mov    %rcx,%rdi
  2011f5:	mov    %rbx,%rsi
  2011f8:	call   *0x24cdd02(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2011fe:	lea    0x242a933(%rip),%rdx        # 262bb38 <__gmpfr_one+0x143b8>
  201205:	mov    %rax,%rdi
  201208:	mov    %rbx,%rsi
  20120b:	call   *0x24cdcef(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201211:	lea    0x242bc58(%rip),%rdx        # 262ce70 <__gmpfr_one+0x156f0>
  201218:	mov    %rax,%rdi
  20121b:	mov    %rbx,%rsi
  20121e:	call   *0x24cdcdc(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201224:	lea    0x242aaa5(%rip),%rdx        # 262bcd0 <__gmpfr_one+0x14550>
  20122b:	mov    %rbx,%rsi
  20122e:	call   *0x24cdccc(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201234:	lea    0x242aaf5(%rip),%rdx        # 262bd30 <__gmpfr_one+0x145b0>
  20123b:	mov    %rbx,%rsi
  20123e:	call   *0x24cdcbc(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201244:	lea    0x242aacd(%rip),%rdx        # 262bd18 <__gmpfr_one+0x14598>
  20124b:	mov    %rax,%rdi
  20124e:	mov    %rbx,%rsi
  201251:	call   *0x24cdca9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201257:	lea    0x242aaa2(%rip),%rdx        # 262bd00 <__gmpfr_one+0x14580>
  20125e:	mov    %rcx,%rdi
  201261:	mov    %rbx,%rsi
  201264:	call   *0x24cdc96(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20126a:	lea    0x242aad7(%rip),%rdx        # 262bd48 <__gmpfr_one+0x145c8>
  201271:	mov    %r11,%rsi
  201274:	call   *0x24cdc86(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20127a:	lea    0x242ac47(%rip),%rdx        # 262bec8 <__gmpfr_one+0x14748>
  201281:	mov    %r11,%rsi
  201284:	call   *0x24cdc76(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20128a:	lea    0x242ad9f(%rip),%rdx        # 262c030 <__gmpfr_one+0x148b0>
  201291:	mov    %r14,%rdi
  201294:	mov    %rbx,%rsi
  201297:	call   *0x24cdc63(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20129d:	lea    0x242ad74(%rip),%rdx        # 262c018 <__gmpfr_one+0x14898>
  2012a4:	mov    %rbx,%rsi
  2012a7:	call   *0x24cdc53(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2012ad:	lea    0x242ad94(%rip),%rdx        # 262c048 <__gmpfr_one+0x148c8>
  2012b4:	mov    %r11,%rsi
  2012b7:	call   *0x24cdc43(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2012bd:	lea    0x242ae74(%rip),%rdx        # 262c138 <__gmpfr_one+0x149b8>
  2012c4:	mov    %r11,%rsi
  2012c7:	call   *0x24cdc33(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2012cd:	lea    0x242be0c(%rip),%rdx        # 262d0e0 <__gmpfr_one+0x15960>
  2012d4:	mov    %r12,%rsi
  2012d7:	call   *0x24cdc23(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2012dd:	lea    0x242bcac(%rip),%rdx        # 262cf90 <__gmpfr_one+0x15810>
  2012e4:	mov    %r14,%rdi
  2012e7:	mov    %r12,%rsi
  2012ea:	call   *0x24cdc10(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2012f0:	lea    0x242b189(%rip),%rdx        # 262c480 <__gmpfr_one+0x14d00>
  2012f7:	mov    %r14,%rdi
  2012fa:	mov    %rbx,%rsi
  2012fd:	call   *0x24cdbfd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201303:	lea    0x242b1d6(%rip),%rdx        # 262c4e0 <__gmpfr_one+0x14d60>
  20130a:	mov    %rbx,%rsi
  20130d:	call   *0x24cdbed(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201313:	lea    0x242b1ae(%rip),%rdx        # 262c4c8 <__gmpfr_one+0x14d48>
  20131a:	mov    %rcx,%rdi
  20131d:	mov    %rbx,%rsi
  201320:	call   *0x24cdbda(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201326:	lea    0x242b183(%rip),%rdx        # 262c4b0 <__gmpfr_one+0x14d30>
  20132d:	mov    %rax,%rdi
  201330:	mov    %rbx,%rsi
  201333:	call   *0x24cdbc7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201339:	lea    0x242b1b8(%rip),%rdx        # 262c4f8 <__gmpfr_one+0x14d78>
  201340:	mov    %r11,%rsi
  201343:	call   *0x24cdbb7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201349:	lea    0x242bbb0(%rip),%rdx        # 262cf00 <__gmpfr_one+0x15780>
  201350:	mov    %rsi,%rdi
  201353:	mov    %r12,%rsi
  201356:	call   *0x24cdba4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20135c:	lea    0x242b2b5(%rip),%rdx        # 262c618 <__gmpfr_one+0x14e98>
  201363:	mov    %rbx,%rsi
  201366:	call   *0x24cdb94(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20136c:	lea    0x242b28d(%rip),%rdx        # 262c600 <__gmpfr_one+0x14e80>
  201373:	mov    %rax,%rdi
  201376:	mov    %rbx,%rsi
  201379:	call   *0x24cdb81(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20137f:	lea    0x242b2da(%rip),%rdx        # 262c660 <__gmpfr_one+0x14ee0>
  201386:	mov    %rbx,%rsi
  201389:	call   *0x24cdb71(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20138f:	lea    0x242b2b2(%rip),%rdx        # 262c648 <__gmpfr_one+0x14ec8>
  201396:	mov    %rcx,%rdi
  201399:	mov    %rbx,%rsi
  20139c:	call   *0x24cdb5e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2013a2:	lea    0x242b287(%rip),%rdx        # 262c630 <__gmpfr_one+0x14eb0>
  2013a9:	mov    %rax,%rdi
  2013ac:	mov    %rbx,%rsi
  2013af:	call   *0x24cdb4b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2013b5:	lea    0x242b2d4(%rip),%rdx        # 262c690 <__gmpfr_one+0x14f10>
  2013bc:	mov    %r14,%rdi
  2013bf:	mov    %rbx,%rsi
  2013c2:	call   *0x24cdb38(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2013c8:	lea    0x242b2a9(%rip),%rdx        # 262c678 <__gmpfr_one+0x14ef8>
  2013cf:	mov    %rbx,%rsi
  2013d2:	call   *0x24cdb28(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2013d8:	lea    0x242b2f9(%rip),%rdx        # 262c6d8 <__gmpfr_one+0x14f58>
  2013df:	mov    %rbx,%rsi
  2013e2:	call   *0x24cdb18(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2013e8:	lea    0x242b2d1(%rip),%rdx        # 262c6c0 <__gmpfr_one+0x14f40>
  2013ef:	mov    %rcx,%rdi
  2013f2:	mov    %rbx,%rsi
  2013f5:	call   *0x24cdb05(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2013fb:	lea    0x242b2a6(%rip),%rdx        # 262c6a8 <__gmpfr_one+0x14f28>
  201402:	mov    %rax,%rdi
  201405:	mov    %rbx,%rsi
  201408:	call   *0x24cdaf2(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20140e:	lea    0x242b2f3(%rip),%rdx        # 262c708 <__gmpfr_one+0x14f88>
  201415:	mov    %r14,%rdi
  201418:	mov    %rbx,%rsi
  20141b:	call   *0x24cdadf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201421:	lea    0x242b2c8(%rip),%rdx        # 262c6f0 <__gmpfr_one+0x14f70>
  201428:	mov    %rbx,%rsi
  20142b:	call   *0x24cdacf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201431:	lea    0x242b300(%rip),%rdx        # 262c738 <__gmpfr_one+0x14fb8>
  201438:	mov    %rbx,%rsi
  20143b:	call   *0x24cdabf(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201441:	lea    0x242b2d8(%rip),%rdx        # 262c720 <__gmpfr_one+0x14fa0>
  201448:	mov    %rax,%rdi
  20144b:	mov    %rbx,%rsi
  20144e:	call   *0x24cdaac(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201454:	lea    0x242b325(%rip),%rdx        # 262c780 <__gmpfr_one+0x15000>
  20145b:	mov    %rbx,%rsi
  20145e:	call   *0x24cda9c(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201464:	lea    0x242b2fd(%rip),%rdx        # 262c768 <__gmpfr_one+0x14fe8>
  20146b:	mov    %rcx,%rdi
  20146e:	mov    %rbx,%rsi
  201471:	call   *0x24cda89(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201477:	lea    0x242b2d2(%rip),%rdx        # 262c750 <__gmpfr_one+0x14fd0>
  20147e:	mov    %rax,%rdi
  201481:	mov    %rbx,%rsi
  201484:	call   *0x24cda76(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20148a:	lea    0x242b64f(%rip),%rdx        # 262cae0 <__gmpfr_one+0x15360>
  201491:	mov    %rax,%rdi
  201494:	mov    %rbx,%rsi
  201497:	call   *0x24cda63(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20149d:	lea    0x242b984(%rip),%rdx        # 262ce28 <__gmpfr_one+0x156a8>
  2014a4:	mov    %r14,%rdi
  2014a7:	mov    %r12,%rsi
  2014aa:	call   *0x24cda50(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2014b0:	lea    0x242b431(%rip),%rdx        # 262c8e8 <__gmpfr_one+0x15168>
  2014b7:	mov    %r14,%rdi
  2014ba:	mov    %rbx,%rsi
  2014bd:	call   *0x24cda3d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2014c3:	lea    0x242b47e(%rip),%rdx        # 262c948 <__gmpfr_one+0x151c8>
  2014ca:	mov    %rbx,%rsi
  2014cd:	call   *0x24cda2d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2014d3:	lea    0x242b456(%rip),%rdx        # 262c930 <__gmpfr_one+0x151b0>
  2014da:	mov    %rcx,%rdi
  2014dd:	mov    %rbx,%rsi
  2014e0:	call   *0x24cda1a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2014e6:	lea    0x242b42b(%rip),%rdx        # 262c918 <__gmpfr_one+0x15198>
  2014ed:	mov    %rax,%rdi
  2014f0:	mov    %rbx,%rsi
  2014f3:	call   *0x24cda07(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2014f9:	lea    0x242b460(%rip),%rdx        # 262c960 <__gmpfr_one+0x151e0>
  201500:	mov    %r11,%rsi
  201503:	call   *0x24cd9f7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201509:	lea    0x242b888(%rip),%rdx        # 262cd98 <__gmpfr_one+0x15618>
  201510:	mov    %rsi,%rdi
  201513:	mov    %r12,%rsi
  201516:	call   *0x24cd9e4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20151c:	lea    0x242b7fd(%rip),%rdx        # 262cd20 <__gmpfr_one+0x155a0>
  201523:	mov    %r13,%rdi
  201526:	mov    %r12,%rsi
  201529:	call   *0x24cd9d1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20152f:	lea    0x242b772(%rip),%rdx        # 262cca8 <__gmpfr_one+0x15528>
  201536:	mov    %rsi,%rdi
  201539:	mov    %r12,%rsi
  20153c:	call   *0x24cd9be(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201542:	lea    0x242ac97(%rip),%rdx        # 262c1e0 <__gmpfr_one+0x14a60>
  201549:	mov    %rbx,%rsi
  20154c:	call   *0x24cd9ae(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201552:	lea    0x242b6a7(%rip),%rdx        # 262cc00 <__gmpfr_one+0x15480>
  201559:	mov    %r13,%rdi
  20155c:	mov    %r12,%rsi
  20155f:	call   *0x24cd99b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201565:	lea    0x242b604(%rip),%rdx        # 262cb70 <__gmpfr_one+0x153f0>
  20156c:	mov    %r13,%rdi
  20156f:	mov    %r12,%rsi
  201572:	call   *0x24cd988(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201578:	lea    0x242b519(%rip),%rdx        # 262ca98 <__gmpfr_one+0x15318>
  20157f:	mov    %r13,%rdi
  201582:	mov    0xf0(%rsp),%rsi
  20158a:	call   *0x24cd970(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201590:	lea    0x242bb31(%rip),%rdx        # 262d0c8 <__gmpfr_one+0x15948>
  201597:	mov    %rcx,%rdi
  20159a:	mov    %r11,%rsi
  20159d:	call   *0x24cd95d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2015a3:	lea    0x242a1fe(%rip),%rdx        # 262b7a8 <__gmpfr_one+0x14028>
  2015aa:	mov    %rcx,%rdi
  2015ad:	mov    %rbx,%rsi
  2015b0:	call   *0x24cd94a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2015b6:	lea    0x242b9bb(%rip),%rdx        # 262cf78 <__gmpfr_one+0x157f8>
  2015bd:	mov    %r11,%rsi
  2015c0:	call   *0x24cd93a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2015c6:	lea    0x2429d8b(%rip),%rdx        # 262b358 <__gmpfr_one+0x13bd8>
  2015cd:	mov    %rbx,%rsi
  2015d0:	call   *0x24cd92a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2015d6:	lea    0x2429ddb(%rip),%rdx        # 262b3b8 <__gmpfr_one+0x13c38>
  2015dd:	mov    %r14,%rdi
  2015e0:	mov    %rbx,%rsi
  2015e3:	call   *0x24cd917(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2015e9:	lea    0x2429db0(%rip),%rdx        # 262b3a0 <__gmpfr_one+0x13c20>
  2015f0:	mov    %rcx,%rdi
  2015f3:	mov    %rbx,%rsi
  2015f6:	call   *0x24cd904(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2015fc:	lea    0x2429d85(%rip),%rdx        # 262b388 <__gmpfr_one+0x13c08>
  201603:	mov    %rax,%rdi
  201606:	mov    %rbx,%rsi
  201609:	call   *0x24cd8f1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20160f:	lea    0x2429d5a(%rip),%rdx        # 262b370 <__gmpfr_one+0x13bf0>
  201616:	mov    %rbx,%rsi
  201619:	call   *0x24cd8e1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20161f:	lea    0x2429dc2(%rip),%rdx        # 262b3e8 <__gmpfr_one+0x13c68>
  201626:	mov    %rbx,%rsi
  201629:	call   *0x24cd8d1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20162f:	lea    0x2429d9a(%rip),%rdx        # 262b3d0 <__gmpfr_one+0x13c50>
  201636:	mov    %rax,%rdi
  201639:	mov    %rbx,%rsi
  20163c:	call   *0x24cd8be(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201642:	lea    0x2429de7(%rip),%rdx        # 262b430 <__gmpfr_one+0x13cb0>
  201649:	mov    %rbx,%rsi
  20164c:	call   *0x24cd8ae(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201652:	lea    0x2429e07(%rip),%rdx        # 262b460 <__gmpfr_one+0x13ce0>
  201659:	mov    %rbx,%rsi
  20165c:	call   *0x24cd89e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201662:	lea    0x2429ddf(%rip),%rdx        # 262b448 <__gmpfr_one+0x13cc8>
  201669:	mov    %rax,%rdi
  20166c:	mov    %rbx,%rsi
  20166f:	call   *0x24cd88b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201675:	lea    0x2429e44(%rip),%rdx        # 262b4c0 <__gmpfr_one+0x13d40>
  20167c:	mov    %rbx,%rsi
  20167f:	call   *0x24cd87b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201685:	lea    0x2429e1c(%rip),%rdx        # 262b4a8 <__gmpfr_one+0x13d28>
  20168c:	mov    %rsi,%rdi
  20168f:	mov    %rbx,%rsi
  201692:	call   *0x24cd868(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201698:	lea    0x2429df1(%rip),%rdx        # 262b490 <__gmpfr_one+0x13d10>
  20169f:	mov    %rcx,%rdi
  2016a2:	mov    %rbx,%rsi
  2016a5:	call   *0x24cd855(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2016ab:	lea    0x2429dc6(%rip),%rdx        # 262b478 <__gmpfr_one+0x13cf8>
  2016b2:	mov    %rax,%rdi
  2016b5:	mov    %rbx,%rsi
  2016b8:	call   *0x24cd842(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2016be:	lea    0x2429e2b(%rip),%rdx        # 262b4f0 <__gmpfr_one+0x13d70>
  2016c5:	mov    %rbx,%rsi
  2016c8:	call   *0x24cd832(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2016ce:	lea    0x2429e03(%rip),%rdx        # 262b4d8 <__gmpfr_one+0x13d58>
  2016d5:	mov    %rax,%rdi
  2016d8:	mov    %rbx,%rsi
  2016db:	call   *0x24cd81f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2016e1:	lea    0x2429e50(%rip),%rdx        # 262b538 <__gmpfr_one+0x13db8>
  2016e8:	mov    %rbx,%rsi
  2016eb:	call   *0x24cd80f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2016f1:	lea    0x2429e28(%rip),%rdx        # 262b520 <__gmpfr_one+0x13da0>
  2016f8:	mov    %rcx,%rdi
  2016fb:	mov    %rbx,%rsi
  2016fe:	call   *0x24cd7fc(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201704:	lea    0x2429dfd(%rip),%rdx        # 262b508 <__gmpfr_one+0x13d88>
  20170b:	mov    %rax,%rdi
  20170e:	mov    %rbx,%rsi
  201711:	call   *0x24cd7e9(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201717:	lea    0x2429e4a(%rip),%rdx        # 262b568 <__gmpfr_one+0x13de8>
  20171e:	mov    %r14,%rdi
  201721:	mov    %rbx,%rsi
  201724:	call   *0x24cd7d6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20172a:	lea    0x2429e1f(%rip),%rdx        # 262b550 <__gmpfr_one+0x13dd0>
  201731:	mov    %rbx,%rsi
  201734:	call   *0x24cd7c6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20173a:	lea    0x2429e6f(%rip),%rdx        # 262b5b0 <__gmpfr_one+0x13e30>
  201741:	mov    %rbx,%rsi
  201744:	call   *0x24cd7b6(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20174a:	lea    0x2429e47(%rip),%rdx        # 262b598 <__gmpfr_one+0x13e18>
  201751:	mov    %rcx,%rdi
  201754:	mov    %rbx,%rsi
  201757:	call   *0x24cd7a3(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20175d:	lea    0x2429e1c(%rip),%rdx        # 262b580 <__gmpfr_one+0x13e00>
  201764:	mov    %rax,%rdi
  201767:	mov    %rbx,%rsi
  20176a:	call   *0x24cd790(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201770:	lea    0x2429e69(%rip),%rdx        # 262b5e0 <__gmpfr_one+0x13e60>
  201777:	mov    %r14,%rdi
  20177a:	mov    %rbx,%rsi
  20177d:	call   *0x24cd77d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201783:	lea    0x2429e3e(%rip),%rdx        # 262b5c8 <__gmpfr_one+0x13e48>
  20178a:	mov    %rbx,%rsi
  20178d:	call   *0x24cd76d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201793:	lea    0x2429e76(%rip),%rdx        # 262b610 <__gmpfr_one+0x13e90>
  20179a:	mov    %rbx,%rsi
  20179d:	call   *0x24cd75d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2017a3:	lea    0x2429e4e(%rip),%rdx        # 262b5f8 <__gmpfr_one+0x13e78>
  2017aa:	mov    %rax,%rdi
  2017ad:	mov    %rbx,%rsi
  2017b0:	call   *0x24cd74a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2017b6:	lea    0x2429e9b(%rip),%rdx        # 262b658 <__gmpfr_one+0x13ed8>
  2017bd:	mov    %rbx,%rsi
  2017c0:	call   *0x24cd73a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2017c6:	lea    0x2429e73(%rip),%rdx        # 262b640 <__gmpfr_one+0x13ec0>
  2017cd:	mov    %rcx,%rdi
  2017d0:	mov    %rbx,%rsi
  2017d3:	call   *0x24cd727(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2017d9:	lea    0x2429e48(%rip),%rdx        # 262b628 <__gmpfr_one+0x13ea8>
  2017e0:	mov    %rax,%rdi
  2017e3:	mov    %rbx,%rsi
  2017e6:	call   *0x24cd714(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2017ec:	lea    0x2429e95(%rip),%rdx        # 262b688 <__gmpfr_one+0x13f08>
  2017f3:	mov    %r14,%rdi
  2017f6:	mov    %rbx,%rsi
  2017f9:	call   *0x24cd701(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2017ff:	lea    0x2429e6a(%rip),%rdx        # 262b670 <__gmpfr_one+0x13ef0>
  201806:	mov    %rbx,%rsi
  201809:	call   *0x24cd6f1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20180f:	lea    0x2429ea2(%rip),%rdx        # 262b6b8 <__gmpfr_one+0x13f38>
  201816:	mov    %rbx,%rsi
  201819:	call   *0x24cd6e1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20181f:	lea    0x2429e7a(%rip),%rdx        # 262b6a0 <__gmpfr_one+0x13f20>
  201826:	mov    %rax,%rdi
  201829:	mov    %rbx,%rsi
  20182c:	call   *0x24cd6ce(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201832:	lea    0x2429ec7(%rip),%rdx        # 262b700 <__gmpfr_one+0x13f80>
  201839:	mov    %rbx,%rsi
  20183c:	call   *0x24cd6be(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201842:	lea    0x2429e9f(%rip),%rdx        # 262b6e8 <__gmpfr_one+0x13f68>
  201849:	mov    %rcx,%rdi
  20184c:	mov    %rbx,%rsi
  20184f:	call   *0x24cd6ab(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201855:	lea    0x2429e74(%rip),%rdx        # 262b6d0 <__gmpfr_one+0x13f50>
  20185c:	mov    %rax,%rdi
  20185f:	mov    %rbx,%rsi
  201862:	call   *0x24cd698(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201868:	lea    0x242b769(%rip),%rdx        # 262cfd8 <__gmpfr_one+0x15858>
  20186f:	mov    %rax,%rdi
  201872:	mov    %rbx,%rsi
  201875:	call   *0x24cd685(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20187b:	lea    0x242b666(%rip),%rdx        # 262cee8 <__gmpfr_one+0x15768>
  201882:	mov    %r11,%rsi
  201885:	call   *0x24cd675(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20188b:	lea    0x242a37e(%rip),%rdx        # 262bc10 <__gmpfr_one+0x14490>
  201892:	mov    %rcx,%rdi
  201895:	mov    %rbx,%rsi
  201898:	call   *0x24cd662(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20189e:	lea    0x242a2db(%rip),%rdx        # 262bb80 <__gmpfr_one+0x14400>
  2018a5:	mov    %r11,%rsi
  2018a8:	call   *0x24cd652(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2018ae:	lea    0x242b55b(%rip),%rdx        # 262ce10 <__gmpfr_one+0x15690>
  2018b5:	mov    %r11,%rsi
  2018b8:	call   *0x24cd642(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2018be:	lea    0x242b4bb(%rip),%rdx        # 262cd80 <__gmpfr_one+0x15600>
  2018c5:	mov    %r11,%rsi
  2018c8:	call   *0x24cd632(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2018ce:	lea    0x242a683(%rip),%rdx        # 262bf58 <__gmpfr_one+0x147d8>
  2018d5:	mov    %rcx,%rdi
  2018d8:	mov    %rbx,%rsi
  2018db:	call   *0x24cd61f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2018e1:	lea    0x242b420(%rip),%rdx        # 262cd08 <__gmpfr_one+0x15588>
  2018e8:	mov    %r11,%rsi
  2018eb:	call   *0x24cd60f(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2018f1:	lea    0x242b398(%rip),%rdx        # 262cc90 <__gmpfr_one+0x15510>
  2018f8:	mov    %r11,%rsi
  2018fb:	call   *0x24cd5ff(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201901:	lea    0x2429a38(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201908:	mov    $0x3,%edi
  20190d:	call   *0x24cd5ed(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201913:	lea    0x242a8ae(%rip),%rdx        # 262c1c8 <__gmpfr_one+0x14a48>
  20191a:	mov    %rbx,%rsi
  20191d:	call   *0x24cd5dd(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201923:	lea    0x242b756(%rip),%rdx        # 262d080 <__gmpfr_one+0x15900>
  20192a:	mov    %rsi,%rdi
  20192d:	mov    %r12,%rsi
  201930:	call   *0x24cd5ca(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201936:	lea    0x242ab2b(%rip),%rdx        # 262c468 <__gmpfr_one+0x14ce8>
  20193d:	mov    %rcx,%rdi
  201940:	mov    %rbx,%rsi
  201943:	call   *0x24cd5b7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201949:	lea    0x242b298(%rip),%rdx        # 262cbe8 <__gmpfr_one+0x15468>
  201950:	mov    %r11,%rsi
  201953:	call   *0x24cd5a7(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201959:	lea    0x242b1f8(%rip),%rdx        # 262cb58 <__gmpfr_one+0x153d8>
  201960:	mov    %r11,%rsi
  201963:	call   *0x24cd597(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201969:	lea    0x242b530(%rip),%rdx        # 262cea0 <__gmpfr_one+0x15720>
  201970:	mov    %rsi,%rdi
  201973:	mov    %r12,%rsi
  201976:	call   *0x24cd584(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  20197c:	lea    0x24299bd(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201983:	mov    $0x3,%edi
  201988:	mov    0x118(%rsp),%rsi
  201990:	call   *0x24cd56a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201996:	lea    0x242ae8b(%rip),%rdx        # 262c828 <__gmpfr_one+0x150a8>
  20199d:	mov    %rcx,%rdi
  2019a0:	mov    %rbx,%rsi
  2019a3:	call   *0x24cd557(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2019a9:	lea    0x242ade8(%rip),%rdx        # 262c798 <__gmpfr_one+0x15018>
  2019b0:	mov    %r11,%rsi
  2019b3:	call   *0x24cd547(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2019b9:	lea    0x242b0c0(%rip),%rdx        # 262ca80 <__gmpfr_one+0x15300>
  2019c0:	mov    %r11,%rsi
  2019c3:	call   *0x24cd537(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2019c9:	lea    0x242b140(%rip),%rdx        # 262cb10 <__gmpfr_one+0x15390>
  2019d0:	mov    %rsi,%rdi
  2019d3:	mov    %r12,%rsi
  2019d6:	call   *0x24cd524(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2019dc:	lea    0x242b685(%rip),%rdx        # 262d068 <__gmpfr_one+0x158e8>
  2019e3:	mov    %rax,%rdi
  2019e6:	mov    %r11,%rsi
  2019e9:	call   *0x24cd511(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2019ef:	lea    0x2429d22(%rip),%rdx        # 262b718 <__gmpfr_one+0x13f98>
  2019f6:	mov    %r11,%rsi
  2019f9:	call   *0x24cd501(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  2019ff:	lea    0x242b482(%rip),%rdx        # 262ce88 <__gmpfr_one+0x15708>
  201a06:	mov    %r11,%rsi
  201a09:	call   *0x24cd4f1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201a0f:	lea    0x242b5f2(%rip),%rdx        # 262d008 <__gmpfr_one+0x15888>
  201a16:	mov    %rsi,%rdi
  201a19:	mov    %r12,%rsi
  201a1c:	call   *0x24cd4de(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201a22:	lea    0x242b0cf(%rip),%rdx        # 262caf8 <__gmpfr_one+0x15378>
  201a29:	mov    %r11,%rsi
  201a2c:	call   *0x24cd4ce(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201a32:	lea    0x242b5b7(%rip),%rdx        # 262cff0 <__gmpfr_one+0x15870>
  201a39:	mov    %r11,%rsi
  201a3c:	call   *0x24cd4be(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201a42:	lea    0x24298f7(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201a49:	mov    $0x1,%edi
  201a4e:	mov    0x118(%rsp),%rsi
  201a56:	call   *0x24cd4a4(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201a5c:	lea    0x24298dd(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201a63:	mov    $0x4,%edi
  201a68:	mov    0x118(%rsp),%rsi
  201a70:	call   *0x24cd48a(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201a76:	lea    0x24298c3(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201a7d:	mov    $0x4,%edi
  201a82:	mov    0x118(%rsp),%rsi
  201a8a:	call   *0x24cd470(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201a90:	lea    0x24298a9(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201a97:	mov    $0x6,%edi
  201a9c:	call   *0x24cd45e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201aa2:	lea    0x2429897(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201aa9:	mov    $0x7,%edi
  201aae:	mov    $0x7,%esi
  201ab3:	call   *0x24cd447(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201ab9:	lea    0x2429880(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201ac0:	mov    $0x8,%edi
  201ac5:	mov    $0x8,%esi
  201aca:	call   *0x24cd430(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201ad0:	add    (%r9),%rdx
  201ad3:	mov    %rdx,%rax
  201ad6:	cmp    %rbx,%rdx
  201ad9:	jb     201afe <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x787e>
  201adb:	lea    0x242aa8e(%rip),%rdx        # 262c570 <__gmpfr_one+0x14df0>
  201ae2:	mov    %rax,%rdi
  201ae5:	mov    %rbx,%rsi
  201ae8:	call   *0x24cd412(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201aee:	mov    0x8(%rsp),%rcx
  201af3:	add    (%r9),%rcx
  201af6:	mov    %rcx,%rax
  201af9:	cmp    %rbx,%rcx
  201afc:	jae    201b0f <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x788f>
  201afe:	lea    0x242983b(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201b05:	xor    %edi,%edi
  201b07:	xor    %esi,%esi
  201b09:	call   *0x24cd3f1(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201b0f:	lea    0x242aec2(%rip),%rdx        # 262c9d8 <__gmpfr_one+0x15258>
  201b16:	mov    %rax,%rdi
  201b19:	mov    %rbx,%rsi
  201b1c:	call   *0x24cd3de(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201b22:	lea    0x2429817(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201b29:	mov    $0x1,%edi
  201b2e:	call   *0x24cd3cc(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201b34:	lea    0x2429805(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201b3b:	mov    $0x1,%edi
  201b40:	call   *0x24cd3ba(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201b46:	mov    0x8(%rsp),%rcx
  201b4b:	add    (%r9),%rcx
  201b4e:	mov    %rcx,%rax
  201b51:	cmp    %rbx,%rcx
  201b54:	jae    201b70 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x78f0>
  201b56:	lea    0x24297e3(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201b5d:	mov    $0x1,%edi
  201b62:	mov    0x118(%rsp),%rsi
  201b6a:	call   *0x24cd390(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201b70:	lea    0x24297b1(%rip),%rdx        # 262b328 <__gmpfr_one+0x13ba8>
  201b77:	mov    %rax,%rdi
  201b7a:	mov    %rbx,%rsi
  201b7d:	call   *0x24cd37d(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201b83:	mov    (%r9),%rax
  201b86:	cmp    %rbx,%rax
  201b89:	jae    201baf <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x792f>
  201b8b:	add    0x8(%rsp),%rax
  201b90:	mov    %rax,%rcx
  201b93:	cmp    %rbx,%rax
  201b96:	jae    201bc2 <native_dense_fixed_b0::generated::baseline::batch_block_0::<f64>+0x7942>
  201b98:	lea    0x24297a1(%rip),%rdx        # 262b340 <__gmpfr_one+0x13bc0>
  201b9f:	mov    $0x2,%edi
  201ba4:	mov    $0x2,%esi
  201ba9:	call   *0x24cd351(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201baf:	lea    0x242984a(%rip),%rdx        # 262b400 <__gmpfr_one+0x13c80>
  201bb6:	mov    %rax,%rdi
  201bb9:	mov    %rbx,%rsi
  201bbc:	call   *0x24cd33e(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
  201bc2:	lea    0x242984f(%rip),%rdx        # 262b418 <__gmpfr_one+0x13c98>
  201bc9:	mov    %rcx,%rdi
  201bcc:	mov    %rbx,%rsi
  201bcf:	call   *0x24cd32b(%rip)        # 26cef00 <_GLOBAL_OFFSET_TABLE_+0x3a70>
