#!/usr/bin/env python3
"""Single bounded, reviewed stage. No retry, Cargo, or numerical evaluation."""
import json
import os
from pathlib import Path
import sys
import time
from common import (ROOT, BUNDLE, bindings, execute, finish, install_signal_handlers,
                    load_protocol, save, sha, utc, verify)


def main():
    install_signal_handlers()
    assert len(sys.argv) == 2
    stage = sys.argv[1]
    protocol = load_protocol()
    assert stage in ['build', 'prepare']
    spec = protocol['stage_specs'][stage]
    output = BUNDLE / 'runs' / f'{stage}-001'
    output.mkdir(parents=True, exist_ok=False)
    path = output / 'run.json'
    start = time.monotonic()
    record = {'status': 'running', 'stage': stage, 'started_utc': utc(),
              'bound_seconds': spec['bound_seconds'], 'stages': [],
              'scope': protocol['scope'], 'outputs': {}}
    save(path, record)
    files = {}
    try:
        files = bindings(protocol, stage)
        if stage == 'prepare':
            previous_path = BUNDLE / 'runs/build-001/run.json'
            previous = json.loads(previous_path.read_text())
            assert previous['status'] == 'passed' and previous['inputs_unchanged'] is True
            assert not previous.get('total_bound_exceeded', False)
            assert len(previous['stages']) == 3 and all(s['passed'] for s in previous['stages'])
            for key, digest in previous['inputs'].items():
                files[Path(key)] = digest
            for key, digest in previous['outputs'].items():
                files[ROOT / key] = digest
            files[previous_path] = sha(previous_path)
            granted = json.loads((BUNDLE / 'protocol/grants/prepare.json').read_text())
            assert granted['build_receipt_sha256'] == sha(previous_path)
            assert granted['binary_sha256'] == sha(output.parent / 'build-001/driver')
            assert granted['core_sha256'] == sha(output.parent / 'build-001/libiregi_rust.rlib')
            exact_path = BUNDLE / 'runs/exact-001/run.json'
            exact = json.loads(exact_path.read_text())
            assert exact['status'] == 'passed' and exact['tests_passed'] == 22 and exact['tests_failed'] == 0
            assert exact['inputs_unchanged'] is True and not exact.get('total_bound_exceeded', False)
            assert granted['exact_receipt_sha256'] == sha(exact_path)
            files[exact_path] = sha(exact_path)
            for key, digest in exact['inputs'].items():
                assert key not in {str(x): d for x, d in files.items()} or files[Path(key)] == digest
                files[Path(key)] = digest
            for key, digest in exact['outputs'].items():
                files[ROOT / key] = digest
        verify(files, protocol)
        record['inputs'] = {str(p): digest for p, digest in files.items()}
        save(path, record)
        env = os.environ.copy()
        env.update(RAYON_NUM_THREADS='1', RUST_TEST_THREADS='1', OMP_NUM_THREADS='1',
                   IREGI_PV_PREPARATION_PROFILE='1')
        for item in spec['commands']:
            remaining = spec['bound_seconds'] - (time.monotonic() - start) - spec['postguard_reserve_seconds']
            seconds = min(remaining, item['bound_seconds'])
            env.update(item['environment'])
            step = execute(item['command'], output / item['log'], seconds, env)
            step['name'] = item['name']
            record['stages'].append(step)
            save(path, record)
            assert step['passed'], f"{item['name']} did not pass"
            # Pin the newly produced core before linking the helper.
            if stage == 'build' and item['name'] == 'core':
                core = output / 'libiregi_rust.rlib'
                files[core] = sha(core)
                record['inputs'][str(core)] = files[core]
                save(path, record)
            verify(files, protocol)
        record['status'] = 'passed'
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        save(path, record)  # Terminal precedes output/provenance hashes.
        try:
            record['outputs'] = {name: sha(ROOT / name) for name in spec['outputs'] if (ROOT / name).is_file()}
            record['missing_outputs'] = [name for name in spec['outputs'] if not (ROOT / name).is_file()]
            if record['missing_outputs']:
                record['status'] = 'failed'
        except BaseException as error:
            record.update(status='failed', output_hash_error=f'{type(error).__name__}: {error}')
        finish(record, path, files, protocol, start)
    print({'stage': stage, 'status': record['status'], 'receipt': str(path)})
    return 0 if record['status'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main())
