#!/usr/bin/env python3
"""Run22 selected exact tests once; retain ignored constructor as UNRUN."""
import json
import os
import re
import sys
import time
from pathlib import Path
from common import (ROOT, BUNDLE, bindings, execute, finish, install_signal_handlers,
                    load_protocol, save, sha, utc, verify)


def main():
    install_signal_handlers()
    protocol = load_protocol()
    assert protocol['selected_count'] == 22 and len(protocol['tests']) == 23
    output = BUNDLE / 'runs/exact-001'
    output.mkdir(parents=True, exist_ok=False)
    path = output / 'run.json'
    start = time.monotonic()
    record = {'status': 'running', 'started_utc': utc(), 'bound_seconds': 180,
              'scope': protocol['scope'], 'tests': [dict(t) for t in protocol['tests']],
              'stages': [], 'tests_passed': 0, 'tests_failed': 0, 'outputs': {}}
    save(path, record)
    files = {}
    try:
        files = bindings(protocol, 'exact_tests')
        build_path = BUNDLE / 'runs/build-001/run.json'
        build = json.loads(build_path.read_text())
        assert build['status'] == 'passed' and build['inputs_unchanged'] is True
        assert not build.get('total_bound_exceeded', False)
        assert len(build['stages']) == 3 and all(s['passed'] for s in build['stages'])
        grant = json.loads((BUNDLE / 'protocol/grants/exact_tests.json').read_text())
        assert grant['build_receipt_sha256'] == sha(build_path)
        for key, digest in build['inputs'].items():
            files[Path(key)] = digest
        for key, digest in build['outputs'].items():
            files[ROOT / key] = digest
        files[build_path] = sha(build_path)
        verify(files, protocol)
        record['inputs'] = {str(p): d for p, d in files.items()}
        save(path, record)
        env = os.environ.copy()
        env.update(RAYON_NUM_THREADS='1', RUST_TEST_THREADS='1')
        # Exact tests do not need phase logging; constructor diagnostic does.
        env.pop('IREGI_PV_PREPARATION_PROFILE', None)
        binary = str(build_path.parent / 'tests')
        taskset = protocol['tool_paths']['taskset']
        listed = execute([taskset, '-c', '6', binary, '--list', '--format', 'terse'],
                         output / 'inventory.log', 10, env)
        record['stages'].append(dict(listed, name='inventory'))
        save(path, record)
        assert listed['passed'], 'inventory failed'
        names = re.findall(r'^([^\n]+): test$', (output / 'inventory.log').read_text(), re.M)
        assert len(names) == len(set(names))
        for test in record['tests']:
            assert names.count(test['name']) == 1, f"missing test {test['name']}"
        for index, test in enumerate(record['tests']):
            if not test['selected']:
                assert test['status'] == 'unrun_explicitly_ignored'
                continue
            verify(files, protocol)
            remaining = 180 - (time.monotonic() - start) - 30
            assert remaining > 2, 'exact gate exhausted its budget; remaining tests stay UNRUN'
            logfile = output / f'test-{index:02d}.log'
            step = execute([taskset, '-c', '6', binary, test['name'], '--exact', '--nocapture', '--test-threads=1'],
                           logfile, min(45, remaining), env)
            step['name'] = test['name']
            record['stages'].append(step)
            test.update(status='passed' if step['passed'] else 'failed', log=logfile.name)
            save(path, record)
            assert not step['cleanup_errors'] and not step.get('interrupted', False)
            text = logfile.read_text()
            correct = (step['passed'] and f"test {test['name']} ... ok" in text
                       and re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;', text))
            if correct:
                record['tests_passed'] += 1
            else:
                test['status'] = 'failed'
                test['result_gate_error'] = 'one-test success record absent or unsuccessful process'
                record['tests_failed'] += 1
            save(path, record)
        record['status'] = 'passed' if record['tests_passed'] == 22 and record['tests_failed'] == 0 else 'failed'
    except BaseException as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}')
    finally:
        save(path, record)
        try:
            record['outputs'] = {str(p.relative_to(ROOT)): sha(p) for p in sorted(output.iterdir())
                                 if p.is_file() and (p.suffix == '.log' or p.name.endswith('.terminal.json'))}
        except BaseException as error:
            record.update(status='failed', output_hash_error=f'{type(error).__name__}: {error}')
        finish(record, path, files, protocol, start)
    print({'status': record['status'], 'passed': record['tests_passed'], 'failed': record['tests_failed'],
           'ignored_constructor': 'UNRUN', 'receipt': str(path)})
    return 0 if record['status'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main())
