#!/usr/bin/env python3
"""Package the completed private qualification without binaries or rerunning code."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path('/shared/external/iregi/iregi-rust')
SOURCE = ROOT / 'target/public-highpoint/thin-n7-rational-domain'
DEST = ROOT / 'validation/highpoint-thin-n7-rational-domain'
assert Path.cwd().resolve() == ROOT


def digest(data):
    return hashlib.sha256(data).hexdigest()


def info(path):
    data = path.read_bytes()
    return {'sha256': digest(data), 'bytes': len(data)}


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


review = SOURCE / 'independent-runtime-review.json'
assert review.is_file(), 'Independent saved-data review must be complete first.'
assert not DEST.exists(), 'Never overwrite a frozen capsule.'
qualification = json.loads((SOURCE / 'qualification.json').read_text())
assert qualification['status'] == 'private_build_exact_and_rank0_constructor_passed'
assert qualification['tests_passed'] == 22 and qualification['tests_failed'] == 0
assert qualification['tests_explicitly_ignored_unrun'] == 1
protocol = json.loads((SOURCE / 'protocol/protocol.json').read_text())
for name, sha in protocol['inputs'].items():
    assert info(ROOT / name)['sha256'] == sha, name
for stage in ['build', 'exact', 'prepare']:
    saved = json.loads((SOURCE / f'runs/{stage}-001/run.json').read_text())
    assert saved['status'] == 'passed' and saved['inputs_unchanged']
    assert not saved.get('total_bound_exceeded', False)

members = {}
for path in sorted((SOURCE / 'core').rglob('*')):
    if path.is_file():
        members[str(path.relative_to(SOURCE))] = path
assert len(members) == 40
for relative in ['driver.rs', 'domain-change.patch', 'source.json', 'README.md', 'package.py']:
    members[relative] = SOURCE / relative
for path in sorted((SOURCE / 'protocol').rglob('*')):
    if path.is_file():
        assert path.suffix in ['.py', '.json'], path
        members[str(path.relative_to(SOURCE))] = path


def archive_bytes():
    plain = io.BytesIO()
    with tarfile.open(fileobj=plain, mode='w', format=tarfile.USTAR_FORMAT) as tar:
        for name, path in sorted(members.items()):
            data = path.read_bytes()
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            entry.uid = entry.gid = entry.mtime = 0
            entry.uname = entry.gname = ''
            tar.addfile(entry, io.BytesIO(data))
    compressed = io.BytesIO()
    with gzip.GzipFile(fileobj=compressed, mode='wb', filename='', mtime=0, compresslevel=9) as stream:
        stream.write(plain.getvalue())
    return compressed.getvalue()


archive = archive_bytes()
assert archive == archive_bytes()
DEST.mkdir()
origins = {'payloads': {}, 'archive_members': {}}
for name, path in members.items():
    origins['archive_members'][name] = {'origin': str(path.relative_to(ROOT)), **info(path)}
for relative in ['qualification.json', 'independent-runtime-review.json', 'runtime-window-release.json', 'runtime-completion.json']:
    path = SOURCE / relative
    (DEST / relative).write_bytes(path.read_bytes())
    origins['payloads'][relative] = {'origin': str(path.relative_to(ROOT)), **info(path)}
for stage in ['build', 'exact', 'prepare']:
    folder = SOURCE / f'runs/{stage}-001'
    for path in sorted(folder.iterdir()):
        if path.suffix not in ['.json', '.log']:
            continue
        relative = f'{stage}-001/{path.name}'
        target = DEST / relative
        target.parent.mkdir(exist_ok=True)
        target.write_bytes(path.read_bytes())
        origins['payloads'][relative] = {'origin': str(path.relative_to(ROOT)), **info(path)}
(DEST / 'sources.tar.gz').write_bytes(archive)
write_json(DEST / 'payload-origins.json', origins)
closed = {name: sha for name, sha in protocol['inputs'].items()
          if str(Path(name).parent) in protocol['closed_search_directories']}
assert len(closed) == 118
write_json(DEST / 'protocol-input-bindings.json', {
    'protocol_sha256': info(SOURCE / 'protocol/protocol.json')['sha256'],
    'input_count': len(protocol['inputs']), 'inputs': protocol['inputs'],
    'closed_artifact_count': len(closed), 'closed_artifacts': closed,
    'closed_search_directories': protocol['closed_search_directories'],
    'dependency_profile': protocol['dependency_profile'],
    'excluded_payloads': 'No binaries, rlibs, numerical dependencies, cache files or credentials; retain hashes only.'})
(DEST / 'README.md').write_text('''# Private N7 rational-polynomial preparation qualification

**The private build, 22 selected exact tests, and generic rank-zero constructor passed. Numerical reduction remains unqualified.** The original ignored constructor-variant test remains explicitly UNRUN. The separate constructor helper completed in 58.442222272 seconds; its process took 58.491748579 seconds and the complete guarded stage took 66.659951613 seconds, within the fixed 150-second limit. No workspace, master evaluation, numerical input sample or coefficient array was created. This is not a full-call benchmark, optimized speedup claim, precision-convergence result, reference agreement or production adoption.

Only the generic N7 chart coefficient domain changes relative to the retained marker-only source: Symbolica owns Q-to-Z rational-polynomial conversion, determinant, inverse, all five RHS products, exact residual and determinant-times-solution polynomial checks. Raw normalized determinant and weight expressions remain visible to existing guards. Direct exact complex fixtures pass Gaussian-rational declaration/matrix validation before the original AtomField compatibility solve; i remains a coefficient. Failed rational-path checks cannot trigger fallback. Unit powers, dimension shift zero, preserved shifts, FromShifts invariants, PV routing, native four Laurent slots and all mandatory child subsets remain the private domain.

The build took 56.616011398 seconds and the exact-test gate 38.069447643 seconds, with all retained input guards passing. The fixed inventory contains 23 named tests: 17 historical selected tests, five new exact-domain tests, and one unchanged ignored constructor-variant test. The constructor's seven chart systems, all five columns, exact solution checks, full geometry, parent assembly and generic N5 child-plan phases completed. Geometry took 55.580885106 seconds and the generic N5 child plan 2.834655241 seconds. Nested markers are inclusive and must not be summed across parent/child boundaries. Dependencies use the historical native opt2/debug2 profile, while this core/helper uses opt0/debug0.

The previous [rank-zero numerical capture failure](../highpoint-thin-n7-rank0-attempt/README.md) and [marker-only constructor timeout](../highpoint-thin-n7-phase-attribution/README.md) remain immutable and separate. This result does not replace their failed arrays/oracle-comparison status. In particular, the prior fixed six-rule scalar oracle remains inconclusive at its original uncertainty gate.

`qualification.json`, the independent saved-data review, both runtime release/completion records, all three stage receipts, every test log and every pre-cleanup terminal sidecar are byte-identical copies. The source archive contains exactly 40 private core/fixture files plus the driver, one-file patch, source manifest, source review, protocol, runners, immutable grants and deterministic packager. Payload origins and full protocol/118-artifact closure hash inventories are retained. Binaries, rlibs, dependency payloads, credentials and caches are excluded.

The archive uses sorted USTAR regular files with fixed mode/ownership/time and deterministic gzip metadata; repeated serialization was byte-identical. `manifest.json` binds every payload and archive member, excluding its own hash. Reproduction requires the hash-matched frozen dependency closure or a separately qualified rebuild; packaging itself runs no candidate or numerical work.
''')
files = {str(path.relative_to(DEST)): info(path) for path in sorted(DEST.rglob('*')) if path.is_file()}
parents = {}
for name in ['highpoint-thin-n7-exact', 'highpoint-thin-n7-rank0-attempt', 'highpoint-thin-n7-phase-attribution']:
    path = ROOT / 'validation' / name / 'manifest.json'
    parents[str(path.relative_to(ROOT))] = info(path)
manifest = {'schema_version': 1, 'status': 'private_exact_and_constructor_only_pass',
            'scope': qualification['scope'], 'files': files,
            'archive': {'path': 'sources.tar.gz', **info(DEST / 'sources.tar.gz'),
                        'members': len(members), 'core_source_files': 40,
                        'format': 'USTAR regular files sorted; mode0644; uid=gid=mtime0; empty names; gzip level9 mtime0 empty filename',
                        'repeated_serialization_byte_identical': True},
            'archive_members': {name: info(path) for name, path in sorted(members.items())},
            'parent_manifests': parents}
write_json(DEST / 'manifest.json', manifest)
for name, metadata in files.items():
    assert info(DEST / name) == metadata
print(json.dumps({'path': str(DEST.relative_to(ROOT)), 'manifest': info(DEST / 'manifest.json'),
                  'qualification': info(DEST / 'qualification.json'), 'files': len(files) + 1,
                  'archive': manifest['archive']}, indent=2))
