use figment::{providers::Serialized, Figment, Profile};
use linnet::half_edge::subgraph::{SuBitGraph, SubSetLike};
use linnet::parser::set::DotGraphSet;

use crate::{
    graph_api::{decode_graph_bytes_list, decode_typst_graph, encode_cbor},
    TypstGraph,
};

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
use crate::{__ToResult, __send_result_to_host, __write_args_to_buffer};
#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
use wasm_minimal_protocol::*;

fn decode_cbor_map(arg: &[u8]) -> Result<ciborium::Value, String> {
    ciborium::de::from_reader(arg).map_err(|e| format!("Failed to deserialize CBOR value: {e}"))
}

fn take_layout_subgraph(cbor_map: &mut ciborium::Value) -> Result<Option<String>, String> {
    let ciborium::Value::Map(entries) = cbor_map else {
        return Ok(None);
    };

    let mut subgraph = None;
    entries.retain(|(key, value)| {
        let is_subgraph = matches!(key, ciborium::Value::Text(key) if key == "subgraph");
        if is_subgraph {
            subgraph = Some(value.clone());
        }
        !is_subgraph
    });

    let Some(value) = subgraph else {
        return Ok(None);
    };

    match value {
        ciborium::Value::Null => Ok(None),
        ciborium::Value::Text(label) if label == "none" => Ok(None),
        ciborium::Value::Text(label) => Ok(Some(label)),
        other => Err(format!(
            "layout subgraph must be a base62 string or none, got {other:?}"
        )),
    }
}

fn decode_dot_string(arg: &[u8]) -> Result<&str, String> {
    std::str::from_utf8(arg).map_err(|_| "Invalid UTF-8".to_string())
}

pub fn parse_dot_graphs_bytes(arg: &[u8]) -> Result<Vec<u8>, String> {
    let dot_string = decode_dot_string(arg)?;
    let dots = DotGraphSet::from_string(dot_string).map_err(|err| err.to_string())?;
    let mut graph_bytes = Vec::with_capacity(dots.set.len());
    for dot in dots {
        graph_bytes.push(
            rkyv::to_bytes::<_, 4096>(&TypstGraph::from_dot(dot, &crate::default_figment()))
                .map(|bytes| bytes.to_vec())
                .map_err(|err| err.to_string())?,
        );
    }
    encode_cbor(&graph_bytes)
}

pub fn layout_parsed_graph_bytes(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    let mut cbor_map = decode_cbor_map(arg2)?;
    let subgraph_label = take_layout_subgraph(&mut cbor_map)?;
    let figment = Figment::from(Serialized::from(cbor_map, Profile::Default));

    let mut typst_graph = decode_typst_graph(arg)?;
    let subgraph = subgraph_label
        .as_deref()
        .map(|label| {
            SuBitGraph::from_base62(label, typst_graph.n_hedges()).ok_or_else(|| {
                format!(
                    "Invalid subgraph label {label:?} for graph with {} half edges",
                    typst_graph.n_hedges()
                )
            })
        })
        .transpose()?;

    typst_graph.layout_config = crate::LayoutConfig::from_figment(&figment);
    typst_graph.layout_with_subgraph(subgraph.as_ref())?;
    rkyv::to_bytes::<_, 4096>(&typst_graph)
        .map(|bytes| bytes.to_vec())
        .map_err(|err| err.to_string())
}

pub fn layout_parsed_graphs_bytes(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    let graph_bytes = decode_graph_bytes_list(arg)?;
    let mut graphs = Vec::with_capacity(graph_bytes.len());
    for graph_bytes in graph_bytes {
        graphs.push(layout_parsed_graph_bytes(&graph_bytes, arg2)?);
    }

    encode_cbor(&graphs)
}

pub fn layout_graph_bytes(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    let parsed = parse_dot_graphs_bytes(arg)?;
    layout_parsed_graphs_bytes(&parsed, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn parse_graph(arg: &[u8]) -> Result<Vec<u8>, String> {
    parse_dot_graphs_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_from_spec(arg: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_from_spec_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_with_data(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_with_data_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_apply_structural_patches(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_apply_structural_patches_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_node_data_by_name(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_node_data_by_name_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_edge_data_by_name(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_edge_data_by_name_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_set_node_data_by_name(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_set_node_data_by_name_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_set_edge_data_by_name(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_set_edge_data_by_name_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn layout_parsed_graph(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    layout_parsed_graph_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn layout_graph(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    layout_graph_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_info(arg: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_info_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_layout_snapshot(arg: &[u8], options: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_layout_snapshot_bytes(arg, options)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_impred_diagram(snapshot: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_impred_diagram_bytes(snapshot)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_impred_seed(request: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_impred_seed_bytes(request)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_impred_layout(
    snapshot: &[u8],
    seed: &[u8],
    options: &[u8],
) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_impred_layout_bytes(snapshot, seed, options)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_dot(arg: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_dot_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_nodes(arg: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_nodes_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_nodes_of(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_nodes_of_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_nodes_of_subgraph(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_nodes_of_archived_subgraph_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_edges(arg: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_edges_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_edges_of(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_edges_of_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_edges_of_subgraph(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_edges_of_archived_subgraph_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_cut(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    TypstGraph::cut_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_subgraph(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_subgraph_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_archived_subgraph(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_archived_subgraph_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_compass_subgraph(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_compass_subgraph_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_archived_compass_subgraph(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_archived_compass_subgraph_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn subgraph_size(arg: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::subgraph_size_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn subgraph_label(arg: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::subgraph_label_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn subgraph_hedges(arg: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::subgraph_hedges_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn subgraph_contains_hedge(arg: &[u8], arg2: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::subgraph_contains_hedge_bytes(arg, arg2)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_cycle_basis(arg: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_cycle_basis_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_spanning_forests(arg: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_spanning_forests_bytes(arg)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_join_by_edge_key(arg: &[u8], arg2: &[u8], arg3: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_join_by_edge_key_bytes(arg, arg2, arg3)
}

#[cfg(all(target_arch = "wasm32", feature = "typst-plugin"))]
#[wasm_func]
pub fn graph_join_by_hedge_key(arg: &[u8], arg2: &[u8], arg3: &[u8]) -> Result<Vec<u8>, String> {
    crate::graph_api::graph_join_by_hedge_key_bytes(arg, arg2, arg3)
}
