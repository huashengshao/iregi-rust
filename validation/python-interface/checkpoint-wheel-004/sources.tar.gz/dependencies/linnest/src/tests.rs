use crate::graph_api::TypstJoinResult;
use std::{collections::BTreeMap, fs};

use figment::providers::Serialized;
use figment::{Figment, Profile};
use linnet::half_edge::layout::{
    simulatedanneale::{anneal, Energy, GeoSchedule, Neighbor, SAConfig},
    spring::{Constraint, PinnedLayoutNeighbor, ShiftDirection},
};
use linnet::half_edge::subgraph::{Inclusion, ModifySubSet, SuBitGraph};
use linnet::half_edge::swap::Swap;
use linnet::half_edge::{involution::EdgeIndex, NodeIndex};
use linnet::{dot, parser::set::DotGraphSet};
use rand::{rngs::SmallRng, SeedableRng};
use serde::{Deserialize, Serialize};

use crate::{
    graph_apply_structural_patches_bytes, graph_archived_compass_subgraph_bytes,
    graph_compass_subgraph_bytes, graph_cycle_basis_bytes, graph_dot_bytes,
    graph_edge_data_by_name_bytes, graph_edges_bytes, graph_edges_of_archived_subgraph_bytes,
    graph_edges_of_bytes, graph_from_spec_bytes, graph_info_bytes, graph_node_data_by_name_bytes,
    graph_nodes_bytes, graph_nodes_of_archived_subgraph_bytes, graph_nodes_of_bytes,
    graph_set_edge_data_by_name_bytes, graph_set_node_data_by_name_bytes,
    graph_spanning_forests_bytes, graph_subgraph_bytes, graph_with_data_bytes, layout_graph_bytes,
    layout_parsed_graph_bytes, layout_parsed_graphs_bytes, parse_dot_graphs_bytes,
    subgraph_contains_hedge_bytes, subgraph_hedges_bytes, subgraph_label_bytes, CBORTypstGraph,
    DotPlacementExpr, PinConstraint, TreeInitCfg, TypstDotEdge, TypstDotGraphInfo, TypstDotNode,
    TypstGraph, TypstPoint,
};

fn test_figment() -> Figment {
    Figment::from(Serialized::from(
        BTreeMap::<String, String>::new(),
        Profile::Default,
    ))
}

fn empty_config_bytes() -> Vec<u8> {
    let mut bytes = Vec::new();
    ciborium::ser::into_writer(&BTreeMap::<String, String>::new(), &mut bytes).unwrap();
    bytes
}

#[derive(Serialize)]
struct TestGraphSpecEnvelope<'a, T> {
    schema: &'static str,
    version: u32,
    graph: &'a T,
}

fn encode_graph_spec<T: Serialize>(graph: &T) -> Vec<u8> {
    encode_cbor(&TestGraphSpecEnvelope {
        schema: crate::GRAPH_SPEC_SCHEMA,
        version: crate::GRAPH_SPEC_VERSION,
        graph,
    })
}

#[test]
fn graph_spec_rejects_unknown_schema_and_version() {
    let graph = TestGraphSpec {
        name: "empty".to_owned(),
        statements: BTreeMap::new(),
        nodes: Vec::new(),
        edges: Vec::new(),
    };
    let schema = encode_cbor(&TestGraphSpecEnvelope {
        schema: "other-graph-spec",
        version: crate::GRAPH_SPEC_VERSION,
        graph: &graph,
    });
    assert!(graph_from_spec_bytes(&schema)
        .unwrap_err()
        .contains("Invalid graph spec schema"));
    let version = encode_cbor(&TestGraphSpecEnvelope {
        schema: crate::GRAPH_SPEC_SCHEMA,
        version: crate::GRAPH_SPEC_VERSION + 1,
        graph: &graph,
    });
    assert!(graph_from_spec_bytes(&version)
        .unwrap_err()
        .contains("Unsupported graph spec version"));
}

#[test]
fn parsed_dot_layout_keys_do_not_configure_layout() {
    let graph = TypstGraph::from_dot(
        dot!(digraph {
            steps = 1
            seed = 99
            a -> b
        })
        .unwrap(),
        &test_figment(),
    );

    assert!(matches!(
        graph.layout_config.layout_algo,
        crate::LayoutAlgo::Force
    ));
    assert_eq!(graph.layout_config.schedule.steps, 100);
    assert_eq!(graph.layout_config.schedule.epochs, 30);
    assert_eq!(graph.layout_config.seed, 2);
    assert_eq!(
        graph.global_statements.get("steps").map(String::as_str),
        Some("1")
    );
    assert_eq!(
        graph.global_statements.get("seed").map(String::as_str),
        Some("99")
    );
}

#[test]
fn explicit_layout_figment_configures_layout() {
    assert_eq!(
        crate::LayoutConfig::default().subgraph_mode,
        crate::LayoutSubgraphMode::FixedBoundary
    );
    let figment = Figment::from(Serialized::from(
        BTreeMap::from([
            ("layout-algo".to_string(), "tree".to_string()),
            ("label-layout".to_string(), "fixed-length".to_string()),
            ("subgraph-mode".to_string(), "isolated".to_string()),
            ("tree-dx".to_string(), "3.0".to_string()),
        ]),
        Profile::Default,
    ));
    let graph = TypstGraph::from_dot(dot!(digraph { a -> b }).unwrap(), &figment);

    assert!(matches!(
        graph.layout_config.layout_algo,
        crate::LayoutAlgo::Tree
    ));
    assert!(matches!(
        graph.layout_config.label_layout,
        crate::LabelLayout::FixedLength
    ));
    assert_eq!(
        graph.layout_config.subgraph_mode,
        crate::LayoutSubgraphMode::Isolated
    );
    assert_eq!(graph.layout_config.tree_dx, 3.0);
}

fn decode_graphs(bytes: &[u8]) -> Vec<Vec<u8>> {
    ciborium::de::from_reader(bytes).unwrap()
}

fn encode_cbor<T: Serialize>(value: &T) -> Vec<u8> {
    let mut bytes = Vec::new();
    ciborium::ser::into_writer(value, &mut bytes).unwrap();
    bytes
}

fn decode_cbor<T: for<'de> Deserialize<'de>>(bytes: &[u8]) -> T {
    ciborium::de::from_reader(bytes).unwrap()
}

fn one_statement(key: &str, value: &str) -> BTreeMap<String, String> {
    BTreeMap::from([(key.to_string(), value.to_string())])
}

fn assert_point_close(left: &TypstPoint, right: &TypstPoint) {
    assert!((left.x - right.x).abs() < 1e-9, "{left:?} != {right:?}");
    assert!((left.y - right.y).abs() < 1e-9, "{left:?} != {right:?}");
}

#[test]
fn test_pin_direction_syntaxes_parse() {
    assert!(matches!(
        PinConstraint::parse("x:@+right"),
        Some(PinConstraint::LinkX(group)) if group == "+right"
    ));
    assert!(matches!(
        PinConstraint::parse("x:+@right"),
        Some(PinConstraint::LinkX(group)) if group == "+right"
    ));
    assert!(matches!(
        PinConstraint::parse("y:@-edge0"),
        Some(PinConstraint::LinkY(group)) if group == "-edge0"
    ));
    assert!(matches!(
        PinConstraint::parse("y:-@edge0"),
        Some(PinConstraint::LinkY(group)) if group == "-edge0"
    ));
}

#[test]
fn dot_pos_refs_resolve_by_explicit_node_and_edge_ids() {
    let figment = test_figment();
    let typst_graph = TypstGraph::from_dot(
        dot!(digraph {
            a [id=0 pos="1,2!"]
            b [id=1 pos="ref(node:0)+3,-1!"]
            c [id=2]
            a -> b [id=0 pos="ref(node:1)+0,2!"]
            b -> c [id=1 pos="ref(edge:0)+1,0!"]
        })
        .unwrap(),
        &figment,
    );

    let mut node_positions = BTreeMap::new();
    for (_, _, node) in typst_graph.iter_nodes() {
        node_positions.insert(node.index.unwrap().0, node.pos);
    }

    assert_eq!(node_positions[&0].x, 1.0);
    assert_eq!(node_positions[&0].y, 2.0);
    assert_eq!(node_positions[&1].x, 4.0);
    assert_eq!(node_positions[&1].y, 1.0);

    let mut edge_positions = BTreeMap::new();
    for (_, edge_index, edge) in typst_graph.iter_edges() {
        edge_positions.insert(edge_index.0, edge.data.pos);
    }

    assert_eq!(edge_positions[&0].x, 4.0);
    assert_eq!(edge_positions[&0].y, 3.0);
    assert_eq!(edge_positions[&1].x, 5.0);
    assert_eq!(edge_positions[&1].y, 3.0);
}

#[test]
fn dot_pos_constraint_value_replaces_external_pin_attribute() {
    let figment = test_figment();
    let typst_graph = TypstGraph::from_dot(
        dot!(digraph {
            ext [style=invis]
            a
            ext -> a [id=0 pos="x:@-left!,y:@edge0!"]
        })
        .unwrap(),
        &figment,
    );

    let (_, _, edge) = typst_graph.iter_edges().next().unwrap();
    assert!(matches!(
        edge.data.constraints.x,
        Constraint::Grouped(_, ShiftDirection::NegativeOnly)
    ));
    assert!(matches!(
        edge.data.constraints.y,
        Constraint::Grouped(_, ShiftDirection::Any)
    ));
    assert_eq!(
        edge.data.statements.get("pos").map(String::as_str),
        Some("0,0")
    );
    assert_eq!(
        edge.data.statements.get("pin").map(String::as_str),
        Some("x:@-left,y:@edge0")
    );

    let serialized = typst_graph.to_dot_graph().debug_dot();
    let reparsed = TypstGraph::parse(&serialized).unwrap();
    let (_, _, edge) = reparsed.iter_edges().next().unwrap();
    assert!(matches!(
        edge.data.constraints.x,
        Constraint::Grouped(_, ShiftDirection::NegativeOnly)
    ));
    assert!(matches!(
        edge.data.constraints.y,
        Constraint::Grouped(_, ShiftDirection::Any)
    ));
}

#[test]
fn dot_pos_axis_constraints_support_numeric_partial_pins() {
    let figment = test_figment();
    let typst_graph = TypstGraph::from_dot(
        dot!(digraph {
            a [id=0 pos="x:2!"]
            b [id=1 pos="y:-1!"]
            a -> b [pos="x:5!"]
        })
        .unwrap(),
        &figment,
    );

    let mut nodes = BTreeMap::new();
    for (_, _, node) in typst_graph.iter_nodes() {
        nodes.insert(node.index.unwrap().0, node);
    }

    assert_eq!(nodes[&0].pos.x, 2.0);
    assert_eq!(nodes[&0].pos.y, 0.0);
    assert_eq!((nodes[&0].start_x, nodes[&0].start_y), (true, false));
    assert!(matches!(nodes[&0].constraints.x, Constraint::Fixed));
    assert!(matches!(nodes[&0].constraints.y, Constraint::Free));

    assert_eq!(nodes[&1].pos.x, 0.0);
    assert_eq!(nodes[&1].pos.y, -1.0);
    assert_eq!((nodes[&1].start_x, nodes[&1].start_y), (false, true));
    assert!(matches!(nodes[&1].constraints.x, Constraint::Free));
    assert!(matches!(nodes[&1].constraints.y, Constraint::Fixed));

    let (_, _, edge) = typst_graph.iter_edges().next().unwrap();
    assert_eq!(edge.data.pos.x, 5.0);
    assert_eq!(edge.data.pos.y, 0.0);
    assert_eq!((edge.data.start_x, edge.data.start_y), (true, false));

    let serialized = typst_graph.to_dot_graph().debug_dot();
    let mut reparsed = TypstGraph::parse(&serialized).unwrap();
    let mut nodes = BTreeMap::new();
    for (_, _, node) in reparsed.iter_nodes() {
        nodes.insert(node.name.as_deref().unwrap(), node);
    }
    assert!(matches!(nodes["a"].constraints.x, Constraint::Fixed));
    assert!(matches!(nodes["a"].constraints.y, Constraint::Free));
    assert!(matches!(nodes["b"].constraints.x, Constraint::Free));
    assert!(matches!(nodes["b"].constraints.y, Constraint::Fixed));

    let (_, _, edge) = reparsed.iter_edges().next().unwrap();
    assert_eq!((edge.data.start_x, edge.data.start_y), (true, false));
    assert!(matches!(edge.data.constraints.x, Constraint::Fixed));
    assert!(matches!(edge.data.constraints.y, Constraint::Free));

    reparsed.layout();
    let mut nodes = BTreeMap::new();
    for (_, _, node) in reparsed.iter_nodes() {
        nodes.insert(node.name.as_deref().unwrap(), node);
    }
    assert_eq!(nodes["a"].pos.x, 2.0);
    assert_eq!(nodes["b"].pos.y, -1.0);
    let (_, _, edge) = reparsed.iter_edges().next().unwrap();
    assert_eq!(edge.data.pos.x, 5.0);
}

#[test]
fn dot_pos_axis_bangs_apply_per_axis() {
    let figment = test_figment();
    let typst_graph = TypstGraph::from_dot(
        dot!(digraph {
            a [id=0 pos="x:2!,y:3"]
            b [id=1 pos="x:4,y:-1!"]
            a -> b
        })
        .unwrap(),
        &figment,
    );

    let mut nodes = BTreeMap::new();
    for (_, _, node) in typst_graph.iter_nodes() {
        nodes.insert(node.index.unwrap().0, node);
    }

    assert_eq!(nodes[&0].pos.x, 2.0);
    assert_eq!(nodes[&0].pos.y, 3.0);
    assert!(matches!(nodes[&0].constraints.x, Constraint::Fixed));
    assert!(matches!(nodes[&0].constraints.y, Constraint::Free));

    assert_eq!(nodes[&1].pos.x, 4.0);
    assert_eq!(nodes[&1].pos.y, -1.0);
    assert!(matches!(nodes[&1].constraints.x, Constraint::Free));
    assert!(matches!(nodes[&1].constraints.y, Constraint::Fixed));
}

#[test]
fn dot_pos_group_axis_requires_axis_bang() {
    let err = DotPlacementExpr::parse("x:@left,y:0").unwrap_err();
    assert!(err.contains("must be pinned with !"));
}

#[test]
fn quoted_dot_statement_keys_are_normalized() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph {
            ext [style=invis]
            ext -> a [id=0 label="$x$" "label-pos"="1,1" "label-anchor"="east"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    let edge = edges.first().unwrap();

    assert_eq!(edge.label_pos, Some(crate::TypstPoint { x: 1.0, y: 1.0 }));
    assert_eq!(
        edge.statements.get("label-anchor").map(String::as_str),
        Some("east")
    );
    assert!(!edge.statements.contains_key("\"label-anchor\""));
}

#[test]
fn explicit_dot_bend_survives_parse_and_layout() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph {
            ext [style=invis]
            a -> ext [id=0 bend=19]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    assert_eq!(edges[0].bend, Some(19.0));

    let laid_out = layout_parsed_graph_bytes(&graph, &empty_config_bytes()).unwrap();
    let laid_out_edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
    assert_eq!(laid_out_edges[0].bend, Some(19.0));
}

#[derive(Serialize)]
struct TestGraphSpec {
    name: String,
    #[serde(default)]
    statements: BTreeMap<String, String>,
    nodes: Vec<TestNodeSpec>,
    edges: Vec<TestEdgeSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "kebab-case")]
struct TestTemplatedGraphSpec {
    name: String,
    #[serde(default)]
    statements: BTreeMap<String, String>,
    #[serde(default)]
    default_edge_statements: BTreeMap<String, String>,
    #[serde(default)]
    default_node_statements: BTreeMap<String, String>,
    nodes: Vec<TestNodeSpec>,
    edges: Vec<TestEdgeSpec>,
}

#[derive(Serialize)]
struct TestNodeSpec {
    name: String,
    #[serde(default)]
    statements: BTreeMap<String, String>,
}

#[derive(Serialize)]
struct TestEdgeSpec {
    #[serde(skip_serializing_if = "Option::is_none")]
    source: Option<TestEndpointSpec>,
    #[serde(skip_serializing_if = "Option::is_none")]
    sink: Option<TestEndpointSpec>,
    #[serde(default)]
    statements: BTreeMap<String, String>,
}

#[derive(Serialize)]
struct TestPlacementGraphSpec {
    name: String,
    nodes: Vec<TestPlacedNodeSpec>,
    edges: Vec<TestPlacedEdgeSpec>,
}

#[derive(Serialize)]
struct TestPlacedNodeSpec {
    name: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pos: Option<TestPlacementSpec>,
    #[serde(default)]
    statements: BTreeMap<String, String>,
}

#[derive(Serialize)]
struct TestPlacedEdgeSpec {
    #[serde(skip_serializing_if = "Option::is_none")]
    source: Option<TestEndpointSpec>,
    #[serde(skip_serializing_if = "Option::is_none")]
    sink: Option<TestEndpointSpec>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pos: Option<TestPlacementSpec>,
    #[serde(default)]
    statements: BTreeMap<String, String>,
}

#[derive(Serialize)]
struct TestStructuralPatch {
    #[serde(default)]
    nodes: Vec<TestNodeStructuralPatch>,
    #[serde(default)]
    edges: Vec<TestEdgeStructuralPatch>,
    #[serde(default)]
    hedges: Vec<TestHedgeStructuralPatch>,
}

#[derive(Serialize)]
#[serde(rename_all = "kebab-case")]
struct TestNodeStructuralPatch {
    index: usize,
    #[serde(skip_serializing_if = "Option::is_none")]
    pos: Option<TestPlacementSpec>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    statements: BTreeMap<String, String>,
}

#[derive(Serialize)]
#[serde(rename_all = "kebab-case")]
struct TestEdgeStructuralPatch {
    index: usize,
    #[serde(skip_serializing_if = "Option::is_none")]
    pos: Option<TestPlacementSpec>,
    #[serde(skip_serializing_if = "Option::is_none")]
    label_pos: Option<(f64, f64)>,
    #[serde(skip_serializing_if = "Option::is_none")]
    bend: Option<f64>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    statements: BTreeMap<String, String>,
}

#[derive(Serialize)]
#[serde(rename_all = "kebab-case")]
struct TestHedgeStructuralPatch {
    index: usize,
    #[serde(skip_serializing_if = "Option::is_none")]
    statement: Option<&'static str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    port_label: Option<&'static str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    compass: Option<&'static str>,
}

#[derive(Serialize)]
#[serde(rename_all = "kebab-case")]
struct TestPlacementSpec {
    #[serde(skip_serializing_if = "Option::is_none")]
    mode: Option<&'static str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    x: Option<TestPlacementCoord>,
    #[serde(skip_serializing_if = "Option::is_none")]
    y: Option<TestPlacementCoord>,
    #[serde(skip_serializing_if = "Option::is_none", rename = "ref")]
    reference: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    dx: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    dy: Option<f64>,
}

#[derive(Serialize)]
#[serde(untagged)]
enum TestPlacementCoord {
    Number(f64),
    Group(TestPlacementGroup),
}

#[derive(Serialize)]
struct TestPlacementGroup {
    kind: &'static str,
    name: &'static str,
    #[serde(skip_serializing_if = "Option::is_none")]
    side: Option<&'static str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    start: Option<f64>,
}

#[derive(Serialize)]
struct TestEndpointSpec {
    node: usize,
    #[serde(skip_serializing_if = "Option::is_none")]
    compass: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    statement: Option<String>,
}

#[test]
fn test_parse_pass_returns_archived_typst_graphs() {
    let parsed =
        parse_dot_graphs_bytes(br#"digraph first { a -> b } digraph second { c -> d }"#).unwrap();

    let archived = decode_graphs(&parsed);

    assert_eq!(archived.len(), 2);
    let first = crate::graph_api::decode_typst_graph(&archived[0]).unwrap();
    let second = crate::graph_api::decode_typst_graph(&archived[1]).unwrap();
    assert_eq!(first.name, "first");
    assert_eq!(second.name, "second");
}

#[test]
fn graph_archive_boundaries_validate_bytes_without_requiring_input_alignment() {
    let parsed = parse_dot_graphs_bytes(br#"digraph safe { a -> b }"#).unwrap();
    let graph = decode_graphs(&parsed).pop().unwrap();

    assert!(graph_info_bytes(&graph[..graph.len() / 2]).is_err());

    let mut misaligned = rkyv::AlignedVec::with_capacity(graph.len() + 1);
    misaligned.push(0);
    misaligned.extend_from_slice(&graph);
    assert_ne!(
        misaligned[1..]
            .as_ptr()
            .align_offset(std::mem::align_of::<rkyv::Archived<TypstGraph>>()),
        0
    );
    let info: TypstDotGraphInfo = decode_cbor(&graph_info_bytes(&misaligned[1..]).unwrap());
    assert_eq!(info.name, "safe");

    let subgraph = graph_archived_compass_subgraph_bytes(&graph, &encode_cbor(&"none")).unwrap();
    assert!(subgraph_label_bytes(&subgraph[..subgraph.len() / 2]).is_err());

    let mut misaligned = rkyv::AlignedVec::with_capacity(subgraph.len() + 1);
    misaligned.push(0);
    misaligned.extend_from_slice(&subgraph);
    assert!(subgraph_label_bytes(&misaligned[1..]).is_ok());
}

#[test]
fn test_graph_query_api_reads_nodes_edges_and_subgraphs() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph first {
            graph [full_num="x+y"];
            a [eval="left"];
            b [eval="right"];
            a:out:n -> b:in:s [label="ab"];
            ext -> a [dir=back, source="src"];
        }"#,
    )
    .unwrap();

    let graphs = decode_graphs(&parsed);
    let graph = &graphs[0];

    let info: TypstDotGraphInfo =
        ciborium::de::from_reader(graph_info_bytes(graph).unwrap().as_slice()).unwrap();
    assert_eq!(info.name, "first");
    assert_eq!(
        info.global_statements.get("full_num").map(String::as_str),
        Some("x+y")
    );

    let nodes: Vec<TypstDotNode> =
        ciborium::de::from_reader(graph_nodes_bytes(graph).unwrap().as_slice()).unwrap();
    assert_eq!(nodes.len(), 3);
    assert_eq!(nodes[0].name.as_deref(), Some("a"));

    let edges: Vec<TypstDotEdge> =
        ciborium::de::from_reader(graph_edges_bytes(graph).unwrap().as_slice()).unwrap();
    assert_eq!(edges.len(), 2);
    assert_eq!(edges[0].orientation, "default");

    let north = graph_compass_subgraph_bytes(graph, &encode_cbor(&"n")).unwrap();
    let north_label: String = ciborium::de::from_reader(north.as_slice()).unwrap();

    let north_edges: Vec<TypstDotEdge> = ciborium::de::from_reader(
        graph_edges_of_bytes(graph, &encode_cbor(&north_label))
            .unwrap()
            .as_slice(),
    )
    .unwrap();
    assert_eq!(north_edges.len(), 1);

    let view = crate::graph_api::decode_typst_graph(graph).unwrap();
    let mut south_bits = vec![false; view.n_hedges()];
    south_bits[view.n_hedges() - 1] = true;
    let subgraph = graph_subgraph_bytes(graph, &encode_cbor(&south_bits)).unwrap();
    let south_label: String = ciborium::de::from_reader(subgraph.as_slice()).unwrap();
    let south_nodes: Vec<TypstDotNode> = ciborium::de::from_reader(
        graph_nodes_of_bytes(graph, &encode_cbor(&south_label))
            .unwrap()
            .as_slice(),
    )
    .unwrap();
    assert_eq!(south_nodes.len(), 1);
}

#[test]
fn test_graph_spec_constructor_reads_nodes_edges_and_subgraphs() {
    let spec = TestGraphSpec {
        name: "constructed".to_string(),
        statements: one_statement("full_num", "x+y"),
        nodes: vec![
            TestNodeSpec {
                name: "a".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "b".to_string(),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![
            TestEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 0,
                    compass: Some("e".to_string()),
                    statement: Some("out".to_string()),
                }),
                sink: Some(TestEndpointSpec {
                    node: 1,
                    compass: Some("w".to_string()),
                    statement: Some("in".to_string()),
                }),
                statements: one_statement("label", "a-to-b"),
            },
            TestEdgeSpec {
                source: None,
                sink: Some(TestEndpointSpec {
                    node: 0,
                    compass: Some("n".to_string()),
                    statement: None,
                }),
                statements: one_statement("label", "incoming"),
            },
            TestEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 1,
                    compass: Some("s".to_string()),
                    statement: None,
                }),
                sink: None,
                statements: one_statement("label", "outgoing"),
            },
        ],
    };

    let graph = graph_from_spec_bytes(&encode_graph_spec(&spec)).unwrap();
    let info: TypstDotGraphInfo =
        ciborium::de::from_reader(graph_info_bytes(&graph).unwrap().as_slice()).unwrap();
    assert_eq!(info.name, "constructed");
    assert_eq!(
        info.global_statements.get("full_num").map(String::as_str),
        Some("x+y")
    );

    let nodes: Vec<TypstDotNode> =
        ciborium::de::from_reader(graph_nodes_bytes(&graph).unwrap().as_slice()).unwrap();
    assert_eq!(nodes.len(), 2);

    let edges: Vec<TypstDotEdge> =
        ciborium::de::from_reader(graph_edges_bytes(&graph).unwrap().as_slice()).unwrap();
    assert_eq!(edges.len(), 3);

    let dot: String =
        ciborium::de::from_reader(graph_dot_bytes(&graph).unwrap().as_slice()).unwrap();
    assert!(dot.contains("digraph constructed"));
    assert!(dot.contains("a"));
    assert!(dot.contains("b"));

    let north = graph_compass_subgraph_bytes(&graph, &encode_cbor(&"n")).unwrap();
    let north_label: String = ciborium::de::from_reader(north.as_slice()).unwrap();
    let north_edges: Vec<TypstDotEdge> = ciborium::de::from_reader(
        graph_edges_of_bytes(&graph, &encode_cbor(&north_label))
            .unwrap()
            .as_slice(),
    )
    .unwrap();
    assert_eq!(north_edges.len(), 1);

    let internal =
        graph_subgraph_bytes(&graph, &encode_cbor(&vec![true, true, false, false])).unwrap();
    let internal_label: String = ciborium::de::from_reader(internal.as_slice()).unwrap();
    let internal_nodes: Vec<TypstDotNode> = ciborium::de::from_reader(
        graph_nodes_of_bytes(&graph, &encode_cbor(&internal_label))
            .unwrap()
            .as_slice(),
    )
    .unwrap();
    assert_eq!(internal_nodes.len(), 2);
}

#[test]
fn graph_spec_underscore_compass_round_trips_through_archived_views() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestGraphSpec {
        name: "underscore".to_string(),
        statements: BTreeMap::new(),
        nodes: vec![
            TestNodeSpec {
                name: "a".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "b".to_string(),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![TestEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: Some("_".to_string()),
                statement: None,
            }),
            sink: Some(TestEndpointSpec {
                node: 1,
                compass: None,
                statement: None,
            }),
            statements: BTreeMap::new(),
        }],
    }))
    .unwrap();

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    assert_eq!(
        edges[0].source.as_ref().unwrap().compass.as_deref(),
        Some("_")
    );

    let label: String =
        decode_cbor(&graph_compass_subgraph_bytes(&graph, &encode_cbor(&"_")).unwrap());
    let selected: Vec<TypstDotEdge> =
        decode_cbor(&graph_edges_of_bytes(&graph, &encode_cbor(&label)).unwrap());
    assert_eq!(selected.len(), 1);
}

#[test]
fn test_graph_spec_data_are_opaque_and_survive_layout() {
    #[derive(Serialize)]
    struct DataGraphSpec {
        name: String,
        data: Vec<u8>,
        nodes: Vec<DataNodeSpec>,
        edges: Vec<DataEdgeSpec>,
    }

    #[derive(Serialize)]
    struct DataNodeSpec {
        name: String,
        data: Vec<u8>,
    }

    #[derive(Serialize)]
    struct DataEdgeSpec {
        data: Vec<u8>,
        source: DataEndpointSpec,
        sink: DataEndpointSpec,
    }

    #[derive(Serialize)]
    struct DataEndpointSpec {
        node: usize,
        data: Vec<u8>,
    }

    fn assert_data(graph: &[u8]) {
        let info: TypstDotGraphInfo = decode_cbor(&graph_info_bytes(graph).unwrap());
        assert_eq!(info.data.as_deref(), Some(&b"graph"[..]));

        let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(graph).unwrap());
        assert_eq!(nodes[0].data.as_deref(), Some(&b"node-a"[..]));
        assert_eq!(nodes[1].data.as_deref(), Some(&b"node-b"[..]));

        let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(graph).unwrap());
        assert_eq!(edges[0].data.as_deref(), Some(&b"edge"[..]));
        assert_eq!(
            edges[0]
                .source
                .as_ref()
                .and_then(|source| source.data.as_deref()),
            Some(&b"source"[..])
        );
        assert_eq!(
            edges[0].sink.as_ref().and_then(|sink| sink.data.as_deref()),
            Some(&b"sink"[..])
        );
    }

    let spec = DataGraphSpec {
        name: "data".to_string(),
        data: b"graph".to_vec(),
        nodes: vec![
            DataNodeSpec {
                name: "a".to_string(),
                data: b"node-a".to_vec(),
            },
            DataNodeSpec {
                name: "b".to_string(),
                data: b"node-b".to_vec(),
            },
        ],
        edges: vec![DataEdgeSpec {
            data: b"edge".to_vec(),
            source: DataEndpointSpec {
                node: 0,
                data: b"source".to_vec(),
            },
            sink: DataEndpointSpec {
                node: 1,
                data: b"sink".to_vec(),
            },
        }],
    };

    let graph = graph_from_spec_bytes(&encode_graph_spec(&spec)).unwrap();
    assert_data(&graph);

    let laid_out = layout_parsed_graph_bytes(&graph, &empty_config_bytes()).unwrap();
    assert_data(&laid_out);
}

#[test]
fn test_parsed_graph_data_patch_sets_opaque_data() {
    #[derive(Serialize)]
    struct DataPatch {
        data: Vec<u8>,
        nodes: Vec<IndexedDataPatch>,
        edges: Vec<EdgeDataPatch>,
    }

    #[derive(Serialize)]
    struct IndexedDataPatch {
        index: usize,
        data: Vec<u8>,
    }

    #[derive(Serialize)]
    struct EdgeDataPatch {
        index: usize,
        data: Vec<u8>,
        source: Vec<u8>,
        sink: Vec<u8>,
    }

    let parsed = parse_dot_graphs_bytes(
        br#"digraph data {
            graph [label="graph"];
            a [label="node"];
            b;
            a:e -> b:w [label="edge", source="src", sink="snk"];
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let patched = graph_with_data_bytes(
        &graph,
        &encode_cbor(&DataPatch {
            data: b"graph-data".to_vec(),
            nodes: vec![IndexedDataPatch {
                index: 0,
                data: b"node-data".to_vec(),
            }],
            edges: vec![EdgeDataPatch {
                index: 0,
                data: b"edge-data".to_vec(),
                source: b"source-data".to_vec(),
                sink: b"sink-data".to_vec(),
            }],
        }),
    )
    .unwrap();

    let info: TypstDotGraphInfo = decode_cbor(&graph_info_bytes(&patched).unwrap());
    assert_eq!(info.data.as_deref(), Some(&b"graph-data"[..]));

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&patched).unwrap());
    assert_eq!(nodes[0].data.as_deref(), Some(&b"node-data"[..]));

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&patched).unwrap());
    assert_eq!(edges[0].data.as_deref(), Some(&b"edge-data"[..]));
    assert_eq!(
        edges[0]
            .source
            .as_ref()
            .and_then(|source| source.data.as_deref()),
        Some(&b"source-data"[..])
    );
    assert_eq!(
        edges[0].sink.as_ref().and_then(|sink| sink.data.as_deref()),
        Some(&b"sink-data"[..])
    );
}

#[test]
fn test_named_node_and_edge_data_api() {
    #[derive(Serialize)]
    struct NamedData<'a> {
        name: &'a str,
        data: Vec<u8>,
    }

    let mut edge_statements = one_statement("__linnest-edge-name", "e1");
    edge_statements.insert("label".to_string(), "a-b".to_string());
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestGraphSpec {
        name: "named-data".to_string(),
        statements: BTreeMap::new(),
        nodes: vec![
            TestNodeSpec {
                name: "a".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "b".to_string(),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![TestEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: None,
            }),
            sink: Some(TestEndpointSpec {
                node: 1,
                compass: None,
                statement: None,
            }),
            statements: edge_statements,
        }],
    }))
    .unwrap();

    let node_data: Option<Vec<u8>> =
        decode_cbor(&graph_node_data_by_name_bytes(&graph, &encode_cbor(&"a")).unwrap());
    assert_eq!(node_data, None);

    let graph = graph_set_node_data_by_name_bytes(
        &graph,
        &encode_cbor(&NamedData {
            name: "a",
            data: b"node-data".to_vec(),
        }),
    )
    .unwrap();
    let graph = graph_set_edge_data_by_name_bytes(
        &graph,
        &encode_cbor(&NamedData {
            name: "e1",
            data: b"edge-data".to_vec(),
        }),
    )
    .unwrap();

    let node_data: Option<Vec<u8>> =
        decode_cbor(&graph_node_data_by_name_bytes(&graph, &encode_cbor(&"a")).unwrap());
    assert_eq!(node_data.as_deref(), Some(&b"node-data"[..]));
    let edge_data: Option<Vec<u8>> =
        decode_cbor(&graph_edge_data_by_name_bytes(&graph, &encode_cbor(&"e1")).unwrap());
    assert_eq!(edge_data.as_deref(), Some(&b"edge-data"[..]));

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    assert_eq!(edges[0].name.as_deref(), Some("e1"));
    assert!(!edges[0].statements.contains_key("__linnest-edge-name"));

    let dot: String = decode_cbor(&graph_dot_bytes(&graph).unwrap());
    assert!(!dot.contains("__linnest-edge-name"));
}

#[test]
fn graph_spec_edge_name_is_first_class() {
    #[derive(Serialize)]
    struct NamedGraphSpec {
        nodes: Vec<TestNodeSpec>,
        edges: Vec<NamedEdgeSpec>,
    }

    #[derive(Serialize)]
    struct NamedEdgeSpec {
        name: &'static str,
        source: TestEndpointSpec,
        sink: TestEndpointSpec,
    }

    let graph = graph_from_spec_bytes(&encode_graph_spec(&NamedGraphSpec {
        nodes: vec![
            TestNodeSpec {
                name: "a".to_owned(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "b".to_owned(),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![NamedEdgeSpec {
            name: "a-to-b",
            source: TestEndpointSpec {
                node: 0,
                compass: None,
                statement: None,
            },
            sink: TestEndpointSpec {
                node: 1,
                compass: None,
                statement: None,
            },
        }],
    }))
    .unwrap();
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    assert_eq!(edges[0].name.as_deref(), Some("a-to-b"));
    assert!(!edges[0].statements.contains_key("__linnest-edge-name"));
}

#[test]
fn fixed_length_label_layout_keeps_label_radius() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestGraphSpec {
        name: "fixed-label".to_string(),
        statements: BTreeMap::new(),
        nodes: vec![TestNodeSpec {
            name: "a".to_string(),
            statements: BTreeMap::new(),
        }],
        edges: vec![TestEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: None,
            }),
            sink: None,
            statements: BTreeMap::new(),
        }],
    }))
    .unwrap();

    let label_distance = |label_layout: &str| {
        let laid_out = layout_parsed_graph_bytes(
            &graph,
            &encode_cbor(&BTreeMap::from([
                ("layout-algo".to_string(), "tree".to_string()),
                ("label-layout".to_string(), label_layout.to_string()),
                ("label-spring".to_string(), "0".to_string()),
                ("label-charge".to_string(), "100".to_string()),
                ("label-steps".to_string(), "2".to_string()),
            ])),
        )
        .unwrap();
        let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
        let edge = edges.first().unwrap();
        let edge_pos = edge.pos.as_ref().unwrap();
        let label_pos = edge.label_pos.as_ref().unwrap();
        let dx = label_pos.x - edge_pos.x;
        let dy = label_pos.y - edge_pos.y;
        (dx * dx + dy * dy).sqrt()
    };

    let expected_radius = crate::default_label_length_scale()
        * crate::default_length_scale()
        * (crate::default_viewport_w() * crate::default_viewport_h()).sqrt();
    let fixed_distance = label_distance("fixed-length");
    let normal_distance = label_distance("normal");

    assert!((fixed_distance - expected_radius).abs() < 1e-9);
    assert!((normal_distance - expected_radius).abs() > 1e-3);
}

#[test]
fn measured_label_collision_pass_preserves_repulsion() {
    for label_size in [0.0, 0.2] {
        let dot = format!(
            r#"digraph {{
                a [pos="-2,0!" "layout-width"="0.2" "layout-height"="0.2"]
                b [pos="2,0!" "layout-width"="0.2" "layout-height"="0.2"]
                a -> b [pos="0,0!" "label-width"="{label_size}" "label-height"="{label_size}"]
            }}"#
        );
        let graph = decode_graphs(&parse_dot_graphs_bytes(dot.as_bytes()).unwrap()).remove(0);

        for (charge, expected_y) in [("0", 1.0), ("100", 1.1)] {
            let config = BTreeMap::from([
                ("layout-algo", "tree"),
                ("layout-nodes", "fixed"),
                ("viewport-w", "2"),
                ("viewport-h", "1"),
                ("length-scale", "1"),
                ("label-layout", "normal"),
                ("internal-label-length-scale", "1"),
                ("label-spring", "0"),
                ("label-charge", charge),
                ("label-steps", "1"),
                ("label-step", "1"),
                ("label-max-delta-scale", "0.1"),
            ]);
            let laid_out = layout_parsed_graph_bytes(&graph, &encode_cbor(&config)).unwrap();
            let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
            assert_point_close(
                edges[0].pos.as_ref().unwrap(),
                &TypstPoint { x: 0.0, y: 0.0 },
            );
            // Symmetric repulsion moves the label upward by the configured step cap.
            // Its measured box is collision-free, so placement must retain that move.
            assert_point_close(
                edges[0].label_pos.as_ref().unwrap(),
                &TypstPoint {
                    x: 0.0,
                    y: expected_y,
                },
            );
        }
    }
}

#[test]
fn dangling_tangent_label_layout_keeps_paired_labels_normal() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestPlacementGraphSpec {
        name: "dangling-tangent-label".to_string(),
        nodes: vec![
            TestPlacedNodeSpec {
                name: "a".to_string(),
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Number(0.0)),
                    y: Some(TestPlacementCoord::Number(0.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                statements: BTreeMap::new(),
            },
            TestPlacedNodeSpec {
                name: "b".to_string(),
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Number(2.0)),
                    y: Some(TestPlacementCoord::Number(0.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![
            TestPlacedEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: None,
                }),
                sink: None,
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Number(2.0)),
                    y: Some(TestPlacementCoord::Number(0.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                statements: BTreeMap::new(),
            },
            TestPlacedEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: None,
                }),
                sink: Some(TestEndpointSpec {
                    node: 1,
                    compass: None,
                    statement: None,
                }),
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Number(1.0)),
                    y: Some(TestPlacementCoord::Number(0.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                statements: BTreeMap::new(),
            },
        ],
    }))
    .unwrap();

    for (internal, external) in [(0.6_f64, 0.6_f64), (0.9, 0.6), (0.6, 1.2)] {
        let laid_out = layout_parsed_graph_bytes(
            &graph,
            &encode_cbor(&BTreeMap::from([
                ("layout-algo".to_string(), "tree".to_string()),
                ("layout-nodes".to_string(), "fixed".to_string()),
                ("label-layout".to_string(), "dangling-tangent".to_string()),
                ("label-charge".to_string(), "0".to_string()),
                (
                    "internal-label-length-scale".to_string(),
                    internal.to_string(),
                ),
                (
                    "external-label-length-scale".to_string(),
                    external.to_string(),
                ),
                ("label-steps".to_string(), "1".to_string()),
            ])),
        )
        .unwrap();
        let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
        let spring_length = crate::default_length_scale()
            * (crate::default_viewport_w() * crate::default_viewport_h() / 2.0).sqrt();

        let expected_offset = external * spring_length;
        let dangling = &edges[0];
        let dangling_pos = dangling.pos.as_ref().unwrap();
        let dangling_label = dangling.label_pos.as_ref().unwrap();
        let dangling_dx = dangling_label.x - dangling_pos.x;
        let dangling_dy = dangling_label.y - dangling_pos.y;
        assert!(
            (dangling_dx - expected_offset).abs() < 1e-9,
            "{dangling_dx} != {expected_offset}"
        );
        assert!(dangling_dy.abs() < 1e-9, "{dangling_dy} != 0");

        let expected_offset = internal * spring_length;
        let paired = &edges[1];
        let paired_pos = paired.pos.as_ref().unwrap();
        let paired_label = paired.label_pos.as_ref().unwrap();
        let paired_dx = paired_label.x - paired_pos.x;
        let paired_dy = paired_label.y - paired_pos.y;
        assert!(paired_dx.abs() < 1e-9, "{paired_dx} != 0");
        assert!(
            (paired_dy - expected_offset).abs() < 1e-9,
            "{paired_dy} != {expected_offset}"
        );
    }
}

#[test]
fn test_graph_spec_applies_explicit_edge_and_half_edge_ids() {
    #[derive(Serialize)]
    struct HalfIdGraphSpec {
        name: String,
        nodes: Vec<IndexedNodeSpec>,
        edges: Vec<HalfIdEdgeSpec>,
    }

    #[derive(Serialize)]
    struct IndexedNodeSpec {
        name: String,
        index: usize,
        #[serde(default)]
        statements: BTreeMap<String, String>,
    }

    #[derive(Serialize)]
    struct HalfIdEdgeSpec {
        id: usize,
        source: HalfIdEndpointSpec,
        sink: HalfIdEndpointSpec,
    }

    #[derive(Serialize)]
    struct HalfIdEndpointSpec {
        node: usize,
        id: usize,
    }

    let graph = graph_from_spec_bytes(&encode_graph_spec(&HalfIdGraphSpec {
        name: "half-ids".to_string(),
        nodes: vec![
            IndexedNodeSpec {
                name: "a".to_string(),
                index: 1,
                statements: BTreeMap::new(),
            },
            IndexedNodeSpec {
                name: "b".to_string(),
                index: 0,
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![
            HalfIdEdgeSpec {
                id: 1,
                source: HalfIdEndpointSpec { node: 0, id: 2 },
                sink: HalfIdEndpointSpec { node: 1, id: 3 },
            },
            HalfIdEdgeSpec {
                id: 0,
                source: HalfIdEndpointSpec { node: 1, id: 0 },
                sink: HalfIdEndpointSpec { node: 0, id: 1 },
            },
        ],
    }))
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&graph).unwrap());
    assert_eq!(nodes[0].name.as_deref(), Some("b"));
    assert_eq!(nodes[1].name.as_deref(), Some("a"));

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    assert_eq!(edges[0].edge, 0);
    assert_eq!(edges[0].source.as_ref().unwrap().hedge, 0);
    assert_eq!(edges[0].sink.as_ref().unwrap().hedge, 1);
    assert_eq!(edges[0].source.as_ref().unwrap().node, 0);
    assert_eq!(edges[0].sink.as_ref().unwrap().node, 1);
    assert_eq!(edges[1].edge, 1);
    assert_eq!(edges[1].source.as_ref().unwrap().hedge, 2);
    assert_eq!(edges[1].sink.as_ref().unwrap().hedge, 3);
    assert_eq!(edges[1].source.as_ref().unwrap().node, 1);
    assert_eq!(edges[1].sink.as_ref().unwrap().node, 0);
}

#[test]
fn test_graph_spec_uses_first_class_placements() {
    let spec = TestPlacementGraphSpec {
        name: "placed".to_string(),
        nodes: vec![
            TestPlacedNodeSpec {
                name: "a".to_string(),
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Number(1.0)),
                    y: Some(TestPlacementCoord::Number(2.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                statements: one_statement("label", "left"),
            },
            TestPlacedNodeSpec {
                name: "b".to_string(),
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: None,
                    y: None,
                    reference: Some(0),
                    dx: Some(3.0),
                    dy: Some(-1.0),
                }),
                statements: one_statement("label", "right"),
            },
        ],
        edges: vec![TestPlacedEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: None,
            }),
            sink: Some(TestEndpointSpec {
                node: 1,
                compass: None,
                statement: None,
            }),
            pos: Some(TestPlacementSpec {
                mode: Some("pin"),
                x: Some(TestPlacementCoord::Group(TestPlacementGroup {
                    kind: "group",
                    name: "edge-column",
                    side: Some("+"),
                    start: None,
                })),
                y: Some(TestPlacementCoord::Number(0.5)),
                reference: None,
                dx: None,
                dy: None,
            }),
            statements: BTreeMap::new(),
        }],
    };

    let graph = graph_from_spec_bytes(&encode_graph_spec(&spec)).unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&graph).unwrap());
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());

    assert_eq!(nodes[0].pos, Some(crate::TypstPoint { x: 1.0, y: 2.0 }));
    assert_eq!(nodes[1].pos, Some(crate::TypstPoint { x: 4.0, y: 1.0 }));
    assert_eq!((nodes[0].pos_x_set, nodes[0].pos_y_set), (true, true));
    assert_eq!((nodes[1].pos_x_set, nodes[1].pos_y_set), (true, true));
    assert_eq!(
        nodes[0].statements.get("label").map(String::as_str),
        Some("left")
    );
    assert!(!nodes[0].statements.contains_key("pos"));
    assert!(!nodes[0].statements.contains_key("pin"));
    assert_eq!(edges[0].pos, Some(crate::TypstPoint { x: 0.0, y: 0.5 }));
    assert_eq!((edges[0].pos_x_set, edges[0].pos_y_set), (true, true));
    assert!(!edges[0].statements.contains_key("pos"));
    assert!(!edges[0].statements.contains_key("pin"));

    let laid_out = layout_parsed_graph_bytes(&graph, &empty_config_bytes()).unwrap();
    let laid_out_nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    assert_eq!(
        laid_out_nodes[0].pos,
        Some(crate::TypstPoint { x: 1.0, y: 2.0 })
    );
    assert_eq!(
        laid_out_nodes[1].pos,
        Some(crate::TypstPoint { x: 4.0, y: 1.0 })
    );
}

#[test]
fn test_group_start_seeds_first_class_placement() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestPlacementGraphSpec {
        name: "group-start".to_string(),
        nodes: vec![
            TestPlacedNodeSpec {
                name: "a".to_string(),
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Group(TestPlacementGroup {
                        kind: "group",
                        name: "column",
                        side: None,
                        start: Some(2.0),
                    })),
                    y: Some(TestPlacementCoord::Number(0.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                statements: BTreeMap::new(),
            },
            TestPlacedNodeSpec {
                name: "b".to_string(),
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Number(0.0)),
                    y: Some(TestPlacementCoord::Number(2.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![TestPlacedEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: None,
            }),
            sink: Some(TestEndpointSpec {
                node: 1,
                compass: None,
                statement: None,
            }),
            pos: Some(TestPlacementSpec {
                mode: Some("pin"),
                x: Some(TestPlacementCoord::Group(TestPlacementGroup {
                    kind: "group",
                    name: "column",
                    side: None,
                    start: Some(6.0),
                })),
                y: Some(TestPlacementCoord::Number(1.0)),
                reference: None,
                dx: None,
                dy: None,
            }),
            statements: BTreeMap::new(),
        }],
    }))
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&graph).unwrap());
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    assert_eq!(nodes[0].pos, Some(crate::TypstPoint { x: 2.0, y: 0.0 }));
    assert_eq!(edges[0].pos, Some(crate::TypstPoint { x: 6.0, y: 1.0 }));

    let mut graph = crate::graph_api::decode_typst_graph(&graph).unwrap();
    let (node_positions, edge_positions) = graph.new_positions(TreeInitCfg { dx: 1.0, dy: 1.0 });
    assert_eq!(node_positions[NodeIndex(0)].x, 4.0);
    assert_eq!(edge_positions[EdgeIndex(0)].x, 4.0);

    let settings = BTreeMap::from([
        ("layout-algo".to_string(), "force".to_string()),
        ("steps".to_string(), "20".to_string()),
        ("epochs".to_string(), "1".to_string()),
        ("step".to_string(), "0.05".to_string()),
        ("beta".to_string(), "0".to_string()),
        ("gamma-ev".to_string(), "0".to_string()),
        ("k-spring".to_string(), "4".to_string()),
        ("depth-scale".to_string(), "0".to_string()),
    ]);
    graph.layout_config = crate::LayoutConfig::from_figment(&Figment::from(Serialized::from(
        settings,
        Profile::Default,
    )));
    graph.layout();
    assert_eq!(graph[NodeIndex(0)].pos.x, graph[EdgeIndex(0)].pos.x);
    assert!((graph[NodeIndex(0)].pos.x - 4.0).abs() > 1e-3);
}

#[test]
fn test_graph_structural_patch_updates_edge_position() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestPlacementGraphSpec {
        name: "patchable".to_string(),
        nodes: vec![
            TestPlacedNodeSpec {
                name: "a".to_string(),
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Number(0.0)),
                    y: Some(TestPlacementCoord::Number(0.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                statements: BTreeMap::new(),
            },
            TestPlacedNodeSpec {
                name: "b".to_string(),
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Number(1.0)),
                    y: Some(TestPlacementCoord::Number(0.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![TestPlacedEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: None,
            }),
            sink: Some(TestEndpointSpec {
                node: 1,
                compass: None,
                statement: None,
            }),
            pos: None,
            statements: BTreeMap::new(),
        }],
    }))
    .unwrap();

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    assert_eq!(edges[0].pos, Some(crate::TypstPoint { x: 0.5, y: 0.0 }));
    assert_eq!((edges[0].pos_x_set, edges[0].pos_y_set), (false, false));

    let dot: String = decode_cbor(&graph_dot_bytes(&graph).unwrap());
    let reparsed = decode_graphs(&parse_dot_graphs_bytes(dot.as_bytes()).unwrap()).remove(0);
    let reparsed_edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&reparsed).unwrap());
    assert_eq!(
        (reparsed_edges[0].pos_x_set, reparsed_edges[0].pos_y_set),
        (false, false)
    );

    let patched = graph_apply_structural_patches_bytes(
        &graph,
        &encode_cbor(&TestStructuralPatch {
            nodes: Vec::new(),
            edges: vec![TestEdgeStructuralPatch {
                index: 0,
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Group(TestPlacementGroup {
                        kind: "group",
                        name: "right",
                        side: Some("+"),
                        start: None,
                    })),
                    y: Some(TestPlacementCoord::Number(10.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                label_pos: Some((1.5, -0.5)),
                bend: Some(0.75),
                statements: BTreeMap::new(),
            }],
            hedges: Vec::new(),
        }),
    )
    .unwrap();

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&patched).unwrap());
    assert_eq!(edges[0].pos, Some(crate::TypstPoint { x: 0.0, y: 10.0 }));
    assert_eq!((edges[0].pos_x_set, edges[0].pos_y_set), (true, true));
    assert_eq!(
        edges[0].label_pos,
        Some(crate::TypstPoint { x: 1.5, y: -0.5 })
    );
    assert_eq!(edges[0].bend, Some(0.75));

    let dot: String = decode_cbor(&graph_dot_bytes(&patched).unwrap());
    assert!(dot.contains("pin=\"x:@+right,y:10\""), "{dot}");
    assert!(dot.contains("bend=\"0.75rad\""), "{dot}");
    assert!(dot.contains("\"pos-x-set\"=\"true\""), "{dot}");
    assert!(dot.contains("\"pos-y-set\"=\"true\""), "{dot}");
}

#[test]
fn test_edge_structural_patch_preserves_unpatched_layout_positions() {
    let parsed =
        parse_dot_graphs_bytes(br#"digraph { a [pos="-4,2"]; b [pos="4,2"]; a -> b [pos="0,0"] }"#)
            .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "force".to_string()),
            ("label-steps".to_string(), "0".to_string()),
            ("steps".to_string(), "20".to_string()),
            ("epochs".to_string(), "1".to_string()),
            ("step".to_string(), "0.05".to_string()),
            ("beta".to_string(), "0".to_string()),
            ("gamma-ev".to_string(), "0".to_string()),
            ("k-spring".to_string(), "4".to_string()),
            ("depth-scale".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let before: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    assert_ne!(before[0].pos.as_ref().unwrap().x, -4.0);

    let patched = graph_apply_structural_patches_bytes(
        &laid_out,
        &encode_cbor(&TestStructuralPatch {
            nodes: Vec::new(),
            edges: vec![TestEdgeStructuralPatch {
                index: 0,
                pos: Some(TestPlacementSpec {
                    mode: Some("pin"),
                    x: Some(TestPlacementCoord::Number(0.0)),
                    y: Some(TestPlacementCoord::Number(-2.0)),
                    reference: None,
                    dx: None,
                    dy: None,
                }),
                label_pos: None,
                bend: None,
                statements: BTreeMap::new(),
            }],
            hedges: Vec::new(),
        }),
    )
    .unwrap();
    let after: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&patched).unwrap());
    assert_eq!(after, before);
}

#[test]
fn test_graph_structural_axis_merge_preserves_edge_positions_and_constraints() {
    use ciborium::Value;

    let parsed = parse_dot_graphs_bytes(
        br#"digraph {
            a -> b [id=0 pos="x:4!"]
            a -> b [id=1 pos="y:6"]
            a -> b [id=2 pos="x:@+column!,y:2!"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let before = crate::graph_api::decode_typst_graph(&graph).unwrap();
    assert!(matches!(
        before[EdgeIndex(0)].constraints.x,
        Constraint::Fixed
    ));
    assert!(matches!(
        before[EdgeIndex(1)].constraints.y,
        Constraint::Free
    ));
    assert!(matches!(
        before[EdgeIndex(2)].constraints.x,
        Constraint::Grouped(_, ShiftDirection::PositiveOnly)
    ));

    let patches = [
        (0, "y", Value::Integer(7.into()), "start"),
        (
            1,
            "x",
            Value::Map(vec![
                (Value::Text("kind".into()), Value::Text("group".into())),
                (Value::Text("name".into()), Value::Text("left".into())),
                (Value::Text("side".into()), Value::Text("-".into())),
            ]),
            "pin",
        ),
        (2, "y", Value::Integer(9.into()), "pin"),
    ]
    .map(|(index, axis, value, mode)| {
        BTreeMap::from([
            ("index", Value::Integer(index.into())),
            (
                "pos",
                Value::Map(vec![
                    (Value::Text("merge-axes".into()), Value::Bool(true)),
                    (Value::Text("mode".into()), Value::Text(mode.into())),
                    (Value::Text(axis.into()), value),
                ]),
            ),
        ])
    });
    let patched = graph_apply_structural_patches_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([("edges", patches)])),
    )
    .unwrap();
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&patched).unwrap());
    assert!(edges.iter().all(|edge| edge.pos_x_set && edge.pos_y_set));
    let patched = crate::graph_api::decode_typst_graph(&patched).unwrap();
    let pinned = &patched[EdgeIndex(0)];
    assert_eq!((pinned.pos.x, pinned.pos.y), (4.0, 7.0));
    assert!(matches!(pinned.constraints.x, Constraint::Fixed));
    assert!(matches!(pinned.constraints.y, Constraint::Free));
    let started = &patched[EdgeIndex(1)];
    assert_eq!(started.pos.y, 6.0);
    assert!(matches!(started.constraints.y, Constraint::Free));
    assert!(matches!(
        started.constraints.x,
        Constraint::Grouped(_, ShiftDirection::NegativeOnly)
    ));
    let grouped = &patched[EdgeIndex(2)];
    assert_eq!(grouped.pos.y, 9.0);
    assert!(matches!(grouped.constraints.y, Constraint::Fixed));
    assert!(matches!(
        grouped.constraints.x,
        Constraint::Grouped(_, ShiftDirection::PositiveOnly)
    ));
    assert!(grouped.statements["pin"].contains("x:@+column"));
}

#[test]
fn test_graph_structural_axis_merge_updates_same_batch_node_references() {
    use ciborium::Value;

    let parsed = parse_dot_graphs_bytes(br#"digraph { a [pos="4,5!"]; b; a -> b; }"#).unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let patches = [
        vec![(Value::Text("x".into()), Value::Integer(8.into()))],
        vec![
            (Value::Text("ref".into()), Value::Integer(0.into())),
            (Value::Text("dx".into()), Value::Integer(2.into())),
        ],
    ]
    .into_iter()
    .enumerate()
    .map(|(index, mut pos)| {
        pos.push((Value::Text("merge-axes".into()), Value::Bool(true)));
        BTreeMap::from([
            ("index", Value::Integer(index.into())),
            ("pos", Value::Map(pos)),
        ])
    })
    .collect::<Vec<_>>();
    let patched = graph_apply_structural_patches_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([("nodes", patches)])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&patched).unwrap());
    assert_eq!(nodes[0].pos, Some(TypstPoint { x: 8.0, y: 5.0 }));
    assert_eq!(nodes[1].pos, Some(TypstPoint { x: 10.0, y: 5.0 }));
    assert!(nodes.iter().all(|node| node.pos_x_set && node.pos_y_set));
    let patched = crate::graph_api::decode_typst_graph(&patched).unwrap();
    for index in [NodeIndex(0), NodeIndex(1)] {
        assert!(matches!(patched[index].constraints.x, Constraint::Fixed));
        assert!(matches!(patched[index].constraints.y, Constraint::Fixed));
    }
}

#[test]
fn test_graph_structural_statement_patch_does_not_pin_nodes() {
    let parsed = parse_dot_graphs_bytes(br#"digraph { a -> b; b -> c }"#).unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let patched = graph_apply_structural_patches_bytes(
        &graph,
        &encode_cbor(&TestStructuralPatch {
            nodes: vec![TestNodeStructuralPatch {
                index: 0,
                pos: None,
                statements: BTreeMap::from([("layout-width".to_string(), "4".to_string())]),
            }],
            edges: Vec::new(),
            hedges: Vec::new(),
        }),
    )
    .unwrap();

    let laid_out = layout_parsed_graph_bytes(
        &patched,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "tree".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());

    assert!(
        nodes[1].pos.as_ref().unwrap().y < -0.1,
        "statement-only structural patches must not freeze layout positions: {nodes:?}"
    );
}

#[test]
fn test_graph_structural_patch_updates_half_edge_fields() {
    let parsed = parse_dot_graphs_bytes(br#"digraph { a:0 -> b:1 [id=0]; }"#).unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let patched = graph_apply_structural_patches_bytes(
        &graph,
        &encode_cbor(&TestStructuralPatch {
            nodes: Vec::new(),
            edges: Vec::new(),
            hedges: vec![
                TestHedgeStructuralPatch {
                    index: 0,
                    statement: Some("source-statement"),
                    port_label: Some("source-port"),
                    compass: Some("e"),
                },
                TestHedgeStructuralPatch {
                    index: 1,
                    statement: Some("sink-statement"),
                    port_label: Some("sink-port"),
                    compass: Some("w"),
                },
            ],
        }),
    )
    .unwrap();

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&patched).unwrap());
    let edge = &edges[0];
    let source = edge.source.as_ref().unwrap();
    let sink = edge.sink.as_ref().unwrap();
    assert_eq!(source.statement.as_deref(), Some("source-statement"));
    assert_eq!(source.port_label.as_deref(), Some("source-port"));
    assert_eq!(source.compass.as_deref(), Some("e"));
    assert_eq!(sink.statement.as_deref(), Some("sink-statement"));
    assert_eq!(sink.port_label.as_deref(), Some("sink-port"));
    assert_eq!(sink.compass.as_deref(), Some("w"));
}

#[test]
fn test_graph_structural_statement_patch_preserves_grouped_edge_constraints() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph {
            left [style=invis]
            right [style=invis]
            left -> a [id=0 pos="x:@-external!,y:@row!"]
            b -> right [id=1 pos="x:@+external!,y:@row!"]
            a -> b [id=2]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let patched = graph_apply_structural_patches_bytes(
        &graph,
        &encode_cbor(&TestStructuralPatch {
            nodes: Vec::new(),
            edges: vec![TestEdgeStructuralPatch {
                index: 0,
                pos: None,
                label_pos: None,
                bend: None,
                statements: BTreeMap::from([
                    ("label-width".to_string(), "2".to_string()),
                    ("label-height".to_string(), "1".to_string()),
                ]),
            }],
            hedges: Vec::new(),
        }),
    )
    .unwrap();

    let graph = crate::graph_api::decode_typst_graph(&patched).unwrap();
    let mut edges = graph.iter_edges().map(|(_, _, edge)| edge.data);
    let left = edges.next().unwrap();
    let right = edges.next().unwrap();
    assert!(matches!(
        left.constraints.x,
        Constraint::Grouped(_, ShiftDirection::NegativeOnly)
    ));
    assert!(matches!(
        right.constraints.x,
        Constraint::Grouped(_, ShiftDirection::PositiveOnly)
    ));
    let (
        Constraint::Grouped(left_row, ShiftDirection::Any),
        Constraint::Grouped(right_row, ShiftDirection::Any),
    ) = (left.constraints.y, right.constraints.y)
    else {
        panic!("external edges lost their shared row constraint");
    };
    assert_eq!(left_row, right_row);
}

#[test]
fn label_position_patch_preserves_solved_group_positions() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph {
            ext [style=invis]
            ext -> a [id=0 pin="x:@-external"]
            ext -> b [id=1 pin="x:@-external"]
            a -> b [id=2]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "tree".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let before: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
    assert_ne!(before[0].pos.as_ref().unwrap().x, 0.0);

    let patched = graph_apply_structural_patches_bytes(
        &laid_out,
        &encode_cbor(&TestStructuralPatch {
            nodes: Vec::new(),
            edges: vec![TestEdgeStructuralPatch {
                index: 0,
                pos: None,
                label_pos: Some((2.5, -1.0)),
                bend: None,
                statements: BTreeMap::new(),
            }],
            hedges: Vec::new(),
        }),
    )
    .unwrap();
    let after: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&patched).unwrap());

    assert_eq!(
        before
            .iter()
            .map(|edge| edge.pos.clone())
            .collect::<Vec<_>>(),
        after
            .iter()
            .map(|edge| edge.pos.clone())
            .collect::<Vec<_>>()
    );
    assert_eq!(
        after[0].label_pos,
        Some(crate::TypstPoint { x: 2.5, y: -1.0 })
    );
}

#[test]
fn test_graph_spec_axis_modes_pin_axes_independently() {
    #[derive(Serialize)]
    struct AxisModeGraphSpec {
        name: String,
        nodes: Vec<AxisModeNodeSpec>,
        edges: Vec<TestEdgeSpec>,
    }

    #[derive(Serialize)]
    struct AxisModeNodeSpec {
        name: String,
        pos: AxisModePlacementSpec,
    }

    #[derive(Serialize)]
    #[serde(rename_all = "kebab-case")]
    struct AxisModePlacementSpec {
        mode: &'static str,
        x: f64,
        y: f64,
        #[serde(skip_serializing_if = "Option::is_none")]
        x_mode: Option<&'static str>,
        #[serde(skip_serializing_if = "Option::is_none")]
        y_mode: Option<&'static str>,
    }

    let graph = graph_from_spec_bytes(&encode_graph_spec(&AxisModeGraphSpec {
        name: "axis-modes".to_string(),
        nodes: vec![
            AxisModeNodeSpec {
                name: "a".to_string(),
                pos: AxisModePlacementSpec {
                    mode: "pin",
                    x: 1.0,
                    y: 2.0,
                    x_mode: None,
                    y_mode: Some("start"),
                },
            },
            AxisModeNodeSpec {
                name: "b".to_string(),
                pos: AxisModePlacementSpec {
                    mode: "start",
                    x: 3.0,
                    y: 4.0,
                    x_mode: Some("pin"),
                    y_mode: None,
                },
            },
        ],
        edges: Vec::new(),
    }))
    .unwrap();

    let graph = crate::graph_api::decode_typst_graph(&graph).unwrap();
    let mut nodes = BTreeMap::new();
    for (_, _, node) in graph.iter_nodes() {
        nodes.insert(node.name.as_deref().unwrap(), node);
    }

    assert_eq!(nodes["a"].pos.x, 1.0);
    assert_eq!(nodes["a"].pos.y, 2.0);
    assert!(matches!(nodes["a"].constraints.x, Constraint::Fixed));
    assert!(matches!(nodes["a"].constraints.y, Constraint::Free));

    assert_eq!(nodes["b"].pos.x, 3.0);
    assert_eq!(nodes["b"].pos.y, 4.0);
    assert!(matches!(nodes["b"].constraints.x, Constraint::Fixed));
    assert!(matches!(nodes["b"].constraints.y, Constraint::Free));
}

#[test]
fn test_graph_spec_placement_defaults_to_pin() {
    let spec = TestPlacementGraphSpec {
        name: "placed-default".to_string(),
        nodes: vec![TestPlacedNodeSpec {
            name: "a".to_string(),
            pos: Some(TestPlacementSpec {
                mode: None,
                x: Some(TestPlacementCoord::Number(1.0)),
                y: Some(TestPlacementCoord::Number(2.0)),
                reference: None,
                dx: None,
                dy: None,
            }),
            statements: BTreeMap::new(),
        }],
        edges: Vec::new(),
    };

    let graph = graph_from_spec_bytes(&encode_graph_spec(&spec)).unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&graph).unwrap());
    assert_eq!(nodes[0].pos, Some(crate::TypstPoint { x: 1.0, y: 2.0 }));

    let laid_out = layout_parsed_graph_bytes(&graph, &empty_config_bytes()).unwrap();
    let laid_out_nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    assert_eq!(
        laid_out_nodes[0].pos,
        Some(crate::TypstPoint { x: 1.0, y: 2.0 })
    );
}

#[test]
fn test_graph_spec_constructor_preserves_default_statements() {
    let spec = TestTemplatedGraphSpec {
        name: "templated".to_string(),
        statements: BTreeMap::new(),
        default_edge_statements: BTreeMap::from([
            (
                "source-style".to_string(),
                "(stroke: red + 0.5pt)".to_string(),
            ),
            (
                "sink-style".to_string(),
                "(stroke: blue + 0.5pt)".to_string(),
            ),
            (
                "display-label".to_string(),
                "(text(fill: rgb(\"#{color}\"))[{label}])".to_string(),
            ),
        ]),
        default_node_statements: BTreeMap::from([(
            "eval".to_string(),
            "(fill: rgb(\"#{color}\"))".to_string(),
        )]),
        nodes: vec![
            TestNodeSpec {
                name: "a".to_string(),
                statements: one_statement("color", "ff0000"),
            },
            TestNodeSpec {
                name: "b".to_string(),
                statements: one_statement("color", "00aa00"),
            },
        ],
        edges: vec![TestEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: Some("e".to_string()),
                statement: None,
            }),
            sink: Some(TestEndpointSpec {
                node: 1,
                compass: Some("w".to_string()),
                statement: None,
            }),
            statements: BTreeMap::from([
                ("color".to_string(), "0055ff".to_string()),
                ("label".to_string(), "a-c".to_string()),
            ]),
        }],
    };

    let graph = graph_from_spec_bytes(&encode_graph_spec(&spec)).unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&graph).unwrap());
    assert_eq!(
        nodes[0].statements.get("eval").map(String::as_str),
        Some("(fill: rgb(\"#{color}\"))")
    );
    assert_eq!(
        nodes[1].statements.get("eval").map(String::as_str),
        Some("(fill: rgb(\"#{color}\"))")
    );

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    assert_eq!(
        edges[0].statements.get("display-label").map(String::as_str),
        Some("(text(fill: rgb(\"#{color}\"))[{label}])")
    );
    assert_eq!(
        edges[0].statements.get("source-style").map(String::as_str),
        Some("(stroke: red + 0.5pt)")
    );
    assert_eq!(
        edges[0].statements.get("sink-style").map(String::as_str),
        Some("(stroke: blue + 0.5pt)")
    );
}

#[test]
fn test_archived_graph_and_subgraph_api() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestGraphSpec {
        name: "constructed".to_string(),
        statements: BTreeMap::new(),
        nodes: vec![
            TestNodeSpec {
                name: "a".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "b".to_string(),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![TestEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: Some("e".to_string()),
                statement: None,
            }),
            sink: Some(TestEndpointSpec {
                node: 1,
                compass: Some("w".to_string()),
                statement: None,
            }),
            statements: one_statement("join", "ab"),
        }],
    }))
    .unwrap();

    let east = graph_archived_compass_subgraph_bytes(&graph, &encode_cbor(&"e")).unwrap();
    let east_label: String = decode_cbor(&subgraph_label_bytes(&east).unwrap());
    assert!(!east_label.is_empty());
    let east_hedges: Vec<usize> = decode_cbor(&subgraph_hedges_bytes(&east).unwrap());
    assert_eq!(east_hedges, vec![0]);
    let contains: bool =
        decode_cbor(&subgraph_contains_hedge_bytes(&east, &encode_cbor(&0)).unwrap());
    assert!(contains);

    let east_edges: Vec<TypstDotEdge> =
        decode_cbor(&graph_edges_of_archived_subgraph_bytes(&graph, &east).unwrap());
    assert_eq!(east_edges.len(), 1);
    let east_nodes: Vec<TypstDotNode> =
        decode_cbor(&graph_nodes_of_archived_subgraph_bytes(&graph, &east).unwrap());
    assert_eq!(east_nodes.len(), 1);

    let cycles: Vec<Vec<u8>> = decode_cbor(&graph_cycle_basis_bytes(&graph).unwrap());
    assert!(cycles.is_empty());
    let forests: Vec<Vec<u8>> = decode_cbor(&graph_spanning_forests_bytes(&graph).unwrap());
    assert_eq!(forests.len(), 1);
}

#[test]
fn test_graph_spec_preserves_default_statements() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestTemplatedGraphSpec {
        name: "constructed".to_string(),
        statements: BTreeMap::new(),
        default_edge_statements: BTreeMap::from([
            (
                "source-style".to_string(),
                "(stroke: red + 0.5pt)".to_string(),
            ),
            (
                "sink-style".to_string(),
                "(stroke: blue + 0.5pt)".to_string(),
            ),
            (
                "display-label".to_string(),
                "(text(fill: rgb(\"#{color}\"))[{label}])".to_string(),
            ),
        ]),
        default_node_statements: BTreeMap::from([(
            "eval".to_string(),
            "(fill: rgb(\"#{color}\"))".to_string(),
        )]),
        nodes: vec![
            TestNodeSpec {
                name: "a".to_string(),
                statements: one_statement("color", "ff0000"),
            },
            TestNodeSpec {
                name: "b".to_string(),
                statements: one_statement("color", "00aa00"),
            },
        ],
        edges: vec![TestEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: None,
            }),
            sink: Some(TestEndpointSpec {
                node: 1,
                compass: None,
                statement: None,
            }),
            statements: BTreeMap::from([
                ("color".to_string(), "0055ff".to_string()),
                ("label".to_string(), "a-c".to_string()),
            ]),
        }],
    }))
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&graph).unwrap());
    assert_eq!(
        nodes[0].statements.get("eval").map(String::as_str),
        Some("(fill: rgb(\"#{color}\"))")
    );
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    assert_eq!(
        edges[0].statements.get("display-label").map(String::as_str),
        Some("(text(fill: rgb(\"#{color}\"))[{label}])")
    );
    assert_eq!(
        edges[0].statements.get("source-style").map(String::as_str),
        Some("(stroke: red + 0.5pt)")
    );
    assert_eq!(
        edges[0].statements.get("sink-style").map(String::as_str),
        Some("(stroke: blue + 0.5pt)")
    );
}

#[test]
fn test_graph_join_matches_half_edge_statement() {
    let left = graph_from_spec_bytes(&encode_graph_spec(&TestGraphSpec {
        name: "left".to_string(),
        statements: BTreeMap::new(),
        nodes: vec![TestNodeSpec {
            name: "a".to_string(),
            statements: BTreeMap::new(),
        }],
        edges: vec![TestEdgeSpec {
            source: None,
            sink: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: Some("join".to_string()),
            }),
            statements: BTreeMap::new(),
        }],
    }))
    .unwrap();
    let right = graph_from_spec_bytes(&encode_graph_spec(&TestGraphSpec {
        name: "right".to_string(),
        statements: BTreeMap::new(),
        nodes: vec![TestNodeSpec {
            name: "b".to_string(),
            statements: BTreeMap::new(),
        }],
        edges: vec![TestEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: Some("join".to_string()),
            }),
            sink: None,
            statements: BTreeMap::new(),
        }],
    }))
    .unwrap();

    let joined = crate::graph_join_by_hedge_key_bytes(
        &left,
        &right,
        &encode_cbor(&one_statement("key", "statement")),
    )
    .unwrap();
    let joined: TypstJoinResult = decode_cbor::<TypstJoinResult>(&joined);
    assert_eq!(joined.nodes.len(), 2);
    assert_eq!(joined.edges.len(), 1);
    assert_eq!(joined.hedges.len(), 2);
    assert_eq!(joined.edges[0].left, Some(0));
    assert_eq!(joined.edges[0].right, Some(0));
    assert_eq!(joined.nodes[0].left, Some(0));
    assert_eq!(joined.nodes[1].right, Some(0));
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&joined.graph).unwrap());
    assert_eq!(edges.len(), 1);
    assert!(edges[0].source.is_some());
    assert!(edges[0].sink.is_some());
}

#[test]
fn test_graph_join_rejects_unknown_key() {
    let spec = TestGraphSpec {
        name: "g".into(),
        statements: BTreeMap::new(),
        nodes: vec![TestNodeSpec {
            name: "a".into(),
            statements: BTreeMap::new(),
        }],
        edges: vec![TestEdgeSpec {
            source: None,
            sink: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: Some("x".into()),
            }),
            statements: BTreeMap::new(),
        }],
    };
    let bytes = graph_from_spec_bytes(&encode_graph_spec(&spec)).unwrap();
    let err = crate::graph_join_by_hedge_key_bytes(
        &bytes,
        &bytes,
        &encode_cbor(&one_statement("key", "unknown")),
    )
    .unwrap_err();
    assert!(err.contains("unsupported hedge key"));
}

#[test]
fn test_graph_join_rejects_duplicate_matching_identity() {
    let spec = TestGraphSpec {
        name: "g".into(),
        statements: BTreeMap::new(),
        nodes: vec![TestNodeSpec {
            name: "a".into(),
            statements: BTreeMap::new(),
        }],
        edges: vec![
            TestEdgeSpec {
                source: None,
                sink: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: Some("x".into()),
                }),
                statements: BTreeMap::new(),
            },
            TestEdgeSpec {
                source: None,
                sink: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: Some("x".into()),
                }),
                statements: BTreeMap::new(),
            },
        ],
    };
    let bytes = graph_from_spec_bytes(&encode_graph_spec(&spec)).unwrap();
    let err = crate::graph_join_by_hedge_key_bytes(
        &bytes,
        &bytes,
        &encode_cbor(&one_statement("key", "statement")),
    )
    .unwrap_err();
    assert!(err.contains("duplicate dangling identity"));
}

#[test]
fn test_graph_join_edges_rejects_duplicate_matching_identity() {
    let spec = TestGraphSpec {
        name: "g".into(),
        statements: BTreeMap::new(),
        nodes: vec![TestNodeSpec {
            name: "a".into(),
            statements: BTreeMap::new(),
        }],
        edges: vec![
            TestEdgeSpec {
                source: None,
                sink: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: None,
                }),
                statements: one_statement("edge-key", "x"),
            },
            TestEdgeSpec {
                source: None,
                sink: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: None,
                }),
                statements: one_statement("edge-key", "x"),
            },
        ],
    };
    let bytes = graph_from_spec_bytes(&encode_graph_spec(&spec)).unwrap();
    let err = crate::graph_join_by_edge_key_bytes(
        &bytes,
        &bytes,
        &encode_cbor(&one_statement("key", "edge-key")),
    )
    .unwrap_err();
    assert!(err.contains("duplicate dangling identity"));
}

#[test]
fn test_graph_join_rejects_cross_input_node_label_collision() {
    let spec = TestGraphSpec {
        name: "g".into(),
        statements: BTreeMap::new(),
        nodes: vec![TestNodeSpec {
            name: "same".into(),
            statements: BTreeMap::new(),
        }],
        edges: Vec::new(),
    };
    let bytes = graph_from_spec_bytes(&encode_graph_spec(&spec)).unwrap();
    let err = crate::graph_join_by_hedge_key_bytes(
        &bytes,
        &bytes,
        &encode_cbor(&one_statement("key", "statement")),
    )
    .unwrap_err();
    assert!(err.contains("duplicate node label"));
}

#[test]
fn test_graph_join_rejects_cross_input_edge_label_collision() {
    let make = |name: &str| TestGraphSpec {
        name: name.into(),
        statements: BTreeMap::new(),
        nodes: vec![TestNodeSpec {
            name: name.into(),
            statements: BTreeMap::new(),
        }],
        edges: vec![TestEdgeSpec {
            source: None,
            sink: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: None,
            }),
            statements: BTreeMap::from([("__linnest-edge-name".into(), "same".into())]),
        }],
    };
    let left = graph_from_spec_bytes(&encode_graph_spec(&make("left"))).unwrap();
    let right = graph_from_spec_bytes(&encode_graph_spec(&make("right"))).unwrap();
    let err = crate::graph_join_by_hedge_key_bytes(
        &left,
        &right,
        &encode_cbor(&one_statement("key", "statement")),
    )
    .unwrap_err();
    assert!(err.contains("duplicate edge label"));
}

#[test]
fn test_graph_join_keeps_zero_match_partial_edges() {
    let left = TestGraphSpec {
        name: "left".into(),
        statements: BTreeMap::new(),
        nodes: vec![TestNodeSpec {
            name: "a".into(),
            statements: BTreeMap::new(),
        }],
        edges: vec![TestEdgeSpec {
            source: None,
            sink: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: Some("left".into()),
            }),
            statements: BTreeMap::new(),
        }],
    };
    let right = TestGraphSpec {
        name: "right".into(),
        statements: BTreeMap::new(),
        nodes: vec![TestNodeSpec {
            name: "b".into(),
            statements: BTreeMap::new(),
        }],
        edges: vec![TestEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: Some("right".into()),
            }),
            sink: None,
            statements: BTreeMap::new(),
        }],
    };
    let left = graph_from_spec_bytes(&encode_graph_spec(&left)).unwrap();
    let right = graph_from_spec_bytes(&encode_graph_spec(&right)).unwrap();
    let joined = crate::graph_join_by_hedge_key_bytes(
        &left,
        &right,
        &encode_cbor(&one_statement("key", "statement")),
    )
    .unwrap();
    let joined: TypstJoinResult = decode_cbor(&joined);
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&joined.graph).unwrap());
    assert_eq!(edges.len(), 2);
    assert!(edges
        .iter()
        .all(|edge| edge.source.is_none() || edge.sink.is_none()));
}

#[test]
fn test_split_parse_layout_matches_wrapper() {
    let input = br#"digraph archived { a [pin="x:1.0"]; a -> b }"#;
    let config = empty_config_bytes();

    let parsed = parse_dot_graphs_bytes(input).unwrap();
    let split = layout_parsed_graphs_bytes(&parsed, &config).unwrap();
    let wrapped = layout_graph_bytes(input, &config).unwrap();

    assert_eq!(split, wrapped);

    let output = decode_graphs(&split);
    assert_eq!(output.len(), 1);
}

#[test]
fn test_single_graph_layout_mutates_graph_bytes() {
    let parsed =
        parse_dot_graphs_bytes(br#"digraph archived { a [pin="x:1.0"]; a -> b }"#).unwrap();
    let graphs = decode_graphs(&parsed);
    let laid_out = layout_parsed_graph_bytes(&graphs[0], &empty_config_bytes()).unwrap();

    let nodes: Vec<TypstDotNode> =
        ciborium::de::from_reader(graph_nodes_bytes(&laid_out).unwrap().as_slice()).unwrap();
    assert_eq!(nodes.len(), 2);
    assert!(nodes.iter().all(|node| node.pos.is_some()));
}

#[test]
fn test_dot_layout_layers_directed_graph() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestGraphSpec {
        name: "dot".to_string(),
        statements: BTreeMap::new(),
        nodes: vec![
            TestNodeSpec {
                name: "a".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "b".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "c".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "d".to_string(),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![
            TestEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: None,
                }),
                sink: Some(TestEndpointSpec {
                    node: 1,
                    compass: None,
                    statement: None,
                }),
                statements: BTreeMap::new(),
            },
            TestEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: None,
                }),
                sink: Some(TestEndpointSpec {
                    node: 2,
                    compass: None,
                    statement: None,
                }),
                statements: BTreeMap::new(),
            },
            TestEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 1,
                    compass: None,
                    statement: None,
                }),
                sink: Some(TestEndpointSpec {
                    node: 3,
                    compass: None,
                    statement: None,
                }),
                statements: BTreeMap::new(),
            },
            TestEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 2,
                    compass: None,
                    statement: None,
                }),
                sink: Some(TestEndpointSpec {
                    node: 3,
                    compass: None,
                    statement: None,
                }),
                statements: BTreeMap::new(),
            },
        ],
    }))
    .unwrap();

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert!(by_name["a"].y > by_name["b"].y);
    assert_eq!(by_name["b"].y, by_name["c"].y);
    assert!(by_name["b"].y > by_name["d"].y);
}

#[test]
fn test_tree_layout_centers_parents_over_child_subtrees() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph tidy {
            r
            a
            b
            c
            d
            e
            r -> a
            r -> b
            a -> c
            a -> d
            d -> e
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let initial_nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&graph).unwrap());
    let root_index = initial_nodes
        .iter()
        .position(|node| node.name.as_deref() == Some("r"))
        .unwrap();

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "tree".to_string()),
            ("layout-roots".to_string(), root_index.to_string()),
            ("tree-dx".to_string(), "1.0".to_string()),
            ("tree-dy".to_string(), "1.0".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert!((by_name["a"].x - 0.5 * (by_name["c"].x + by_name["d"].x)).abs() < 1e-9);
    assert!((by_name["d"].x - by_name["e"].x).abs() < 1e-9);
    assert!((by_name["r"].x - 0.5 * (by_name["c"].x + by_name["b"].x)).abs() < 1e-9);
    assert_eq!(by_name["r"].y, 0.0);
    assert!(by_name["r"].y > by_name["a"].y);
    assert!(by_name["a"].y > by_name["e"].y);
}

#[test]
fn test_tree_layout_uses_node_size_hints() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph sizes {
            r ["layout-height"=2]
            a ["layout-width"=6, "layout-height"=4]
            b ["layout-width"=2]
            r -> a
            r -> b
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let initial_nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&graph).unwrap());
    let root_index = initial_nodes
        .iter()
        .position(|node| node.name.as_deref() == Some("r"))
        .unwrap();

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "tree".to_string()),
            ("layout-roots".to_string(), root_index.to_string()),
            ("tree-dx".to_string(), "0.0".to_string()),
            ("tree-dy".to_string(), "0.0".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert!((by_name["b"].x - by_name["a"].x - 4.0).abs() < 1e-9);
    assert!((by_name["r"].y - by_name["a"].y - 3.0).abs() < 1e-9);
    assert_eq!(by_name["a"].y, by_name["b"].y);
}

#[test]
fn test_dot_layout_reorders_rank_to_reduce_crossing() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph crossing {
            a
            b
            c
            d
            a -> d
            b -> c
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert!(by_name["a"].x < by_name["b"].x);
    assert!(by_name["d"].x < by_name["c"].x);
    assert_eq!(by_name["a"].y, by_name["b"].y);
    assert_eq!(by_name["c"].y, by_name["d"].y);
}

#[test]
fn test_dot_layout_reduces_crossings_for_nearly_tree_graph() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph near_tree {
            r
            a
            b
            c
            d
            r -> a
            r -> b
            a -> d
            b -> c
            a -> c
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert!(by_name["a"].x < by_name["b"].x);
    assert!(by_name["d"].x < by_name["c"].x);
    assert_eq!(by_name["a"].y, by_name["b"].y);
    assert_eq!(by_name["c"].y, by_name["d"].y);
}

#[test]
fn test_dot_layout_uses_node_size_hints() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph sizes {
            a ["layout-width"=6, "layout-height"=2]
            b ["layout-width"=2]
            c ["layout-height"=4]
            a -> c
            b -> c
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("tree-dx".to_string(), "0.0".to_string()),
            ("tree-dy".to_string(), "0.0".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert!((by_name["b"].x - by_name["a"].x - 4.0).abs() < 1e-9);
    assert!((by_name["a"].y - by_name["c"].y - 3.0).abs() < 1e-9);
    assert_eq!(by_name["a"].y, by_name["b"].y);
}

#[test]
fn test_stable_layered_preserves_input_rank_order() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph stable {
            a
            b
            c
            d
            a -> d
            b -> c
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "stable-layered".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert!(by_name["a"].x < by_name["b"].x);
    assert!(by_name["c"].x < by_name["d"].x);
    assert_eq!(by_name["a"].y, by_name["b"].y);
    assert_eq!(by_name["c"].y, by_name["d"].y);
}

#[test]
fn test_dot_layout_accepts_typst_rank_same_subgraph() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph same_rank {
            a -> b
            b -> c
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let full_label: String = decode_cbor(
        &graph_subgraph_bytes(&graph, &encode_cbor(&vec![true, true, true, true])).unwrap(),
    );

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("rank-same".to_string(), full_label),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert_eq!(by_name["a"].y, by_name["b"].y);
    assert_eq!(by_name["b"].y, by_name["c"].y);
}

#[test]
fn test_layered_layout_merges_overlapping_same_rank_groups() {
    use ciborium::value::Value;

    let parsed =
        parse_dot_graphs_bytes(br#"digraph { a:0 -> b:1 [id=0]; b:2 -> c:3 [id=1]; }"#).unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let mut groups: Vec<Value> = [vec![true, true, true, false], vec![false, true, true, true]]
        .iter()
        .map(|bits| {
            let label: String =
                decode_cbor(&graph_subgraph_bytes(&graph, &encode_cbor(bits)).unwrap());
            Value::Text(label)
        })
        .collect();
    for algorithm in ["dot", "stable-layered"] {
        for _ in 0..2 {
            let options = BTreeMap::from([
                ("layout-algo", Value::Text(algorithm.into())),
                ("rank-same", Value::Array(groups.clone())),
                ("label-steps", Value::Text("0".into())),
            ]);
            let laid_out = layout_parsed_graph_bytes(&graph, &encode_cbor(&options)).unwrap();
            let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
            assert!(nodes
                .iter()
                .all(|node| node.pos.as_ref().unwrap().y == nodes[0].pos.as_ref().unwrap().y));
            groups.reverse();
        }
    }
}

#[test]
fn test_dot_layout_accepts_explicit_node_layout_rank() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph explicit_rank {
            a ["layout-rank"=2]
            b ["layout-rank"=0]
            c ["layout-rank"=2]
            a -> b
            b -> c
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert_eq!(by_name["a"].y, by_name["c"].y);
    assert!(
        by_name["b"].y > by_name["a"].y,
        "rank 0 should be above rank 2: {by_name:?}"
    );
}

#[test]
fn test_dot_layout_handles_cycles_deterministically() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph cycle {
            a -> b
            b -> c
            c -> a
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let first = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let second = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let first_nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&first).unwrap());
    let second_nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&second).unwrap());

    for (left, right) in first_nodes.iter().zip(second_nodes.iter()) {
        let left = left.pos.as_ref().unwrap();
        let right = right.pos.as_ref().unwrap();
        assert!(left.x.is_finite() && left.y.is_finite());
        assert_point_close(left, right);
    }
}

#[test]
fn test_tree_layout_uses_explicit_root_order() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph roots {
            a -> b
            b -> c
            d -> e
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&ciborium::Value::Map(vec![
            (
                ciborium::Value::Text("layout-algo".to_string()),
                ciborium::Value::Text("tree".to_string()),
            ),
            (
                ciborium::Value::Text("layout-roots".to_string()),
                ciborium::Value::Array(vec![
                    ciborium::Value::Integer(3.into()),
                    ciborium::Value::Integer(0.into()),
                ]),
            ),
            (
                ciborium::Value::Text("label-steps".to_string()),
                ciborium::Value::Text("0".to_string()),
            ),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert!(by_name["d"].x < by_name["a"].x);
    assert_eq!(by_name["d"].y, by_name["a"].y);
}

#[test]
fn test_dot_layout_uses_explicit_roots_as_first_rank() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph roots {
            a -> b
            c -> d
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&ciborium::Value::Map(vec![
            (
                ciborium::Value::Text("layout-algo".to_string()),
                ciborium::Value::Text("dot".to_string()),
            ),
            (
                ciborium::Value::Text("layout-roots".to_string()),
                ciborium::Value::Integer(2.into()),
            ),
            (
                ciborium::Value::Text("label-steps".to_string()),
                ciborium::Value::Text("0".to_string()),
            ),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert!(by_name["c"].x < by_name["a"].x);
    assert_eq!(by_name["c"].y, by_name["a"].y);
    assert!(by_name["c"].y > by_name["d"].y);
}

#[test]
fn test_dot_layout_exports_long_edge_route_points_on_half_edges() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph long_edge {
            a -> b [minlen=4]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
    assert_eq!(edges.len(), 1);
    let edge = &edges[0];
    let source_route = &edge.source.as_ref().unwrap().route_points;
    let sink_route = &edge.sink.as_ref().unwrap().route_points;
    assert!(!source_route.is_empty());
    assert!(!sink_route.is_empty());

    let edge_pos = edge.pos.as_ref().unwrap();
    assert!(source_route.iter().all(|point| point.y > edge_pos.y));
    assert!(sink_route.iter().all(|point| point.y < edge_pos.y));
}

#[test]
fn test_dot_layout_route_exit_statements_export_endpoint_guides() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph route_exits {
            a -> b ["source-route-exit"=south, "sink-route-exit"=north]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let node_positions = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
    let edge = &edges[0];
    let source_route = &edge.source.as_ref().unwrap().route_points;
    let sink_route = &edge.sink.as_ref().unwrap().route_points;

    assert_eq!(source_route.len(), 1);
    assert_eq!(sink_route.len(), 1);
    assert!(source_route[0].y < node_positions["a"].y);
    assert!(sink_route[0].y > node_positions["b"].y);
}

#[test]
fn test_dot_layout_direction_right_rotates_ranks_and_node_extents() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph rightward {
            a ["layout-rank"=0, "layout-width"=100, "layout-height"=1]
            b ["layout-rank"=0, "layout-width"=100, "layout-height"=1]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("layout-direction".to_string(), "right".to_string()),
            ("tree-dy".to_string(), "0.5".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    assert!((by_name["a"].x - by_name["b"].x).abs() < 1e-9);
    assert!(
        (by_name["a"].y - by_name["b"].y).abs() < 10.0,
        "left-to-right same-rank spacing should use node height, not node width"
    );
}

#[test]
fn test_dot_layout_direction_right_route_exits_use_east_west() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph route_exits {
            a -> b ["source-route-exit"=east, "sink-route-exit"=west]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("layout-direction".to_string(), "right".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let node_positions = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
    let edge = &edges[0];
    let source_route = &edge.source.as_ref().unwrap().route_points;
    let sink_route = &edge.sink.as_ref().unwrap().route_points;

    assert_eq!(source_route.len(), 1);
    assert_eq!(sink_route.len(), 1);
    assert!(node_positions["a"].x < node_positions["b"].x);
    assert!(source_route[0].x > node_positions["a"].x);
    assert!(sink_route[0].x < node_positions["b"].x);
}

#[test]
fn test_dot_layout_direction_right_can_left_align_rank_nodes() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph rightward_align {
            a ["layout-rank"=0, "layout-width"=8, "layout-height"=1]
            b ["layout-rank"=0, "layout-width"=2, "layout-height"=1]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("layout-direction".to_string(), "right".to_string()),
            ("rank-align".to_string(), "left".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let by_name = nodes
        .iter()
        .map(|node| (node.name.as_deref().unwrap(), node.pos.as_ref().unwrap()))
        .collect::<BTreeMap<_, _>>();

    let a_left = by_name["a"].x - 4.0;
    let b_left = by_name["b"].x - 1.0;
    assert!((a_left - b_left).abs() < 1e-9);
    assert!(by_name["a"].x > by_name["b"].x);
}

#[test]
fn test_partial_tree_layout_keeps_non_tree_edges_straight() {
    let parsed =
        parse_dot_graphs_bytes(br#"digraph partial { a -> b; b -> c; c -> d; d -> a; a -> c }"#)
            .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let forests: Vec<Vec<u8>> = decode_cbor(&graph_spanning_forests_bytes(&graph).unwrap());
    let forest_label: String = decode_cbor(&subgraph_label_bytes(&forests[0]).unwrap());
    let forest_hedges: Vec<usize> = decode_cbor(&subgraph_hedges_bytes(&forests[0]).unwrap());

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "tree".to_string()),
            ("subgraph".to_string(), forest_label),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
    let non_tree_edge = edges
        .iter()
        .find(|edge| {
            let source = edge.source.as_ref().unwrap().hedge;
            let sink = edge.sink.as_ref().unwrap().hedge;
            !(forest_hedges.contains(&source) && forest_hedges.contains(&sink))
        })
        .unwrap();
    let source = nodes[non_tree_edge.source.as_ref().unwrap().node]
        .pos
        .as_ref()
        .unwrap();
    let sink = nodes[non_tree_edge.sink.as_ref().unwrap().node]
        .pos
        .as_ref()
        .unwrap();
    let expected_midpoint = TypstPoint {
        x: 0.5 * (source.x + sink.x),
        y: 0.5 * (source.y + sink.y),
    };

    assert_point_close(non_tree_edge.pos.as_ref().unwrap(), &expected_midpoint);
}

#[test]
fn test_fixed_node_subgraph_tree_layout_moves_only_selected_edges() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph fixed_edges {
            a [pos="0,0"]
            b [pos="4,0"]
            c [pos="8,0"]
            a -> b
            b -> c [pos="88,88"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let selected_label: String = decode_cbor(
        &graph_subgraph_bytes(&graph, &encode_cbor(&vec![true, true, false, false])).unwrap(),
    );

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "tree".to_string()),
            ("layout-nodes".to_string(), "fixed".to_string()),
            ("subgraph".to_string(), selected_label),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());

    assert_point_close(
        nodes[0].pos.as_ref().unwrap(),
        &TypstPoint { x: 0.0, y: 0.0 },
    );
    assert_point_close(
        nodes[1].pos.as_ref().unwrap(),
        &TypstPoint { x: 4.0, y: 0.0 },
    );
    assert_point_close(
        nodes[2].pos.as_ref().unwrap(),
        &TypstPoint { x: 8.0, y: 0.0 },
    );
    assert_point_close(
        edges[0].pos.as_ref().unwrap(),
        &TypstPoint { x: 2.0, y: 0.0 },
    );
    assert_point_close(
        edges[1].pos.as_ref().unwrap(),
        &TypstPoint { x: 88.0, y: 88.0 },
    );
}

#[test]
fn test_partial_iterative_layout_preserves_complement_positions() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph partial {
            a [pos="0,0"]
            b [pos="1,0"]
            c [pos="4,4"]
            a -> b [pos="0.5,0"]
            b -> c [pos="4,5"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let selected_label: String = decode_cbor(
        &graph_subgraph_bytes(&graph, &encode_cbor(&vec![true, true, false, false])).unwrap(),
    );

    for algo in ["force", "anneal"] {
        let laid_out = layout_parsed_graph_bytes(
            &graph,
            &encode_cbor(&BTreeMap::from([
                ("layout-algo".to_string(), algo.to_string()),
                ("subgraph".to_string(), selected_label.clone()),
                ("label-steps".to_string(), "0".to_string()),
                ("steps".to_string(), "4".to_string()),
                ("epochs".to_string(), "2".to_string()),
            ])),
        )
        .unwrap();

        let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
        let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());

        assert_point_close(
            nodes[2].pos.as_ref().unwrap(),
            &TypstPoint { x: 4.0, y: 4.0 },
        );
        assert_point_close(
            edges[1].pos.as_ref().unwrap(),
            &TypstPoint { x: 4.0, y: 5.0 },
        );
    }
}

#[test]
fn isolated_partial_iterative_layout_ignores_complement() {
    for algo in ["force", "anneal"] {
        let mut outputs = Vec::new();
        for (node_pos, edge_pos, extra) in [
            ("4,4", "4,5", ""),
            ("400,-300", "-250,500", ""),
            ("4,4", "4,5", "d [pos=\"900,-800\"]"),
        ] {
            let source = format!(
                r#"digraph partial {{
                    a [pos="0,0"]
                    b [pos="1,0"]
                    c [pos="{node_pos}"]
                    {extra}
                    a -> b [pos="0.5,0"]
                    b -> c [pos="{edge_pos}"]
                }}"#
            );
            let parsed = parse_dot_graphs_bytes(source.as_bytes()).unwrap();
            let graph = decode_graphs(&parsed).remove(0);
            let selected_label: String = decode_cbor(
                &graph_subgraph_bytes(&graph, &encode_cbor(&vec![true, true, false, false]))
                    .unwrap(),
            );
            let laid_out = layout_parsed_graph_bytes(
                &graph,
                &encode_cbor(&BTreeMap::from([
                    ("layout-algo".to_string(), algo.to_string()),
                    ("subgraph-mode".to_string(), "isolated".to_string()),
                    ("subgraph".to_string(), selected_label),
                    ("label-steps".to_string(), "0".to_string()),
                    ("depth-scale".to_string(), "0".to_string()),
                    ("steps".to_string(), "8".to_string()),
                    ("epochs".to_string(), "2".to_string()),
                    ("seed".to_string(), "17".to_string()),
                ])),
            )
            .unwrap();
            outputs.push((
                decode_cbor::<Vec<TypstDotNode>>(&graph_nodes_bytes(&laid_out).unwrap()),
                decode_cbor::<Vec<TypstDotEdge>>(&graph_edges_bytes(&laid_out).unwrap()),
            ));
        }

        for output in &outputs[1..] {
            for node in 0..2 {
                assert_point_close(
                    outputs[0].0[node].pos.as_ref().unwrap(),
                    output.0[node].pos.as_ref().unwrap(),
                );
            }
            assert_point_close(
                outputs[0].1[0].pos.as_ref().unwrap(),
                output.1[0].pos.as_ref().unwrap(),
            );
        }
        assert_point_close(
            outputs[0].0[2].pos.as_ref().unwrap(),
            &TypstPoint { x: 4.0, y: 4.0 },
        );
        assert_point_close(
            outputs[1].0[2].pos.as_ref().unwrap(),
            &TypstPoint {
                x: 400.0,
                y: -300.0,
            },
        );
        assert_point_close(
            outputs[0].1[1].pos.as_ref().unwrap(),
            &TypstPoint { x: 4.0, y: 5.0 },
        );
        assert_point_close(
            outputs[1].1[1].pos.as_ref().unwrap(),
            &TypstPoint {
                x: -250.0,
                y: 500.0,
            },
        );
    }
}

#[test]
fn isolated_layout_preserves_complement_fixed_gap_labels() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph {
            a [id=0 pos="0,0!"]
            b [id=1 pos="2,0!"]
            c [id=2 pos="4,0!"]
            a -> b [id=0 pos="1,1" "label-width"="0.4" "label-height"="0.2"]
            b -> c [id=1 pos="3,1" "label-width"="0.4" "label-height"="0.2"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let graph = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo", "tree"),
            ("layout-nodes", "fixed"),
            ("label-layout", "fixed-gap"),
            ("label-steps", "30"),
        ])),
    )
    .unwrap();
    let expected: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());
    assert!(expected[1].statements.contains_key("layout-label-gap"));
    let selected_label: String = decode_cbor(
        &graph_subgraph_bytes(&graph, &encode_cbor(&vec![true, true, false, false])).unwrap(),
    );
    for algo in ["force", "anneal"] {
        for label_steps in ["0", "30"] {
            let output = layout_parsed_graph_bytes(
                &graph,
                &encode_cbor(&BTreeMap::from([
                    ("layout-algo", algo),
                    ("subgraph-mode", "isolated"),
                    ("subgraph", selected_label.as_str()),
                    ("label-layout", "normal"),
                    ("label-steps", label_steps),
                    ("steps", "4"),
                    ("epochs", "1"),
                    ("depth-scale", "0"),
                ])),
            )
            .unwrap();
            let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&output).unwrap());
            assert_eq!(
                edges[1], expected[1],
                "algo={algo}, label_steps={label_steps}"
            );
            assert!(!edges[0].statements.contains_key("layout-label-gap"));
        }
    }
}

#[test]
fn empty_partial_iterative_layout_is_a_no_op() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph empty_partial {
            a [pos="0,0"]
            b [pos="2,3"]
            a -> b [pos="5,7"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let selected_label: String =
        decode_cbor(&graph_subgraph_bytes(&graph, &encode_cbor(&vec![false, false])).unwrap());
    let expected_nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&graph).unwrap());
    let expected_edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&graph).unwrap());

    for algo in ["force", "anneal"] {
        let laid_out = layout_parsed_graph_bytes(
            &graph,
            &encode_cbor(&BTreeMap::from([
                ("layout-algo".to_string(), algo.to_string()),
                ("subgraph-mode".to_string(), "isolated".to_string()),
                ("subgraph".to_string(), selected_label.clone()),
            ])),
        )
        .unwrap();
        let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
        let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
        for (actual, expected) in nodes.iter().zip(&expected_nodes) {
            assert_point_close(actual.pos.as_ref().unwrap(), expected.pos.as_ref().unwrap());
        }
        for (actual, expected) in edges.iter().zip(&expected_edges) {
            assert_point_close(actual.pos.as_ref().unwrap(), expected.pos.as_ref().unwrap());
        }
    }
}

#[test]
fn isolated_partial_layout_rejects_cross_boundary_groups() {
    let figment = Figment::from(Serialized::from(
        BTreeMap::from([
            ("layout-algo".to_string(), "force".to_string()),
            ("subgraph-mode".to_string(), "isolated".to_string()),
        ]),
        Profile::Default,
    ));
    let mut graph = TypstGraph::from_dot(
        dot!(digraph {
            helper [id=0 pin="y:@row"]
            a [id=1 pin="y:@row"]
            b [id=2]
            a -> b [id=0]
        })
        .unwrap(),
        &figment,
    );
    let mut selected = graph.empty_subgraph::<SuBitGraph>();
    selected.add(graph.iter_edges().next().unwrap().0);

    assert_eq!(
        graph.layout_with_subgraph(Some(&selected)).unwrap_err(),
        "isolated subgraph layout cannot cross a grouped coordinate boundary"
    );
}

#[test]
fn test_fixed_node_iterative_layout_keeps_nodes_and_complement_fixed() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph fixed_force {
            a [pos="0,0"]
            b [pos="4,0"]
            c [pos="8,0"]
            a -> b [pos="2,3"]
            b -> c [pos="88,88"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let selected_label: String = decode_cbor(
        &graph_subgraph_bytes(&graph, &encode_cbor(&vec![true, true, false, false])).unwrap(),
    );

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "force".to_string()),
            ("layout-nodes".to_string(), "fixed".to_string()),
            ("subgraph".to_string(), selected_label),
            ("label-steps".to_string(), "0".to_string()),
            ("steps".to_string(), "4".to_string()),
            ("epochs".to_string(), "2".to_string()),
        ])),
    )
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());

    assert_point_close(
        nodes[0].pos.as_ref().unwrap(),
        &TypstPoint { x: 0.0, y: 0.0 },
    );
    assert_point_close(
        nodes[1].pos.as_ref().unwrap(),
        &TypstPoint { x: 4.0, y: 0.0 },
    );
    assert_point_close(
        nodes[2].pos.as_ref().unwrap(),
        &TypstPoint { x: 8.0, y: 0.0 },
    );
    assert_point_close(
        edges[1].pos.as_ref().unwrap(),
        &TypstPoint { x: 88.0, y: 88.0 },
    );
    let selected_edge = edges[0].pos.as_ref().unwrap();
    assert!(
        (selected_edge.x - 2.0).abs() > 1e-6 || (selected_edge.y - 3.0).abs() > 1e-6,
        "selected edge control point should remain free when layout-nodes is fixed"
    );
}

#[test]
fn fixed_grouped_nodes_anchor_edges_without_being_rewritten() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph fixed_group {
            helper [id=0 pos="-5,2" pin="x:+@column"]
            a [id=1 pos="0,0!"]
            b [id=2 pos="4,0!"]
            a -> b [id=0 pin="x:+@column,y:1"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    for algorithm in ["tree", "force"] {
        let laid_out = layout_parsed_graph_bytes(
            &graph,
            &encode_cbor(&BTreeMap::from([
                ("layout-algo".to_string(), algorithm.to_string()),
                ("layout-nodes".to_string(), "fixed".to_string()),
                ("label-steps".to_string(), "0".to_string()),
                ("steps".to_string(), "4".to_string()),
                ("epochs".to_string(), "2".to_string()),
            ])),
        )
        .unwrap();
        let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
        let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());

        assert_point_close(
            nodes[0].pos.as_ref().unwrap(),
            &TypstPoint { x: -5.0, y: 2.0 },
        );
        assert_eq!(edges[0].pos.as_ref().unwrap().x, -5.0);
    }
}

#[test]
fn test_fixed_node_dot_layout_routes_only_selected_edges() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph fixed_dot {
            a [pos="0,0"]
            b [pos="4,0"]
            c [pos="8,0"]
            a -> b [pos="2,3"]
            b -> c [pos="88,88"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);
    let selected_label: String = decode_cbor(
        &graph_subgraph_bytes(&graph, &encode_cbor(&vec![true, true, false, false])).unwrap(),
    );

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("layout-nodes".to_string(), "fixed".to_string()),
            ("subgraph".to_string(), selected_label),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();

    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());

    assert_point_close(
        nodes[0].pos.as_ref().unwrap(),
        &TypstPoint { x: 0.0, y: 0.0 },
    );
    assert_point_close(
        nodes[1].pos.as_ref().unwrap(),
        &TypstPoint { x: 4.0, y: 0.0 },
    );
    assert_point_close(
        nodes[2].pos.as_ref().unwrap(),
        &TypstPoint { x: 8.0, y: 0.0 },
    );
    let selected_edge = edges[0].pos.as_ref().unwrap();
    assert!((selected_edge.x - 2.0).abs() < 1e-9);
    assert!(
        selected_edge.y > 0.0,
        "same-rank fixed-node dot edges should be routed off the node rank"
    );
    assert_point_close(
        edges[1].pos.as_ref().unwrap(),
        &TypstPoint { x: 88.0, y: 88.0 },
    );
}

#[test]
fn test_fixed_node_dot_layout_uses_edge_label_size_for_parallel_edges() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph fixed_dot_labels {
            a [pos="0,0"]
            b [pos="10,0"]
            a -> b ["label-width"="8", "label-height"="1"]
            a -> b ["label-width"="8", "label-height"="1"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("layout-nodes".to_string(), "fixed".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
    let first = edges[0].pos.as_ref().unwrap();
    let second = edges[1].pos.as_ref().unwrap();
    assert!((first.x - 5.0).abs() < 1e-9);
    assert!((second.x - 5.0).abs() < 1e-9);
    assert!(
        (first.y - second.y).abs() > 1.0,
        "parallel same-rank edge labels should be assigned distinct measured-height lanes: {first:?} {second:?}"
    );
}

#[test]
fn test_fixed_node_dot_layout_lanes_same_rank_edge_labels() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph fixed_dot_same_rank_labels {
            a [pos="0,0"]
            b [pos="3,0"]
            c [pos="6,0"]
            d [pos="9,0"]
            a -> c ["label-width"="4", "label-height"="1"]
            b -> d ["label-width"="4", "label-height"="1"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let laid_out = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "dot".to_string()),
            ("layout-nodes".to_string(), "fixed".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();

    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
    let first = edges[0].pos.as_ref().unwrap();
    let second = edges[1].pos.as_ref().unwrap();
    assert!(first.y.abs() > 0.0);
    assert!(second.y.abs() > 0.0);
    assert!(
        (first.y - second.y).abs() > 0.5,
        "same-rank edge labels with overlapping x ranges should be assigned distinct lanes"
    );
}

#[test]
fn test_fixed_node_second_layout_respects_previous_node_positions() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph partial { a -> b; a -> b; a -> b; b -> c; c -> d; d -> a }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let tree_layout = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "tree".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let tree_nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&tree_layout).unwrap());

    let fixed_force_layout = layout_parsed_graph_bytes(
        &tree_layout,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "force".to_string()),
            ("layout-nodes".to_string(), "fixed".to_string()),
            ("label-steps".to_string(), "0".to_string()),
            ("steps".to_string(), "8".to_string()),
            ("epochs".to_string(), "3".to_string()),
        ])),
    )
    .unwrap();
    let fixed_nodes: Vec<TypstDotNode> =
        decode_cbor(&graph_nodes_bytes(&fixed_force_layout).unwrap());

    for (tree_node, fixed_node) in tree_nodes.iter().zip(fixed_nodes.iter()) {
        assert_point_close(
            fixed_node.pos.as_ref().unwrap(),
            tree_node.pos.as_ref().unwrap(),
        );
    }

    let info: TypstDotGraphInfo = decode_cbor(&graph_info_bytes(&fixed_force_layout).unwrap());
    assert!(!info.global_statements.contains_key("layout-nodes"));
    assert!(!info.global_statements.contains_key("layout-algo"));
    assert!(!info.global_statements.contains_key("steps"));
}

#[test]
fn test_fixed_node_tree_layout_straightens_existing_edges() {
    let parsed = parse_dot_graphs_bytes(
        br#"digraph straight {
            a [pos="0,0"]
            b [pos="4,0"]
            a -> b [pos="0,8"]
        }"#,
    )
    .unwrap();
    let graph = decode_graphs(&parsed).remove(0);

    let fixed_tree_layout = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "tree".to_string()),
            ("layout-nodes".to_string(), "fixed".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&fixed_tree_layout).unwrap());
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&fixed_tree_layout).unwrap());
    let source = nodes[0].pos.as_ref().unwrap();
    let sink = nodes[1].pos.as_ref().unwrap();

    assert_point_close(
        edges[0].pos.as_ref().unwrap(),
        &TypstPoint {
            x: 0.5 * (source.x + sink.x),
            y: 0.5 * (source.y + sink.y),
        },
    );

    let force_layout = layout_parsed_graph_bytes(
        &graph,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "force".to_string()),
            ("label-steps".to_string(), "0".to_string()),
            ("steps".to_string(), "8".to_string()),
            ("epochs".to_string(), "2".to_string()),
        ])),
    )
    .unwrap();
    let fixed_tree_layout = layout_parsed_graph_bytes(
        &force_layout,
        &encode_cbor(&BTreeMap::from([
            ("layout-algo".to_string(), "tree".to_string()),
            ("layout-nodes".to_string(), "fixed".to_string()),
            ("label-steps".to_string(), "0".to_string()),
        ])),
    )
    .unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&fixed_tree_layout).unwrap());
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&fixed_tree_layout).unwrap());
    let source = nodes[0].pos.as_ref().unwrap();
    let sink = nodes[1].pos.as_ref().unwrap();

    assert_point_close(
        edges[0].pos.as_ref().unwrap(),
        &TypstPoint {
            x: 0.5 * (source.x + sink.x),
            y: 0.5 * (source.y + sink.y),
        },
    );
}

#[test]
fn test_layout_preserves_hedge_compass_subgraphs() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestGraphSpec {
        name: "compass".to_string(),
        statements: BTreeMap::new(),
        nodes: vec![
            TestNodeSpec {
                name: "a".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "b".to_string(),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![TestEdgeSpec {
            source: Some(TestEndpointSpec {
                node: 0,
                compass: None,
                statement: None,
            }),
            sink: Some(TestEndpointSpec {
                node: 1,
                compass: Some("e".to_string()),
                statement: None,
            }),
            statements: BTreeMap::new(),
        }],
    }))
    .unwrap();

    let laid_out = layout_parsed_graph_bytes(&graph, &empty_config_bytes()).unwrap();
    let east = graph_archived_compass_subgraph_bytes(&laid_out, &encode_cbor(&"e")).unwrap();
    let hedges: Vec<usize> = decode_cbor(&subgraph_hedges_bytes(&east).unwrap());

    assert_eq!(hedges.len(), 1);
    let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
    assert_eq!(
        edges[0].sink.as_ref().unwrap().compass.as_deref(),
        Some("e")
    );
    assert_eq!(hedges[0], edges[0].sink.as_ref().unwrap().hedge);
}

#[test]
fn test_layout_handles_disconnected_spec_nodes() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestGraphSpec {
        name: "demo".to_string(),
        statements: BTreeMap::new(),
        nodes: vec![
            TestNodeSpec {
                name: "a".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "c".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "d".to_string(),
                statements: BTreeMap::new(),
            },
            TestNodeSpec {
                name: "e".to_string(),
                statements: BTreeMap::new(),
            },
        ],
        edges: vec![
            TestEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: None,
                }),
                sink: Some(TestEndpointSpec {
                    node: 3,
                    compass: None,
                    statement: None,
                }),
                statements: BTreeMap::new(),
            },
            TestEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 3,
                    compass: None,
                    statement: None,
                }),
                sink: Some(TestEndpointSpec {
                    node: 2,
                    compass: None,
                    statement: None,
                }),
                statements: BTreeMap::new(),
            },
        ],
    }))
    .unwrap();

    let laid_out = layout_parsed_graph_bytes(&graph, &empty_config_bytes()).unwrap();
    let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());
    assert_eq!(nodes.len(), 4);
    assert!(nodes.iter().all(|node| node.pos.is_some()));
}

#[test]
fn test_force_center_gravity_keeps_disconnected_nodes_close() {
    fn max_node_radius(g_center: &str) -> f64 {
        let graph = graph_from_spec_bytes(&encode_graph_spec(&TestGraphSpec {
            name: "demo".to_string(),
            statements: BTreeMap::new(),
            nodes: vec![
                TestNodeSpec {
                    name: "a".to_string(),
                    statements: BTreeMap::new(),
                },
                TestNodeSpec {
                    name: "c".to_string(),
                    statements: BTreeMap::new(),
                },
                TestNodeSpec {
                    name: "d".to_string(),
                    statements: BTreeMap::new(),
                },
            ],
            edges: vec![TestEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: None,
                }),
                sink: Some(TestEndpointSpec {
                    node: 1,
                    compass: None,
                    statement: None,
                }),
                statements: BTreeMap::new(),
            }],
        }))
        .unwrap();

        let config = BTreeMap::from([
            ("layout-algo".to_string(), "force".to_string()),
            ("seed".to_string(), "2".to_string()),
            ("steps".to_string(), "10".to_string()),
            ("epochs".to_string(), "3".to_string()),
            ("step".to_string(), "0.81".to_string()),
            ("delta".to_string(), "0.4".to_string()),
            ("beta".to_string(), "46.1".to_string()),
            ("g-center".to_string(), g_center.to_string()),
            ("length-scale".to_string(), "0.01".to_string()),
        ]);
        let laid_out = layout_parsed_graph_bytes(&graph, &encode_cbor(&config)).unwrap();
        let nodes: Vec<TypstDotNode> = decode_cbor(&graph_nodes_bytes(&laid_out).unwrap());

        nodes
            .iter()
            .map(|node| {
                let pos = node.pos.as_ref().unwrap();
                (pos.x.powi(2) + pos.y.powi(2)).sqrt()
            })
            .fold(0.0, f64::max)
    }

    let uncentered = max_node_radius("0");
    let centered = max_node_radius("500000");

    assert!(
        centered < uncentered,
        "expected center gravity to reduce max radius, got {centered} >= {uncentered}"
    );
}

#[test]
fn dot_cbor() {
    let figment = test_figment();
    let g = TypstGraph::from_dot(dot!(digraph{ a; a->b}).unwrap(), &figment);

    let _cbor = g.to_cbor();
}

#[test]
fn test_cbor_serialization() {
    let figment = test_figment();
    let g = TypstGraph::from_dot(dot!(digraph{ a; a->b; b->c}).unwrap(), &figment);
    let cbor = g.to_cbor();

    let test_path = "test_graph.cbor";

    cbor.serialize_to_file(test_path)
        .expect("Failed to serialize to file");

    let deserialized =
        CBORTypstGraph::deserialize_from_file(test_path).expect("Failed to deserialize from file");

    assert_eq!(cbor.nodes.len(), deserialized.nodes.len());
    assert_eq!(cbor.edges.len(), deserialized.edges.len());

    fs::remove_file(test_path).ok();
}

#[test]
fn test_typst_graph_convenience_serialization() {
    let figment = test_figment();
    let g = TypstGraph::from_dot(dot!(digraph{ a->b; b->c}).unwrap(), &figment);
    let test_path = "test_convenience_graph.cbor";

    g.serialize_to_file(test_path)
        .expect("Failed to serialize using convenience method");

    let deserialized =
        CBORTypstGraph::deserialize_from_file(test_path).expect("Failed to deserialize from file");

    assert_eq!(g.to_cbor().nodes.len(), deserialized.nodes.len());
    assert_eq!(g.to_cbor().edges.len(), deserialized.edges.len());

    fs::remove_file(test_path).ok();
}

#[test]
fn typst_graph_rkyv_roundtrip() {
    let figment = test_figment();
    let mut graph = TypstGraph::from_dot(
        dot!(digraph {
            a [pin="x:1,y:-2"];
            b;
            a -> b [pin="@edge", "label-pos"="0.4,0.2", "label-angle"="0.3rad"];
        })
        .unwrap(),
        &figment,
    );
    graph.layout();

    let bytes = rkyv::to_bytes::<_, 4096>(&graph).expect("failed to archive TypstGraph");
    let restored =
        crate::graph_api::decode_typst_graph(&bytes).expect("failed to restore TypstGraph");

    assert_eq!(
        graph.to_dot_graph().debug_dot(),
        restored.to_dot_graph().debug_dot()
    );
}

#[test]
fn test_pin_parsing() {
    let figment = test_figment();
    let mut g = TypstGraph::from_dot(
        dot!( digraph dot_80_0_GL208 {

            steps=1
            step=0.4
            beta =13.1
            "k-spring"=20.3;
            "g-center"=0
            "gamma-ee"=0.3
            "gamma-ev"=0.01
            "length-scale" = 0.25
            node[
              eval="(stroke:blue,fill :black,
         radius:2pt,
         outset: -2pt)"
            ]

            edge[
              eval=top
            ]
            v0[pin="x:@initial,y:@p1", style=invis]
            v1[pin="x:@initial,y:@p2",style=invis]
            v2[pin="x:@final,y:@p1",style=invis]
            v3[pin="x:@final,y:@p2",style=invis]
            v0 -> v11 [eval=photon]
            v1 -> v10 [eval="(..photon,label:[$gamma$],label-side: left)"]
            v9 -> v2 [eval=photon]
            v8 -> v3 [eval=photon]
            v4 -> v10
            v10 -> v5
            v5 -> v11 [dir=back]
            v11 -> v4
            v4 -> v7 [eval=gluon]
            v5 -> v6 [eval=gluon]
            v6 -> v8
            v8 -> v7
            v7 -> v9
            v9 -> v6
        })
        .unwrap(),
        &figment,
    );

    g.layout();
    println!("{}", g.to_dot_graph().debug_dot())
}

#[test]
fn test_parsing() {
    let figment = test_figment();
    let g = TypstGraph::from_dot(
        dot!(digraph qqx_aaa_pentagon {
            steps=600
            step=.2
            beta =3.1
            "k-spring"=15.3;
            "g-center"=0
            "gamma-ee"=0.3
            "gamma-ev"=0.01
            "length-scale" = 0.2

             node[
              eval="(stroke:blue,fill :black,
          radius:2pt,
          outset: -2pt)"
            ]

        exte0 [style=invis pin="x:-4"];
        v3:0 -> exte0;
        })
        .unwrap(),
        &figment,
    );

    println!("{}", g.to_dot_graph().debug_dot())
}

#[test]
fn test_directional_constraints() {
    let figment = test_figment();
    let typst_graph = TypstGraph::from_dot(
        dot!(digraph {
            "tree-dy" = 2.0
            "tree-dx" = 3.0
            a [pin="x:+@group1"]
            b [pin="x:-@group1"]
            c [pin="y:+@group2"]
            d [pin="y:-@group2"]
            e -> f [pin="x:+@edge_group"]
            g -> h [pin="x:-@edge_group"]
            a -> b
            c -> d
        })
        .unwrap(),
        &figment,
    );
    let cfg = TreeInitCfg { dy: 2.0, dx: 3.0 };
    let (node_positions, edge_positions) = typst_graph.new_positions(cfg);

    let mut group1_positive = None;
    let mut group1_negative = None;
    let mut group2_positive = None;
    let mut group2_negative = None;

    for (node_idx, _, node) in typst_graph.iter_nodes() {
        match &node.constraints.x {
            Constraint::Grouped(_, ShiftDirection::PositiveOnly) => {
                group1_positive = Some(node_positions[node_idx].x);
            }
            Constraint::Grouped(_, ShiftDirection::NegativeOnly) => {
                group1_negative = Some(node_positions[node_idx].x);
            }
            _ => {}
        }
        match &node.constraints.y {
            Constraint::Grouped(_, ShiftDirection::PositiveOnly) => {
                group2_positive = Some(node_positions[node_idx].y);
            }
            Constraint::Grouped(_, ShiftDirection::NegativeOnly) => {
                group2_negative = Some(node_positions[node_idx].y);
            }
            _ => {}
        }
    }

    if let Some(pos_x) = group1_positive {
        assert!(pos_x >= 0.0);
    }

    if let Some(neg_x) = group1_negative {
        assert!(neg_x <= 0.0);
    }

    if let Some(pos_y) = group2_positive {
        assert!(pos_y >= 0.0);
    }

    if let Some(neg_y) = group2_negative {
        assert!(neg_y <= 0.0);
    }

    if let (Some(pos_x), Some(neg_x)) = (group1_positive, group1_negative) {
        assert!(pos_x > neg_x);
    }

    if let (Some(pos_y), Some(neg_y)) = (group2_positive, group2_negative) {
        assert!(pos_y > neg_y);
    }

    let mut edge_group_positive = None;
    let mut edge_group_negative = None;

    for (_, eid, edge_data) in typst_graph.iter_edges() {
        let edge = edge_data.data;
        match &edge.constraints.x {
            Constraint::Grouped(_, ShiftDirection::PositiveOnly) => {
                edge_group_positive = Some(edge_positions[eid].x);
            }
            Constraint::Grouped(_, ShiftDirection::NegativeOnly) => {
                edge_group_negative = Some(edge_positions[eid].x);
            }
            _ => {}
        }
    }

    if let Some(pos_edge_x) = edge_group_positive {
        assert!(pos_edge_x >= 0.0);
    }

    if let Some(neg_edge_x) = edge_group_negative {
        assert!(neg_edge_x <= 0.0);
    }

    if let (Some(pos_edge_x), Some(neg_edge_x)) = (edge_group_positive, edge_group_negative) {
        assert!(pos_edge_x > neg_edge_x);
    }

    assert!(group1_positive.is_some());
    assert!(group1_negative.is_some());
    assert!(group2_positive.is_some());
    assert!(group2_negative.is_some());
    assert!(edge_group_positive.is_some());
    assert!(edge_group_negative.is_some());
}

#[test]
fn grouped_coordinate_identity_includes_axis_and_side() {
    let graph = TypstGraph::from_dot(
        dot!(digraph {
            both [id=0 pin="@same"]
            x_member [id=1 pin="x:@same"]
            y_member [id=2 pin="y:@same"]
            positive [id=3 pin="x:+@same"]
            negative [id=4 pin="x:-@same"]
        })
        .unwrap(),
        &test_figment(),
    );

    let Constraint::Grouped(both_x, _) = graph[NodeIndex(0)].constraints.x else {
        panic!("combined group lost its x coordinate");
    };
    let Constraint::Grouped(both_y, _) = graph[NodeIndex(0)].constraints.y else {
        panic!("combined group lost its y coordinate");
    };
    let Constraint::Grouped(x_member, _) = graph[NodeIndex(1)].constraints.x else {
        panic!("x member lost its grouped coordinate");
    };
    let Constraint::Grouped(y_member, _) = graph[NodeIndex(2)].constraints.y else {
        panic!("y member lost its grouped coordinate");
    };
    let Constraint::Grouped(positive_x, _) = graph[NodeIndex(3)].constraints.x else {
        panic!("positive group lost its x coordinate");
    };
    let Constraint::Grouped(negative_x, _) = graph[NodeIndex(4)].constraints.x else {
        panic!("negative group lost its x coordinate");
    };

    assert_eq!(x_member, both_x);
    assert_eq!(y_member, both_y);
    assert_ne!(positive_x, negative_x);
    assert_ne!(both_x, positive_x);
    assert_ne!(both_x, negative_x);

    let (mut nodes, mut edges) = graph.new_positions(TreeInitCfg { dx: 1.0, dy: 1.0 });
    nodes[NodeIndex(0)] = cgmath::Point2::new(1.0, 2.0);
    nodes[NodeIndex(1)] = cgmath::Point2::new(-9.0, 30.0);
    nodes[NodeIndex(2)] = cgmath::Point2::new(40.0, -8.0);
    graph.apply_grouped_constraints(&mut nodes, &mut edges);
    assert_eq!(nodes[NodeIndex(1)], cgmath::Point2::new(1.0, 30.0));
    assert_eq!(nodes[NodeIndex(2)], cgmath::Point2::new(40.0, 2.0));
}

#[test]
fn grouped_directional_constraints_enforce_pin_side_after_layout() {
    let figment = test_figment();
    let typst_graph = TypstGraph::from_dot(
        dot!(digraph {
            a -> b [pin="x:@+right"]
            b -> c [pin="x:@-left"]
        })
        .unwrap(),
        &figment,
    );
    let (mut node_positions, mut edge_positions) =
        typst_graph.new_positions(TreeInitCfg { dx: 1.0, dy: 1.0 });

    edge_positions[EdgeIndex(0)].x = -2.0;
    edge_positions[EdgeIndex(1)].x = 2.0;

    typst_graph.apply_grouped_constraints(&mut node_positions, &mut edge_positions);

    assert!(edge_positions[EdgeIndex(0)].x >= 0.0);
    assert!(edge_positions[EdgeIndex(1)].x <= 0.0);
}

#[test]
fn node_and_edge_groups_share_their_axis() {
    let typst_graph = TypstGraph::from_dot(
        dot!(digraph {
            helper [id=0 pin="x:@-left"]
            a [id=1]
            b [id=2]
            a -> b [id=0 pin="x:@-left"]
        })
        .unwrap(),
        &test_figment(),
    );
    let (mut node_positions, mut edge_positions) =
        typst_graph.new_positions(TreeInitCfg { dx: 1.0, dy: 1.0 });

    node_positions[NodeIndex(0)].x = -2.0;
    edge_positions[EdgeIndex(0)].x = -8.0;
    typst_graph.apply_grouped_constraints(&mut node_positions, &mut edge_positions);

    assert_eq!(
        node_positions[NodeIndex(0)].x,
        edge_positions[EdgeIndex(0)].x
    );
    assert_eq!(edge_positions[EdgeIndex(0)].x, -2.0);
}

#[test]
fn cross_kind_group_is_one_force_and_annealing_coordinate() {
    let settings = BTreeMap::from([
        ("layout-algo".to_string(), "force".to_string()),
        ("steps".to_string(), "20".to_string()),
        ("epochs".to_string(), "1".to_string()),
        ("step".to_string(), "0.05".to_string()),
        ("delta".to_string(), "0.2".to_string()),
        ("beta".to_string(), "0".to_string()),
        ("k-spring".to_string(), "4".to_string()),
        ("depth-scale".to_string(), "0".to_string()),
        ("length-scale".to_string(), "0.2".to_string()),
    ]);
    let figment = Figment::from(Serialized::from(settings, Profile::Default));
    let mut graph = TypstGraph::from_dot(
        dot!(digraph {
            helper [id=0 pin="y:@row"]
            a [id=1 pin="-2,-2"]
            b [id=2 pin="2,3"]
            a -> b [id=0 pin="x:0,y:@row"]
        })
        .unwrap(),
        &figment,
    );

    let Constraint::Grouped(node_reference, _) = graph[NodeIndex(0)].constraints.y else {
        panic!("helper node lost its y group");
    };
    let Constraint::Grouped(edge_reference, _) = graph[EdgeIndex(0)].constraints.y else {
        panic!("edge control point lost its y group");
    };
    assert_eq!(node_reference, edge_reference);

    let selected_nodes = graph.new_nodevec(|_, _, _| false);
    let mut selected_edges = graph.new_edgevec(|_, _, _| false);
    selected_edges[EdgeIndex(0)] = true;
    let (node_axes, edge_axes) =
        graph.grouped_layout_selection(&selected_nodes, &selected_edges, true);
    assert!(!node_axes[NodeIndex(0)].x);
    assert!(node_axes[NodeIndex(0)].y);
    assert!(edge_axes[EdgeIndex(0)].x);
    assert!(edge_axes[EdgeIndex(0)].y);
    let saved_node_constraints = graph.new_nodevec(|_, _, node| node.constraints);
    let saved_edge_constraints = graph.new_edgevec(|edge, _, _| edge.constraints);
    graph.freeze_unselected_layout_axes(&node_axes, &edge_axes);
    assert!(matches!(
        graph[NodeIndex(0)].constraints.x,
        Constraint::Fixed
    ));
    assert!(matches!(
        graph[NodeIndex(0)].constraints.y,
        Constraint::Grouped(_, _)
    ));
    graph.restore_layout_constraints(saved_node_constraints, saved_edge_constraints);

    let spring = linnet::half_edge::layout::spring::ParamTuning::from(&graph.layout_config.spring);
    let (tree, energy) = graph.tree_init_cfg(&spring, graph.n_nodes());
    let (mut nodes, mut edges) = graph.new_positions(tree);
    nodes[NodeIndex(0)].y = 4.0;
    edges[EdgeIndex(0)].y = -3.0;

    let state = graph.new_layout_state(nodes.clone(), edges.clone(), 0.2, 0.0, true);
    let mut empty_schedule = GeoSchedule::new(0, 0, 0.85, 0.15, 0.7, 1e-6);
    let (prepared, _) = anneal::<_, _, _, _, SmallRng>(
        state.clone(),
        SAConfig {
            seed: 7,
            temp: 0.3,
            step: 0.2,
        },
        &PinnedLayoutNeighbor,
        &energy,
        &mut empty_schedule,
    );
    assert_eq!(
        prepared.vertex_points[NodeIndex(0)].y,
        prepared.edge_points[EdgeIndex(0)].y
    );

    let mut rng = SmallRng::seed_from_u64(7);
    let next = PinnedLayoutNeighbor.propose(&state, &mut rng, 0.2, 0.3);
    assert_eq!(
        next.vertex_points[NodeIndex(0)].y,
        next.edge_points[EdgeIndex(0)].y
    );
    assert_ne!(next.vertex_points[NodeIndex(0)].y, 4.0);
    assert!(next.changed_nodes.includes(&NodeIndex(0)));
    assert!(next.changed_edges.includes(&EdgeIndex(0)));
    let cached = energy.energy(None, &state);
    let incremental = energy.energy(Some((&state, cached)), &next);
    let mut full = next.clone();
    full.incremental = false;
    let exact = energy.energy(None, &full);
    assert!((incremental - exact).abs() <= 1e-9 * (1.0 + exact.abs()));

    let (nodes, edges, _) = graph.optimized_positions(nodes, edges, &energy, None, None);
    assert_eq!(nodes[NodeIndex(0)].y, edges[EdgeIndex(0)].y);
    assert_ne!(nodes[NodeIndex(0)].y, 4.0);
}

#[test]
fn gammaloop_external_edge_pins_align_by_group_and_side() {
    let figment = test_figment();
    let mut typst_graph = TypstGraph::from_dot(
        dot!(digraph {
            "layout-algo" = "force"
            steps = 10
            epochs = 2
            ext_r0 [style=invis]
            ext_r1 [style=invis]
            ext_l0 [style=invis]
            ext_l1 [style=invis]
            a
            b
            ext_r0 -> a [id=0 pin="x:@+right,y:@edgee0"]
            ext_r1 -> a [id=1 pin="x:@+right,y:@edgee1"]
            b -> ext_l0 [id=2 pin="x:@-left,y:@edgee0"]
            b -> ext_l1 [id=3 pin="x:@-left,y:@edgee1"]
            a -> b
        })
        .unwrap(),
        &figment,
    );

    typst_graph.layout();

    let mut edge_positions = BTreeMap::new();
    for (_, edge_index, edge_data) in typst_graph.iter_edges() {
        let edge = edge_data.data;
        edge_positions.insert(edge_index.0, edge.pos);
    }

    let right0 = edge_positions.get(&0).unwrap();
    let right1 = edge_positions.get(&1).unwrap();
    let left0 = edge_positions.get(&2).unwrap();
    let left1 = edge_positions.get(&3).unwrap();

    assert!(right0.x > 0.0, "{right0:?}");
    assert!(right1.x > 0.0, "{right1:?}");
    assert!(left0.x < 0.0, "{left0:?}");
    assert!(left1.x < 0.0, "{left1:?}");
    assert!((right0.y - left0.y).abs() < 1e-9, "{right0:?} {left0:?}");
    assert!((right1.y - left1.y).abs() < 1e-9, "{right1:?} {left1:?}");
}

#[test]
fn gammaloop_external_edge_pos_aligns_by_group_and_side() {
    let figment = test_figment();
    let mut typst_graph = TypstGraph::from_dot(
        dot!(digraph {
            "layout-algo" = "force"
            steps = 10
            epochs = 2
            ext_l0 [style=invis]
            ext_l1 [style=invis]
            ext_r0 [style=invis]
            ext_r1 [style=invis]
            a
            b
            ext_l0 -> a [id=0 pos="x:@-left!,y:@edgee0!"]
            ext_l1 -> a [id=1 pos="x:@-left!,y:@edgee1!"]
            b -> ext_r0 [id=2 pos="x:@+right!,y:@edgee0!"]
            b -> ext_r1 [id=3 pos="x:@+right!,y:@edgee1!"]
            a -> b
        })
        .unwrap(),
        &figment,
    );

    typst_graph.layout();

    let mut edge_positions = BTreeMap::new();
    for (_, edge_index, edge_data) in typst_graph.iter_edges() {
        let edge = edge_data.data;
        edge_positions.insert(edge_index.0, edge.pos);
    }

    let left0 = edge_positions.get(&0).unwrap();
    let left1 = edge_positions.get(&1).unwrap();
    let right0 = edge_positions.get(&2).unwrap();
    let right1 = edge_positions.get(&3).unwrap();

    assert!(left0.x < 0.0, "{left0:?}");
    assert!(left1.x < 0.0, "{left1:?}");
    assert!(right0.x > 0.0, "{right0:?}");
    assert!(right1.x > 0.0, "{right1:?}");
    assert!((left0.y - right0.y).abs() < 1e-9, "{left0:?} {right0:?}");
    assert!((left1.y - right1.y).abs() < 1e-9, "{left1:?} {right1:?}");
}

#[test]
fn test_full() {
    let input = stringify!(
       digraph {
           steps=600
           step=0.4
           beta =13.1
           "k-spring"=3.3;
           "g-center"=0
           "gamma-dangling"=50
           "gamma-ee"=0.3
           "gamma-ev"=0.01
           "length-scale" = 0.25
           a->b
       }
    );

    let figment = Figment::from(Serialized::from(
        BTreeMap::<String, String>::new(),
        Profile::Default,
    ));

    let dots = DotGraphSet::from_string_with_figment(input, figment.clone())
        .map_err(|a| a.to_string())
        .unwrap()
        .into_iter();

    let mut graphs = Vec::new();
    for g in dots {
        let mut typst_graph = TypstGraph::from_dot(g, &figment);

        typst_graph.layout();
        graphs.push((
            typst_graph.to_cbor(),
            typst_graph.to_dot_graph().debug_dot(),
        ));
    }
}

#[test]
fn dangling_centroid_repulsion_keeps_grouped_external_edges_outside() {
    let input = r#"digraph {
        a [pin="y:0" pos="0,0" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        b [pin="y:-3" pos="-2,-3" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        c [pin="y:3" pos="-2,3" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        d [pin="y:0" pos="2,0" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        a -> c [id=0]
        b -> a [id=1]
        ext2 [style=invis]
        ext2 -> b [id=2 pin="x:@-in,y:-4"]
        ext3 [style=invis]
        ext3 -> c [id=3 pin="x:@-in,y:4"]
        ext4 [style=invis]
        ext4 -> d [id=4 pin="x:@+out,y:4"]
        ext5 [style=invis]
        d -> ext5 [id=5 pin="x:@+out,y:-4"]
        a -> d [id=6]
        ext7 [style=invis]
        b -> ext7 [id=7 pin="x:@+out,y:0"]
        ext8 [style=invis]
        ext8 -> c [id=8 pin="x:@-in,y:0"]
    }"#;

    let settings = BTreeMap::from([
        ("steps".to_string(), "50".to_string()),
        ("epochs".to_string(), "50".to_string()),
        ("seed".to_string(), "7".to_string()),
        ("gamma-dangling".to_string(), "3.0".to_string()),
        ("gamma-dangling-centroid".to_string(), "1.25".to_string()),
        ("gamma-ev".to_string(), "0.05".to_string()),
        ("k-spring".to_string(), "4".to_string()),
        ("beta".to_string(), "10".to_string()),
        ("directional-force".to_string(), "10".to_string()),
        ("length-scale".to_string(), "0.4".to_string()),
    ]);
    let figment = Figment::from(Serialized::from(settings, Profile::Default));
    let mut graph = TypstGraph::parse(input).unwrap();
    graph.layout_config = crate::LayoutConfig::from_figment(&figment);
    let spring = linnet::half_edge::layout::spring::ParamTuning::from(&graph.layout_config.spring);
    let (tree, energy) = graph.tree_init_cfg(&spring, graph.n_nodes());
    assert!((energy.dangling_centroid_charge / energy.c_vv - 1.25).abs() < 1e-12);
    let (nodes, edges) = graph.new_positions(tree);
    let (nodes, edges, _) = graph.optimized_positions(nodes, edges, &energy, None, None);

    assert!(edges[EdgeIndex(4)].x > nodes[NodeIndex(3)].x);
    assert!(edges[EdgeIndex(2)].x < nodes[NodeIndex(2)].x);
}

#[test]
fn grouped_open_xbox_keeps_cut_gluons_aligned_and_outside() {
    let input = r#"digraph {
        a [pin="y:0" pos="0,0" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        b [pin="y:-3" pos="-2,-3" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        c [pin="y:3" pos="-2,3" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        d [pin="y:0" pos="2,0" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        a -> c [id=0]
        b -> a [id=1 pin="x:@+lower-inner" pos="0.5,0" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="false" "group-start-x"="true"]
        ext2 [style=invis]
        ext2 -> b [id=2 pin="x:@-in,y:-4" pos="0,-4" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        ext3 [style=invis]
        ext3 -> c [id=3 pin="x:@-in,y:4" pos="0,4" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        ext4 [style=invis]
        ext4 -> d [id=4 pin="x:@+out,y:4" pos="0,4" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        ext5 [style=invis]
        d -> ext5 [id=5 pin="x:@+out,y:-4" pos="0,-4" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true"]
        a -> d [id=6]
        ext7 [style=invis]
        b -> ext7 [id=7 pin="x:@+out,y:@cut" pos="0,0" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true" "group-start-y"="true"]
        ext8 [style=invis]
        ext8 -> c [id=8 pin="x:@-in,y:@cut" pos="0,0" "pos-mode"="start" "pos-x-set"="true" "pos-y-set"="true" "group-start-y"="true"]
    }"#;
    let settings = BTreeMap::from([
        ("layout-algo".to_string(), "force".to_string()),
        ("steps".to_string(), "50".to_string()),
        ("epochs".to_string(), "50".to_string()),
        ("seed".to_string(), "2".to_string()),
        ("step".to_string(), "0.09".to_string()),
        ("delta".to_string(), "0.35".to_string()),
        ("cool".to_string(), "0.92".to_string()),
        ("gamma-dangling".to_string(), "1.8".to_string()),
        ("gamma-dangling-centroid".to_string(), "3.6".to_string()),
        ("gamma-ev".to_string(), "0.07".to_string()),
        ("k-spring".to_string(), "11".to_string()),
        ("beta".to_string(), "4.8".to_string()),
        ("gamma-ee".to_string(), "0.08".to_string()),
        ("g-center".to_string(), "0.015".to_string()),
        ("directional-force".to_string(), "5".to_string()),
        ("length-scale".to_string(), "0.51".to_string()),
        ("depth-scale".to_string(), "1".to_string()),
        ("flattening-end".to_string(), "0.5".to_string()),
    ]);
    let figment = Figment::from(Serialized::from(settings, Profile::Default));
    let mut graph = TypstGraph::parse(input).unwrap();
    graph.layout_config = crate::LayoutConfig::from_figment(&figment);

    let Constraint::Grouped(right_cut_y, ShiftDirection::Any) = graph[EdgeIndex(7)].constraints.y
    else {
        panic!("right cut gluon lost its free y group")
    };
    let Constraint::Grouped(left_cut_y, ShiftDirection::Any) = graph[EdgeIndex(8)].constraints.y
    else {
        panic!("left cut gluon lost its free y group")
    };
    assert_eq!(right_cut_y, left_cut_y);
    assert_eq!(graph[EdgeIndex(7)].pos.y, graph[EdgeIndex(8)].pos.y);

    graph.layout();

    let lower_inner = graph[EdgeIndex(1)].pos;
    let upper_in = graph[EdgeIndex(3)].pos;
    let upper_out = graph[EdgeIndex(4)].pos;
    let lower_out = graph[EdgeIndex(5)].pos;
    let right_cut = graph[EdgeIndex(7)].pos;
    let left_cut = graph[EdgeIndex(8)].pos;
    let right_node = graph[NodeIndex(3)].pos;
    assert!(
        lower_inner.x > 0.0,
        "lower-inner control moved left: {lower_inner:?}"
    );
    assert!(
        (lower_out.y + 4.0).abs() < 1e-9,
        "pinned outgoing edge moved: {lower_out:?}"
    );
    assert_eq!(right_cut.y, left_cut.y);
    assert!((upper_out.x - lower_out.x).abs() < 1e-9);
    assert!((lower_out.x - right_cut.x).abs() < 1e-9);
    assert!((upper_in.x - left_cut.x).abs() < 1e-9);
    assert!(
        lower_out.x > right_node.x,
        "out group is not outside: {lower_out:?} {right_node:?}"
    );

    let mut repeated = TypstGraph::parse(input).unwrap();
    repeated.layout_config = crate::LayoutConfig::from_figment(&figment);
    repeated.layout();
    for edge in [1, 3, 4, 5, 7, 8] {
        assert_eq!(graph[EdgeIndex(edge)].pos, repeated[EdgeIndex(edge)].pos);
    }
}

#[test]
fn grouped_open_xbox_free_rows_separate_after_depth_flattening() {
    // Unlike the pinned-row fixture, all node y coordinates and all three rows
    // are free. The 3D-only layout left cut and d1 just 0.20764 units apart in 2D.
    let input = r#"digraph {
        a [id=0 pos="0,0" "pos-mode"="start" "pos-x-set"=true "pos-y-set"=false]
        b [id=1 pos="-2,0" "pos-mode"="start" "pos-x-set"=true "pos-y-set"=false]
        c [id=2 pos="-2,0" "pos-mode"="start" "pos-x-set"=true "pos-y-set"=false]
        d [id=3 pos="2,0" "pos-mode"="start" "pos-x-set"=true "pos-y-set"=false]
        ext [style=invis]
        a -> c [id=0]
        b -> a [id=1 pin="x:@+lower-inner" pos="0.5,0" "pos-x-set"=true "pos-y-set"=false "group-start-x"=true]
        ext -> b [id=2 pin="x:@-in,y:@d1" pos="-7,-5" "group-start-x"=true "group-start-y"=true]
        ext -> c [id=3 pin="x:@-in,y:@d2" pos="-7,5" "group-start-x"=true "group-start-y"=true]
        ext -> d [id=4 pin="x:@+out,y:@d2" pos="7,5" "group-start-x"=true "group-start-y"=true]
        d -> ext [id=5 pin="x:@+out,y:@d1" pos="7,-5" "group-start-x"=true "group-start-y"=true]
        a -> d [id=6 "spring-length"=0.1]
        b -> ext [id=7 pin="x:@+out,y:@cut" pos="7,0" "group-start-x"=true "group-start-y"=true]
        ext -> c [id=8 pin="x:@-in,y:@cut" pos="-7,0" "group-start-x"=true "group-start-y"=true]
    }"#;
    let settings = BTreeMap::from([
        ("layout-algo".to_string(), "force".to_string()),
        ("steps".to_string(), "50".to_string()),
        ("epochs".to_string(), "50".to_string()),
        ("seed".to_string(), "2".to_string()),
        ("step".to_string(), "0.81".to_string()),
        ("delta".to_string(), "0.4".to_string()),
        ("cool".to_string(), "0.85".to_string()),
        ("k-spring".to_string(), "18".to_string()),
        ("length-scale".to_string(), "0.25".to_string()),
        ("beta".to_string(), "12".to_string()),
        ("gamma-ev".to_string(), "0.29".to_string()),
        ("gamma-ee".to_string(), "0.1".to_string()),
        ("gamma-dangling".to_string(), "14.75".to_string()),
        ("gamma-dangling-centroid".to_string(), "25".to_string()),
        ("g-center".to_string(), "0.0005".to_string()),
        ("directional-force".to_string(), "10".to_string()),
        ("depth-scale".to_string(), "1".to_string()),
        ("flattening-end".to_string(), "0.5".to_string()),
        ("label-steps".to_string(), "0".to_string()),
    ]);
    let figment = Figment::from(Serialized::from(settings, Profile::Default));
    let mut graph = TypstGraph::parse(input).unwrap();
    graph.layout_config = crate::LayoutConfig::from_figment(&figment);
    for index in 0..4 {
        assert!(matches!(
            graph[NodeIndex(index)].constraints.y,
            Constraint::Free
        ));
        assert!(!graph[NodeIndex(index)].start_y);
    }
    for (left, right) in [(2, 5), (3, 4), (7, 8)] {
        let Constraint::Grouped(left_group, ShiftDirection::Any) =
            graph[EdgeIndex(left)].constraints.y
        else {
            panic!("edge {left} lost its freely ordered y group");
        };
        let Constraint::Grouped(right_group, ShiftDirection::Any) =
            graph[EdgeIndex(right)].constraints.y
        else {
            panic!("edge {right} lost its freely ordered y group");
        };
        assert_eq!(left_group, right_group);
    }

    graph.layout();

    for (left, right) in [(2, 5), (3, 4), (7, 8)] {
        assert_eq!(graph[EdgeIndex(left)].pos.y, graph[EdgeIndex(right)].pos.y);
    }
    for (first, second) in [(2, 3), (2, 8), (4, 5), (4, 7)] {
        assert_eq!(
            graph[EdgeIndex(first)].pos.x,
            graph[EdgeIndex(second)].pos.x
        );
    }
    let cut_y = graph[EdgeIndex(7)].pos.y;
    for row in [2, 3] {
        let row_y = graph[EdgeIndex(row)].pos.y;
        let gap = (cut_y - row_y).abs();
        assert!(
            gap > 1.0,
            "projected cut/row gap is too small: cut={cut_y}, edge {row} y={row_y}, gap={gap}",
        );
    }
    assert!(graph[EdgeIndex(1)].pos.x >= 0.0);
    assert!(graph[EdgeIndex(2)].pos.x <= 0.0);
    assert!(graph[EdgeIndex(4)].pos.x >= 0.0);

    let mut repeated = TypstGraph::parse(input).unwrap();
    repeated.layout_config = crate::LayoutConfig::from_figment(&figment);
    repeated.layout();
    for index in 0..4 {
        let position = graph[NodeIndex(index)].pos;
        assert!(position.x.is_finite() && position.y.is_finite());
        assert_eq!(position, repeated[NodeIndex(index)].pos);
    }
    for index in 0..9 {
        let position = graph[EdgeIndex(index)].pos;
        assert!(position.x.is_finite() && position.y.is_finite());
        assert_eq!(position, repeated[EdgeIndex(index)].pos);
    }
}

#[test]
fn grouped_xbox_hidden_nodes_stay_clear_of_dangling_endpoints() {
    let input = r#"digraph {
        ext [style=invis]
        a [id=0 pin="x:-3,y:@+top" pos="-3,5" "group-start-y"=true]
        b [id=1 pin="x:-3,y:@-bottom" pos="-3,-5" "group-start-y"=true]
        c [id=2 pin="x:3,y:@+top" pos="3,5" "group-start-y"=true]
        d [id=3 pin="x:3,y:@-bottom" pos="3,-5" "group-start-y"=true]
        h1 [id=4 pin="x:@-in,y:@-lower-middle" pos="-7,-2" "group-start-x"=true "group-start-y"=true]
        h2 [id=5 pin="x:@+out,y:@+upper-middle" pos="7,2" "group-start-x"=true "group-start-y"=true]
        a -> ext [id=0 pin="x:@-in,y:@+top" pos="-7,5" "group-start-x"=true "group-start-y"=true]
        b -> a [id=1]
        ext -> b [id=2 pin="x:@-in,y:@-bottom" pos="-7,-5" "group-start-x"=true "group-start-y"=true]
        h1 -> h2 [id=3 pin="x:0" pos="0,0" "pos-x-set"=true "pos-y-set"=false]
        ext -> c [id=4 pin="x:@+out,y:@+top" pos="7,5" "group-start-x"=true "group-start-y"=true]
        c -> d [id=5]
        d -> ext [id=6 pin="x:@+out,y:@-bottom" pos="7,-5" "group-start-x"=true "group-start-y"=true]
        a -> ext [id=7 pin="x:@-in,y:@+upper-middle" pos="-7,2" "group-start-x"=true "group-start-y"=true]
        ext -> d [id=8 pin="x:@+out,y:@-lower-middle" pos="7,-2" "group-start-x"=true "group-start-y"=true]
        b -> c [id=9]
    }"#;
    let settings = BTreeMap::from([
        ("layout-algo".to_string(), "force".to_string()),
        ("steps".to_string(), "50".to_string()),
        ("epochs".to_string(), "50".to_string()),
        ("seed".to_string(), "2".to_string()),
        ("step".to_string(), "0.81".to_string()),
        ("cool".to_string(), "0.85".to_string()),
        ("delta".to_string(), "0.4".to_string()),
        ("beta".to_string(), "10".to_string()),
        ("k-spring".to_string(), "4".to_string()),
        ("gamma-dangling".to_string(), "2".to_string()),
        ("gamma-dangling-centroid".to_string(), "0".to_string()),
        ("gamma-ev".to_string(), "0.5".to_string()),
        ("gamma-ee".to_string(), "0.1".to_string()),
        ("g-center".to_string(), "0.005".to_string()),
        ("directional-force".to_string(), "10".to_string()),
        ("length-scale".to_string(), "0.45".to_string()),
        ("depth-scale".to_string(), "1".to_string()),
    ]);
    let figment = Figment::from(Serialized::from(settings, Profile::Default));
    let mut graph = TypstGraph::parse(input).unwrap();
    graph.layout_config = crate::LayoutConfig::from_figment(&figment);
    graph.layout();

    let h1 = graph[NodeIndex(4)].pos;
    let h2 = graph[NodeIndex(5)].pos;
    assert!((h1.y - graph[EdgeIndex(8)].pos.y).abs() < 1e-9);
    assert!((h2.y - graph[EdgeIndex(7)].pos.y).abs() < 1e-9);
    assert!(h1.x < 0.0 && h1.y < 0.0, "{h1:?}");
    assert!(h2.x > 0.0 && h2.y > 0.0, "{h2:?}");

    let left_gap = (h1.y - graph[EdgeIndex(7)].pos.y).abs();
    let right_gap = (h2.y - graph[EdgeIndex(8)].pos.y).abs();
    // Two 0.25-amplitude coils need more than 0.5 centerline spacing before
    // accounting for their strokes.
    assert!(
        left_gap > 0.75 && right_gap > 0.75,
        "hidden/dangling y gaps are too small: left={left_gap}, right={right_gap}",
    );
}

#[test]
fn edge_spring_length_scales_preserve_defaults_and_round_trip() {
    let graph = graph_from_spec_bytes(&encode_graph_spec(&TestTemplatedGraphSpec {
        name: "spring-scales".to_string(),
        statements: BTreeMap::new(),
        default_node_statements: BTreeMap::new(),
        default_edge_statements: one_statement("spring-length", "2"),
        nodes: ["a", "b"]
            .map(|name| TestNodeSpec {
                name: name.to_string(),
                statements: BTreeMap::new(),
            })
            .into(),
        edges: [None, Some("1"), Some("\"0.5\"")]
            .map(|scale| TestEdgeSpec {
                source: Some(TestEndpointSpec {
                    node: 0,
                    compass: None,
                    statement: None,
                }),
                sink: Some(TestEndpointSpec {
                    node: 1,
                    compass: None,
                    statement: None,
                }),
                statements: scale
                    .map(|scale| one_statement("spring-length", scale))
                    .unwrap_or_default(),
            })
            .into(),
    }))
    .unwrap();
    let graph = crate::graph_api::decode_typst_graph(&graph).unwrap();
    let archived = rkyv::to_bytes::<_, 4096>(&graph).unwrap();
    let restored = crate::graph_api::decode_typst_graph(&archived).unwrap();
    let round_trip = TypstGraph::parse(&graph.to_dot_graph().debug_dot()).unwrap();
    for graph in [&graph, &restored, &round_trip] {
        let (state, energy) = graph.layout_energy_state();
        assert_eq!(state.edge_spring_length_scales[EdgeIndex(0)], 2.0);
        assert_eq!(state.edge_spring_length_scales[EdgeIndex(1)], 1.0);
        assert_eq!(state.edge_spring_length_scales[EdgeIndex(2)], 0.5);
        let mut unscaled = TypstGraph::parse(&graph.to_dot_graph().debug_dot()).unwrap();
        for index in 0..3 {
            unscaled.graph[EdgeIndex(index)].statements.clear();
        }
        let (unscaled_state, unscaled_energy) = unscaled.layout_energy_state();
        for index in 0..3 {
            assert_eq!(
                unscaled_state.edge_spring_length_scales[EdgeIndex(index)],
                1.0
            );
        }
        assert_eq!(energy.spring_length, unscaled_energy.spring_length);
        assert_eq!(energy.c_vv, unscaled_energy.c_vv);
        assert_eq!(energy.eps, unscaled_energy.eps);
    }
}

#[test]
fn edge_spring_length_scales_affect_force_and_anneal_layout() {
    let input = r#"digraph {
        a [pin="x:0,y:0"]
        ext [style=invis]
        a -> ext [id=0 pos="2,0" pin="y:0" "spring-length"=0.5]
        a -> ext [id=1 pos="2,0" pin="y:0" "spring-length"=2]
    }"#;
    for algorithm in ["force", "anneal"] {
        let settings = BTreeMap::from([
            ("layout-algo".to_string(), algorithm.to_string()),
            ("viewport-w".to_string(), "2".to_string()),
            ("viewport-h".to_string(), "2".to_string()),
            ("length-scale".to_string(), "0.5".to_string()),
            ("beta".to_string(), "0".to_string()),
            ("k-spring".to_string(), "1".to_string()),
            ("label-steps".to_string(), "0".to_string()),
            ("steps".to_string(), "100".to_string()),
            ("epochs".to_string(), "30".to_string()),
            ("step".to_string(), "0.1".to_string()),
            ("cool".to_string(), "0.95".to_string()),
            ("temp".to_string(), "0.001".to_string()),
        ]);
        let mut graph = TypstGraph::parse(input).unwrap();
        graph.layout_config = crate::LayoutConfig::from_figment(&Figment::from(Serialized::from(
            settings,
            Profile::Default,
        )));
        graph.layout();
        assert_eq!(graph[NodeIndex(0)].pos, cgmath::Point2::new(0.0, 0.0));
        for (index, expected) in [1.0, 4.0].into_iter().enumerate() {
            let position = graph[EdgeIndex(index)].pos;
            assert_eq!(position.y, 0.0);
            assert!(
                (position.x.abs() - expected).abs() < 0.1,
                "{algorithm}: edge {index} should relax near {expected}, got {position:?}",
            );
        }
    }
}

#[test]
fn edge_spring_length_scales_reject_invalid_statements() {
    for value in ["0", "-1", "NaN", "inf", "bad"] {
        let mut graph = TypstGraph::parse("digraph { a -> b }").unwrap();
        graph.graph[EdgeIndex(0)].statements = one_statement("spring-length", value);
        let error = graph.layout_with_subgraph(None).unwrap_err();
        assert!(error.contains("spring-length must be a positive finite multiplier"));
    }
}

#[test]
fn external_pull_balance_defaults_and_propagates_through_settings() {
    let mut graph = TypstGraph::parse("digraph { a -> b }").unwrap();
    graph.layout_config = crate::LayoutConfig::from_figment(&test_figment());
    assert_eq!(graph.layout_config.spring.external_pull_balance, 1.0);
    assert_eq!(graph.layout_energy_state().1.external_pull_balance, 1.0);
    assert!(crate::LayoutConfig::is_layout_statement_key(
        "external-pull-balance"
    ));
    assert!(crate::LayoutConfig::is_layout_statement_key(
        "external_pull_balance"
    ));

    for balance in [0.0, 0.25, 1.0, 2.0, 3.5] {
        let config = one_statement("external-pull-balance", &balance.to_string());
        graph.layout_config = crate::LayoutConfig::from_figment(&Figment::from(Serialized::from(
            config,
            Profile::Default,
        )));
        assert_eq!(graph.layout_config.spring.external_pull_balance, balance);
        graph.validate_layout().unwrap();
        assert_eq!(graph.layout_energy_state().1.external_pull_balance, balance);
        let archived = rkyv::to_bytes::<_, 4096>(&graph).unwrap();
        let restored = crate::graph_api::decode_typst_graph(&archived).unwrap();
        assert_eq!(
            restored.layout_energy_state().1.external_pull_balance,
            balance
        );
    }
}

#[test]
fn external_pull_balance_rejects_invalid_settings_before_layout_or_streaming() {
    for value in ["-0.1", "NaN", "inf", "-inf"] {
        let config = one_statement("external-pull-balance", value);
        let mut graph = TypstGraph::parse("digraph { a -> b }").unwrap();
        graph.layout_config = crate::LayoutConfig::from_figment(&Figment::from(Serialized::from(
            &config,
            Profile::Default,
        )));
        assert!(graph
            .validate_layout()
            .unwrap_err()
            .contains("external-pull-balance"));
        let bytes = encode_cbor(&config);
        assert!(
            crate::ForceLayoutStream::from_dot("digraph { a -> b }", &bytes)
                .err()
                .unwrap()
                .contains("external-pull-balance")
        );
    }
}

#[test]
fn external_pull_attachment_defaults_and_propagates_through_settings() {
    let mut graph = TypstGraph::parse("digraph { a -> b }").unwrap();
    graph.layout_config = crate::LayoutConfig::from_figment(&test_figment());
    assert_eq!(graph.layout_config.spring.external_pull_attachment, 1.0);
    assert_eq!(graph.layout_energy_state().1.external_pull_attachment, 1.0);
    assert!(crate::LayoutConfig::is_layout_statement_key(
        "external-pull-attachment"
    ));
    assert!(crate::LayoutConfig::is_layout_statement_key(
        "external_pull_attachment"
    ));

    for balance in [0.0, 0.25, 1.0, 2.0, 16.0] {
        let config = one_statement("external-pull-attachment", &balance.to_string());
        graph.layout_config = crate::LayoutConfig::from_figment(&Figment::from(Serialized::from(
            config,
            Profile::Default,
        )));
        assert_eq!(graph.layout_config.spring.external_pull_attachment, balance);
        graph.validate_layout().unwrap();
        assert_eq!(
            graph.layout_energy_state().1.external_pull_attachment,
            balance
        );
        let archived = rkyv::to_bytes::<_, 4096>(&graph).unwrap();
        let restored = crate::graph_api::decode_typst_graph(&archived).unwrap();
        assert_eq!(
            restored.layout_energy_state().1.external_pull_attachment,
            balance
        );
    }
}

#[test]
fn external_pull_attachment_rejects_invalid_settings_before_layout_or_streaming() {
    for value in ["-0.1", "NaN", "inf", "-inf"] {
        let config = one_statement("external-pull-attachment", value);
        let mut graph = TypstGraph::parse("digraph { a -> b }").unwrap();
        graph.layout_config = crate::LayoutConfig::from_figment(&Figment::from(Serialized::from(
            &config,
            Profile::Default,
        )));
        assert!(graph
            .validate_layout()
            .unwrap_err()
            .contains("external-pull-attachment"));
        let bytes = encode_cbor(&config);
        assert!(
            crate::ForceLayoutStream::from_dot("digraph { a -> b }", &bytes)
                .err()
                .unwrap()
                .contains("external-pull-attachment")
        );
    }
}

#[test]
fn dangling_centroid_incremental_delta_matches_total_delta() {
    let input = r#"digraph {
        ext [style=invis]
        ext -> a
        b -> ext
        a -> b
        b -> c
        c -> a
    }"#;
    let settings = BTreeMap::from([
        ("gamma-dangling-centroid".to_string(), "1.25".to_string()),
        ("external-pull".to_string(), "2.0".to_string()),
    ]);
    let figment = Figment::from(Serialized::from(settings, Profile::Default));
    let mut graph = TypstGraph::parse(input).unwrap();
    graph.layout_config = crate::LayoutConfig::from_figment(&figment);
    let (mut state, energy) = graph.layout_energy_state();
    let mut baseline_energy = energy;
    baseline_energy.dangling_centroid_charge = 0.0;
    assert_eq!(
        energy.external_pull,
        2.0 * energy.k_spring * energy.spring_length
    );
    baseline_energy.external_pull = 0.0;
    let mut rng = SmallRng::seed_from_u64(17);
    let mut cached = energy.energy(None, &state);
    let mut baseline_cached = baseline_energy.energy(None, &state);

    for iteration in 0..100 {
        let next = PinnedLayoutNeighbor.propose(&state, &mut rng, 0.2, 0.3);
        let incremental = energy.energy(Some((&state, cached)), &next);
        let baseline_incremental = baseline_energy.energy(Some((&state, baseline_cached)), &next);
        let mut full = next.clone();
        full.incremental = false;
        let exact = energy.energy(None, &full);
        let baseline_exact = baseline_energy.energy(None, &full);
        let incremental_centroid = incremental - baseline_incremental;
        let exact_centroid = exact - baseline_exact;
        assert!(
            (incremental_centroid - exact_centroid).abs() <= 1e-9 * (1.0 + exact_centroid.abs()),
            "iteration {iteration}: incremental={incremental_centroid}, exact={exact_centroid}, difference={}",
            incremental_centroid - exact_centroid,
        );
        state = next;
        energy.on_accept(&mut state);
        cached = incremental;
        baseline_cached = baseline_incremental;
    }
}

#[test]
fn fixed_gap_labels_preserve_clearance_across_sizes_bends_and_rotations() {
    for angle in [
        0.0_f64,
        std::f64::consts::FRAC_PI_4,
        std::f64::consts::FRAC_PI_2,
    ] {
        let (sin, cos) = angle.sin_cos();
        let dot = format!(
            r#"digraph {{
                a [pos="{},{}!" "layout-width"="0.2" "layout-height"="0.2"]
                b [pos="{},{}!" "layout-width"="0.2" "layout-height"="0.2"]
                a -> b [id=0 pos="{},{}!" "label-width"="0.2" "label-height"="0.4"]
                b -> a [id=1 pos="{},{}!" "label-width"="2.2" "label-height"="1.4"]
                a -> b [id=2 pos="0,0!" "label-width"="0.6" "label-height"="0.6"]
                a -> b [id=3 pos="0,0!" "label-width"="2.0" "label-height"="1.2"]
            }}"#,
            -4.0 * cos,
            -4.0 * sin,
            4.0 * cos,
            4.0 * sin,
            -2.0 * sin,
            2.0 * cos,
            2.0 * sin,
            -2.0 * cos,
        );
        let graph = decode_graphs(&parse_dot_graphs_bytes(dot.as_bytes()).unwrap()).remove(0);
        for charge in ["0", "100"] {
            let config = BTreeMap::from([
                ("layout-algo", "tree"),
                ("layout-nodes", "fixed"),
                ("viewport-w", "2"),
                ("viewport-h", "1"),
                ("length-scale", "1"),
                ("label-layout", "fixed-gap"),
                ("internal-label-length-scale", "0.6"),
                ("label-charge", charge),
                ("label-steps", "30"),
            ]);
            let laid_out = layout_parsed_graph_bytes(&graph, &encode_cbor(&config)).unwrap();
            let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&laid_out).unwrap());
            for (edge, (width, height, side)) in edges.iter().zip([
                (0.2, 0.4, 1.0),
                (2.2, 1.4, -1.0),
                (0.6, 0.6, 1.0),
                (2.0, 1.2, 1.0),
            ]) {
                assert_eq!(edge.statements["layout-label-gap"], "0.6");
                let point = edge.pos.as_ref().unwrap();
                let label = edge.label_pos.as_ref().unwrap();
                let outward_distance =
                    side * (-(label.x - point.x) * sin + (label.y - point.y) * cos);
                let text_extent = (width * sin.abs() + height * cos.abs()) / 2.0;
                assert!(
                    (outward_distance - text_extent - 0.6).abs() < 1e-9,
                    "angle={angle}, charge={charge}, edge={}, clearance={}",
                    edge.edge,
                    outward_distance - text_extent
                );
            }
            let mut config = config;
            config.insert("label-layout", "normal");
            let relaxed = layout_parsed_graph_bytes(&laid_out, &encode_cbor(&config)).unwrap();
            let edges: Vec<TypstDotEdge> = decode_cbor(&graph_edges_bytes(&relaxed).unwrap());
            assert!(edges
                .iter()
                .all(|edge| !edge.statements.contains_key("layout-label-gap")));
        }
    }
}

#[test]
fn global_rest_length_scale_multiplies_edges_without_rescaling_forces() {
    let mut graph =
        TypstGraph::parse(r#"digraph { a -> b ["spring-length"=2]; b -> c; c -> a }"#).unwrap();
    graph.layout_config.spring.external_pull = 1.0;
    let (_, baseline_energy) = graph.layout_energy_state();
    graph.layout_config.spring_length_scale = 0.75;
    let (state, energy) = graph.layout_energy_state();
    assert_eq!(state.edge_spring_length_scales[EdgeIndex(0)], 1.5);
    assert_eq!(state.edge_spring_length_scales[EdgeIndex(1)], 0.75);
    assert_eq!(state.edge_spring_length_scales[EdgeIndex(2)], 0.75);
    assert_eq!(energy.spring_length, baseline_energy.spring_length);
    assert_eq!(energy.c_vv, baseline_energy.c_vv);
    assert_eq!(energy.external_pull, baseline_energy.external_pull);
}

#[test]
fn relaxation_parameters_reject_invalid_values() {
    for key in ["initial-repulsion", "repulsion-growth"] {
        for value in ["-0.1", "1.1", "NaN", "inf"] {
            let mut graph = TypstGraph::parse("digraph { a -> b }").unwrap();
            graph.layout_config = crate::LayoutConfig::from_figment(&Figment::from(
                Serialized::from(one_statement(key, value), Profile::Default),
            ));
            assert!(graph.validate_layout().unwrap_err().contains(key));
        }
    }
    for value in [0.0, -1.0, f64::NAN, f64::INFINITY] {
        let mut graph = TypstGraph::parse("digraph { a -> b }").unwrap();
        graph.layout_config.spring_length_scale = value;
        assert!(graph
            .validate_layout()
            .unwrap_err()
            .contains("spring-length-scale"));
    }
}

#[test]
fn iterative_layout_preserves_and_relaxes_variable_half_routes() {
    use cgmath::Point2;
    use linnet::half_edge::involution::Hedge;

    for algorithm in ["force", "anneal"] {
        let mut graph = TypstGraph::parse(
            r#"digraph {
            a [id=0 pos="0,0!"]
            b [id=1 pos="4,0!"]
            a:0 -> b:1 [id=0 pos="2,0"]
        }"#,
        )
        .unwrap();
        graph.graph[Hedge(0)].route_points = vec![Point2::new(0.5, 1.0), Point2::new(1.5, 1.0)];
        graph.graph[Hedge(1)].route_points = vec![Point2::new(3.0, -1.0)];
        let settings = BTreeMap::from([
            ("layout-algo", algorithm),
            ("steps", "0"),
            ("epochs", "1"),
            ("label-steps", "0"),
            ("beta", "0"),
            ("k-spring", "1"),
            ("depth-scale", "0"),
            ("early-tol", "0"),
            ("step", "0.01"),
        ]);
        graph.layout_config = crate::LayoutConfig::from_figment(&Figment::from(Serialized::from(
            settings.clone(),
            Profile::Default,
        )));
        let original = graph.layout_route_points();
        graph.layout_with_subgraph(None).unwrap();
        for (hedge, points) in &original {
            assert_eq!(
                &graph.graph[hedge].route_points, points,
                "{algorithm}: zero steps"
            );
        }
        let mut settings = settings;
        settings.insert("steps", "30");
        graph.layout_config = crate::LayoutConfig::from_figment(&Figment::from(Serialized::from(
            settings,
            Profile::Default,
        )));
        graph.layout_with_subgraph(None).unwrap();
        assert_ne!(
            graph.graph[Hedge(0)].route_points,
            original[Hedge(0)],
            "{algorithm}: bends must move"
        );
        assert_eq!(graph.graph[Hedge(0)].route_points.len(), 2);
        assert_eq!(graph.graph[Hedge(1)].route_points.len(), 1);
        assert_eq!(graph.graph[NodeIndex(0)].pos, Point2::new(0.0, 0.0));
        assert_eq!(graph.graph[NodeIndex(1)].pos, Point2::new(4.0, 0.0));
        graph.layout_with_subgraph(None).unwrap();
        assert_eq!(
            graph.graph[Hedge(0)].route_points.len(),
            2,
            "{algorithm}: warm start"
        );
    }
}

#[test]
fn invalid_half_route_coordinates_are_rejected_before_layout() {
    use cgmath::Point2;
    use linnet::half_edge::involution::Hedge;
    for value in [f64::NAN, f64::INFINITY] {
        let mut graph = TypstGraph::parse("digraph { a -> b }").unwrap();
        graph.graph[Hedge(0)].route_points = vec![Point2::new(value, 0.0)];
        assert!(graph
            .layout_with_subgraph(None)
            .unwrap_err()
            .contains("route points must be finite"));
    }
}

#[test]
fn isolated_half_route_writeback_preserves_complement_with_edge_shift() {
    use cgmath::Point2;
    use linnet::half_edge::involution::Hedge;

    for algorithm in ["force", "anneal"] {
        let mut graph = TypstGraph::parse(
            r#"digraph {
            a [id=0 pos="0,0!"]
            b [id=1 pos="4,0!"]
            a:0 -> b:1 [id=0 pos="2,0" shift="0.5,1.0"]
        }"#,
        )
        .unwrap();
        let source = vec![Point2::new(0.5, 1.0), Point2::new(1.5, 1.0)];
        let sink = vec![Point2::new(3.0, -1.0)];
        graph.graph[Hedge(0)].route_points = source.clone();
        graph.graph[Hedge(1)].route_points = sink.clone();
        let settings = BTreeMap::from([
            ("layout-algo", algorithm),
            ("subgraph-mode", "isolated"),
            ("steps", "0"),
            ("epochs", "0"),
            ("label-steps", "0"),
            ("depth-scale", "0"),
        ]);
        graph.layout_config = crate::LayoutConfig::from_figment(&Figment::from(Serialized::from(
            settings,
            Profile::Default,
        )));
        let mut selected = graph.empty_subgraph::<SuBitGraph>();
        selected.add(Hedge(0));
        graph.layout_with_subgraph(Some(&selected)).unwrap();
        assert_eq!(
            graph.graph[Hedge(1)].route_points,
            sink,
            "{algorithm}: inactive half moved"
        );
        assert_eq!(
            graph.graph[Hedge(0)].route_points,
            source
                .into_iter()
                .map(|point| Point2::new(point.x + 0.5, point.y + 1.0))
                .collect::<Vec<_>>(),
            "{algorithm}: active half must receive its edge shift"
        );
    }
}
