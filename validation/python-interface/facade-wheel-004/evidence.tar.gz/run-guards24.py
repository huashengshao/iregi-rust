"""Independent cold-constructor partitions on the root-assigned free CPU24."""
from pathlib import Path
import hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owned_wheel_driver',HERE/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
allowed={'affine_capability','checked_constructor','checked_plain','checked_profile','checked_dual'}
original=m.specs
stage=sys.argv[1]
assert stage in allowed
identity={'status':'independent_runtime_affinity_partition','controller_sha256':m.sha(Path(__file__)),'base_driver_sha256':m.sha(HERE/'run.py'),'context_sha256':m.sha(HERE/'context.json'),'cpu':'24','allowed_stages':sorted(allowed),'scope':'Existing constructor/empty/rejection API assertions, no timing qualification or scalar-master activation; same per-case bounds.'}
identity_path=HERE/'guards24-controller.json'
if identity_path.exists():assert m.read(identity_path)==identity
else:m.save(identity_path,identity)
def specs(name,directory):
    assert name==stage
    seconds,reserve,cpu,commands,count=original(name,directory)
    return seconds,reserve,'24',commands,count
m.specs=specs
sys.exit(m.run(stage))
