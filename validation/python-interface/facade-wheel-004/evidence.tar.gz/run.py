"""Finite current-source wheel/API qualification. No process on import."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, shutil, subprocess, sys, xml.etree.ElementTree as ET, zipfile
ROOT=Path.cwd().resolve(); HERE=Path(__file__).resolve().parent
ENV=ROOT/'.local/tirust-feature-rank6-env'
BASE=Path('/nix/store/0r6k8xa2kgqyp3r4v2w7yrb80ma2iawm-python3-3.13.12/bin/python3')
UV=Path('/nix/store/07gw2d21ivy19hgjj8wmyqhf338gqzdj-uv-0.13.1/bin/uv')
BUILDPY=ROOT/'.local/python-interface-env/bin/python'
LIFECYCLE=ROOT/'target/ibp-workspace-preparation-research/profile-n2-rank7-128/lifecycle-profile.py'
WHEEL=HERE/'wheels/tirust-0.1.0-cp310-abi3-linux_x86_64.whl'
CLIENT=HERE/'installed-client'
PINNED_CARGO=Path('/nix/store/1jwkiz96iwqdhm4bh2hvgd86ysb0b67q-cargo-1.99.0/bin/cargo')
PINNED_RUSTC=Path('/nix/store/1qg7z7i461qsv0lczc40nyi8ps6snlca-rustc-1.99.0/bin/rustc')
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):
    q=Path(p).with_suffix('.partial');q.write_text(json.dumps(v,indent=2)+'\n');q.replace(p)
def require(v,m):
    if not v:raise ValueError(m)
def load(p):
    spec=importlib.util.spec_from_file_location('current_lifecycle',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def freeze():
    require(ROOT==HERE.parents[1],'run from project root')
    require(not (HERE/'context.json').exists() and not ENV.exists() and not WHEEL.exists(),'fresh build and environment')
    previous=read(ROOT/'target/python-current-qualification-retry/context.json')
    coherent_path=ROOT/'target/checked-g-generalized-qualification/build-004/receipt.json'
    coherent=read(coherent_path)
    require(sha(coherent_path)=='371dd8662f702ca0bcb4425dbbb79ae803b2069fc22ab7c95d3b58d35ba3e106' and coherent['status']=='passed','current coherent source bodies')
    require(len(coherent['source_files'])==158,'current158 body context')
    for name,digest in coherent['source_files'].items():require(sha(name)==digest,'changed coherent body: '+name)
    paths={Path(x) for x in previous['inputs'] if not str(x).startswith('target/') and not str(x).startswith(str(ROOT/'target'))}
    for crate in ('iregi-rust','iregi-masters','iregi-prepare','iregi-python','iregi-cli'):
        paths.update(Path(f'crates/{crate}/src').rglob('*.rs'));paths.add(Path(f'crates/{crate}/Cargo.toml'))
    paths.update(Path('python/tirust').rglob('*.pyi'));paths.update(Path('python/tirust').rglob('*.py'))
    paths.update(Path('examples/notebooks').glob('*.py'))
    paths.update(Path('tests/python').glob('*.py'))
    paths.update(map(Path,('Cargo.toml','Cargo.lock','pyproject.toml','scripts/env.sh','scripts/cargo.sh')))
    paths.update((Path(__file__).resolve(),LIFECYCLE))
    paths.update(Path(name) for name in coherent['source_files'])
    paths.update((coherent_path,ROOT/'target/checked-g-generalized-qualification/build-003/receipt.json',ROOT/'target/checked-g-generalized-qualification/test-selection-bridge.json'))
    paths.update((ROOT/'target/legacy-noop-python-proposal/typing_legacy_noop_assignability.py',ROOT/'target/legacy-noop-python-proposal/typing_legacy_noop.py',ROOT/'target/legacy-noop-python-proposal/typing-output.json',ROOT/'target/legacy-noop-python-proposal/typing-receipt.json'))
    paths={p for p in paths if p.is_file()}
    context={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'current158 coherent source bodies frozen for fresh standalone native wheel',
        'inputs':{str(p):sha(p) for p in sorted(paths)},'scope':'Owned project Rust sources, selected dependency owners and frontend inputs; not a complete compiler/native/system closure. API qualification only; no new mathematical or performance gate.',
        'coherent_body_inputs':coherent['source_files'],'coherent_body_context_count':158,
        'coherent_build_004_sha256':sha(coherent_path),'production_cli_build_003_sha256':sha(ROOT/'target/checked-g-generalized-qualification/build-003/receipt.json'),
        'test_only_bridge_sha256':sha(ROOT/'target/checked-g-generalized-qualification/test-selection-bridge.json'),
        'historical_qualified_wheel003_manifest_sha256':sha(ROOT/'validation/python-interface/facade-wheel-003/manifest.json'),
        'toolchain':{str(p):{'sha256':sha(p),'version':subprocess.check_output([str(p),'--version'],text=True,timeout=10).strip()} for p in (PINNED_CARGO,PINNED_RUSTC,BASE,UV)},
        'build_budget':{'seconds':1800,'reserve':60,'cpus':'18,19,22,24','jobs':4},'runtime_cpu':'22'}
    save(HERE/'context.json',context)
    CLIENT.mkdir()
    shutil.copyfile('tests/python/typing_example.py',CLIENT/'typing_example.py')
    (CLIENT/'dispatch_client.py').write_text('from typing import TYPE_CHECKING, assert_type\nfrom tirust import ReductionPlan\nif TYPE_CHECKING:\n    from tirust._tirust import Engine\nworkspace = ReductionPlan(1, 0).workspace()\nassert_type(workspace.engine, Engine)\nassert_type(workspace.preparation_notes, list[str])\ndetail = workspace.reduce_batch([]).engine_execution\nif detail["engine"] == "generic":\n    assert_type(detail["execution"], dict[str, int])\nelif detail["engine"] == "affine_power":\n    assert_type(detail["child_methods"][0]["powers"], list[int])\nelif detail["engine"] == "certified_tensor":\n    assert_type(detail["certificate_execution"]["gram"], dict[str, int])\nelif detail["engine"] == "mass_taylor":\n    assert_type(detail["physical_components"], int)\n')
    shutil.copyfile(ROOT/'target/legacy-noop-python-proposal/typing_legacy_noop_assignability.py',CLIENT/'typing_legacy_noop_assignability.py')
    save(CLIENT/'pyrightconfig.json',{'include':['typing_example.py','dispatch_client.py','typing_legacy_noop_assignability.py'],'extraPaths':[],'typeCheckingMode':'standard','pythonVersion':'3.13','reportMissingTypeStubs':False})
    print(json.dumps({'status':'frozen','inputs':len(context['inputs']),'sha256':sha(HERE/'context.json')}))

def specs(stage,directory):
    py=str(ENV/'bin/python'); pytest=[py,'-I','-B','-m','pytest','-vv','-ra','--junitxml='+str(directory/'tests.xml')]
    dispatch='tests/python/test_tirust_dispatch.py'
    d={
      'build':(1800,60,'18,19,22,24',[
          [str(BUILDPY),'-m','maturin','build','--manifest-path','crates/iregi-python/Cargo.toml','--features','standalone,native','--profile','dev','--compatibility','linux','--jobs','4','--locked','--offline','--interpreter',str(BASE),'--out',str(HERE/'wheels')]],None),
      'install':(180,30,'22',[[str(UV),'venv','--python',str(BASE),str(ENV)],[str(UV),'pip','install','--offline','--python',py,str(WHEEL),'numpy==2.5.4','pytest==8.4.2','basedpyright==1.40.2','marimo==0.24.0']],None),
      'import':(60,20,'22',[[py,'-I','-B','-c',"import tirust,importlib,json,pathlib,sys; n=importlib.import_module('tirust._tirust'); names=('Expression','Float','ComplexFloat','Model','FeynmanDiagram','TensorExpression','ReductionPlan','Workspace'); assert all(getattr(tirust,k) is getattr(n,k) for k in names); assert not any(k=='symbolica' or k.startswith('symbolica.') for k in sys.modules); print(json.dumps({'package':tirust.__file__,'native':n.__file__,'shared_aliases':names,'python':sys.version}))"]],None),
      'upstream':(180,30,'22',[pytest+['dependencies/symbolica/lib/numerica/tests/python_complex_native_precision.py','dependencies/symbolica/lib/numerica/tests/python_floats.py']],25),
      'historical':(360,30,'22',[pytest+['tests/python/test_tirust_interop.py','tests/python/test_tirust_numerics.py']],29),
      'generic_low':(180,30,'22',[pytest+[dispatch+'::test_generic_tag_profile_and_result_snapshot_are_owned',dispatch+'::test_explicit_dual_shape_uses_generic_and_preserves_components[shape0]',dispatch+'::test_explicit_dual_shape_uses_generic_and_preserves_components[shape1]']],3),
      'affine_capability':(300,30,'22',[pytest+[dispatch+'::test_highpoint_profiling_and_zero_order_dual_keep_affine_capabilities']],1),
      'checked_constructor':(240,30,'22',[pytest+[dispatch+'::test_checked_scalar_products_require_explicit_compatible_inputs']],1),
      'checked_plain':(240,30,'22',[pytest+[dispatch+'::test_checked_scalar_products_cannot_bypass_certificates[options0]']],1),
      'checked_profile':(240,30,'22',[pytest+[dispatch+'::test_checked_scalar_products_cannot_bypass_certificates[options1]']],1),
      'checked_dual':(240,30,'22',[pytest+[dispatch+'::test_checked_scalar_products_cannot_bypass_certificates[options2]']],1),
      'legacy':(300,30,'22',[pytest+['tests/python/test_tirust_legacy_noop.py']],1),
      'n6':(300,30,'22',[pytest+[dispatch+'::test_eligible_highpoint_batch_contraction_failure_and_recovery[6-1-six_point-6]']],1),
      'n7':(600,45,'22',[pytest+[dispatch+'::test_eligible_highpoint_batch_contraction_failure_and_recovery[7-0-seven_point-21]']],1),
      'typing':(120,25,'22',[[str(ENV/'bin/basedpyright'),'--project',str(CLIENT/'pyrightconfig.json'),'--pythonpath',py,'--outputjson']],None),
      'gallery':(600,45,'22',[pytest+['tests/python/test_gallery_runtime.py']],7),
    };return d[stage]

def run(stage):
    directory=HERE/(stage+'-001');directory.mkdir(exist_ok=False)
    context=read(HERE/'context.json');seconds,reserve,cpu,commands,count=specs(stage,directory)
    lifecycle=load(LIFECYCLE);budget=lifecycle.Budget(seconds);budget.work_deadline=budget.deadline-reserve
    env=os.environ.copy();env.update(RAYON_NUM_THREADS='1',RUST_TEST_THREADS='1',NUMERICA_PYTHON_MODULE='tirust',RUSTC=str(PINNED_RUSTC))
    env['PATH']=str(PINNED_CARGO.parent)+':'+str(PINNED_RUSTC.parent)+':'+env['PATH']
    require(bool(env.get('SYMBOLICA_LICENSE')),'source private license silently')
    if stage=='build':guards=dict(context['inputs'])
    else:
        require(read(HERE/'build-001/receipt.json')['status']=='passed','build prerequisite')
        guards={str(HERE/'build-001/source-snapshot'/Path(name).resolve().relative_to(ROOT)):digest for name,digest in context['inputs'].items()}
        guards[str(WHEEL)]=read(HERE/'build-001/wheel.json')['wheel_sha256']
        guards.update({str(p):sha(p) for p in Path('tests/python').glob('*.py')})
        guards.update({str(p):sha(p) for p in CLIENT.iterdir() if p.is_file()})
    guards[str(HERE/'context.json')]=sha(HERE/'context.json')
    record={'stage':stage,'status':'preflight','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':seconds,'reserve':reserve,'cpu':cpu,'source_context_sha256':sha(HERE/'context.json'),'steps':[],'cleanup_errors':[],'performance_evidence':False,'main_source_lease':stage=='build','toolchain':context['toolchain']}
    save(directory/'receipt.json',record)
    def verify():
        for p,digest in guards.items():budget.remaining();require(sha(p)==digest,'changed owned source/product: '+p)
    good=False
    try:
        budget.arm();verify()
        for i,command in enumerate(commands):
            prefix=['taskset','-c',cpu] if stage=='build' else ['prlimit','--as=34359738368','--','taskset','-c',cpu]
            step={};record['steps'].append(step)
            def persist(value):step.update(value);save(directory/'receipt.json',record)
            result=lifecycle.execute(prefix+command,directory/f'step-{i}.log',budget,max(1,seconds-reserve-5),record['cleanup_errors'],persist,env)
            require(result['status']=='exited' and result['returncode']==0 and result['owned_group_gone'],'bounded child failed')
        if stage=='build':
            with zipfile.ZipFile(WHEEL) as z:
                native=[n for n in z.namelist() if n.startswith('tirust/_tirust') and n.endswith('.so')];require(len(native)==1,'one native owner')
                require(z.read('tirust/_tirust.pyi')==Path('python/tirust/_tirust.pyi').read_bytes(),'fresh wheel stub')
                data=z.read(native[0]);require(data[:4]==b'\x7fELF','actual native ELF')
                save(directory/'wheel.json',{'wheel':str(WHEEL),'wheel_sha256':sha(WHEEL),'wheel_bytes':WHEEL.stat().st_size,'native_member':native[0],'native_sha256':hashlib.sha256(data).hexdigest(),'native_bytes':len(data)})
            production=read(ROOT/'target/checked-g-generalized-qualification/build-003/receipt.json')
            save(directory/'existing-cli-products.json',{'coherent_source_context':'158currentbodies; only cfg(test) mass_taylor_tests.rs differs from productionCLI003, checked by retained bridge',
                'production_build_receipt_sha256':sha(ROOT/'target/checked-g-generalized-qualification/build-003/receipt.json'),'products':production['products']})
            for name,digest in context['inputs'].items():
                p=Path(name).resolve();dst=directory/'source-snapshot'/p.relative_to(ROOT);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst);require(sha(dst)==digest,'snapshot mismatch')
        elif stage=='import':
            identity=json.loads((directory/'step-0.log').read_text().splitlines()[-1]);require(Path(identity['native']).is_relative_to(ENV),'fresh installed native')
            require(sha(identity['native'])==read(HERE/'build-001/wheel.json')['native_sha256'],'installed exact native');save(directory/'identity.json',identity)
        elif count is not None:
            cases=list(ET.parse(directory/'tests.xml').iter('testcase'));require(len(cases)==count and all(not list(c) for c in cases),'exact pass count/no skips');record['test_names']=[c.attrib['name'] for c in cases]
        elif stage=='typing':
            value=read(directory/'step-0.log');require(value['summary']['errorCount']==value['summary']['warningCount']==0,'installed consumer typing');record['typing_summary']=value['summary']
        verify();good=True
    except BaseException as exc:record['error']=repr(exc)
    finally:
        budget.disarm();record.update(elapsed_seconds=budget.elapsed(),cancellation=budget.cancelled,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        record['status']='passed' if good and not record['cleanup_errors'] and not budget.cancelled and budget.elapsed()<=seconds else 'failed'
        record['saved_files']={p.name:sha(p) for p in directory.iterdir() if p.is_file() and p.name!='receipt.json'}
        save(directory/'receipt.json',record)
    print(json.dumps({'stage':stage,'status':record['status'],'elapsed_seconds':record['elapsed_seconds'],'receipt_sha256':sha(directory/'receipt.json')}));return 0 if record['status']=='passed' else 1
if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze()
    else:sys.exit(run(sys.argv[1]))
