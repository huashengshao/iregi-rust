"""Compact current-wheel source/evidence record; excludes wheel/native payloads."""
from pathlib import Path
import gzip,hashlib,io,json,os,tarfile
ROOT=Path.cwd();HERE=ROOT/'target/python-feature-wheel-current';DEST=ROOT/'validation/python-interface/facade-wheel-004'
STAGES=('build','install','import','typing','upstream','historical','generic_low','checked_constructor','checked_plain','checked_profile','checked_dual','affine_capability','legacy','n6','n7','gallery')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def archive(path,entries):
 with Path(path).open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for name,body in sorted(entries.items()):
     assert not name.startswith('/') and '..' not in Path(name).parts
     assert not body.startswith((b'\x7fELF',b'!<arch>'))
     if os.environ.get('SYMBOLICA_LICENSE'):assert os.environ['SYMBOLICA_LICENSE'].encode() not in body
     info=tarfile.TarInfo(name);info.size=len(body);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(body))
 return {'sha256':sha(Path(path).read_bytes()),'bytes':Path(path).stat().st_size,'members':{n:{'sha256':sha(b),'bytes':len(b)}for n,b in sorted(entries.items())}}
def main():
 assert all(read(HERE/(s+'-001/receipt.json'))['status']=='passed' for s in STAGES)
 assert not DEST.exists();DEST.mkdir()
 context=read(HERE/'context.json')
 sources={str(Path(n).resolve().relative_to(ROOT)):(HERE/'build-001/source-snapshot'/Path(n).resolve().relative_to(ROOT)).read_bytes() for n in context['inputs']}
 assert all(sha(sources[str(Path(n).resolve().relative_to(ROOT))])==digest for n,digest in context['inputs'].items())
 evidence={}
 for stage in STAGES:
  for p in (HERE/(stage+'-001')).iterdir():
   if p.is_file():evidence[f'{stage}-001/{p.name}']=p.read_bytes()
 for p in HERE.iterdir():
  if p.is_file() and p.suffix in ('.py','.json'):evidence[p.name]=p.read_bytes()
 for p in (HERE/'installed-client').iterdir():
  if p.is_file():evidence['installed-client/'+p.name]=p.read_bytes()
 prior=ROOT/'target/legacy-noop-python-proposal';old=read(prior/'typing-receipt.json')
 for name,digest in old['source_sha256'].items():
  p=ROOT/name;body=p.read_bytes();assert sha(body)==digest
  evidence['preserved-recursive-observer/'+str(p.relative_to(prior))]=body
 for p in (prior/'typing-output.json',prior/'typing-receipt.json'):evidence['preserved-recursive-observer/'+p.name]=p.read_bytes()
 manifest={'status':'passed_current_installed_feature_wheel','source_context_sha256':sha((HERE/'context.json').read_bytes()),'coherent_body_context_count':158,'selected_source_files':len(sources),'tests':{'upstream':25,'historical':29,'generic_low':3,'checked_constructor':1,'checked_plain':1,'checked_profile':1,'checked_dual':1,'affine_capability':1,'legacy':1,'n6':1,'n7':1,'api_total':65,'gallery':7,'total':72},'wheel':read(HERE/'build-001/wheel.json'),'scope':'Fresh installed API/shared-type/typing/notebook qualification on retained fixtures, including Legacy no-op admission and current MassTaylor routing. No new independent integral, highpoint Dual or performance qualification. Historical wheel003 remains unchanged; current source closure is selected files, not a complete compiler/native/system closure.'}
 manifest['sources']=archive(DEST/'sources.tar.gz',sources);manifest['evidence']=archive(DEST/'evidence.tar.gz',evidence)
 (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps({'selected_sources':len(sources),'coherent_bodies':158,'evidence_files':len(evidence),'archive_bytes':manifest['sources']['bytes']+manifest['evidence']['bytes']}))
if __name__=='__main__':main()
