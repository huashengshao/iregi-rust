"""Static-only consumer of the recursive installed EngineExecution union."""
from __future__ import annotations
from typing import TYPE_CHECKING, assert_type

if TYPE_CHECKING:
    from tirust import BatchResult
    from tirust._tirust import EngineExecution, LegacyNoOpEngineExecution


def inspect_legacy(detail: LegacyNoOpEngineExecution) -> int:
    assert_type(detail["certificate_execution"], dict[str, int])
    assert_type(detail["child_preparation_error"], str | None)
    child = detail["child"]
    assert_type(child, EngineExecution | None)
    if child is None:
        return 0
    if child["engine"] == "generic":
        assert_type(child["execution"], dict[str, int])
        return child["execution"]["input_rows"]
    if child["engine"] == "legacy_noop":
        assert_type(child, LegacyNoOpEngineExecution)
        assert_type(child["child"], EngineExecution | None)
        return inspect_legacy(child)
    return detail["accepted_rows"]


def inspect_result(result: BatchResult) -> int:
    detail = result.engine_execution
    if detail["engine"] != "legacy_noop":
        return 0
    assert_type(detail, LegacyNoOpEngineExecution)
    return inspect_legacy(detail)
