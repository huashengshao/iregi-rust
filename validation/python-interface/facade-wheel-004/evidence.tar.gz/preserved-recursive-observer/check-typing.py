"""Static-only check against copied current stubs; starts no numerical host."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
ROOT=Path.cwd();HERE=ROOT/'target/legacy-noop-python-proposal'
LIFE=ROOT/'target/ibp-workspace-preparation-research/profile-n2-rank7-128/lifecycle-profile.py'
spec=importlib.util.spec_from_file_location('life',LIFE);life=importlib.util.module_from_spec(spec);spec.loader.exec_module(life)
record={'status':'preflight','native_evaluations':0,'main_changes':False,'cleanup_errors':[],'steps':[],'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [HERE/'typing_legacy_noop.py',HERE/'stubs/tirust/_tirust.pyi',HERE/'pyrightconfig.json',Path(__file__).resolve()]}}
path=HERE/'typing-receipt.json'
def save():path.write_text(json.dumps(record,indent=2)+'\n')
budget=life.Budget(60);budget.work_deadline=budget.deadline-10;good=False;save()
try:
 budget.arm();step={};record['steps'].append(step)
 def persist(value):step.update(value);save()
 command=['prlimit','--as=34359738368','--','taskset','-c','31',str(ROOT/'.local/tirust-current-rank6-env/bin/basedpyright'),'--project',str(HERE/'pyrightconfig.json'),'--pythonpath',str(ROOT/'.local/tirust-current-rank6-env/bin/python'),'--outputjson']
 result=life.execute(command,HERE/'typing-output.json',budget,45,record['cleanup_errors'],persist,os.environ.copy())
 if result['status']!='exited' or result['returncode']!=0:raise ValueError('static typecheck failed')
 value=json.loads((HERE/'typing-output.json').read_text());record['summary']=value['summary']
 if value['summary']['errorCount'] or value['summary']['warningCount']:raise ValueError('static consumer diagnostics')
 good=True
except BaseException as error:record['error']=repr(error)
finally:
 budget.disarm();record['elapsed_seconds']=budget.elapsed();record['status']='passed' if good and not record['cleanup_errors'] else 'failed';save()
print(json.dumps({k:record[k] for k in ('status','elapsed_seconds','native_evaluations','main_changes')},indent=2));sys.exit(0 if record['status']=='passed' else 1)
