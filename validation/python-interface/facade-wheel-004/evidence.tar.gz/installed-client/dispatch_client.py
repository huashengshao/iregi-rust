from typing import TYPE_CHECKING, assert_type
from tirust import ReductionPlan
if TYPE_CHECKING:
    from tirust._tirust import Engine
workspace = ReductionPlan(1, 0).workspace()
assert_type(workspace.engine, Engine)
assert_type(workspace.preparation_notes, list[str])
detail = workspace.reduce_batch([]).engine_execution
if detail["engine"] == "generic":
    assert_type(detail["execution"], dict[str, int])
elif detail["engine"] == "affine_power":
    assert_type(detail["child_methods"][0]["powers"], list[int])
elif detail["engine"] == "certified_tensor":
    assert_type(detail["certificate_execution"]["gram"], dict[str, int])
elif detail["engine"] == "mass_taylor":
    assert_type(detail["user_components"], int)
    assert_type(detail["internal_components"], int)
