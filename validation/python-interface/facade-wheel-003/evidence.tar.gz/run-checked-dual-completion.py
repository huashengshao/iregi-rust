"""Complete the one unfinished node after a preserved aggregate-stage timeout."""
from pathlib import Path
import importlib.util,re,sys
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('current_frontend',HERE/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old_specs=m.specs
NODE='tests/python/test_tirust_dispatch.py::test_checked_scalar_products_cannot_bypass_certificates[options2]'
def specs(stage,directory):
    assert stage=='checked_dual'
    old=m.read(HERE/'dispatch-001/receipt.json')
    assert old['status']=='failed' and not old['cleanup_errors'] and old['steps'][0].get('timeout') and old['steps'][0]['owned_group_gone']
    text=(HERE/'dispatch-001/step-0.log').read_text()
    passed=re.findall(r'^(tests/python/test_tirust_dispatch\.py::\S+) PASSED(?:\s|$)',text,re.M)
    assert len(passed)==len(set(passed))==7 and NODE not in passed
    command=[str(m.ENV/'bin/python'),'-I','-B','-m','pytest','-vv','-ra','--junitxml='+str(directory/'tests.xml'),NODE]
    return 240,30,'31',[command],1
m.specs=specs
sys.exit(m.run('checked_dual'))
