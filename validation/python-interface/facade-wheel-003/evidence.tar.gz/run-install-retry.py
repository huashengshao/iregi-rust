"""Install exact requested pins after preserved offline marimo cache miss."""
from pathlib import Path
import importlib.util,sys
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('current_frontend',HERE/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old_specs=m.specs
def specs(stage,directory):
    assert stage=='install_retry'
    seconds,reserve,cpu,commands,count=old_specs('install',directory)
    # The first stage created this fresh venv and failed dependency resolution
    # before installing any package. Retain that venv, permit pinned downloads.
    assert m.read(HERE/'install-001/receipt.json')['status']=='failed'
    command=[arg for arg in commands[1] if arg!='--offline']
    return seconds,reserve,cpu,[command],count
m.specs=specs
sys.exit(m.run('install_retry'))
