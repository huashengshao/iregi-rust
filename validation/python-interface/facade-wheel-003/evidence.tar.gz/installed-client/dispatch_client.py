from typing import Literal, assert_type
from tirust import ReductionPlan
workspace = ReductionPlan(1, 0).workspace()
assert_type(workspace.engine, Literal["generic", "six_point", "six_point_hybrid", "certified_tensor", "seven_point", "affine_power"])
assert_type(workspace.preparation_notes, list[str])
detail = workspace.reduce_batch([]).engine_execution
if detail["engine"] == "generic":
    assert_type(detail["execution"], dict[str, int])
elif detail["engine"] == "affine_power":
    assert_type(detail["child_methods"][0]["powers"], list[int])
elif detail["engine"] == "certified_tensor":
    assert_type(detail["certificate_execution"]["gram"], dict[str, int])
