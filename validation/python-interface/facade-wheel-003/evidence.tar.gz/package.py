"""Compact final API record; archives source/evidence, never wheels or secrets."""
from pathlib import Path
import gzip, hashlib, io, json, os, tarfile
ROOT=Path.cwd().resolve();HERE=Path(__file__).resolve().parent
DEST=ROOT/'validation/python-interface/facade-wheel-003'
def sha_bytes(data):return hashlib.sha256(data).hexdigest()
def sha(p):return sha_bytes(Path(p).read_bytes())
def read(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def archive(path,entries):
    with Path(path).open('xb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for name,data in sorted(entries.items()):
                    assert not name.startswith('/') and '..' not in Path(name).parts
                    assert not data.startswith((b'\x7fELF',b'!<arch>'))
                    if os.environ.get('SYMBOLICA_LICENSE'):assert os.environ['SYMBOLICA_LICENSE'].encode() not in data
                    info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
    return {'sha256':sha(path),'bytes':Path(path).stat().st_size,'members':{n:{'sha256':sha_bytes(d),'bytes':len(d)} for n,d in sorted(entries.items())}}
def main():
    stages=('build','install','import','upstream','historical','n6','n7','typing','gallery','checked_dual')
    phase_directories={s:('install_retry-001' if s=='install' else s+'-001') for s in stages}
    assert all(read(HERE/phase_directories[s]/'receipt.json')['status']=='passed' for s in stages)
    assert not DEST.exists();DEST.mkdir(parents=True)
    context=read(HERE/'context.json')
    sources={str(Path(n).resolve().relative_to(ROOT)):(HERE/'build-001/source-snapshot'/Path(n).resolve().relative_to(ROOT)).read_bytes() for n in context['inputs']}
    assert all(sha_bytes(sources[str(Path(n).resolve().relative_to(ROOT))])==v for n,v in context['inputs'].items())
    evidence={}
    for stage in stages:
        for p in (HERE/phase_directories[stage]).iterdir():
            if p.is_file() and p.name!='owned-cli-tests':evidence[f'{phase_directories[stage]}/{p.name}']=p.read_bytes()
    for p in (HERE/'dispatch-001').iterdir():
        if p.is_file():evidence['dispatch-001/'+p.name]=p.read_bytes()
    for p in (HERE/'cli-binary-001').iterdir():
        if p.is_file() and p.name!='owned-iregi-rust':evidence['cli-binary-001/'+p.name]=p.read_bytes()
    for p in (HERE/'install-001').iterdir():
        if p.is_file():evidence['preserved-install-cache-miss/'+p.name]=p.read_bytes()
    for p in HERE.glob('*.py'):
        evidence[p.name]=p.read_bytes()
    for p in HERE.glob('*.json'):evidence[p.name]=p.read_bytes()
    for p in (HERE/'installed-client').iterdir():
        if p.is_file():evidence['installed-client/'+p.name]=p.read_bytes()
    old=ROOT/'target/python-current-qualification'
    for p in [old/'context.json',old/'run.py',old/'build-001/receipt.json',old/'build-001/step-0.log']:
        evidence['preserved-toolchain-failure/'+str(p.relative_to(old))]=p.read_bytes()
    evidence['package.py']=Path(__file__).read_bytes()
    manifest={'status':'passed_scoped_current_installed_api','source_context_sha256':sha(HERE/'context.json'),'tests':{'upstream':25,'historical':29,'dispatch':8,'n6':1,'n7':1,'gallery':7,'total':71},'dispatch_coverage':{'partial_phase':'dispatch-001','partial_status':'timeout_after_seven_actual_passes','completion_phase':'checked_dual-001','completion_node':'tests/python/test_tirust_dispatch.py::test_checked_scalar_products_cannot_bypass_certificates[options2]'},'phase_directories':phase_directories,'first_failed_build_common_inputs':{'count':146,'all_hashes_equal':True},'source_files':len(sources),'wheel':read(HERE/'build-001/wheel.json'),'cli_test_product':read(HERE/'build-001/cli-test-product.json'),'cli_binary_product':read(HERE/'cli-binary-001/product.json'),'scope':'Installed frontend/shared-native-object/state/typing and existing marimo runtime qualification only. No new full-array integral or performance gate. Existing N7scalar regression only. Selected source snapshot is not a full compiler/native/system closure. Failed external toolchain removal is retained separately; exact preceding toolchain was restored and GC-rooted. The failed eight-case aggregate dispatch phase is preserved: seven cases passed in its raw pytest log, and only the unfinished final case was completed with a full per-case budget.'}
    manifest['sources']=archive(DEST/'sources.tar.gz',sources)
    manifest['evidence']=archive(DEST/'evidence.tar.gz',evidence)
    save(DEST/'manifest.json',manifest)
    print(json.dumps({'manifest':str(DEST/'manifest.json'),'sources':len(sources),'evidence_files':len(evidence),'archive_bytes':manifest['sources']['bytes']+manifest['evidence']['bytes']}))
if __name__=='__main__':main()
