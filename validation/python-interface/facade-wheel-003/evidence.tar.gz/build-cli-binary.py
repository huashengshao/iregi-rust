"""Small root-requested standalone CLI suffix to the same source build lease."""
from pathlib import Path
import importlib.util,json,os,shutil,sys
ROOT=Path.cwd().resolve();HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('base_frontend',HERE/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
directory=HERE/'cli-binary-001';directory.mkdir(exist_ok=False)
context=m.read(HERE/'context.json');m.require(m.read(HERE/'build-001/receipt.json')['status']=='passed','preceding current warm build')
lifecycle=m.load(m.LIFECYCLE);budget=lifecycle.Budget(300);budget.work_deadline=budget.deadline-30
record={'status':'preflight','source_context_sha256':m.sha(HERE/'context.json'),'controller_sha256':m.sha(Path(__file__)),'seconds':300,'reserve':30,'steps':[],'cleanup_errors':[],'main_source_lease':True,'performance_evidence':False,'toolchain':context['toolchain']}
m.save(directory/'receipt.json',record)
def verify():
 for p,d in context['inputs'].items():budget.remaining();m.require(m.sha(p)==d,'changed source: '+p)
env=os.environ.copy();env.update(RAYON_NUM_THREADS='1',RUST_TEST_THREADS='1',RUSTC=str(m.PINNED_RUSTC));env['PATH']=str(m.PINNED_CARGO.parent)+':'+str(m.PINNED_RUSTC.parent)+':'+env['PATH']
good=False
try:
 budget.arm();verify()
 step={};record['steps'].append(step)
 def persist(v):step.update(v);m.save(directory/'receipt.json',record)
 command=['taskset','-c','24,26,28,30',str(m.PINNED_CARGO),'build','--locked','--offline','-p','iregi-cli','--bin','iregi-rust','--message-format=json','-j','4']
 result=lifecycle.execute(command,directory/'step-0.log',budget,250,record['cleanup_errors'],persist,env)
 m.require(result['status']=='exited' and result['returncode']==0 and result['owned_group_gone'],'bounded CLI suffix failed')
 products=[]
 for line in (directory/'step-0.log').read_text().splitlines():
  try:row=json.loads(line)
  except json.JSONDecodeError:continue
  if row.get('reason')=='compiler-artifact' and row.get('executable') and row.get('target',{}).get('name')=='iregi-rust' and not row.get('profile',{}).get('test'):products.append(Path(row['executable']))
 m.require(len(products)==1,'one standalone CLI')
 owned=directory/'owned-iregi-rust';shutil.copyfile(products[0],owned);owned.chmod(0o500)
 m.save(directory/'product.json',{'source_path':str(products[0]),'owned_path':str(owned),'sha256':m.sha(owned),'bytes':owned.stat().st_size,'source_context_sha256':m.sha(HERE/'context.json')})
 verify();good=True
except BaseException as exc:record['error']=repr(exc)
finally:
 budget.disarm();record.update(elapsed_seconds=budget.elapsed(),cancellation=budget.cancelled)
 record['status']='passed' if good and not record['cleanup_errors'] and not budget.cancelled and budget.elapsed()<=300 else 'failed'
 record['saved_files']={p.name:m.sha(p) for p in directory.iterdir() if p.is_file() and p.name!='receipt.json'};m.save(directory/'receipt.json',record)
print(json.dumps({'stage':'cli_binary','status':record['status'],'elapsed_seconds':record['elapsed_seconds'],'receipt_sha256':m.sha(directory/'receipt.json')}));sys.exit(0 if record['status']=='passed' else 1)
